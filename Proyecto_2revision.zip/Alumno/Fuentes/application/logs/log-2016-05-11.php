<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-11 17:41:15 --> Config Class Initialized
INFO - 2016-05-11 17:41:15 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:41:15 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:41:15 --> Utf8 Class Initialized
INFO - 2016-05-11 17:41:15 --> URI Class Initialized
DEBUG - 2016-05-11 17:41:16 --> No URI present. Default controller set.
INFO - 2016-05-11 17:41:16 --> Router Class Initialized
INFO - 2016-05-11 17:41:16 --> Output Class Initialized
INFO - 2016-05-11 17:41:16 --> Security Class Initialized
DEBUG - 2016-05-11 17:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:41:16 --> Input Class Initialized
INFO - 2016-05-11 17:41:16 --> Language Class Initialized
INFO - 2016-05-11 17:41:16 --> Loader Class Initialized
INFO - 2016-05-11 17:41:16 --> Helper loaded: url_helper
INFO - 2016-05-11 17:41:16 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:41:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:41:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:41:16 --> Helper loaded: form_helper
INFO - 2016-05-11 17:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:41:16 --> Form Validation Class Initialized
INFO - 2016-05-11 17:41:16 --> Controller Class Initialized
INFO - 2016-05-11 17:41:16 --> Model Class Initialized
INFO - 2016-05-11 17:41:16 --> Database Driver Class Initialized
INFO - 2016-05-11 17:41:16 --> Config Class Initialized
INFO - 2016-05-11 17:41:16 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:41:16 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:41:16 --> Utf8 Class Initialized
INFO - 2016-05-11 17:41:16 --> URI Class Initialized
INFO - 2016-05-11 17:41:16 --> Router Class Initialized
INFO - 2016-05-11 17:41:16 --> Output Class Initialized
INFO - 2016-05-11 17:41:16 --> Security Class Initialized
DEBUG - 2016-05-11 17:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:41:16 --> Input Class Initialized
INFO - 2016-05-11 17:41:16 --> Language Class Initialized
INFO - 2016-05-11 17:41:16 --> Loader Class Initialized
INFO - 2016-05-11 17:41:16 --> Helper loaded: url_helper
INFO - 2016-05-11 17:41:16 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:41:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:41:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:41:16 --> Helper loaded: form_helper
INFO - 2016-05-11 17:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:41:16 --> Form Validation Class Initialized
INFO - 2016-05-11 17:41:16 --> Controller Class Initialized
INFO - 2016-05-11 17:41:16 --> Model Class Initialized
INFO - 2016-05-11 17:41:16 --> Database Driver Class Initialized
INFO - 2016-05-11 17:41:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-11 17:41:16 --> Final output sent to browser
DEBUG - 2016-05-11 17:41:16 --> Total execution time: 0.2473
INFO - 2016-05-11 17:41:23 --> Config Class Initialized
INFO - 2016-05-11 17:41:23 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:41:23 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:41:23 --> Utf8 Class Initialized
INFO - 2016-05-11 17:41:23 --> URI Class Initialized
INFO - 2016-05-11 17:41:23 --> Router Class Initialized
INFO - 2016-05-11 17:41:23 --> Output Class Initialized
INFO - 2016-05-11 17:41:23 --> Security Class Initialized
DEBUG - 2016-05-11 17:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:41:23 --> Input Class Initialized
INFO - 2016-05-11 17:41:23 --> Language Class Initialized
INFO - 2016-05-11 17:41:23 --> Loader Class Initialized
INFO - 2016-05-11 17:41:23 --> Helper loaded: url_helper
INFO - 2016-05-11 17:41:23 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:41:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:41:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:41:23 --> Helper loaded: form_helper
INFO - 2016-05-11 17:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:41:23 --> Form Validation Class Initialized
INFO - 2016-05-11 17:41:23 --> Controller Class Initialized
INFO - 2016-05-11 17:41:23 --> Model Class Initialized
INFO - 2016-05-11 17:41:23 --> Database Driver Class Initialized
INFO - 2016-05-11 17:41:23 --> Config Class Initialized
INFO - 2016-05-11 17:41:23 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:41:23 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:41:23 --> Utf8 Class Initialized
INFO - 2016-05-11 17:41:23 --> URI Class Initialized
DEBUG - 2016-05-11 17:41:23 --> No URI present. Default controller set.
INFO - 2016-05-11 17:41:23 --> Router Class Initialized
INFO - 2016-05-11 17:41:23 --> Output Class Initialized
INFO - 2016-05-11 17:41:23 --> Security Class Initialized
DEBUG - 2016-05-11 17:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:41:23 --> Input Class Initialized
INFO - 2016-05-11 17:41:23 --> Language Class Initialized
INFO - 2016-05-11 17:41:23 --> Loader Class Initialized
INFO - 2016-05-11 17:41:23 --> Helper loaded: url_helper
INFO - 2016-05-11 17:41:23 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:41:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:41:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:41:23 --> Helper loaded: form_helper
INFO - 2016-05-11 17:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:41:23 --> Form Validation Class Initialized
INFO - 2016-05-11 17:41:23 --> Controller Class Initialized
INFO - 2016-05-11 17:41:23 --> Model Class Initialized
INFO - 2016-05-11 17:41:23 --> Database Driver Class Initialized
ERROR - 2016-05-11 17:41:24 --> Severity: Error --> Call to undefined method Mdl_tienda::getProductos() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Main.php 24
INFO - 2016-05-11 17:41:36 --> Config Class Initialized
INFO - 2016-05-11 17:41:36 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:41:36 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:41:36 --> Utf8 Class Initialized
INFO - 2016-05-11 17:41:36 --> URI Class Initialized
DEBUG - 2016-05-11 17:41:36 --> No URI present. Default controller set.
INFO - 2016-05-11 17:41:36 --> Router Class Initialized
INFO - 2016-05-11 17:41:36 --> Output Class Initialized
INFO - 2016-05-11 17:41:36 --> Security Class Initialized
DEBUG - 2016-05-11 17:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:41:36 --> Input Class Initialized
INFO - 2016-05-11 17:41:36 --> Language Class Initialized
INFO - 2016-05-11 17:41:36 --> Loader Class Initialized
INFO - 2016-05-11 17:41:36 --> Helper loaded: url_helper
INFO - 2016-05-11 17:41:36 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:41:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:41:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:41:36 --> Helper loaded: form_helper
INFO - 2016-05-11 17:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:41:36 --> Form Validation Class Initialized
INFO - 2016-05-11 17:41:36 --> Controller Class Initialized
INFO - 2016-05-11 17:41:36 --> Model Class Initialized
INFO - 2016-05-11 17:41:36 --> Database Driver Class Initialized
INFO - 2016-05-11 17:41:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 17:41:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 17:41:36 --> Final output sent to browser
DEBUG - 2016-05-11 17:41:36 --> Total execution time: 0.2352
INFO - 2016-05-11 17:48:09 --> Config Class Initialized
INFO - 2016-05-11 17:48:09 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:48:09 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:48:09 --> Utf8 Class Initialized
INFO - 2016-05-11 17:48:09 --> URI Class Initialized
DEBUG - 2016-05-11 17:48:09 --> No URI present. Default controller set.
INFO - 2016-05-11 17:48:09 --> Router Class Initialized
INFO - 2016-05-11 17:48:09 --> Output Class Initialized
INFO - 2016-05-11 17:48:09 --> Security Class Initialized
DEBUG - 2016-05-11 17:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:48:09 --> Input Class Initialized
INFO - 2016-05-11 17:48:09 --> Language Class Initialized
INFO - 2016-05-11 17:48:09 --> Loader Class Initialized
INFO - 2016-05-11 17:48:09 --> Helper loaded: url_helper
INFO - 2016-05-11 17:48:09 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:48:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:48:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:48:09 --> Helper loaded: form_helper
INFO - 2016-05-11 17:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:48:09 --> Form Validation Class Initialized
INFO - 2016-05-11 17:48:09 --> Controller Class Initialized
INFO - 2016-05-11 17:48:09 --> Model Class Initialized
INFO - 2016-05-11 17:48:09 --> Database Driver Class Initialized
INFO - 2016-05-11 17:48:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 17:48:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 17:48:09 --> Final output sent to browser
DEBUG - 2016-05-11 17:48:09 --> Total execution time: 0.1430
INFO - 2016-05-11 17:48:41 --> Config Class Initialized
INFO - 2016-05-11 17:48:41 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:48:41 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:48:41 --> Utf8 Class Initialized
INFO - 2016-05-11 17:48:41 --> URI Class Initialized
DEBUG - 2016-05-11 17:48:41 --> No URI present. Default controller set.
INFO - 2016-05-11 17:48:41 --> Router Class Initialized
INFO - 2016-05-11 17:48:41 --> Output Class Initialized
INFO - 2016-05-11 17:48:41 --> Security Class Initialized
DEBUG - 2016-05-11 17:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:48:41 --> Input Class Initialized
INFO - 2016-05-11 17:48:41 --> Language Class Initialized
INFO - 2016-05-11 17:48:41 --> Loader Class Initialized
INFO - 2016-05-11 17:48:41 --> Helper loaded: url_helper
INFO - 2016-05-11 17:48:41 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:48:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:48:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:48:41 --> Helper loaded: form_helper
INFO - 2016-05-11 17:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:48:41 --> Form Validation Class Initialized
INFO - 2016-05-11 17:48:41 --> Controller Class Initialized
INFO - 2016-05-11 17:48:41 --> Model Class Initialized
INFO - 2016-05-11 17:48:41 --> Database Driver Class Initialized
INFO - 2016-05-11 17:48:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 17:48:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 17:48:41 --> Final output sent to browser
DEBUG - 2016-05-11 17:48:41 --> Total execution time: 0.2032
INFO - 2016-05-11 17:52:42 --> Config Class Initialized
INFO - 2016-05-11 17:52:42 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:52:42 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:52:42 --> Utf8 Class Initialized
INFO - 2016-05-11 17:52:42 --> URI Class Initialized
DEBUG - 2016-05-11 17:52:42 --> No URI present. Default controller set.
INFO - 2016-05-11 17:52:42 --> Router Class Initialized
INFO - 2016-05-11 17:52:42 --> Output Class Initialized
INFO - 2016-05-11 17:52:42 --> Security Class Initialized
DEBUG - 2016-05-11 17:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:52:42 --> Input Class Initialized
INFO - 2016-05-11 17:52:42 --> Language Class Initialized
INFO - 2016-05-11 17:52:42 --> Loader Class Initialized
INFO - 2016-05-11 17:52:42 --> Helper loaded: url_helper
INFO - 2016-05-11 17:52:42 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:52:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:52:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:52:42 --> Helper loaded: form_helper
INFO - 2016-05-11 17:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:52:42 --> Form Validation Class Initialized
INFO - 2016-05-11 17:52:42 --> Controller Class Initialized
INFO - 2016-05-11 17:52:42 --> Model Class Initialized
INFO - 2016-05-11 17:52:42 --> Database Driver Class Initialized
INFO - 2016-05-11 17:52:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 17:52:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 17:52:42 --> Final output sent to browser
DEBUG - 2016-05-11 17:52:42 --> Total execution time: 0.0907
INFO - 2016-05-11 17:53:00 --> Config Class Initialized
INFO - 2016-05-11 17:53:00 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:53:00 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:53:00 --> Utf8 Class Initialized
INFO - 2016-05-11 17:53:00 --> URI Class Initialized
DEBUG - 2016-05-11 17:53:00 --> No URI present. Default controller set.
INFO - 2016-05-11 17:53:00 --> Router Class Initialized
INFO - 2016-05-11 17:53:00 --> Output Class Initialized
INFO - 2016-05-11 17:53:00 --> Security Class Initialized
DEBUG - 2016-05-11 17:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:53:00 --> Input Class Initialized
INFO - 2016-05-11 17:53:00 --> Language Class Initialized
INFO - 2016-05-11 17:53:00 --> Loader Class Initialized
INFO - 2016-05-11 17:53:00 --> Helper loaded: url_helper
INFO - 2016-05-11 17:53:00 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:53:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:53:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:53:00 --> Helper loaded: form_helper
INFO - 2016-05-11 17:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:53:00 --> Form Validation Class Initialized
INFO - 2016-05-11 17:53:00 --> Controller Class Initialized
INFO - 2016-05-11 17:53:00 --> Model Class Initialized
INFO - 2016-05-11 17:53:00 --> Database Driver Class Initialized
INFO - 2016-05-11 17:53:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 17:53:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 17:53:00 --> Final output sent to browser
DEBUG - 2016-05-11 17:53:00 --> Total execution time: 0.0748
INFO - 2016-05-11 17:53:01 --> Config Class Initialized
INFO - 2016-05-11 17:53:01 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:53:01 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:53:01 --> Utf8 Class Initialized
INFO - 2016-05-11 17:53:01 --> URI Class Initialized
DEBUG - 2016-05-11 17:53:01 --> No URI present. Default controller set.
INFO - 2016-05-11 17:53:01 --> Router Class Initialized
INFO - 2016-05-11 17:53:01 --> Output Class Initialized
INFO - 2016-05-11 17:53:01 --> Security Class Initialized
DEBUG - 2016-05-11 17:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:53:01 --> Input Class Initialized
INFO - 2016-05-11 17:53:01 --> Language Class Initialized
INFO - 2016-05-11 17:53:01 --> Loader Class Initialized
INFO - 2016-05-11 17:53:01 --> Helper loaded: url_helper
INFO - 2016-05-11 17:53:01 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:53:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:53:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:53:01 --> Helper loaded: form_helper
INFO - 2016-05-11 17:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:53:01 --> Form Validation Class Initialized
INFO - 2016-05-11 17:53:01 --> Controller Class Initialized
INFO - 2016-05-11 17:53:02 --> Model Class Initialized
INFO - 2016-05-11 17:53:02 --> Database Driver Class Initialized
INFO - 2016-05-11 17:53:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 17:53:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 17:53:02 --> Final output sent to browser
DEBUG - 2016-05-11 17:53:02 --> Total execution time: 0.0847
INFO - 2016-05-11 17:53:47 --> Config Class Initialized
INFO - 2016-05-11 17:53:47 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:53:47 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:53:47 --> Utf8 Class Initialized
INFO - 2016-05-11 17:53:47 --> URI Class Initialized
DEBUG - 2016-05-11 17:53:47 --> No URI present. Default controller set.
INFO - 2016-05-11 17:53:47 --> Router Class Initialized
INFO - 2016-05-11 17:53:47 --> Output Class Initialized
INFO - 2016-05-11 17:53:47 --> Security Class Initialized
DEBUG - 2016-05-11 17:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:53:47 --> Input Class Initialized
INFO - 2016-05-11 17:53:47 --> Language Class Initialized
INFO - 2016-05-11 17:53:47 --> Loader Class Initialized
INFO - 2016-05-11 17:53:47 --> Helper loaded: url_helper
INFO - 2016-05-11 17:53:47 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:53:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:53:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:53:47 --> Helper loaded: form_helper
INFO - 2016-05-11 17:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:53:47 --> Form Validation Class Initialized
INFO - 2016-05-11 17:53:47 --> Controller Class Initialized
INFO - 2016-05-11 17:53:47 --> Model Class Initialized
INFO - 2016-05-11 17:53:47 --> Database Driver Class Initialized
INFO - 2016-05-11 17:53:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 17:53:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 17:53:47 --> Final output sent to browser
DEBUG - 2016-05-11 17:53:47 --> Total execution time: 0.1175
INFO - 2016-05-11 17:54:05 --> Config Class Initialized
INFO - 2016-05-11 17:54:05 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:54:05 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:54:05 --> Utf8 Class Initialized
INFO - 2016-05-11 17:54:05 --> URI Class Initialized
DEBUG - 2016-05-11 17:54:05 --> No URI present. Default controller set.
INFO - 2016-05-11 17:54:05 --> Router Class Initialized
INFO - 2016-05-11 17:54:05 --> Output Class Initialized
INFO - 2016-05-11 17:54:05 --> Security Class Initialized
DEBUG - 2016-05-11 17:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:54:05 --> Input Class Initialized
INFO - 2016-05-11 17:54:05 --> Language Class Initialized
INFO - 2016-05-11 17:54:05 --> Loader Class Initialized
INFO - 2016-05-11 17:54:05 --> Helper loaded: url_helper
INFO - 2016-05-11 17:54:05 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:54:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:54:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:54:05 --> Helper loaded: form_helper
INFO - 2016-05-11 17:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:54:05 --> Form Validation Class Initialized
INFO - 2016-05-11 17:54:05 --> Controller Class Initialized
INFO - 2016-05-11 17:54:05 --> Model Class Initialized
INFO - 2016-05-11 17:54:05 --> Database Driver Class Initialized
INFO - 2016-05-11 17:54:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 17:54:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 17:54:05 --> Final output sent to browser
DEBUG - 2016-05-11 17:54:05 --> Total execution time: 0.1913
INFO - 2016-05-11 17:54:21 --> Config Class Initialized
INFO - 2016-05-11 17:54:21 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:54:21 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:54:21 --> Utf8 Class Initialized
INFO - 2016-05-11 17:54:21 --> URI Class Initialized
INFO - 2016-05-11 17:54:21 --> Router Class Initialized
INFO - 2016-05-11 17:54:21 --> Output Class Initialized
INFO - 2016-05-11 17:54:21 --> Security Class Initialized
DEBUG - 2016-05-11 17:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:54:21 --> Input Class Initialized
INFO - 2016-05-11 17:54:21 --> Language Class Initialized
INFO - 2016-05-11 17:54:21 --> Loader Class Initialized
INFO - 2016-05-11 17:54:21 --> Helper loaded: url_helper
INFO - 2016-05-11 17:54:21 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:54:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:54:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:54:21 --> Helper loaded: form_helper
INFO - 2016-05-11 17:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:54:21 --> Form Validation Class Initialized
INFO - 2016-05-11 17:54:21 --> Controller Class Initialized
INFO - 2016-05-11 17:54:21 --> Config Class Initialized
INFO - 2016-05-11 17:54:21 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:54:21 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:54:21 --> Utf8 Class Initialized
INFO - 2016-05-11 17:54:21 --> URI Class Initialized
INFO - 2016-05-11 17:54:21 --> Router Class Initialized
INFO - 2016-05-11 17:54:21 --> Output Class Initialized
INFO - 2016-05-11 17:54:21 --> Security Class Initialized
DEBUG - 2016-05-11 17:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:54:21 --> Input Class Initialized
INFO - 2016-05-11 17:54:21 --> Language Class Initialized
INFO - 2016-05-11 17:54:21 --> Loader Class Initialized
INFO - 2016-05-11 17:54:21 --> Helper loaded: url_helper
INFO - 2016-05-11 17:54:21 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:54:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:54:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:54:21 --> Helper loaded: form_helper
INFO - 2016-05-11 17:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:54:21 --> Form Validation Class Initialized
INFO - 2016-05-11 17:54:21 --> Controller Class Initialized
INFO - 2016-05-11 17:54:21 --> Model Class Initialized
INFO - 2016-05-11 17:54:21 --> Database Driver Class Initialized
INFO - 2016-05-11 17:54:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-11 17:54:21 --> Final output sent to browser
DEBUG - 2016-05-11 17:54:21 --> Total execution time: 0.1174
INFO - 2016-05-11 17:54:27 --> Config Class Initialized
INFO - 2016-05-11 17:54:27 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:54:27 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:54:27 --> Utf8 Class Initialized
INFO - 2016-05-11 17:54:27 --> URI Class Initialized
INFO - 2016-05-11 17:54:27 --> Router Class Initialized
INFO - 2016-05-11 17:54:27 --> Output Class Initialized
INFO - 2016-05-11 17:54:27 --> Security Class Initialized
DEBUG - 2016-05-11 17:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:54:27 --> Input Class Initialized
INFO - 2016-05-11 17:54:27 --> Language Class Initialized
INFO - 2016-05-11 17:54:27 --> Loader Class Initialized
INFO - 2016-05-11 17:54:27 --> Helper loaded: url_helper
INFO - 2016-05-11 17:54:27 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:54:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:54:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:54:27 --> Helper loaded: form_helper
INFO - 2016-05-11 17:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:54:27 --> Form Validation Class Initialized
INFO - 2016-05-11 17:54:27 --> Controller Class Initialized
INFO - 2016-05-11 17:54:27 --> Model Class Initialized
INFO - 2016-05-11 17:54:27 --> Database Driver Class Initialized
INFO - 2016-05-11 17:54:27 --> Config Class Initialized
INFO - 2016-05-11 17:54:27 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:54:27 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:54:27 --> Utf8 Class Initialized
INFO - 2016-05-11 17:54:27 --> URI Class Initialized
INFO - 2016-05-11 17:54:27 --> Router Class Initialized
INFO - 2016-05-11 17:54:27 --> Output Class Initialized
INFO - 2016-05-11 17:54:27 --> Security Class Initialized
DEBUG - 2016-05-11 17:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:54:27 --> Input Class Initialized
INFO - 2016-05-11 17:54:27 --> Language Class Initialized
INFO - 2016-05-11 17:54:27 --> Loader Class Initialized
INFO - 2016-05-11 17:54:27 --> Helper loaded: url_helper
INFO - 2016-05-11 17:54:27 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:54:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:54:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:54:27 --> Helper loaded: form_helper
INFO - 2016-05-11 17:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:54:27 --> Form Validation Class Initialized
INFO - 2016-05-11 17:54:27 --> Controller Class Initialized
INFO - 2016-05-11 17:54:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-11 17:54:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 17:54:27 --> Final output sent to browser
DEBUG - 2016-05-11 17:54:27 --> Total execution time: 0.1047
INFO - 2016-05-11 17:54:28 --> Config Class Initialized
INFO - 2016-05-11 17:54:28 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:54:28 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:54:28 --> Utf8 Class Initialized
INFO - 2016-05-11 17:54:28 --> URI Class Initialized
INFO - 2016-05-11 17:54:28 --> Router Class Initialized
INFO - 2016-05-11 17:54:28 --> Output Class Initialized
INFO - 2016-05-11 17:54:28 --> Security Class Initialized
DEBUG - 2016-05-11 17:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:54:28 --> Input Class Initialized
INFO - 2016-05-11 17:54:28 --> Language Class Initialized
INFO - 2016-05-11 17:54:28 --> Loader Class Initialized
INFO - 2016-05-11 17:54:28 --> Helper loaded: url_helper
INFO - 2016-05-11 17:54:28 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:54:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:54:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:54:28 --> Helper loaded: form_helper
INFO - 2016-05-11 17:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:54:28 --> Form Validation Class Initialized
INFO - 2016-05-11 17:54:28 --> Controller Class Initialized
INFO - 2016-05-11 17:54:28 --> Model Class Initialized
INFO - 2016-05-11 17:54:28 --> Database Driver Class Initialized
INFO - 2016-05-11 17:54:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:54:28 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:54:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:54:28 --> Final output sent to browser
DEBUG - 2016-05-11 17:54:28 --> Total execution time: 0.1813
INFO - 2016-05-11 17:54:34 --> Config Class Initialized
INFO - 2016-05-11 17:54:34 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:54:34 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:54:34 --> Utf8 Class Initialized
INFO - 2016-05-11 17:54:34 --> URI Class Initialized
INFO - 2016-05-11 17:54:34 --> Router Class Initialized
INFO - 2016-05-11 17:54:34 --> Output Class Initialized
INFO - 2016-05-11 17:54:34 --> Security Class Initialized
DEBUG - 2016-05-11 17:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:54:34 --> Input Class Initialized
INFO - 2016-05-11 17:54:34 --> Language Class Initialized
INFO - 2016-05-11 17:54:34 --> Loader Class Initialized
INFO - 2016-05-11 17:54:34 --> Helper loaded: url_helper
INFO - 2016-05-11 17:54:34 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:54:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:54:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:54:34 --> Helper loaded: form_helper
INFO - 2016-05-11 17:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:54:34 --> Form Validation Class Initialized
INFO - 2016-05-11 17:54:34 --> Controller Class Initialized
INFO - 2016-05-11 17:54:34 --> Model Class Initialized
INFO - 2016-05-11 17:54:34 --> Database Driver Class Initialized
INFO - 2016-05-11 17:54:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-11 17:54:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:54:34 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:54:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:54:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-11 17:54:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 17:54:34 --> Final output sent to browser
DEBUG - 2016-05-11 17:54:34 --> Total execution time: 0.1851
INFO - 2016-05-11 17:54:34 --> Config Class Initialized
INFO - 2016-05-11 17:54:34 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:54:34 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:54:34 --> Utf8 Class Initialized
INFO - 2016-05-11 17:54:34 --> URI Class Initialized
INFO - 2016-05-11 17:54:34 --> Router Class Initialized
INFO - 2016-05-11 17:54:34 --> Output Class Initialized
INFO - 2016-05-11 17:54:34 --> Security Class Initialized
DEBUG - 2016-05-11 17:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:54:34 --> Input Class Initialized
INFO - 2016-05-11 17:54:34 --> Language Class Initialized
INFO - 2016-05-11 17:54:34 --> Loader Class Initialized
INFO - 2016-05-11 17:54:34 --> Helper loaded: url_helper
INFO - 2016-05-11 17:54:34 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:54:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:54:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:54:34 --> Helper loaded: form_helper
INFO - 2016-05-11 17:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:54:34 --> Form Validation Class Initialized
INFO - 2016-05-11 17:54:34 --> Controller Class Initialized
INFO - 2016-05-11 17:54:34 --> Model Class Initialized
INFO - 2016-05-11 17:54:34 --> Database Driver Class Initialized
INFO - 2016-05-11 17:54:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:54:34 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:54:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:54:34 --> Final output sent to browser
DEBUG - 2016-05-11 17:54:34 --> Total execution time: 0.1320
INFO - 2016-05-11 17:54:37 --> Config Class Initialized
INFO - 2016-05-11 17:54:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:54:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:54:37 --> Utf8 Class Initialized
INFO - 2016-05-11 17:54:37 --> URI Class Initialized
INFO - 2016-05-11 17:54:37 --> Router Class Initialized
INFO - 2016-05-11 17:54:37 --> Output Class Initialized
INFO - 2016-05-11 17:54:37 --> Security Class Initialized
DEBUG - 2016-05-11 17:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:54:37 --> Input Class Initialized
INFO - 2016-05-11 17:54:37 --> Language Class Initialized
INFO - 2016-05-11 17:54:37 --> Loader Class Initialized
INFO - 2016-05-11 17:54:37 --> Helper loaded: url_helper
INFO - 2016-05-11 17:54:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:54:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:54:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:54:37 --> Helper loaded: form_helper
INFO - 2016-05-11 17:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:54:37 --> Form Validation Class Initialized
INFO - 2016-05-11 17:54:37 --> Controller Class Initialized
INFO - 2016-05-11 17:54:37 --> Model Class Initialized
INFO - 2016-05-11 17:54:37 --> Database Driver Class Initialized
INFO - 2016-05-11 17:54:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-11 17:54:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:54:37 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:54:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:54:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-11 17:54:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 17:54:37 --> Final output sent to browser
DEBUG - 2016-05-11 17:54:37 --> Total execution time: 0.1146
INFO - 2016-05-11 17:54:37 --> Config Class Initialized
INFO - 2016-05-11 17:54:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:54:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:54:37 --> Utf8 Class Initialized
INFO - 2016-05-11 17:54:37 --> URI Class Initialized
INFO - 2016-05-11 17:54:37 --> Router Class Initialized
INFO - 2016-05-11 17:54:37 --> Output Class Initialized
INFO - 2016-05-11 17:54:37 --> Security Class Initialized
DEBUG - 2016-05-11 17:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:54:37 --> Input Class Initialized
INFO - 2016-05-11 17:54:37 --> Language Class Initialized
INFO - 2016-05-11 17:54:37 --> Loader Class Initialized
INFO - 2016-05-11 17:54:37 --> Helper loaded: url_helper
INFO - 2016-05-11 17:54:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:54:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:54:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:54:37 --> Helper loaded: form_helper
INFO - 2016-05-11 17:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:54:37 --> Form Validation Class Initialized
INFO - 2016-05-11 17:54:37 --> Controller Class Initialized
INFO - 2016-05-11 17:54:37 --> Model Class Initialized
INFO - 2016-05-11 17:54:37 --> Database Driver Class Initialized
INFO - 2016-05-11 17:54:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:54:37 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:54:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:54:37 --> Final output sent to browser
DEBUG - 2016-05-11 17:54:37 --> Total execution time: 0.0970
INFO - 2016-05-11 17:54:42 --> Config Class Initialized
INFO - 2016-05-11 17:54:42 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:54:42 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:54:42 --> Utf8 Class Initialized
INFO - 2016-05-11 17:54:42 --> URI Class Initialized
INFO - 2016-05-11 17:54:42 --> Router Class Initialized
INFO - 2016-05-11 17:54:42 --> Output Class Initialized
INFO - 2016-05-11 17:54:42 --> Security Class Initialized
DEBUG - 2016-05-11 17:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:54:42 --> Input Class Initialized
INFO - 2016-05-11 17:54:42 --> Language Class Initialized
INFO - 2016-05-11 17:54:42 --> Loader Class Initialized
INFO - 2016-05-11 17:54:42 --> Helper loaded: url_helper
INFO - 2016-05-11 17:54:42 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:54:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:54:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:54:42 --> Helper loaded: form_helper
INFO - 2016-05-11 17:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:54:42 --> Form Validation Class Initialized
INFO - 2016-05-11 17:54:42 --> Controller Class Initialized
INFO - 2016-05-11 17:54:42 --> Model Class Initialized
INFO - 2016-05-11 17:54:42 --> Database Driver Class Initialized
INFO - 2016-05-11 17:54:42 --> Helper loaded: creaselect_helper
INFO - 2016-05-11 17:54:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:54:42 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:54:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:54:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-11 17:54:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 17:54:42 --> Final output sent to browser
DEBUG - 2016-05-11 17:54:42 --> Total execution time: 0.0956
INFO - 2016-05-11 17:54:42 --> Config Class Initialized
INFO - 2016-05-11 17:54:42 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:54:42 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:54:42 --> Utf8 Class Initialized
INFO - 2016-05-11 17:54:42 --> URI Class Initialized
INFO - 2016-05-11 17:54:42 --> Router Class Initialized
INFO - 2016-05-11 17:54:42 --> Output Class Initialized
INFO - 2016-05-11 17:54:42 --> Security Class Initialized
DEBUG - 2016-05-11 17:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:54:42 --> Input Class Initialized
INFO - 2016-05-11 17:54:42 --> Language Class Initialized
INFO - 2016-05-11 17:54:42 --> Loader Class Initialized
INFO - 2016-05-11 17:54:42 --> Helper loaded: url_helper
INFO - 2016-05-11 17:54:42 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:54:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:54:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:54:42 --> Helper loaded: form_helper
INFO - 2016-05-11 17:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:54:42 --> Form Validation Class Initialized
INFO - 2016-05-11 17:54:42 --> Controller Class Initialized
INFO - 2016-05-11 17:54:42 --> Model Class Initialized
INFO - 2016-05-11 17:54:42 --> Database Driver Class Initialized
INFO - 2016-05-11 17:54:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:54:42 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:54:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:54:42 --> Final output sent to browser
DEBUG - 2016-05-11 17:54:42 --> Total execution time: 0.0867
INFO - 2016-05-11 17:54:46 --> Config Class Initialized
INFO - 2016-05-11 17:54:46 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:54:46 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:54:46 --> Utf8 Class Initialized
INFO - 2016-05-11 17:54:46 --> URI Class Initialized
INFO - 2016-05-11 17:54:46 --> Router Class Initialized
INFO - 2016-05-11 17:54:46 --> Output Class Initialized
INFO - 2016-05-11 17:54:46 --> Security Class Initialized
DEBUG - 2016-05-11 17:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:54:46 --> Input Class Initialized
INFO - 2016-05-11 17:54:46 --> Language Class Initialized
INFO - 2016-05-11 17:54:46 --> Loader Class Initialized
INFO - 2016-05-11 17:54:46 --> Helper loaded: url_helper
INFO - 2016-05-11 17:54:46 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:54:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:54:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:54:46 --> Helper loaded: form_helper
INFO - 2016-05-11 17:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:54:46 --> Form Validation Class Initialized
INFO - 2016-05-11 17:54:46 --> Controller Class Initialized
INFO - 2016-05-11 17:54:46 --> Model Class Initialized
INFO - 2016-05-11 17:54:46 --> Database Driver Class Initialized
INFO - 2016-05-11 17:54:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-11 17:54:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:54:46 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:54:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:54:46 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-11 17:54:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-11 17:54:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 17:54:46 --> Final output sent to browser
DEBUG - 2016-05-11 17:54:46 --> Total execution time: 0.3159
INFO - 2016-05-11 17:54:47 --> Config Class Initialized
INFO - 2016-05-11 17:54:47 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:54:47 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:54:47 --> Utf8 Class Initialized
INFO - 2016-05-11 17:54:47 --> URI Class Initialized
INFO - 2016-05-11 17:54:47 --> Router Class Initialized
INFO - 2016-05-11 17:54:47 --> Output Class Initialized
INFO - 2016-05-11 17:54:47 --> Security Class Initialized
DEBUG - 2016-05-11 17:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:54:47 --> Input Class Initialized
INFO - 2016-05-11 17:54:47 --> Language Class Initialized
INFO - 2016-05-11 17:54:47 --> Loader Class Initialized
INFO - 2016-05-11 17:54:47 --> Helper loaded: url_helper
INFO - 2016-05-11 17:54:47 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:54:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:54:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:54:47 --> Helper loaded: form_helper
INFO - 2016-05-11 17:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:54:47 --> Form Validation Class Initialized
INFO - 2016-05-11 17:54:47 --> Controller Class Initialized
INFO - 2016-05-11 17:54:47 --> Model Class Initialized
INFO - 2016-05-11 17:54:47 --> Database Driver Class Initialized
INFO - 2016-05-11 17:54:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:54:47 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:54:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:54:47 --> Final output sent to browser
DEBUG - 2016-05-11 17:54:47 --> Total execution time: 0.0902
INFO - 2016-05-11 17:55:20 --> Config Class Initialized
INFO - 2016-05-11 17:55:20 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:55:20 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:55:20 --> Utf8 Class Initialized
INFO - 2016-05-11 17:55:20 --> URI Class Initialized
INFO - 2016-05-11 17:55:20 --> Router Class Initialized
INFO - 2016-05-11 17:55:20 --> Output Class Initialized
INFO - 2016-05-11 17:55:20 --> Security Class Initialized
DEBUG - 2016-05-11 17:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:55:20 --> Input Class Initialized
INFO - 2016-05-11 17:55:20 --> Language Class Initialized
INFO - 2016-05-11 17:55:20 --> Loader Class Initialized
INFO - 2016-05-11 17:55:20 --> Helper loaded: url_helper
INFO - 2016-05-11 17:55:20 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:55:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:55:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:55:20 --> Helper loaded: form_helper
INFO - 2016-05-11 17:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:55:20 --> Form Validation Class Initialized
INFO - 2016-05-11 17:55:20 --> Controller Class Initialized
INFO - 2016-05-11 17:55:20 --> Model Class Initialized
INFO - 2016-05-11 17:55:20 --> Database Driver Class Initialized
INFO - 2016-05-11 17:55:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-11 17:55:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:55:20 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:55:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:55:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-11 17:55:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 17:55:20 --> Final output sent to browser
DEBUG - 2016-05-11 17:55:20 --> Total execution time: 0.1237
INFO - 2016-05-11 17:55:20 --> Config Class Initialized
INFO - 2016-05-11 17:55:20 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:55:20 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:55:20 --> Utf8 Class Initialized
INFO - 2016-05-11 17:55:20 --> URI Class Initialized
INFO - 2016-05-11 17:55:20 --> Router Class Initialized
INFO - 2016-05-11 17:55:20 --> Output Class Initialized
INFO - 2016-05-11 17:55:20 --> Security Class Initialized
DEBUG - 2016-05-11 17:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:55:20 --> Input Class Initialized
INFO - 2016-05-11 17:55:20 --> Language Class Initialized
INFO - 2016-05-11 17:55:20 --> Loader Class Initialized
INFO - 2016-05-11 17:55:20 --> Helper loaded: url_helper
INFO - 2016-05-11 17:55:20 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:55:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:55:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:55:20 --> Helper loaded: form_helper
INFO - 2016-05-11 17:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:55:20 --> Form Validation Class Initialized
INFO - 2016-05-11 17:55:20 --> Controller Class Initialized
INFO - 2016-05-11 17:55:20 --> Model Class Initialized
INFO - 2016-05-11 17:55:20 --> Database Driver Class Initialized
INFO - 2016-05-11 17:55:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:55:20 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:55:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:55:20 --> Final output sent to browser
DEBUG - 2016-05-11 17:55:20 --> Total execution time: 0.1124
INFO - 2016-05-11 17:55:23 --> Config Class Initialized
INFO - 2016-05-11 17:55:23 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:55:23 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:55:23 --> Utf8 Class Initialized
INFO - 2016-05-11 17:55:23 --> URI Class Initialized
INFO - 2016-05-11 17:55:23 --> Router Class Initialized
INFO - 2016-05-11 17:55:23 --> Output Class Initialized
INFO - 2016-05-11 17:55:23 --> Security Class Initialized
DEBUG - 2016-05-11 17:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:55:23 --> Input Class Initialized
INFO - 2016-05-11 17:55:23 --> Language Class Initialized
INFO - 2016-05-11 17:55:23 --> Loader Class Initialized
INFO - 2016-05-11 17:55:23 --> Helper loaded: url_helper
INFO - 2016-05-11 17:55:23 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:55:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:55:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:55:23 --> Helper loaded: form_helper
INFO - 2016-05-11 17:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:55:23 --> Form Validation Class Initialized
INFO - 2016-05-11 17:55:23 --> Controller Class Initialized
INFO - 2016-05-11 17:55:23 --> Model Class Initialized
INFO - 2016-05-11 17:55:23 --> Database Driver Class Initialized
INFO - 2016-05-11 17:55:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-11 17:55:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:55:23 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:55:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:55:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-11 17:55:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 17:55:23 --> Final output sent to browser
DEBUG - 2016-05-11 17:55:23 --> Total execution time: 0.0755
INFO - 2016-05-11 17:55:23 --> Config Class Initialized
INFO - 2016-05-11 17:55:23 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:55:23 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:55:23 --> Utf8 Class Initialized
INFO - 2016-05-11 17:55:23 --> URI Class Initialized
INFO - 2016-05-11 17:55:23 --> Router Class Initialized
INFO - 2016-05-11 17:55:23 --> Output Class Initialized
INFO - 2016-05-11 17:55:23 --> Security Class Initialized
DEBUG - 2016-05-11 17:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:55:23 --> Input Class Initialized
INFO - 2016-05-11 17:55:23 --> Language Class Initialized
INFO - 2016-05-11 17:55:23 --> Loader Class Initialized
INFO - 2016-05-11 17:55:23 --> Helper loaded: url_helper
INFO - 2016-05-11 17:55:23 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:55:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:55:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:55:23 --> Helper loaded: form_helper
INFO - 2016-05-11 17:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:55:23 --> Form Validation Class Initialized
INFO - 2016-05-11 17:55:23 --> Controller Class Initialized
INFO - 2016-05-11 17:55:23 --> Model Class Initialized
INFO - 2016-05-11 17:55:23 --> Database Driver Class Initialized
INFO - 2016-05-11 17:55:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:55:23 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:55:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:55:23 --> Final output sent to browser
DEBUG - 2016-05-11 17:55:23 --> Total execution time: 0.1030
INFO - 2016-05-11 17:55:26 --> Config Class Initialized
INFO - 2016-05-11 17:55:26 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:55:26 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:55:26 --> Utf8 Class Initialized
INFO - 2016-05-11 17:55:26 --> URI Class Initialized
INFO - 2016-05-11 17:55:26 --> Router Class Initialized
INFO - 2016-05-11 17:55:26 --> Output Class Initialized
INFO - 2016-05-11 17:55:26 --> Security Class Initialized
DEBUG - 2016-05-11 17:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:55:26 --> Input Class Initialized
INFO - 2016-05-11 17:55:26 --> Language Class Initialized
INFO - 2016-05-11 17:55:27 --> Loader Class Initialized
INFO - 2016-05-11 17:55:27 --> Helper loaded: url_helper
INFO - 2016-05-11 17:55:27 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:55:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:55:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:55:27 --> Helper loaded: form_helper
INFO - 2016-05-11 17:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:55:27 --> Form Validation Class Initialized
INFO - 2016-05-11 17:55:27 --> Controller Class Initialized
INFO - 2016-05-11 17:55:27 --> Model Class Initialized
INFO - 2016-05-11 17:55:27 --> Database Driver Class Initialized
INFO - 2016-05-11 17:55:27 --> Helper loaded: creaselect_helper
INFO - 2016-05-11 17:55:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:55:27 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:55:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:55:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-11 17:55:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 17:55:27 --> Final output sent to browser
DEBUG - 2016-05-11 17:55:27 --> Total execution time: 0.0901
INFO - 2016-05-11 17:55:27 --> Config Class Initialized
INFO - 2016-05-11 17:55:27 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:55:27 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:55:27 --> Utf8 Class Initialized
INFO - 2016-05-11 17:55:27 --> URI Class Initialized
INFO - 2016-05-11 17:55:27 --> Router Class Initialized
INFO - 2016-05-11 17:55:27 --> Output Class Initialized
INFO - 2016-05-11 17:55:27 --> Security Class Initialized
DEBUG - 2016-05-11 17:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:55:27 --> Input Class Initialized
INFO - 2016-05-11 17:55:27 --> Language Class Initialized
INFO - 2016-05-11 17:55:27 --> Loader Class Initialized
INFO - 2016-05-11 17:55:27 --> Helper loaded: url_helper
INFO - 2016-05-11 17:55:27 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:55:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:55:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:55:27 --> Helper loaded: form_helper
INFO - 2016-05-11 17:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:55:27 --> Form Validation Class Initialized
INFO - 2016-05-11 17:55:27 --> Controller Class Initialized
INFO - 2016-05-11 17:55:27 --> Model Class Initialized
INFO - 2016-05-11 17:55:27 --> Database Driver Class Initialized
INFO - 2016-05-11 17:55:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:55:27 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:55:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:55:27 --> Final output sent to browser
DEBUG - 2016-05-11 17:55:27 --> Total execution time: 0.1003
INFO - 2016-05-11 17:55:28 --> Config Class Initialized
INFO - 2016-05-11 17:55:28 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:55:28 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:55:28 --> Utf8 Class Initialized
INFO - 2016-05-11 17:55:28 --> URI Class Initialized
INFO - 2016-05-11 17:55:28 --> Router Class Initialized
INFO - 2016-05-11 17:55:28 --> Output Class Initialized
INFO - 2016-05-11 17:55:28 --> Security Class Initialized
DEBUG - 2016-05-11 17:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:55:28 --> Input Class Initialized
INFO - 2016-05-11 17:55:28 --> Language Class Initialized
INFO - 2016-05-11 17:55:28 --> Loader Class Initialized
INFO - 2016-05-11 17:55:28 --> Helper loaded: url_helper
INFO - 2016-05-11 17:55:28 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:55:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:55:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:55:28 --> Helper loaded: form_helper
INFO - 2016-05-11 17:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:55:28 --> Form Validation Class Initialized
INFO - 2016-05-11 17:55:28 --> Controller Class Initialized
INFO - 2016-05-11 17:55:28 --> Model Class Initialized
INFO - 2016-05-11 17:55:28 --> Database Driver Class Initialized
INFO - 2016-05-11 17:55:28 --> Helper loaded: creaselect_helper
INFO - 2016-05-11 17:55:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:55:28 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:55:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:55:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-11 17:55:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 17:55:28 --> Final output sent to browser
DEBUG - 2016-05-11 17:55:28 --> Total execution time: 0.1021
INFO - 2016-05-11 17:55:29 --> Config Class Initialized
INFO - 2016-05-11 17:55:29 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:55:29 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:55:29 --> Utf8 Class Initialized
INFO - 2016-05-11 17:55:29 --> URI Class Initialized
INFO - 2016-05-11 17:55:29 --> Router Class Initialized
INFO - 2016-05-11 17:55:29 --> Output Class Initialized
INFO - 2016-05-11 17:55:29 --> Security Class Initialized
DEBUG - 2016-05-11 17:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:55:29 --> Input Class Initialized
INFO - 2016-05-11 17:55:29 --> Language Class Initialized
INFO - 2016-05-11 17:55:29 --> Loader Class Initialized
INFO - 2016-05-11 17:55:29 --> Helper loaded: url_helper
INFO - 2016-05-11 17:55:29 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:55:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:55:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:55:29 --> Helper loaded: form_helper
INFO - 2016-05-11 17:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:55:29 --> Form Validation Class Initialized
INFO - 2016-05-11 17:55:29 --> Controller Class Initialized
INFO - 2016-05-11 17:55:29 --> Model Class Initialized
INFO - 2016-05-11 17:55:29 --> Database Driver Class Initialized
INFO - 2016-05-11 17:55:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:55:29 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:55:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:55:29 --> Final output sent to browser
DEBUG - 2016-05-11 17:55:29 --> Total execution time: 0.0936
INFO - 2016-05-11 17:55:31 --> Config Class Initialized
INFO - 2016-05-11 17:55:31 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:55:31 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:55:31 --> Utf8 Class Initialized
INFO - 2016-05-11 17:55:31 --> URI Class Initialized
INFO - 2016-05-11 17:55:31 --> Router Class Initialized
INFO - 2016-05-11 17:55:31 --> Output Class Initialized
INFO - 2016-05-11 17:55:31 --> Security Class Initialized
DEBUG - 2016-05-11 17:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:55:31 --> Input Class Initialized
INFO - 2016-05-11 17:55:31 --> Language Class Initialized
INFO - 2016-05-11 17:55:31 --> Loader Class Initialized
INFO - 2016-05-11 17:55:31 --> Helper loaded: url_helper
INFO - 2016-05-11 17:55:31 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:55:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:55:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:55:31 --> Helper loaded: form_helper
INFO - 2016-05-11 17:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:55:31 --> Form Validation Class Initialized
INFO - 2016-05-11 17:55:31 --> Controller Class Initialized
INFO - 2016-05-11 17:55:31 --> Model Class Initialized
INFO - 2016-05-11 17:55:31 --> Database Driver Class Initialized
INFO - 2016-05-11 17:55:31 --> Helper loaded: creaselect_helper
INFO - 2016-05-11 17:55:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:55:31 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:55:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:55:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-11 17:55:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 17:55:31 --> Final output sent to browser
DEBUG - 2016-05-11 17:55:31 --> Total execution time: 0.0838
INFO - 2016-05-11 17:55:31 --> Config Class Initialized
INFO - 2016-05-11 17:55:31 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:55:31 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:55:31 --> Utf8 Class Initialized
INFO - 2016-05-11 17:55:31 --> URI Class Initialized
INFO - 2016-05-11 17:55:31 --> Router Class Initialized
INFO - 2016-05-11 17:55:31 --> Output Class Initialized
INFO - 2016-05-11 17:55:31 --> Security Class Initialized
DEBUG - 2016-05-11 17:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:55:31 --> Input Class Initialized
INFO - 2016-05-11 17:55:31 --> Language Class Initialized
INFO - 2016-05-11 17:55:31 --> Loader Class Initialized
INFO - 2016-05-11 17:55:31 --> Helper loaded: url_helper
INFO - 2016-05-11 17:55:31 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:55:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:55:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:55:31 --> Helper loaded: form_helper
INFO - 2016-05-11 17:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:55:31 --> Form Validation Class Initialized
INFO - 2016-05-11 17:55:31 --> Controller Class Initialized
INFO - 2016-05-11 17:55:31 --> Model Class Initialized
INFO - 2016-05-11 17:55:31 --> Database Driver Class Initialized
INFO - 2016-05-11 17:55:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:55:31 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:55:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:55:31 --> Final output sent to browser
DEBUG - 2016-05-11 17:55:31 --> Total execution time: 0.1077
INFO - 2016-05-11 17:55:40 --> Config Class Initialized
INFO - 2016-05-11 17:55:40 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:55:40 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:55:40 --> Utf8 Class Initialized
INFO - 2016-05-11 17:55:40 --> URI Class Initialized
DEBUG - 2016-05-11 17:55:40 --> No URI present. Default controller set.
INFO - 2016-05-11 17:55:40 --> Router Class Initialized
INFO - 2016-05-11 17:55:40 --> Output Class Initialized
INFO - 2016-05-11 17:55:40 --> Security Class Initialized
DEBUG - 2016-05-11 17:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:55:40 --> Input Class Initialized
INFO - 2016-05-11 17:55:40 --> Language Class Initialized
INFO - 2016-05-11 17:55:40 --> Loader Class Initialized
INFO - 2016-05-11 17:55:40 --> Helper loaded: url_helper
INFO - 2016-05-11 17:55:40 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:55:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:55:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:55:40 --> Helper loaded: form_helper
INFO - 2016-05-11 17:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:55:40 --> Form Validation Class Initialized
INFO - 2016-05-11 17:55:40 --> Controller Class Initialized
INFO - 2016-05-11 17:55:40 --> Model Class Initialized
INFO - 2016-05-11 17:55:40 --> Database Driver Class Initialized
INFO - 2016-05-11 17:55:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 17:55:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 17:55:40 --> Final output sent to browser
DEBUG - 2016-05-11 17:55:40 --> Total execution time: 0.1910
INFO - 2016-05-11 17:56:20 --> Config Class Initialized
INFO - 2016-05-11 17:56:20 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:56:20 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:56:20 --> Utf8 Class Initialized
INFO - 2016-05-11 17:56:20 --> URI Class Initialized
DEBUG - 2016-05-11 17:56:20 --> No URI present. Default controller set.
INFO - 2016-05-11 17:56:20 --> Router Class Initialized
INFO - 2016-05-11 17:56:20 --> Output Class Initialized
INFO - 2016-05-11 17:56:20 --> Security Class Initialized
DEBUG - 2016-05-11 17:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:56:20 --> Input Class Initialized
INFO - 2016-05-11 17:56:20 --> Language Class Initialized
INFO - 2016-05-11 17:56:20 --> Loader Class Initialized
INFO - 2016-05-11 17:56:20 --> Helper loaded: url_helper
INFO - 2016-05-11 17:56:20 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:56:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:56:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:56:20 --> Helper loaded: form_helper
INFO - 2016-05-11 17:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:56:20 --> Form Validation Class Initialized
INFO - 2016-05-11 17:56:20 --> Controller Class Initialized
INFO - 2016-05-11 17:56:20 --> Model Class Initialized
INFO - 2016-05-11 17:56:20 --> Database Driver Class Initialized
INFO - 2016-05-11 17:56:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 17:56:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 17:56:20 --> Final output sent to browser
DEBUG - 2016-05-11 17:56:20 --> Total execution time: 0.1082
INFO - 2016-05-11 17:56:31 --> Config Class Initialized
INFO - 2016-05-11 17:56:31 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:56:31 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:56:31 --> Utf8 Class Initialized
INFO - 2016-05-11 17:56:31 --> URI Class Initialized
INFO - 2016-05-11 17:56:31 --> Router Class Initialized
INFO - 2016-05-11 17:56:31 --> Output Class Initialized
INFO - 2016-05-11 17:56:31 --> Security Class Initialized
DEBUG - 2016-05-11 17:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:56:31 --> Input Class Initialized
INFO - 2016-05-11 17:56:31 --> Language Class Initialized
INFO - 2016-05-11 17:56:31 --> Loader Class Initialized
INFO - 2016-05-11 17:56:31 --> Helper loaded: url_helper
INFO - 2016-05-11 17:56:31 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:56:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:56:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:56:32 --> Helper loaded: form_helper
INFO - 2016-05-11 17:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:56:32 --> Form Validation Class Initialized
INFO - 2016-05-11 17:56:32 --> Controller Class Initialized
INFO - 2016-05-11 17:56:32 --> Model Class Initialized
INFO - 2016-05-11 17:56:32 --> Database Driver Class Initialized
INFO - 2016-05-11 17:56:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:56:32 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:56:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:56:32 --> Final output sent to browser
DEBUG - 2016-05-11 17:56:32 --> Total execution time: 0.0814
INFO - 2016-05-11 17:57:03 --> Config Class Initialized
INFO - 2016-05-11 17:57:03 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:57:03 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:57:03 --> Utf8 Class Initialized
INFO - 2016-05-11 17:57:03 --> URI Class Initialized
DEBUG - 2016-05-11 17:57:03 --> No URI present. Default controller set.
INFO - 2016-05-11 17:57:03 --> Router Class Initialized
INFO - 2016-05-11 17:57:03 --> Output Class Initialized
INFO - 2016-05-11 17:57:03 --> Security Class Initialized
DEBUG - 2016-05-11 17:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:57:03 --> Input Class Initialized
INFO - 2016-05-11 17:57:03 --> Language Class Initialized
INFO - 2016-05-11 17:57:03 --> Loader Class Initialized
INFO - 2016-05-11 17:57:03 --> Helper loaded: url_helper
INFO - 2016-05-11 17:57:03 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:57:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:57:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:57:03 --> Helper loaded: form_helper
INFO - 2016-05-11 17:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:57:03 --> Form Validation Class Initialized
INFO - 2016-05-11 17:57:03 --> Controller Class Initialized
INFO - 2016-05-11 17:57:03 --> Model Class Initialized
INFO - 2016-05-11 17:57:03 --> Database Driver Class Initialized
INFO - 2016-05-11 17:57:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 17:57:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 17:57:03 --> Final output sent to browser
DEBUG - 2016-05-11 17:57:03 --> Total execution time: 0.1365
INFO - 2016-05-11 17:57:31 --> Config Class Initialized
INFO - 2016-05-11 17:57:31 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:57:31 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:57:31 --> Utf8 Class Initialized
INFO - 2016-05-11 17:57:31 --> URI Class Initialized
INFO - 2016-05-11 17:57:31 --> Router Class Initialized
INFO - 2016-05-11 17:57:31 --> Output Class Initialized
INFO - 2016-05-11 17:57:31 --> Security Class Initialized
DEBUG - 2016-05-11 17:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:57:31 --> Input Class Initialized
INFO - 2016-05-11 17:57:31 --> Language Class Initialized
INFO - 2016-05-11 17:57:31 --> Loader Class Initialized
INFO - 2016-05-11 17:57:31 --> Helper loaded: url_helper
INFO - 2016-05-11 17:57:31 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:57:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:57:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:57:32 --> Helper loaded: form_helper
INFO - 2016-05-11 17:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:57:32 --> Form Validation Class Initialized
INFO - 2016-05-11 17:57:32 --> Controller Class Initialized
INFO - 2016-05-11 17:57:32 --> Model Class Initialized
INFO - 2016-05-11 17:57:32 --> Database Driver Class Initialized
INFO - 2016-05-11 17:57:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:57:32 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:57:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:57:32 --> Final output sent to browser
DEBUG - 2016-05-11 17:57:32 --> Total execution time: 0.0806
INFO - 2016-05-11 17:58:31 --> Config Class Initialized
INFO - 2016-05-11 17:58:31 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:58:31 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:58:31 --> Utf8 Class Initialized
INFO - 2016-05-11 17:58:31 --> URI Class Initialized
INFO - 2016-05-11 17:58:31 --> Router Class Initialized
INFO - 2016-05-11 17:58:31 --> Output Class Initialized
INFO - 2016-05-11 17:58:32 --> Security Class Initialized
DEBUG - 2016-05-11 17:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:58:32 --> Input Class Initialized
INFO - 2016-05-11 17:58:32 --> Language Class Initialized
INFO - 2016-05-11 17:58:32 --> Loader Class Initialized
INFO - 2016-05-11 17:58:32 --> Helper loaded: url_helper
INFO - 2016-05-11 17:58:32 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:58:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:58:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:58:32 --> Helper loaded: form_helper
INFO - 2016-05-11 17:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:58:32 --> Form Validation Class Initialized
INFO - 2016-05-11 17:58:32 --> Controller Class Initialized
INFO - 2016-05-11 17:58:32 --> Model Class Initialized
INFO - 2016-05-11 17:58:32 --> Database Driver Class Initialized
INFO - 2016-05-11 17:58:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:58:32 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:58:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:58:32 --> Final output sent to browser
DEBUG - 2016-05-11 17:58:32 --> Total execution time: 0.1454
INFO - 2016-05-11 17:59:31 --> Config Class Initialized
INFO - 2016-05-11 17:59:31 --> Hooks Class Initialized
DEBUG - 2016-05-11 17:59:31 --> UTF-8 Support Enabled
INFO - 2016-05-11 17:59:31 --> Utf8 Class Initialized
INFO - 2016-05-11 17:59:31 --> URI Class Initialized
INFO - 2016-05-11 17:59:31 --> Router Class Initialized
INFO - 2016-05-11 17:59:31 --> Output Class Initialized
INFO - 2016-05-11 17:59:31 --> Security Class Initialized
DEBUG - 2016-05-11 17:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 17:59:31 --> Input Class Initialized
INFO - 2016-05-11 17:59:31 --> Language Class Initialized
INFO - 2016-05-11 17:59:31 --> Loader Class Initialized
INFO - 2016-05-11 17:59:31 --> Helper loaded: url_helper
INFO - 2016-05-11 17:59:31 --> Helper loaded: sesion_helper
INFO - 2016-05-11 17:59:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 17:59:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 17:59:31 --> Helper loaded: form_helper
INFO - 2016-05-11 17:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 17:59:31 --> Form Validation Class Initialized
INFO - 2016-05-11 17:59:31 --> Controller Class Initialized
INFO - 2016-05-11 17:59:31 --> Model Class Initialized
INFO - 2016-05-11 17:59:31 --> Database Driver Class Initialized
INFO - 2016-05-11 17:59:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 17:59:32 --> Pagination Class Initialized
DEBUG - 2016-05-11 17:59:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 17:59:32 --> Final output sent to browser
DEBUG - 2016-05-11 17:59:32 --> Total execution time: 0.0681
INFO - 2016-05-11 18:05:15 --> Config Class Initialized
INFO - 2016-05-11 18:05:15 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:05:15 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:05:15 --> Utf8 Class Initialized
INFO - 2016-05-11 18:05:15 --> URI Class Initialized
DEBUG - 2016-05-11 18:05:15 --> No URI present. Default controller set.
INFO - 2016-05-11 18:05:15 --> Router Class Initialized
INFO - 2016-05-11 18:05:15 --> Output Class Initialized
INFO - 2016-05-11 18:05:15 --> Security Class Initialized
DEBUG - 2016-05-11 18:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:05:15 --> Input Class Initialized
INFO - 2016-05-11 18:05:15 --> Language Class Initialized
INFO - 2016-05-11 18:05:15 --> Loader Class Initialized
INFO - 2016-05-11 18:05:15 --> Helper loaded: url_helper
INFO - 2016-05-11 18:05:15 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:05:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:05:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:05:15 --> Helper loaded: form_helper
INFO - 2016-05-11 18:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:05:15 --> Form Validation Class Initialized
INFO - 2016-05-11 18:05:15 --> Controller Class Initialized
INFO - 2016-05-11 18:05:15 --> Model Class Initialized
INFO - 2016-05-11 18:05:15 --> Database Driver Class Initialized
INFO - 2016-05-11 18:05:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:05:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:05:15 --> Final output sent to browser
DEBUG - 2016-05-11 18:05:15 --> Total execution time: 0.2470
INFO - 2016-05-11 18:05:38 --> Config Class Initialized
INFO - 2016-05-11 18:05:38 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:05:38 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:05:38 --> Utf8 Class Initialized
INFO - 2016-05-11 18:05:38 --> URI Class Initialized
DEBUG - 2016-05-11 18:05:38 --> No URI present. Default controller set.
INFO - 2016-05-11 18:05:38 --> Router Class Initialized
INFO - 2016-05-11 18:05:38 --> Output Class Initialized
INFO - 2016-05-11 18:05:38 --> Security Class Initialized
DEBUG - 2016-05-11 18:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:05:38 --> Input Class Initialized
INFO - 2016-05-11 18:05:38 --> Language Class Initialized
INFO - 2016-05-11 18:05:38 --> Loader Class Initialized
INFO - 2016-05-11 18:05:38 --> Helper loaded: url_helper
INFO - 2016-05-11 18:05:38 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:05:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:05:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:05:38 --> Helper loaded: form_helper
INFO - 2016-05-11 18:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:05:38 --> Form Validation Class Initialized
INFO - 2016-05-11 18:05:38 --> Controller Class Initialized
INFO - 2016-05-11 18:05:38 --> Model Class Initialized
INFO - 2016-05-11 18:05:38 --> Database Driver Class Initialized
INFO - 2016-05-11 18:05:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:05:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:05:38 --> Final output sent to browser
DEBUG - 2016-05-11 18:05:38 --> Total execution time: 0.1761
INFO - 2016-05-11 18:06:23 --> Config Class Initialized
INFO - 2016-05-11 18:06:23 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:06:23 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:06:23 --> Utf8 Class Initialized
INFO - 2016-05-11 18:06:23 --> URI Class Initialized
DEBUG - 2016-05-11 18:06:23 --> No URI present. Default controller set.
INFO - 2016-05-11 18:06:23 --> Router Class Initialized
INFO - 2016-05-11 18:06:23 --> Output Class Initialized
INFO - 2016-05-11 18:06:23 --> Security Class Initialized
DEBUG - 2016-05-11 18:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:06:23 --> Input Class Initialized
INFO - 2016-05-11 18:06:23 --> Language Class Initialized
INFO - 2016-05-11 18:06:23 --> Loader Class Initialized
INFO - 2016-05-11 18:06:23 --> Helper loaded: url_helper
INFO - 2016-05-11 18:06:23 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:06:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:06:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:06:23 --> Helper loaded: form_helper
INFO - 2016-05-11 18:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:06:23 --> Form Validation Class Initialized
INFO - 2016-05-11 18:06:23 --> Controller Class Initialized
INFO - 2016-05-11 18:06:23 --> Model Class Initialized
INFO - 2016-05-11 18:06:23 --> Database Driver Class Initialized
INFO - 2016-05-11 18:06:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:06:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:06:23 --> Final output sent to browser
DEBUG - 2016-05-11 18:06:23 --> Total execution time: 0.1139
INFO - 2016-05-11 18:06:44 --> Config Class Initialized
INFO - 2016-05-11 18:06:44 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:06:44 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:06:44 --> Utf8 Class Initialized
INFO - 2016-05-11 18:06:44 --> URI Class Initialized
DEBUG - 2016-05-11 18:06:44 --> No URI present. Default controller set.
INFO - 2016-05-11 18:06:44 --> Router Class Initialized
INFO - 2016-05-11 18:06:44 --> Output Class Initialized
INFO - 2016-05-11 18:06:44 --> Security Class Initialized
DEBUG - 2016-05-11 18:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:06:44 --> Input Class Initialized
INFO - 2016-05-11 18:06:44 --> Language Class Initialized
INFO - 2016-05-11 18:06:44 --> Loader Class Initialized
INFO - 2016-05-11 18:06:44 --> Helper loaded: url_helper
INFO - 2016-05-11 18:06:44 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:06:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:06:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:06:44 --> Helper loaded: form_helper
INFO - 2016-05-11 18:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:06:44 --> Form Validation Class Initialized
INFO - 2016-05-11 18:06:44 --> Controller Class Initialized
INFO - 2016-05-11 18:06:44 --> Model Class Initialized
INFO - 2016-05-11 18:06:44 --> Database Driver Class Initialized
INFO - 2016-05-11 18:06:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:06:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:06:44 --> Final output sent to browser
DEBUG - 2016-05-11 18:06:44 --> Total execution time: 0.1069
INFO - 2016-05-11 18:09:31 --> Config Class Initialized
INFO - 2016-05-11 18:09:31 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:09:31 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:09:31 --> Utf8 Class Initialized
INFO - 2016-05-11 18:09:31 --> URI Class Initialized
DEBUG - 2016-05-11 18:09:31 --> No URI present. Default controller set.
INFO - 2016-05-11 18:09:31 --> Router Class Initialized
INFO - 2016-05-11 18:09:31 --> Output Class Initialized
INFO - 2016-05-11 18:09:31 --> Security Class Initialized
DEBUG - 2016-05-11 18:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:09:31 --> Input Class Initialized
INFO - 2016-05-11 18:09:31 --> Language Class Initialized
INFO - 2016-05-11 18:09:31 --> Loader Class Initialized
INFO - 2016-05-11 18:09:31 --> Helper loaded: url_helper
INFO - 2016-05-11 18:09:31 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:09:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:09:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:09:31 --> Helper loaded: form_helper
INFO - 2016-05-11 18:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:09:31 --> Form Validation Class Initialized
INFO - 2016-05-11 18:09:31 --> Controller Class Initialized
INFO - 2016-05-11 18:09:31 --> Model Class Initialized
INFO - 2016-05-11 18:09:31 --> Database Driver Class Initialized
INFO - 2016-05-11 18:09:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:09:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:09:32 --> Final output sent to browser
DEBUG - 2016-05-11 18:09:32 --> Total execution time: 0.1747
INFO - 2016-05-11 18:15:10 --> Config Class Initialized
INFO - 2016-05-11 18:15:10 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:15:10 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:15:10 --> Utf8 Class Initialized
INFO - 2016-05-11 18:15:10 --> URI Class Initialized
DEBUG - 2016-05-11 18:15:10 --> No URI present. Default controller set.
INFO - 2016-05-11 18:15:10 --> Router Class Initialized
INFO - 2016-05-11 18:15:10 --> Output Class Initialized
INFO - 2016-05-11 18:15:10 --> Security Class Initialized
DEBUG - 2016-05-11 18:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:15:10 --> Input Class Initialized
INFO - 2016-05-11 18:15:10 --> Language Class Initialized
INFO - 2016-05-11 18:15:10 --> Loader Class Initialized
INFO - 2016-05-11 18:15:10 --> Helper loaded: url_helper
INFO - 2016-05-11 18:15:10 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:15:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:15:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:15:10 --> Helper loaded: form_helper
INFO - 2016-05-11 18:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:15:10 --> Form Validation Class Initialized
INFO - 2016-05-11 18:15:10 --> Controller Class Initialized
INFO - 2016-05-11 18:15:10 --> Model Class Initialized
INFO - 2016-05-11 18:15:10 --> Database Driver Class Initialized
INFO - 2016-05-11 18:15:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:15:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:15:10 --> Final output sent to browser
DEBUG - 2016-05-11 18:15:10 --> Total execution time: 0.1005
INFO - 2016-05-11 18:15:46 --> Config Class Initialized
INFO - 2016-05-11 18:15:46 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:15:46 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:15:46 --> Utf8 Class Initialized
INFO - 2016-05-11 18:15:46 --> URI Class Initialized
DEBUG - 2016-05-11 18:15:46 --> No URI present. Default controller set.
INFO - 2016-05-11 18:15:46 --> Router Class Initialized
INFO - 2016-05-11 18:15:46 --> Output Class Initialized
INFO - 2016-05-11 18:15:46 --> Security Class Initialized
DEBUG - 2016-05-11 18:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:15:46 --> Input Class Initialized
INFO - 2016-05-11 18:15:46 --> Language Class Initialized
INFO - 2016-05-11 18:15:46 --> Loader Class Initialized
INFO - 2016-05-11 18:15:46 --> Helper loaded: url_helper
INFO - 2016-05-11 18:15:46 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:15:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:15:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:15:46 --> Helper loaded: form_helper
INFO - 2016-05-11 18:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:15:46 --> Form Validation Class Initialized
INFO - 2016-05-11 18:15:46 --> Controller Class Initialized
INFO - 2016-05-11 18:15:46 --> Model Class Initialized
INFO - 2016-05-11 18:15:46 --> Database Driver Class Initialized
INFO - 2016-05-11 18:15:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:15:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:15:46 --> Final output sent to browser
DEBUG - 2016-05-11 18:15:46 --> Total execution time: 0.0896
INFO - 2016-05-11 18:16:10 --> Config Class Initialized
INFO - 2016-05-11 18:16:10 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:16:10 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:16:10 --> Utf8 Class Initialized
INFO - 2016-05-11 18:16:10 --> URI Class Initialized
DEBUG - 2016-05-11 18:16:10 --> No URI present. Default controller set.
INFO - 2016-05-11 18:16:10 --> Router Class Initialized
INFO - 2016-05-11 18:16:10 --> Output Class Initialized
INFO - 2016-05-11 18:16:10 --> Security Class Initialized
DEBUG - 2016-05-11 18:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:16:10 --> Input Class Initialized
INFO - 2016-05-11 18:16:10 --> Language Class Initialized
INFO - 2016-05-11 18:16:10 --> Loader Class Initialized
INFO - 2016-05-11 18:16:10 --> Helper loaded: url_helper
INFO - 2016-05-11 18:16:11 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:16:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:16:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:16:11 --> Helper loaded: form_helper
INFO - 2016-05-11 18:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:16:11 --> Form Validation Class Initialized
INFO - 2016-05-11 18:16:11 --> Controller Class Initialized
INFO - 2016-05-11 18:16:11 --> Model Class Initialized
INFO - 2016-05-11 18:16:11 --> Database Driver Class Initialized
INFO - 2016-05-11 18:16:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:16:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:16:11 --> Final output sent to browser
DEBUG - 2016-05-11 18:16:11 --> Total execution time: 0.1742
INFO - 2016-05-11 18:16:19 --> Config Class Initialized
INFO - 2016-05-11 18:16:19 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:16:19 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:16:19 --> Utf8 Class Initialized
INFO - 2016-05-11 18:16:19 --> URI Class Initialized
DEBUG - 2016-05-11 18:16:19 --> No URI present. Default controller set.
INFO - 2016-05-11 18:16:19 --> Router Class Initialized
INFO - 2016-05-11 18:16:19 --> Output Class Initialized
INFO - 2016-05-11 18:16:19 --> Security Class Initialized
DEBUG - 2016-05-11 18:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:16:19 --> Input Class Initialized
INFO - 2016-05-11 18:16:19 --> Language Class Initialized
INFO - 2016-05-11 18:16:19 --> Loader Class Initialized
INFO - 2016-05-11 18:16:19 --> Helper loaded: url_helper
INFO - 2016-05-11 18:16:19 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:16:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:16:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:16:19 --> Helper loaded: form_helper
INFO - 2016-05-11 18:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:16:19 --> Form Validation Class Initialized
INFO - 2016-05-11 18:16:19 --> Controller Class Initialized
INFO - 2016-05-11 18:16:19 --> Model Class Initialized
INFO - 2016-05-11 18:16:19 --> Database Driver Class Initialized
INFO - 2016-05-11 18:16:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:16:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:16:19 --> Final output sent to browser
DEBUG - 2016-05-11 18:16:19 --> Total execution time: 0.1387
INFO - 2016-05-11 18:16:23 --> Config Class Initialized
INFO - 2016-05-11 18:16:23 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:16:24 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:16:24 --> Utf8 Class Initialized
INFO - 2016-05-11 18:16:24 --> URI Class Initialized
DEBUG - 2016-05-11 18:16:24 --> No URI present. Default controller set.
INFO - 2016-05-11 18:16:24 --> Router Class Initialized
INFO - 2016-05-11 18:16:24 --> Output Class Initialized
INFO - 2016-05-11 18:16:24 --> Security Class Initialized
DEBUG - 2016-05-11 18:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:16:24 --> Input Class Initialized
INFO - 2016-05-11 18:16:24 --> Language Class Initialized
INFO - 2016-05-11 18:16:24 --> Loader Class Initialized
INFO - 2016-05-11 18:16:24 --> Helper loaded: url_helper
INFO - 2016-05-11 18:16:24 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:16:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:16:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:16:24 --> Helper loaded: form_helper
INFO - 2016-05-11 18:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:16:24 --> Form Validation Class Initialized
INFO - 2016-05-11 18:16:24 --> Controller Class Initialized
INFO - 2016-05-11 18:16:24 --> Model Class Initialized
INFO - 2016-05-11 18:16:24 --> Database Driver Class Initialized
INFO - 2016-05-11 18:16:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:16:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:16:24 --> Final output sent to browser
DEBUG - 2016-05-11 18:16:24 --> Total execution time: 0.1789
INFO - 2016-05-11 18:16:46 --> Config Class Initialized
INFO - 2016-05-11 18:16:46 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:16:46 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:16:46 --> Utf8 Class Initialized
INFO - 2016-05-11 18:16:46 --> URI Class Initialized
DEBUG - 2016-05-11 18:16:46 --> No URI present. Default controller set.
INFO - 2016-05-11 18:16:46 --> Router Class Initialized
INFO - 2016-05-11 18:16:46 --> Output Class Initialized
INFO - 2016-05-11 18:16:46 --> Security Class Initialized
DEBUG - 2016-05-11 18:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:16:46 --> Input Class Initialized
INFO - 2016-05-11 18:16:46 --> Language Class Initialized
INFO - 2016-05-11 18:16:46 --> Loader Class Initialized
INFO - 2016-05-11 18:16:46 --> Helper loaded: url_helper
INFO - 2016-05-11 18:16:46 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:16:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:16:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:16:46 --> Helper loaded: form_helper
INFO - 2016-05-11 18:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:16:46 --> Form Validation Class Initialized
INFO - 2016-05-11 18:16:46 --> Controller Class Initialized
INFO - 2016-05-11 18:16:46 --> Model Class Initialized
INFO - 2016-05-11 18:16:46 --> Database Driver Class Initialized
INFO - 2016-05-11 18:16:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:16:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:16:46 --> Final output sent to browser
DEBUG - 2016-05-11 18:16:46 --> Total execution time: 0.1042
INFO - 2016-05-11 18:17:30 --> Config Class Initialized
INFO - 2016-05-11 18:17:30 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:17:30 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:17:30 --> Utf8 Class Initialized
INFO - 2016-05-11 18:17:30 --> URI Class Initialized
DEBUG - 2016-05-11 18:17:30 --> No URI present. Default controller set.
INFO - 2016-05-11 18:17:30 --> Router Class Initialized
INFO - 2016-05-11 18:17:30 --> Output Class Initialized
INFO - 2016-05-11 18:17:30 --> Security Class Initialized
DEBUG - 2016-05-11 18:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:17:30 --> Input Class Initialized
INFO - 2016-05-11 18:17:30 --> Language Class Initialized
INFO - 2016-05-11 18:17:30 --> Loader Class Initialized
INFO - 2016-05-11 18:17:30 --> Helper loaded: url_helper
INFO - 2016-05-11 18:17:30 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:17:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:17:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:17:30 --> Helper loaded: form_helper
INFO - 2016-05-11 18:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:17:30 --> Form Validation Class Initialized
INFO - 2016-05-11 18:17:30 --> Controller Class Initialized
INFO - 2016-05-11 18:17:30 --> Model Class Initialized
INFO - 2016-05-11 18:17:30 --> Database Driver Class Initialized
INFO - 2016-05-11 18:17:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:17:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:17:30 --> Final output sent to browser
DEBUG - 2016-05-11 18:17:30 --> Total execution time: 0.0766
INFO - 2016-05-11 18:17:31 --> Config Class Initialized
INFO - 2016-05-11 18:17:31 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:17:31 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:17:31 --> Utf8 Class Initialized
INFO - 2016-05-11 18:17:31 --> URI Class Initialized
DEBUG - 2016-05-11 18:17:31 --> No URI present. Default controller set.
INFO - 2016-05-11 18:17:31 --> Router Class Initialized
INFO - 2016-05-11 18:17:31 --> Output Class Initialized
INFO - 2016-05-11 18:17:31 --> Security Class Initialized
DEBUG - 2016-05-11 18:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:17:31 --> Input Class Initialized
INFO - 2016-05-11 18:17:31 --> Language Class Initialized
INFO - 2016-05-11 18:17:31 --> Loader Class Initialized
INFO - 2016-05-11 18:17:31 --> Helper loaded: url_helper
INFO - 2016-05-11 18:17:31 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:17:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:17:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:17:31 --> Helper loaded: form_helper
INFO - 2016-05-11 18:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:17:31 --> Form Validation Class Initialized
INFO - 2016-05-11 18:17:31 --> Controller Class Initialized
INFO - 2016-05-11 18:17:31 --> Model Class Initialized
INFO - 2016-05-11 18:17:31 --> Database Driver Class Initialized
INFO - 2016-05-11 18:17:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:17:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:17:31 --> Final output sent to browser
DEBUG - 2016-05-11 18:17:31 --> Total execution time: 0.1404
INFO - 2016-05-11 18:19:00 --> Config Class Initialized
INFO - 2016-05-11 18:19:00 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:19:00 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:19:00 --> Utf8 Class Initialized
INFO - 2016-05-11 18:19:00 --> URI Class Initialized
DEBUG - 2016-05-11 18:19:00 --> No URI present. Default controller set.
INFO - 2016-05-11 18:19:00 --> Router Class Initialized
INFO - 2016-05-11 18:19:00 --> Output Class Initialized
INFO - 2016-05-11 18:19:00 --> Security Class Initialized
DEBUG - 2016-05-11 18:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:19:00 --> Input Class Initialized
INFO - 2016-05-11 18:19:00 --> Language Class Initialized
INFO - 2016-05-11 18:19:00 --> Loader Class Initialized
INFO - 2016-05-11 18:19:00 --> Helper loaded: url_helper
INFO - 2016-05-11 18:19:00 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:19:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:19:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:19:00 --> Helper loaded: form_helper
INFO - 2016-05-11 18:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:19:00 --> Form Validation Class Initialized
INFO - 2016-05-11 18:19:00 --> Controller Class Initialized
INFO - 2016-05-11 18:19:00 --> Model Class Initialized
INFO - 2016-05-11 18:19:00 --> Database Driver Class Initialized
INFO - 2016-05-11 18:19:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:19:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:19:00 --> Final output sent to browser
DEBUG - 2016-05-11 18:19:00 --> Total execution time: 0.0998
INFO - 2016-05-11 18:23:37 --> Config Class Initialized
INFO - 2016-05-11 18:23:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:23:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:23:37 --> Utf8 Class Initialized
INFO - 2016-05-11 18:23:37 --> URI Class Initialized
DEBUG - 2016-05-11 18:23:37 --> No URI present. Default controller set.
INFO - 2016-05-11 18:23:37 --> Router Class Initialized
INFO - 2016-05-11 18:23:37 --> Output Class Initialized
INFO - 2016-05-11 18:23:37 --> Security Class Initialized
DEBUG - 2016-05-11 18:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:23:37 --> Input Class Initialized
INFO - 2016-05-11 18:23:37 --> Language Class Initialized
INFO - 2016-05-11 18:23:37 --> Loader Class Initialized
INFO - 2016-05-11 18:23:37 --> Helper loaded: url_helper
INFO - 2016-05-11 18:23:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:23:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:23:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:23:37 --> Helper loaded: form_helper
INFO - 2016-05-11 18:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:23:37 --> Form Validation Class Initialized
INFO - 2016-05-11 18:23:37 --> Controller Class Initialized
INFO - 2016-05-11 18:23:37 --> Model Class Initialized
INFO - 2016-05-11 18:23:37 --> Database Driver Class Initialized
INFO - 2016-05-11 18:23:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:23:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:23:37 --> Final output sent to browser
DEBUG - 2016-05-11 18:23:37 --> Total execution time: 0.2169
INFO - 2016-05-11 18:25:14 --> Config Class Initialized
INFO - 2016-05-11 18:25:14 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:25:14 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:25:14 --> Utf8 Class Initialized
INFO - 2016-05-11 18:25:14 --> URI Class Initialized
DEBUG - 2016-05-11 18:25:14 --> No URI present. Default controller set.
INFO - 2016-05-11 18:25:14 --> Router Class Initialized
INFO - 2016-05-11 18:25:14 --> Output Class Initialized
INFO - 2016-05-11 18:25:14 --> Security Class Initialized
DEBUG - 2016-05-11 18:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:25:14 --> Input Class Initialized
INFO - 2016-05-11 18:25:14 --> Language Class Initialized
INFO - 2016-05-11 18:25:14 --> Loader Class Initialized
INFO - 2016-05-11 18:25:14 --> Helper loaded: url_helper
INFO - 2016-05-11 18:25:14 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:25:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:25:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:25:14 --> Helper loaded: form_helper
INFO - 2016-05-11 18:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:25:15 --> Form Validation Class Initialized
INFO - 2016-05-11 18:25:15 --> Controller Class Initialized
INFO - 2016-05-11 18:25:15 --> Model Class Initialized
INFO - 2016-05-11 18:25:15 --> Database Driver Class Initialized
INFO - 2016-05-11 18:25:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:25:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:25:15 --> Final output sent to browser
DEBUG - 2016-05-11 18:25:15 --> Total execution time: 0.1788
INFO - 2016-05-11 18:25:17 --> Config Class Initialized
INFO - 2016-05-11 18:25:17 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:25:17 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:25:17 --> Utf8 Class Initialized
INFO - 2016-05-11 18:25:17 --> URI Class Initialized
DEBUG - 2016-05-11 18:25:17 --> No URI present. Default controller set.
INFO - 2016-05-11 18:25:17 --> Router Class Initialized
INFO - 2016-05-11 18:25:17 --> Output Class Initialized
INFO - 2016-05-11 18:25:17 --> Security Class Initialized
DEBUG - 2016-05-11 18:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:25:17 --> Input Class Initialized
INFO - 2016-05-11 18:25:17 --> Language Class Initialized
INFO - 2016-05-11 18:25:17 --> Loader Class Initialized
INFO - 2016-05-11 18:25:17 --> Helper loaded: url_helper
INFO - 2016-05-11 18:25:17 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:25:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:25:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:25:17 --> Helper loaded: form_helper
INFO - 2016-05-11 18:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:25:17 --> Form Validation Class Initialized
INFO - 2016-05-11 18:25:17 --> Controller Class Initialized
INFO - 2016-05-11 18:25:17 --> Model Class Initialized
INFO - 2016-05-11 18:25:17 --> Database Driver Class Initialized
INFO - 2016-05-11 18:25:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:25:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:25:17 --> Final output sent to browser
DEBUG - 2016-05-11 18:25:17 --> Total execution time: 0.0804
INFO - 2016-05-11 18:27:36 --> Config Class Initialized
INFO - 2016-05-11 18:27:36 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:27:36 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:27:36 --> Utf8 Class Initialized
INFO - 2016-05-11 18:27:36 --> URI Class Initialized
DEBUG - 2016-05-11 18:27:36 --> No URI present. Default controller set.
INFO - 2016-05-11 18:27:36 --> Router Class Initialized
INFO - 2016-05-11 18:27:36 --> Output Class Initialized
INFO - 2016-05-11 18:27:36 --> Security Class Initialized
DEBUG - 2016-05-11 18:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:27:36 --> Input Class Initialized
INFO - 2016-05-11 18:27:36 --> Language Class Initialized
INFO - 2016-05-11 18:27:36 --> Loader Class Initialized
INFO - 2016-05-11 18:27:36 --> Helper loaded: url_helper
INFO - 2016-05-11 18:27:36 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:27:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:27:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:27:36 --> Helper loaded: form_helper
INFO - 2016-05-11 18:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:27:36 --> Form Validation Class Initialized
INFO - 2016-05-11 18:27:36 --> Controller Class Initialized
INFO - 2016-05-11 18:27:36 --> Model Class Initialized
INFO - 2016-05-11 18:27:36 --> Database Driver Class Initialized
INFO - 2016-05-11 18:27:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:27:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:27:36 --> Final output sent to browser
DEBUG - 2016-05-11 18:27:36 --> Total execution time: 0.2102
INFO - 2016-05-11 18:27:37 --> Config Class Initialized
INFO - 2016-05-11 18:27:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:27:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:27:37 --> Utf8 Class Initialized
INFO - 2016-05-11 18:27:37 --> URI Class Initialized
DEBUG - 2016-05-11 18:27:37 --> No URI present. Default controller set.
INFO - 2016-05-11 18:27:37 --> Router Class Initialized
INFO - 2016-05-11 18:27:37 --> Output Class Initialized
INFO - 2016-05-11 18:27:37 --> Security Class Initialized
DEBUG - 2016-05-11 18:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:27:37 --> Input Class Initialized
INFO - 2016-05-11 18:27:37 --> Language Class Initialized
INFO - 2016-05-11 18:27:37 --> Loader Class Initialized
INFO - 2016-05-11 18:27:37 --> Helper loaded: url_helper
INFO - 2016-05-11 18:27:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:27:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:27:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:27:37 --> Helper loaded: form_helper
INFO - 2016-05-11 18:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:27:37 --> Form Validation Class Initialized
INFO - 2016-05-11 18:27:37 --> Controller Class Initialized
INFO - 2016-05-11 18:27:37 --> Model Class Initialized
INFO - 2016-05-11 18:27:37 --> Database Driver Class Initialized
INFO - 2016-05-11 18:27:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:27:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:27:37 --> Final output sent to browser
DEBUG - 2016-05-11 18:27:37 --> Total execution time: 0.1094
INFO - 2016-05-11 18:28:24 --> Config Class Initialized
INFO - 2016-05-11 18:28:24 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:28:24 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:28:24 --> Utf8 Class Initialized
INFO - 2016-05-11 18:28:24 --> URI Class Initialized
DEBUG - 2016-05-11 18:28:24 --> No URI present. Default controller set.
INFO - 2016-05-11 18:28:24 --> Router Class Initialized
INFO - 2016-05-11 18:28:24 --> Output Class Initialized
INFO - 2016-05-11 18:28:24 --> Security Class Initialized
DEBUG - 2016-05-11 18:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:28:24 --> Input Class Initialized
INFO - 2016-05-11 18:28:24 --> Language Class Initialized
INFO - 2016-05-11 18:28:24 --> Loader Class Initialized
INFO - 2016-05-11 18:28:24 --> Helper loaded: url_helper
INFO - 2016-05-11 18:28:24 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:28:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:28:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:28:24 --> Helper loaded: form_helper
INFO - 2016-05-11 18:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:28:24 --> Form Validation Class Initialized
INFO - 2016-05-11 18:28:24 --> Controller Class Initialized
INFO - 2016-05-11 18:28:24 --> Model Class Initialized
INFO - 2016-05-11 18:28:24 --> Database Driver Class Initialized
INFO - 2016-05-11 18:28:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:28:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:28:24 --> Final output sent to browser
DEBUG - 2016-05-11 18:28:24 --> Total execution time: 0.1229
INFO - 2016-05-11 18:28:44 --> Config Class Initialized
INFO - 2016-05-11 18:28:44 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:28:44 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:28:44 --> Utf8 Class Initialized
INFO - 2016-05-11 18:28:44 --> URI Class Initialized
DEBUG - 2016-05-11 18:28:44 --> No URI present. Default controller set.
INFO - 2016-05-11 18:28:44 --> Router Class Initialized
INFO - 2016-05-11 18:28:44 --> Output Class Initialized
INFO - 2016-05-11 18:28:44 --> Security Class Initialized
DEBUG - 2016-05-11 18:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:28:44 --> Input Class Initialized
INFO - 2016-05-11 18:28:44 --> Language Class Initialized
INFO - 2016-05-11 18:28:44 --> Loader Class Initialized
INFO - 2016-05-11 18:28:44 --> Helper loaded: url_helper
INFO - 2016-05-11 18:28:44 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:28:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:28:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:28:44 --> Helper loaded: form_helper
INFO - 2016-05-11 18:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:28:44 --> Form Validation Class Initialized
INFO - 2016-05-11 18:28:44 --> Controller Class Initialized
INFO - 2016-05-11 18:28:44 --> Model Class Initialized
INFO - 2016-05-11 18:28:44 --> Database Driver Class Initialized
INFO - 2016-05-11 18:28:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:28:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:28:44 --> Final output sent to browser
DEBUG - 2016-05-11 18:28:44 --> Total execution time: 0.2041
INFO - 2016-05-11 18:28:50 --> Config Class Initialized
INFO - 2016-05-11 18:28:50 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:28:50 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:28:50 --> Utf8 Class Initialized
INFO - 2016-05-11 18:28:50 --> URI Class Initialized
DEBUG - 2016-05-11 18:28:50 --> No URI present. Default controller set.
INFO - 2016-05-11 18:28:50 --> Router Class Initialized
INFO - 2016-05-11 18:28:50 --> Output Class Initialized
INFO - 2016-05-11 18:28:50 --> Security Class Initialized
DEBUG - 2016-05-11 18:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:28:50 --> Input Class Initialized
INFO - 2016-05-11 18:28:50 --> Language Class Initialized
INFO - 2016-05-11 18:28:50 --> Loader Class Initialized
INFO - 2016-05-11 18:28:50 --> Helper loaded: url_helper
INFO - 2016-05-11 18:28:50 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:28:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:28:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:28:50 --> Helper loaded: form_helper
INFO - 2016-05-11 18:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:28:51 --> Form Validation Class Initialized
INFO - 2016-05-11 18:28:51 --> Controller Class Initialized
INFO - 2016-05-11 18:28:51 --> Model Class Initialized
INFO - 2016-05-11 18:28:51 --> Database Driver Class Initialized
INFO - 2016-05-11 18:28:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:28:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:28:51 --> Final output sent to browser
DEBUG - 2016-05-11 18:28:51 --> Total execution time: 0.1104
INFO - 2016-05-11 18:29:00 --> Config Class Initialized
INFO - 2016-05-11 18:29:00 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:29:00 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:29:00 --> Utf8 Class Initialized
INFO - 2016-05-11 18:29:00 --> URI Class Initialized
DEBUG - 2016-05-11 18:29:00 --> No URI present. Default controller set.
INFO - 2016-05-11 18:29:00 --> Router Class Initialized
INFO - 2016-05-11 18:29:00 --> Output Class Initialized
INFO - 2016-05-11 18:29:00 --> Security Class Initialized
DEBUG - 2016-05-11 18:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:29:00 --> Input Class Initialized
INFO - 2016-05-11 18:29:00 --> Language Class Initialized
INFO - 2016-05-11 18:29:00 --> Loader Class Initialized
INFO - 2016-05-11 18:29:00 --> Helper loaded: url_helper
INFO - 2016-05-11 18:29:00 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:29:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:29:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:29:00 --> Helper loaded: form_helper
INFO - 2016-05-11 18:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:29:00 --> Form Validation Class Initialized
INFO - 2016-05-11 18:29:00 --> Controller Class Initialized
INFO - 2016-05-11 18:29:00 --> Model Class Initialized
INFO - 2016-05-11 18:29:00 --> Database Driver Class Initialized
INFO - 2016-05-11 18:29:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:29:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:29:00 --> Final output sent to browser
DEBUG - 2016-05-11 18:29:00 --> Total execution time: 0.1314
INFO - 2016-05-11 18:30:42 --> Config Class Initialized
INFO - 2016-05-11 18:30:42 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:30:42 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:30:42 --> Utf8 Class Initialized
INFO - 2016-05-11 18:30:42 --> URI Class Initialized
DEBUG - 2016-05-11 18:30:42 --> No URI present. Default controller set.
INFO - 2016-05-11 18:30:42 --> Router Class Initialized
INFO - 2016-05-11 18:30:42 --> Output Class Initialized
INFO - 2016-05-11 18:30:42 --> Security Class Initialized
DEBUG - 2016-05-11 18:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:30:42 --> Input Class Initialized
INFO - 2016-05-11 18:30:42 --> Language Class Initialized
INFO - 2016-05-11 18:30:42 --> Loader Class Initialized
INFO - 2016-05-11 18:30:42 --> Helper loaded: url_helper
INFO - 2016-05-11 18:30:42 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:30:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:30:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:30:42 --> Helper loaded: form_helper
INFO - 2016-05-11 18:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:30:42 --> Form Validation Class Initialized
INFO - 2016-05-11 18:30:42 --> Controller Class Initialized
INFO - 2016-05-11 18:30:42 --> Model Class Initialized
INFO - 2016-05-11 18:30:42 --> Database Driver Class Initialized
INFO - 2016-05-11 18:30:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:30:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:30:42 --> Final output sent to browser
DEBUG - 2016-05-11 18:30:42 --> Total execution time: 0.1060
INFO - 2016-05-11 18:33:20 --> Config Class Initialized
INFO - 2016-05-11 18:33:20 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:33:20 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:33:20 --> Utf8 Class Initialized
INFO - 2016-05-11 18:33:20 --> URI Class Initialized
DEBUG - 2016-05-11 18:33:20 --> No URI present. Default controller set.
INFO - 2016-05-11 18:33:20 --> Router Class Initialized
INFO - 2016-05-11 18:33:20 --> Output Class Initialized
INFO - 2016-05-11 18:33:20 --> Security Class Initialized
DEBUG - 2016-05-11 18:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:33:20 --> Input Class Initialized
INFO - 2016-05-11 18:33:20 --> Language Class Initialized
INFO - 2016-05-11 18:33:20 --> Loader Class Initialized
INFO - 2016-05-11 18:33:20 --> Helper loaded: url_helper
INFO - 2016-05-11 18:33:20 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:33:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:33:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:33:20 --> Helper loaded: form_helper
INFO - 2016-05-11 18:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:33:20 --> Form Validation Class Initialized
INFO - 2016-05-11 18:33:20 --> Controller Class Initialized
INFO - 2016-05-11 18:33:20 --> Model Class Initialized
INFO - 2016-05-11 18:33:20 --> Database Driver Class Initialized
INFO - 2016-05-11 18:33:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:33:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:33:20 --> Final output sent to browser
DEBUG - 2016-05-11 18:33:20 --> Total execution time: 0.1915
INFO - 2016-05-11 18:33:41 --> Config Class Initialized
INFO - 2016-05-11 18:33:41 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:33:41 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:33:41 --> Utf8 Class Initialized
INFO - 2016-05-11 18:33:41 --> URI Class Initialized
DEBUG - 2016-05-11 18:33:41 --> No URI present. Default controller set.
INFO - 2016-05-11 18:33:41 --> Router Class Initialized
INFO - 2016-05-11 18:33:42 --> Output Class Initialized
INFO - 2016-05-11 18:33:42 --> Security Class Initialized
DEBUG - 2016-05-11 18:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:33:42 --> Input Class Initialized
INFO - 2016-05-11 18:33:42 --> Language Class Initialized
INFO - 2016-05-11 18:33:42 --> Loader Class Initialized
INFO - 2016-05-11 18:33:42 --> Helper loaded: url_helper
INFO - 2016-05-11 18:33:42 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:33:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:33:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:33:42 --> Helper loaded: form_helper
INFO - 2016-05-11 18:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:33:42 --> Form Validation Class Initialized
INFO - 2016-05-11 18:33:42 --> Controller Class Initialized
INFO - 2016-05-11 18:33:42 --> Model Class Initialized
INFO - 2016-05-11 18:33:42 --> Database Driver Class Initialized
INFO - 2016-05-11 18:33:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:33:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:33:42 --> Final output sent to browser
DEBUG - 2016-05-11 18:33:42 --> Total execution time: 0.1617
INFO - 2016-05-11 18:33:52 --> Config Class Initialized
INFO - 2016-05-11 18:33:52 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:33:52 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:33:52 --> Utf8 Class Initialized
INFO - 2016-05-11 18:33:52 --> URI Class Initialized
DEBUG - 2016-05-11 18:33:52 --> No URI present. Default controller set.
INFO - 2016-05-11 18:33:52 --> Router Class Initialized
INFO - 2016-05-11 18:33:52 --> Output Class Initialized
INFO - 2016-05-11 18:33:52 --> Security Class Initialized
DEBUG - 2016-05-11 18:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:33:52 --> Input Class Initialized
INFO - 2016-05-11 18:33:52 --> Language Class Initialized
INFO - 2016-05-11 18:33:52 --> Loader Class Initialized
INFO - 2016-05-11 18:33:52 --> Helper loaded: url_helper
INFO - 2016-05-11 18:33:52 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:33:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:33:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:33:52 --> Helper loaded: form_helper
INFO - 2016-05-11 18:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:33:52 --> Form Validation Class Initialized
INFO - 2016-05-11 18:33:52 --> Controller Class Initialized
INFO - 2016-05-11 18:33:52 --> Model Class Initialized
INFO - 2016-05-11 18:33:52 --> Database Driver Class Initialized
INFO - 2016-05-11 18:33:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:33:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:33:52 --> Final output sent to browser
DEBUG - 2016-05-11 18:33:52 --> Total execution time: 0.0739
INFO - 2016-05-11 18:33:53 --> Config Class Initialized
INFO - 2016-05-11 18:33:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:33:54 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:33:54 --> Utf8 Class Initialized
INFO - 2016-05-11 18:33:54 --> URI Class Initialized
DEBUG - 2016-05-11 18:33:54 --> No URI present. Default controller set.
INFO - 2016-05-11 18:33:54 --> Router Class Initialized
INFO - 2016-05-11 18:33:54 --> Output Class Initialized
INFO - 2016-05-11 18:33:54 --> Security Class Initialized
DEBUG - 2016-05-11 18:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:33:54 --> Input Class Initialized
INFO - 2016-05-11 18:33:54 --> Language Class Initialized
INFO - 2016-05-11 18:33:54 --> Loader Class Initialized
INFO - 2016-05-11 18:33:54 --> Helper loaded: url_helper
INFO - 2016-05-11 18:33:54 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:33:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:33:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:33:54 --> Helper loaded: form_helper
INFO - 2016-05-11 18:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:33:54 --> Form Validation Class Initialized
INFO - 2016-05-11 18:33:54 --> Controller Class Initialized
INFO - 2016-05-11 18:33:54 --> Model Class Initialized
INFO - 2016-05-11 18:33:54 --> Database Driver Class Initialized
INFO - 2016-05-11 18:33:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:33:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:33:54 --> Final output sent to browser
DEBUG - 2016-05-11 18:33:54 --> Total execution time: 0.1853
INFO - 2016-05-11 18:34:28 --> Config Class Initialized
INFO - 2016-05-11 18:34:28 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:34:28 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:34:28 --> Utf8 Class Initialized
INFO - 2016-05-11 18:34:28 --> URI Class Initialized
DEBUG - 2016-05-11 18:34:28 --> No URI present. Default controller set.
INFO - 2016-05-11 18:34:28 --> Router Class Initialized
INFO - 2016-05-11 18:34:28 --> Output Class Initialized
INFO - 2016-05-11 18:34:28 --> Security Class Initialized
DEBUG - 2016-05-11 18:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:34:28 --> Input Class Initialized
INFO - 2016-05-11 18:34:28 --> Language Class Initialized
INFO - 2016-05-11 18:34:28 --> Loader Class Initialized
INFO - 2016-05-11 18:34:28 --> Helper loaded: url_helper
INFO - 2016-05-11 18:34:28 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:34:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:34:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:34:28 --> Helper loaded: form_helper
INFO - 2016-05-11 18:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:34:28 --> Form Validation Class Initialized
INFO - 2016-05-11 18:34:28 --> Controller Class Initialized
INFO - 2016-05-11 18:34:28 --> Model Class Initialized
INFO - 2016-05-11 18:34:28 --> Database Driver Class Initialized
INFO - 2016-05-11 18:34:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:34:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:34:28 --> Final output sent to browser
DEBUG - 2016-05-11 18:34:28 --> Total execution time: 0.0836
INFO - 2016-05-11 18:35:14 --> Config Class Initialized
INFO - 2016-05-11 18:35:14 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:35:14 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:35:14 --> Utf8 Class Initialized
INFO - 2016-05-11 18:35:14 --> URI Class Initialized
DEBUG - 2016-05-11 18:35:14 --> No URI present. Default controller set.
INFO - 2016-05-11 18:35:14 --> Router Class Initialized
INFO - 2016-05-11 18:35:14 --> Output Class Initialized
INFO - 2016-05-11 18:35:14 --> Security Class Initialized
DEBUG - 2016-05-11 18:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:35:14 --> Input Class Initialized
INFO - 2016-05-11 18:35:14 --> Language Class Initialized
INFO - 2016-05-11 18:35:14 --> Loader Class Initialized
INFO - 2016-05-11 18:35:14 --> Helper loaded: url_helper
INFO - 2016-05-11 18:35:14 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:35:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:35:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:35:14 --> Helper loaded: form_helper
INFO - 2016-05-11 18:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:35:14 --> Form Validation Class Initialized
INFO - 2016-05-11 18:35:14 --> Controller Class Initialized
INFO - 2016-05-11 18:35:14 --> Model Class Initialized
INFO - 2016-05-11 18:35:14 --> Database Driver Class Initialized
INFO - 2016-05-11 18:35:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:35:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:35:14 --> Final output sent to browser
DEBUG - 2016-05-11 18:35:14 --> Total execution time: 0.0793
INFO - 2016-05-11 18:36:57 --> Config Class Initialized
INFO - 2016-05-11 18:36:57 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:36:57 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:36:57 --> Utf8 Class Initialized
INFO - 2016-05-11 18:36:57 --> URI Class Initialized
DEBUG - 2016-05-11 18:36:57 --> No URI present. Default controller set.
INFO - 2016-05-11 18:36:57 --> Router Class Initialized
INFO - 2016-05-11 18:36:58 --> Output Class Initialized
INFO - 2016-05-11 18:36:58 --> Security Class Initialized
DEBUG - 2016-05-11 18:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:36:58 --> Input Class Initialized
INFO - 2016-05-11 18:36:58 --> Language Class Initialized
INFO - 2016-05-11 18:36:58 --> Loader Class Initialized
INFO - 2016-05-11 18:36:58 --> Helper loaded: url_helper
INFO - 2016-05-11 18:36:58 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:36:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:36:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:36:58 --> Helper loaded: form_helper
INFO - 2016-05-11 18:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:36:58 --> Form Validation Class Initialized
INFO - 2016-05-11 18:36:58 --> Controller Class Initialized
INFO - 2016-05-11 18:36:58 --> Model Class Initialized
INFO - 2016-05-11 18:36:58 --> Database Driver Class Initialized
INFO - 2016-05-11 18:36:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:36:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:36:58 --> Final output sent to browser
DEBUG - 2016-05-11 18:36:58 --> Total execution time: 0.0825
INFO - 2016-05-11 18:37:09 --> Config Class Initialized
INFO - 2016-05-11 18:37:09 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:37:09 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:37:09 --> Utf8 Class Initialized
INFO - 2016-05-11 18:37:09 --> URI Class Initialized
DEBUG - 2016-05-11 18:37:09 --> No URI present. Default controller set.
INFO - 2016-05-11 18:37:09 --> Router Class Initialized
INFO - 2016-05-11 18:37:09 --> Output Class Initialized
INFO - 2016-05-11 18:37:09 --> Security Class Initialized
DEBUG - 2016-05-11 18:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:37:09 --> Input Class Initialized
INFO - 2016-05-11 18:37:09 --> Language Class Initialized
INFO - 2016-05-11 18:37:09 --> Loader Class Initialized
INFO - 2016-05-11 18:37:09 --> Helper loaded: url_helper
INFO - 2016-05-11 18:37:09 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:37:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:37:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:37:09 --> Helper loaded: form_helper
INFO - 2016-05-11 18:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:37:09 --> Form Validation Class Initialized
INFO - 2016-05-11 18:37:09 --> Controller Class Initialized
INFO - 2016-05-11 18:37:09 --> Model Class Initialized
INFO - 2016-05-11 18:37:09 --> Database Driver Class Initialized
INFO - 2016-05-11 18:37:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:37:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:37:09 --> Final output sent to browser
DEBUG - 2016-05-11 18:37:09 --> Total execution time: 0.1054
INFO - 2016-05-11 18:37:33 --> Config Class Initialized
INFO - 2016-05-11 18:37:33 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:37:33 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:37:33 --> Utf8 Class Initialized
INFO - 2016-05-11 18:37:33 --> URI Class Initialized
DEBUG - 2016-05-11 18:37:33 --> No URI present. Default controller set.
INFO - 2016-05-11 18:37:33 --> Router Class Initialized
INFO - 2016-05-11 18:37:33 --> Output Class Initialized
INFO - 2016-05-11 18:37:33 --> Security Class Initialized
DEBUG - 2016-05-11 18:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:37:33 --> Input Class Initialized
INFO - 2016-05-11 18:37:33 --> Language Class Initialized
INFO - 2016-05-11 18:37:33 --> Loader Class Initialized
INFO - 2016-05-11 18:37:33 --> Helper loaded: url_helper
INFO - 2016-05-11 18:37:33 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:37:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:37:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:37:33 --> Helper loaded: form_helper
INFO - 2016-05-11 18:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:37:33 --> Form Validation Class Initialized
INFO - 2016-05-11 18:37:33 --> Controller Class Initialized
INFO - 2016-05-11 18:37:33 --> Model Class Initialized
INFO - 2016-05-11 18:37:33 --> Database Driver Class Initialized
INFO - 2016-05-11 18:37:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:37:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:37:33 --> Final output sent to browser
DEBUG - 2016-05-11 18:37:33 --> Total execution time: 0.1611
INFO - 2016-05-11 18:37:44 --> Config Class Initialized
INFO - 2016-05-11 18:37:44 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:37:44 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:37:44 --> Utf8 Class Initialized
INFO - 2016-05-11 18:37:44 --> URI Class Initialized
DEBUG - 2016-05-11 18:37:44 --> No URI present. Default controller set.
INFO - 2016-05-11 18:37:44 --> Router Class Initialized
INFO - 2016-05-11 18:37:44 --> Output Class Initialized
INFO - 2016-05-11 18:37:44 --> Security Class Initialized
DEBUG - 2016-05-11 18:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:37:44 --> Input Class Initialized
INFO - 2016-05-11 18:37:44 --> Language Class Initialized
INFO - 2016-05-11 18:37:44 --> Loader Class Initialized
INFO - 2016-05-11 18:37:44 --> Helper loaded: url_helper
INFO - 2016-05-11 18:37:44 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:37:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:37:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:37:44 --> Helper loaded: form_helper
INFO - 2016-05-11 18:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:37:44 --> Form Validation Class Initialized
INFO - 2016-05-11 18:37:44 --> Controller Class Initialized
INFO - 2016-05-11 18:37:44 --> Model Class Initialized
INFO - 2016-05-11 18:37:44 --> Database Driver Class Initialized
INFO - 2016-05-11 18:37:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:37:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:37:44 --> Final output sent to browser
DEBUG - 2016-05-11 18:37:44 --> Total execution time: 0.0925
INFO - 2016-05-11 18:40:33 --> Config Class Initialized
INFO - 2016-05-11 18:40:33 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:40:33 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:40:33 --> Utf8 Class Initialized
INFO - 2016-05-11 18:40:33 --> URI Class Initialized
DEBUG - 2016-05-11 18:40:33 --> No URI present. Default controller set.
INFO - 2016-05-11 18:40:33 --> Router Class Initialized
INFO - 2016-05-11 18:40:33 --> Output Class Initialized
INFO - 2016-05-11 18:40:33 --> Security Class Initialized
DEBUG - 2016-05-11 18:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:40:33 --> Input Class Initialized
INFO - 2016-05-11 18:40:33 --> Language Class Initialized
INFO - 2016-05-11 18:40:33 --> Loader Class Initialized
INFO - 2016-05-11 18:40:33 --> Helper loaded: url_helper
INFO - 2016-05-11 18:40:33 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:40:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:40:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:40:33 --> Helper loaded: form_helper
INFO - 2016-05-11 18:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:40:33 --> Form Validation Class Initialized
INFO - 2016-05-11 18:40:33 --> Controller Class Initialized
INFO - 2016-05-11 18:40:33 --> Model Class Initialized
INFO - 2016-05-11 18:40:33 --> Database Driver Class Initialized
INFO - 2016-05-11 18:40:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:40:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:40:33 --> Final output sent to browser
DEBUG - 2016-05-11 18:40:33 --> Total execution time: 0.1485
INFO - 2016-05-11 18:42:13 --> Config Class Initialized
INFO - 2016-05-11 18:42:13 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:42:13 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:42:13 --> Utf8 Class Initialized
INFO - 2016-05-11 18:42:13 --> URI Class Initialized
DEBUG - 2016-05-11 18:42:13 --> No URI present. Default controller set.
INFO - 2016-05-11 18:42:13 --> Router Class Initialized
INFO - 2016-05-11 18:42:13 --> Output Class Initialized
INFO - 2016-05-11 18:42:13 --> Security Class Initialized
DEBUG - 2016-05-11 18:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:42:13 --> Input Class Initialized
INFO - 2016-05-11 18:42:13 --> Language Class Initialized
INFO - 2016-05-11 18:42:13 --> Loader Class Initialized
INFO - 2016-05-11 18:42:13 --> Helper loaded: url_helper
INFO - 2016-05-11 18:42:13 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:42:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:42:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:42:13 --> Helper loaded: form_helper
INFO - 2016-05-11 18:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:42:13 --> Form Validation Class Initialized
INFO - 2016-05-11 18:42:13 --> Controller Class Initialized
INFO - 2016-05-11 18:42:13 --> Model Class Initialized
INFO - 2016-05-11 18:42:13 --> Database Driver Class Initialized
INFO - 2016-05-11 18:42:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:42:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:42:14 --> Final output sent to browser
DEBUG - 2016-05-11 18:42:14 --> Total execution time: 0.1436
INFO - 2016-05-11 18:44:11 --> Config Class Initialized
INFO - 2016-05-11 18:44:11 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:44:11 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:44:11 --> Utf8 Class Initialized
INFO - 2016-05-11 18:44:11 --> URI Class Initialized
DEBUG - 2016-05-11 18:44:11 --> No URI present. Default controller set.
INFO - 2016-05-11 18:44:11 --> Router Class Initialized
INFO - 2016-05-11 18:44:11 --> Output Class Initialized
INFO - 2016-05-11 18:44:11 --> Security Class Initialized
DEBUG - 2016-05-11 18:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:44:11 --> Input Class Initialized
INFO - 2016-05-11 18:44:11 --> Language Class Initialized
INFO - 2016-05-11 18:44:11 --> Loader Class Initialized
INFO - 2016-05-11 18:44:11 --> Helper loaded: url_helper
INFO - 2016-05-11 18:44:11 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:44:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:44:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:44:11 --> Helper loaded: form_helper
INFO - 2016-05-11 18:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:44:11 --> Form Validation Class Initialized
INFO - 2016-05-11 18:44:11 --> Controller Class Initialized
INFO - 2016-05-11 18:44:11 --> Model Class Initialized
INFO - 2016-05-11 18:44:12 --> Database Driver Class Initialized
INFO - 2016-05-11 18:44:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:44:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:44:12 --> Final output sent to browser
DEBUG - 2016-05-11 18:44:12 --> Total execution time: 0.1942
INFO - 2016-05-11 18:44:13 --> Config Class Initialized
INFO - 2016-05-11 18:44:13 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:44:13 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:44:13 --> Utf8 Class Initialized
INFO - 2016-05-11 18:44:13 --> URI Class Initialized
DEBUG - 2016-05-11 18:44:13 --> No URI present. Default controller set.
INFO - 2016-05-11 18:44:13 --> Router Class Initialized
INFO - 2016-05-11 18:44:13 --> Output Class Initialized
INFO - 2016-05-11 18:44:13 --> Security Class Initialized
DEBUG - 2016-05-11 18:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:44:13 --> Input Class Initialized
INFO - 2016-05-11 18:44:13 --> Language Class Initialized
INFO - 2016-05-11 18:44:13 --> Loader Class Initialized
INFO - 2016-05-11 18:44:13 --> Helper loaded: url_helper
INFO - 2016-05-11 18:44:13 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:44:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:44:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:44:13 --> Helper loaded: form_helper
INFO - 2016-05-11 18:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:44:13 --> Form Validation Class Initialized
INFO - 2016-05-11 18:44:13 --> Controller Class Initialized
INFO - 2016-05-11 18:44:13 --> Model Class Initialized
INFO - 2016-05-11 18:44:13 --> Database Driver Class Initialized
INFO - 2016-05-11 18:44:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:44:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:44:13 --> Final output sent to browser
DEBUG - 2016-05-11 18:44:13 --> Total execution time: 0.0798
INFO - 2016-05-11 18:46:59 --> Config Class Initialized
INFO - 2016-05-11 18:46:59 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:46:59 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:46:59 --> Utf8 Class Initialized
INFO - 2016-05-11 18:46:59 --> URI Class Initialized
DEBUG - 2016-05-11 18:46:59 --> No URI present. Default controller set.
INFO - 2016-05-11 18:46:59 --> Router Class Initialized
INFO - 2016-05-11 18:46:59 --> Output Class Initialized
INFO - 2016-05-11 18:46:59 --> Security Class Initialized
DEBUG - 2016-05-11 18:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:46:59 --> Input Class Initialized
INFO - 2016-05-11 18:46:59 --> Language Class Initialized
INFO - 2016-05-11 18:46:59 --> Loader Class Initialized
INFO - 2016-05-11 18:46:59 --> Helper loaded: url_helper
INFO - 2016-05-11 18:46:59 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:46:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:46:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:46:59 --> Helper loaded: form_helper
INFO - 2016-05-11 18:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:46:59 --> Form Validation Class Initialized
INFO - 2016-05-11 18:46:59 --> Controller Class Initialized
INFO - 2016-05-11 18:46:59 --> Model Class Initialized
INFO - 2016-05-11 18:46:59 --> Database Driver Class Initialized
INFO - 2016-05-11 18:46:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:46:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:46:59 --> Final output sent to browser
DEBUG - 2016-05-11 18:46:59 --> Total execution time: 0.2236
INFO - 2016-05-11 18:49:59 --> Config Class Initialized
INFO - 2016-05-11 18:49:59 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:49:59 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:49:59 --> Utf8 Class Initialized
INFO - 2016-05-11 18:49:59 --> URI Class Initialized
DEBUG - 2016-05-11 18:49:59 --> No URI present. Default controller set.
INFO - 2016-05-11 18:49:59 --> Router Class Initialized
INFO - 2016-05-11 18:49:59 --> Output Class Initialized
INFO - 2016-05-11 18:49:59 --> Security Class Initialized
DEBUG - 2016-05-11 18:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:49:59 --> Input Class Initialized
INFO - 2016-05-11 18:49:59 --> Language Class Initialized
INFO - 2016-05-11 18:49:59 --> Loader Class Initialized
INFO - 2016-05-11 18:49:59 --> Helper loaded: url_helper
INFO - 2016-05-11 18:49:59 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:49:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:49:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:49:59 --> Helper loaded: form_helper
INFO - 2016-05-11 18:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:49:59 --> Form Validation Class Initialized
INFO - 2016-05-11 18:49:59 --> Controller Class Initialized
INFO - 2016-05-11 18:49:59 --> Model Class Initialized
INFO - 2016-05-11 18:49:59 --> Database Driver Class Initialized
INFO - 2016-05-11 18:49:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:49:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:49:59 --> Final output sent to browser
DEBUG - 2016-05-11 18:49:59 --> Total execution time: 0.0724
INFO - 2016-05-11 18:50:15 --> Config Class Initialized
INFO - 2016-05-11 18:50:15 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:50:15 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:50:15 --> Utf8 Class Initialized
INFO - 2016-05-11 18:50:15 --> URI Class Initialized
DEBUG - 2016-05-11 18:50:15 --> No URI present. Default controller set.
INFO - 2016-05-11 18:50:15 --> Router Class Initialized
INFO - 2016-05-11 18:50:15 --> Output Class Initialized
INFO - 2016-05-11 18:50:15 --> Security Class Initialized
DEBUG - 2016-05-11 18:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:50:15 --> Input Class Initialized
INFO - 2016-05-11 18:50:15 --> Language Class Initialized
INFO - 2016-05-11 18:50:15 --> Loader Class Initialized
INFO - 2016-05-11 18:50:15 --> Helper loaded: url_helper
INFO - 2016-05-11 18:50:15 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:50:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:50:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:50:15 --> Helper loaded: form_helper
INFO - 2016-05-11 18:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:50:15 --> Form Validation Class Initialized
INFO - 2016-05-11 18:50:15 --> Controller Class Initialized
INFO - 2016-05-11 18:50:15 --> Model Class Initialized
INFO - 2016-05-11 18:50:15 --> Database Driver Class Initialized
INFO - 2016-05-11 18:50:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:50:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:50:15 --> Final output sent to browser
DEBUG - 2016-05-11 18:50:15 --> Total execution time: 0.0758
INFO - 2016-05-11 18:50:53 --> Config Class Initialized
INFO - 2016-05-11 18:50:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:50:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:50:53 --> Utf8 Class Initialized
INFO - 2016-05-11 18:50:53 --> URI Class Initialized
DEBUG - 2016-05-11 18:50:53 --> No URI present. Default controller set.
INFO - 2016-05-11 18:50:53 --> Router Class Initialized
INFO - 2016-05-11 18:50:53 --> Output Class Initialized
INFO - 2016-05-11 18:50:53 --> Security Class Initialized
DEBUG - 2016-05-11 18:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:50:53 --> Input Class Initialized
INFO - 2016-05-11 18:50:53 --> Language Class Initialized
INFO - 2016-05-11 18:50:53 --> Loader Class Initialized
INFO - 2016-05-11 18:50:53 --> Helper loaded: url_helper
INFO - 2016-05-11 18:50:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:50:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:50:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:50:53 --> Helper loaded: form_helper
INFO - 2016-05-11 18:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:50:53 --> Form Validation Class Initialized
INFO - 2016-05-11 18:50:53 --> Controller Class Initialized
INFO - 2016-05-11 18:50:53 --> Model Class Initialized
INFO - 2016-05-11 18:50:53 --> Database Driver Class Initialized
INFO - 2016-05-11 18:50:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:50:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:50:53 --> Final output sent to browser
DEBUG - 2016-05-11 18:50:53 --> Total execution time: 0.0749
INFO - 2016-05-11 18:51:23 --> Config Class Initialized
INFO - 2016-05-11 18:51:23 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:51:23 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:51:23 --> Utf8 Class Initialized
INFO - 2016-05-11 18:51:23 --> URI Class Initialized
DEBUG - 2016-05-11 18:51:23 --> No URI present. Default controller set.
INFO - 2016-05-11 18:51:23 --> Router Class Initialized
INFO - 2016-05-11 18:51:23 --> Output Class Initialized
INFO - 2016-05-11 18:51:23 --> Security Class Initialized
DEBUG - 2016-05-11 18:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:51:23 --> Input Class Initialized
INFO - 2016-05-11 18:51:23 --> Language Class Initialized
INFO - 2016-05-11 18:51:23 --> Loader Class Initialized
INFO - 2016-05-11 18:51:23 --> Helper loaded: url_helper
INFO - 2016-05-11 18:51:23 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:51:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:51:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:51:23 --> Helper loaded: form_helper
INFO - 2016-05-11 18:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:51:23 --> Form Validation Class Initialized
INFO - 2016-05-11 18:51:23 --> Controller Class Initialized
INFO - 2016-05-11 18:51:23 --> Model Class Initialized
INFO - 2016-05-11 18:51:23 --> Database Driver Class Initialized
INFO - 2016-05-11 18:51:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:51:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:51:23 --> Final output sent to browser
DEBUG - 2016-05-11 18:51:23 --> Total execution time: 0.0740
INFO - 2016-05-11 18:51:27 --> Config Class Initialized
INFO - 2016-05-11 18:51:27 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:51:27 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:51:27 --> Utf8 Class Initialized
INFO - 2016-05-11 18:51:27 --> URI Class Initialized
DEBUG - 2016-05-11 18:51:27 --> No URI present. Default controller set.
INFO - 2016-05-11 18:51:27 --> Router Class Initialized
INFO - 2016-05-11 18:51:27 --> Output Class Initialized
INFO - 2016-05-11 18:51:27 --> Security Class Initialized
DEBUG - 2016-05-11 18:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:51:27 --> Input Class Initialized
INFO - 2016-05-11 18:51:27 --> Language Class Initialized
INFO - 2016-05-11 18:51:27 --> Loader Class Initialized
INFO - 2016-05-11 18:51:27 --> Helper loaded: url_helper
INFO - 2016-05-11 18:51:27 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:51:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:51:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:51:27 --> Helper loaded: form_helper
INFO - 2016-05-11 18:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:51:27 --> Form Validation Class Initialized
INFO - 2016-05-11 18:51:27 --> Controller Class Initialized
INFO - 2016-05-11 18:51:27 --> Model Class Initialized
INFO - 2016-05-11 18:51:27 --> Database Driver Class Initialized
INFO - 2016-05-11 18:51:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:51:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:51:28 --> Final output sent to browser
DEBUG - 2016-05-11 18:51:28 --> Total execution time: 0.0759
INFO - 2016-05-11 18:52:04 --> Config Class Initialized
INFO - 2016-05-11 18:52:04 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:52:04 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:52:04 --> Utf8 Class Initialized
INFO - 2016-05-11 18:52:04 --> URI Class Initialized
DEBUG - 2016-05-11 18:52:04 --> No URI present. Default controller set.
INFO - 2016-05-11 18:52:04 --> Router Class Initialized
INFO - 2016-05-11 18:52:04 --> Output Class Initialized
INFO - 2016-05-11 18:52:04 --> Security Class Initialized
DEBUG - 2016-05-11 18:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:52:04 --> Input Class Initialized
INFO - 2016-05-11 18:52:04 --> Language Class Initialized
INFO - 2016-05-11 18:52:04 --> Loader Class Initialized
INFO - 2016-05-11 18:52:04 --> Helper loaded: url_helper
INFO - 2016-05-11 18:52:04 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:52:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:52:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:52:04 --> Helper loaded: form_helper
INFO - 2016-05-11 18:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:52:04 --> Form Validation Class Initialized
INFO - 2016-05-11 18:52:04 --> Controller Class Initialized
INFO - 2016-05-11 18:52:04 --> Model Class Initialized
INFO - 2016-05-11 18:52:04 --> Database Driver Class Initialized
INFO - 2016-05-11 18:52:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:52:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:52:05 --> Final output sent to browser
DEBUG - 2016-05-11 18:52:05 --> Total execution time: 0.0717
INFO - 2016-05-11 18:53:07 --> Config Class Initialized
INFO - 2016-05-11 18:53:07 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:53:07 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:53:07 --> Utf8 Class Initialized
INFO - 2016-05-11 18:53:07 --> URI Class Initialized
DEBUG - 2016-05-11 18:53:07 --> No URI present. Default controller set.
INFO - 2016-05-11 18:53:07 --> Router Class Initialized
INFO - 2016-05-11 18:53:07 --> Output Class Initialized
INFO - 2016-05-11 18:53:07 --> Security Class Initialized
DEBUG - 2016-05-11 18:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:53:07 --> Input Class Initialized
INFO - 2016-05-11 18:53:07 --> Language Class Initialized
INFO - 2016-05-11 18:53:07 --> Loader Class Initialized
INFO - 2016-05-11 18:53:07 --> Helper loaded: url_helper
INFO - 2016-05-11 18:53:07 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:53:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:53:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:53:07 --> Helper loaded: form_helper
INFO - 2016-05-11 18:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:53:07 --> Form Validation Class Initialized
INFO - 2016-05-11 18:53:07 --> Controller Class Initialized
INFO - 2016-05-11 18:53:07 --> Model Class Initialized
INFO - 2016-05-11 18:53:07 --> Database Driver Class Initialized
INFO - 2016-05-11 18:53:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:53:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:53:07 --> Final output sent to browser
DEBUG - 2016-05-11 18:53:07 --> Total execution time: 0.0737
INFO - 2016-05-11 18:53:17 --> Config Class Initialized
INFO - 2016-05-11 18:53:17 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:53:17 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:53:17 --> Utf8 Class Initialized
INFO - 2016-05-11 18:53:17 --> URI Class Initialized
DEBUG - 2016-05-11 18:53:17 --> No URI present. Default controller set.
INFO - 2016-05-11 18:53:17 --> Router Class Initialized
INFO - 2016-05-11 18:53:17 --> Output Class Initialized
INFO - 2016-05-11 18:53:17 --> Security Class Initialized
DEBUG - 2016-05-11 18:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:53:17 --> Input Class Initialized
INFO - 2016-05-11 18:53:17 --> Language Class Initialized
INFO - 2016-05-11 18:53:17 --> Loader Class Initialized
INFO - 2016-05-11 18:53:17 --> Helper loaded: url_helper
INFO - 2016-05-11 18:53:17 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:53:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:53:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:53:17 --> Helper loaded: form_helper
INFO - 2016-05-11 18:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:53:17 --> Form Validation Class Initialized
INFO - 2016-05-11 18:53:17 --> Controller Class Initialized
INFO - 2016-05-11 18:53:17 --> Model Class Initialized
INFO - 2016-05-11 18:53:17 --> Database Driver Class Initialized
INFO - 2016-05-11 18:53:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:53:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:53:17 --> Final output sent to browser
DEBUG - 2016-05-11 18:53:17 --> Total execution time: 0.0762
INFO - 2016-05-11 18:53:43 --> Config Class Initialized
INFO - 2016-05-11 18:53:43 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:53:43 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:53:43 --> Utf8 Class Initialized
INFO - 2016-05-11 18:53:43 --> URI Class Initialized
DEBUG - 2016-05-11 18:53:43 --> No URI present. Default controller set.
INFO - 2016-05-11 18:53:43 --> Router Class Initialized
INFO - 2016-05-11 18:53:43 --> Output Class Initialized
INFO - 2016-05-11 18:53:43 --> Security Class Initialized
DEBUG - 2016-05-11 18:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:53:43 --> Input Class Initialized
INFO - 2016-05-11 18:53:43 --> Language Class Initialized
INFO - 2016-05-11 18:53:43 --> Loader Class Initialized
INFO - 2016-05-11 18:53:43 --> Helper loaded: url_helper
INFO - 2016-05-11 18:53:43 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:53:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:53:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:53:43 --> Helper loaded: form_helper
INFO - 2016-05-11 18:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:53:43 --> Form Validation Class Initialized
INFO - 2016-05-11 18:53:43 --> Controller Class Initialized
INFO - 2016-05-11 18:53:43 --> Model Class Initialized
INFO - 2016-05-11 18:53:43 --> Database Driver Class Initialized
INFO - 2016-05-11 18:53:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:53:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:53:43 --> Final output sent to browser
DEBUG - 2016-05-11 18:53:43 --> Total execution time: 0.0758
INFO - 2016-05-11 18:55:05 --> Config Class Initialized
INFO - 2016-05-11 18:55:05 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:55:05 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:55:05 --> Utf8 Class Initialized
INFO - 2016-05-11 18:55:05 --> URI Class Initialized
DEBUG - 2016-05-11 18:55:05 --> No URI present. Default controller set.
INFO - 2016-05-11 18:55:05 --> Router Class Initialized
INFO - 2016-05-11 18:55:05 --> Output Class Initialized
INFO - 2016-05-11 18:55:05 --> Security Class Initialized
DEBUG - 2016-05-11 18:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:55:05 --> Input Class Initialized
INFO - 2016-05-11 18:55:05 --> Language Class Initialized
INFO - 2016-05-11 18:55:05 --> Loader Class Initialized
INFO - 2016-05-11 18:55:05 --> Helper loaded: url_helper
INFO - 2016-05-11 18:55:05 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:55:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:55:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:55:05 --> Helper loaded: form_helper
INFO - 2016-05-11 18:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:55:05 --> Form Validation Class Initialized
INFO - 2016-05-11 18:55:05 --> Controller Class Initialized
INFO - 2016-05-11 18:55:05 --> Model Class Initialized
INFO - 2016-05-11 18:55:05 --> Database Driver Class Initialized
INFO - 2016-05-11 18:55:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:55:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:55:05 --> Final output sent to browser
DEBUG - 2016-05-11 18:55:05 --> Total execution time: 0.0685
INFO - 2016-05-11 18:56:02 --> Config Class Initialized
INFO - 2016-05-11 18:56:02 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:56:02 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:56:02 --> Utf8 Class Initialized
INFO - 2016-05-11 18:56:02 --> URI Class Initialized
DEBUG - 2016-05-11 18:56:02 --> No URI present. Default controller set.
INFO - 2016-05-11 18:56:02 --> Router Class Initialized
INFO - 2016-05-11 18:56:02 --> Output Class Initialized
INFO - 2016-05-11 18:56:02 --> Security Class Initialized
DEBUG - 2016-05-11 18:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:56:02 --> Input Class Initialized
INFO - 2016-05-11 18:56:02 --> Language Class Initialized
INFO - 2016-05-11 18:56:02 --> Loader Class Initialized
INFO - 2016-05-11 18:56:02 --> Helper loaded: url_helper
INFO - 2016-05-11 18:56:02 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:56:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:56:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:56:02 --> Helper loaded: form_helper
INFO - 2016-05-11 18:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:56:02 --> Form Validation Class Initialized
INFO - 2016-05-11 18:56:02 --> Controller Class Initialized
INFO - 2016-05-11 18:56:02 --> Model Class Initialized
INFO - 2016-05-11 18:56:02 --> Database Driver Class Initialized
INFO - 2016-05-11 18:56:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:56:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:56:02 --> Final output sent to browser
DEBUG - 2016-05-11 18:56:02 --> Total execution time: 0.0736
INFO - 2016-05-11 18:56:45 --> Config Class Initialized
INFO - 2016-05-11 18:56:45 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:56:45 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:56:45 --> Utf8 Class Initialized
INFO - 2016-05-11 18:56:45 --> URI Class Initialized
DEBUG - 2016-05-11 18:56:45 --> No URI present. Default controller set.
INFO - 2016-05-11 18:56:45 --> Router Class Initialized
INFO - 2016-05-11 18:56:45 --> Output Class Initialized
INFO - 2016-05-11 18:56:45 --> Security Class Initialized
DEBUG - 2016-05-11 18:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:56:45 --> Input Class Initialized
INFO - 2016-05-11 18:56:45 --> Language Class Initialized
INFO - 2016-05-11 18:56:45 --> Loader Class Initialized
INFO - 2016-05-11 18:56:45 --> Helper loaded: url_helper
INFO - 2016-05-11 18:56:45 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:56:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:56:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:56:45 --> Helper loaded: form_helper
INFO - 2016-05-11 18:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:56:45 --> Form Validation Class Initialized
INFO - 2016-05-11 18:56:45 --> Controller Class Initialized
INFO - 2016-05-11 18:56:46 --> Model Class Initialized
INFO - 2016-05-11 18:56:46 --> Database Driver Class Initialized
INFO - 2016-05-11 18:56:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:56:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:56:46 --> Final output sent to browser
DEBUG - 2016-05-11 18:56:46 --> Total execution time: 0.0743
INFO - 2016-05-11 18:57:36 --> Config Class Initialized
INFO - 2016-05-11 18:57:36 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:57:36 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:57:36 --> Utf8 Class Initialized
INFO - 2016-05-11 18:57:36 --> URI Class Initialized
DEBUG - 2016-05-11 18:57:36 --> No URI present. Default controller set.
INFO - 2016-05-11 18:57:36 --> Router Class Initialized
INFO - 2016-05-11 18:57:36 --> Output Class Initialized
INFO - 2016-05-11 18:57:36 --> Security Class Initialized
DEBUG - 2016-05-11 18:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:57:36 --> Input Class Initialized
INFO - 2016-05-11 18:57:36 --> Language Class Initialized
INFO - 2016-05-11 18:57:36 --> Loader Class Initialized
INFO - 2016-05-11 18:57:36 --> Helper loaded: url_helper
INFO - 2016-05-11 18:57:36 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:57:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:57:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:57:36 --> Helper loaded: form_helper
INFO - 2016-05-11 18:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:57:36 --> Form Validation Class Initialized
INFO - 2016-05-11 18:57:36 --> Controller Class Initialized
INFO - 2016-05-11 18:57:36 --> Model Class Initialized
INFO - 2016-05-11 18:57:36 --> Database Driver Class Initialized
INFO - 2016-05-11 18:57:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:57:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:57:36 --> Final output sent to browser
DEBUG - 2016-05-11 18:57:36 --> Total execution time: 0.0717
INFO - 2016-05-11 18:58:12 --> Config Class Initialized
INFO - 2016-05-11 18:58:12 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:58:12 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:58:12 --> Utf8 Class Initialized
INFO - 2016-05-11 18:58:12 --> URI Class Initialized
DEBUG - 2016-05-11 18:58:12 --> No URI present. Default controller set.
INFO - 2016-05-11 18:58:12 --> Router Class Initialized
INFO - 2016-05-11 18:58:12 --> Output Class Initialized
INFO - 2016-05-11 18:58:12 --> Security Class Initialized
DEBUG - 2016-05-11 18:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:58:12 --> Input Class Initialized
INFO - 2016-05-11 18:58:12 --> Language Class Initialized
INFO - 2016-05-11 18:58:12 --> Loader Class Initialized
INFO - 2016-05-11 18:58:12 --> Helper loaded: url_helper
INFO - 2016-05-11 18:58:12 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:58:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:58:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:58:12 --> Helper loaded: form_helper
INFO - 2016-05-11 18:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:58:12 --> Form Validation Class Initialized
INFO - 2016-05-11 18:58:12 --> Controller Class Initialized
INFO - 2016-05-11 18:58:12 --> Model Class Initialized
INFO - 2016-05-11 18:58:12 --> Database Driver Class Initialized
INFO - 2016-05-11 18:58:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:58:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:58:12 --> Final output sent to browser
DEBUG - 2016-05-11 18:58:12 --> Total execution time: 0.0694
INFO - 2016-05-11 18:58:13 --> Config Class Initialized
INFO - 2016-05-11 18:58:13 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:58:13 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:58:13 --> Utf8 Class Initialized
INFO - 2016-05-11 18:58:13 --> URI Class Initialized
DEBUG - 2016-05-11 18:58:13 --> No URI present. Default controller set.
INFO - 2016-05-11 18:58:13 --> Router Class Initialized
INFO - 2016-05-11 18:58:13 --> Output Class Initialized
INFO - 2016-05-11 18:58:13 --> Security Class Initialized
DEBUG - 2016-05-11 18:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:58:13 --> Input Class Initialized
INFO - 2016-05-11 18:58:13 --> Language Class Initialized
INFO - 2016-05-11 18:58:13 --> Loader Class Initialized
INFO - 2016-05-11 18:58:13 --> Helper loaded: url_helper
INFO - 2016-05-11 18:58:13 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:58:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:58:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:58:13 --> Helper loaded: form_helper
INFO - 2016-05-11 18:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:58:13 --> Form Validation Class Initialized
INFO - 2016-05-11 18:58:13 --> Controller Class Initialized
INFO - 2016-05-11 18:58:13 --> Model Class Initialized
INFO - 2016-05-11 18:58:13 --> Database Driver Class Initialized
INFO - 2016-05-11 18:58:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:58:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:58:13 --> Final output sent to browser
DEBUG - 2016-05-11 18:58:13 --> Total execution time: 0.0831
INFO - 2016-05-11 18:58:27 --> Config Class Initialized
INFO - 2016-05-11 18:58:27 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:58:27 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:58:27 --> Utf8 Class Initialized
INFO - 2016-05-11 18:58:27 --> URI Class Initialized
DEBUG - 2016-05-11 18:58:27 --> No URI present. Default controller set.
INFO - 2016-05-11 18:58:27 --> Router Class Initialized
INFO - 2016-05-11 18:58:27 --> Output Class Initialized
INFO - 2016-05-11 18:58:27 --> Security Class Initialized
DEBUG - 2016-05-11 18:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:58:27 --> Input Class Initialized
INFO - 2016-05-11 18:58:27 --> Language Class Initialized
INFO - 2016-05-11 18:58:27 --> Loader Class Initialized
INFO - 2016-05-11 18:58:27 --> Helper loaded: url_helper
INFO - 2016-05-11 18:58:27 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:58:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:58:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:58:27 --> Helper loaded: form_helper
INFO - 2016-05-11 18:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:58:27 --> Form Validation Class Initialized
INFO - 2016-05-11 18:58:27 --> Controller Class Initialized
INFO - 2016-05-11 18:58:27 --> Model Class Initialized
INFO - 2016-05-11 18:58:27 --> Database Driver Class Initialized
INFO - 2016-05-11 18:58:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:58:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:58:27 --> Final output sent to browser
DEBUG - 2016-05-11 18:58:27 --> Total execution time: 0.0740
INFO - 2016-05-11 18:58:35 --> Config Class Initialized
INFO - 2016-05-11 18:58:35 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:58:35 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:58:35 --> Utf8 Class Initialized
INFO - 2016-05-11 18:58:35 --> URI Class Initialized
DEBUG - 2016-05-11 18:58:35 --> No URI present. Default controller set.
INFO - 2016-05-11 18:58:35 --> Router Class Initialized
INFO - 2016-05-11 18:58:35 --> Output Class Initialized
INFO - 2016-05-11 18:58:35 --> Security Class Initialized
DEBUG - 2016-05-11 18:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:58:35 --> Input Class Initialized
INFO - 2016-05-11 18:58:35 --> Language Class Initialized
INFO - 2016-05-11 18:58:35 --> Loader Class Initialized
INFO - 2016-05-11 18:58:35 --> Helper loaded: url_helper
INFO - 2016-05-11 18:58:35 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:58:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:58:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:58:35 --> Helper loaded: form_helper
INFO - 2016-05-11 18:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:58:35 --> Form Validation Class Initialized
INFO - 2016-05-11 18:58:35 --> Controller Class Initialized
INFO - 2016-05-11 18:58:35 --> Model Class Initialized
INFO - 2016-05-11 18:58:35 --> Database Driver Class Initialized
INFO - 2016-05-11 18:58:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:58:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:58:35 --> Final output sent to browser
DEBUG - 2016-05-11 18:58:35 --> Total execution time: 0.0716
INFO - 2016-05-11 18:58:43 --> Config Class Initialized
INFO - 2016-05-11 18:58:43 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:58:43 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:58:43 --> Utf8 Class Initialized
INFO - 2016-05-11 18:58:43 --> URI Class Initialized
DEBUG - 2016-05-11 18:58:43 --> No URI present. Default controller set.
INFO - 2016-05-11 18:58:43 --> Router Class Initialized
INFO - 2016-05-11 18:58:43 --> Output Class Initialized
INFO - 2016-05-11 18:58:43 --> Security Class Initialized
DEBUG - 2016-05-11 18:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:58:43 --> Input Class Initialized
INFO - 2016-05-11 18:58:43 --> Language Class Initialized
INFO - 2016-05-11 18:58:43 --> Loader Class Initialized
INFO - 2016-05-11 18:58:43 --> Helper loaded: url_helper
INFO - 2016-05-11 18:58:43 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:58:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:58:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:58:43 --> Helper loaded: form_helper
INFO - 2016-05-11 18:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:58:43 --> Form Validation Class Initialized
INFO - 2016-05-11 18:58:43 --> Controller Class Initialized
INFO - 2016-05-11 18:58:43 --> Model Class Initialized
INFO - 2016-05-11 18:58:43 --> Database Driver Class Initialized
INFO - 2016-05-11 18:58:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:58:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:58:43 --> Final output sent to browser
DEBUG - 2016-05-11 18:58:43 --> Total execution time: 0.0778
INFO - 2016-05-11 18:59:05 --> Config Class Initialized
INFO - 2016-05-11 18:59:05 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:59:05 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:59:05 --> Utf8 Class Initialized
INFO - 2016-05-11 18:59:05 --> URI Class Initialized
DEBUG - 2016-05-11 18:59:05 --> No URI present. Default controller set.
INFO - 2016-05-11 18:59:05 --> Router Class Initialized
INFO - 2016-05-11 18:59:05 --> Output Class Initialized
INFO - 2016-05-11 18:59:05 --> Security Class Initialized
DEBUG - 2016-05-11 18:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:59:05 --> Input Class Initialized
INFO - 2016-05-11 18:59:05 --> Language Class Initialized
INFO - 2016-05-11 18:59:05 --> Loader Class Initialized
INFO - 2016-05-11 18:59:05 --> Helper loaded: url_helper
INFO - 2016-05-11 18:59:05 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:59:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:59:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:59:05 --> Helper loaded: form_helper
INFO - 2016-05-11 18:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:59:05 --> Form Validation Class Initialized
INFO - 2016-05-11 18:59:05 --> Controller Class Initialized
INFO - 2016-05-11 18:59:05 --> Model Class Initialized
INFO - 2016-05-11 18:59:05 --> Database Driver Class Initialized
INFO - 2016-05-11 18:59:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:59:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:59:05 --> Final output sent to browser
DEBUG - 2016-05-11 18:59:05 --> Total execution time: 0.0701
INFO - 2016-05-11 18:59:13 --> Config Class Initialized
INFO - 2016-05-11 18:59:13 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:59:13 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:59:13 --> Utf8 Class Initialized
INFO - 2016-05-11 18:59:13 --> URI Class Initialized
DEBUG - 2016-05-11 18:59:13 --> No URI present. Default controller set.
INFO - 2016-05-11 18:59:13 --> Router Class Initialized
INFO - 2016-05-11 18:59:13 --> Output Class Initialized
INFO - 2016-05-11 18:59:13 --> Security Class Initialized
DEBUG - 2016-05-11 18:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:59:13 --> Input Class Initialized
INFO - 2016-05-11 18:59:13 --> Language Class Initialized
INFO - 2016-05-11 18:59:13 --> Loader Class Initialized
INFO - 2016-05-11 18:59:13 --> Helper loaded: url_helper
INFO - 2016-05-11 18:59:13 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:59:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:59:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:59:13 --> Helper loaded: form_helper
INFO - 2016-05-11 18:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:59:13 --> Form Validation Class Initialized
INFO - 2016-05-11 18:59:13 --> Controller Class Initialized
INFO - 2016-05-11 18:59:13 --> Model Class Initialized
INFO - 2016-05-11 18:59:13 --> Database Driver Class Initialized
INFO - 2016-05-11 18:59:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:59:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:59:13 --> Final output sent to browser
DEBUG - 2016-05-11 18:59:13 --> Total execution time: 0.0747
INFO - 2016-05-11 18:59:14 --> Config Class Initialized
INFO - 2016-05-11 18:59:14 --> Hooks Class Initialized
DEBUG - 2016-05-11 18:59:14 --> UTF-8 Support Enabled
INFO - 2016-05-11 18:59:14 --> Utf8 Class Initialized
INFO - 2016-05-11 18:59:14 --> URI Class Initialized
DEBUG - 2016-05-11 18:59:14 --> No URI present. Default controller set.
INFO - 2016-05-11 18:59:14 --> Router Class Initialized
INFO - 2016-05-11 18:59:14 --> Output Class Initialized
INFO - 2016-05-11 18:59:14 --> Security Class Initialized
DEBUG - 2016-05-11 18:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 18:59:14 --> Input Class Initialized
INFO - 2016-05-11 18:59:14 --> Language Class Initialized
INFO - 2016-05-11 18:59:14 --> Loader Class Initialized
INFO - 2016-05-11 18:59:14 --> Helper loaded: url_helper
INFO - 2016-05-11 18:59:14 --> Helper loaded: sesion_helper
INFO - 2016-05-11 18:59:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 18:59:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 18:59:14 --> Helper loaded: form_helper
INFO - 2016-05-11 18:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 18:59:14 --> Form Validation Class Initialized
INFO - 2016-05-11 18:59:14 --> Controller Class Initialized
INFO - 2016-05-11 18:59:14 --> Model Class Initialized
INFO - 2016-05-11 18:59:14 --> Database Driver Class Initialized
INFO - 2016-05-11 18:59:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 18:59:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 18:59:14 --> Final output sent to browser
DEBUG - 2016-05-11 18:59:14 --> Total execution time: 0.0852
INFO - 2016-05-11 19:00:42 --> Config Class Initialized
INFO - 2016-05-11 19:00:42 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:00:42 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:00:42 --> Utf8 Class Initialized
INFO - 2016-05-11 19:00:42 --> URI Class Initialized
INFO - 2016-05-11 19:00:42 --> Router Class Initialized
INFO - 2016-05-11 19:00:42 --> Output Class Initialized
INFO - 2016-05-11 19:00:42 --> Security Class Initialized
DEBUG - 2016-05-11 19:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:00:42 --> Input Class Initialized
INFO - 2016-05-11 19:00:43 --> Language Class Initialized
INFO - 2016-05-11 19:00:43 --> Loader Class Initialized
INFO - 2016-05-11 19:00:43 --> Helper loaded: url_helper
INFO - 2016-05-11 19:00:43 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:00:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:00:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:00:43 --> Helper loaded: form_helper
INFO - 2016-05-11 19:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:00:43 --> Form Validation Class Initialized
INFO - 2016-05-11 19:00:43 --> Controller Class Initialized
INFO - 2016-05-11 19:00:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-11 19:00:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 19:00:43 --> Final output sent to browser
DEBUG - 2016-05-11 19:00:43 --> Total execution time: 0.0524
INFO - 2016-05-11 19:00:43 --> Config Class Initialized
INFO - 2016-05-11 19:00:43 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:00:43 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:00:43 --> Utf8 Class Initialized
INFO - 2016-05-11 19:00:43 --> URI Class Initialized
INFO - 2016-05-11 19:00:43 --> Router Class Initialized
INFO - 2016-05-11 19:00:43 --> Output Class Initialized
INFO - 2016-05-11 19:00:43 --> Security Class Initialized
DEBUG - 2016-05-11 19:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:00:43 --> Input Class Initialized
INFO - 2016-05-11 19:00:43 --> Language Class Initialized
INFO - 2016-05-11 19:00:43 --> Loader Class Initialized
INFO - 2016-05-11 19:00:43 --> Helper loaded: url_helper
INFO - 2016-05-11 19:00:43 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:00:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:00:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:00:43 --> Helper loaded: form_helper
INFO - 2016-05-11 19:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:00:43 --> Form Validation Class Initialized
INFO - 2016-05-11 19:00:43 --> Controller Class Initialized
INFO - 2016-05-11 19:00:43 --> Model Class Initialized
INFO - 2016-05-11 19:00:43 --> Database Driver Class Initialized
INFO - 2016-05-11 19:00:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:00:43 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:00:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:00:43 --> Final output sent to browser
DEBUG - 2016-05-11 19:00:43 --> Total execution time: 0.0876
INFO - 2016-05-11 19:01:43 --> Config Class Initialized
INFO - 2016-05-11 19:01:43 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:01:43 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:01:43 --> Utf8 Class Initialized
INFO - 2016-05-11 19:01:43 --> URI Class Initialized
INFO - 2016-05-11 19:01:43 --> Router Class Initialized
INFO - 2016-05-11 19:01:43 --> Output Class Initialized
INFO - 2016-05-11 19:01:43 --> Security Class Initialized
DEBUG - 2016-05-11 19:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:01:43 --> Input Class Initialized
INFO - 2016-05-11 19:01:43 --> Language Class Initialized
INFO - 2016-05-11 19:01:43 --> Loader Class Initialized
INFO - 2016-05-11 19:01:43 --> Helper loaded: url_helper
INFO - 2016-05-11 19:01:43 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:01:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:01:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:01:44 --> Helper loaded: form_helper
INFO - 2016-05-11 19:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:01:44 --> Form Validation Class Initialized
INFO - 2016-05-11 19:01:44 --> Controller Class Initialized
INFO - 2016-05-11 19:01:44 --> Model Class Initialized
INFO - 2016-05-11 19:01:44 --> Database Driver Class Initialized
INFO - 2016-05-11 19:01:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:01:44 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:01:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:01:44 --> Final output sent to browser
DEBUG - 2016-05-11 19:01:44 --> Total execution time: 0.0845
INFO - 2016-05-11 19:02:36 --> Config Class Initialized
INFO - 2016-05-11 19:02:36 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:02:36 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:02:36 --> Utf8 Class Initialized
INFO - 2016-05-11 19:02:36 --> URI Class Initialized
DEBUG - 2016-05-11 19:02:36 --> No URI present. Default controller set.
INFO - 2016-05-11 19:02:36 --> Router Class Initialized
INFO - 2016-05-11 19:02:36 --> Output Class Initialized
INFO - 2016-05-11 19:02:36 --> Security Class Initialized
DEBUG - 2016-05-11 19:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:02:36 --> Input Class Initialized
INFO - 2016-05-11 19:02:36 --> Language Class Initialized
INFO - 2016-05-11 19:02:36 --> Loader Class Initialized
INFO - 2016-05-11 19:02:36 --> Helper loaded: url_helper
INFO - 2016-05-11 19:02:36 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:02:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:02:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:02:36 --> Helper loaded: form_helper
INFO - 2016-05-11 19:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:02:36 --> Form Validation Class Initialized
INFO - 2016-05-11 19:02:36 --> Controller Class Initialized
INFO - 2016-05-11 19:02:36 --> Model Class Initialized
INFO - 2016-05-11 19:02:37 --> Database Driver Class Initialized
INFO - 2016-05-11 19:02:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:02:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:02:37 --> Final output sent to browser
DEBUG - 2016-05-11 19:02:37 --> Total execution time: 0.0987
INFO - 2016-05-11 19:02:39 --> Config Class Initialized
INFO - 2016-05-11 19:02:39 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:02:39 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:02:39 --> Utf8 Class Initialized
INFO - 2016-05-11 19:02:39 --> URI Class Initialized
DEBUG - 2016-05-11 19:02:39 --> No URI present. Default controller set.
INFO - 2016-05-11 19:02:39 --> Router Class Initialized
INFO - 2016-05-11 19:02:39 --> Output Class Initialized
INFO - 2016-05-11 19:02:39 --> Security Class Initialized
DEBUG - 2016-05-11 19:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:02:39 --> Input Class Initialized
INFO - 2016-05-11 19:02:39 --> Language Class Initialized
INFO - 2016-05-11 19:02:39 --> Loader Class Initialized
INFO - 2016-05-11 19:02:39 --> Helper loaded: url_helper
INFO - 2016-05-11 19:02:39 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:02:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:02:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:02:39 --> Helper loaded: form_helper
INFO - 2016-05-11 19:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:02:39 --> Form Validation Class Initialized
INFO - 2016-05-11 19:02:39 --> Controller Class Initialized
INFO - 2016-05-11 19:02:39 --> Model Class Initialized
INFO - 2016-05-11 19:02:39 --> Database Driver Class Initialized
INFO - 2016-05-11 19:02:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:02:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:02:39 --> Final output sent to browser
DEBUG - 2016-05-11 19:02:39 --> Total execution time: 0.0884
INFO - 2016-05-11 19:02:43 --> Config Class Initialized
INFO - 2016-05-11 19:02:43 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:02:43 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:02:43 --> Utf8 Class Initialized
INFO - 2016-05-11 19:02:43 --> URI Class Initialized
INFO - 2016-05-11 19:02:43 --> Router Class Initialized
INFO - 2016-05-11 19:02:43 --> Output Class Initialized
INFO - 2016-05-11 19:02:43 --> Security Class Initialized
DEBUG - 2016-05-11 19:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:02:43 --> Input Class Initialized
INFO - 2016-05-11 19:02:43 --> Language Class Initialized
INFO - 2016-05-11 19:02:43 --> Loader Class Initialized
INFO - 2016-05-11 19:02:43 --> Helper loaded: url_helper
INFO - 2016-05-11 19:02:43 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:02:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:02:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:02:44 --> Helper loaded: form_helper
INFO - 2016-05-11 19:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:02:44 --> Form Validation Class Initialized
INFO - 2016-05-11 19:02:44 --> Controller Class Initialized
INFO - 2016-05-11 19:02:44 --> Model Class Initialized
INFO - 2016-05-11 19:02:44 --> Database Driver Class Initialized
INFO - 2016-05-11 19:02:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:02:44 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:02:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:02:44 --> Final output sent to browser
DEBUG - 2016-05-11 19:02:44 --> Total execution time: 0.0757
INFO - 2016-05-11 19:03:43 --> Config Class Initialized
INFO - 2016-05-11 19:03:44 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:03:44 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:03:44 --> Utf8 Class Initialized
INFO - 2016-05-11 19:03:44 --> URI Class Initialized
INFO - 2016-05-11 19:03:44 --> Router Class Initialized
INFO - 2016-05-11 19:03:44 --> Output Class Initialized
INFO - 2016-05-11 19:03:44 --> Security Class Initialized
DEBUG - 2016-05-11 19:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:03:44 --> Input Class Initialized
INFO - 2016-05-11 19:03:44 --> Language Class Initialized
INFO - 2016-05-11 19:03:44 --> Loader Class Initialized
INFO - 2016-05-11 19:03:44 --> Helper loaded: url_helper
INFO - 2016-05-11 19:03:44 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:03:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:03:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:03:44 --> Helper loaded: form_helper
INFO - 2016-05-11 19:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:03:44 --> Form Validation Class Initialized
INFO - 2016-05-11 19:03:44 --> Controller Class Initialized
INFO - 2016-05-11 19:03:44 --> Model Class Initialized
INFO - 2016-05-11 19:03:44 --> Database Driver Class Initialized
INFO - 2016-05-11 19:03:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:03:44 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:03:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:03:44 --> Final output sent to browser
DEBUG - 2016-05-11 19:03:44 --> Total execution time: 0.0917
INFO - 2016-05-11 19:04:37 --> Config Class Initialized
INFO - 2016-05-11 19:04:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:04:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:04:37 --> Utf8 Class Initialized
INFO - 2016-05-11 19:04:37 --> URI Class Initialized
DEBUG - 2016-05-11 19:04:37 --> No URI present. Default controller set.
INFO - 2016-05-11 19:04:37 --> Router Class Initialized
INFO - 2016-05-11 19:04:37 --> Output Class Initialized
INFO - 2016-05-11 19:04:37 --> Security Class Initialized
DEBUG - 2016-05-11 19:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:04:37 --> Input Class Initialized
INFO - 2016-05-11 19:04:37 --> Language Class Initialized
INFO - 2016-05-11 19:04:37 --> Loader Class Initialized
INFO - 2016-05-11 19:04:37 --> Helper loaded: url_helper
INFO - 2016-05-11 19:04:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:04:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:04:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:04:37 --> Helper loaded: form_helper
INFO - 2016-05-11 19:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:04:37 --> Form Validation Class Initialized
INFO - 2016-05-11 19:04:37 --> Controller Class Initialized
INFO - 2016-05-11 19:04:37 --> Model Class Initialized
INFO - 2016-05-11 19:04:37 --> Database Driver Class Initialized
INFO - 2016-05-11 19:04:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:04:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:04:37 --> Final output sent to browser
DEBUG - 2016-05-11 19:04:37 --> Total execution time: 0.0768
INFO - 2016-05-11 19:04:43 --> Config Class Initialized
INFO - 2016-05-11 19:04:43 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:04:43 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:04:43 --> Utf8 Class Initialized
INFO - 2016-05-11 19:04:43 --> URI Class Initialized
INFO - 2016-05-11 19:04:43 --> Router Class Initialized
INFO - 2016-05-11 19:04:43 --> Output Class Initialized
INFO - 2016-05-11 19:04:43 --> Security Class Initialized
DEBUG - 2016-05-11 19:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:04:43 --> Input Class Initialized
INFO - 2016-05-11 19:04:43 --> Language Class Initialized
INFO - 2016-05-11 19:04:43 --> Loader Class Initialized
INFO - 2016-05-11 19:04:43 --> Helper loaded: url_helper
INFO - 2016-05-11 19:04:43 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:04:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:04:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:04:44 --> Helper loaded: form_helper
INFO - 2016-05-11 19:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:04:44 --> Form Validation Class Initialized
INFO - 2016-05-11 19:04:44 --> Controller Class Initialized
INFO - 2016-05-11 19:04:44 --> Model Class Initialized
INFO - 2016-05-11 19:04:44 --> Database Driver Class Initialized
INFO - 2016-05-11 19:04:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:04:44 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:04:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:04:44 --> Final output sent to browser
DEBUG - 2016-05-11 19:04:44 --> Total execution time: 0.0726
INFO - 2016-05-11 19:05:43 --> Config Class Initialized
INFO - 2016-05-11 19:05:43 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:05:43 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:05:43 --> Utf8 Class Initialized
INFO - 2016-05-11 19:05:43 --> URI Class Initialized
INFO - 2016-05-11 19:05:43 --> Router Class Initialized
INFO - 2016-05-11 19:05:43 --> Output Class Initialized
INFO - 2016-05-11 19:05:43 --> Security Class Initialized
DEBUG - 2016-05-11 19:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:05:43 --> Input Class Initialized
INFO - 2016-05-11 19:05:43 --> Language Class Initialized
INFO - 2016-05-11 19:05:43 --> Loader Class Initialized
INFO - 2016-05-11 19:05:43 --> Helper loaded: url_helper
INFO - 2016-05-11 19:05:43 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:05:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:05:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:05:43 --> Helper loaded: form_helper
INFO - 2016-05-11 19:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:05:43 --> Form Validation Class Initialized
INFO - 2016-05-11 19:05:44 --> Controller Class Initialized
INFO - 2016-05-11 19:05:44 --> Model Class Initialized
INFO - 2016-05-11 19:05:44 --> Database Driver Class Initialized
INFO - 2016-05-11 19:05:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:05:44 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:05:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:05:44 --> Final output sent to browser
DEBUG - 2016-05-11 19:05:44 --> Total execution time: 0.0888
INFO - 2016-05-11 19:06:41 --> Config Class Initialized
INFO - 2016-05-11 19:06:41 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:06:41 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:06:41 --> Utf8 Class Initialized
INFO - 2016-05-11 19:06:41 --> URI Class Initialized
DEBUG - 2016-05-11 19:06:41 --> No URI present. Default controller set.
INFO - 2016-05-11 19:06:41 --> Router Class Initialized
INFO - 2016-05-11 19:06:41 --> Output Class Initialized
INFO - 2016-05-11 19:06:41 --> Security Class Initialized
DEBUG - 2016-05-11 19:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:06:41 --> Input Class Initialized
INFO - 2016-05-11 19:06:41 --> Language Class Initialized
INFO - 2016-05-11 19:06:41 --> Loader Class Initialized
INFO - 2016-05-11 19:06:41 --> Helper loaded: url_helper
INFO - 2016-05-11 19:06:41 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:06:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:06:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:06:41 --> Helper loaded: form_helper
INFO - 2016-05-11 19:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:06:41 --> Form Validation Class Initialized
INFO - 2016-05-11 19:06:41 --> Controller Class Initialized
INFO - 2016-05-11 19:06:41 --> Model Class Initialized
INFO - 2016-05-11 19:06:41 --> Database Driver Class Initialized
INFO - 2016-05-11 19:06:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:06:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:06:41 --> Final output sent to browser
DEBUG - 2016-05-11 19:06:41 --> Total execution time: 0.0830
INFO - 2016-05-11 19:06:43 --> Config Class Initialized
INFO - 2016-05-11 19:06:43 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:06:43 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:06:43 --> Utf8 Class Initialized
INFO - 2016-05-11 19:06:43 --> URI Class Initialized
INFO - 2016-05-11 19:06:43 --> Router Class Initialized
INFO - 2016-05-11 19:06:43 --> Output Class Initialized
INFO - 2016-05-11 19:06:43 --> Security Class Initialized
DEBUG - 2016-05-11 19:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:06:43 --> Input Class Initialized
INFO - 2016-05-11 19:06:43 --> Language Class Initialized
INFO - 2016-05-11 19:06:43 --> Loader Class Initialized
INFO - 2016-05-11 19:06:43 --> Helper loaded: url_helper
INFO - 2016-05-11 19:06:43 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:06:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:06:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:06:43 --> Helper loaded: form_helper
INFO - 2016-05-11 19:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:06:43 --> Form Validation Class Initialized
INFO - 2016-05-11 19:06:43 --> Controller Class Initialized
INFO - 2016-05-11 19:06:43 --> Model Class Initialized
INFO - 2016-05-11 19:06:43 --> Database Driver Class Initialized
INFO - 2016-05-11 19:06:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:06:43 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:06:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:06:44 --> Final output sent to browser
DEBUG - 2016-05-11 19:06:44 --> Total execution time: 0.1428
INFO - 2016-05-11 19:07:25 --> Config Class Initialized
INFO - 2016-05-11 19:07:25 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:07:25 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:07:25 --> Utf8 Class Initialized
INFO - 2016-05-11 19:07:25 --> URI Class Initialized
DEBUG - 2016-05-11 19:07:25 --> No URI present. Default controller set.
INFO - 2016-05-11 19:07:25 --> Router Class Initialized
INFO - 2016-05-11 19:07:25 --> Output Class Initialized
INFO - 2016-05-11 19:07:25 --> Security Class Initialized
DEBUG - 2016-05-11 19:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:07:25 --> Input Class Initialized
INFO - 2016-05-11 19:07:25 --> Language Class Initialized
INFO - 2016-05-11 19:07:25 --> Loader Class Initialized
INFO - 2016-05-11 19:07:25 --> Helper loaded: url_helper
INFO - 2016-05-11 19:07:25 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:07:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:07:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:07:25 --> Helper loaded: form_helper
INFO - 2016-05-11 19:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:07:25 --> Form Validation Class Initialized
INFO - 2016-05-11 19:07:25 --> Controller Class Initialized
INFO - 2016-05-11 19:07:25 --> Model Class Initialized
INFO - 2016-05-11 19:07:25 --> Database Driver Class Initialized
INFO - 2016-05-11 19:07:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:07:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:07:25 --> Final output sent to browser
DEBUG - 2016-05-11 19:07:25 --> Total execution time: 0.0770
INFO - 2016-05-11 19:09:37 --> Config Class Initialized
INFO - 2016-05-11 19:09:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:09:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:09:37 --> Utf8 Class Initialized
INFO - 2016-05-11 19:09:37 --> URI Class Initialized
DEBUG - 2016-05-11 19:09:37 --> No URI present. Default controller set.
INFO - 2016-05-11 19:09:37 --> Router Class Initialized
INFO - 2016-05-11 19:09:37 --> Output Class Initialized
INFO - 2016-05-11 19:09:37 --> Security Class Initialized
DEBUG - 2016-05-11 19:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:09:37 --> Input Class Initialized
INFO - 2016-05-11 19:09:37 --> Language Class Initialized
INFO - 2016-05-11 19:09:37 --> Loader Class Initialized
INFO - 2016-05-11 19:09:37 --> Helper loaded: url_helper
INFO - 2016-05-11 19:09:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:09:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:09:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:09:37 --> Helper loaded: form_helper
INFO - 2016-05-11 19:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:09:37 --> Form Validation Class Initialized
INFO - 2016-05-11 19:09:37 --> Controller Class Initialized
INFO - 2016-05-11 19:09:37 --> Model Class Initialized
INFO - 2016-05-11 19:09:37 --> Database Driver Class Initialized
INFO - 2016-05-11 19:09:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:09:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:09:37 --> Final output sent to browser
DEBUG - 2016-05-11 19:09:37 --> Total execution time: 0.0781
INFO - 2016-05-11 19:13:48 --> Config Class Initialized
INFO - 2016-05-11 19:13:48 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:13:48 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:13:48 --> Utf8 Class Initialized
INFO - 2016-05-11 19:13:48 --> URI Class Initialized
DEBUG - 2016-05-11 19:13:48 --> No URI present. Default controller set.
INFO - 2016-05-11 19:13:48 --> Router Class Initialized
INFO - 2016-05-11 19:13:48 --> Output Class Initialized
INFO - 2016-05-11 19:13:48 --> Security Class Initialized
DEBUG - 2016-05-11 19:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:13:48 --> Input Class Initialized
INFO - 2016-05-11 19:13:48 --> Language Class Initialized
INFO - 2016-05-11 19:13:48 --> Loader Class Initialized
INFO - 2016-05-11 19:13:48 --> Helper loaded: url_helper
INFO - 2016-05-11 19:13:48 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:13:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:13:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:13:48 --> Helper loaded: form_helper
INFO - 2016-05-11 19:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:13:48 --> Form Validation Class Initialized
INFO - 2016-05-11 19:13:48 --> Controller Class Initialized
INFO - 2016-05-11 19:13:48 --> Model Class Initialized
INFO - 2016-05-11 19:13:48 --> Database Driver Class Initialized
INFO - 2016-05-11 19:13:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:13:48 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:13:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:13:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:13:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:13:48 --> Final output sent to browser
DEBUG - 2016-05-11 19:13:48 --> Total execution time: 0.1058
INFO - 2016-05-11 19:14:35 --> Config Class Initialized
INFO - 2016-05-11 19:14:35 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:14:35 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:14:35 --> Utf8 Class Initialized
INFO - 2016-05-11 19:14:35 --> URI Class Initialized
DEBUG - 2016-05-11 19:14:35 --> No URI present. Default controller set.
INFO - 2016-05-11 19:14:35 --> Router Class Initialized
INFO - 2016-05-11 19:14:35 --> Output Class Initialized
INFO - 2016-05-11 19:14:35 --> Security Class Initialized
DEBUG - 2016-05-11 19:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:14:35 --> Input Class Initialized
INFO - 2016-05-11 19:14:35 --> Language Class Initialized
INFO - 2016-05-11 19:14:35 --> Loader Class Initialized
INFO - 2016-05-11 19:14:35 --> Helper loaded: url_helper
INFO - 2016-05-11 19:14:35 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:14:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:14:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:14:35 --> Helper loaded: form_helper
INFO - 2016-05-11 19:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:14:35 --> Form Validation Class Initialized
INFO - 2016-05-11 19:14:35 --> Controller Class Initialized
INFO - 2016-05-11 19:14:35 --> Model Class Initialized
INFO - 2016-05-11 19:14:35 --> Database Driver Class Initialized
INFO - 2016-05-11 19:14:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:14:35 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:14:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:14:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:14:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:14:35 --> Final output sent to browser
DEBUG - 2016-05-11 19:14:35 --> Total execution time: 0.0760
INFO - 2016-05-11 19:28:10 --> Config Class Initialized
INFO - 2016-05-11 19:28:10 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:28:10 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:28:10 --> Utf8 Class Initialized
INFO - 2016-05-11 19:28:10 --> URI Class Initialized
DEBUG - 2016-05-11 19:28:10 --> No URI present. Default controller set.
INFO - 2016-05-11 19:28:10 --> Router Class Initialized
INFO - 2016-05-11 19:28:10 --> Output Class Initialized
INFO - 2016-05-11 19:28:10 --> Security Class Initialized
DEBUG - 2016-05-11 19:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:28:10 --> Input Class Initialized
INFO - 2016-05-11 19:28:10 --> Language Class Initialized
INFO - 2016-05-11 19:28:10 --> Loader Class Initialized
INFO - 2016-05-11 19:28:10 --> Helper loaded: url_helper
INFO - 2016-05-11 19:28:10 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:28:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:28:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:28:10 --> Helper loaded: form_helper
INFO - 2016-05-11 19:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:28:10 --> Form Validation Class Initialized
INFO - 2016-05-11 19:28:10 --> Controller Class Initialized
INFO - 2016-05-11 19:28:10 --> Model Class Initialized
INFO - 2016-05-11 19:28:10 --> Database Driver Class Initialized
INFO - 2016-05-11 19:28:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:28:10 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:28:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:28:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:28:10 --> Final output sent to browser
DEBUG - 2016-05-11 19:28:10 --> Total execution time: 0.0796
INFO - 2016-05-11 19:35:54 --> Config Class Initialized
INFO - 2016-05-11 19:35:54 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:35:54 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:35:54 --> Utf8 Class Initialized
INFO - 2016-05-11 19:35:54 --> URI Class Initialized
DEBUG - 2016-05-11 19:35:54 --> No URI present. Default controller set.
INFO - 2016-05-11 19:35:54 --> Router Class Initialized
INFO - 2016-05-11 19:35:54 --> Output Class Initialized
INFO - 2016-05-11 19:35:54 --> Security Class Initialized
DEBUG - 2016-05-11 19:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:35:54 --> Input Class Initialized
INFO - 2016-05-11 19:35:54 --> Language Class Initialized
INFO - 2016-05-11 19:35:54 --> Loader Class Initialized
INFO - 2016-05-11 19:35:54 --> Helper loaded: url_helper
INFO - 2016-05-11 19:35:54 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:35:54 --> Helper loaded: admin_templates_helper
ERROR - 2016-05-11 19:35:54 --> Severity: Compile Error --> Cannot redeclare getLinksJS() (previously declared in C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\helpers\admin_templates_helper.php:58) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\helpers\ven_templates_helper.php 43
INFO - 2016-05-11 19:36:20 --> Config Class Initialized
INFO - 2016-05-11 19:36:20 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:36:20 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:36:20 --> Utf8 Class Initialized
INFO - 2016-05-11 19:36:20 --> URI Class Initialized
DEBUG - 2016-05-11 19:36:20 --> No URI present. Default controller set.
INFO - 2016-05-11 19:36:20 --> Router Class Initialized
INFO - 2016-05-11 19:36:20 --> Output Class Initialized
INFO - 2016-05-11 19:36:20 --> Security Class Initialized
DEBUG - 2016-05-11 19:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:36:20 --> Input Class Initialized
INFO - 2016-05-11 19:36:20 --> Language Class Initialized
INFO - 2016-05-11 19:36:20 --> Loader Class Initialized
INFO - 2016-05-11 19:36:20 --> Helper loaded: url_helper
INFO - 2016-05-11 19:36:20 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:36:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:36:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:36:20 --> Helper loaded: form_helper
INFO - 2016-05-11 19:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:36:20 --> Form Validation Class Initialized
INFO - 2016-05-11 19:36:20 --> Controller Class Initialized
INFO - 2016-05-11 19:36:20 --> Model Class Initialized
INFO - 2016-05-11 19:36:20 --> Database Driver Class Initialized
INFO - 2016-05-11 19:36:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:36:20 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:36:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:36:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:36:20 --> Final output sent to browser
DEBUG - 2016-05-11 19:36:20 --> Total execution time: 0.0869
INFO - 2016-05-11 19:43:26 --> Config Class Initialized
INFO - 2016-05-11 19:43:26 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:43:26 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:43:26 --> Utf8 Class Initialized
INFO - 2016-05-11 19:43:26 --> URI Class Initialized
DEBUG - 2016-05-11 19:43:26 --> No URI present. Default controller set.
INFO - 2016-05-11 19:43:26 --> Router Class Initialized
INFO - 2016-05-11 19:43:26 --> Output Class Initialized
INFO - 2016-05-11 19:43:26 --> Security Class Initialized
DEBUG - 2016-05-11 19:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:43:26 --> Input Class Initialized
INFO - 2016-05-11 19:43:26 --> Language Class Initialized
INFO - 2016-05-11 19:43:26 --> Loader Class Initialized
INFO - 2016-05-11 19:43:26 --> Helper loaded: url_helper
INFO - 2016-05-11 19:43:26 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:43:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:43:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:43:26 --> Helper loaded: form_helper
INFO - 2016-05-11 19:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:43:26 --> Form Validation Class Initialized
INFO - 2016-05-11 19:43:26 --> Controller Class Initialized
INFO - 2016-05-11 19:43:26 --> Model Class Initialized
INFO - 2016-05-11 19:43:26 --> Database Driver Class Initialized
INFO - 2016-05-11 19:43:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:43:26 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:43:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:43:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:43:26 --> Final output sent to browser
DEBUG - 2016-05-11 19:43:26 --> Total execution time: 0.0779
INFO - 2016-05-11 19:43:33 --> Config Class Initialized
INFO - 2016-05-11 19:43:33 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:43:33 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:43:33 --> Utf8 Class Initialized
INFO - 2016-05-11 19:43:33 --> URI Class Initialized
INFO - 2016-05-11 19:43:33 --> Router Class Initialized
INFO - 2016-05-11 19:43:33 --> Output Class Initialized
INFO - 2016-05-11 19:43:33 --> Security Class Initialized
DEBUG - 2016-05-11 19:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:43:33 --> Input Class Initialized
INFO - 2016-05-11 19:43:33 --> Language Class Initialized
INFO - 2016-05-11 19:43:33 --> Loader Class Initialized
INFO - 2016-05-11 19:43:33 --> Helper loaded: url_helper
INFO - 2016-05-11 19:43:33 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:43:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:43:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:43:33 --> Helper loaded: form_helper
INFO - 2016-05-11 19:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:43:33 --> Form Validation Class Initialized
INFO - 2016-05-11 19:43:33 --> Controller Class Initialized
INFO - 2016-05-11 19:43:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-11 19:43:33 --> Final output sent to browser
DEBUG - 2016-05-11 19:43:33 --> Total execution time: 0.0488
INFO - 2016-05-11 19:43:41 --> Config Class Initialized
INFO - 2016-05-11 19:43:41 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:43:41 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:43:41 --> Utf8 Class Initialized
INFO - 2016-05-11 19:43:41 --> URI Class Initialized
INFO - 2016-05-11 19:43:41 --> Router Class Initialized
INFO - 2016-05-11 19:43:41 --> Output Class Initialized
INFO - 2016-05-11 19:43:41 --> Security Class Initialized
DEBUG - 2016-05-11 19:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:43:41 --> Input Class Initialized
INFO - 2016-05-11 19:43:41 --> Language Class Initialized
INFO - 2016-05-11 19:43:41 --> Loader Class Initialized
INFO - 2016-05-11 19:43:41 --> Helper loaded: url_helper
INFO - 2016-05-11 19:43:41 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:43:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:43:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:43:41 --> Helper loaded: form_helper
INFO - 2016-05-11 19:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:43:41 --> Form Validation Class Initialized
INFO - 2016-05-11 19:43:41 --> Controller Class Initialized
INFO - 2016-05-11 19:43:41 --> Model Class Initialized
INFO - 2016-05-11 19:43:41 --> Database Driver Class Initialized
INFO - 2016-05-11 19:43:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:43:41 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:43:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-11 19:43:41 --> Severity: Warning --> Missing argument 1 for Mdl_tienda::getProductos(), called in C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Main.php on line 37 and defined C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_tienda.php 13
ERROR - 2016-05-11 19:43:41 --> Severity: Warning --> Missing argument 2 for Mdl_tienda::getProductos(), called in C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Main.php on line 37 and defined C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_tienda.php 13
ERROR - 2016-05-11 19:43:41 --> Severity: Notice --> Undefined variable: start C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_tienda.php 21
ERROR - 2016-05-11 19:43:41 --> Severity: Notice --> Undefined variable: limit C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_tienda.php 21
ERROR - 2016-05-11 19:43:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT prod.nombre, prod.imagen, prod.descripcion, cat.nombre 'categoria' FROM producto prod INNER JOIN categoria cat ON prod.idCategoria = cat.idCategoria WHERE prod.estado = 'Alta' AND cat.estado = 'Alta'ORDER BY prod.referencia LIMIT , ; 
INFO - 2016-05-11 19:43:41 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-11 19:44:33 --> Config Class Initialized
INFO - 2016-05-11 19:44:33 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:44:33 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:44:33 --> Utf8 Class Initialized
INFO - 2016-05-11 19:44:33 --> URI Class Initialized
INFO - 2016-05-11 19:44:33 --> Router Class Initialized
INFO - 2016-05-11 19:44:33 --> Output Class Initialized
INFO - 2016-05-11 19:44:33 --> Security Class Initialized
DEBUG - 2016-05-11 19:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:44:33 --> Input Class Initialized
INFO - 2016-05-11 19:44:33 --> Language Class Initialized
INFO - 2016-05-11 19:44:33 --> Loader Class Initialized
INFO - 2016-05-11 19:44:33 --> Helper loaded: url_helper
INFO - 2016-05-11 19:44:33 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:44:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:44:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:44:33 --> Helper loaded: form_helper
INFO - 2016-05-11 19:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:44:33 --> Form Validation Class Initialized
INFO - 2016-05-11 19:44:33 --> Controller Class Initialized
INFO - 2016-05-11 19:44:33 --> Model Class Initialized
INFO - 2016-05-11 19:44:33 --> Database Driver Class Initialized
INFO - 2016-05-11 19:44:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:44:33 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:44:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-11 19:44:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' 4' at line 1 - Invalid query: SELECT prod.nombre, prod.imagen, prod.descripcion, cat.nombre 'categoria' FROM producto prod INNER JOIN categoria cat ON prod.idCategoria = cat.idCategoria WHERE prod.estado = 'Alta' AND cat.estado = 'Alta'ORDER BY prod.referencia LIMIT , 4; 
INFO - 2016-05-11 19:44:33 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-11 19:44:57 --> Config Class Initialized
INFO - 2016-05-11 19:44:57 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:44:57 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:44:57 --> Utf8 Class Initialized
INFO - 2016-05-11 19:44:57 --> URI Class Initialized
INFO - 2016-05-11 19:44:57 --> Router Class Initialized
INFO - 2016-05-11 19:44:57 --> Output Class Initialized
INFO - 2016-05-11 19:44:57 --> Security Class Initialized
DEBUG - 2016-05-11 19:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:44:57 --> Input Class Initialized
INFO - 2016-05-11 19:44:57 --> Language Class Initialized
INFO - 2016-05-11 19:44:57 --> Loader Class Initialized
INFO - 2016-05-11 19:44:57 --> Helper loaded: url_helper
INFO - 2016-05-11 19:44:57 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:44:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:44:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:44:57 --> Helper loaded: form_helper
INFO - 2016-05-11 19:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:44:57 --> Form Validation Class Initialized
INFO - 2016-05-11 19:44:57 --> Controller Class Initialized
INFO - 2016-05-11 19:44:57 --> Model Class Initialized
INFO - 2016-05-11 19:44:57 --> Database Driver Class Initialized
INFO - 2016-05-11 19:44:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:44:57 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:44:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-11 19:44:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' 4' at line 1 - Invalid query: SELECT prod.nombre, prod.imagen, prod.descripcion, cat.nombre 'categoria' FROM producto prod INNER JOIN categoria cat ON prod.idCategoria = cat.idCategoria WHERE prod.estado = 'Alta' AND cat.estado = 'Alta' ORDER BY prod.referencia LIMIT , 4;
INFO - 2016-05-11 19:44:57 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-11 19:44:58 --> Config Class Initialized
INFO - 2016-05-11 19:44:58 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:44:58 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:44:58 --> Utf8 Class Initialized
INFO - 2016-05-11 19:44:58 --> URI Class Initialized
INFO - 2016-05-11 19:44:58 --> Router Class Initialized
INFO - 2016-05-11 19:44:58 --> Output Class Initialized
INFO - 2016-05-11 19:44:58 --> Security Class Initialized
DEBUG - 2016-05-11 19:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:44:58 --> Input Class Initialized
INFO - 2016-05-11 19:44:58 --> Language Class Initialized
INFO - 2016-05-11 19:44:58 --> Loader Class Initialized
INFO - 2016-05-11 19:44:58 --> Helper loaded: url_helper
INFO - 2016-05-11 19:44:58 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:44:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:44:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:44:58 --> Helper loaded: form_helper
INFO - 2016-05-11 19:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:44:58 --> Form Validation Class Initialized
INFO - 2016-05-11 19:44:58 --> Controller Class Initialized
INFO - 2016-05-11 19:44:58 --> Model Class Initialized
INFO - 2016-05-11 19:44:58 --> Database Driver Class Initialized
INFO - 2016-05-11 19:44:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:44:58 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:44:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-11 19:44:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' 4' at line 1 - Invalid query: SELECT prod.nombre, prod.imagen, prod.descripcion, cat.nombre 'categoria' FROM producto prod INNER JOIN categoria cat ON prod.idCategoria = cat.idCategoria WHERE prod.estado = 'Alta' AND cat.estado = 'Alta' ORDER BY prod.referencia LIMIT , 4;
INFO - 2016-05-11 19:44:58 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-11 19:45:43 --> Config Class Initialized
INFO - 2016-05-11 19:45:43 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:45:43 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:45:43 --> Utf8 Class Initialized
INFO - 2016-05-11 19:45:43 --> URI Class Initialized
INFO - 2016-05-11 19:45:43 --> Router Class Initialized
INFO - 2016-05-11 19:45:43 --> Output Class Initialized
INFO - 2016-05-11 19:45:43 --> Security Class Initialized
DEBUG - 2016-05-11 19:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:45:43 --> Input Class Initialized
INFO - 2016-05-11 19:45:43 --> Language Class Initialized
INFO - 2016-05-11 19:45:43 --> Loader Class Initialized
INFO - 2016-05-11 19:45:43 --> Helper loaded: url_helper
INFO - 2016-05-11 19:45:43 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:45:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:45:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:45:43 --> Helper loaded: form_helper
INFO - 2016-05-11 19:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:45:43 --> Form Validation Class Initialized
INFO - 2016-05-11 19:45:43 --> Controller Class Initialized
INFO - 2016-05-11 19:45:43 --> Model Class Initialized
INFO - 2016-05-11 19:45:43 --> Database Driver Class Initialized
INFO - 2016-05-11 19:45:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:45:43 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:45:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:45:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:45:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:45:43 --> Final output sent to browser
DEBUG - 2016-05-11 19:45:43 --> Total execution time: 0.0816
INFO - 2016-05-11 19:45:48 --> Config Class Initialized
INFO - 2016-05-11 19:45:48 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:45:48 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:45:48 --> Utf8 Class Initialized
INFO - 2016-05-11 19:45:48 --> URI Class Initialized
INFO - 2016-05-11 19:45:48 --> Router Class Initialized
INFO - 2016-05-11 19:45:48 --> Output Class Initialized
INFO - 2016-05-11 19:45:48 --> Security Class Initialized
DEBUG - 2016-05-11 19:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:45:48 --> Input Class Initialized
INFO - 2016-05-11 19:45:48 --> Language Class Initialized
INFO - 2016-05-11 19:45:48 --> Loader Class Initialized
INFO - 2016-05-11 19:45:48 --> Helper loaded: url_helper
INFO - 2016-05-11 19:45:48 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:45:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:45:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:45:48 --> Helper loaded: form_helper
INFO - 2016-05-11 19:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:45:48 --> Form Validation Class Initialized
INFO - 2016-05-11 19:45:48 --> Controller Class Initialized
INFO - 2016-05-11 19:45:48 --> Model Class Initialized
INFO - 2016-05-11 19:45:48 --> Database Driver Class Initialized
INFO - 2016-05-11 19:45:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:45:48 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:45:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:45:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:45:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:45:48 --> Final output sent to browser
DEBUG - 2016-05-11 19:45:48 --> Total execution time: 0.1060
INFO - 2016-05-11 19:45:53 --> Config Class Initialized
INFO - 2016-05-11 19:45:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:45:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:45:53 --> Utf8 Class Initialized
INFO - 2016-05-11 19:45:53 --> URI Class Initialized
INFO - 2016-05-11 19:45:53 --> Router Class Initialized
INFO - 2016-05-11 19:45:53 --> Output Class Initialized
INFO - 2016-05-11 19:45:53 --> Security Class Initialized
DEBUG - 2016-05-11 19:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:45:53 --> Input Class Initialized
INFO - 2016-05-11 19:45:53 --> Language Class Initialized
INFO - 2016-05-11 19:45:53 --> Loader Class Initialized
INFO - 2016-05-11 19:45:53 --> Helper loaded: url_helper
INFO - 2016-05-11 19:45:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:45:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:45:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:45:53 --> Helper loaded: form_helper
INFO - 2016-05-11 19:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:45:53 --> Form Validation Class Initialized
INFO - 2016-05-11 19:45:53 --> Controller Class Initialized
INFO - 2016-05-11 19:45:53 --> Model Class Initialized
INFO - 2016-05-11 19:45:53 --> Database Driver Class Initialized
INFO - 2016-05-11 19:45:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:45:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:45:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:45:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:45:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:45:53 --> Final output sent to browser
DEBUG - 2016-05-11 19:45:53 --> Total execution time: 0.1013
INFO - 2016-05-11 19:46:00 --> Config Class Initialized
INFO - 2016-05-11 19:46:00 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:46:00 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:46:00 --> Utf8 Class Initialized
INFO - 2016-05-11 19:46:00 --> URI Class Initialized
INFO - 2016-05-11 19:46:00 --> Router Class Initialized
INFO - 2016-05-11 19:46:00 --> Output Class Initialized
INFO - 2016-05-11 19:46:00 --> Security Class Initialized
DEBUG - 2016-05-11 19:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:46:00 --> Input Class Initialized
INFO - 2016-05-11 19:46:00 --> Language Class Initialized
INFO - 2016-05-11 19:46:00 --> Loader Class Initialized
INFO - 2016-05-11 19:46:00 --> Helper loaded: url_helper
INFO - 2016-05-11 19:46:00 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:46:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:46:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:46:00 --> Helper loaded: form_helper
INFO - 2016-05-11 19:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:46:00 --> Form Validation Class Initialized
INFO - 2016-05-11 19:46:00 --> Controller Class Initialized
INFO - 2016-05-11 19:46:00 --> Model Class Initialized
INFO - 2016-05-11 19:46:00 --> Database Driver Class Initialized
INFO - 2016-05-11 19:46:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:46:00 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:46:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:46:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:46:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:46:00 --> Final output sent to browser
DEBUG - 2016-05-11 19:46:00 --> Total execution time: 0.0861
INFO - 2016-05-11 19:47:07 --> Config Class Initialized
INFO - 2016-05-11 19:47:07 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:47:07 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:47:07 --> Utf8 Class Initialized
INFO - 2016-05-11 19:47:07 --> URI Class Initialized
INFO - 2016-05-11 19:47:07 --> Router Class Initialized
INFO - 2016-05-11 19:47:07 --> Output Class Initialized
INFO - 2016-05-11 19:47:07 --> Security Class Initialized
DEBUG - 2016-05-11 19:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:47:07 --> Input Class Initialized
INFO - 2016-05-11 19:47:07 --> Language Class Initialized
INFO - 2016-05-11 19:47:07 --> Loader Class Initialized
INFO - 2016-05-11 19:47:07 --> Helper loaded: url_helper
INFO - 2016-05-11 19:47:07 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:47:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:47:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:47:07 --> Helper loaded: form_helper
INFO - 2016-05-11 19:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:47:07 --> Form Validation Class Initialized
INFO - 2016-05-11 19:47:07 --> Controller Class Initialized
INFO - 2016-05-11 19:47:07 --> Model Class Initialized
INFO - 2016-05-11 19:47:07 --> Database Driver Class Initialized
INFO - 2016-05-11 19:47:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:47:07 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:47:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:47:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:47:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:47:07 --> Final output sent to browser
DEBUG - 2016-05-11 19:47:07 --> Total execution time: 0.1054
INFO - 2016-05-11 19:47:10 --> Config Class Initialized
INFO - 2016-05-11 19:47:10 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:47:10 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:47:10 --> Utf8 Class Initialized
INFO - 2016-05-11 19:47:10 --> URI Class Initialized
INFO - 2016-05-11 19:47:10 --> Router Class Initialized
INFO - 2016-05-11 19:47:10 --> Output Class Initialized
INFO - 2016-05-11 19:47:10 --> Security Class Initialized
DEBUG - 2016-05-11 19:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:47:10 --> Input Class Initialized
INFO - 2016-05-11 19:47:10 --> Language Class Initialized
INFO - 2016-05-11 19:47:10 --> Loader Class Initialized
INFO - 2016-05-11 19:47:10 --> Helper loaded: url_helper
INFO - 2016-05-11 19:47:10 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:47:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:47:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:47:10 --> Helper loaded: form_helper
INFO - 2016-05-11 19:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:47:10 --> Form Validation Class Initialized
INFO - 2016-05-11 19:47:10 --> Controller Class Initialized
INFO - 2016-05-11 19:47:10 --> Model Class Initialized
INFO - 2016-05-11 19:47:10 --> Database Driver Class Initialized
INFO - 2016-05-11 19:47:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:47:10 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:47:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:47:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:47:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:47:10 --> Final output sent to browser
DEBUG - 2016-05-11 19:47:10 --> Total execution time: 0.0712
INFO - 2016-05-11 19:48:12 --> Config Class Initialized
INFO - 2016-05-11 19:48:12 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:48:12 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:48:12 --> Utf8 Class Initialized
INFO - 2016-05-11 19:48:12 --> URI Class Initialized
INFO - 2016-05-11 19:48:12 --> Router Class Initialized
INFO - 2016-05-11 19:48:12 --> Output Class Initialized
INFO - 2016-05-11 19:48:12 --> Security Class Initialized
DEBUG - 2016-05-11 19:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:48:12 --> Input Class Initialized
INFO - 2016-05-11 19:48:12 --> Language Class Initialized
INFO - 2016-05-11 19:48:12 --> Loader Class Initialized
INFO - 2016-05-11 19:48:12 --> Helper loaded: url_helper
INFO - 2016-05-11 19:48:12 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:48:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:48:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:48:12 --> Helper loaded: form_helper
INFO - 2016-05-11 19:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:48:12 --> Form Validation Class Initialized
INFO - 2016-05-11 19:48:12 --> Controller Class Initialized
INFO - 2016-05-11 19:48:12 --> Model Class Initialized
INFO - 2016-05-11 19:48:12 --> Database Driver Class Initialized
INFO - 2016-05-11 19:48:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:48:12 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:48:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:48:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:48:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:48:12 --> Final output sent to browser
DEBUG - 2016-05-11 19:48:12 --> Total execution time: 0.0778
INFO - 2016-05-11 19:49:03 --> Config Class Initialized
INFO - 2016-05-11 19:49:03 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:49:03 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:49:03 --> Utf8 Class Initialized
INFO - 2016-05-11 19:49:03 --> URI Class Initialized
INFO - 2016-05-11 19:49:03 --> Router Class Initialized
INFO - 2016-05-11 19:49:03 --> Output Class Initialized
INFO - 2016-05-11 19:49:03 --> Security Class Initialized
DEBUG - 2016-05-11 19:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:49:03 --> Input Class Initialized
INFO - 2016-05-11 19:49:03 --> Language Class Initialized
INFO - 2016-05-11 19:49:03 --> Loader Class Initialized
INFO - 2016-05-11 19:49:03 --> Helper loaded: url_helper
INFO - 2016-05-11 19:49:03 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:49:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:49:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:49:03 --> Helper loaded: form_helper
INFO - 2016-05-11 19:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:49:03 --> Form Validation Class Initialized
INFO - 2016-05-11 19:49:03 --> Controller Class Initialized
INFO - 2016-05-11 19:49:03 --> Model Class Initialized
INFO - 2016-05-11 19:49:03 --> Database Driver Class Initialized
INFO - 2016-05-11 19:49:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:49:03 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:49:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:49:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:49:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:49:03 --> Final output sent to browser
DEBUG - 2016-05-11 19:49:03 --> Total execution time: 0.0796
INFO - 2016-05-11 19:49:06 --> Config Class Initialized
INFO - 2016-05-11 19:49:06 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:49:06 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:49:06 --> Utf8 Class Initialized
INFO - 2016-05-11 19:49:06 --> URI Class Initialized
INFO - 2016-05-11 19:49:06 --> Router Class Initialized
INFO - 2016-05-11 19:49:06 --> Output Class Initialized
INFO - 2016-05-11 19:49:06 --> Security Class Initialized
DEBUG - 2016-05-11 19:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:49:06 --> Input Class Initialized
INFO - 2016-05-11 19:49:06 --> Language Class Initialized
INFO - 2016-05-11 19:49:06 --> Loader Class Initialized
INFO - 2016-05-11 19:49:06 --> Helper loaded: url_helper
INFO - 2016-05-11 19:49:06 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:49:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:49:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:49:06 --> Helper loaded: form_helper
INFO - 2016-05-11 19:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:49:06 --> Form Validation Class Initialized
INFO - 2016-05-11 19:49:06 --> Controller Class Initialized
INFO - 2016-05-11 19:49:06 --> Model Class Initialized
INFO - 2016-05-11 19:49:06 --> Database Driver Class Initialized
INFO - 2016-05-11 19:49:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:49:06 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:49:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:49:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:49:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:49:06 --> Final output sent to browser
DEBUG - 2016-05-11 19:49:06 --> Total execution time: 0.0700
INFO - 2016-05-11 19:50:54 --> Config Class Initialized
INFO - 2016-05-11 19:50:54 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:50:54 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:50:54 --> Utf8 Class Initialized
INFO - 2016-05-11 19:50:54 --> URI Class Initialized
INFO - 2016-05-11 19:50:54 --> Router Class Initialized
INFO - 2016-05-11 19:50:54 --> Output Class Initialized
INFO - 2016-05-11 19:50:54 --> Security Class Initialized
DEBUG - 2016-05-11 19:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:50:54 --> Input Class Initialized
INFO - 2016-05-11 19:50:54 --> Language Class Initialized
INFO - 2016-05-11 19:50:54 --> Loader Class Initialized
INFO - 2016-05-11 19:50:54 --> Helper loaded: url_helper
INFO - 2016-05-11 19:50:54 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:50:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:50:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:50:54 --> Helper loaded: form_helper
INFO - 2016-05-11 19:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:50:54 --> Form Validation Class Initialized
INFO - 2016-05-11 19:50:54 --> Controller Class Initialized
INFO - 2016-05-11 19:50:54 --> Model Class Initialized
INFO - 2016-05-11 19:50:54 --> Database Driver Class Initialized
INFO - 2016-05-11 19:50:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:50:54 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:50:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:50:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:50:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:50:54 --> Final output sent to browser
DEBUG - 2016-05-11 19:50:54 --> Total execution time: 0.0881
INFO - 2016-05-11 19:50:58 --> Config Class Initialized
INFO - 2016-05-11 19:50:58 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:50:58 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:50:58 --> Utf8 Class Initialized
INFO - 2016-05-11 19:50:58 --> URI Class Initialized
INFO - 2016-05-11 19:50:58 --> Router Class Initialized
INFO - 2016-05-11 19:50:58 --> Output Class Initialized
INFO - 2016-05-11 19:50:58 --> Security Class Initialized
DEBUG - 2016-05-11 19:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:50:58 --> Input Class Initialized
INFO - 2016-05-11 19:50:58 --> Language Class Initialized
INFO - 2016-05-11 19:50:58 --> Loader Class Initialized
INFO - 2016-05-11 19:50:58 --> Helper loaded: url_helper
INFO - 2016-05-11 19:50:58 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:50:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:50:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:50:58 --> Helper loaded: form_helper
INFO - 2016-05-11 19:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:50:58 --> Form Validation Class Initialized
INFO - 2016-05-11 19:50:58 --> Controller Class Initialized
INFO - 2016-05-11 19:50:58 --> Model Class Initialized
INFO - 2016-05-11 19:50:58 --> Database Driver Class Initialized
INFO - 2016-05-11 19:50:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:50:58 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:50:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:50:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:50:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:50:58 --> Final output sent to browser
DEBUG - 2016-05-11 19:50:58 --> Total execution time: 0.0930
INFO - 2016-05-11 19:51:25 --> Config Class Initialized
INFO - 2016-05-11 19:51:25 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:51:25 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:51:25 --> Utf8 Class Initialized
INFO - 2016-05-11 19:51:25 --> URI Class Initialized
INFO - 2016-05-11 19:51:25 --> Router Class Initialized
INFO - 2016-05-11 19:51:25 --> Output Class Initialized
INFO - 2016-05-11 19:51:25 --> Security Class Initialized
DEBUG - 2016-05-11 19:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:51:25 --> Input Class Initialized
INFO - 2016-05-11 19:51:25 --> Language Class Initialized
INFO - 2016-05-11 19:51:25 --> Loader Class Initialized
INFO - 2016-05-11 19:51:25 --> Helper loaded: url_helper
INFO - 2016-05-11 19:51:25 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:51:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:51:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:51:25 --> Helper loaded: form_helper
INFO - 2016-05-11 19:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:51:25 --> Form Validation Class Initialized
INFO - 2016-05-11 19:51:25 --> Controller Class Initialized
INFO - 2016-05-11 19:51:25 --> Model Class Initialized
INFO - 2016-05-11 19:51:25 --> Database Driver Class Initialized
INFO - 2016-05-11 19:51:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:51:25 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:51:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:51:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:51:25 --> Final output sent to browser
DEBUG - 2016-05-11 19:51:25 --> Total execution time: 0.0746
INFO - 2016-05-11 19:51:52 --> Config Class Initialized
INFO - 2016-05-11 19:51:52 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:51:52 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:51:52 --> Utf8 Class Initialized
INFO - 2016-05-11 19:51:52 --> URI Class Initialized
INFO - 2016-05-11 19:51:52 --> Router Class Initialized
INFO - 2016-05-11 19:51:52 --> Output Class Initialized
INFO - 2016-05-11 19:51:52 --> Security Class Initialized
DEBUG - 2016-05-11 19:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:51:52 --> Input Class Initialized
INFO - 2016-05-11 19:51:52 --> Language Class Initialized
INFO - 2016-05-11 19:51:52 --> Loader Class Initialized
INFO - 2016-05-11 19:51:52 --> Helper loaded: url_helper
INFO - 2016-05-11 19:51:52 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:51:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:51:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:51:52 --> Helper loaded: form_helper
INFO - 2016-05-11 19:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:51:52 --> Form Validation Class Initialized
INFO - 2016-05-11 19:51:52 --> Controller Class Initialized
INFO - 2016-05-11 19:51:52 --> Model Class Initialized
INFO - 2016-05-11 19:51:52 --> Database Driver Class Initialized
INFO - 2016-05-11 19:51:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:51:52 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:51:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:51:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:51:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:51:52 --> Final output sent to browser
DEBUG - 2016-05-11 19:51:52 --> Total execution time: 0.0771
INFO - 2016-05-11 19:52:15 --> Config Class Initialized
INFO - 2016-05-11 19:52:15 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:52:15 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:52:15 --> Utf8 Class Initialized
INFO - 2016-05-11 19:52:15 --> URI Class Initialized
INFO - 2016-05-11 19:52:15 --> Router Class Initialized
INFO - 2016-05-11 19:52:15 --> Output Class Initialized
INFO - 2016-05-11 19:52:15 --> Security Class Initialized
DEBUG - 2016-05-11 19:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:52:15 --> Input Class Initialized
INFO - 2016-05-11 19:52:15 --> Language Class Initialized
INFO - 2016-05-11 19:52:15 --> Loader Class Initialized
INFO - 2016-05-11 19:52:15 --> Helper loaded: url_helper
INFO - 2016-05-11 19:52:15 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:52:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:52:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:52:15 --> Helper loaded: form_helper
INFO - 2016-05-11 19:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:52:15 --> Form Validation Class Initialized
INFO - 2016-05-11 19:52:15 --> Controller Class Initialized
INFO - 2016-05-11 19:52:15 --> Model Class Initialized
INFO - 2016-05-11 19:52:15 --> Database Driver Class Initialized
INFO - 2016-05-11 19:52:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:52:15 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:52:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:52:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:52:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:52:15 --> Final output sent to browser
DEBUG - 2016-05-11 19:52:15 --> Total execution time: 0.0812
INFO - 2016-05-11 19:52:16 --> Config Class Initialized
INFO - 2016-05-11 19:52:16 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:52:16 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:52:16 --> Utf8 Class Initialized
INFO - 2016-05-11 19:52:16 --> URI Class Initialized
INFO - 2016-05-11 19:52:16 --> Router Class Initialized
INFO - 2016-05-11 19:52:16 --> Output Class Initialized
INFO - 2016-05-11 19:52:16 --> Security Class Initialized
DEBUG - 2016-05-11 19:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:52:16 --> Input Class Initialized
INFO - 2016-05-11 19:52:16 --> Language Class Initialized
INFO - 2016-05-11 19:52:16 --> Loader Class Initialized
INFO - 2016-05-11 19:52:16 --> Helper loaded: url_helper
INFO - 2016-05-11 19:52:16 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:52:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:52:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:52:16 --> Helper loaded: form_helper
INFO - 2016-05-11 19:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:52:16 --> Form Validation Class Initialized
INFO - 2016-05-11 19:52:16 --> Controller Class Initialized
INFO - 2016-05-11 19:52:16 --> Model Class Initialized
INFO - 2016-05-11 19:52:16 --> Database Driver Class Initialized
INFO - 2016-05-11 19:52:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:52:16 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:52:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:52:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:52:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:52:16 --> Final output sent to browser
DEBUG - 2016-05-11 19:52:16 --> Total execution time: 0.0720
INFO - 2016-05-11 19:52:16 --> Config Class Initialized
INFO - 2016-05-11 19:52:16 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:52:16 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:52:16 --> Utf8 Class Initialized
INFO - 2016-05-11 19:52:16 --> URI Class Initialized
INFO - 2016-05-11 19:52:16 --> Router Class Initialized
INFO - 2016-05-11 19:52:16 --> Output Class Initialized
INFO - 2016-05-11 19:52:16 --> Security Class Initialized
DEBUG - 2016-05-11 19:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:52:16 --> Input Class Initialized
INFO - 2016-05-11 19:52:16 --> Language Class Initialized
INFO - 2016-05-11 19:52:16 --> Loader Class Initialized
INFO - 2016-05-11 19:52:16 --> Helper loaded: url_helper
INFO - 2016-05-11 19:52:16 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:52:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:52:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:52:16 --> Helper loaded: form_helper
INFO - 2016-05-11 19:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:52:16 --> Form Validation Class Initialized
INFO - 2016-05-11 19:52:16 --> Controller Class Initialized
INFO - 2016-05-11 19:52:16 --> Model Class Initialized
INFO - 2016-05-11 19:52:16 --> Database Driver Class Initialized
INFO - 2016-05-11 19:52:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:52:16 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:52:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:52:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:52:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:52:16 --> Final output sent to browser
DEBUG - 2016-05-11 19:52:16 --> Total execution time: 0.0974
INFO - 2016-05-11 19:53:31 --> Config Class Initialized
INFO - 2016-05-11 19:53:31 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:53:31 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:53:31 --> Utf8 Class Initialized
INFO - 2016-05-11 19:53:31 --> URI Class Initialized
INFO - 2016-05-11 19:53:31 --> Router Class Initialized
INFO - 2016-05-11 19:53:31 --> Output Class Initialized
INFO - 2016-05-11 19:53:31 --> Security Class Initialized
DEBUG - 2016-05-11 19:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:53:31 --> Input Class Initialized
INFO - 2016-05-11 19:53:31 --> Language Class Initialized
INFO - 2016-05-11 19:53:31 --> Loader Class Initialized
INFO - 2016-05-11 19:53:31 --> Helper loaded: url_helper
INFO - 2016-05-11 19:53:31 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:53:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:53:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:53:31 --> Helper loaded: form_helper
INFO - 2016-05-11 19:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:53:31 --> Form Validation Class Initialized
INFO - 2016-05-11 19:53:31 --> Controller Class Initialized
INFO - 2016-05-11 19:53:31 --> Model Class Initialized
INFO - 2016-05-11 19:53:31 --> Database Driver Class Initialized
INFO - 2016-05-11 19:53:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:53:31 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:53:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:53:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:53:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:53:31 --> Final output sent to browser
DEBUG - 2016-05-11 19:53:31 --> Total execution time: 0.0750
INFO - 2016-05-11 19:53:34 --> Config Class Initialized
INFO - 2016-05-11 19:53:34 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:53:34 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:53:34 --> Utf8 Class Initialized
INFO - 2016-05-11 19:53:34 --> URI Class Initialized
DEBUG - 2016-05-11 19:53:34 --> No URI present. Default controller set.
INFO - 2016-05-11 19:53:34 --> Router Class Initialized
INFO - 2016-05-11 19:53:34 --> Output Class Initialized
INFO - 2016-05-11 19:53:34 --> Security Class Initialized
DEBUG - 2016-05-11 19:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:53:34 --> Input Class Initialized
INFO - 2016-05-11 19:53:34 --> Language Class Initialized
INFO - 2016-05-11 19:53:34 --> Loader Class Initialized
INFO - 2016-05-11 19:53:34 --> Helper loaded: url_helper
INFO - 2016-05-11 19:53:34 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:53:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:53:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:53:34 --> Helper loaded: form_helper
INFO - 2016-05-11 19:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:53:34 --> Form Validation Class Initialized
INFO - 2016-05-11 19:53:34 --> Controller Class Initialized
INFO - 2016-05-11 19:53:34 --> Model Class Initialized
INFO - 2016-05-11 19:53:34 --> Database Driver Class Initialized
INFO - 2016-05-11 19:53:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:53:34 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:53:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:53:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:53:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:53:34 --> Final output sent to browser
DEBUG - 2016-05-11 19:53:34 --> Total execution time: 0.0707
INFO - 2016-05-11 19:54:07 --> Config Class Initialized
INFO - 2016-05-11 19:54:07 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:54:07 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:54:07 --> Utf8 Class Initialized
INFO - 2016-05-11 19:54:07 --> URI Class Initialized
DEBUG - 2016-05-11 19:54:07 --> No URI present. Default controller set.
INFO - 2016-05-11 19:54:07 --> Router Class Initialized
INFO - 2016-05-11 19:54:07 --> Output Class Initialized
INFO - 2016-05-11 19:54:07 --> Security Class Initialized
DEBUG - 2016-05-11 19:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:54:07 --> Input Class Initialized
INFO - 2016-05-11 19:54:07 --> Language Class Initialized
INFO - 2016-05-11 19:54:07 --> Loader Class Initialized
INFO - 2016-05-11 19:54:07 --> Helper loaded: url_helper
INFO - 2016-05-11 19:54:07 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:54:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:54:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:54:07 --> Helper loaded: form_helper
INFO - 2016-05-11 19:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:54:07 --> Form Validation Class Initialized
INFO - 2016-05-11 19:54:07 --> Controller Class Initialized
INFO - 2016-05-11 19:54:07 --> Model Class Initialized
INFO - 2016-05-11 19:54:07 --> Database Driver Class Initialized
INFO - 2016-05-11 19:54:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:54:07 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:54:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:54:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:54:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:54:07 --> Final output sent to browser
DEBUG - 2016-05-11 19:54:07 --> Total execution time: 0.0770
INFO - 2016-05-11 19:54:11 --> Config Class Initialized
INFO - 2016-05-11 19:54:11 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:54:11 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:54:11 --> Utf8 Class Initialized
INFO - 2016-05-11 19:54:11 --> URI Class Initialized
INFO - 2016-05-11 19:54:11 --> Router Class Initialized
INFO - 2016-05-11 19:54:11 --> Output Class Initialized
INFO - 2016-05-11 19:54:11 --> Security Class Initialized
DEBUG - 2016-05-11 19:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:54:11 --> Input Class Initialized
INFO - 2016-05-11 19:54:11 --> Language Class Initialized
INFO - 2016-05-11 19:54:11 --> Loader Class Initialized
INFO - 2016-05-11 19:54:11 --> Helper loaded: url_helper
INFO - 2016-05-11 19:54:11 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:54:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:54:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:54:11 --> Helper loaded: form_helper
INFO - 2016-05-11 19:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:54:11 --> Form Validation Class Initialized
INFO - 2016-05-11 19:54:11 --> Controller Class Initialized
INFO - 2016-05-11 19:54:11 --> Model Class Initialized
INFO - 2016-05-11 19:54:11 --> Database Driver Class Initialized
INFO - 2016-05-11 19:54:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:54:11 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:54:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:54:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:54:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:54:11 --> Final output sent to browser
DEBUG - 2016-05-11 19:54:11 --> Total execution time: 0.0686
INFO - 2016-05-11 19:54:15 --> Config Class Initialized
INFO - 2016-05-11 19:54:15 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:54:15 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:54:15 --> Utf8 Class Initialized
INFO - 2016-05-11 19:54:15 --> URI Class Initialized
INFO - 2016-05-11 19:54:15 --> Router Class Initialized
INFO - 2016-05-11 19:54:15 --> Output Class Initialized
INFO - 2016-05-11 19:54:15 --> Security Class Initialized
DEBUG - 2016-05-11 19:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:54:15 --> Input Class Initialized
INFO - 2016-05-11 19:54:15 --> Language Class Initialized
INFO - 2016-05-11 19:54:15 --> Loader Class Initialized
INFO - 2016-05-11 19:54:15 --> Helper loaded: url_helper
INFO - 2016-05-11 19:54:15 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:54:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:54:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:54:15 --> Helper loaded: form_helper
INFO - 2016-05-11 19:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:54:15 --> Form Validation Class Initialized
INFO - 2016-05-11 19:54:15 --> Controller Class Initialized
INFO - 2016-05-11 19:54:15 --> Model Class Initialized
INFO - 2016-05-11 19:54:15 --> Database Driver Class Initialized
INFO - 2016-05-11 19:54:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:54:15 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:54:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:54:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:54:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:54:15 --> Final output sent to browser
DEBUG - 2016-05-11 19:54:15 --> Total execution time: 0.0677
INFO - 2016-05-11 19:54:15 --> Config Class Initialized
INFO - 2016-05-11 19:54:15 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:54:15 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:54:15 --> Utf8 Class Initialized
INFO - 2016-05-11 19:54:15 --> URI Class Initialized
INFO - 2016-05-11 19:54:15 --> Router Class Initialized
INFO - 2016-05-11 19:54:15 --> Output Class Initialized
INFO - 2016-05-11 19:54:15 --> Security Class Initialized
DEBUG - 2016-05-11 19:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:54:15 --> Input Class Initialized
INFO - 2016-05-11 19:54:15 --> Language Class Initialized
INFO - 2016-05-11 19:54:15 --> Loader Class Initialized
INFO - 2016-05-11 19:54:15 --> Helper loaded: url_helper
INFO - 2016-05-11 19:54:15 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:54:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:54:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:54:15 --> Helper loaded: form_helper
INFO - 2016-05-11 19:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:54:15 --> Form Validation Class Initialized
INFO - 2016-05-11 19:54:15 --> Controller Class Initialized
INFO - 2016-05-11 19:54:15 --> Model Class Initialized
INFO - 2016-05-11 19:54:15 --> Database Driver Class Initialized
INFO - 2016-05-11 19:54:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:54:15 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:54:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:54:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:54:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:54:15 --> Final output sent to browser
DEBUG - 2016-05-11 19:54:15 --> Total execution time: 0.0876
INFO - 2016-05-11 19:54:16 --> Config Class Initialized
INFO - 2016-05-11 19:54:16 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:54:16 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:54:16 --> Utf8 Class Initialized
INFO - 2016-05-11 19:54:16 --> URI Class Initialized
INFO - 2016-05-11 19:54:16 --> Router Class Initialized
INFO - 2016-05-11 19:54:16 --> Output Class Initialized
INFO - 2016-05-11 19:54:16 --> Security Class Initialized
DEBUG - 2016-05-11 19:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:54:16 --> Input Class Initialized
INFO - 2016-05-11 19:54:16 --> Language Class Initialized
INFO - 2016-05-11 19:54:16 --> Loader Class Initialized
INFO - 2016-05-11 19:54:16 --> Helper loaded: url_helper
INFO - 2016-05-11 19:54:16 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:54:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:54:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:54:16 --> Helper loaded: form_helper
INFO - 2016-05-11 19:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:54:17 --> Form Validation Class Initialized
INFO - 2016-05-11 19:54:17 --> Controller Class Initialized
INFO - 2016-05-11 19:54:17 --> Model Class Initialized
INFO - 2016-05-11 19:54:17 --> Database Driver Class Initialized
INFO - 2016-05-11 19:54:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:54:17 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:54:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:54:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:54:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:54:17 --> Final output sent to browser
DEBUG - 2016-05-11 19:54:17 --> Total execution time: 0.0848
INFO - 2016-05-11 19:54:17 --> Config Class Initialized
INFO - 2016-05-11 19:54:17 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:54:17 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:54:17 --> Utf8 Class Initialized
INFO - 2016-05-11 19:54:17 --> Config Class Initialized
INFO - 2016-05-11 19:54:17 --> Hooks Class Initialized
INFO - 2016-05-11 19:54:17 --> URI Class Initialized
INFO - 2016-05-11 19:54:17 --> Router Class Initialized
DEBUG - 2016-05-11 19:54:17 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:54:17 --> Utf8 Class Initialized
INFO - 2016-05-11 19:54:17 --> Output Class Initialized
INFO - 2016-05-11 19:54:17 --> URI Class Initialized
INFO - 2016-05-11 19:54:17 --> Security Class Initialized
INFO - 2016-05-11 19:54:17 --> Router Class Initialized
DEBUG - 2016-05-11 19:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:54:17 --> Input Class Initialized
INFO - 2016-05-11 19:54:17 --> Language Class Initialized
INFO - 2016-05-11 19:54:17 --> Output Class Initialized
INFO - 2016-05-11 19:54:17 --> Security Class Initialized
INFO - 2016-05-11 19:54:17 --> Loader Class Initialized
INFO - 2016-05-11 19:54:17 --> Config Class Initialized
INFO - 2016-05-11 19:54:17 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:54:17 --> Input Class Initialized
INFO - 2016-05-11 19:54:17 --> Helper loaded: url_helper
INFO - 2016-05-11 19:54:17 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:54:17 --> Language Class Initialized
INFO - 2016-05-11 19:54:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:54:17 --> Helper loaded: ven_templates_helper
DEBUG - 2016-05-11 19:54:17 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:54:17 --> Loader Class Initialized
INFO - 2016-05-11 19:54:17 --> Utf8 Class Initialized
INFO - 2016-05-11 19:54:17 --> Helper loaded: form_helper
INFO - 2016-05-11 19:54:17 --> URI Class Initialized
INFO - 2016-05-11 19:54:17 --> Helper loaded: url_helper
INFO - 2016-05-11 19:54:17 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:54:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:54:17 --> Router Class Initialized
INFO - 2016-05-11 19:54:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:54:17 --> Helper loaded: form_helper
INFO - 2016-05-11 19:54:17 --> Output Class Initialized
INFO - 2016-05-11 19:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:54:17 --> Security Class Initialized
DEBUG - 2016-05-11 19:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:54:17 --> Input Class Initialized
INFO - 2016-05-11 19:54:17 --> Form Validation Class Initialized
INFO - 2016-05-11 19:54:17 --> Controller Class Initialized
INFO - 2016-05-11 19:54:17 --> Language Class Initialized
INFO - 2016-05-11 19:54:17 --> Model Class Initialized
INFO - 2016-05-11 19:54:17 --> Loader Class Initialized
INFO - 2016-05-11 19:54:17 --> Helper loaded: url_helper
INFO - 2016-05-11 19:54:17 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:54:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:54:17 --> Database Driver Class Initialized
INFO - 2016-05-11 19:54:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:54:17 --> Helper loaded: form_helper
INFO - 2016-05-11 19:54:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:54:17 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:54:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:54:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:54:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:54:17 --> Final output sent to browser
DEBUG - 2016-05-11 19:54:17 --> Total execution time: 0.1101
INFO - 2016-05-11 19:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:54:17 --> Form Validation Class Initialized
INFO - 2016-05-11 19:54:17 --> Controller Class Initialized
INFO - 2016-05-11 19:54:17 --> Model Class Initialized
INFO - 2016-05-11 19:54:17 --> Database Driver Class Initialized
INFO - 2016-05-11 19:54:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:54:17 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:54:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:54:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:54:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:54:17 --> Final output sent to browser
DEBUG - 2016-05-11 19:54:17 --> Total execution time: 0.1402
INFO - 2016-05-11 19:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:54:17 --> Form Validation Class Initialized
INFO - 2016-05-11 19:54:17 --> Controller Class Initialized
INFO - 2016-05-11 19:54:17 --> Model Class Initialized
INFO - 2016-05-11 19:54:17 --> Database Driver Class Initialized
INFO - 2016-05-11 19:54:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:54:17 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:54:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:54:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:54:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:54:17 --> Final output sent to browser
DEBUG - 2016-05-11 19:54:17 --> Total execution time: 0.1463
INFO - 2016-05-11 19:54:45 --> Config Class Initialized
INFO - 2016-05-11 19:54:45 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:54:45 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:54:45 --> Utf8 Class Initialized
INFO - 2016-05-11 19:54:45 --> URI Class Initialized
DEBUG - 2016-05-11 19:54:45 --> No URI present. Default controller set.
INFO - 2016-05-11 19:54:45 --> Router Class Initialized
INFO - 2016-05-11 19:54:45 --> Output Class Initialized
INFO - 2016-05-11 19:54:45 --> Security Class Initialized
DEBUG - 2016-05-11 19:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:54:45 --> Input Class Initialized
INFO - 2016-05-11 19:54:45 --> Language Class Initialized
INFO - 2016-05-11 19:54:45 --> Loader Class Initialized
INFO - 2016-05-11 19:54:45 --> Helper loaded: url_helper
INFO - 2016-05-11 19:54:45 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:54:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:54:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:54:45 --> Helper loaded: form_helper
INFO - 2016-05-11 19:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:54:45 --> Form Validation Class Initialized
INFO - 2016-05-11 19:54:45 --> Controller Class Initialized
INFO - 2016-05-11 19:54:45 --> Model Class Initialized
INFO - 2016-05-11 19:54:45 --> Database Driver Class Initialized
INFO - 2016-05-11 19:54:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:54:45 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:54:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:54:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:54:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:54:45 --> Final output sent to browser
DEBUG - 2016-05-11 19:54:45 --> Total execution time: 0.0830
INFO - 2016-05-11 19:54:47 --> Config Class Initialized
INFO - 2016-05-11 19:54:47 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:54:47 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:54:47 --> Utf8 Class Initialized
INFO - 2016-05-11 19:54:47 --> URI Class Initialized
INFO - 2016-05-11 19:54:47 --> Router Class Initialized
INFO - 2016-05-11 19:54:47 --> Output Class Initialized
INFO - 2016-05-11 19:54:47 --> Security Class Initialized
DEBUG - 2016-05-11 19:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:54:47 --> Input Class Initialized
INFO - 2016-05-11 19:54:47 --> Language Class Initialized
INFO - 2016-05-11 19:54:47 --> Loader Class Initialized
INFO - 2016-05-11 19:54:47 --> Helper loaded: url_helper
INFO - 2016-05-11 19:54:47 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:54:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:54:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:54:47 --> Helper loaded: form_helper
INFO - 2016-05-11 19:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:54:47 --> Form Validation Class Initialized
INFO - 2016-05-11 19:54:47 --> Controller Class Initialized
INFO - 2016-05-11 19:54:47 --> Model Class Initialized
INFO - 2016-05-11 19:54:47 --> Database Driver Class Initialized
INFO - 2016-05-11 19:54:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:54:47 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:54:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:54:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:54:47 --> Final output sent to browser
DEBUG - 2016-05-11 19:54:47 --> Total execution time: 0.1160
INFO - 2016-05-11 19:57:38 --> Config Class Initialized
INFO - 2016-05-11 19:57:38 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:57:38 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:57:38 --> Utf8 Class Initialized
INFO - 2016-05-11 19:57:38 --> URI Class Initialized
DEBUG - 2016-05-11 19:57:38 --> No URI present. Default controller set.
INFO - 2016-05-11 19:57:38 --> Router Class Initialized
INFO - 2016-05-11 19:57:38 --> Output Class Initialized
INFO - 2016-05-11 19:57:38 --> Security Class Initialized
DEBUG - 2016-05-11 19:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:57:38 --> Input Class Initialized
INFO - 2016-05-11 19:57:38 --> Language Class Initialized
INFO - 2016-05-11 19:57:38 --> Loader Class Initialized
INFO - 2016-05-11 19:57:38 --> Helper loaded: url_helper
INFO - 2016-05-11 19:57:38 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:57:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:57:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:57:38 --> Helper loaded: form_helper
INFO - 2016-05-11 19:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:57:38 --> Form Validation Class Initialized
INFO - 2016-05-11 19:57:38 --> Controller Class Initialized
INFO - 2016-05-11 19:57:38 --> Model Class Initialized
INFO - 2016-05-11 19:57:38 --> Database Driver Class Initialized
INFO - 2016-05-11 19:57:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:57:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:57:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:57:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
ERROR - 2016-05-11 19:57:38 --> Severity: Notice --> Use of undefined constant document - assumed 'document' C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Main.php 39
ERROR - 2016-05-11 19:57:38 --> Severity: Error --> Call to undefined function getElementById() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Main.php 39
INFO - 2016-05-11 19:57:45 --> Config Class Initialized
INFO - 2016-05-11 19:57:45 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:57:45 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:57:45 --> Utf8 Class Initialized
INFO - 2016-05-11 19:57:45 --> URI Class Initialized
DEBUG - 2016-05-11 19:57:45 --> No URI present. Default controller set.
INFO - 2016-05-11 19:57:45 --> Router Class Initialized
INFO - 2016-05-11 19:57:45 --> Output Class Initialized
INFO - 2016-05-11 19:57:45 --> Security Class Initialized
DEBUG - 2016-05-11 19:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:57:45 --> Input Class Initialized
INFO - 2016-05-11 19:57:45 --> Language Class Initialized
INFO - 2016-05-11 19:57:45 --> Loader Class Initialized
INFO - 2016-05-11 19:57:45 --> Helper loaded: url_helper
INFO - 2016-05-11 19:57:45 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:57:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:57:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:57:45 --> Helper loaded: form_helper
INFO - 2016-05-11 19:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:57:45 --> Form Validation Class Initialized
INFO - 2016-05-11 19:57:45 --> Controller Class Initialized
INFO - 2016-05-11 19:57:45 --> Model Class Initialized
INFO - 2016-05-11 19:57:45 --> Database Driver Class Initialized
INFO - 2016-05-11 19:57:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:57:45 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:57:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:57:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:57:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:57:45 --> Final output sent to browser
DEBUG - 2016-05-11 19:57:45 --> Total execution time: 0.0885
INFO - 2016-05-11 19:58:02 --> Config Class Initialized
INFO - 2016-05-11 19:58:02 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:58:02 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:58:02 --> Utf8 Class Initialized
INFO - 2016-05-11 19:58:02 --> URI Class Initialized
DEBUG - 2016-05-11 19:58:02 --> No URI present. Default controller set.
INFO - 2016-05-11 19:58:02 --> Router Class Initialized
INFO - 2016-05-11 19:58:02 --> Output Class Initialized
INFO - 2016-05-11 19:58:02 --> Security Class Initialized
DEBUG - 2016-05-11 19:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:58:02 --> Input Class Initialized
INFO - 2016-05-11 19:58:02 --> Language Class Initialized
INFO - 2016-05-11 19:58:02 --> Loader Class Initialized
INFO - 2016-05-11 19:58:02 --> Helper loaded: url_helper
INFO - 2016-05-11 19:58:02 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:58:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:58:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:58:02 --> Helper loaded: form_helper
INFO - 2016-05-11 19:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:58:02 --> Form Validation Class Initialized
INFO - 2016-05-11 19:58:02 --> Controller Class Initialized
INFO - 2016-05-11 19:58:02 --> Model Class Initialized
INFO - 2016-05-11 19:58:02 --> Database Driver Class Initialized
INFO - 2016-05-11 19:58:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:58:02 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:58:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:58:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:58:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:58:02 --> Final output sent to browser
DEBUG - 2016-05-11 19:58:02 --> Total execution time: 0.0765
INFO - 2016-05-11 19:58:20 --> Config Class Initialized
INFO - 2016-05-11 19:58:20 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:58:20 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:58:20 --> Utf8 Class Initialized
INFO - 2016-05-11 19:58:20 --> URI Class Initialized
DEBUG - 2016-05-11 19:58:20 --> No URI present. Default controller set.
INFO - 2016-05-11 19:58:20 --> Router Class Initialized
INFO - 2016-05-11 19:58:20 --> Output Class Initialized
INFO - 2016-05-11 19:58:20 --> Security Class Initialized
DEBUG - 2016-05-11 19:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:58:20 --> Input Class Initialized
INFO - 2016-05-11 19:58:20 --> Language Class Initialized
INFO - 2016-05-11 19:58:20 --> Loader Class Initialized
INFO - 2016-05-11 19:58:20 --> Helper loaded: url_helper
INFO - 2016-05-11 19:58:20 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:58:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:58:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:58:20 --> Helper loaded: form_helper
INFO - 2016-05-11 19:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:58:20 --> Form Validation Class Initialized
INFO - 2016-05-11 19:58:20 --> Controller Class Initialized
INFO - 2016-05-11 19:58:20 --> Model Class Initialized
INFO - 2016-05-11 19:58:20 --> Database Driver Class Initialized
INFO - 2016-05-11 19:58:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:58:20 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:58:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:58:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:58:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:58:20 --> Final output sent to browser
DEBUG - 2016-05-11 19:58:20 --> Total execution time: 0.0844
INFO - 2016-05-11 19:58:23 --> Config Class Initialized
INFO - 2016-05-11 19:58:23 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:58:23 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:58:23 --> Utf8 Class Initialized
INFO - 2016-05-11 19:58:23 --> URI Class Initialized
INFO - 2016-05-11 19:58:23 --> Router Class Initialized
INFO - 2016-05-11 19:58:23 --> Output Class Initialized
INFO - 2016-05-11 19:58:23 --> Security Class Initialized
DEBUG - 2016-05-11 19:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:58:23 --> Input Class Initialized
INFO - 2016-05-11 19:58:23 --> Language Class Initialized
INFO - 2016-05-11 19:58:23 --> Loader Class Initialized
INFO - 2016-05-11 19:58:23 --> Helper loaded: url_helper
INFO - 2016-05-11 19:58:23 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:58:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:58:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:58:23 --> Helper loaded: form_helper
INFO - 2016-05-11 19:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:58:23 --> Form Validation Class Initialized
INFO - 2016-05-11 19:58:23 --> Controller Class Initialized
INFO - 2016-05-11 19:58:23 --> Model Class Initialized
INFO - 2016-05-11 19:58:23 --> Database Driver Class Initialized
INFO - 2016-05-11 19:58:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:58:23 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:58:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:58:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:58:23 --> Final output sent to browser
DEBUG - 2016-05-11 19:58:23 --> Total execution time: 0.0986
INFO - 2016-05-11 19:58:29 --> Config Class Initialized
INFO - 2016-05-11 19:58:29 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:58:29 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:58:29 --> Utf8 Class Initialized
INFO - 2016-05-11 19:58:29 --> URI Class Initialized
INFO - 2016-05-11 19:58:29 --> Router Class Initialized
INFO - 2016-05-11 19:58:29 --> Output Class Initialized
INFO - 2016-05-11 19:58:29 --> Security Class Initialized
DEBUG - 2016-05-11 19:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:58:29 --> Input Class Initialized
INFO - 2016-05-11 19:58:29 --> Language Class Initialized
INFO - 2016-05-11 19:58:29 --> Loader Class Initialized
INFO - 2016-05-11 19:58:29 --> Helper loaded: url_helper
INFO - 2016-05-11 19:58:29 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:58:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:58:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:58:29 --> Helper loaded: form_helper
INFO - 2016-05-11 19:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:58:29 --> Form Validation Class Initialized
INFO - 2016-05-11 19:58:29 --> Controller Class Initialized
INFO - 2016-05-11 19:58:29 --> Model Class Initialized
INFO - 2016-05-11 19:58:29 --> Database Driver Class Initialized
INFO - 2016-05-11 19:58:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:58:29 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:58:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:58:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:58:29 --> Final output sent to browser
DEBUG - 2016-05-11 19:58:29 --> Total execution time: 0.0742
INFO - 2016-05-11 19:58:31 --> Config Class Initialized
INFO - 2016-05-11 19:58:31 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:58:31 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:58:31 --> Utf8 Class Initialized
INFO - 2016-05-11 19:58:31 --> URI Class Initialized
INFO - 2016-05-11 19:58:31 --> Router Class Initialized
INFO - 2016-05-11 19:58:31 --> Output Class Initialized
INFO - 2016-05-11 19:58:31 --> Security Class Initialized
DEBUG - 2016-05-11 19:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:58:31 --> Input Class Initialized
INFO - 2016-05-11 19:58:31 --> Language Class Initialized
INFO - 2016-05-11 19:58:31 --> Loader Class Initialized
INFO - 2016-05-11 19:58:31 --> Helper loaded: url_helper
INFO - 2016-05-11 19:58:31 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:58:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:58:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:58:31 --> Helper loaded: form_helper
INFO - 2016-05-11 19:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:58:31 --> Form Validation Class Initialized
INFO - 2016-05-11 19:58:31 --> Controller Class Initialized
INFO - 2016-05-11 19:58:31 --> Model Class Initialized
INFO - 2016-05-11 19:58:31 --> Database Driver Class Initialized
INFO - 2016-05-11 19:58:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:58:31 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:58:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:58:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:58:31 --> Final output sent to browser
DEBUG - 2016-05-11 19:58:31 --> Total execution time: 0.0791
INFO - 2016-05-11 19:58:32 --> Config Class Initialized
INFO - 2016-05-11 19:58:32 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:58:32 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:58:32 --> Utf8 Class Initialized
INFO - 2016-05-11 19:58:32 --> URI Class Initialized
INFO - 2016-05-11 19:58:32 --> Router Class Initialized
INFO - 2016-05-11 19:58:32 --> Output Class Initialized
INFO - 2016-05-11 19:58:32 --> Security Class Initialized
DEBUG - 2016-05-11 19:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:58:32 --> Input Class Initialized
INFO - 2016-05-11 19:58:32 --> Language Class Initialized
INFO - 2016-05-11 19:58:32 --> Loader Class Initialized
INFO - 2016-05-11 19:58:32 --> Helper loaded: url_helper
INFO - 2016-05-11 19:58:32 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:58:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:58:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:58:32 --> Helper loaded: form_helper
INFO - 2016-05-11 19:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:58:32 --> Form Validation Class Initialized
INFO - 2016-05-11 19:58:32 --> Controller Class Initialized
INFO - 2016-05-11 19:58:32 --> Model Class Initialized
INFO - 2016-05-11 19:58:32 --> Database Driver Class Initialized
INFO - 2016-05-11 19:58:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:58:32 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:58:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:58:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:58:32 --> Final output sent to browser
DEBUG - 2016-05-11 19:58:32 --> Total execution time: 0.0863
INFO - 2016-05-11 19:58:34 --> Config Class Initialized
INFO - 2016-05-11 19:58:34 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:58:34 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:58:34 --> Utf8 Class Initialized
INFO - 2016-05-11 19:58:34 --> URI Class Initialized
INFO - 2016-05-11 19:58:34 --> Router Class Initialized
INFO - 2016-05-11 19:58:34 --> Output Class Initialized
INFO - 2016-05-11 19:58:34 --> Security Class Initialized
DEBUG - 2016-05-11 19:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:58:34 --> Input Class Initialized
INFO - 2016-05-11 19:58:34 --> Language Class Initialized
INFO - 2016-05-11 19:58:34 --> Loader Class Initialized
INFO - 2016-05-11 19:58:34 --> Helper loaded: url_helper
INFO - 2016-05-11 19:58:34 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:58:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:58:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:58:34 --> Helper loaded: form_helper
INFO - 2016-05-11 19:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:58:34 --> Form Validation Class Initialized
INFO - 2016-05-11 19:58:34 --> Controller Class Initialized
INFO - 2016-05-11 19:58:34 --> Model Class Initialized
INFO - 2016-05-11 19:58:34 --> Database Driver Class Initialized
INFO - 2016-05-11 19:58:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:58:34 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:58:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:58:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:58:34 --> Final output sent to browser
DEBUG - 2016-05-11 19:58:34 --> Total execution time: 0.0860
INFO - 2016-05-11 19:58:58 --> Config Class Initialized
INFO - 2016-05-11 19:58:58 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:58:58 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:58:58 --> Utf8 Class Initialized
INFO - 2016-05-11 19:58:58 --> URI Class Initialized
DEBUG - 2016-05-11 19:58:58 --> No URI present. Default controller set.
INFO - 2016-05-11 19:58:58 --> Router Class Initialized
INFO - 2016-05-11 19:58:58 --> Output Class Initialized
INFO - 2016-05-11 19:58:58 --> Security Class Initialized
DEBUG - 2016-05-11 19:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:58:58 --> Input Class Initialized
INFO - 2016-05-11 19:58:58 --> Language Class Initialized
INFO - 2016-05-11 19:58:58 --> Loader Class Initialized
INFO - 2016-05-11 19:58:58 --> Helper loaded: url_helper
INFO - 2016-05-11 19:58:58 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:58:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:58:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:58:58 --> Helper loaded: form_helper
INFO - 2016-05-11 19:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:58:58 --> Form Validation Class Initialized
INFO - 2016-05-11 19:58:58 --> Controller Class Initialized
INFO - 2016-05-11 19:58:58 --> Model Class Initialized
INFO - 2016-05-11 19:58:58 --> Database Driver Class Initialized
INFO - 2016-05-11 19:58:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:58:58 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:58:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:58:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:58:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:58:58 --> Final output sent to browser
DEBUG - 2016-05-11 19:58:58 --> Total execution time: 0.0788
INFO - 2016-05-11 19:59:01 --> Config Class Initialized
INFO - 2016-05-11 19:59:01 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:59:01 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:59:01 --> Utf8 Class Initialized
INFO - 2016-05-11 19:59:01 --> URI Class Initialized
INFO - 2016-05-11 19:59:01 --> Router Class Initialized
INFO - 2016-05-11 19:59:01 --> Output Class Initialized
INFO - 2016-05-11 19:59:01 --> Security Class Initialized
DEBUG - 2016-05-11 19:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:59:01 --> Input Class Initialized
INFO - 2016-05-11 19:59:01 --> Language Class Initialized
INFO - 2016-05-11 19:59:01 --> Loader Class Initialized
INFO - 2016-05-11 19:59:01 --> Helper loaded: url_helper
INFO - 2016-05-11 19:59:01 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:59:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:59:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:59:01 --> Helper loaded: form_helper
INFO - 2016-05-11 19:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:59:01 --> Form Validation Class Initialized
INFO - 2016-05-11 19:59:01 --> Controller Class Initialized
INFO - 2016-05-11 19:59:01 --> Model Class Initialized
INFO - 2016-05-11 19:59:01 --> Database Driver Class Initialized
INFO - 2016-05-11 19:59:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:59:01 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:59:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:59:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:59:01 --> Final output sent to browser
DEBUG - 2016-05-11 19:59:01 --> Total execution time: 0.0662
INFO - 2016-05-11 19:59:03 --> Config Class Initialized
INFO - 2016-05-11 19:59:03 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:59:03 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:59:03 --> Utf8 Class Initialized
INFO - 2016-05-11 19:59:03 --> URI Class Initialized
INFO - 2016-05-11 19:59:03 --> Router Class Initialized
INFO - 2016-05-11 19:59:03 --> Output Class Initialized
INFO - 2016-05-11 19:59:03 --> Security Class Initialized
DEBUG - 2016-05-11 19:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:59:03 --> Input Class Initialized
INFO - 2016-05-11 19:59:03 --> Language Class Initialized
INFO - 2016-05-11 19:59:03 --> Loader Class Initialized
INFO - 2016-05-11 19:59:03 --> Helper loaded: url_helper
INFO - 2016-05-11 19:59:03 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:59:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:59:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:59:03 --> Helper loaded: form_helper
INFO - 2016-05-11 19:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:59:03 --> Form Validation Class Initialized
INFO - 2016-05-11 19:59:03 --> Controller Class Initialized
INFO - 2016-05-11 19:59:03 --> Model Class Initialized
INFO - 2016-05-11 19:59:03 --> Database Driver Class Initialized
INFO - 2016-05-11 19:59:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:59:03 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:59:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:59:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:59:03 --> Final output sent to browser
DEBUG - 2016-05-11 19:59:03 --> Total execution time: 0.0955
INFO - 2016-05-11 19:59:40 --> Config Class Initialized
INFO - 2016-05-11 19:59:40 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:59:40 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:59:40 --> Utf8 Class Initialized
INFO - 2016-05-11 19:59:40 --> URI Class Initialized
DEBUG - 2016-05-11 19:59:40 --> No URI present. Default controller set.
INFO - 2016-05-11 19:59:40 --> Router Class Initialized
INFO - 2016-05-11 19:59:40 --> Output Class Initialized
INFO - 2016-05-11 19:59:40 --> Security Class Initialized
DEBUG - 2016-05-11 19:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:59:40 --> Input Class Initialized
INFO - 2016-05-11 19:59:40 --> Language Class Initialized
INFO - 2016-05-11 19:59:40 --> Loader Class Initialized
INFO - 2016-05-11 19:59:40 --> Helper loaded: url_helper
INFO - 2016-05-11 19:59:40 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:59:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:59:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:59:40 --> Helper loaded: form_helper
INFO - 2016-05-11 19:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:59:40 --> Form Validation Class Initialized
INFO - 2016-05-11 19:59:40 --> Controller Class Initialized
INFO - 2016-05-11 19:59:40 --> Model Class Initialized
INFO - 2016-05-11 19:59:40 --> Database Driver Class Initialized
INFO - 2016-05-11 19:59:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:59:40 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:59:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:59:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:59:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 19:59:40 --> Final output sent to browser
DEBUG - 2016-05-11 19:59:40 --> Total execution time: 0.0789
INFO - 2016-05-11 19:59:49 --> Config Class Initialized
INFO - 2016-05-11 19:59:49 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:59:49 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:59:49 --> Utf8 Class Initialized
INFO - 2016-05-11 19:59:49 --> URI Class Initialized
INFO - 2016-05-11 19:59:49 --> Router Class Initialized
INFO - 2016-05-11 19:59:49 --> Output Class Initialized
INFO - 2016-05-11 19:59:49 --> Security Class Initialized
DEBUG - 2016-05-11 19:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:59:49 --> Input Class Initialized
INFO - 2016-05-11 19:59:49 --> Language Class Initialized
INFO - 2016-05-11 19:59:49 --> Loader Class Initialized
INFO - 2016-05-11 19:59:49 --> Helper loaded: url_helper
INFO - 2016-05-11 19:59:49 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:59:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:59:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:59:49 --> Helper loaded: form_helper
INFO - 2016-05-11 19:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:59:49 --> Form Validation Class Initialized
INFO - 2016-05-11 19:59:49 --> Controller Class Initialized
INFO - 2016-05-11 19:59:49 --> Model Class Initialized
INFO - 2016-05-11 19:59:49 --> Database Driver Class Initialized
INFO - 2016-05-11 19:59:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:59:49 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:59:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:59:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:59:49 --> Final output sent to browser
DEBUG - 2016-05-11 19:59:49 --> Total execution time: 0.0779
INFO - 2016-05-11 19:59:51 --> Config Class Initialized
INFO - 2016-05-11 19:59:51 --> Hooks Class Initialized
DEBUG - 2016-05-11 19:59:51 --> UTF-8 Support Enabled
INFO - 2016-05-11 19:59:51 --> Utf8 Class Initialized
INFO - 2016-05-11 19:59:51 --> URI Class Initialized
INFO - 2016-05-11 19:59:51 --> Router Class Initialized
INFO - 2016-05-11 19:59:51 --> Output Class Initialized
INFO - 2016-05-11 19:59:51 --> Security Class Initialized
DEBUG - 2016-05-11 19:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 19:59:51 --> Input Class Initialized
INFO - 2016-05-11 19:59:51 --> Language Class Initialized
INFO - 2016-05-11 19:59:51 --> Loader Class Initialized
INFO - 2016-05-11 19:59:51 --> Helper loaded: url_helper
INFO - 2016-05-11 19:59:51 --> Helper loaded: sesion_helper
INFO - 2016-05-11 19:59:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 19:59:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 19:59:51 --> Helper loaded: form_helper
INFO - 2016-05-11 19:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 19:59:51 --> Form Validation Class Initialized
INFO - 2016-05-11 19:59:51 --> Controller Class Initialized
INFO - 2016-05-11 19:59:51 --> Model Class Initialized
INFO - 2016-05-11 19:59:51 --> Database Driver Class Initialized
INFO - 2016-05-11 19:59:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 19:59:51 --> Pagination Class Initialized
DEBUG - 2016-05-11 19:59:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 19:59:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 19:59:51 --> Final output sent to browser
DEBUG - 2016-05-11 19:59:51 --> Total execution time: 0.0821
INFO - 2016-05-11 20:00:08 --> Config Class Initialized
INFO - 2016-05-11 20:00:08 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:00:08 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:00:08 --> Utf8 Class Initialized
INFO - 2016-05-11 20:00:08 --> URI Class Initialized
DEBUG - 2016-05-11 20:00:08 --> No URI present. Default controller set.
INFO - 2016-05-11 20:00:08 --> Router Class Initialized
INFO - 2016-05-11 20:00:08 --> Output Class Initialized
INFO - 2016-05-11 20:00:08 --> Security Class Initialized
DEBUG - 2016-05-11 20:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:00:08 --> Input Class Initialized
INFO - 2016-05-11 20:00:08 --> Language Class Initialized
INFO - 2016-05-11 20:00:08 --> Loader Class Initialized
INFO - 2016-05-11 20:00:08 --> Helper loaded: url_helper
INFO - 2016-05-11 20:00:08 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:00:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:00:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:00:08 --> Helper loaded: form_helper
INFO - 2016-05-11 20:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:00:08 --> Form Validation Class Initialized
INFO - 2016-05-11 20:00:08 --> Controller Class Initialized
INFO - 2016-05-11 20:00:08 --> Model Class Initialized
INFO - 2016-05-11 20:00:08 --> Database Driver Class Initialized
INFO - 2016-05-11 20:00:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:00:08 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:00:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:00:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:00:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:00:08 --> Final output sent to browser
DEBUG - 2016-05-11 20:00:08 --> Total execution time: 0.0878
INFO - 2016-05-11 20:00:10 --> Config Class Initialized
INFO - 2016-05-11 20:00:10 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:00:10 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:00:10 --> Utf8 Class Initialized
INFO - 2016-05-11 20:00:10 --> URI Class Initialized
DEBUG - 2016-05-11 20:00:10 --> No URI present. Default controller set.
INFO - 2016-05-11 20:00:10 --> Router Class Initialized
INFO - 2016-05-11 20:00:10 --> Output Class Initialized
INFO - 2016-05-11 20:00:10 --> Security Class Initialized
DEBUG - 2016-05-11 20:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:00:10 --> Input Class Initialized
INFO - 2016-05-11 20:00:10 --> Language Class Initialized
INFO - 2016-05-11 20:00:10 --> Loader Class Initialized
INFO - 2016-05-11 20:00:10 --> Helper loaded: url_helper
INFO - 2016-05-11 20:00:10 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:00:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:00:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:00:10 --> Helper loaded: form_helper
INFO - 2016-05-11 20:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:00:10 --> Form Validation Class Initialized
INFO - 2016-05-11 20:00:10 --> Controller Class Initialized
INFO - 2016-05-11 20:00:10 --> Model Class Initialized
INFO - 2016-05-11 20:00:10 --> Database Driver Class Initialized
INFO - 2016-05-11 20:00:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:00:10 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:00:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:00:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:00:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:00:10 --> Final output sent to browser
DEBUG - 2016-05-11 20:00:10 --> Total execution time: 0.0730
INFO - 2016-05-11 20:00:19 --> Config Class Initialized
INFO - 2016-05-11 20:00:19 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:00:19 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:00:19 --> Utf8 Class Initialized
INFO - 2016-05-11 20:00:19 --> URI Class Initialized
DEBUG - 2016-05-11 20:00:19 --> No URI present. Default controller set.
INFO - 2016-05-11 20:00:19 --> Router Class Initialized
INFO - 2016-05-11 20:00:19 --> Output Class Initialized
INFO - 2016-05-11 20:00:19 --> Security Class Initialized
DEBUG - 2016-05-11 20:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:00:19 --> Input Class Initialized
INFO - 2016-05-11 20:00:19 --> Language Class Initialized
INFO - 2016-05-11 20:00:19 --> Loader Class Initialized
INFO - 2016-05-11 20:00:19 --> Helper loaded: url_helper
INFO - 2016-05-11 20:00:19 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:00:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:00:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:00:19 --> Helper loaded: form_helper
INFO - 2016-05-11 20:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:00:19 --> Form Validation Class Initialized
INFO - 2016-05-11 20:00:19 --> Controller Class Initialized
INFO - 2016-05-11 20:00:19 --> Model Class Initialized
INFO - 2016-05-11 20:00:19 --> Database Driver Class Initialized
INFO - 2016-05-11 20:00:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:00:19 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:00:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:00:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:00:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:00:19 --> Final output sent to browser
DEBUG - 2016-05-11 20:00:19 --> Total execution time: 0.0827
INFO - 2016-05-11 20:00:32 --> Config Class Initialized
INFO - 2016-05-11 20:00:32 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:00:32 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:00:32 --> Utf8 Class Initialized
INFO - 2016-05-11 20:00:32 --> URI Class Initialized
DEBUG - 2016-05-11 20:00:32 --> No URI present. Default controller set.
INFO - 2016-05-11 20:00:32 --> Router Class Initialized
INFO - 2016-05-11 20:00:32 --> Output Class Initialized
INFO - 2016-05-11 20:00:32 --> Security Class Initialized
DEBUG - 2016-05-11 20:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:00:32 --> Input Class Initialized
INFO - 2016-05-11 20:00:32 --> Language Class Initialized
INFO - 2016-05-11 20:00:32 --> Loader Class Initialized
INFO - 2016-05-11 20:00:32 --> Helper loaded: url_helper
INFO - 2016-05-11 20:00:32 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:00:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:00:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:00:32 --> Helper loaded: form_helper
INFO - 2016-05-11 20:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:00:32 --> Form Validation Class Initialized
INFO - 2016-05-11 20:00:32 --> Controller Class Initialized
INFO - 2016-05-11 20:00:32 --> Model Class Initialized
INFO - 2016-05-11 20:00:32 --> Database Driver Class Initialized
INFO - 2016-05-11 20:00:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:00:32 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:00:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:00:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:00:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:00:32 --> Final output sent to browser
DEBUG - 2016-05-11 20:00:32 --> Total execution time: 0.0879
INFO - 2016-05-11 20:00:49 --> Config Class Initialized
INFO - 2016-05-11 20:00:49 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:00:49 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:00:49 --> Utf8 Class Initialized
INFO - 2016-05-11 20:00:49 --> URI Class Initialized
INFO - 2016-05-11 20:00:49 --> Router Class Initialized
INFO - 2016-05-11 20:00:49 --> Output Class Initialized
INFO - 2016-05-11 20:00:49 --> Security Class Initialized
DEBUG - 2016-05-11 20:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:00:49 --> Input Class Initialized
INFO - 2016-05-11 20:00:49 --> Language Class Initialized
INFO - 2016-05-11 20:00:49 --> Loader Class Initialized
INFO - 2016-05-11 20:00:49 --> Helper loaded: url_helper
INFO - 2016-05-11 20:00:49 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:00:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:00:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:00:49 --> Helper loaded: form_helper
INFO - 2016-05-11 20:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:00:49 --> Form Validation Class Initialized
INFO - 2016-05-11 20:00:49 --> Controller Class Initialized
INFO - 2016-05-11 20:00:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-11 20:00:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 20:00:49 --> Final output sent to browser
DEBUG - 2016-05-11 20:00:49 --> Total execution time: 0.0570
INFO - 2016-05-11 20:00:50 --> Config Class Initialized
INFO - 2016-05-11 20:00:50 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:00:50 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:00:50 --> Utf8 Class Initialized
INFO - 2016-05-11 20:00:50 --> URI Class Initialized
INFO - 2016-05-11 20:00:50 --> Router Class Initialized
INFO - 2016-05-11 20:00:50 --> Output Class Initialized
INFO - 2016-05-11 20:00:50 --> Security Class Initialized
DEBUG - 2016-05-11 20:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:00:50 --> Input Class Initialized
INFO - 2016-05-11 20:00:50 --> Language Class Initialized
INFO - 2016-05-11 20:00:50 --> Loader Class Initialized
INFO - 2016-05-11 20:00:50 --> Helper loaded: url_helper
INFO - 2016-05-11 20:00:50 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:00:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:00:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:00:50 --> Helper loaded: form_helper
INFO - 2016-05-11 20:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:00:50 --> Form Validation Class Initialized
INFO - 2016-05-11 20:00:50 --> Controller Class Initialized
INFO - 2016-05-11 20:00:50 --> Model Class Initialized
INFO - 2016-05-11 20:00:50 --> Database Driver Class Initialized
INFO - 2016-05-11 20:00:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:00:50 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:00:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:00:50 --> Final output sent to browser
DEBUG - 2016-05-11 20:00:50 --> Total execution time: 0.1144
INFO - 2016-05-11 20:00:58 --> Config Class Initialized
INFO - 2016-05-11 20:00:58 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:00:58 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:00:58 --> Utf8 Class Initialized
INFO - 2016-05-11 20:00:58 --> URI Class Initialized
DEBUG - 2016-05-11 20:00:58 --> No URI present. Default controller set.
INFO - 2016-05-11 20:00:58 --> Router Class Initialized
INFO - 2016-05-11 20:00:58 --> Output Class Initialized
INFO - 2016-05-11 20:00:58 --> Security Class Initialized
DEBUG - 2016-05-11 20:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:00:58 --> Input Class Initialized
INFO - 2016-05-11 20:00:58 --> Language Class Initialized
INFO - 2016-05-11 20:00:58 --> Loader Class Initialized
INFO - 2016-05-11 20:00:58 --> Helper loaded: url_helper
INFO - 2016-05-11 20:00:58 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:00:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:00:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:00:58 --> Helper loaded: form_helper
INFO - 2016-05-11 20:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:00:58 --> Form Validation Class Initialized
INFO - 2016-05-11 20:00:58 --> Controller Class Initialized
INFO - 2016-05-11 20:00:58 --> Model Class Initialized
INFO - 2016-05-11 20:00:58 --> Database Driver Class Initialized
INFO - 2016-05-11 20:00:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:00:58 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:00:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:00:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:00:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:00:58 --> Final output sent to browser
DEBUG - 2016-05-11 20:00:58 --> Total execution time: 0.0786
INFO - 2016-05-11 20:01:00 --> Config Class Initialized
INFO - 2016-05-11 20:01:00 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:01:00 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:01:00 --> Utf8 Class Initialized
INFO - 2016-05-11 20:01:00 --> URI Class Initialized
INFO - 2016-05-11 20:01:00 --> Router Class Initialized
INFO - 2016-05-11 20:01:00 --> Output Class Initialized
INFO - 2016-05-11 20:01:00 --> Security Class Initialized
DEBUG - 2016-05-11 20:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:01:00 --> Input Class Initialized
INFO - 2016-05-11 20:01:00 --> Language Class Initialized
INFO - 2016-05-11 20:01:00 --> Loader Class Initialized
INFO - 2016-05-11 20:01:00 --> Helper loaded: url_helper
INFO - 2016-05-11 20:01:00 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:01:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:01:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:01:00 --> Helper loaded: form_helper
INFO - 2016-05-11 20:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:01:00 --> Form Validation Class Initialized
INFO - 2016-05-11 20:01:00 --> Controller Class Initialized
INFO - 2016-05-11 20:01:00 --> Model Class Initialized
INFO - 2016-05-11 20:01:00 --> Database Driver Class Initialized
INFO - 2016-05-11 20:01:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:01:00 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:01:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:01:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:01:00 --> Final output sent to browser
DEBUG - 2016-05-11 20:01:00 --> Total execution time: 0.0840
INFO - 2016-05-11 20:01:02 --> Config Class Initialized
INFO - 2016-05-11 20:01:02 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:01:02 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:01:02 --> Utf8 Class Initialized
INFO - 2016-05-11 20:01:02 --> URI Class Initialized
INFO - 2016-05-11 20:01:02 --> Router Class Initialized
INFO - 2016-05-11 20:01:02 --> Output Class Initialized
INFO - 2016-05-11 20:01:02 --> Security Class Initialized
DEBUG - 2016-05-11 20:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:01:02 --> Input Class Initialized
INFO - 2016-05-11 20:01:02 --> Language Class Initialized
INFO - 2016-05-11 20:01:02 --> Loader Class Initialized
INFO - 2016-05-11 20:01:02 --> Helper loaded: url_helper
INFO - 2016-05-11 20:01:02 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:01:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:01:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:01:02 --> Helper loaded: form_helper
INFO - 2016-05-11 20:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:01:02 --> Form Validation Class Initialized
INFO - 2016-05-11 20:01:02 --> Controller Class Initialized
INFO - 2016-05-11 20:01:02 --> Model Class Initialized
INFO - 2016-05-11 20:01:02 --> Database Driver Class Initialized
INFO - 2016-05-11 20:01:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:01:02 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:01:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:01:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:01:02 --> Final output sent to browser
DEBUG - 2016-05-11 20:01:02 --> Total execution time: 0.0954
INFO - 2016-05-11 20:01:11 --> Config Class Initialized
INFO - 2016-05-11 20:01:11 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:01:11 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:01:11 --> Utf8 Class Initialized
INFO - 2016-05-11 20:01:11 --> URI Class Initialized
INFO - 2016-05-11 20:01:11 --> Router Class Initialized
INFO - 2016-05-11 20:01:11 --> Output Class Initialized
INFO - 2016-05-11 20:01:11 --> Security Class Initialized
DEBUG - 2016-05-11 20:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:01:11 --> Input Class Initialized
INFO - 2016-05-11 20:01:11 --> Language Class Initialized
INFO - 2016-05-11 20:01:11 --> Loader Class Initialized
INFO - 2016-05-11 20:01:11 --> Helper loaded: url_helper
INFO - 2016-05-11 20:01:11 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:01:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:01:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:01:11 --> Helper loaded: form_helper
INFO - 2016-05-11 20:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:01:11 --> Form Validation Class Initialized
INFO - 2016-05-11 20:01:11 --> Controller Class Initialized
INFO - 2016-05-11 20:01:11 --> Model Class Initialized
INFO - 2016-05-11 20:01:11 --> Database Driver Class Initialized
INFO - 2016-05-11 20:01:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:01:11 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:01:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:01:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-11 20:01:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 20:01:11 --> Final output sent to browser
DEBUG - 2016-05-11 20:01:11 --> Total execution time: 0.0744
INFO - 2016-05-11 20:01:11 --> Config Class Initialized
INFO - 2016-05-11 20:01:11 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:01:11 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:01:11 --> Utf8 Class Initialized
INFO - 2016-05-11 20:01:11 --> URI Class Initialized
INFO - 2016-05-11 20:01:11 --> Router Class Initialized
INFO - 2016-05-11 20:01:11 --> Output Class Initialized
INFO - 2016-05-11 20:01:11 --> Security Class Initialized
DEBUG - 2016-05-11 20:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:01:11 --> Input Class Initialized
INFO - 2016-05-11 20:01:11 --> Language Class Initialized
INFO - 2016-05-11 20:01:11 --> Loader Class Initialized
INFO - 2016-05-11 20:01:11 --> Helper loaded: url_helper
INFO - 2016-05-11 20:01:11 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:01:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:01:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:01:11 --> Helper loaded: form_helper
INFO - 2016-05-11 20:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:01:11 --> Form Validation Class Initialized
INFO - 2016-05-11 20:01:11 --> Controller Class Initialized
INFO - 2016-05-11 20:01:11 --> Model Class Initialized
INFO - 2016-05-11 20:01:11 --> Database Driver Class Initialized
INFO - 2016-05-11 20:01:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:01:12 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:01:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:01:12 --> Final output sent to browser
DEBUG - 2016-05-11 20:01:12 --> Total execution time: 0.1007
INFO - 2016-05-11 20:01:52 --> Config Class Initialized
INFO - 2016-05-11 20:01:52 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:01:52 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:01:52 --> Utf8 Class Initialized
INFO - 2016-05-11 20:01:52 --> URI Class Initialized
INFO - 2016-05-11 20:01:52 --> Router Class Initialized
INFO - 2016-05-11 20:01:52 --> Output Class Initialized
INFO - 2016-05-11 20:01:52 --> Security Class Initialized
DEBUG - 2016-05-11 20:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:01:52 --> Input Class Initialized
INFO - 2016-05-11 20:01:52 --> Language Class Initialized
INFO - 2016-05-11 20:01:52 --> Loader Class Initialized
INFO - 2016-05-11 20:01:52 --> Helper loaded: url_helper
INFO - 2016-05-11 20:01:52 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:01:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:01:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:01:52 --> Helper loaded: form_helper
INFO - 2016-05-11 20:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:01:52 --> Form Validation Class Initialized
INFO - 2016-05-11 20:01:52 --> Controller Class Initialized
INFO - 2016-05-11 20:01:52 --> Model Class Initialized
INFO - 2016-05-11 20:01:52 --> Database Driver Class Initialized
INFO - 2016-05-11 20:01:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:01:52 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:01:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:01:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-11 20:01:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 20:01:52 --> Final output sent to browser
DEBUG - 2016-05-11 20:01:52 --> Total execution time: 0.0783
INFO - 2016-05-11 20:01:53 --> Config Class Initialized
INFO - 2016-05-11 20:01:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:01:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:01:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:01:53 --> URI Class Initialized
INFO - 2016-05-11 20:01:53 --> Router Class Initialized
INFO - 2016-05-11 20:01:53 --> Output Class Initialized
INFO - 2016-05-11 20:01:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:01:53 --> Input Class Initialized
INFO - 2016-05-11 20:01:53 --> Language Class Initialized
INFO - 2016-05-11 20:01:53 --> Loader Class Initialized
INFO - 2016-05-11 20:01:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:01:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:01:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:01:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:01:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:01:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:01:53 --> Controller Class Initialized
INFO - 2016-05-11 20:01:53 --> Model Class Initialized
INFO - 2016-05-11 20:01:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:01:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:01:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:01:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:01:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:01:53 --> Total execution time: 0.1103
INFO - 2016-05-11 20:01:58 --> Config Class Initialized
INFO - 2016-05-11 20:01:58 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:01:58 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:01:58 --> Utf8 Class Initialized
INFO - 2016-05-11 20:01:58 --> URI Class Initialized
DEBUG - 2016-05-11 20:01:58 --> No URI present. Default controller set.
INFO - 2016-05-11 20:01:58 --> Router Class Initialized
INFO - 2016-05-11 20:01:58 --> Output Class Initialized
INFO - 2016-05-11 20:01:58 --> Security Class Initialized
DEBUG - 2016-05-11 20:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:01:58 --> Input Class Initialized
INFO - 2016-05-11 20:01:58 --> Language Class Initialized
INFO - 2016-05-11 20:01:58 --> Loader Class Initialized
INFO - 2016-05-11 20:01:58 --> Helper loaded: url_helper
INFO - 2016-05-11 20:01:58 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:01:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:01:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:01:58 --> Helper loaded: form_helper
INFO - 2016-05-11 20:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:01:58 --> Form Validation Class Initialized
INFO - 2016-05-11 20:01:58 --> Controller Class Initialized
INFO - 2016-05-11 20:01:58 --> Model Class Initialized
INFO - 2016-05-11 20:01:58 --> Database Driver Class Initialized
INFO - 2016-05-11 20:01:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:01:58 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:01:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:01:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:01:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:01:58 --> Final output sent to browser
DEBUG - 2016-05-11 20:01:58 --> Total execution time: 0.0788
INFO - 2016-05-11 20:02:01 --> Config Class Initialized
INFO - 2016-05-11 20:02:01 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:02:01 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:02:01 --> Utf8 Class Initialized
INFO - 2016-05-11 20:02:01 --> URI Class Initialized
INFO - 2016-05-11 20:02:01 --> Router Class Initialized
INFO - 2016-05-11 20:02:01 --> Output Class Initialized
INFO - 2016-05-11 20:02:01 --> Security Class Initialized
DEBUG - 2016-05-11 20:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:02:01 --> Input Class Initialized
INFO - 2016-05-11 20:02:01 --> Language Class Initialized
INFO - 2016-05-11 20:02:01 --> Loader Class Initialized
INFO - 2016-05-11 20:02:01 --> Helper loaded: url_helper
INFO - 2016-05-11 20:02:01 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:02:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:02:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:02:01 --> Helper loaded: form_helper
INFO - 2016-05-11 20:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:02:02 --> Form Validation Class Initialized
INFO - 2016-05-11 20:02:02 --> Controller Class Initialized
INFO - 2016-05-11 20:02:02 --> Model Class Initialized
INFO - 2016-05-11 20:02:02 --> Database Driver Class Initialized
INFO - 2016-05-11 20:02:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:02:02 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:02:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:02:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:02:02 --> Final output sent to browser
DEBUG - 2016-05-11 20:02:02 --> Total execution time: 0.0763
INFO - 2016-05-11 20:02:03 --> Config Class Initialized
INFO - 2016-05-11 20:02:03 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:02:03 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:02:03 --> Utf8 Class Initialized
INFO - 2016-05-11 20:02:03 --> URI Class Initialized
INFO - 2016-05-11 20:02:03 --> Router Class Initialized
INFO - 2016-05-11 20:02:03 --> Output Class Initialized
INFO - 2016-05-11 20:02:03 --> Security Class Initialized
DEBUG - 2016-05-11 20:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:02:03 --> Input Class Initialized
INFO - 2016-05-11 20:02:03 --> Language Class Initialized
INFO - 2016-05-11 20:02:03 --> Loader Class Initialized
INFO - 2016-05-11 20:02:03 --> Helper loaded: url_helper
INFO - 2016-05-11 20:02:03 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:02:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:02:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:02:03 --> Helper loaded: form_helper
INFO - 2016-05-11 20:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:02:03 --> Form Validation Class Initialized
INFO - 2016-05-11 20:02:03 --> Controller Class Initialized
INFO - 2016-05-11 20:02:03 --> Model Class Initialized
INFO - 2016-05-11 20:02:03 --> Database Driver Class Initialized
INFO - 2016-05-11 20:02:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:02:03 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:02:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:02:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:02:03 --> Final output sent to browser
DEBUG - 2016-05-11 20:02:03 --> Total execution time: 0.0964
INFO - 2016-05-11 20:02:05 --> Config Class Initialized
INFO - 2016-05-11 20:02:05 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:02:05 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:02:05 --> Utf8 Class Initialized
INFO - 2016-05-11 20:02:05 --> URI Class Initialized
INFO - 2016-05-11 20:02:05 --> Router Class Initialized
INFO - 2016-05-11 20:02:05 --> Output Class Initialized
INFO - 2016-05-11 20:02:05 --> Security Class Initialized
DEBUG - 2016-05-11 20:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:02:05 --> Input Class Initialized
INFO - 2016-05-11 20:02:05 --> Language Class Initialized
INFO - 2016-05-11 20:02:05 --> Loader Class Initialized
INFO - 2016-05-11 20:02:05 --> Helper loaded: url_helper
INFO - 2016-05-11 20:02:05 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:02:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:02:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:02:05 --> Helper loaded: form_helper
INFO - 2016-05-11 20:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:02:05 --> Form Validation Class Initialized
INFO - 2016-05-11 20:02:05 --> Controller Class Initialized
INFO - 2016-05-11 20:02:05 --> Model Class Initialized
INFO - 2016-05-11 20:02:05 --> Database Driver Class Initialized
INFO - 2016-05-11 20:02:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:02:05 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:02:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:02:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:02:05 --> Final output sent to browser
DEBUG - 2016-05-11 20:02:05 --> Total execution time: 0.0828
INFO - 2016-05-11 20:02:06 --> Config Class Initialized
INFO - 2016-05-11 20:02:06 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:02:06 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:02:06 --> Utf8 Class Initialized
INFO - 2016-05-11 20:02:06 --> URI Class Initialized
INFO - 2016-05-11 20:02:06 --> Router Class Initialized
INFO - 2016-05-11 20:02:06 --> Output Class Initialized
INFO - 2016-05-11 20:02:06 --> Security Class Initialized
DEBUG - 2016-05-11 20:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:02:06 --> Input Class Initialized
INFO - 2016-05-11 20:02:06 --> Language Class Initialized
INFO - 2016-05-11 20:02:06 --> Loader Class Initialized
INFO - 2016-05-11 20:02:06 --> Helper loaded: url_helper
INFO - 2016-05-11 20:02:06 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:02:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:02:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:02:06 --> Helper loaded: form_helper
INFO - 2016-05-11 20:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:02:06 --> Form Validation Class Initialized
INFO - 2016-05-11 20:02:06 --> Controller Class Initialized
INFO - 2016-05-11 20:02:06 --> Model Class Initialized
INFO - 2016-05-11 20:02:06 --> Database Driver Class Initialized
INFO - 2016-05-11 20:02:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:02:06 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:02:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:02:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:02:06 --> Final output sent to browser
DEBUG - 2016-05-11 20:02:06 --> Total execution time: 0.0841
INFO - 2016-05-11 20:02:08 --> Config Class Initialized
INFO - 2016-05-11 20:02:08 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:02:08 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:02:08 --> Utf8 Class Initialized
INFO - 2016-05-11 20:02:08 --> URI Class Initialized
INFO - 2016-05-11 20:02:08 --> Router Class Initialized
INFO - 2016-05-11 20:02:08 --> Output Class Initialized
INFO - 2016-05-11 20:02:08 --> Security Class Initialized
DEBUG - 2016-05-11 20:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:02:08 --> Input Class Initialized
INFO - 2016-05-11 20:02:08 --> Language Class Initialized
INFO - 2016-05-11 20:02:08 --> Loader Class Initialized
INFO - 2016-05-11 20:02:08 --> Helper loaded: url_helper
INFO - 2016-05-11 20:02:08 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:02:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:02:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:02:08 --> Helper loaded: form_helper
INFO - 2016-05-11 20:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:02:08 --> Form Validation Class Initialized
INFO - 2016-05-11 20:02:08 --> Controller Class Initialized
INFO - 2016-05-11 20:02:08 --> Model Class Initialized
INFO - 2016-05-11 20:02:08 --> Database Driver Class Initialized
INFO - 2016-05-11 20:02:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:02:08 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:02:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:02:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:02:08 --> Final output sent to browser
DEBUG - 2016-05-11 20:02:08 --> Total execution time: 0.0761
INFO - 2016-05-11 20:02:10 --> Config Class Initialized
INFO - 2016-05-11 20:02:10 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:02:10 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:02:10 --> Utf8 Class Initialized
INFO - 2016-05-11 20:02:10 --> URI Class Initialized
INFO - 2016-05-11 20:02:10 --> Router Class Initialized
INFO - 2016-05-11 20:02:10 --> Output Class Initialized
INFO - 2016-05-11 20:02:10 --> Security Class Initialized
DEBUG - 2016-05-11 20:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:02:10 --> Input Class Initialized
INFO - 2016-05-11 20:02:10 --> Language Class Initialized
INFO - 2016-05-11 20:02:10 --> Loader Class Initialized
INFO - 2016-05-11 20:02:10 --> Helper loaded: url_helper
INFO - 2016-05-11 20:02:10 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:02:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:02:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:02:10 --> Helper loaded: form_helper
INFO - 2016-05-11 20:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:02:10 --> Form Validation Class Initialized
INFO - 2016-05-11 20:02:10 --> Controller Class Initialized
INFO - 2016-05-11 20:02:10 --> Model Class Initialized
INFO - 2016-05-11 20:02:10 --> Database Driver Class Initialized
INFO - 2016-05-11 20:02:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:02:10 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:02:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:02:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:02:10 --> Final output sent to browser
DEBUG - 2016-05-11 20:02:10 --> Total execution time: 0.0818
INFO - 2016-05-11 20:02:12 --> Config Class Initialized
INFO - 2016-05-11 20:02:12 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:02:12 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:02:12 --> Utf8 Class Initialized
INFO - 2016-05-11 20:02:12 --> URI Class Initialized
INFO - 2016-05-11 20:02:12 --> Router Class Initialized
INFO - 2016-05-11 20:02:12 --> Output Class Initialized
INFO - 2016-05-11 20:02:12 --> Security Class Initialized
DEBUG - 2016-05-11 20:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:02:12 --> Input Class Initialized
INFO - 2016-05-11 20:02:12 --> Language Class Initialized
INFO - 2016-05-11 20:02:12 --> Loader Class Initialized
INFO - 2016-05-11 20:02:12 --> Helper loaded: url_helper
INFO - 2016-05-11 20:02:12 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:02:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:02:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:02:12 --> Helper loaded: form_helper
INFO - 2016-05-11 20:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:02:12 --> Form Validation Class Initialized
INFO - 2016-05-11 20:02:12 --> Controller Class Initialized
INFO - 2016-05-11 20:02:12 --> Model Class Initialized
INFO - 2016-05-11 20:02:12 --> Database Driver Class Initialized
INFO - 2016-05-11 20:02:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:02:12 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:02:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:02:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:02:12 --> Final output sent to browser
DEBUG - 2016-05-11 20:02:12 --> Total execution time: 0.0997
INFO - 2016-05-11 20:02:14 --> Config Class Initialized
INFO - 2016-05-11 20:02:14 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:02:14 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:02:14 --> Utf8 Class Initialized
INFO - 2016-05-11 20:02:14 --> URI Class Initialized
INFO - 2016-05-11 20:02:14 --> Router Class Initialized
INFO - 2016-05-11 20:02:14 --> Output Class Initialized
INFO - 2016-05-11 20:02:14 --> Security Class Initialized
DEBUG - 2016-05-11 20:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:02:14 --> Input Class Initialized
INFO - 2016-05-11 20:02:14 --> Language Class Initialized
INFO - 2016-05-11 20:02:14 --> Loader Class Initialized
INFO - 2016-05-11 20:02:14 --> Helper loaded: url_helper
INFO - 2016-05-11 20:02:14 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:02:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:02:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:02:14 --> Helper loaded: form_helper
INFO - 2016-05-11 20:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:02:14 --> Form Validation Class Initialized
INFO - 2016-05-11 20:02:14 --> Controller Class Initialized
INFO - 2016-05-11 20:02:14 --> Model Class Initialized
INFO - 2016-05-11 20:02:14 --> Database Driver Class Initialized
INFO - 2016-05-11 20:02:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:02:14 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:02:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:02:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:02:14 --> Final output sent to browser
DEBUG - 2016-05-11 20:02:14 --> Total execution time: 0.0856
INFO - 2016-05-11 20:02:53 --> Config Class Initialized
INFO - 2016-05-11 20:02:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:02:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:02:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:02:53 --> URI Class Initialized
INFO - 2016-05-11 20:02:53 --> Router Class Initialized
INFO - 2016-05-11 20:02:53 --> Output Class Initialized
INFO - 2016-05-11 20:02:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:02:53 --> Input Class Initialized
INFO - 2016-05-11 20:02:53 --> Language Class Initialized
INFO - 2016-05-11 20:02:53 --> Loader Class Initialized
INFO - 2016-05-11 20:02:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:02:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:02:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:02:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:02:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:02:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:02:53 --> Controller Class Initialized
INFO - 2016-05-11 20:02:53 --> Model Class Initialized
INFO - 2016-05-11 20:02:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:02:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:02:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:02:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:02:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:02:53 --> Total execution time: 0.0752
INFO - 2016-05-11 20:03:01 --> Config Class Initialized
INFO - 2016-05-11 20:03:01 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:03:01 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:03:01 --> Utf8 Class Initialized
INFO - 2016-05-11 20:03:01 --> URI Class Initialized
INFO - 2016-05-11 20:03:01 --> Router Class Initialized
INFO - 2016-05-11 20:03:01 --> Output Class Initialized
INFO - 2016-05-11 20:03:01 --> Security Class Initialized
DEBUG - 2016-05-11 20:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:03:01 --> Input Class Initialized
INFO - 2016-05-11 20:03:01 --> Language Class Initialized
INFO - 2016-05-11 20:03:01 --> Loader Class Initialized
INFO - 2016-05-11 20:03:01 --> Helper loaded: url_helper
INFO - 2016-05-11 20:03:01 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:03:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:03:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:03:01 --> Helper loaded: form_helper
INFO - 2016-05-11 20:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:03:01 --> Form Validation Class Initialized
INFO - 2016-05-11 20:03:01 --> Controller Class Initialized
INFO - 2016-05-11 20:03:01 --> Model Class Initialized
INFO - 2016-05-11 20:03:01 --> Database Driver Class Initialized
INFO - 2016-05-11 20:03:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:03:01 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:03:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:03:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:03:01 --> Final output sent to browser
DEBUG - 2016-05-11 20:03:01 --> Total execution time: 0.0827
INFO - 2016-05-11 20:03:53 --> Config Class Initialized
INFO - 2016-05-11 20:03:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:03:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:03:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:03:53 --> URI Class Initialized
INFO - 2016-05-11 20:03:53 --> Router Class Initialized
INFO - 2016-05-11 20:03:53 --> Output Class Initialized
INFO - 2016-05-11 20:03:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:03:53 --> Input Class Initialized
INFO - 2016-05-11 20:03:53 --> Language Class Initialized
INFO - 2016-05-11 20:03:53 --> Loader Class Initialized
INFO - 2016-05-11 20:03:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:03:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:03:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:03:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:03:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:03:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:03:53 --> Controller Class Initialized
INFO - 2016-05-11 20:03:53 --> Model Class Initialized
INFO - 2016-05-11 20:03:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:03:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:03:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:03:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:03:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:03:53 --> Total execution time: 0.0736
INFO - 2016-05-11 20:04:20 --> Config Class Initialized
INFO - 2016-05-11 20:04:20 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:04:20 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:04:20 --> Utf8 Class Initialized
INFO - 2016-05-11 20:04:20 --> URI Class Initialized
DEBUG - 2016-05-11 20:04:20 --> No URI present. Default controller set.
INFO - 2016-05-11 20:04:20 --> Router Class Initialized
INFO - 2016-05-11 20:04:20 --> Output Class Initialized
INFO - 2016-05-11 20:04:20 --> Security Class Initialized
DEBUG - 2016-05-11 20:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:04:20 --> Input Class Initialized
INFO - 2016-05-11 20:04:20 --> Language Class Initialized
INFO - 2016-05-11 20:04:20 --> Loader Class Initialized
INFO - 2016-05-11 20:04:20 --> Helper loaded: url_helper
INFO - 2016-05-11 20:04:20 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:04:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:04:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:04:20 --> Helper loaded: form_helper
INFO - 2016-05-11 20:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:04:20 --> Form Validation Class Initialized
INFO - 2016-05-11 20:04:20 --> Controller Class Initialized
INFO - 2016-05-11 20:04:20 --> Model Class Initialized
INFO - 2016-05-11 20:04:20 --> Database Driver Class Initialized
INFO - 2016-05-11 20:04:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:04:20 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:04:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:04:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:04:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:04:20 --> Final output sent to browser
DEBUG - 2016-05-11 20:04:20 --> Total execution time: 0.0798
INFO - 2016-05-11 20:04:24 --> Config Class Initialized
INFO - 2016-05-11 20:04:24 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:04:24 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:04:24 --> Utf8 Class Initialized
INFO - 2016-05-11 20:04:24 --> URI Class Initialized
INFO - 2016-05-11 20:04:24 --> Router Class Initialized
INFO - 2016-05-11 20:04:24 --> Output Class Initialized
INFO - 2016-05-11 20:04:24 --> Security Class Initialized
DEBUG - 2016-05-11 20:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:04:24 --> Input Class Initialized
INFO - 2016-05-11 20:04:24 --> Language Class Initialized
INFO - 2016-05-11 20:04:24 --> Loader Class Initialized
INFO - 2016-05-11 20:04:24 --> Helper loaded: url_helper
INFO - 2016-05-11 20:04:24 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:04:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:04:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:04:24 --> Helper loaded: form_helper
INFO - 2016-05-11 20:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:04:24 --> Form Validation Class Initialized
INFO - 2016-05-11 20:04:24 --> Controller Class Initialized
INFO - 2016-05-11 20:04:24 --> Model Class Initialized
INFO - 2016-05-11 20:04:24 --> Database Driver Class Initialized
INFO - 2016-05-11 20:04:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:04:24 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:04:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:04:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:04:24 --> Final output sent to browser
DEBUG - 2016-05-11 20:04:24 --> Total execution time: 0.0743
INFO - 2016-05-11 20:04:27 --> Config Class Initialized
INFO - 2016-05-11 20:04:27 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:04:27 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:04:27 --> Utf8 Class Initialized
INFO - 2016-05-11 20:04:27 --> URI Class Initialized
INFO - 2016-05-11 20:04:27 --> Router Class Initialized
INFO - 2016-05-11 20:04:27 --> Output Class Initialized
INFO - 2016-05-11 20:04:27 --> Security Class Initialized
DEBUG - 2016-05-11 20:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:04:27 --> Input Class Initialized
INFO - 2016-05-11 20:04:27 --> Language Class Initialized
INFO - 2016-05-11 20:04:27 --> Loader Class Initialized
INFO - 2016-05-11 20:04:27 --> Helper loaded: url_helper
INFO - 2016-05-11 20:04:27 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:04:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:04:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:04:27 --> Helper loaded: form_helper
INFO - 2016-05-11 20:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:04:27 --> Form Validation Class Initialized
INFO - 2016-05-11 20:04:27 --> Controller Class Initialized
INFO - 2016-05-11 20:04:27 --> Model Class Initialized
INFO - 2016-05-11 20:04:27 --> Database Driver Class Initialized
INFO - 2016-05-11 20:04:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:04:27 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:04:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:04:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:04:27 --> Final output sent to browser
DEBUG - 2016-05-11 20:04:27 --> Total execution time: 0.0868
INFO - 2016-05-11 20:04:48 --> Config Class Initialized
INFO - 2016-05-11 20:04:48 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:04:48 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:04:48 --> Utf8 Class Initialized
INFO - 2016-05-11 20:04:48 --> URI Class Initialized
DEBUG - 2016-05-11 20:04:48 --> No URI present. Default controller set.
INFO - 2016-05-11 20:04:48 --> Router Class Initialized
INFO - 2016-05-11 20:04:48 --> Output Class Initialized
INFO - 2016-05-11 20:04:48 --> Security Class Initialized
DEBUG - 2016-05-11 20:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:04:48 --> Input Class Initialized
INFO - 2016-05-11 20:04:48 --> Language Class Initialized
INFO - 2016-05-11 20:04:48 --> Loader Class Initialized
INFO - 2016-05-11 20:04:48 --> Helper loaded: url_helper
INFO - 2016-05-11 20:04:48 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:04:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:04:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:04:48 --> Helper loaded: form_helper
INFO - 2016-05-11 20:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:04:48 --> Form Validation Class Initialized
INFO - 2016-05-11 20:04:48 --> Controller Class Initialized
INFO - 2016-05-11 20:04:48 --> Model Class Initialized
INFO - 2016-05-11 20:04:48 --> Database Driver Class Initialized
INFO - 2016-05-11 20:04:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:04:48 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:04:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:04:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:04:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:04:48 --> Final output sent to browser
DEBUG - 2016-05-11 20:04:48 --> Total execution time: 0.0731
INFO - 2016-05-11 20:04:52 --> Config Class Initialized
INFO - 2016-05-11 20:04:52 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:04:52 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:04:52 --> Utf8 Class Initialized
INFO - 2016-05-11 20:04:52 --> URI Class Initialized
INFO - 2016-05-11 20:04:52 --> Router Class Initialized
INFO - 2016-05-11 20:04:52 --> Output Class Initialized
INFO - 2016-05-11 20:04:52 --> Security Class Initialized
DEBUG - 2016-05-11 20:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:04:52 --> Input Class Initialized
INFO - 2016-05-11 20:04:52 --> Language Class Initialized
INFO - 2016-05-11 20:04:52 --> Loader Class Initialized
INFO - 2016-05-11 20:04:52 --> Helper loaded: url_helper
INFO - 2016-05-11 20:04:52 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:04:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:04:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:04:52 --> Helper loaded: form_helper
INFO - 2016-05-11 20:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:04:52 --> Form Validation Class Initialized
INFO - 2016-05-11 20:04:52 --> Controller Class Initialized
INFO - 2016-05-11 20:04:52 --> Model Class Initialized
INFO - 2016-05-11 20:04:52 --> Database Driver Class Initialized
INFO - 2016-05-11 20:04:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:04:52 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:04:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:04:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:04:52 --> Final output sent to browser
DEBUG - 2016-05-11 20:04:52 --> Total execution time: 0.0776
INFO - 2016-05-11 20:04:53 --> Config Class Initialized
INFO - 2016-05-11 20:04:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:04:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:04:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:04:53 --> URI Class Initialized
INFO - 2016-05-11 20:04:53 --> Router Class Initialized
INFO - 2016-05-11 20:04:53 --> Output Class Initialized
INFO - 2016-05-11 20:04:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:04:53 --> Input Class Initialized
INFO - 2016-05-11 20:04:53 --> Language Class Initialized
INFO - 2016-05-11 20:04:53 --> Loader Class Initialized
INFO - 2016-05-11 20:04:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:04:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:04:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:04:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:04:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:04:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:04:53 --> Controller Class Initialized
INFO - 2016-05-11 20:04:53 --> Model Class Initialized
INFO - 2016-05-11 20:04:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:04:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:04:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:04:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:04:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:04:53 --> Total execution time: 0.0761
INFO - 2016-05-11 20:05:53 --> Config Class Initialized
INFO - 2016-05-11 20:05:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:05:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:05:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:05:53 --> URI Class Initialized
INFO - 2016-05-11 20:05:53 --> Router Class Initialized
INFO - 2016-05-11 20:05:53 --> Output Class Initialized
INFO - 2016-05-11 20:05:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:05:53 --> Input Class Initialized
INFO - 2016-05-11 20:05:53 --> Language Class Initialized
INFO - 2016-05-11 20:05:53 --> Loader Class Initialized
INFO - 2016-05-11 20:05:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:05:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:05:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:05:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:05:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:05:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:05:53 --> Controller Class Initialized
INFO - 2016-05-11 20:05:53 --> Model Class Initialized
INFO - 2016-05-11 20:05:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:05:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:05:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:05:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:05:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:05:53 --> Total execution time: 0.0736
INFO - 2016-05-11 20:06:25 --> Config Class Initialized
INFO - 2016-05-11 20:06:25 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:06:25 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:06:25 --> Utf8 Class Initialized
INFO - 2016-05-11 20:06:25 --> URI Class Initialized
INFO - 2016-05-11 20:06:25 --> Router Class Initialized
INFO - 2016-05-11 20:06:25 --> Output Class Initialized
INFO - 2016-05-11 20:06:25 --> Security Class Initialized
DEBUG - 2016-05-11 20:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:06:25 --> Input Class Initialized
INFO - 2016-05-11 20:06:25 --> Language Class Initialized
INFO - 2016-05-11 20:06:25 --> Loader Class Initialized
INFO - 2016-05-11 20:06:25 --> Helper loaded: url_helper
INFO - 2016-05-11 20:06:25 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:06:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:06:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:06:25 --> Helper loaded: form_helper
INFO - 2016-05-11 20:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:06:25 --> Form Validation Class Initialized
INFO - 2016-05-11 20:06:25 --> Controller Class Initialized
INFO - 2016-05-11 20:06:25 --> Model Class Initialized
INFO - 2016-05-11 20:06:25 --> Database Driver Class Initialized
INFO - 2016-05-11 20:06:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:06:25 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:06:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:06:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:06:25 --> Final output sent to browser
DEBUG - 2016-05-11 20:06:25 --> Total execution time: 0.1034
INFO - 2016-05-11 20:06:32 --> Config Class Initialized
INFO - 2016-05-11 20:06:32 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:06:32 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:06:32 --> Utf8 Class Initialized
INFO - 2016-05-11 20:06:32 --> URI Class Initialized
INFO - 2016-05-11 20:06:32 --> Router Class Initialized
INFO - 2016-05-11 20:06:32 --> Output Class Initialized
INFO - 2016-05-11 20:06:32 --> Security Class Initialized
DEBUG - 2016-05-11 20:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:06:32 --> Input Class Initialized
INFO - 2016-05-11 20:06:32 --> Language Class Initialized
INFO - 2016-05-11 20:06:32 --> Loader Class Initialized
INFO - 2016-05-11 20:06:32 --> Helper loaded: url_helper
INFO - 2016-05-11 20:06:32 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:06:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:06:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:06:32 --> Helper loaded: form_helper
INFO - 2016-05-11 20:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:06:32 --> Form Validation Class Initialized
INFO - 2016-05-11 20:06:32 --> Controller Class Initialized
INFO - 2016-05-11 20:06:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-11 20:06:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 20:06:32 --> Final output sent to browser
DEBUG - 2016-05-11 20:06:32 --> Total execution time: 0.0514
INFO - 2016-05-11 20:06:32 --> Config Class Initialized
INFO - 2016-05-11 20:06:32 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:06:32 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:06:32 --> Utf8 Class Initialized
INFO - 2016-05-11 20:06:32 --> URI Class Initialized
INFO - 2016-05-11 20:06:32 --> Router Class Initialized
INFO - 2016-05-11 20:06:32 --> Output Class Initialized
INFO - 2016-05-11 20:06:32 --> Security Class Initialized
DEBUG - 2016-05-11 20:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:06:32 --> Input Class Initialized
INFO - 2016-05-11 20:06:32 --> Language Class Initialized
INFO - 2016-05-11 20:06:32 --> Loader Class Initialized
INFO - 2016-05-11 20:06:32 --> Helper loaded: url_helper
INFO - 2016-05-11 20:06:32 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:06:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:06:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:06:32 --> Helper loaded: form_helper
INFO - 2016-05-11 20:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:06:32 --> Form Validation Class Initialized
INFO - 2016-05-11 20:06:32 --> Controller Class Initialized
INFO - 2016-05-11 20:06:32 --> Model Class Initialized
INFO - 2016-05-11 20:06:32 --> Database Driver Class Initialized
INFO - 2016-05-11 20:06:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:06:32 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:06:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:06:32 --> Final output sent to browser
DEBUG - 2016-05-11 20:06:32 --> Total execution time: 0.0844
INFO - 2016-05-11 20:06:36 --> Config Class Initialized
INFO - 2016-05-11 20:06:36 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:06:36 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:06:36 --> Utf8 Class Initialized
INFO - 2016-05-11 20:06:36 --> URI Class Initialized
INFO - 2016-05-11 20:06:36 --> Router Class Initialized
INFO - 2016-05-11 20:06:36 --> Output Class Initialized
INFO - 2016-05-11 20:06:36 --> Security Class Initialized
DEBUG - 2016-05-11 20:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:06:36 --> Input Class Initialized
INFO - 2016-05-11 20:06:36 --> Language Class Initialized
INFO - 2016-05-11 20:06:36 --> Loader Class Initialized
INFO - 2016-05-11 20:06:36 --> Helper loaded: url_helper
INFO - 2016-05-11 20:06:36 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:06:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:06:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:06:36 --> Helper loaded: form_helper
INFO - 2016-05-11 20:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:06:36 --> Form Validation Class Initialized
INFO - 2016-05-11 20:06:36 --> Controller Class Initialized
INFO - 2016-05-11 20:06:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-11 20:06:36 --> Helper loaded: nif_validate_helper
INFO - 2016-05-11 20:06:36 --> Model Class Initialized
INFO - 2016-05-11 20:06:36 --> Database Driver Class Initialized
INFO - 2016-05-11 20:06:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-11 20:06:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-11 20:06:36 --> Final output sent to browser
DEBUG - 2016-05-11 20:06:36 --> Total execution time: 0.1120
INFO - 2016-05-11 20:06:37 --> Config Class Initialized
INFO - 2016-05-11 20:06:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:06:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:06:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:06:37 --> URI Class Initialized
INFO - 2016-05-11 20:06:37 --> Router Class Initialized
INFO - 2016-05-11 20:06:37 --> Output Class Initialized
INFO - 2016-05-11 20:06:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:06:37 --> Input Class Initialized
INFO - 2016-05-11 20:06:37 --> Language Class Initialized
INFO - 2016-05-11 20:06:37 --> Loader Class Initialized
INFO - 2016-05-11 20:06:37 --> Helper loaded: url_helper
INFO - 2016-05-11 20:06:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:06:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:06:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:06:37 --> Helper loaded: form_helper
INFO - 2016-05-11 20:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:06:37 --> Form Validation Class Initialized
INFO - 2016-05-11 20:06:37 --> Controller Class Initialized
INFO - 2016-05-11 20:06:37 --> Model Class Initialized
INFO - 2016-05-11 20:06:37 --> Database Driver Class Initialized
INFO - 2016-05-11 20:06:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:06:37 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:06:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:06:37 --> Final output sent to browser
DEBUG - 2016-05-11 20:06:37 --> Total execution time: 0.0927
INFO - 2016-05-11 20:06:53 --> Config Class Initialized
INFO - 2016-05-11 20:06:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:06:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:06:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:06:53 --> URI Class Initialized
INFO - 2016-05-11 20:06:53 --> Router Class Initialized
INFO - 2016-05-11 20:06:53 --> Output Class Initialized
INFO - 2016-05-11 20:06:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:06:53 --> Input Class Initialized
INFO - 2016-05-11 20:06:53 --> Language Class Initialized
INFO - 2016-05-11 20:06:53 --> Loader Class Initialized
INFO - 2016-05-11 20:06:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:06:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:06:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:06:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:06:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:06:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:06:53 --> Controller Class Initialized
INFO - 2016-05-11 20:06:53 --> Model Class Initialized
INFO - 2016-05-11 20:06:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:06:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:06:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:06:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:06:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:06:53 --> Total execution time: 0.0726
INFO - 2016-05-11 20:07:37 --> Config Class Initialized
INFO - 2016-05-11 20:07:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:07:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:07:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:07:37 --> URI Class Initialized
INFO - 2016-05-11 20:07:37 --> Router Class Initialized
INFO - 2016-05-11 20:07:37 --> Output Class Initialized
INFO - 2016-05-11 20:07:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:07:37 --> Input Class Initialized
INFO - 2016-05-11 20:07:37 --> Language Class Initialized
INFO - 2016-05-11 20:07:37 --> Loader Class Initialized
INFO - 2016-05-11 20:07:37 --> Helper loaded: url_helper
INFO - 2016-05-11 20:07:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:07:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:07:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:07:37 --> Helper loaded: form_helper
INFO - 2016-05-11 20:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:07:38 --> Form Validation Class Initialized
INFO - 2016-05-11 20:07:38 --> Controller Class Initialized
INFO - 2016-05-11 20:07:38 --> Model Class Initialized
INFO - 2016-05-11 20:07:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:07:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:07:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:07:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:07:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:07:38 --> Total execution time: 0.0977
INFO - 2016-05-11 20:07:53 --> Config Class Initialized
INFO - 2016-05-11 20:07:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:07:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:07:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:07:53 --> URI Class Initialized
INFO - 2016-05-11 20:07:53 --> Router Class Initialized
INFO - 2016-05-11 20:07:53 --> Output Class Initialized
INFO - 2016-05-11 20:07:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:07:53 --> Input Class Initialized
INFO - 2016-05-11 20:07:53 --> Language Class Initialized
INFO - 2016-05-11 20:07:53 --> Loader Class Initialized
INFO - 2016-05-11 20:07:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:07:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:07:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:07:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:07:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:07:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:07:53 --> Controller Class Initialized
INFO - 2016-05-11 20:07:53 --> Model Class Initialized
INFO - 2016-05-11 20:07:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:07:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:07:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:07:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:07:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:07:53 --> Total execution time: 0.0991
INFO - 2016-05-11 20:08:37 --> Config Class Initialized
INFO - 2016-05-11 20:08:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:08:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:08:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:08:37 --> URI Class Initialized
INFO - 2016-05-11 20:08:37 --> Router Class Initialized
INFO - 2016-05-11 20:08:37 --> Output Class Initialized
INFO - 2016-05-11 20:08:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:08:37 --> Input Class Initialized
INFO - 2016-05-11 20:08:37 --> Language Class Initialized
INFO - 2016-05-11 20:08:37 --> Loader Class Initialized
INFO - 2016-05-11 20:08:37 --> Helper loaded: url_helper
INFO - 2016-05-11 20:08:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:08:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:08:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:08:38 --> Helper loaded: form_helper
INFO - 2016-05-11 20:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:08:38 --> Form Validation Class Initialized
INFO - 2016-05-11 20:08:38 --> Controller Class Initialized
INFO - 2016-05-11 20:08:38 --> Model Class Initialized
INFO - 2016-05-11 20:08:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:08:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:08:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:08:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:08:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:08:38 --> Total execution time: 0.0707
INFO - 2016-05-11 20:08:53 --> Config Class Initialized
INFO - 2016-05-11 20:08:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:08:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:08:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:08:53 --> URI Class Initialized
INFO - 2016-05-11 20:08:53 --> Router Class Initialized
INFO - 2016-05-11 20:08:53 --> Output Class Initialized
INFO - 2016-05-11 20:08:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:08:53 --> Input Class Initialized
INFO - 2016-05-11 20:08:53 --> Language Class Initialized
INFO - 2016-05-11 20:08:53 --> Loader Class Initialized
INFO - 2016-05-11 20:08:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:08:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:08:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:08:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:08:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:08:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:08:53 --> Controller Class Initialized
INFO - 2016-05-11 20:08:53 --> Model Class Initialized
INFO - 2016-05-11 20:08:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:08:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:08:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:08:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:08:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:08:53 --> Total execution time: 0.0811
INFO - 2016-05-11 20:09:21 --> Config Class Initialized
INFO - 2016-05-11 20:09:21 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:09:21 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:09:21 --> Utf8 Class Initialized
INFO - 2016-05-11 20:09:21 --> URI Class Initialized
DEBUG - 2016-05-11 20:09:21 --> No URI present. Default controller set.
INFO - 2016-05-11 20:09:21 --> Router Class Initialized
INFO - 2016-05-11 20:09:21 --> Output Class Initialized
INFO - 2016-05-11 20:09:21 --> Security Class Initialized
DEBUG - 2016-05-11 20:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:09:21 --> Input Class Initialized
INFO - 2016-05-11 20:09:21 --> Language Class Initialized
INFO - 2016-05-11 20:09:21 --> Loader Class Initialized
INFO - 2016-05-11 20:09:21 --> Helper loaded: url_helper
INFO - 2016-05-11 20:09:21 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:09:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:09:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:09:21 --> Helper loaded: form_helper
INFO - 2016-05-11 20:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:09:21 --> Form Validation Class Initialized
INFO - 2016-05-11 20:09:21 --> Controller Class Initialized
INFO - 2016-05-11 20:09:21 --> Model Class Initialized
INFO - 2016-05-11 20:09:21 --> Database Driver Class Initialized
INFO - 2016-05-11 20:09:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:09:21 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:09:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:09:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:09:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:09:21 --> Final output sent to browser
DEBUG - 2016-05-11 20:09:21 --> Total execution time: 0.1126
INFO - 2016-05-11 20:09:23 --> Config Class Initialized
INFO - 2016-05-11 20:09:23 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:09:23 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:09:23 --> Utf8 Class Initialized
INFO - 2016-05-11 20:09:23 --> URI Class Initialized
INFO - 2016-05-11 20:09:23 --> Router Class Initialized
INFO - 2016-05-11 20:09:23 --> Output Class Initialized
INFO - 2016-05-11 20:09:23 --> Security Class Initialized
DEBUG - 2016-05-11 20:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:09:23 --> Input Class Initialized
INFO - 2016-05-11 20:09:23 --> Language Class Initialized
INFO - 2016-05-11 20:09:23 --> Loader Class Initialized
INFO - 2016-05-11 20:09:23 --> Helper loaded: url_helper
INFO - 2016-05-11 20:09:23 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:09:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:09:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:09:23 --> Helper loaded: form_helper
INFO - 2016-05-11 20:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:09:23 --> Form Validation Class Initialized
INFO - 2016-05-11 20:09:23 --> Controller Class Initialized
INFO - 2016-05-11 20:09:23 --> Model Class Initialized
INFO - 2016-05-11 20:09:23 --> Database Driver Class Initialized
INFO - 2016-05-11 20:09:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:09:23 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:09:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:09:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:09:23 --> Final output sent to browser
DEBUG - 2016-05-11 20:09:23 --> Total execution time: 0.0970
INFO - 2016-05-11 20:09:35 --> Config Class Initialized
INFO - 2016-05-11 20:09:35 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:09:35 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:09:35 --> Utf8 Class Initialized
INFO - 2016-05-11 20:09:35 --> URI Class Initialized
DEBUG - 2016-05-11 20:09:35 --> No URI present. Default controller set.
INFO - 2016-05-11 20:09:35 --> Router Class Initialized
INFO - 2016-05-11 20:09:35 --> Output Class Initialized
INFO - 2016-05-11 20:09:35 --> Security Class Initialized
DEBUG - 2016-05-11 20:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:09:35 --> Input Class Initialized
INFO - 2016-05-11 20:09:35 --> Language Class Initialized
INFO - 2016-05-11 20:09:35 --> Loader Class Initialized
INFO - 2016-05-11 20:09:35 --> Helper loaded: url_helper
INFO - 2016-05-11 20:09:35 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:09:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:09:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:09:35 --> Helper loaded: form_helper
INFO - 2016-05-11 20:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:09:35 --> Form Validation Class Initialized
INFO - 2016-05-11 20:09:35 --> Controller Class Initialized
INFO - 2016-05-11 20:09:35 --> Model Class Initialized
INFO - 2016-05-11 20:09:35 --> Database Driver Class Initialized
INFO - 2016-05-11 20:09:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:09:35 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:09:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:09:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:09:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:09:35 --> Final output sent to browser
DEBUG - 2016-05-11 20:09:35 --> Total execution time: 0.0868
INFO - 2016-05-11 20:09:36 --> Config Class Initialized
INFO - 2016-05-11 20:09:36 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:09:36 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:09:36 --> Utf8 Class Initialized
INFO - 2016-05-11 20:09:36 --> URI Class Initialized
DEBUG - 2016-05-11 20:09:36 --> No URI present. Default controller set.
INFO - 2016-05-11 20:09:36 --> Router Class Initialized
INFO - 2016-05-11 20:09:36 --> Output Class Initialized
INFO - 2016-05-11 20:09:36 --> Security Class Initialized
DEBUG - 2016-05-11 20:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:09:36 --> Input Class Initialized
INFO - 2016-05-11 20:09:36 --> Language Class Initialized
INFO - 2016-05-11 20:09:36 --> Loader Class Initialized
INFO - 2016-05-11 20:09:36 --> Helper loaded: url_helper
INFO - 2016-05-11 20:09:36 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:09:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:09:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:09:36 --> Helper loaded: form_helper
INFO - 2016-05-11 20:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:09:36 --> Form Validation Class Initialized
INFO - 2016-05-11 20:09:36 --> Controller Class Initialized
INFO - 2016-05-11 20:09:36 --> Model Class Initialized
INFO - 2016-05-11 20:09:36 --> Database Driver Class Initialized
INFO - 2016-05-11 20:09:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:09:36 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:09:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:09:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:09:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:09:36 --> Final output sent to browser
DEBUG - 2016-05-11 20:09:36 --> Total execution time: 0.0845
INFO - 2016-05-11 20:09:37 --> Config Class Initialized
INFO - 2016-05-11 20:09:37 --> Hooks Class Initialized
INFO - 2016-05-11 20:09:37 --> Config Class Initialized
INFO - 2016-05-11 20:09:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:09:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:09:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:09:37 --> URI Class Initialized
DEBUG - 2016-05-11 20:09:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:09:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:09:37 --> Router Class Initialized
INFO - 2016-05-11 20:09:37 --> URI Class Initialized
INFO - 2016-05-11 20:09:37 --> Output Class Initialized
INFO - 2016-05-11 20:09:37 --> Router Class Initialized
INFO - 2016-05-11 20:09:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:09:37 --> Output Class Initialized
INFO - 2016-05-11 20:09:37 --> Input Class Initialized
INFO - 2016-05-11 20:09:37 --> Language Class Initialized
INFO - 2016-05-11 20:09:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:09:37 --> Input Class Initialized
INFO - 2016-05-11 20:09:37 --> Loader Class Initialized
INFO - 2016-05-11 20:09:37 --> Language Class Initialized
INFO - 2016-05-11 20:09:37 --> Helper loaded: url_helper
INFO - 2016-05-11 20:09:37 --> Loader Class Initialized
INFO - 2016-05-11 20:09:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:09:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:09:37 --> Helper loaded: url_helper
INFO - 2016-05-11 20:09:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:09:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:09:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:09:37 --> Helper loaded: form_helper
INFO - 2016-05-11 20:09:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:09:37 --> Helper loaded: form_helper
INFO - 2016-05-11 20:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:09:38 --> Form Validation Class Initialized
INFO - 2016-05-11 20:09:38 --> Controller Class Initialized
INFO - 2016-05-11 20:09:38 --> Model Class Initialized
INFO - 2016-05-11 20:09:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:09:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:09:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:09:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:09:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:09:38 --> Total execution time: 0.1017
INFO - 2016-05-11 20:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:09:38 --> Form Validation Class Initialized
INFO - 2016-05-11 20:09:38 --> Controller Class Initialized
INFO - 2016-05-11 20:09:38 --> Model Class Initialized
INFO - 2016-05-11 20:09:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:09:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:09:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:09:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:09:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:09:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:09:38 --> Total execution time: 0.1344
INFO - 2016-05-11 20:09:39 --> Config Class Initialized
INFO - 2016-05-11 20:09:39 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:09:39 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:09:39 --> Utf8 Class Initialized
INFO - 2016-05-11 20:09:39 --> URI Class Initialized
INFO - 2016-05-11 20:09:39 --> Router Class Initialized
INFO - 2016-05-11 20:09:39 --> Output Class Initialized
INFO - 2016-05-11 20:09:39 --> Security Class Initialized
DEBUG - 2016-05-11 20:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:09:39 --> Input Class Initialized
INFO - 2016-05-11 20:09:39 --> Language Class Initialized
INFO - 2016-05-11 20:09:39 --> Loader Class Initialized
INFO - 2016-05-11 20:09:39 --> Helper loaded: url_helper
INFO - 2016-05-11 20:09:39 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:09:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:09:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:09:39 --> Helper loaded: form_helper
INFO - 2016-05-11 20:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:09:39 --> Form Validation Class Initialized
INFO - 2016-05-11 20:09:39 --> Controller Class Initialized
INFO - 2016-05-11 20:09:39 --> Model Class Initialized
INFO - 2016-05-11 20:09:39 --> Database Driver Class Initialized
INFO - 2016-05-11 20:09:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:09:39 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:09:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:09:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:09:39 --> Final output sent to browser
DEBUG - 2016-05-11 20:09:39 --> Total execution time: 0.1216
INFO - 2016-05-11 20:09:53 --> Config Class Initialized
INFO - 2016-05-11 20:09:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:09:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:09:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:09:53 --> URI Class Initialized
INFO - 2016-05-11 20:09:53 --> Router Class Initialized
INFO - 2016-05-11 20:09:53 --> Output Class Initialized
INFO - 2016-05-11 20:09:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:09:53 --> Input Class Initialized
INFO - 2016-05-11 20:09:53 --> Language Class Initialized
INFO - 2016-05-11 20:09:53 --> Loader Class Initialized
INFO - 2016-05-11 20:09:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:09:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:09:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:09:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:09:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:09:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:09:53 --> Controller Class Initialized
INFO - 2016-05-11 20:09:53 --> Model Class Initialized
INFO - 2016-05-11 20:09:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:09:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:09:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:09:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:09:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:09:53 --> Total execution time: 0.0721
INFO - 2016-05-11 20:10:34 --> Config Class Initialized
INFO - 2016-05-11 20:10:34 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:10:34 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:10:34 --> Utf8 Class Initialized
INFO - 2016-05-11 20:10:34 --> URI Class Initialized
DEBUG - 2016-05-11 20:10:34 --> No URI present. Default controller set.
INFO - 2016-05-11 20:10:34 --> Router Class Initialized
INFO - 2016-05-11 20:10:34 --> Output Class Initialized
INFO - 2016-05-11 20:10:34 --> Security Class Initialized
DEBUG - 2016-05-11 20:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:10:34 --> Input Class Initialized
INFO - 2016-05-11 20:10:34 --> Language Class Initialized
INFO - 2016-05-11 20:10:34 --> Loader Class Initialized
INFO - 2016-05-11 20:10:34 --> Helper loaded: url_helper
INFO - 2016-05-11 20:10:34 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:10:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:10:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:10:34 --> Helper loaded: form_helper
INFO - 2016-05-11 20:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:10:34 --> Form Validation Class Initialized
INFO - 2016-05-11 20:10:34 --> Controller Class Initialized
INFO - 2016-05-11 20:10:34 --> Model Class Initialized
INFO - 2016-05-11 20:10:34 --> Database Driver Class Initialized
INFO - 2016-05-11 20:10:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:10:34 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:10:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:10:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:10:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:10:34 --> Final output sent to browser
DEBUG - 2016-05-11 20:10:34 --> Total execution time: 0.0896
INFO - 2016-05-11 20:10:36 --> Config Class Initialized
INFO - 2016-05-11 20:10:36 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:10:36 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:10:36 --> Utf8 Class Initialized
INFO - 2016-05-11 20:10:36 --> URI Class Initialized
INFO - 2016-05-11 20:10:36 --> Router Class Initialized
INFO - 2016-05-11 20:10:36 --> Output Class Initialized
INFO - 2016-05-11 20:10:36 --> Security Class Initialized
DEBUG - 2016-05-11 20:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:10:36 --> Input Class Initialized
INFO - 2016-05-11 20:10:36 --> Language Class Initialized
INFO - 2016-05-11 20:10:36 --> Loader Class Initialized
INFO - 2016-05-11 20:10:36 --> Helper loaded: url_helper
INFO - 2016-05-11 20:10:36 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:10:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:10:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:10:36 --> Helper loaded: form_helper
INFO - 2016-05-11 20:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:10:36 --> Form Validation Class Initialized
INFO - 2016-05-11 20:10:36 --> Controller Class Initialized
INFO - 2016-05-11 20:10:36 --> Model Class Initialized
INFO - 2016-05-11 20:10:36 --> Database Driver Class Initialized
INFO - 2016-05-11 20:10:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:10:36 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:10:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:10:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:10:36 --> Final output sent to browser
DEBUG - 2016-05-11 20:10:36 --> Total execution time: 0.1071
INFO - 2016-05-11 20:10:37 --> Config Class Initialized
INFO - 2016-05-11 20:10:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:10:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:10:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:10:37 --> URI Class Initialized
DEBUG - 2016-05-11 20:10:37 --> No URI present. Default controller set.
INFO - 2016-05-11 20:10:37 --> Router Class Initialized
INFO - 2016-05-11 20:10:37 --> Output Class Initialized
INFO - 2016-05-11 20:10:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:10:37 --> Input Class Initialized
INFO - 2016-05-11 20:10:37 --> Language Class Initialized
INFO - 2016-05-11 20:10:37 --> Loader Class Initialized
INFO - 2016-05-11 20:10:37 --> Helper loaded: url_helper
INFO - 2016-05-11 20:10:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:10:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:10:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:10:37 --> Helper loaded: form_helper
INFO - 2016-05-11 20:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:10:37 --> Form Validation Class Initialized
INFO - 2016-05-11 20:10:37 --> Controller Class Initialized
INFO - 2016-05-11 20:10:37 --> Model Class Initialized
INFO - 2016-05-11 20:10:37 --> Database Driver Class Initialized
INFO - 2016-05-11 20:10:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:10:37 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:10:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:10:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:10:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:10:37 --> Final output sent to browser
DEBUG - 2016-05-11 20:10:37 --> Total execution time: 0.0841
INFO - 2016-05-11 20:10:37 --> Config Class Initialized
INFO - 2016-05-11 20:10:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:10:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:10:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:10:37 --> URI Class Initialized
INFO - 2016-05-11 20:10:37 --> Router Class Initialized
INFO - 2016-05-11 20:10:37 --> Output Class Initialized
INFO - 2016-05-11 20:10:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:10:37 --> Input Class Initialized
INFO - 2016-05-11 20:10:38 --> Language Class Initialized
INFO - 2016-05-11 20:10:38 --> Loader Class Initialized
INFO - 2016-05-11 20:10:38 --> Helper loaded: url_helper
INFO - 2016-05-11 20:10:38 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:10:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:10:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:10:38 --> Helper loaded: form_helper
INFO - 2016-05-11 20:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:10:38 --> Form Validation Class Initialized
INFO - 2016-05-11 20:10:38 --> Controller Class Initialized
INFO - 2016-05-11 20:10:38 --> Model Class Initialized
INFO - 2016-05-11 20:10:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:10:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:10:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:10:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:10:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:10:38 --> Total execution time: 0.0877
INFO - 2016-05-11 20:10:38 --> Config Class Initialized
INFO - 2016-05-11 20:10:38 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:10:38 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:10:38 --> Utf8 Class Initialized
INFO - 2016-05-11 20:10:38 --> URI Class Initialized
DEBUG - 2016-05-11 20:10:38 --> No URI present. Default controller set.
INFO - 2016-05-11 20:10:38 --> Router Class Initialized
INFO - 2016-05-11 20:10:38 --> Output Class Initialized
INFO - 2016-05-11 20:10:38 --> Security Class Initialized
DEBUG - 2016-05-11 20:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:10:38 --> Input Class Initialized
INFO - 2016-05-11 20:10:38 --> Language Class Initialized
INFO - 2016-05-11 20:10:38 --> Loader Class Initialized
INFO - 2016-05-11 20:10:38 --> Helper loaded: url_helper
INFO - 2016-05-11 20:10:38 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:10:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:10:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:10:38 --> Helper loaded: form_helper
INFO - 2016-05-11 20:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:10:38 --> Form Validation Class Initialized
INFO - 2016-05-11 20:10:38 --> Controller Class Initialized
INFO - 2016-05-11 20:10:38 --> Model Class Initialized
INFO - 2016-05-11 20:10:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:10:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:10:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:10:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:10:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:10:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:10:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:10:38 --> Total execution time: 0.0763
INFO - 2016-05-11 20:10:53 --> Config Class Initialized
INFO - 2016-05-11 20:10:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:10:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:10:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:10:53 --> URI Class Initialized
INFO - 2016-05-11 20:10:53 --> Router Class Initialized
INFO - 2016-05-11 20:10:53 --> Output Class Initialized
INFO - 2016-05-11 20:10:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:10:53 --> Input Class Initialized
INFO - 2016-05-11 20:10:53 --> Language Class Initialized
INFO - 2016-05-11 20:10:53 --> Loader Class Initialized
INFO - 2016-05-11 20:10:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:10:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:10:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:10:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:10:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:10:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:10:53 --> Controller Class Initialized
INFO - 2016-05-11 20:10:53 --> Model Class Initialized
INFO - 2016-05-11 20:10:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:10:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:10:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:10:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:10:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:10:53 --> Total execution time: 0.0686
INFO - 2016-05-11 20:10:54 --> Config Class Initialized
INFO - 2016-05-11 20:10:54 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:10:54 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:10:54 --> Utf8 Class Initialized
INFO - 2016-05-11 20:10:54 --> URI Class Initialized
DEBUG - 2016-05-11 20:10:54 --> No URI present. Default controller set.
INFO - 2016-05-11 20:10:54 --> Router Class Initialized
INFO - 2016-05-11 20:10:54 --> Output Class Initialized
INFO - 2016-05-11 20:10:54 --> Security Class Initialized
DEBUG - 2016-05-11 20:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:10:54 --> Input Class Initialized
INFO - 2016-05-11 20:10:54 --> Language Class Initialized
INFO - 2016-05-11 20:10:54 --> Loader Class Initialized
INFO - 2016-05-11 20:10:54 --> Helper loaded: url_helper
INFO - 2016-05-11 20:10:54 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:10:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:10:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:10:54 --> Helper loaded: form_helper
INFO - 2016-05-11 20:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:10:54 --> Form Validation Class Initialized
INFO - 2016-05-11 20:10:54 --> Controller Class Initialized
INFO - 2016-05-11 20:10:54 --> Model Class Initialized
INFO - 2016-05-11 20:10:54 --> Database Driver Class Initialized
INFO - 2016-05-11 20:10:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:10:54 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:10:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:10:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:10:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:10:54 --> Final output sent to browser
DEBUG - 2016-05-11 20:10:54 --> Total execution time: 0.0849
INFO - 2016-05-11 20:10:57 --> Config Class Initialized
INFO - 2016-05-11 20:10:57 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:10:57 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:10:57 --> Utf8 Class Initialized
INFO - 2016-05-11 20:10:57 --> URI Class Initialized
INFO - 2016-05-11 20:10:57 --> Router Class Initialized
INFO - 2016-05-11 20:10:57 --> Output Class Initialized
INFO - 2016-05-11 20:10:57 --> Security Class Initialized
DEBUG - 2016-05-11 20:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:10:57 --> Input Class Initialized
INFO - 2016-05-11 20:10:57 --> Language Class Initialized
INFO - 2016-05-11 20:10:57 --> Loader Class Initialized
INFO - 2016-05-11 20:10:57 --> Helper loaded: url_helper
INFO - 2016-05-11 20:10:57 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:10:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:10:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:10:57 --> Helper loaded: form_helper
INFO - 2016-05-11 20:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:10:57 --> Form Validation Class Initialized
INFO - 2016-05-11 20:10:57 --> Controller Class Initialized
INFO - 2016-05-11 20:10:57 --> Model Class Initialized
INFO - 2016-05-11 20:10:57 --> Database Driver Class Initialized
INFO - 2016-05-11 20:10:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:10:57 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:10:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:10:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:10:57 --> Final output sent to browser
DEBUG - 2016-05-11 20:10:57 --> Total execution time: 0.0913
INFO - 2016-05-11 20:10:58 --> Config Class Initialized
INFO - 2016-05-11 20:10:58 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:10:58 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:10:58 --> Utf8 Class Initialized
INFO - 2016-05-11 20:10:58 --> URI Class Initialized
DEBUG - 2016-05-11 20:10:58 --> No URI present. Default controller set.
INFO - 2016-05-11 20:10:58 --> Router Class Initialized
INFO - 2016-05-11 20:10:58 --> Output Class Initialized
INFO - 2016-05-11 20:10:58 --> Security Class Initialized
DEBUG - 2016-05-11 20:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:10:58 --> Input Class Initialized
INFO - 2016-05-11 20:10:58 --> Language Class Initialized
INFO - 2016-05-11 20:10:58 --> Loader Class Initialized
INFO - 2016-05-11 20:10:58 --> Helper loaded: url_helper
INFO - 2016-05-11 20:10:58 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:10:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:10:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:10:58 --> Helper loaded: form_helper
INFO - 2016-05-11 20:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:10:58 --> Form Validation Class Initialized
INFO - 2016-05-11 20:10:58 --> Controller Class Initialized
INFO - 2016-05-11 20:10:58 --> Model Class Initialized
INFO - 2016-05-11 20:10:58 --> Database Driver Class Initialized
INFO - 2016-05-11 20:10:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:10:58 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:10:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:10:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:10:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:10:58 --> Final output sent to browser
DEBUG - 2016-05-11 20:10:58 --> Total execution time: 0.0760
INFO - 2016-05-11 20:11:37 --> Config Class Initialized
INFO - 2016-05-11 20:11:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:11:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:11:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:11:37 --> URI Class Initialized
INFO - 2016-05-11 20:11:37 --> Router Class Initialized
INFO - 2016-05-11 20:11:37 --> Output Class Initialized
INFO - 2016-05-11 20:11:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:11:37 --> Input Class Initialized
INFO - 2016-05-11 20:11:37 --> Language Class Initialized
INFO - 2016-05-11 20:11:37 --> Loader Class Initialized
INFO - 2016-05-11 20:11:37 --> Helper loaded: url_helper
INFO - 2016-05-11 20:11:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:11:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:11:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:11:37 --> Helper loaded: form_helper
INFO - 2016-05-11 20:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:11:38 --> Form Validation Class Initialized
INFO - 2016-05-11 20:11:38 --> Controller Class Initialized
INFO - 2016-05-11 20:11:38 --> Model Class Initialized
INFO - 2016-05-11 20:11:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:11:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:11:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:11:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:11:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:11:38 --> Total execution time: 0.0779
INFO - 2016-05-11 20:11:53 --> Config Class Initialized
INFO - 2016-05-11 20:11:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:11:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:11:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:11:53 --> URI Class Initialized
INFO - 2016-05-11 20:11:53 --> Router Class Initialized
INFO - 2016-05-11 20:11:53 --> Output Class Initialized
INFO - 2016-05-11 20:11:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:11:53 --> Input Class Initialized
INFO - 2016-05-11 20:11:53 --> Language Class Initialized
INFO - 2016-05-11 20:11:53 --> Loader Class Initialized
INFO - 2016-05-11 20:11:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:11:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:11:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:11:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:11:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:11:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:11:53 --> Controller Class Initialized
INFO - 2016-05-11 20:11:53 --> Model Class Initialized
INFO - 2016-05-11 20:11:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:11:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:11:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:11:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:11:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:11:53 --> Total execution time: 0.0971
INFO - 2016-05-11 20:12:24 --> Config Class Initialized
INFO - 2016-05-11 20:12:24 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:12:24 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:12:24 --> Utf8 Class Initialized
INFO - 2016-05-11 20:12:24 --> URI Class Initialized
DEBUG - 2016-05-11 20:12:24 --> No URI present. Default controller set.
INFO - 2016-05-11 20:12:24 --> Router Class Initialized
INFO - 2016-05-11 20:12:24 --> Output Class Initialized
INFO - 2016-05-11 20:12:24 --> Security Class Initialized
DEBUG - 2016-05-11 20:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:12:24 --> Input Class Initialized
INFO - 2016-05-11 20:12:24 --> Language Class Initialized
INFO - 2016-05-11 20:12:24 --> Loader Class Initialized
INFO - 2016-05-11 20:12:24 --> Helper loaded: url_helper
INFO - 2016-05-11 20:12:24 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:12:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:12:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:12:24 --> Helper loaded: form_helper
INFO - 2016-05-11 20:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:12:24 --> Form Validation Class Initialized
INFO - 2016-05-11 20:12:24 --> Controller Class Initialized
INFO - 2016-05-11 20:12:24 --> Model Class Initialized
INFO - 2016-05-11 20:12:24 --> Database Driver Class Initialized
INFO - 2016-05-11 20:12:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:12:24 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:12:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:12:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:12:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:12:24 --> Final output sent to browser
DEBUG - 2016-05-11 20:12:24 --> Total execution time: 0.0758
INFO - 2016-05-11 20:12:27 --> Config Class Initialized
INFO - 2016-05-11 20:12:27 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:12:27 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:12:27 --> Utf8 Class Initialized
INFO - 2016-05-11 20:12:27 --> URI Class Initialized
INFO - 2016-05-11 20:12:27 --> Router Class Initialized
INFO - 2016-05-11 20:12:27 --> Output Class Initialized
INFO - 2016-05-11 20:12:27 --> Security Class Initialized
DEBUG - 2016-05-11 20:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:12:27 --> Input Class Initialized
INFO - 2016-05-11 20:12:27 --> Language Class Initialized
INFO - 2016-05-11 20:12:27 --> Loader Class Initialized
INFO - 2016-05-11 20:12:27 --> Helper loaded: url_helper
INFO - 2016-05-11 20:12:27 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:12:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:12:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:12:27 --> Helper loaded: form_helper
INFO - 2016-05-11 20:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:12:27 --> Form Validation Class Initialized
INFO - 2016-05-11 20:12:27 --> Controller Class Initialized
INFO - 2016-05-11 20:12:27 --> Model Class Initialized
INFO - 2016-05-11 20:12:27 --> Database Driver Class Initialized
INFO - 2016-05-11 20:12:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:12:27 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:12:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:12:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:12:27 --> Final output sent to browser
DEBUG - 2016-05-11 20:12:27 --> Total execution time: 0.1054
INFO - 2016-05-11 20:12:28 --> Config Class Initialized
INFO - 2016-05-11 20:12:28 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:12:28 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:12:28 --> Utf8 Class Initialized
INFO - 2016-05-11 20:12:28 --> URI Class Initialized
DEBUG - 2016-05-11 20:12:28 --> No URI present. Default controller set.
INFO - 2016-05-11 20:12:28 --> Router Class Initialized
INFO - 2016-05-11 20:12:28 --> Output Class Initialized
INFO - 2016-05-11 20:12:28 --> Security Class Initialized
DEBUG - 2016-05-11 20:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:12:28 --> Input Class Initialized
INFO - 2016-05-11 20:12:28 --> Language Class Initialized
INFO - 2016-05-11 20:12:28 --> Loader Class Initialized
INFO - 2016-05-11 20:12:28 --> Helper loaded: url_helper
INFO - 2016-05-11 20:12:28 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:12:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:12:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:12:28 --> Helper loaded: form_helper
INFO - 2016-05-11 20:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:12:28 --> Form Validation Class Initialized
INFO - 2016-05-11 20:12:28 --> Controller Class Initialized
INFO - 2016-05-11 20:12:28 --> Model Class Initialized
INFO - 2016-05-11 20:12:28 --> Database Driver Class Initialized
INFO - 2016-05-11 20:12:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:12:28 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:12:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:12:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:12:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:12:28 --> Final output sent to browser
DEBUG - 2016-05-11 20:12:28 --> Total execution time: 0.0781
INFO - 2016-05-11 20:12:37 --> Config Class Initialized
INFO - 2016-05-11 20:12:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:12:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:12:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:12:37 --> URI Class Initialized
INFO - 2016-05-11 20:12:37 --> Router Class Initialized
INFO - 2016-05-11 20:12:37 --> Output Class Initialized
INFO - 2016-05-11 20:12:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:12:37 --> Input Class Initialized
INFO - 2016-05-11 20:12:37 --> Language Class Initialized
INFO - 2016-05-11 20:12:37 --> Loader Class Initialized
INFO - 2016-05-11 20:12:37 --> Helper loaded: url_helper
INFO - 2016-05-11 20:12:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:12:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:12:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:12:37 --> Helper loaded: form_helper
INFO - 2016-05-11 20:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:12:37 --> Form Validation Class Initialized
INFO - 2016-05-11 20:12:37 --> Controller Class Initialized
INFO - 2016-05-11 20:12:37 --> Model Class Initialized
INFO - 2016-05-11 20:12:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:12:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:12:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:12:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:12:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:12:38 --> Total execution time: 0.0789
INFO - 2016-05-11 20:12:53 --> Config Class Initialized
INFO - 2016-05-11 20:12:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:12:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:12:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:12:53 --> URI Class Initialized
INFO - 2016-05-11 20:12:53 --> Router Class Initialized
INFO - 2016-05-11 20:12:53 --> Output Class Initialized
INFO - 2016-05-11 20:12:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:12:53 --> Input Class Initialized
INFO - 2016-05-11 20:12:53 --> Language Class Initialized
INFO - 2016-05-11 20:12:53 --> Loader Class Initialized
INFO - 2016-05-11 20:12:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:12:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:12:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:12:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:12:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:12:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:12:53 --> Controller Class Initialized
INFO - 2016-05-11 20:12:53 --> Model Class Initialized
INFO - 2016-05-11 20:12:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:12:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:12:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:12:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:12:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:12:53 --> Total execution time: 0.0708
INFO - 2016-05-11 20:13:03 --> Config Class Initialized
INFO - 2016-05-11 20:13:03 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:13:03 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:13:03 --> Utf8 Class Initialized
INFO - 2016-05-11 20:13:03 --> URI Class Initialized
DEBUG - 2016-05-11 20:13:03 --> No URI present. Default controller set.
INFO - 2016-05-11 20:13:03 --> Router Class Initialized
INFO - 2016-05-11 20:13:03 --> Output Class Initialized
INFO - 2016-05-11 20:13:03 --> Security Class Initialized
DEBUG - 2016-05-11 20:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:13:03 --> Input Class Initialized
INFO - 2016-05-11 20:13:03 --> Language Class Initialized
INFO - 2016-05-11 20:13:03 --> Loader Class Initialized
INFO - 2016-05-11 20:13:03 --> Helper loaded: url_helper
INFO - 2016-05-11 20:13:03 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:13:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:13:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:13:03 --> Helper loaded: form_helper
INFO - 2016-05-11 20:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:13:03 --> Form Validation Class Initialized
INFO - 2016-05-11 20:13:03 --> Controller Class Initialized
INFO - 2016-05-11 20:13:03 --> Model Class Initialized
INFO - 2016-05-11 20:13:03 --> Database Driver Class Initialized
INFO - 2016-05-11 20:13:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:13:03 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:13:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:13:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:13:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:13:03 --> Final output sent to browser
DEBUG - 2016-05-11 20:13:03 --> Total execution time: 0.0864
INFO - 2016-05-11 20:13:04 --> Config Class Initialized
INFO - 2016-05-11 20:13:04 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:13:04 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:13:04 --> Utf8 Class Initialized
INFO - 2016-05-11 20:13:04 --> URI Class Initialized
INFO - 2016-05-11 20:13:04 --> Router Class Initialized
INFO - 2016-05-11 20:13:04 --> Output Class Initialized
INFO - 2016-05-11 20:13:04 --> Security Class Initialized
DEBUG - 2016-05-11 20:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:13:04 --> Input Class Initialized
INFO - 2016-05-11 20:13:04 --> Language Class Initialized
INFO - 2016-05-11 20:13:04 --> Loader Class Initialized
INFO - 2016-05-11 20:13:04 --> Helper loaded: url_helper
INFO - 2016-05-11 20:13:04 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:13:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:13:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:13:04 --> Helper loaded: form_helper
INFO - 2016-05-11 20:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:13:04 --> Form Validation Class Initialized
INFO - 2016-05-11 20:13:04 --> Controller Class Initialized
INFO - 2016-05-11 20:13:04 --> Model Class Initialized
INFO - 2016-05-11 20:13:04 --> Database Driver Class Initialized
INFO - 2016-05-11 20:13:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:13:04 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:13:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:13:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:13:04 --> Final output sent to browser
DEBUG - 2016-05-11 20:13:04 --> Total execution time: 0.0949
INFO - 2016-05-11 20:13:12 --> Config Class Initialized
INFO - 2016-05-11 20:13:12 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:13:12 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:13:12 --> Utf8 Class Initialized
INFO - 2016-05-11 20:13:12 --> URI Class Initialized
INFO - 2016-05-11 20:13:12 --> Router Class Initialized
INFO - 2016-05-11 20:13:12 --> Output Class Initialized
INFO - 2016-05-11 20:13:12 --> Security Class Initialized
DEBUG - 2016-05-11 20:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:13:12 --> Input Class Initialized
INFO - 2016-05-11 20:13:12 --> Language Class Initialized
INFO - 2016-05-11 20:13:12 --> Loader Class Initialized
INFO - 2016-05-11 20:13:12 --> Helper loaded: url_helper
INFO - 2016-05-11 20:13:12 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:13:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:13:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:13:12 --> Helper loaded: form_helper
INFO - 2016-05-11 20:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:13:12 --> Form Validation Class Initialized
INFO - 2016-05-11 20:13:12 --> Controller Class Initialized
INFO - 2016-05-11 20:13:12 --> Model Class Initialized
INFO - 2016-05-11 20:13:12 --> Database Driver Class Initialized
INFO - 2016-05-11 20:13:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:13:12 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:13:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:13:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:13:12 --> Final output sent to browser
DEBUG - 2016-05-11 20:13:12 --> Total execution time: 0.0751
INFO - 2016-05-11 20:13:12 --> Config Class Initialized
INFO - 2016-05-11 20:13:12 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:13:12 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:13:12 --> Utf8 Class Initialized
INFO - 2016-05-11 20:13:12 --> URI Class Initialized
DEBUG - 2016-05-11 20:13:12 --> No URI present. Default controller set.
INFO - 2016-05-11 20:13:12 --> Router Class Initialized
INFO - 2016-05-11 20:13:12 --> Output Class Initialized
INFO - 2016-05-11 20:13:12 --> Security Class Initialized
DEBUG - 2016-05-11 20:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:13:12 --> Input Class Initialized
INFO - 2016-05-11 20:13:12 --> Language Class Initialized
INFO - 2016-05-11 20:13:12 --> Loader Class Initialized
INFO - 2016-05-11 20:13:12 --> Helper loaded: url_helper
INFO - 2016-05-11 20:13:12 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:13:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:13:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:13:12 --> Helper loaded: form_helper
INFO - 2016-05-11 20:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:13:12 --> Form Validation Class Initialized
INFO - 2016-05-11 20:13:12 --> Controller Class Initialized
INFO - 2016-05-11 20:13:12 --> Model Class Initialized
INFO - 2016-05-11 20:13:12 --> Database Driver Class Initialized
INFO - 2016-05-11 20:13:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:13:12 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:13:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:13:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:13:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:13:12 --> Final output sent to browser
DEBUG - 2016-05-11 20:13:12 --> Total execution time: 0.1022
INFO - 2016-05-11 20:13:13 --> Config Class Initialized
INFO - 2016-05-11 20:13:13 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:13:13 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:13:13 --> Utf8 Class Initialized
INFO - 2016-05-11 20:13:13 --> URI Class Initialized
DEBUG - 2016-05-11 20:13:13 --> No URI present. Default controller set.
INFO - 2016-05-11 20:13:13 --> Router Class Initialized
INFO - 2016-05-11 20:13:13 --> Output Class Initialized
INFO - 2016-05-11 20:13:13 --> Security Class Initialized
DEBUG - 2016-05-11 20:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:13:13 --> Input Class Initialized
INFO - 2016-05-11 20:13:13 --> Language Class Initialized
INFO - 2016-05-11 20:13:13 --> Loader Class Initialized
INFO - 2016-05-11 20:13:13 --> Helper loaded: url_helper
INFO - 2016-05-11 20:13:13 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:13:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:13:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:13:13 --> Helper loaded: form_helper
INFO - 2016-05-11 20:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:13:13 --> Form Validation Class Initialized
INFO - 2016-05-11 20:13:13 --> Controller Class Initialized
INFO - 2016-05-11 20:13:13 --> Model Class Initialized
INFO - 2016-05-11 20:13:13 --> Database Driver Class Initialized
INFO - 2016-05-11 20:13:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:13:13 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:13:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:13:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:13:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:13:13 --> Final output sent to browser
DEBUG - 2016-05-11 20:13:13 --> Total execution time: 0.0736
INFO - 2016-05-11 20:13:15 --> Config Class Initialized
INFO - 2016-05-11 20:13:15 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:13:15 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:13:15 --> Utf8 Class Initialized
INFO - 2016-05-11 20:13:15 --> URI Class Initialized
INFO - 2016-05-11 20:13:15 --> Router Class Initialized
INFO - 2016-05-11 20:13:15 --> Output Class Initialized
INFO - 2016-05-11 20:13:15 --> Security Class Initialized
DEBUG - 2016-05-11 20:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:13:15 --> Input Class Initialized
INFO - 2016-05-11 20:13:15 --> Language Class Initialized
INFO - 2016-05-11 20:13:15 --> Loader Class Initialized
INFO - 2016-05-11 20:13:15 --> Helper loaded: url_helper
INFO - 2016-05-11 20:13:15 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:13:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:13:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:13:15 --> Helper loaded: form_helper
INFO - 2016-05-11 20:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:13:15 --> Form Validation Class Initialized
INFO - 2016-05-11 20:13:15 --> Controller Class Initialized
INFO - 2016-05-11 20:13:15 --> Model Class Initialized
INFO - 2016-05-11 20:13:15 --> Database Driver Class Initialized
INFO - 2016-05-11 20:13:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:13:15 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:13:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:13:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:13:15 --> Final output sent to browser
DEBUG - 2016-05-11 20:13:15 --> Total execution time: 0.0983
INFO - 2016-05-11 20:13:16 --> Config Class Initialized
INFO - 2016-05-11 20:13:16 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:13:16 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:13:16 --> Utf8 Class Initialized
INFO - 2016-05-11 20:13:16 --> URI Class Initialized
DEBUG - 2016-05-11 20:13:16 --> No URI present. Default controller set.
INFO - 2016-05-11 20:13:16 --> Router Class Initialized
INFO - 2016-05-11 20:13:16 --> Output Class Initialized
INFO - 2016-05-11 20:13:16 --> Security Class Initialized
DEBUG - 2016-05-11 20:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:13:16 --> Input Class Initialized
INFO - 2016-05-11 20:13:16 --> Language Class Initialized
INFO - 2016-05-11 20:13:16 --> Loader Class Initialized
INFO - 2016-05-11 20:13:16 --> Helper loaded: url_helper
INFO - 2016-05-11 20:13:16 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:13:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:13:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:13:16 --> Helper loaded: form_helper
INFO - 2016-05-11 20:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:13:16 --> Form Validation Class Initialized
INFO - 2016-05-11 20:13:16 --> Controller Class Initialized
INFO - 2016-05-11 20:13:16 --> Model Class Initialized
INFO - 2016-05-11 20:13:16 --> Database Driver Class Initialized
INFO - 2016-05-11 20:13:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:13:16 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:13:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:13:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:13:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:13:16 --> Final output sent to browser
DEBUG - 2016-05-11 20:13:16 --> Total execution time: 0.0954
INFO - 2016-05-11 20:13:16 --> Config Class Initialized
INFO - 2016-05-11 20:13:16 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:13:16 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:13:16 --> Utf8 Class Initialized
INFO - 2016-05-11 20:13:16 --> URI Class Initialized
DEBUG - 2016-05-11 20:13:16 --> No URI present. Default controller set.
INFO - 2016-05-11 20:13:16 --> Router Class Initialized
INFO - 2016-05-11 20:13:16 --> Output Class Initialized
INFO - 2016-05-11 20:13:16 --> Security Class Initialized
DEBUG - 2016-05-11 20:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:13:16 --> Input Class Initialized
INFO - 2016-05-11 20:13:16 --> Language Class Initialized
INFO - 2016-05-11 20:13:16 --> Loader Class Initialized
INFO - 2016-05-11 20:13:16 --> Helper loaded: url_helper
INFO - 2016-05-11 20:13:16 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:13:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:13:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:13:16 --> Helper loaded: form_helper
INFO - 2016-05-11 20:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:13:16 --> Form Validation Class Initialized
INFO - 2016-05-11 20:13:16 --> Controller Class Initialized
INFO - 2016-05-11 20:13:16 --> Model Class Initialized
INFO - 2016-05-11 20:13:16 --> Database Driver Class Initialized
INFO - 2016-05-11 20:13:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:13:16 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:13:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:13:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:13:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:13:16 --> Final output sent to browser
DEBUG - 2016-05-11 20:13:16 --> Total execution time: 0.0759
INFO - 2016-05-11 20:13:37 --> Config Class Initialized
INFO - 2016-05-11 20:13:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:13:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:13:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:13:37 --> URI Class Initialized
INFO - 2016-05-11 20:13:37 --> Router Class Initialized
INFO - 2016-05-11 20:13:37 --> Output Class Initialized
INFO - 2016-05-11 20:13:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:13:37 --> Input Class Initialized
INFO - 2016-05-11 20:13:37 --> Language Class Initialized
INFO - 2016-05-11 20:13:37 --> Loader Class Initialized
INFO - 2016-05-11 20:13:37 --> Helper loaded: url_helper
INFO - 2016-05-11 20:13:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:13:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:13:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:13:37 --> Helper loaded: form_helper
INFO - 2016-05-11 20:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:13:37 --> Form Validation Class Initialized
INFO - 2016-05-11 20:13:37 --> Controller Class Initialized
INFO - 2016-05-11 20:13:37 --> Model Class Initialized
INFO - 2016-05-11 20:13:37 --> Database Driver Class Initialized
INFO - 2016-05-11 20:13:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:13:37 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:13:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:13:37 --> Final output sent to browser
DEBUG - 2016-05-11 20:13:37 --> Total execution time: 0.0711
INFO - 2016-05-11 20:13:53 --> Config Class Initialized
INFO - 2016-05-11 20:13:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:13:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:13:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:13:53 --> URI Class Initialized
INFO - 2016-05-11 20:13:53 --> Router Class Initialized
INFO - 2016-05-11 20:13:53 --> Output Class Initialized
INFO - 2016-05-11 20:13:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:13:53 --> Input Class Initialized
INFO - 2016-05-11 20:13:53 --> Language Class Initialized
INFO - 2016-05-11 20:13:53 --> Loader Class Initialized
INFO - 2016-05-11 20:13:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:13:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:13:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:13:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:13:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:13:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:13:53 --> Controller Class Initialized
INFO - 2016-05-11 20:13:53 --> Model Class Initialized
INFO - 2016-05-11 20:13:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:13:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:13:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:13:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:13:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:13:53 --> Total execution time: 0.0696
INFO - 2016-05-11 20:14:27 --> Config Class Initialized
INFO - 2016-05-11 20:14:27 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:14:27 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:14:27 --> Utf8 Class Initialized
INFO - 2016-05-11 20:14:27 --> URI Class Initialized
DEBUG - 2016-05-11 20:14:27 --> No URI present. Default controller set.
INFO - 2016-05-11 20:14:27 --> Router Class Initialized
INFO - 2016-05-11 20:14:27 --> Output Class Initialized
INFO - 2016-05-11 20:14:27 --> Security Class Initialized
DEBUG - 2016-05-11 20:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:14:27 --> Input Class Initialized
INFO - 2016-05-11 20:14:27 --> Language Class Initialized
INFO - 2016-05-11 20:14:27 --> Loader Class Initialized
INFO - 2016-05-11 20:14:27 --> Helper loaded: url_helper
INFO - 2016-05-11 20:14:27 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:14:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:14:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:14:28 --> Helper loaded: form_helper
INFO - 2016-05-11 20:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:14:28 --> Form Validation Class Initialized
INFO - 2016-05-11 20:14:28 --> Controller Class Initialized
INFO - 2016-05-11 20:14:28 --> Model Class Initialized
INFO - 2016-05-11 20:14:28 --> Database Driver Class Initialized
INFO - 2016-05-11 20:14:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:14:28 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:14:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:14:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:14:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:14:28 --> Final output sent to browser
DEBUG - 2016-05-11 20:14:28 --> Total execution time: 0.1130
INFO - 2016-05-11 20:14:29 --> Config Class Initialized
INFO - 2016-05-11 20:14:29 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:14:29 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:14:29 --> Utf8 Class Initialized
INFO - 2016-05-11 20:14:29 --> URI Class Initialized
INFO - 2016-05-11 20:14:29 --> Router Class Initialized
INFO - 2016-05-11 20:14:29 --> Output Class Initialized
INFO - 2016-05-11 20:14:29 --> Security Class Initialized
DEBUG - 2016-05-11 20:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:14:29 --> Input Class Initialized
INFO - 2016-05-11 20:14:29 --> Language Class Initialized
INFO - 2016-05-11 20:14:29 --> Loader Class Initialized
INFO - 2016-05-11 20:14:29 --> Helper loaded: url_helper
INFO - 2016-05-11 20:14:29 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:14:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:14:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:14:29 --> Helper loaded: form_helper
INFO - 2016-05-11 20:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:14:29 --> Form Validation Class Initialized
INFO - 2016-05-11 20:14:29 --> Controller Class Initialized
INFO - 2016-05-11 20:14:29 --> Model Class Initialized
INFO - 2016-05-11 20:14:29 --> Database Driver Class Initialized
INFO - 2016-05-11 20:14:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:14:29 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:14:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:14:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:14:29 --> Final output sent to browser
DEBUG - 2016-05-11 20:14:29 --> Total execution time: 0.1054
INFO - 2016-05-11 20:14:30 --> Config Class Initialized
INFO - 2016-05-11 20:14:30 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:14:30 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:14:30 --> Utf8 Class Initialized
INFO - 2016-05-11 20:14:30 --> URI Class Initialized
DEBUG - 2016-05-11 20:14:30 --> No URI present. Default controller set.
INFO - 2016-05-11 20:14:30 --> Router Class Initialized
INFO - 2016-05-11 20:14:30 --> Output Class Initialized
INFO - 2016-05-11 20:14:30 --> Security Class Initialized
DEBUG - 2016-05-11 20:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:14:30 --> Input Class Initialized
INFO - 2016-05-11 20:14:30 --> Language Class Initialized
INFO - 2016-05-11 20:14:30 --> Loader Class Initialized
INFO - 2016-05-11 20:14:30 --> Helper loaded: url_helper
INFO - 2016-05-11 20:14:30 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:14:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:14:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:14:30 --> Helper loaded: form_helper
INFO - 2016-05-11 20:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:14:30 --> Form Validation Class Initialized
INFO - 2016-05-11 20:14:30 --> Controller Class Initialized
INFO - 2016-05-11 20:14:30 --> Model Class Initialized
INFO - 2016-05-11 20:14:30 --> Database Driver Class Initialized
INFO - 2016-05-11 20:14:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:14:30 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:14:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:14:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:14:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:14:30 --> Final output sent to browser
DEBUG - 2016-05-11 20:14:30 --> Total execution time: 0.0796
INFO - 2016-05-11 20:14:37 --> Config Class Initialized
INFO - 2016-05-11 20:14:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:14:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:14:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:14:37 --> URI Class Initialized
INFO - 2016-05-11 20:14:37 --> Router Class Initialized
INFO - 2016-05-11 20:14:37 --> Output Class Initialized
INFO - 2016-05-11 20:14:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:14:37 --> Input Class Initialized
INFO - 2016-05-11 20:14:37 --> Language Class Initialized
INFO - 2016-05-11 20:14:37 --> Loader Class Initialized
INFO - 2016-05-11 20:14:37 --> Helper loaded: url_helper
INFO - 2016-05-11 20:14:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:14:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:14:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:14:38 --> Helper loaded: form_helper
INFO - 2016-05-11 20:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:14:38 --> Form Validation Class Initialized
INFO - 2016-05-11 20:14:38 --> Controller Class Initialized
INFO - 2016-05-11 20:14:38 --> Model Class Initialized
INFO - 2016-05-11 20:14:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:14:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:14:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:14:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:14:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:14:38 --> Total execution time: 0.0880
INFO - 2016-05-11 20:14:53 --> Config Class Initialized
INFO - 2016-05-11 20:14:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:14:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:14:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:14:53 --> URI Class Initialized
INFO - 2016-05-11 20:14:53 --> Router Class Initialized
INFO - 2016-05-11 20:14:53 --> Output Class Initialized
INFO - 2016-05-11 20:14:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:14:53 --> Input Class Initialized
INFO - 2016-05-11 20:14:53 --> Language Class Initialized
INFO - 2016-05-11 20:14:53 --> Loader Class Initialized
INFO - 2016-05-11 20:14:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:14:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:14:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:14:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:14:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:14:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:14:53 --> Controller Class Initialized
INFO - 2016-05-11 20:14:53 --> Model Class Initialized
INFO - 2016-05-11 20:14:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:14:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:14:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:14:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:14:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:14:53 --> Total execution time: 0.0956
INFO - 2016-05-11 20:15:09 --> Config Class Initialized
INFO - 2016-05-11 20:15:09 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:15:09 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:15:09 --> Utf8 Class Initialized
INFO - 2016-05-11 20:15:09 --> URI Class Initialized
DEBUG - 2016-05-11 20:15:09 --> No URI present. Default controller set.
INFO - 2016-05-11 20:15:09 --> Router Class Initialized
INFO - 2016-05-11 20:15:09 --> Output Class Initialized
INFO - 2016-05-11 20:15:09 --> Security Class Initialized
DEBUG - 2016-05-11 20:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:15:09 --> Input Class Initialized
INFO - 2016-05-11 20:15:09 --> Language Class Initialized
INFO - 2016-05-11 20:15:09 --> Loader Class Initialized
INFO - 2016-05-11 20:15:09 --> Helper loaded: url_helper
INFO - 2016-05-11 20:15:09 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:15:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:15:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:15:09 --> Helper loaded: form_helper
INFO - 2016-05-11 20:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:15:09 --> Form Validation Class Initialized
INFO - 2016-05-11 20:15:09 --> Controller Class Initialized
INFO - 2016-05-11 20:15:09 --> Model Class Initialized
INFO - 2016-05-11 20:15:09 --> Database Driver Class Initialized
INFO - 2016-05-11 20:15:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:15:09 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:15:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:15:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:15:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:15:09 --> Final output sent to browser
DEBUG - 2016-05-11 20:15:09 --> Total execution time: 0.0738
INFO - 2016-05-11 20:15:11 --> Config Class Initialized
INFO - 2016-05-11 20:15:11 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:15:11 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:15:11 --> Utf8 Class Initialized
INFO - 2016-05-11 20:15:11 --> URI Class Initialized
INFO - 2016-05-11 20:15:11 --> Router Class Initialized
INFO - 2016-05-11 20:15:11 --> Output Class Initialized
INFO - 2016-05-11 20:15:11 --> Security Class Initialized
DEBUG - 2016-05-11 20:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:15:11 --> Input Class Initialized
INFO - 2016-05-11 20:15:11 --> Language Class Initialized
INFO - 2016-05-11 20:15:11 --> Loader Class Initialized
INFO - 2016-05-11 20:15:11 --> Helper loaded: url_helper
INFO - 2016-05-11 20:15:11 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:15:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:15:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:15:11 --> Helper loaded: form_helper
INFO - 2016-05-11 20:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:15:11 --> Form Validation Class Initialized
INFO - 2016-05-11 20:15:11 --> Controller Class Initialized
INFO - 2016-05-11 20:15:11 --> Model Class Initialized
INFO - 2016-05-11 20:15:11 --> Database Driver Class Initialized
INFO - 2016-05-11 20:15:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:15:11 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:15:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:15:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:15:11 --> Final output sent to browser
DEBUG - 2016-05-11 20:15:11 --> Total execution time: 0.0915
INFO - 2016-05-11 20:15:12 --> Config Class Initialized
INFO - 2016-05-11 20:15:12 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:15:12 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:15:12 --> Utf8 Class Initialized
INFO - 2016-05-11 20:15:12 --> URI Class Initialized
DEBUG - 2016-05-11 20:15:12 --> No URI present. Default controller set.
INFO - 2016-05-11 20:15:12 --> Router Class Initialized
INFO - 2016-05-11 20:15:12 --> Output Class Initialized
INFO - 2016-05-11 20:15:12 --> Security Class Initialized
DEBUG - 2016-05-11 20:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:15:12 --> Input Class Initialized
INFO - 2016-05-11 20:15:12 --> Language Class Initialized
INFO - 2016-05-11 20:15:12 --> Loader Class Initialized
INFO - 2016-05-11 20:15:12 --> Helper loaded: url_helper
INFO - 2016-05-11 20:15:12 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:15:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:15:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:15:12 --> Helper loaded: form_helper
INFO - 2016-05-11 20:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:15:12 --> Form Validation Class Initialized
INFO - 2016-05-11 20:15:12 --> Controller Class Initialized
INFO - 2016-05-11 20:15:12 --> Model Class Initialized
INFO - 2016-05-11 20:15:12 --> Database Driver Class Initialized
INFO - 2016-05-11 20:15:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:15:12 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:15:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:15:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:15:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:15:12 --> Final output sent to browser
DEBUG - 2016-05-11 20:15:12 --> Total execution time: 0.0735
INFO - 2016-05-11 20:15:13 --> Config Class Initialized
INFO - 2016-05-11 20:15:13 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:15:13 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:15:13 --> Utf8 Class Initialized
INFO - 2016-05-11 20:15:13 --> URI Class Initialized
DEBUG - 2016-05-11 20:15:13 --> No URI present. Default controller set.
INFO - 2016-05-11 20:15:13 --> Router Class Initialized
INFO - 2016-05-11 20:15:13 --> Output Class Initialized
INFO - 2016-05-11 20:15:13 --> Security Class Initialized
DEBUG - 2016-05-11 20:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:15:13 --> Input Class Initialized
INFO - 2016-05-11 20:15:13 --> Language Class Initialized
INFO - 2016-05-11 20:15:13 --> Loader Class Initialized
INFO - 2016-05-11 20:15:13 --> Helper loaded: url_helper
INFO - 2016-05-11 20:15:13 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:15:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:15:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:15:13 --> Helper loaded: form_helper
INFO - 2016-05-11 20:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:15:13 --> Form Validation Class Initialized
INFO - 2016-05-11 20:15:13 --> Controller Class Initialized
INFO - 2016-05-11 20:15:13 --> Model Class Initialized
INFO - 2016-05-11 20:15:13 --> Database Driver Class Initialized
INFO - 2016-05-11 20:15:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:15:13 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:15:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:15:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:15:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:15:13 --> Final output sent to browser
DEBUG - 2016-05-11 20:15:13 --> Total execution time: 0.0783
INFO - 2016-05-11 20:15:29 --> Config Class Initialized
INFO - 2016-05-11 20:15:29 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:15:29 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:15:29 --> Utf8 Class Initialized
INFO - 2016-05-11 20:15:29 --> URI Class Initialized
DEBUG - 2016-05-11 20:15:29 --> No URI present. Default controller set.
INFO - 2016-05-11 20:15:29 --> Router Class Initialized
INFO - 2016-05-11 20:15:29 --> Output Class Initialized
INFO - 2016-05-11 20:15:29 --> Security Class Initialized
DEBUG - 2016-05-11 20:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:15:29 --> Input Class Initialized
INFO - 2016-05-11 20:15:29 --> Language Class Initialized
INFO - 2016-05-11 20:15:29 --> Loader Class Initialized
INFO - 2016-05-11 20:15:29 --> Helper loaded: url_helper
INFO - 2016-05-11 20:15:29 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:15:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:15:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:15:29 --> Helper loaded: form_helper
INFO - 2016-05-11 20:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:15:29 --> Form Validation Class Initialized
INFO - 2016-05-11 20:15:29 --> Controller Class Initialized
INFO - 2016-05-11 20:15:29 --> Model Class Initialized
INFO - 2016-05-11 20:15:29 --> Database Driver Class Initialized
INFO - 2016-05-11 20:15:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:15:29 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:15:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:15:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:15:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:15:29 --> Final output sent to browser
DEBUG - 2016-05-11 20:15:29 --> Total execution time: 0.0783
INFO - 2016-05-11 20:15:37 --> Config Class Initialized
INFO - 2016-05-11 20:15:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:15:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:15:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:15:37 --> URI Class Initialized
INFO - 2016-05-11 20:15:37 --> Router Class Initialized
INFO - 2016-05-11 20:15:37 --> Output Class Initialized
INFO - 2016-05-11 20:15:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:15:38 --> Input Class Initialized
INFO - 2016-05-11 20:15:38 --> Language Class Initialized
INFO - 2016-05-11 20:15:38 --> Loader Class Initialized
INFO - 2016-05-11 20:15:38 --> Helper loaded: url_helper
INFO - 2016-05-11 20:15:38 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:15:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:15:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:15:38 --> Helper loaded: form_helper
INFO - 2016-05-11 20:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:15:38 --> Form Validation Class Initialized
INFO - 2016-05-11 20:15:38 --> Controller Class Initialized
INFO - 2016-05-11 20:15:38 --> Model Class Initialized
INFO - 2016-05-11 20:15:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:15:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:15:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:15:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:15:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:15:38 --> Total execution time: 0.0778
INFO - 2016-05-11 20:15:53 --> Config Class Initialized
INFO - 2016-05-11 20:15:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:15:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:15:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:15:53 --> URI Class Initialized
INFO - 2016-05-11 20:15:53 --> Router Class Initialized
INFO - 2016-05-11 20:15:53 --> Output Class Initialized
INFO - 2016-05-11 20:15:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:15:53 --> Input Class Initialized
INFO - 2016-05-11 20:15:53 --> Language Class Initialized
INFO - 2016-05-11 20:15:53 --> Loader Class Initialized
INFO - 2016-05-11 20:15:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:15:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:15:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:15:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:15:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:15:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:15:53 --> Controller Class Initialized
INFO - 2016-05-11 20:15:53 --> Model Class Initialized
INFO - 2016-05-11 20:15:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:15:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:15:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:15:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:15:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:15:53 --> Total execution time: 0.0675
INFO - 2016-05-11 20:16:37 --> Config Class Initialized
INFO - 2016-05-11 20:16:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:16:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:16:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:16:37 --> URI Class Initialized
INFO - 2016-05-11 20:16:37 --> Router Class Initialized
INFO - 2016-05-11 20:16:37 --> Output Class Initialized
INFO - 2016-05-11 20:16:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:16:37 --> Input Class Initialized
INFO - 2016-05-11 20:16:37 --> Language Class Initialized
INFO - 2016-05-11 20:16:37 --> Loader Class Initialized
INFO - 2016-05-11 20:16:37 --> Helper loaded: url_helper
INFO - 2016-05-11 20:16:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:16:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:16:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:16:37 --> Helper loaded: form_helper
INFO - 2016-05-11 20:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:16:38 --> Form Validation Class Initialized
INFO - 2016-05-11 20:16:38 --> Controller Class Initialized
INFO - 2016-05-11 20:16:38 --> Model Class Initialized
INFO - 2016-05-11 20:16:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:16:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:16:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:16:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:16:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:16:38 --> Total execution time: 0.0684
INFO - 2016-05-11 20:16:39 --> Config Class Initialized
INFO - 2016-05-11 20:16:39 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:16:39 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:16:39 --> Utf8 Class Initialized
INFO - 2016-05-11 20:16:39 --> URI Class Initialized
DEBUG - 2016-05-11 20:16:39 --> No URI present. Default controller set.
INFO - 2016-05-11 20:16:39 --> Router Class Initialized
INFO - 2016-05-11 20:16:39 --> Output Class Initialized
INFO - 2016-05-11 20:16:39 --> Security Class Initialized
DEBUG - 2016-05-11 20:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:16:39 --> Input Class Initialized
INFO - 2016-05-11 20:16:39 --> Language Class Initialized
INFO - 2016-05-11 20:16:39 --> Loader Class Initialized
INFO - 2016-05-11 20:16:39 --> Helper loaded: url_helper
INFO - 2016-05-11 20:16:39 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:16:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:16:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:16:39 --> Helper loaded: form_helper
INFO - 2016-05-11 20:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:16:39 --> Form Validation Class Initialized
INFO - 2016-05-11 20:16:39 --> Controller Class Initialized
INFO - 2016-05-11 20:16:39 --> Model Class Initialized
INFO - 2016-05-11 20:16:39 --> Database Driver Class Initialized
INFO - 2016-05-11 20:16:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:16:39 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:16:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:16:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:16:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:16:39 --> Final output sent to browser
DEBUG - 2016-05-11 20:16:39 --> Total execution time: 0.0740
INFO - 2016-05-11 20:16:42 --> Config Class Initialized
INFO - 2016-05-11 20:16:42 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:16:42 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:16:42 --> Utf8 Class Initialized
INFO - 2016-05-11 20:16:42 --> URI Class Initialized
INFO - 2016-05-11 20:16:42 --> Router Class Initialized
INFO - 2016-05-11 20:16:42 --> Output Class Initialized
INFO - 2016-05-11 20:16:42 --> Security Class Initialized
DEBUG - 2016-05-11 20:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:16:42 --> Input Class Initialized
INFO - 2016-05-11 20:16:42 --> Language Class Initialized
INFO - 2016-05-11 20:16:42 --> Loader Class Initialized
INFO - 2016-05-11 20:16:42 --> Helper loaded: url_helper
INFO - 2016-05-11 20:16:42 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:16:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:16:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:16:42 --> Helper loaded: form_helper
INFO - 2016-05-11 20:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:16:42 --> Form Validation Class Initialized
INFO - 2016-05-11 20:16:42 --> Controller Class Initialized
INFO - 2016-05-11 20:16:42 --> Model Class Initialized
INFO - 2016-05-11 20:16:42 --> Database Driver Class Initialized
INFO - 2016-05-11 20:16:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:16:42 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:16:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:16:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:16:42 --> Final output sent to browser
DEBUG - 2016-05-11 20:16:42 --> Total execution time: 0.0866
INFO - 2016-05-11 20:16:48 --> Config Class Initialized
INFO - 2016-05-11 20:16:48 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:16:48 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:16:48 --> Utf8 Class Initialized
INFO - 2016-05-11 20:16:48 --> URI Class Initialized
DEBUG - 2016-05-11 20:16:48 --> No URI present. Default controller set.
INFO - 2016-05-11 20:16:48 --> Router Class Initialized
INFO - 2016-05-11 20:16:48 --> Output Class Initialized
INFO - 2016-05-11 20:16:48 --> Security Class Initialized
DEBUG - 2016-05-11 20:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:16:48 --> Input Class Initialized
INFO - 2016-05-11 20:16:48 --> Language Class Initialized
INFO - 2016-05-11 20:16:48 --> Loader Class Initialized
INFO - 2016-05-11 20:16:48 --> Helper loaded: url_helper
INFO - 2016-05-11 20:16:48 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:16:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:16:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:16:48 --> Helper loaded: form_helper
INFO - 2016-05-11 20:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:16:48 --> Form Validation Class Initialized
INFO - 2016-05-11 20:16:48 --> Controller Class Initialized
INFO - 2016-05-11 20:16:48 --> Model Class Initialized
INFO - 2016-05-11 20:16:48 --> Database Driver Class Initialized
INFO - 2016-05-11 20:16:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:16:48 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:16:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:16:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:16:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:16:48 --> Final output sent to browser
DEBUG - 2016-05-11 20:16:48 --> Total execution time: 0.0735
INFO - 2016-05-11 20:16:50 --> Config Class Initialized
INFO - 2016-05-11 20:16:50 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:16:50 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:16:50 --> Utf8 Class Initialized
INFO - 2016-05-11 20:16:50 --> URI Class Initialized
DEBUG - 2016-05-11 20:16:50 --> No URI present. Default controller set.
INFO - 2016-05-11 20:16:50 --> Router Class Initialized
INFO - 2016-05-11 20:16:50 --> Output Class Initialized
INFO - 2016-05-11 20:16:50 --> Security Class Initialized
DEBUG - 2016-05-11 20:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:16:50 --> Input Class Initialized
INFO - 2016-05-11 20:16:50 --> Language Class Initialized
INFO - 2016-05-11 20:16:50 --> Loader Class Initialized
INFO - 2016-05-11 20:16:50 --> Helper loaded: url_helper
INFO - 2016-05-11 20:16:50 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:16:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:16:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:16:50 --> Helper loaded: form_helper
INFO - 2016-05-11 20:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:16:50 --> Form Validation Class Initialized
INFO - 2016-05-11 20:16:50 --> Controller Class Initialized
INFO - 2016-05-11 20:16:50 --> Model Class Initialized
INFO - 2016-05-11 20:16:50 --> Database Driver Class Initialized
INFO - 2016-05-11 20:16:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:16:50 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:16:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:16:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:16:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:16:50 --> Final output sent to browser
DEBUG - 2016-05-11 20:16:50 --> Total execution time: 0.0849
INFO - 2016-05-11 20:16:53 --> Config Class Initialized
INFO - 2016-05-11 20:16:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:16:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:16:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:16:53 --> URI Class Initialized
INFO - 2016-05-11 20:16:53 --> Router Class Initialized
INFO - 2016-05-11 20:16:53 --> Output Class Initialized
INFO - 2016-05-11 20:16:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:16:53 --> Input Class Initialized
INFO - 2016-05-11 20:16:53 --> Language Class Initialized
INFO - 2016-05-11 20:16:53 --> Loader Class Initialized
INFO - 2016-05-11 20:16:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:16:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:16:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:16:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:16:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:16:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:16:53 --> Controller Class Initialized
INFO - 2016-05-11 20:16:53 --> Model Class Initialized
INFO - 2016-05-11 20:16:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:16:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:16:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:16:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:16:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:16:53 --> Total execution time: 0.0970
INFO - 2016-05-11 20:17:34 --> Config Class Initialized
INFO - 2016-05-11 20:17:34 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:17:34 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:17:34 --> Utf8 Class Initialized
INFO - 2016-05-11 20:17:34 --> URI Class Initialized
DEBUG - 2016-05-11 20:17:34 --> No URI present. Default controller set.
INFO - 2016-05-11 20:17:34 --> Router Class Initialized
INFO - 2016-05-11 20:17:34 --> Output Class Initialized
INFO - 2016-05-11 20:17:34 --> Security Class Initialized
DEBUG - 2016-05-11 20:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:17:34 --> Input Class Initialized
INFO - 2016-05-11 20:17:34 --> Language Class Initialized
INFO - 2016-05-11 20:17:34 --> Loader Class Initialized
INFO - 2016-05-11 20:17:34 --> Helper loaded: url_helper
INFO - 2016-05-11 20:17:34 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:17:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:17:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:17:34 --> Helper loaded: form_helper
INFO - 2016-05-11 20:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:17:34 --> Form Validation Class Initialized
INFO - 2016-05-11 20:17:34 --> Controller Class Initialized
INFO - 2016-05-11 20:17:34 --> Model Class Initialized
INFO - 2016-05-11 20:17:34 --> Database Driver Class Initialized
INFO - 2016-05-11 20:17:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:17:34 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:17:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:17:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:17:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:17:34 --> Final output sent to browser
DEBUG - 2016-05-11 20:17:34 --> Total execution time: 0.0718
INFO - 2016-05-11 20:17:37 --> Config Class Initialized
INFO - 2016-05-11 20:17:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:17:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:17:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:17:37 --> URI Class Initialized
INFO - 2016-05-11 20:17:37 --> Router Class Initialized
INFO - 2016-05-11 20:17:37 --> Output Class Initialized
INFO - 2016-05-11 20:17:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:17:37 --> Input Class Initialized
INFO - 2016-05-11 20:17:37 --> Language Class Initialized
INFO - 2016-05-11 20:17:37 --> Loader Class Initialized
INFO - 2016-05-11 20:17:37 --> Helper loaded: url_helper
INFO - 2016-05-11 20:17:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:17:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:17:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:17:37 --> Helper loaded: form_helper
INFO - 2016-05-11 20:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:17:37 --> Form Validation Class Initialized
INFO - 2016-05-11 20:17:37 --> Controller Class Initialized
INFO - 2016-05-11 20:17:37 --> Model Class Initialized
INFO - 2016-05-11 20:17:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:17:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:17:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:17:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:17:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:17:38 --> Total execution time: 0.0699
INFO - 2016-05-11 20:17:41 --> Config Class Initialized
INFO - 2016-05-11 20:17:41 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:17:41 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:17:41 --> Utf8 Class Initialized
INFO - 2016-05-11 20:17:41 --> URI Class Initialized
DEBUG - 2016-05-11 20:17:41 --> No URI present. Default controller set.
INFO - 2016-05-11 20:17:41 --> Router Class Initialized
INFO - 2016-05-11 20:17:41 --> Output Class Initialized
INFO - 2016-05-11 20:17:41 --> Security Class Initialized
DEBUG - 2016-05-11 20:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:17:41 --> Input Class Initialized
INFO - 2016-05-11 20:17:41 --> Language Class Initialized
INFO - 2016-05-11 20:17:41 --> Loader Class Initialized
INFO - 2016-05-11 20:17:41 --> Helper loaded: url_helper
INFO - 2016-05-11 20:17:41 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:17:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:17:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:17:41 --> Helper loaded: form_helper
INFO - 2016-05-11 20:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:17:41 --> Form Validation Class Initialized
INFO - 2016-05-11 20:17:41 --> Controller Class Initialized
INFO - 2016-05-11 20:17:41 --> Model Class Initialized
INFO - 2016-05-11 20:17:41 --> Database Driver Class Initialized
INFO - 2016-05-11 20:17:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:17:41 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:17:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:17:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:17:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:17:41 --> Final output sent to browser
DEBUG - 2016-05-11 20:17:41 --> Total execution time: 0.0750
INFO - 2016-05-11 20:17:53 --> Config Class Initialized
INFO - 2016-05-11 20:17:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:17:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:17:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:17:53 --> URI Class Initialized
INFO - 2016-05-11 20:17:53 --> Router Class Initialized
INFO - 2016-05-11 20:17:53 --> Output Class Initialized
INFO - 2016-05-11 20:17:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:17:53 --> Input Class Initialized
INFO - 2016-05-11 20:17:53 --> Language Class Initialized
INFO - 2016-05-11 20:17:53 --> Loader Class Initialized
INFO - 2016-05-11 20:17:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:17:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:17:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:17:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:17:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:17:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:17:53 --> Controller Class Initialized
INFO - 2016-05-11 20:17:53 --> Model Class Initialized
INFO - 2016-05-11 20:17:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:17:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:17:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:17:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:17:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:17:53 --> Total execution time: 0.0734
INFO - 2016-05-11 20:18:37 --> Config Class Initialized
INFO - 2016-05-11 20:18:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:18:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:18:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:18:38 --> URI Class Initialized
INFO - 2016-05-11 20:18:38 --> Router Class Initialized
INFO - 2016-05-11 20:18:38 --> Output Class Initialized
INFO - 2016-05-11 20:18:38 --> Security Class Initialized
DEBUG - 2016-05-11 20:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:18:38 --> Input Class Initialized
INFO - 2016-05-11 20:18:38 --> Language Class Initialized
INFO - 2016-05-11 20:18:38 --> Loader Class Initialized
INFO - 2016-05-11 20:18:38 --> Helper loaded: url_helper
INFO - 2016-05-11 20:18:38 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:18:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:18:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:18:38 --> Helper loaded: form_helper
INFO - 2016-05-11 20:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:18:38 --> Form Validation Class Initialized
INFO - 2016-05-11 20:18:38 --> Controller Class Initialized
INFO - 2016-05-11 20:18:38 --> Model Class Initialized
INFO - 2016-05-11 20:18:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:18:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:18:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:18:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:18:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:18:38 --> Total execution time: 0.0890
INFO - 2016-05-11 20:18:44 --> Config Class Initialized
INFO - 2016-05-11 20:18:44 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:18:44 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:18:44 --> Utf8 Class Initialized
INFO - 2016-05-11 20:18:44 --> URI Class Initialized
DEBUG - 2016-05-11 20:18:44 --> No URI present. Default controller set.
INFO - 2016-05-11 20:18:44 --> Router Class Initialized
INFO - 2016-05-11 20:18:44 --> Output Class Initialized
INFO - 2016-05-11 20:18:44 --> Security Class Initialized
DEBUG - 2016-05-11 20:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:18:44 --> Input Class Initialized
INFO - 2016-05-11 20:18:44 --> Language Class Initialized
INFO - 2016-05-11 20:18:44 --> Loader Class Initialized
INFO - 2016-05-11 20:18:44 --> Helper loaded: url_helper
INFO - 2016-05-11 20:18:44 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:18:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:18:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:18:44 --> Helper loaded: form_helper
INFO - 2016-05-11 20:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:18:44 --> Form Validation Class Initialized
INFO - 2016-05-11 20:18:44 --> Controller Class Initialized
INFO - 2016-05-11 20:18:44 --> Model Class Initialized
INFO - 2016-05-11 20:18:44 --> Database Driver Class Initialized
INFO - 2016-05-11 20:18:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:18:44 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:18:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:18:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:18:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:18:44 --> Final output sent to browser
DEBUG - 2016-05-11 20:18:44 --> Total execution time: 0.1053
INFO - 2016-05-11 20:18:44 --> Config Class Initialized
INFO - 2016-05-11 20:18:44 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:18:44 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:18:44 --> Utf8 Class Initialized
INFO - 2016-05-11 20:18:44 --> URI Class Initialized
INFO - 2016-05-11 20:18:44 --> Router Class Initialized
INFO - 2016-05-11 20:18:44 --> Output Class Initialized
INFO - 2016-05-11 20:18:44 --> Security Class Initialized
DEBUG - 2016-05-11 20:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:18:44 --> Input Class Initialized
INFO - 2016-05-11 20:18:44 --> Language Class Initialized
INFO - 2016-05-11 20:18:44 --> Loader Class Initialized
INFO - 2016-05-11 20:18:44 --> Helper loaded: url_helper
INFO - 2016-05-11 20:18:44 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:18:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:18:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:18:44 --> Helper loaded: form_helper
INFO - 2016-05-11 20:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:18:44 --> Form Validation Class Initialized
INFO - 2016-05-11 20:18:44 --> Controller Class Initialized
INFO - 2016-05-11 20:18:44 --> Model Class Initialized
INFO - 2016-05-11 20:18:44 --> Database Driver Class Initialized
INFO - 2016-05-11 20:18:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:18:44 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:18:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:18:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:18:44 --> Final output sent to browser
DEBUG - 2016-05-11 20:18:44 --> Total execution time: 0.1330
INFO - 2016-05-11 20:18:53 --> Config Class Initialized
INFO - 2016-05-11 20:18:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:18:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:18:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:18:53 --> URI Class Initialized
INFO - 2016-05-11 20:18:53 --> Router Class Initialized
INFO - 2016-05-11 20:18:53 --> Output Class Initialized
INFO - 2016-05-11 20:18:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:18:53 --> Input Class Initialized
INFO - 2016-05-11 20:18:53 --> Language Class Initialized
INFO - 2016-05-11 20:18:53 --> Loader Class Initialized
INFO - 2016-05-11 20:18:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:18:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:18:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:18:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:18:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:18:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:18:53 --> Controller Class Initialized
INFO - 2016-05-11 20:18:53 --> Model Class Initialized
INFO - 2016-05-11 20:18:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:18:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:18:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:18:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:18:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:18:53 --> Total execution time: 0.0765
INFO - 2016-05-11 20:18:54 --> Config Class Initialized
INFO - 2016-05-11 20:18:54 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:18:54 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:18:54 --> Utf8 Class Initialized
INFO - 2016-05-11 20:18:54 --> URI Class Initialized
DEBUG - 2016-05-11 20:18:54 --> No URI present. Default controller set.
INFO - 2016-05-11 20:18:54 --> Router Class Initialized
INFO - 2016-05-11 20:18:54 --> Output Class Initialized
INFO - 2016-05-11 20:18:54 --> Security Class Initialized
DEBUG - 2016-05-11 20:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:18:54 --> Input Class Initialized
INFO - 2016-05-11 20:18:54 --> Language Class Initialized
INFO - 2016-05-11 20:18:54 --> Loader Class Initialized
INFO - 2016-05-11 20:18:54 --> Helper loaded: url_helper
INFO - 2016-05-11 20:18:54 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:18:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:18:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:18:54 --> Helper loaded: form_helper
INFO - 2016-05-11 20:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:18:54 --> Form Validation Class Initialized
INFO - 2016-05-11 20:18:54 --> Controller Class Initialized
INFO - 2016-05-11 20:18:54 --> Model Class Initialized
INFO - 2016-05-11 20:18:54 --> Database Driver Class Initialized
INFO - 2016-05-11 20:18:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:18:54 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:18:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:18:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:18:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:18:54 --> Final output sent to browser
DEBUG - 2016-05-11 20:18:54 --> Total execution time: 0.0775
INFO - 2016-05-11 20:18:54 --> Config Class Initialized
INFO - 2016-05-11 20:18:54 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:18:54 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:18:54 --> Utf8 Class Initialized
INFO - 2016-05-11 20:18:54 --> URI Class Initialized
INFO - 2016-05-11 20:18:54 --> Router Class Initialized
INFO - 2016-05-11 20:18:54 --> Output Class Initialized
INFO - 2016-05-11 20:18:54 --> Security Class Initialized
DEBUG - 2016-05-11 20:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:18:54 --> Input Class Initialized
INFO - 2016-05-11 20:18:54 --> Language Class Initialized
INFO - 2016-05-11 20:18:54 --> Loader Class Initialized
INFO - 2016-05-11 20:18:54 --> Helper loaded: url_helper
INFO - 2016-05-11 20:18:54 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:18:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:18:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:18:54 --> Helper loaded: form_helper
INFO - 2016-05-11 20:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:18:54 --> Form Validation Class Initialized
INFO - 2016-05-11 20:18:54 --> Controller Class Initialized
INFO - 2016-05-11 20:18:54 --> Model Class Initialized
INFO - 2016-05-11 20:18:54 --> Database Driver Class Initialized
INFO - 2016-05-11 20:18:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:18:54 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:18:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:18:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:18:54 --> Final output sent to browser
DEBUG - 2016-05-11 20:18:54 --> Total execution time: 0.1051
INFO - 2016-05-11 20:18:56 --> Config Class Initialized
INFO - 2016-05-11 20:18:56 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:18:56 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:18:56 --> Utf8 Class Initialized
INFO - 2016-05-11 20:18:56 --> URI Class Initialized
INFO - 2016-05-11 20:18:56 --> Router Class Initialized
INFO - 2016-05-11 20:18:56 --> Output Class Initialized
INFO - 2016-05-11 20:18:56 --> Security Class Initialized
DEBUG - 2016-05-11 20:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:18:56 --> Input Class Initialized
INFO - 2016-05-11 20:18:56 --> Language Class Initialized
INFO - 2016-05-11 20:18:56 --> Loader Class Initialized
INFO - 2016-05-11 20:18:56 --> Helper loaded: url_helper
INFO - 2016-05-11 20:18:56 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:18:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:18:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:18:56 --> Helper loaded: form_helper
INFO - 2016-05-11 20:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:18:56 --> Form Validation Class Initialized
INFO - 2016-05-11 20:18:56 --> Controller Class Initialized
INFO - 2016-05-11 20:18:56 --> Model Class Initialized
INFO - 2016-05-11 20:18:56 --> Database Driver Class Initialized
INFO - 2016-05-11 20:18:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:18:56 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:18:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:18:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:18:56 --> Final output sent to browser
DEBUG - 2016-05-11 20:18:56 --> Total execution time: 0.0844
INFO - 2016-05-11 20:18:57 --> Config Class Initialized
INFO - 2016-05-11 20:18:57 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:18:57 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:18:57 --> Utf8 Class Initialized
INFO - 2016-05-11 20:18:57 --> URI Class Initialized
DEBUG - 2016-05-11 20:18:57 --> No URI present. Default controller set.
INFO - 2016-05-11 20:18:57 --> Router Class Initialized
INFO - 2016-05-11 20:18:57 --> Output Class Initialized
INFO - 2016-05-11 20:18:57 --> Security Class Initialized
DEBUG - 2016-05-11 20:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:18:57 --> Input Class Initialized
INFO - 2016-05-11 20:18:57 --> Language Class Initialized
INFO - 2016-05-11 20:18:57 --> Loader Class Initialized
INFO - 2016-05-11 20:18:57 --> Helper loaded: url_helper
INFO - 2016-05-11 20:18:57 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:18:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:18:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:18:57 --> Helper loaded: form_helper
INFO - 2016-05-11 20:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:18:57 --> Form Validation Class Initialized
INFO - 2016-05-11 20:18:57 --> Controller Class Initialized
INFO - 2016-05-11 20:18:57 --> Model Class Initialized
INFO - 2016-05-11 20:18:57 --> Database Driver Class Initialized
INFO - 2016-05-11 20:18:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:18:57 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:18:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:18:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:18:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:18:57 --> Final output sent to browser
DEBUG - 2016-05-11 20:18:57 --> Total execution time: 0.0716
INFO - 2016-05-11 20:18:57 --> Config Class Initialized
INFO - 2016-05-11 20:18:57 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:18:57 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:18:57 --> Utf8 Class Initialized
INFO - 2016-05-11 20:18:57 --> URI Class Initialized
INFO - 2016-05-11 20:18:57 --> Router Class Initialized
INFO - 2016-05-11 20:18:57 --> Output Class Initialized
INFO - 2016-05-11 20:18:57 --> Security Class Initialized
DEBUG - 2016-05-11 20:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:18:57 --> Input Class Initialized
INFO - 2016-05-11 20:18:57 --> Language Class Initialized
INFO - 2016-05-11 20:18:57 --> Loader Class Initialized
INFO - 2016-05-11 20:18:57 --> Helper loaded: url_helper
INFO - 2016-05-11 20:18:57 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:18:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:18:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:18:57 --> Helper loaded: form_helper
INFO - 2016-05-11 20:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:18:57 --> Form Validation Class Initialized
INFO - 2016-05-11 20:18:57 --> Controller Class Initialized
INFO - 2016-05-11 20:18:57 --> Model Class Initialized
INFO - 2016-05-11 20:18:57 --> Database Driver Class Initialized
INFO - 2016-05-11 20:18:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:18:57 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:18:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:18:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:18:58 --> Final output sent to browser
DEBUG - 2016-05-11 20:18:58 --> Total execution time: 0.1017
INFO - 2016-05-11 20:18:59 --> Config Class Initialized
INFO - 2016-05-11 20:18:59 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:18:59 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:18:59 --> Utf8 Class Initialized
INFO - 2016-05-11 20:18:59 --> URI Class Initialized
INFO - 2016-05-11 20:18:59 --> Router Class Initialized
INFO - 2016-05-11 20:18:59 --> Output Class Initialized
INFO - 2016-05-11 20:18:59 --> Security Class Initialized
DEBUG - 2016-05-11 20:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:18:59 --> Input Class Initialized
INFO - 2016-05-11 20:18:59 --> Language Class Initialized
INFO - 2016-05-11 20:18:59 --> Loader Class Initialized
INFO - 2016-05-11 20:18:59 --> Helper loaded: url_helper
INFO - 2016-05-11 20:18:59 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:18:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:18:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:18:59 --> Helper loaded: form_helper
INFO - 2016-05-11 20:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:18:59 --> Form Validation Class Initialized
INFO - 2016-05-11 20:18:59 --> Controller Class Initialized
INFO - 2016-05-11 20:18:59 --> Model Class Initialized
INFO - 2016-05-11 20:18:59 --> Database Driver Class Initialized
INFO - 2016-05-11 20:18:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:18:59 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:18:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:18:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:18:59 --> Final output sent to browser
DEBUG - 2016-05-11 20:18:59 --> Total execution time: 0.1183
INFO - 2016-05-11 20:19:13 --> Config Class Initialized
INFO - 2016-05-11 20:19:13 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:19:13 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:19:13 --> Utf8 Class Initialized
INFO - 2016-05-11 20:19:13 --> URI Class Initialized
DEBUG - 2016-05-11 20:19:13 --> No URI present. Default controller set.
INFO - 2016-05-11 20:19:13 --> Router Class Initialized
INFO - 2016-05-11 20:19:13 --> Output Class Initialized
INFO - 2016-05-11 20:19:13 --> Security Class Initialized
DEBUG - 2016-05-11 20:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:19:13 --> Input Class Initialized
INFO - 2016-05-11 20:19:13 --> Language Class Initialized
INFO - 2016-05-11 20:19:13 --> Loader Class Initialized
INFO - 2016-05-11 20:19:13 --> Helper loaded: url_helper
INFO - 2016-05-11 20:19:14 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:19:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:19:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:19:14 --> Helper loaded: form_helper
INFO - 2016-05-11 20:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:19:14 --> Form Validation Class Initialized
INFO - 2016-05-11 20:19:14 --> Controller Class Initialized
INFO - 2016-05-11 20:19:14 --> Model Class Initialized
INFO - 2016-05-11 20:19:14 --> Database Driver Class Initialized
INFO - 2016-05-11 20:19:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:19:14 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:19:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:19:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:19:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:19:14 --> Final output sent to browser
DEBUG - 2016-05-11 20:19:14 --> Total execution time: 0.0726
INFO - 2016-05-11 20:19:14 --> Config Class Initialized
INFO - 2016-05-11 20:19:14 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:19:14 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:19:14 --> Utf8 Class Initialized
INFO - 2016-05-11 20:19:14 --> URI Class Initialized
INFO - 2016-05-11 20:19:14 --> Router Class Initialized
INFO - 2016-05-11 20:19:14 --> Output Class Initialized
INFO - 2016-05-11 20:19:14 --> Security Class Initialized
DEBUG - 2016-05-11 20:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:19:14 --> Input Class Initialized
INFO - 2016-05-11 20:19:14 --> Language Class Initialized
INFO - 2016-05-11 20:19:14 --> Loader Class Initialized
INFO - 2016-05-11 20:19:14 --> Helper loaded: url_helper
INFO - 2016-05-11 20:19:14 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:19:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:19:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:19:14 --> Helper loaded: form_helper
INFO - 2016-05-11 20:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:19:14 --> Form Validation Class Initialized
INFO - 2016-05-11 20:19:14 --> Controller Class Initialized
INFO - 2016-05-11 20:19:14 --> Model Class Initialized
INFO - 2016-05-11 20:19:14 --> Database Driver Class Initialized
INFO - 2016-05-11 20:19:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:19:14 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:19:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:19:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:19:14 --> Final output sent to browser
DEBUG - 2016-05-11 20:19:14 --> Total execution time: 0.1151
INFO - 2016-05-11 20:19:17 --> Config Class Initialized
INFO - 2016-05-11 20:19:17 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:19:17 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:19:17 --> Utf8 Class Initialized
INFO - 2016-05-11 20:19:17 --> URI Class Initialized
DEBUG - 2016-05-11 20:19:17 --> No URI present. Default controller set.
INFO - 2016-05-11 20:19:17 --> Router Class Initialized
INFO - 2016-05-11 20:19:17 --> Output Class Initialized
INFO - 2016-05-11 20:19:17 --> Security Class Initialized
DEBUG - 2016-05-11 20:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:19:17 --> Input Class Initialized
INFO - 2016-05-11 20:19:17 --> Language Class Initialized
INFO - 2016-05-11 20:19:17 --> Loader Class Initialized
INFO - 2016-05-11 20:19:17 --> Helper loaded: url_helper
INFO - 2016-05-11 20:19:17 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:19:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:19:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:19:17 --> Helper loaded: form_helper
INFO - 2016-05-11 20:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:19:17 --> Form Validation Class Initialized
INFO - 2016-05-11 20:19:17 --> Controller Class Initialized
INFO - 2016-05-11 20:19:17 --> Model Class Initialized
INFO - 2016-05-11 20:19:17 --> Database Driver Class Initialized
INFO - 2016-05-11 20:19:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:19:17 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:19:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:19:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:19:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:19:17 --> Final output sent to browser
DEBUG - 2016-05-11 20:19:17 --> Total execution time: 0.0773
INFO - 2016-05-11 20:19:17 --> Config Class Initialized
INFO - 2016-05-11 20:19:17 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:19:17 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:19:17 --> Utf8 Class Initialized
INFO - 2016-05-11 20:19:17 --> URI Class Initialized
INFO - 2016-05-11 20:19:17 --> Router Class Initialized
INFO - 2016-05-11 20:19:17 --> Output Class Initialized
INFO - 2016-05-11 20:19:17 --> Security Class Initialized
DEBUG - 2016-05-11 20:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:19:17 --> Input Class Initialized
INFO - 2016-05-11 20:19:17 --> Language Class Initialized
INFO - 2016-05-11 20:19:17 --> Loader Class Initialized
INFO - 2016-05-11 20:19:17 --> Helper loaded: url_helper
INFO - 2016-05-11 20:19:17 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:19:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:19:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:19:17 --> Helper loaded: form_helper
INFO - 2016-05-11 20:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:19:17 --> Form Validation Class Initialized
INFO - 2016-05-11 20:19:17 --> Controller Class Initialized
INFO - 2016-05-11 20:19:17 --> Model Class Initialized
INFO - 2016-05-11 20:19:17 --> Database Driver Class Initialized
INFO - 2016-05-11 20:19:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:19:17 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:19:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:19:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:19:17 --> Final output sent to browser
DEBUG - 2016-05-11 20:19:17 --> Total execution time: 0.1165
INFO - 2016-05-11 20:19:37 --> Config Class Initialized
INFO - 2016-05-11 20:19:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:19:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:19:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:19:37 --> URI Class Initialized
INFO - 2016-05-11 20:19:37 --> Router Class Initialized
INFO - 2016-05-11 20:19:37 --> Output Class Initialized
INFO - 2016-05-11 20:19:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:19:37 --> Input Class Initialized
INFO - 2016-05-11 20:19:37 --> Language Class Initialized
INFO - 2016-05-11 20:19:38 --> Loader Class Initialized
INFO - 2016-05-11 20:19:38 --> Helper loaded: url_helper
INFO - 2016-05-11 20:19:38 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:19:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:19:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:19:38 --> Helper loaded: form_helper
INFO - 2016-05-11 20:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:19:38 --> Form Validation Class Initialized
INFO - 2016-05-11 20:19:38 --> Controller Class Initialized
INFO - 2016-05-11 20:19:38 --> Model Class Initialized
INFO - 2016-05-11 20:19:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:19:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:19:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:19:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:19:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:19:38 --> Total execution time: 0.0700
INFO - 2016-05-11 20:19:52 --> Config Class Initialized
INFO - 2016-05-11 20:19:52 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:19:52 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:19:52 --> Utf8 Class Initialized
INFO - 2016-05-11 20:19:52 --> URI Class Initialized
DEBUG - 2016-05-11 20:19:52 --> No URI present. Default controller set.
INFO - 2016-05-11 20:19:52 --> Router Class Initialized
INFO - 2016-05-11 20:19:52 --> Output Class Initialized
INFO - 2016-05-11 20:19:52 --> Security Class Initialized
DEBUG - 2016-05-11 20:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:19:52 --> Input Class Initialized
INFO - 2016-05-11 20:19:52 --> Language Class Initialized
INFO - 2016-05-11 20:19:52 --> Loader Class Initialized
INFO - 2016-05-11 20:19:52 --> Helper loaded: url_helper
INFO - 2016-05-11 20:19:52 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:19:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:19:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:19:52 --> Helper loaded: form_helper
INFO - 2016-05-11 20:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:19:52 --> Form Validation Class Initialized
INFO - 2016-05-11 20:19:52 --> Controller Class Initialized
INFO - 2016-05-11 20:19:52 --> Model Class Initialized
INFO - 2016-05-11 20:19:52 --> Database Driver Class Initialized
INFO - 2016-05-11 20:19:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:19:52 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:19:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:19:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
ERROR - 2016-05-11 20:19:52 --> Severity: Notice --> Undefined variable: links C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\helpers\ven_templates_helper.php 32
INFO - 2016-05-11 20:19:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:19:52 --> Final output sent to browser
DEBUG - 2016-05-11 20:19:52 --> Total execution time: 0.1042
INFO - 2016-05-11 20:19:53 --> Config Class Initialized
INFO - 2016-05-11 20:19:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:19:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:19:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:19:53 --> URI Class Initialized
INFO - 2016-05-11 20:19:53 --> Router Class Initialized
INFO - 2016-05-11 20:19:53 --> Output Class Initialized
INFO - 2016-05-11 20:19:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:19:53 --> Input Class Initialized
INFO - 2016-05-11 20:19:53 --> Language Class Initialized
INFO - 2016-05-11 20:19:53 --> Loader Class Initialized
INFO - 2016-05-11 20:19:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:19:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:19:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:19:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:19:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:19:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:19:53 --> Controller Class Initialized
INFO - 2016-05-11 20:19:53 --> Model Class Initialized
INFO - 2016-05-11 20:19:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:19:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:19:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:19:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:19:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:19:53 --> Total execution time: 0.0734
INFO - 2016-05-11 20:20:17 --> Config Class Initialized
INFO - 2016-05-11 20:20:17 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:20:17 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:20:17 --> Utf8 Class Initialized
INFO - 2016-05-11 20:20:17 --> URI Class Initialized
DEBUG - 2016-05-11 20:20:17 --> No URI present. Default controller set.
INFO - 2016-05-11 20:20:17 --> Router Class Initialized
INFO - 2016-05-11 20:20:17 --> Output Class Initialized
INFO - 2016-05-11 20:20:17 --> Security Class Initialized
DEBUG - 2016-05-11 20:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:20:17 --> Input Class Initialized
INFO - 2016-05-11 20:20:17 --> Language Class Initialized
INFO - 2016-05-11 20:20:17 --> Loader Class Initialized
INFO - 2016-05-11 20:20:17 --> Helper loaded: url_helper
INFO - 2016-05-11 20:20:17 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:20:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:20:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:20:17 --> Helper loaded: form_helper
INFO - 2016-05-11 20:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:20:17 --> Form Validation Class Initialized
INFO - 2016-05-11 20:20:17 --> Controller Class Initialized
INFO - 2016-05-11 20:20:17 --> Model Class Initialized
INFO - 2016-05-11 20:20:17 --> Database Driver Class Initialized
INFO - 2016-05-11 20:20:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:20:17 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:20:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:20:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:20:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:20:17 --> Final output sent to browser
DEBUG - 2016-05-11 20:20:17 --> Total execution time: 0.0882
INFO - 2016-05-11 20:20:21 --> Config Class Initialized
INFO - 2016-05-11 20:20:21 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:20:21 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:20:21 --> Utf8 Class Initialized
INFO - 2016-05-11 20:20:21 --> URI Class Initialized
INFO - 2016-05-11 20:20:21 --> Router Class Initialized
INFO - 2016-05-11 20:20:21 --> Output Class Initialized
INFO - 2016-05-11 20:20:21 --> Security Class Initialized
DEBUG - 2016-05-11 20:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:20:21 --> Input Class Initialized
INFO - 2016-05-11 20:20:21 --> Language Class Initialized
INFO - 2016-05-11 20:20:21 --> Loader Class Initialized
INFO - 2016-05-11 20:20:21 --> Helper loaded: url_helper
INFO - 2016-05-11 20:20:21 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:20:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:20:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:20:21 --> Helper loaded: form_helper
INFO - 2016-05-11 20:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:20:21 --> Form Validation Class Initialized
INFO - 2016-05-11 20:20:21 --> Controller Class Initialized
INFO - 2016-05-11 20:20:21 --> Model Class Initialized
INFO - 2016-05-11 20:20:21 --> Database Driver Class Initialized
INFO - 2016-05-11 20:20:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:20:21 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:20:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:20:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:20:21 --> Final output sent to browser
DEBUG - 2016-05-11 20:20:21 --> Total execution time: 0.0830
INFO - 2016-05-11 20:20:22 --> Config Class Initialized
INFO - 2016-05-11 20:20:22 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:20:22 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:20:22 --> Utf8 Class Initialized
INFO - 2016-05-11 20:20:22 --> URI Class Initialized
DEBUG - 2016-05-11 20:20:22 --> No URI present. Default controller set.
INFO - 2016-05-11 20:20:22 --> Router Class Initialized
INFO - 2016-05-11 20:20:22 --> Output Class Initialized
INFO - 2016-05-11 20:20:22 --> Security Class Initialized
DEBUG - 2016-05-11 20:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:20:22 --> Input Class Initialized
INFO - 2016-05-11 20:20:22 --> Language Class Initialized
INFO - 2016-05-11 20:20:22 --> Loader Class Initialized
INFO - 2016-05-11 20:20:22 --> Helper loaded: url_helper
INFO - 2016-05-11 20:20:22 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:20:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:20:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:20:22 --> Helper loaded: form_helper
INFO - 2016-05-11 20:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:20:22 --> Form Validation Class Initialized
INFO - 2016-05-11 20:20:22 --> Controller Class Initialized
INFO - 2016-05-11 20:20:22 --> Model Class Initialized
INFO - 2016-05-11 20:20:22 --> Database Driver Class Initialized
INFO - 2016-05-11 20:20:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:20:22 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:20:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:20:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:20:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:20:22 --> Final output sent to browser
DEBUG - 2016-05-11 20:20:22 --> Total execution time: 0.0749
INFO - 2016-05-11 20:20:38 --> Config Class Initialized
INFO - 2016-05-11 20:20:38 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:20:38 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:20:38 --> Utf8 Class Initialized
INFO - 2016-05-11 20:20:38 --> URI Class Initialized
INFO - 2016-05-11 20:20:38 --> Router Class Initialized
INFO - 2016-05-11 20:20:38 --> Output Class Initialized
INFO - 2016-05-11 20:20:38 --> Security Class Initialized
DEBUG - 2016-05-11 20:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:20:38 --> Input Class Initialized
INFO - 2016-05-11 20:20:38 --> Language Class Initialized
INFO - 2016-05-11 20:20:38 --> Loader Class Initialized
INFO - 2016-05-11 20:20:38 --> Helper loaded: url_helper
INFO - 2016-05-11 20:20:38 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:20:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:20:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:20:38 --> Helper loaded: form_helper
INFO - 2016-05-11 20:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:20:38 --> Form Validation Class Initialized
INFO - 2016-05-11 20:20:38 --> Controller Class Initialized
INFO - 2016-05-11 20:20:38 --> Model Class Initialized
INFO - 2016-05-11 20:20:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:20:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:20:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:20:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:20:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:20:38 --> Total execution time: 0.1137
INFO - 2016-05-11 20:20:53 --> Config Class Initialized
INFO - 2016-05-11 20:20:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:20:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:20:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:20:53 --> URI Class Initialized
INFO - 2016-05-11 20:20:53 --> Router Class Initialized
INFO - 2016-05-11 20:20:53 --> Output Class Initialized
INFO - 2016-05-11 20:20:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:20:53 --> Input Class Initialized
INFO - 2016-05-11 20:20:53 --> Language Class Initialized
INFO - 2016-05-11 20:20:53 --> Loader Class Initialized
INFO - 2016-05-11 20:20:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:20:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:20:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:20:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:20:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:20:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:20:53 --> Controller Class Initialized
INFO - 2016-05-11 20:20:53 --> Model Class Initialized
INFO - 2016-05-11 20:20:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:20:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:20:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:20:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:20:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:20:53 --> Total execution time: 0.0742
INFO - 2016-05-11 20:21:37 --> Config Class Initialized
INFO - 2016-05-11 20:21:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:21:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:21:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:21:37 --> URI Class Initialized
INFO - 2016-05-11 20:21:37 --> Router Class Initialized
INFO - 2016-05-11 20:21:37 --> Output Class Initialized
INFO - 2016-05-11 20:21:37 --> Security Class Initialized
DEBUG - 2016-05-11 20:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:21:37 --> Input Class Initialized
INFO - 2016-05-11 20:21:37 --> Language Class Initialized
INFO - 2016-05-11 20:21:37 --> Loader Class Initialized
INFO - 2016-05-11 20:21:37 --> Helper loaded: url_helper
INFO - 2016-05-11 20:21:37 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:21:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:21:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:21:37 --> Helper loaded: form_helper
INFO - 2016-05-11 20:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:21:38 --> Form Validation Class Initialized
INFO - 2016-05-11 20:21:38 --> Controller Class Initialized
INFO - 2016-05-11 20:21:38 --> Model Class Initialized
INFO - 2016-05-11 20:21:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:21:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:21:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:21:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:21:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:21:38 --> Total execution time: 0.0981
INFO - 2016-05-11 20:21:48 --> Config Class Initialized
INFO - 2016-05-11 20:21:48 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:21:48 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:21:48 --> Utf8 Class Initialized
INFO - 2016-05-11 20:21:48 --> URI Class Initialized
DEBUG - 2016-05-11 20:21:48 --> No URI present. Default controller set.
INFO - 2016-05-11 20:21:48 --> Router Class Initialized
INFO - 2016-05-11 20:21:48 --> Output Class Initialized
INFO - 2016-05-11 20:21:48 --> Security Class Initialized
DEBUG - 2016-05-11 20:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:21:48 --> Input Class Initialized
INFO - 2016-05-11 20:21:48 --> Language Class Initialized
INFO - 2016-05-11 20:21:48 --> Loader Class Initialized
INFO - 2016-05-11 20:21:48 --> Helper loaded: url_helper
INFO - 2016-05-11 20:21:48 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:21:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:21:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:21:48 --> Helper loaded: form_helper
INFO - 2016-05-11 20:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:21:48 --> Form Validation Class Initialized
INFO - 2016-05-11 20:21:48 --> Controller Class Initialized
INFO - 2016-05-11 20:21:48 --> Model Class Initialized
INFO - 2016-05-11 20:21:48 --> Database Driver Class Initialized
INFO - 2016-05-11 20:21:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:21:48 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:21:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:21:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:21:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:21:48 --> Final output sent to browser
DEBUG - 2016-05-11 20:21:48 --> Total execution time: 0.1191
INFO - 2016-05-11 20:21:53 --> Config Class Initialized
INFO - 2016-05-11 20:21:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:21:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:21:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:21:53 --> URI Class Initialized
INFO - 2016-05-11 20:21:53 --> Router Class Initialized
INFO - 2016-05-11 20:21:53 --> Output Class Initialized
INFO - 2016-05-11 20:21:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:21:53 --> Input Class Initialized
INFO - 2016-05-11 20:21:53 --> Language Class Initialized
INFO - 2016-05-11 20:21:53 --> Loader Class Initialized
INFO - 2016-05-11 20:21:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:21:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:21:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:21:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:21:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:21:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:21:53 --> Controller Class Initialized
INFO - 2016-05-11 20:21:53 --> Model Class Initialized
INFO - 2016-05-11 20:21:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:21:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:21:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:21:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:21:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:21:53 --> Total execution time: 0.0668
INFO - 2016-05-11 20:21:57 --> Config Class Initialized
INFO - 2016-05-11 20:21:57 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:21:57 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:21:57 --> Utf8 Class Initialized
INFO - 2016-05-11 20:21:57 --> URI Class Initialized
INFO - 2016-05-11 20:21:57 --> Router Class Initialized
INFO - 2016-05-11 20:21:57 --> Output Class Initialized
INFO - 2016-05-11 20:21:57 --> Security Class Initialized
DEBUG - 2016-05-11 20:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:21:57 --> Input Class Initialized
INFO - 2016-05-11 20:21:57 --> Language Class Initialized
INFO - 2016-05-11 20:21:57 --> Loader Class Initialized
INFO - 2016-05-11 20:21:57 --> Helper loaded: url_helper
INFO - 2016-05-11 20:21:57 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:21:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:21:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:21:57 --> Helper loaded: form_helper
INFO - 2016-05-11 20:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:21:57 --> Form Validation Class Initialized
INFO - 2016-05-11 20:21:57 --> Controller Class Initialized
INFO - 2016-05-11 20:21:57 --> Model Class Initialized
INFO - 2016-05-11 20:21:57 --> Database Driver Class Initialized
INFO - 2016-05-11 20:21:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:21:57 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:21:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:21:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:21:57 --> Final output sent to browser
DEBUG - 2016-05-11 20:21:57 --> Total execution time: 0.0713
INFO - 2016-05-11 20:21:58 --> Config Class Initialized
INFO - 2016-05-11 20:21:58 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:21:58 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:21:58 --> Utf8 Class Initialized
INFO - 2016-05-11 20:21:58 --> URI Class Initialized
DEBUG - 2016-05-11 20:21:58 --> No URI present. Default controller set.
INFO - 2016-05-11 20:21:58 --> Router Class Initialized
INFO - 2016-05-11 20:21:58 --> Output Class Initialized
INFO - 2016-05-11 20:21:58 --> Security Class Initialized
DEBUG - 2016-05-11 20:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:21:58 --> Input Class Initialized
INFO - 2016-05-11 20:21:58 --> Language Class Initialized
INFO - 2016-05-11 20:21:58 --> Loader Class Initialized
INFO - 2016-05-11 20:21:58 --> Helper loaded: url_helper
INFO - 2016-05-11 20:21:58 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:21:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:21:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:21:58 --> Helper loaded: form_helper
INFO - 2016-05-11 20:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:21:58 --> Form Validation Class Initialized
INFO - 2016-05-11 20:21:58 --> Controller Class Initialized
INFO - 2016-05-11 20:21:58 --> Model Class Initialized
INFO - 2016-05-11 20:21:58 --> Database Driver Class Initialized
INFO - 2016-05-11 20:21:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:21:58 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:21:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:21:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:21:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:21:58 --> Final output sent to browser
DEBUG - 2016-05-11 20:21:58 --> Total execution time: 0.1032
INFO - 2016-05-11 20:22:08 --> Config Class Initialized
INFO - 2016-05-11 20:22:08 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:22:08 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:22:08 --> Utf8 Class Initialized
INFO - 2016-05-11 20:22:08 --> URI Class Initialized
INFO - 2016-05-11 20:22:08 --> Router Class Initialized
INFO - 2016-05-11 20:22:08 --> Output Class Initialized
INFO - 2016-05-11 20:22:08 --> Security Class Initialized
DEBUG - 2016-05-11 20:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:22:08 --> Input Class Initialized
INFO - 2016-05-11 20:22:08 --> Language Class Initialized
INFO - 2016-05-11 20:22:08 --> Loader Class Initialized
INFO - 2016-05-11 20:22:08 --> Helper loaded: url_helper
INFO - 2016-05-11 20:22:08 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:22:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:22:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:22:08 --> Helper loaded: form_helper
INFO - 2016-05-11 20:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:22:08 --> Form Validation Class Initialized
INFO - 2016-05-11 20:22:08 --> Controller Class Initialized
INFO - 2016-05-11 20:22:08 --> Model Class Initialized
INFO - 2016-05-11 20:22:08 --> Database Driver Class Initialized
INFO - 2016-05-11 20:22:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:22:08 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:22:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:22:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:22:08 --> Final output sent to browser
DEBUG - 2016-05-11 20:22:08 --> Total execution time: 0.0727
INFO - 2016-05-11 20:22:37 --> Config Class Initialized
INFO - 2016-05-11 20:22:37 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:22:37 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:22:37 --> Utf8 Class Initialized
INFO - 2016-05-11 20:22:37 --> URI Class Initialized
INFO - 2016-05-11 20:22:37 --> Router Class Initialized
INFO - 2016-05-11 20:22:37 --> Output Class Initialized
INFO - 2016-05-11 20:22:38 --> Security Class Initialized
DEBUG - 2016-05-11 20:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:22:38 --> Input Class Initialized
INFO - 2016-05-11 20:22:38 --> Language Class Initialized
INFO - 2016-05-11 20:22:38 --> Loader Class Initialized
INFO - 2016-05-11 20:22:38 --> Helper loaded: url_helper
INFO - 2016-05-11 20:22:38 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:22:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:22:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:22:38 --> Helper loaded: form_helper
INFO - 2016-05-11 20:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:22:38 --> Form Validation Class Initialized
INFO - 2016-05-11 20:22:38 --> Controller Class Initialized
INFO - 2016-05-11 20:22:38 --> Model Class Initialized
INFO - 2016-05-11 20:22:38 --> Database Driver Class Initialized
INFO - 2016-05-11 20:22:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:22:38 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:22:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:22:38 --> Final output sent to browser
DEBUG - 2016-05-11 20:22:38 --> Total execution time: 0.0856
INFO - 2016-05-11 20:22:53 --> Config Class Initialized
INFO - 2016-05-11 20:22:53 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:22:53 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:22:53 --> Utf8 Class Initialized
INFO - 2016-05-11 20:22:53 --> URI Class Initialized
INFO - 2016-05-11 20:22:53 --> Router Class Initialized
INFO - 2016-05-11 20:22:53 --> Output Class Initialized
INFO - 2016-05-11 20:22:53 --> Security Class Initialized
DEBUG - 2016-05-11 20:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:22:53 --> Input Class Initialized
INFO - 2016-05-11 20:22:53 --> Language Class Initialized
INFO - 2016-05-11 20:22:53 --> Loader Class Initialized
INFO - 2016-05-11 20:22:53 --> Helper loaded: url_helper
INFO - 2016-05-11 20:22:53 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:22:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:22:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:22:53 --> Helper loaded: form_helper
INFO - 2016-05-11 20:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:22:53 --> Form Validation Class Initialized
INFO - 2016-05-11 20:22:53 --> Controller Class Initialized
INFO - 2016-05-11 20:22:53 --> Model Class Initialized
INFO - 2016-05-11 20:22:53 --> Database Driver Class Initialized
INFO - 2016-05-11 20:22:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:22:53 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:22:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:22:53 --> Final output sent to browser
DEBUG - 2016-05-11 20:22:53 --> Total execution time: 0.0695
INFO - 2016-05-11 20:23:42 --> Config Class Initialized
INFO - 2016-05-11 20:23:42 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:23:42 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:23:42 --> Utf8 Class Initialized
INFO - 2016-05-11 20:23:42 --> URI Class Initialized
DEBUG - 2016-05-11 20:23:42 --> No URI present. Default controller set.
INFO - 2016-05-11 20:23:42 --> Router Class Initialized
INFO - 2016-05-11 20:23:42 --> Output Class Initialized
INFO - 2016-05-11 20:23:42 --> Security Class Initialized
DEBUG - 2016-05-11 20:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:23:42 --> Input Class Initialized
INFO - 2016-05-11 20:23:42 --> Language Class Initialized
INFO - 2016-05-11 20:23:42 --> Loader Class Initialized
INFO - 2016-05-11 20:23:42 --> Helper loaded: url_helper
INFO - 2016-05-11 20:23:42 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:23:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:23:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:23:42 --> Helper loaded: form_helper
INFO - 2016-05-11 20:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:23:42 --> Form Validation Class Initialized
INFO - 2016-05-11 20:23:42 --> Controller Class Initialized
INFO - 2016-05-11 20:23:42 --> Model Class Initialized
INFO - 2016-05-11 20:23:42 --> Database Driver Class Initialized
INFO - 2016-05-11 20:23:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:23:42 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:23:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:23:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:23:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:23:42 --> Final output sent to browser
DEBUG - 2016-05-11 20:23:42 --> Total execution time: 0.0949
INFO - 2016-05-11 20:23:45 --> Config Class Initialized
INFO - 2016-05-11 20:23:45 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:23:45 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:23:45 --> Utf8 Class Initialized
INFO - 2016-05-11 20:23:45 --> URI Class Initialized
INFO - 2016-05-11 20:23:45 --> Router Class Initialized
INFO - 2016-05-11 20:23:45 --> Output Class Initialized
INFO - 2016-05-11 20:23:45 --> Security Class Initialized
DEBUG - 2016-05-11 20:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:23:45 --> Input Class Initialized
INFO - 2016-05-11 20:23:45 --> Language Class Initialized
INFO - 2016-05-11 20:23:45 --> Loader Class Initialized
INFO - 2016-05-11 20:23:45 --> Helper loaded: url_helper
INFO - 2016-05-11 20:23:45 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:23:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:23:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:23:45 --> Helper loaded: form_helper
INFO - 2016-05-11 20:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:23:45 --> Form Validation Class Initialized
INFO - 2016-05-11 20:23:45 --> Controller Class Initialized
INFO - 2016-05-11 20:23:45 --> Model Class Initialized
INFO - 2016-05-11 20:23:45 --> Database Driver Class Initialized
INFO - 2016-05-11 20:23:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:23:45 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:23:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:23:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:23:45 --> Final output sent to browser
DEBUG - 2016-05-11 20:23:45 --> Total execution time: 0.1074
INFO - 2016-05-11 20:23:46 --> Config Class Initialized
INFO - 2016-05-11 20:23:46 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:23:46 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:23:46 --> Utf8 Class Initialized
INFO - 2016-05-11 20:23:46 --> URI Class Initialized
DEBUG - 2016-05-11 20:23:46 --> No URI present. Default controller set.
INFO - 2016-05-11 20:23:46 --> Router Class Initialized
INFO - 2016-05-11 20:23:46 --> Output Class Initialized
INFO - 2016-05-11 20:23:46 --> Security Class Initialized
DEBUG - 2016-05-11 20:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:23:46 --> Input Class Initialized
INFO - 2016-05-11 20:23:46 --> Language Class Initialized
INFO - 2016-05-11 20:23:46 --> Loader Class Initialized
INFO - 2016-05-11 20:23:46 --> Helper loaded: url_helper
INFO - 2016-05-11 20:23:46 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:23:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:23:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:23:46 --> Helper loaded: form_helper
INFO - 2016-05-11 20:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:23:46 --> Form Validation Class Initialized
INFO - 2016-05-11 20:23:46 --> Controller Class Initialized
INFO - 2016-05-11 20:23:46 --> Model Class Initialized
INFO - 2016-05-11 20:23:46 --> Database Driver Class Initialized
INFO - 2016-05-11 20:23:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:23:46 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:23:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:23:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:23:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:23:46 --> Final output sent to browser
DEBUG - 2016-05-11 20:23:46 --> Total execution time: 0.0907
INFO - 2016-05-11 20:23:58 --> Config Class Initialized
INFO - 2016-05-11 20:23:58 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:23:58 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:23:58 --> Utf8 Class Initialized
INFO - 2016-05-11 20:23:58 --> URI Class Initialized
DEBUG - 2016-05-11 20:23:58 --> No URI present. Default controller set.
INFO - 2016-05-11 20:23:58 --> Router Class Initialized
INFO - 2016-05-11 20:23:58 --> Output Class Initialized
INFO - 2016-05-11 20:23:58 --> Security Class Initialized
DEBUG - 2016-05-11 20:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:23:58 --> Input Class Initialized
INFO - 2016-05-11 20:23:58 --> Language Class Initialized
INFO - 2016-05-11 20:23:58 --> Loader Class Initialized
INFO - 2016-05-11 20:23:58 --> Helper loaded: url_helper
INFO - 2016-05-11 20:23:58 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:23:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:23:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:23:58 --> Helper loaded: form_helper
INFO - 2016-05-11 20:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:23:58 --> Form Validation Class Initialized
INFO - 2016-05-11 20:23:58 --> Controller Class Initialized
INFO - 2016-05-11 20:23:58 --> Model Class Initialized
INFO - 2016-05-11 20:23:58 --> Database Driver Class Initialized
INFO - 2016-05-11 20:23:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:23:58 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:23:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:23:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:23:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:23:58 --> Final output sent to browser
DEBUG - 2016-05-11 20:23:58 --> Total execution time: 0.0826
INFO - 2016-05-11 20:24:01 --> Config Class Initialized
INFO - 2016-05-11 20:24:01 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:24:01 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:24:01 --> Utf8 Class Initialized
INFO - 2016-05-11 20:24:01 --> URI Class Initialized
INFO - 2016-05-11 20:24:01 --> Router Class Initialized
INFO - 2016-05-11 20:24:01 --> Output Class Initialized
INFO - 2016-05-11 20:24:01 --> Security Class Initialized
DEBUG - 2016-05-11 20:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:24:01 --> Input Class Initialized
INFO - 2016-05-11 20:24:01 --> Language Class Initialized
INFO - 2016-05-11 20:24:01 --> Loader Class Initialized
INFO - 2016-05-11 20:24:01 --> Helper loaded: url_helper
INFO - 2016-05-11 20:24:01 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:24:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:24:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:24:01 --> Helper loaded: form_helper
INFO - 2016-05-11 20:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:24:01 --> Form Validation Class Initialized
INFO - 2016-05-11 20:24:01 --> Controller Class Initialized
INFO - 2016-05-11 20:24:01 --> Model Class Initialized
INFO - 2016-05-11 20:24:01 --> Database Driver Class Initialized
INFO - 2016-05-11 20:24:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:24:02 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:24:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:24:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:24:02 --> Final output sent to browser
DEBUG - 2016-05-11 20:24:02 --> Total execution time: 0.0699
INFO - 2016-05-11 20:25:34 --> Config Class Initialized
INFO - 2016-05-11 20:25:34 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:25:34 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:25:34 --> Utf8 Class Initialized
INFO - 2016-05-11 20:25:34 --> URI Class Initialized
DEBUG - 2016-05-11 20:25:34 --> No URI present. Default controller set.
INFO - 2016-05-11 20:25:34 --> Router Class Initialized
INFO - 2016-05-11 20:25:34 --> Output Class Initialized
INFO - 2016-05-11 20:25:34 --> Security Class Initialized
DEBUG - 2016-05-11 20:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:25:34 --> Input Class Initialized
INFO - 2016-05-11 20:25:34 --> Language Class Initialized
INFO - 2016-05-11 20:25:34 --> Loader Class Initialized
INFO - 2016-05-11 20:25:34 --> Helper loaded: url_helper
INFO - 2016-05-11 20:25:34 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:25:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:25:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:25:34 --> Helper loaded: form_helper
INFO - 2016-05-11 20:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:25:34 --> Form Validation Class Initialized
INFO - 2016-05-11 20:25:34 --> Controller Class Initialized
INFO - 2016-05-11 20:25:34 --> Model Class Initialized
INFO - 2016-05-11 20:25:34 --> Database Driver Class Initialized
INFO - 2016-05-11 20:25:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:25:34 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:25:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:25:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:25:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:25:34 --> Final output sent to browser
DEBUG - 2016-05-11 20:25:34 --> Total execution time: 0.0751
INFO - 2016-05-11 20:25:36 --> Config Class Initialized
INFO - 2016-05-11 20:25:36 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:25:36 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:25:36 --> Utf8 Class Initialized
INFO - 2016-05-11 20:25:36 --> URI Class Initialized
INFO - 2016-05-11 20:25:36 --> Router Class Initialized
INFO - 2016-05-11 20:25:36 --> Output Class Initialized
INFO - 2016-05-11 20:25:36 --> Security Class Initialized
DEBUG - 2016-05-11 20:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:25:36 --> Input Class Initialized
INFO - 2016-05-11 20:25:36 --> Language Class Initialized
INFO - 2016-05-11 20:25:36 --> Loader Class Initialized
INFO - 2016-05-11 20:25:36 --> Helper loaded: url_helper
INFO - 2016-05-11 20:25:36 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:25:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:25:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:25:36 --> Helper loaded: form_helper
INFO - 2016-05-11 20:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:25:36 --> Form Validation Class Initialized
INFO - 2016-05-11 20:25:36 --> Controller Class Initialized
INFO - 2016-05-11 20:25:36 --> Model Class Initialized
INFO - 2016-05-11 20:25:36 --> Database Driver Class Initialized
INFO - 2016-05-11 20:25:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:25:37 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:25:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:25:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:25:37 --> Final output sent to browser
DEBUG - 2016-05-11 20:25:37 --> Total execution time: 0.0702
INFO - 2016-05-11 20:25:56 --> Config Class Initialized
INFO - 2016-05-11 20:25:56 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:25:56 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:25:56 --> Utf8 Class Initialized
INFO - 2016-05-11 20:25:56 --> URI Class Initialized
DEBUG - 2016-05-11 20:25:56 --> No URI present. Default controller set.
INFO - 2016-05-11 20:25:56 --> Router Class Initialized
INFO - 2016-05-11 20:25:56 --> Output Class Initialized
INFO - 2016-05-11 20:25:56 --> Security Class Initialized
DEBUG - 2016-05-11 20:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:25:56 --> Input Class Initialized
INFO - 2016-05-11 20:25:56 --> Language Class Initialized
INFO - 2016-05-11 20:25:56 --> Loader Class Initialized
INFO - 2016-05-11 20:25:56 --> Helper loaded: url_helper
INFO - 2016-05-11 20:25:56 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:25:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:25:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:25:56 --> Helper loaded: form_helper
INFO - 2016-05-11 20:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:25:56 --> Form Validation Class Initialized
INFO - 2016-05-11 20:25:56 --> Controller Class Initialized
INFO - 2016-05-11 20:25:56 --> Model Class Initialized
INFO - 2016-05-11 20:25:56 --> Database Driver Class Initialized
INFO - 2016-05-11 20:25:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:25:56 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:25:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:25:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:25:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:25:56 --> Final output sent to browser
DEBUG - 2016-05-11 20:25:56 --> Total execution time: 0.0777
INFO - 2016-05-11 20:25:58 --> Config Class Initialized
INFO - 2016-05-11 20:25:58 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:25:58 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:25:58 --> Utf8 Class Initialized
INFO - 2016-05-11 20:25:58 --> URI Class Initialized
INFO - 2016-05-11 20:25:58 --> Router Class Initialized
INFO - 2016-05-11 20:25:58 --> Output Class Initialized
INFO - 2016-05-11 20:25:58 --> Security Class Initialized
DEBUG - 2016-05-11 20:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:25:58 --> Input Class Initialized
INFO - 2016-05-11 20:25:58 --> Language Class Initialized
INFO - 2016-05-11 20:25:58 --> Loader Class Initialized
INFO - 2016-05-11 20:25:58 --> Helper loaded: url_helper
INFO - 2016-05-11 20:25:58 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:25:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:25:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:25:58 --> Helper loaded: form_helper
INFO - 2016-05-11 20:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:25:58 --> Form Validation Class Initialized
INFO - 2016-05-11 20:25:58 --> Controller Class Initialized
INFO - 2016-05-11 20:25:58 --> Model Class Initialized
INFO - 2016-05-11 20:25:58 --> Database Driver Class Initialized
INFO - 2016-05-11 20:25:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:25:58 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:25:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:25:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:25:58 --> Final output sent to browser
DEBUG - 2016-05-11 20:25:58 --> Total execution time: 0.0768
INFO - 2016-05-11 20:26:00 --> Config Class Initialized
INFO - 2016-05-11 20:26:00 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:26:00 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:26:00 --> Utf8 Class Initialized
INFO - 2016-05-11 20:26:00 --> URI Class Initialized
INFO - 2016-05-11 20:26:00 --> Router Class Initialized
INFO - 2016-05-11 20:26:00 --> Output Class Initialized
INFO - 2016-05-11 20:26:00 --> Security Class Initialized
DEBUG - 2016-05-11 20:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:26:00 --> Input Class Initialized
INFO - 2016-05-11 20:26:00 --> Language Class Initialized
INFO - 2016-05-11 20:26:00 --> Loader Class Initialized
INFO - 2016-05-11 20:26:00 --> Helper loaded: url_helper
INFO - 2016-05-11 20:26:00 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:26:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:26:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:26:00 --> Helper loaded: form_helper
INFO - 2016-05-11 20:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:26:00 --> Form Validation Class Initialized
INFO - 2016-05-11 20:26:00 --> Controller Class Initialized
INFO - 2016-05-11 20:26:00 --> Model Class Initialized
INFO - 2016-05-11 20:26:00 --> Database Driver Class Initialized
INFO - 2016-05-11 20:26:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:26:00 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:26:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:26:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:26:00 --> Final output sent to browser
DEBUG - 2016-05-11 20:26:00 --> Total execution time: 0.0726
INFO - 2016-05-11 20:26:00 --> Config Class Initialized
INFO - 2016-05-11 20:26:00 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:26:00 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:26:00 --> Utf8 Class Initialized
INFO - 2016-05-11 20:26:00 --> URI Class Initialized
INFO - 2016-05-11 20:26:00 --> Router Class Initialized
INFO - 2016-05-11 20:26:00 --> Output Class Initialized
INFO - 2016-05-11 20:26:00 --> Security Class Initialized
DEBUG - 2016-05-11 20:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:26:00 --> Input Class Initialized
INFO - 2016-05-11 20:26:00 --> Language Class Initialized
INFO - 2016-05-11 20:26:00 --> Loader Class Initialized
INFO - 2016-05-11 20:26:00 --> Helper loaded: url_helper
INFO - 2016-05-11 20:26:00 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:26:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:26:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:26:00 --> Helper loaded: form_helper
INFO - 2016-05-11 20:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:26:00 --> Form Validation Class Initialized
INFO - 2016-05-11 20:26:00 --> Controller Class Initialized
INFO - 2016-05-11 20:26:00 --> Model Class Initialized
INFO - 2016-05-11 20:26:00 --> Database Driver Class Initialized
INFO - 2016-05-11 20:26:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:26:00 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:26:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:26:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:26:00 --> Final output sent to browser
DEBUG - 2016-05-11 20:26:00 --> Total execution time: 0.0783
INFO - 2016-05-11 20:26:01 --> Config Class Initialized
INFO - 2016-05-11 20:26:01 --> Hooks Class Initialized
DEBUG - 2016-05-11 20:26:01 --> UTF-8 Support Enabled
INFO - 2016-05-11 20:26:01 --> Utf8 Class Initialized
INFO - 2016-05-11 20:26:01 --> URI Class Initialized
DEBUG - 2016-05-11 20:26:01 --> No URI present. Default controller set.
INFO - 2016-05-11 20:26:01 --> Router Class Initialized
INFO - 2016-05-11 20:26:01 --> Output Class Initialized
INFO - 2016-05-11 20:26:01 --> Security Class Initialized
DEBUG - 2016-05-11 20:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-11 20:26:01 --> Input Class Initialized
INFO - 2016-05-11 20:26:01 --> Language Class Initialized
INFO - 2016-05-11 20:26:01 --> Loader Class Initialized
INFO - 2016-05-11 20:26:01 --> Helper loaded: url_helper
INFO - 2016-05-11 20:26:01 --> Helper loaded: sesion_helper
INFO - 2016-05-11 20:26:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-11 20:26:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-11 20:26:01 --> Helper loaded: form_helper
INFO - 2016-05-11 20:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-11 20:26:01 --> Form Validation Class Initialized
INFO - 2016-05-11 20:26:01 --> Controller Class Initialized
INFO - 2016-05-11 20:26:01 --> Model Class Initialized
INFO - 2016-05-11 20:26:01 --> Database Driver Class Initialized
INFO - 2016-05-11 20:26:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-11 20:26:01 --> Pagination Class Initialized
DEBUG - 2016-05-11 20:26:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-11 20:26:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-11 20:26:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-11 20:26:01 --> Final output sent to browser
DEBUG - 2016-05-11 20:26:01 --> Total execution time: 0.0887
