<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-22 09:32:26 --> Config Class Initialized
INFO - 2016-05-22 09:32:26 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:32:26 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:32:26 --> Utf8 Class Initialized
INFO - 2016-05-22 09:32:26 --> URI Class Initialized
DEBUG - 2016-05-22 09:32:26 --> No URI present. Default controller set.
INFO - 2016-05-22 09:32:26 --> Router Class Initialized
INFO - 2016-05-22 09:32:26 --> Output Class Initialized
INFO - 2016-05-22 09:32:26 --> Security Class Initialized
DEBUG - 2016-05-22 09:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:32:26 --> Input Class Initialized
INFO - 2016-05-22 09:32:26 --> Language Class Initialized
INFO - 2016-05-22 09:32:26 --> Loader Class Initialized
INFO - 2016-05-22 09:32:26 --> Helper loaded: url_helper
INFO - 2016-05-22 09:32:26 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:32:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:32:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:32:26 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:32:26 --> Helper loaded: form_helper
INFO - 2016-05-22 09:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:32:27 --> Form Validation Class Initialized
INFO - 2016-05-22 09:32:27 --> Controller Class Initialized
INFO - 2016-05-22 09:32:27 --> Model Class Initialized
INFO - 2016-05-22 09:32:27 --> Database Driver Class Initialized
INFO - 2016-05-22 09:32:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:32:27 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:32:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:32:27 --> Config Class Initialized
INFO - 2016-05-22 09:32:27 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:32:27 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:32:27 --> Utf8 Class Initialized
INFO - 2016-05-22 09:32:27 --> URI Class Initialized
INFO - 2016-05-22 09:32:27 --> Router Class Initialized
INFO - 2016-05-22 09:32:27 --> Output Class Initialized
INFO - 2016-05-22 09:32:27 --> Security Class Initialized
DEBUG - 2016-05-22 09:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:32:27 --> Input Class Initialized
INFO - 2016-05-22 09:32:27 --> Language Class Initialized
INFO - 2016-05-22 09:32:27 --> Loader Class Initialized
INFO - 2016-05-22 09:32:27 --> Helper loaded: url_helper
INFO - 2016-05-22 09:32:27 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:32:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:32:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:32:27 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:32:27 --> Helper loaded: form_helper
INFO - 2016-05-22 09:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:32:27 --> Form Validation Class Initialized
INFO - 2016-05-22 09:32:27 --> Controller Class Initialized
INFO - 2016-05-22 09:32:27 --> Model Class Initialized
INFO - 2016-05-22 09:32:27 --> Database Driver Class Initialized
INFO - 2016-05-22 09:32:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-22 09:32:27 --> Final output sent to browser
DEBUG - 2016-05-22 09:32:27 --> Total execution time: 0.2607
INFO - 2016-05-22 09:32:29 --> Config Class Initialized
INFO - 2016-05-22 09:32:29 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:32:29 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:32:29 --> Utf8 Class Initialized
INFO - 2016-05-22 09:32:29 --> URI Class Initialized
INFO - 2016-05-22 09:32:29 --> Router Class Initialized
INFO - 2016-05-22 09:32:29 --> Output Class Initialized
INFO - 2016-05-22 09:32:29 --> Security Class Initialized
DEBUG - 2016-05-22 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:32:29 --> Input Class Initialized
INFO - 2016-05-22 09:32:29 --> Language Class Initialized
INFO - 2016-05-22 09:32:29 --> Loader Class Initialized
INFO - 2016-05-22 09:32:29 --> Helper loaded: url_helper
INFO - 2016-05-22 09:32:29 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:32:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:32:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:32:29 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:32:29 --> Helper loaded: form_helper
INFO - 2016-05-22 09:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:32:29 --> Form Validation Class Initialized
INFO - 2016-05-22 09:32:29 --> Controller Class Initialized
INFO - 2016-05-22 09:32:29 --> Config Class Initialized
INFO - 2016-05-22 09:32:29 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:32:29 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:32:29 --> Utf8 Class Initialized
INFO - 2016-05-22 09:32:29 --> URI Class Initialized
INFO - 2016-05-22 09:32:29 --> Router Class Initialized
INFO - 2016-05-22 09:32:29 --> Output Class Initialized
INFO - 2016-05-22 09:32:29 --> Security Class Initialized
DEBUG - 2016-05-22 09:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:32:29 --> Input Class Initialized
INFO - 2016-05-22 09:32:29 --> Language Class Initialized
INFO - 2016-05-22 09:32:29 --> Loader Class Initialized
INFO - 2016-05-22 09:32:29 --> Helper loaded: url_helper
INFO - 2016-05-22 09:32:29 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:32:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:32:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:32:29 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:32:29 --> Helper loaded: form_helper
INFO - 2016-05-22 09:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:32:29 --> Form Validation Class Initialized
INFO - 2016-05-22 09:32:29 --> Controller Class Initialized
INFO - 2016-05-22 09:32:29 --> Model Class Initialized
INFO - 2016-05-22 09:32:29 --> Database Driver Class Initialized
INFO - 2016-05-22 09:32:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-22 09:32:29 --> Final output sent to browser
DEBUG - 2016-05-22 09:32:29 --> Total execution time: 0.0975
INFO - 2016-05-22 09:35:31 --> Config Class Initialized
INFO - 2016-05-22 09:35:31 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:35:31 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:35:31 --> Utf8 Class Initialized
INFO - 2016-05-22 09:35:31 --> URI Class Initialized
INFO - 2016-05-22 09:35:31 --> Router Class Initialized
INFO - 2016-05-22 09:35:31 --> Output Class Initialized
INFO - 2016-05-22 09:35:31 --> Security Class Initialized
DEBUG - 2016-05-22 09:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:35:31 --> Input Class Initialized
INFO - 2016-05-22 09:35:31 --> Language Class Initialized
INFO - 2016-05-22 09:35:31 --> Loader Class Initialized
INFO - 2016-05-22 09:35:31 --> Helper loaded: url_helper
INFO - 2016-05-22 09:35:31 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:35:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:35:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:35:31 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:35:31 --> Helper loaded: form_helper
INFO - 2016-05-22 09:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:35:31 --> Form Validation Class Initialized
INFO - 2016-05-22 09:35:31 --> Controller Class Initialized
INFO - 2016-05-22 09:35:31 --> Model Class Initialized
INFO - 2016-05-22 09:35:31 --> Database Driver Class Initialized
INFO - 2016-05-22 09:35:32 --> Config Class Initialized
INFO - 2016-05-22 09:35:32 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:35:32 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:35:32 --> Utf8 Class Initialized
INFO - 2016-05-22 09:35:32 --> URI Class Initialized
INFO - 2016-05-22 09:35:32 --> Router Class Initialized
INFO - 2016-05-22 09:35:32 --> Output Class Initialized
INFO - 2016-05-22 09:35:32 --> Security Class Initialized
DEBUG - 2016-05-22 09:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:35:32 --> Input Class Initialized
INFO - 2016-05-22 09:35:32 --> Language Class Initialized
INFO - 2016-05-22 09:35:32 --> Loader Class Initialized
INFO - 2016-05-22 09:35:32 --> Helper loaded: url_helper
INFO - 2016-05-22 09:35:32 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:35:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:35:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:35:32 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:35:32 --> Helper loaded: form_helper
INFO - 2016-05-22 09:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:35:32 --> Form Validation Class Initialized
INFO - 2016-05-22 09:35:32 --> Controller Class Initialized
INFO - 2016-05-22 09:35:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-22 09:35:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 09:35:32 --> Final output sent to browser
DEBUG - 2016-05-22 09:35:32 --> Total execution time: 0.0734
INFO - 2016-05-22 09:35:33 --> Config Class Initialized
INFO - 2016-05-22 09:35:33 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:35:33 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:35:33 --> Utf8 Class Initialized
INFO - 2016-05-22 09:35:33 --> URI Class Initialized
INFO - 2016-05-22 09:35:33 --> Router Class Initialized
INFO - 2016-05-22 09:35:33 --> Output Class Initialized
INFO - 2016-05-22 09:35:33 --> Security Class Initialized
DEBUG - 2016-05-22 09:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:35:33 --> Input Class Initialized
INFO - 2016-05-22 09:35:33 --> Language Class Initialized
INFO - 2016-05-22 09:35:33 --> Loader Class Initialized
INFO - 2016-05-22 09:35:33 --> Helper loaded: url_helper
INFO - 2016-05-22 09:35:33 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:35:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:35:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:35:33 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:35:33 --> Helper loaded: form_helper
INFO - 2016-05-22 09:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:35:33 --> Form Validation Class Initialized
INFO - 2016-05-22 09:35:33 --> Controller Class Initialized
INFO - 2016-05-22 09:35:33 --> Model Class Initialized
INFO - 2016-05-22 09:35:33 --> Database Driver Class Initialized
INFO - 2016-05-22 09:35:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:35:33 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:35:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:35:33 --> Final output sent to browser
DEBUG - 2016-05-22 09:35:33 --> Total execution time: 0.1338
INFO - 2016-05-22 09:36:34 --> Config Class Initialized
INFO - 2016-05-22 09:36:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:36:34 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:36:34 --> Utf8 Class Initialized
INFO - 2016-05-22 09:36:34 --> URI Class Initialized
INFO - 2016-05-22 09:36:34 --> Router Class Initialized
INFO - 2016-05-22 09:36:34 --> Output Class Initialized
INFO - 2016-05-22 09:36:34 --> Security Class Initialized
DEBUG - 2016-05-22 09:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:36:34 --> Input Class Initialized
INFO - 2016-05-22 09:36:34 --> Language Class Initialized
INFO - 2016-05-22 09:36:34 --> Loader Class Initialized
INFO - 2016-05-22 09:36:34 --> Helper loaded: url_helper
INFO - 2016-05-22 09:36:34 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:36:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:36:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:36:34 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:36:34 --> Helper loaded: form_helper
INFO - 2016-05-22 09:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:36:34 --> Form Validation Class Initialized
INFO - 2016-05-22 09:36:34 --> Controller Class Initialized
INFO - 2016-05-22 09:36:34 --> Model Class Initialized
INFO - 2016-05-22 09:36:34 --> Database Driver Class Initialized
INFO - 2016-05-22 09:36:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:36:34 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:36:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:36:34 --> Final output sent to browser
DEBUG - 2016-05-22 09:36:34 --> Total execution time: 0.0760
INFO - 2016-05-22 09:37:34 --> Config Class Initialized
INFO - 2016-05-22 09:37:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:37:34 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:37:34 --> Utf8 Class Initialized
INFO - 2016-05-22 09:37:34 --> URI Class Initialized
INFO - 2016-05-22 09:37:34 --> Router Class Initialized
INFO - 2016-05-22 09:37:34 --> Output Class Initialized
INFO - 2016-05-22 09:37:34 --> Security Class Initialized
DEBUG - 2016-05-22 09:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:37:34 --> Input Class Initialized
INFO - 2016-05-22 09:37:34 --> Language Class Initialized
INFO - 2016-05-22 09:37:34 --> Loader Class Initialized
INFO - 2016-05-22 09:37:34 --> Helper loaded: url_helper
INFO - 2016-05-22 09:37:34 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:37:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:37:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:37:34 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:37:34 --> Helper loaded: form_helper
INFO - 2016-05-22 09:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:37:34 --> Form Validation Class Initialized
INFO - 2016-05-22 09:37:34 --> Controller Class Initialized
INFO - 2016-05-22 09:37:34 --> Model Class Initialized
INFO - 2016-05-22 09:37:34 --> Database Driver Class Initialized
INFO - 2016-05-22 09:37:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:37:34 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:37:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:37:34 --> Final output sent to browser
DEBUG - 2016-05-22 09:37:34 --> Total execution time: 0.1205
INFO - 2016-05-22 09:38:34 --> Config Class Initialized
INFO - 2016-05-22 09:38:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:38:34 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:38:34 --> Utf8 Class Initialized
INFO - 2016-05-22 09:38:34 --> URI Class Initialized
INFO - 2016-05-22 09:38:34 --> Router Class Initialized
INFO - 2016-05-22 09:38:34 --> Output Class Initialized
INFO - 2016-05-22 09:38:34 --> Security Class Initialized
DEBUG - 2016-05-22 09:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:38:34 --> Input Class Initialized
INFO - 2016-05-22 09:38:34 --> Language Class Initialized
INFO - 2016-05-22 09:38:34 --> Loader Class Initialized
INFO - 2016-05-22 09:38:34 --> Helper loaded: url_helper
INFO - 2016-05-22 09:38:34 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:38:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:38:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:38:34 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:38:34 --> Helper loaded: form_helper
INFO - 2016-05-22 09:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:38:34 --> Form Validation Class Initialized
INFO - 2016-05-22 09:38:34 --> Controller Class Initialized
INFO - 2016-05-22 09:38:34 --> Model Class Initialized
INFO - 2016-05-22 09:38:34 --> Database Driver Class Initialized
INFO - 2016-05-22 09:38:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:38:34 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:38:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:38:34 --> Final output sent to browser
DEBUG - 2016-05-22 09:38:34 --> Total execution time: 0.0901
INFO - 2016-05-22 09:39:34 --> Config Class Initialized
INFO - 2016-05-22 09:39:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:39:34 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:39:34 --> Utf8 Class Initialized
INFO - 2016-05-22 09:39:34 --> URI Class Initialized
INFO - 2016-05-22 09:39:34 --> Router Class Initialized
INFO - 2016-05-22 09:39:34 --> Output Class Initialized
INFO - 2016-05-22 09:39:34 --> Security Class Initialized
DEBUG - 2016-05-22 09:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:39:34 --> Input Class Initialized
INFO - 2016-05-22 09:39:34 --> Language Class Initialized
INFO - 2016-05-22 09:39:34 --> Loader Class Initialized
INFO - 2016-05-22 09:39:34 --> Helper loaded: url_helper
INFO - 2016-05-22 09:39:34 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:39:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:39:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:39:34 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:39:34 --> Helper loaded: form_helper
INFO - 2016-05-22 09:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:39:34 --> Form Validation Class Initialized
INFO - 2016-05-22 09:39:34 --> Controller Class Initialized
INFO - 2016-05-22 09:39:34 --> Model Class Initialized
INFO - 2016-05-22 09:39:34 --> Database Driver Class Initialized
INFO - 2016-05-22 09:39:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:39:34 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:39:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:39:34 --> Final output sent to browser
DEBUG - 2016-05-22 09:39:34 --> Total execution time: 0.0889
INFO - 2016-05-22 09:40:34 --> Config Class Initialized
INFO - 2016-05-22 09:40:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:40:34 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:40:34 --> Utf8 Class Initialized
INFO - 2016-05-22 09:40:34 --> URI Class Initialized
INFO - 2016-05-22 09:40:34 --> Router Class Initialized
INFO - 2016-05-22 09:40:34 --> Output Class Initialized
INFO - 2016-05-22 09:40:34 --> Security Class Initialized
DEBUG - 2016-05-22 09:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:40:34 --> Input Class Initialized
INFO - 2016-05-22 09:40:34 --> Language Class Initialized
INFO - 2016-05-22 09:40:34 --> Loader Class Initialized
INFO - 2016-05-22 09:40:34 --> Helper loaded: url_helper
INFO - 2016-05-22 09:40:34 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:40:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:40:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:40:34 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:40:34 --> Helper loaded: form_helper
INFO - 2016-05-22 09:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:40:34 --> Form Validation Class Initialized
INFO - 2016-05-22 09:40:34 --> Controller Class Initialized
INFO - 2016-05-22 09:40:34 --> Model Class Initialized
INFO - 2016-05-22 09:40:34 --> Database Driver Class Initialized
INFO - 2016-05-22 09:40:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:40:34 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:40:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:40:34 --> Final output sent to browser
DEBUG - 2016-05-22 09:40:34 --> Total execution time: 0.0843
INFO - 2016-05-22 09:41:34 --> Config Class Initialized
INFO - 2016-05-22 09:41:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:41:34 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:41:34 --> Utf8 Class Initialized
INFO - 2016-05-22 09:41:34 --> URI Class Initialized
INFO - 2016-05-22 09:41:34 --> Router Class Initialized
INFO - 2016-05-22 09:41:34 --> Output Class Initialized
INFO - 2016-05-22 09:41:34 --> Security Class Initialized
DEBUG - 2016-05-22 09:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:41:34 --> Input Class Initialized
INFO - 2016-05-22 09:41:34 --> Language Class Initialized
INFO - 2016-05-22 09:41:34 --> Loader Class Initialized
INFO - 2016-05-22 09:41:34 --> Helper loaded: url_helper
INFO - 2016-05-22 09:41:34 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:41:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:41:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:41:34 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:41:34 --> Helper loaded: form_helper
INFO - 2016-05-22 09:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:41:34 --> Form Validation Class Initialized
INFO - 2016-05-22 09:41:34 --> Controller Class Initialized
INFO - 2016-05-22 09:41:34 --> Model Class Initialized
INFO - 2016-05-22 09:41:34 --> Database Driver Class Initialized
INFO - 2016-05-22 09:41:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:41:34 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:41:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:41:34 --> Final output sent to browser
DEBUG - 2016-05-22 09:41:34 --> Total execution time: 0.0932
INFO - 2016-05-22 09:42:34 --> Config Class Initialized
INFO - 2016-05-22 09:42:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:42:34 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:42:34 --> Utf8 Class Initialized
INFO - 2016-05-22 09:42:34 --> URI Class Initialized
INFO - 2016-05-22 09:42:34 --> Router Class Initialized
INFO - 2016-05-22 09:42:34 --> Output Class Initialized
INFO - 2016-05-22 09:42:34 --> Security Class Initialized
DEBUG - 2016-05-22 09:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:42:34 --> Input Class Initialized
INFO - 2016-05-22 09:42:34 --> Language Class Initialized
INFO - 2016-05-22 09:42:34 --> Loader Class Initialized
INFO - 2016-05-22 09:42:34 --> Helper loaded: url_helper
INFO - 2016-05-22 09:42:34 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:42:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:42:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:42:34 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:42:34 --> Helper loaded: form_helper
INFO - 2016-05-22 09:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:42:34 --> Form Validation Class Initialized
INFO - 2016-05-22 09:42:34 --> Controller Class Initialized
INFO - 2016-05-22 09:42:34 --> Model Class Initialized
INFO - 2016-05-22 09:42:34 --> Database Driver Class Initialized
INFO - 2016-05-22 09:42:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:42:34 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:42:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:42:34 --> Final output sent to browser
DEBUG - 2016-05-22 09:42:34 --> Total execution time: 0.1343
INFO - 2016-05-22 09:42:34 --> Config Class Initialized
INFO - 2016-05-22 09:42:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:42:34 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:42:34 --> Utf8 Class Initialized
INFO - 2016-05-22 09:42:34 --> URI Class Initialized
INFO - 2016-05-22 09:42:34 --> Router Class Initialized
INFO - 2016-05-22 09:42:34 --> Output Class Initialized
INFO - 2016-05-22 09:42:34 --> Security Class Initialized
DEBUG - 2016-05-22 09:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:42:34 --> Input Class Initialized
INFO - 2016-05-22 09:42:34 --> Language Class Initialized
INFO - 2016-05-22 09:42:34 --> Loader Class Initialized
INFO - 2016-05-22 09:42:34 --> Helper loaded: url_helper
INFO - 2016-05-22 09:42:34 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:42:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:42:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:42:34 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:42:34 --> Helper loaded: form_helper
INFO - 2016-05-22 09:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:42:34 --> Form Validation Class Initialized
INFO - 2016-05-22 09:42:34 --> Controller Class Initialized
INFO - 2016-05-22 09:42:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
ERROR - 2016-05-22 09:42:34 --> Severity: Notice --> Undefined property: Main::$Mdl_lista C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\helpers\admin_templates_helper.php 17
ERROR - 2016-05-22 09:42:34 --> Severity: Error --> Call to a member function getTemplateActivaAdmin() on a non-object C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\helpers\admin_templates_helper.php 17
INFO - 2016-05-22 09:43:20 --> Config Class Initialized
INFO - 2016-05-22 09:43:20 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:43:20 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:43:20 --> Utf8 Class Initialized
INFO - 2016-05-22 09:43:20 --> URI Class Initialized
INFO - 2016-05-22 09:43:20 --> Router Class Initialized
INFO - 2016-05-22 09:43:20 --> Output Class Initialized
INFO - 2016-05-22 09:43:20 --> Security Class Initialized
DEBUG - 2016-05-22 09:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:43:20 --> Input Class Initialized
INFO - 2016-05-22 09:43:20 --> Language Class Initialized
INFO - 2016-05-22 09:43:20 --> Loader Class Initialized
INFO - 2016-05-22 09:43:20 --> Helper loaded: url_helper
INFO - 2016-05-22 09:43:20 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:43:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:43:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:43:20 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:43:20 --> Helper loaded: form_helper
INFO - 2016-05-22 09:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:43:20 --> Form Validation Class Initialized
INFO - 2016-05-22 09:43:20 --> Controller Class Initialized
INFO - 2016-05-22 09:43:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-22 09:43:20 --> Model Class Initialized
INFO - 2016-05-22 09:43:20 --> Database Driver Class Initialized
INFO - 2016-05-22 09:43:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 09:43:20 --> Final output sent to browser
DEBUG - 2016-05-22 09:43:20 --> Total execution time: 0.0729
INFO - 2016-05-22 09:43:21 --> Config Class Initialized
INFO - 2016-05-22 09:43:21 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:43:21 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:43:21 --> Utf8 Class Initialized
INFO - 2016-05-22 09:43:21 --> URI Class Initialized
INFO - 2016-05-22 09:43:21 --> Router Class Initialized
INFO - 2016-05-22 09:43:21 --> Output Class Initialized
INFO - 2016-05-22 09:43:21 --> Security Class Initialized
DEBUG - 2016-05-22 09:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:43:21 --> Input Class Initialized
INFO - 2016-05-22 09:43:21 --> Language Class Initialized
INFO - 2016-05-22 09:43:21 --> Loader Class Initialized
INFO - 2016-05-22 09:43:21 --> Helper loaded: url_helper
INFO - 2016-05-22 09:43:21 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:43:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:43:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:43:21 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:43:21 --> Helper loaded: form_helper
INFO - 2016-05-22 09:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:43:21 --> Form Validation Class Initialized
INFO - 2016-05-22 09:43:21 --> Controller Class Initialized
INFO - 2016-05-22 09:43:21 --> Model Class Initialized
INFO - 2016-05-22 09:43:21 --> Database Driver Class Initialized
INFO - 2016-05-22 09:43:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:43:21 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:43:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:43:21 --> Final output sent to browser
DEBUG - 2016-05-22 09:43:21 --> Total execution time: 0.1042
INFO - 2016-05-22 09:44:21 --> Config Class Initialized
INFO - 2016-05-22 09:44:21 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:44:21 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:44:21 --> Utf8 Class Initialized
INFO - 2016-05-22 09:44:21 --> URI Class Initialized
INFO - 2016-05-22 09:44:21 --> Router Class Initialized
INFO - 2016-05-22 09:44:21 --> Output Class Initialized
INFO - 2016-05-22 09:44:21 --> Security Class Initialized
DEBUG - 2016-05-22 09:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:44:21 --> Input Class Initialized
INFO - 2016-05-22 09:44:21 --> Language Class Initialized
INFO - 2016-05-22 09:44:21 --> Loader Class Initialized
INFO - 2016-05-22 09:44:21 --> Helper loaded: url_helper
INFO - 2016-05-22 09:44:21 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:44:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:44:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:44:21 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:44:21 --> Helper loaded: form_helper
INFO - 2016-05-22 09:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:44:21 --> Form Validation Class Initialized
INFO - 2016-05-22 09:44:21 --> Controller Class Initialized
INFO - 2016-05-22 09:44:21 --> Model Class Initialized
INFO - 2016-05-22 09:44:21 --> Database Driver Class Initialized
INFO - 2016-05-22 09:44:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:44:21 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:44:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:44:21 --> Final output sent to browser
DEBUG - 2016-05-22 09:44:21 --> Total execution time: 0.0724
INFO - 2016-05-22 09:45:21 --> Config Class Initialized
INFO - 2016-05-22 09:45:21 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:45:21 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:45:21 --> Utf8 Class Initialized
INFO - 2016-05-22 09:45:21 --> URI Class Initialized
INFO - 2016-05-22 09:45:21 --> Router Class Initialized
INFO - 2016-05-22 09:45:21 --> Output Class Initialized
INFO - 2016-05-22 09:45:21 --> Security Class Initialized
DEBUG - 2016-05-22 09:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:45:21 --> Input Class Initialized
INFO - 2016-05-22 09:45:21 --> Language Class Initialized
INFO - 2016-05-22 09:45:21 --> Loader Class Initialized
INFO - 2016-05-22 09:45:21 --> Helper loaded: url_helper
INFO - 2016-05-22 09:45:21 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:45:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:45:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:45:21 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:45:21 --> Helper loaded: form_helper
INFO - 2016-05-22 09:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:45:21 --> Form Validation Class Initialized
INFO - 2016-05-22 09:45:21 --> Controller Class Initialized
INFO - 2016-05-22 09:45:21 --> Model Class Initialized
INFO - 2016-05-22 09:45:21 --> Database Driver Class Initialized
INFO - 2016-05-22 09:45:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:45:21 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:45:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:45:21 --> Final output sent to browser
DEBUG - 2016-05-22 09:45:21 --> Total execution time: 0.0750
INFO - 2016-05-22 09:46:21 --> Config Class Initialized
INFO - 2016-05-22 09:46:21 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:46:21 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:46:21 --> Utf8 Class Initialized
INFO - 2016-05-22 09:46:21 --> URI Class Initialized
INFO - 2016-05-22 09:46:21 --> Router Class Initialized
INFO - 2016-05-22 09:46:21 --> Output Class Initialized
INFO - 2016-05-22 09:46:21 --> Security Class Initialized
DEBUG - 2016-05-22 09:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:46:21 --> Input Class Initialized
INFO - 2016-05-22 09:46:21 --> Language Class Initialized
INFO - 2016-05-22 09:46:21 --> Loader Class Initialized
INFO - 2016-05-22 09:46:21 --> Helper loaded: url_helper
INFO - 2016-05-22 09:46:21 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:46:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:46:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:46:21 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:46:21 --> Helper loaded: form_helper
INFO - 2016-05-22 09:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:46:21 --> Form Validation Class Initialized
INFO - 2016-05-22 09:46:21 --> Controller Class Initialized
INFO - 2016-05-22 09:46:21 --> Model Class Initialized
INFO - 2016-05-22 09:46:21 --> Database Driver Class Initialized
INFO - 2016-05-22 09:46:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:46:21 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:46:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:46:21 --> Final output sent to browser
DEBUG - 2016-05-22 09:46:21 --> Total execution time: 0.0780
INFO - 2016-05-22 09:47:21 --> Config Class Initialized
INFO - 2016-05-22 09:47:21 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:47:21 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:47:21 --> Utf8 Class Initialized
INFO - 2016-05-22 09:47:21 --> URI Class Initialized
INFO - 2016-05-22 09:47:21 --> Router Class Initialized
INFO - 2016-05-22 09:47:21 --> Output Class Initialized
INFO - 2016-05-22 09:47:21 --> Security Class Initialized
DEBUG - 2016-05-22 09:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:47:21 --> Input Class Initialized
INFO - 2016-05-22 09:47:21 --> Language Class Initialized
INFO - 2016-05-22 09:47:21 --> Loader Class Initialized
INFO - 2016-05-22 09:47:21 --> Helper loaded: url_helper
INFO - 2016-05-22 09:47:21 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:47:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:47:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:47:21 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:47:21 --> Helper loaded: form_helper
INFO - 2016-05-22 09:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:47:21 --> Form Validation Class Initialized
INFO - 2016-05-22 09:47:21 --> Controller Class Initialized
INFO - 2016-05-22 09:47:21 --> Model Class Initialized
INFO - 2016-05-22 09:47:21 --> Database Driver Class Initialized
INFO - 2016-05-22 09:47:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:47:21 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:47:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:47:21 --> Final output sent to browser
DEBUG - 2016-05-22 09:47:21 --> Total execution time: 0.0972
INFO - 2016-05-22 09:48:21 --> Config Class Initialized
INFO - 2016-05-22 09:48:21 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:48:21 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:48:21 --> Utf8 Class Initialized
INFO - 2016-05-22 09:48:21 --> URI Class Initialized
INFO - 2016-05-22 09:48:21 --> Router Class Initialized
INFO - 2016-05-22 09:48:21 --> Output Class Initialized
INFO - 2016-05-22 09:48:21 --> Security Class Initialized
DEBUG - 2016-05-22 09:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:48:21 --> Input Class Initialized
INFO - 2016-05-22 09:48:21 --> Language Class Initialized
INFO - 2016-05-22 09:48:21 --> Loader Class Initialized
INFO - 2016-05-22 09:48:21 --> Helper loaded: url_helper
INFO - 2016-05-22 09:48:21 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:48:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:48:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:48:21 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:48:21 --> Helper loaded: form_helper
INFO - 2016-05-22 09:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:48:21 --> Form Validation Class Initialized
INFO - 2016-05-22 09:48:21 --> Controller Class Initialized
INFO - 2016-05-22 09:48:21 --> Model Class Initialized
INFO - 2016-05-22 09:48:21 --> Database Driver Class Initialized
INFO - 2016-05-22 09:48:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:48:21 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:48:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:48:21 --> Final output sent to browser
DEBUG - 2016-05-22 09:48:21 --> Total execution time: 0.0769
INFO - 2016-05-22 09:49:21 --> Config Class Initialized
INFO - 2016-05-22 09:49:21 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:49:21 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:49:21 --> Utf8 Class Initialized
INFO - 2016-05-22 09:49:21 --> URI Class Initialized
INFO - 2016-05-22 09:49:21 --> Router Class Initialized
INFO - 2016-05-22 09:49:21 --> Output Class Initialized
INFO - 2016-05-22 09:49:21 --> Security Class Initialized
DEBUG - 2016-05-22 09:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:49:21 --> Input Class Initialized
INFO - 2016-05-22 09:49:21 --> Language Class Initialized
INFO - 2016-05-22 09:49:21 --> Loader Class Initialized
INFO - 2016-05-22 09:49:21 --> Helper loaded: url_helper
INFO - 2016-05-22 09:49:21 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:49:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:49:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:49:21 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:49:21 --> Helper loaded: form_helper
INFO - 2016-05-22 09:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:49:21 --> Form Validation Class Initialized
INFO - 2016-05-22 09:49:21 --> Controller Class Initialized
INFO - 2016-05-22 09:49:21 --> Model Class Initialized
INFO - 2016-05-22 09:49:21 --> Database Driver Class Initialized
INFO - 2016-05-22 09:49:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:49:21 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:49:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:49:21 --> Final output sent to browser
DEBUG - 2016-05-22 09:49:21 --> Total execution time: 0.0722
INFO - 2016-05-22 09:50:21 --> Config Class Initialized
INFO - 2016-05-22 09:50:21 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:50:21 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:50:21 --> Utf8 Class Initialized
INFO - 2016-05-22 09:50:21 --> URI Class Initialized
INFO - 2016-05-22 09:50:21 --> Router Class Initialized
INFO - 2016-05-22 09:50:21 --> Output Class Initialized
INFO - 2016-05-22 09:50:21 --> Security Class Initialized
DEBUG - 2016-05-22 09:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:50:21 --> Input Class Initialized
INFO - 2016-05-22 09:50:21 --> Language Class Initialized
INFO - 2016-05-22 09:50:21 --> Loader Class Initialized
INFO - 2016-05-22 09:50:21 --> Helper loaded: url_helper
INFO - 2016-05-22 09:50:21 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:50:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:50:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:50:21 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:50:21 --> Helper loaded: form_helper
INFO - 2016-05-22 09:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:50:21 --> Form Validation Class Initialized
INFO - 2016-05-22 09:50:21 --> Controller Class Initialized
INFO - 2016-05-22 09:50:21 --> Model Class Initialized
INFO - 2016-05-22 09:50:21 --> Database Driver Class Initialized
INFO - 2016-05-22 09:50:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:50:21 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:50:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:50:21 --> Final output sent to browser
DEBUG - 2016-05-22 09:50:21 --> Total execution time: 0.1003
INFO - 2016-05-22 09:51:21 --> Config Class Initialized
INFO - 2016-05-22 09:51:21 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:51:21 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:51:21 --> Utf8 Class Initialized
INFO - 2016-05-22 09:51:21 --> URI Class Initialized
INFO - 2016-05-22 09:51:21 --> Router Class Initialized
INFO - 2016-05-22 09:51:21 --> Output Class Initialized
INFO - 2016-05-22 09:51:21 --> Security Class Initialized
DEBUG - 2016-05-22 09:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:51:21 --> Input Class Initialized
INFO - 2016-05-22 09:51:21 --> Language Class Initialized
INFO - 2016-05-22 09:51:21 --> Loader Class Initialized
INFO - 2016-05-22 09:51:21 --> Helper loaded: url_helper
INFO - 2016-05-22 09:51:21 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:51:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:51:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:51:21 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:51:21 --> Helper loaded: form_helper
INFO - 2016-05-22 09:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:51:21 --> Form Validation Class Initialized
INFO - 2016-05-22 09:51:21 --> Controller Class Initialized
INFO - 2016-05-22 09:51:21 --> Model Class Initialized
INFO - 2016-05-22 09:51:21 --> Database Driver Class Initialized
INFO - 2016-05-22 09:51:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:51:21 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:51:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:51:21 --> Final output sent to browser
DEBUG - 2016-05-22 09:51:21 --> Total execution time: 0.0774
INFO - 2016-05-22 09:51:30 --> Config Class Initialized
INFO - 2016-05-22 09:51:30 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:51:30 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:51:30 --> Utf8 Class Initialized
INFO - 2016-05-22 09:51:30 --> URI Class Initialized
INFO - 2016-05-22 09:51:30 --> Router Class Initialized
INFO - 2016-05-22 09:51:30 --> Output Class Initialized
INFO - 2016-05-22 09:51:30 --> Security Class Initialized
DEBUG - 2016-05-22 09:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:51:30 --> Input Class Initialized
INFO - 2016-05-22 09:51:30 --> Language Class Initialized
INFO - 2016-05-22 09:51:30 --> Loader Class Initialized
INFO - 2016-05-22 09:51:30 --> Helper loaded: url_helper
INFO - 2016-05-22 09:51:30 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:51:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:51:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:51:30 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:51:30 --> Helper loaded: form_helper
INFO - 2016-05-22 09:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:51:30 --> Form Validation Class Initialized
INFO - 2016-05-22 09:51:30 --> Controller Class Initialized
DEBUG - 2016-05-22 09:51:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-22 09:51:30 --> Model Class Initialized
INFO - 2016-05-22 09:51:30 --> Database Driver Class Initialized
ERROR - 2016-05-22 09:51:30 --> Severity: Error --> Call to undefined method ConfigPlantillas::config_item() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\ConfigPlantillas.php 27
INFO - 2016-05-22 09:52:38 --> Config Class Initialized
INFO - 2016-05-22 09:52:38 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:52:38 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:52:38 --> Utf8 Class Initialized
INFO - 2016-05-22 09:52:38 --> URI Class Initialized
INFO - 2016-05-22 09:52:38 --> Router Class Initialized
INFO - 2016-05-22 09:52:38 --> Output Class Initialized
INFO - 2016-05-22 09:52:38 --> Security Class Initialized
DEBUG - 2016-05-22 09:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:52:38 --> Input Class Initialized
INFO - 2016-05-22 09:52:38 --> Language Class Initialized
INFO - 2016-05-22 09:52:38 --> Loader Class Initialized
INFO - 2016-05-22 09:52:38 --> Helper loaded: url_helper
INFO - 2016-05-22 09:52:38 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:52:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:52:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:52:38 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:52:38 --> Helper loaded: form_helper
INFO - 2016-05-22 09:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:52:38 --> Form Validation Class Initialized
INFO - 2016-05-22 09:52:38 --> Controller Class Initialized
DEBUG - 2016-05-22 09:52:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-22 09:52:38 --> Model Class Initialized
INFO - 2016-05-22 09:52:38 --> Database Driver Class Initialized
INFO - 2016-05-22 09:52:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-22 09:52:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 09:52:38 --> Final output sent to browser
DEBUG - 2016-05-22 09:52:38 --> Total execution time: 0.0828
INFO - 2016-05-22 09:52:38 --> Config Class Initialized
INFO - 2016-05-22 09:52:38 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:52:38 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:52:38 --> Utf8 Class Initialized
INFO - 2016-05-22 09:52:38 --> URI Class Initialized
INFO - 2016-05-22 09:52:38 --> Router Class Initialized
INFO - 2016-05-22 09:52:38 --> Output Class Initialized
INFO - 2016-05-22 09:52:38 --> Security Class Initialized
DEBUG - 2016-05-22 09:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:52:38 --> Input Class Initialized
INFO - 2016-05-22 09:52:38 --> Language Class Initialized
INFO - 2016-05-22 09:52:38 --> Loader Class Initialized
INFO - 2016-05-22 09:52:38 --> Helper loaded: url_helper
INFO - 2016-05-22 09:52:38 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:52:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:52:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:52:38 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:52:38 --> Helper loaded: form_helper
INFO - 2016-05-22 09:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:52:38 --> Form Validation Class Initialized
INFO - 2016-05-22 09:52:38 --> Controller Class Initialized
INFO - 2016-05-22 09:52:38 --> Model Class Initialized
INFO - 2016-05-22 09:52:38 --> Database Driver Class Initialized
INFO - 2016-05-22 09:52:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:52:38 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:52:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:52:38 --> Final output sent to browser
DEBUG - 2016-05-22 09:52:38 --> Total execution time: 0.0881
INFO - 2016-05-22 09:53:39 --> Config Class Initialized
INFO - 2016-05-22 09:53:39 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:53:39 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:53:39 --> Utf8 Class Initialized
INFO - 2016-05-22 09:53:39 --> URI Class Initialized
INFO - 2016-05-22 09:53:39 --> Router Class Initialized
INFO - 2016-05-22 09:53:39 --> Output Class Initialized
INFO - 2016-05-22 09:53:39 --> Security Class Initialized
DEBUG - 2016-05-22 09:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:53:39 --> Input Class Initialized
INFO - 2016-05-22 09:53:39 --> Language Class Initialized
INFO - 2016-05-22 09:53:39 --> Loader Class Initialized
INFO - 2016-05-22 09:53:39 --> Helper loaded: url_helper
INFO - 2016-05-22 09:53:39 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:53:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:53:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:53:39 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:53:39 --> Helper loaded: form_helper
INFO - 2016-05-22 09:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:53:39 --> Form Validation Class Initialized
INFO - 2016-05-22 09:53:39 --> Controller Class Initialized
INFO - 2016-05-22 09:53:39 --> Model Class Initialized
INFO - 2016-05-22 09:53:39 --> Database Driver Class Initialized
INFO - 2016-05-22 09:53:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:53:39 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:53:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:53:39 --> Final output sent to browser
DEBUG - 2016-05-22 09:53:39 --> Total execution time: 0.0762
INFO - 2016-05-22 09:54:39 --> Config Class Initialized
INFO - 2016-05-22 09:54:39 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:54:39 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:54:39 --> Utf8 Class Initialized
INFO - 2016-05-22 09:54:39 --> URI Class Initialized
INFO - 2016-05-22 09:54:39 --> Router Class Initialized
INFO - 2016-05-22 09:54:39 --> Output Class Initialized
INFO - 2016-05-22 09:54:39 --> Security Class Initialized
DEBUG - 2016-05-22 09:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:54:39 --> Input Class Initialized
INFO - 2016-05-22 09:54:39 --> Language Class Initialized
INFO - 2016-05-22 09:54:39 --> Loader Class Initialized
INFO - 2016-05-22 09:54:39 --> Helper loaded: url_helper
INFO - 2016-05-22 09:54:39 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:54:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:54:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:54:39 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:54:39 --> Helper loaded: form_helper
INFO - 2016-05-22 09:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:54:39 --> Form Validation Class Initialized
INFO - 2016-05-22 09:54:39 --> Controller Class Initialized
INFO - 2016-05-22 09:54:39 --> Model Class Initialized
INFO - 2016-05-22 09:54:39 --> Database Driver Class Initialized
INFO - 2016-05-22 09:54:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:54:39 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:54:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:54:39 --> Final output sent to browser
DEBUG - 2016-05-22 09:54:39 --> Total execution time: 0.0805
INFO - 2016-05-22 09:55:26 --> Config Class Initialized
INFO - 2016-05-22 09:55:26 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:55:26 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:55:26 --> Utf8 Class Initialized
INFO - 2016-05-22 09:55:26 --> URI Class Initialized
INFO - 2016-05-22 09:55:26 --> Router Class Initialized
INFO - 2016-05-22 09:55:26 --> Output Class Initialized
INFO - 2016-05-22 09:55:26 --> Security Class Initialized
DEBUG - 2016-05-22 09:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:55:26 --> Input Class Initialized
INFO - 2016-05-22 09:55:26 --> Language Class Initialized
INFO - 2016-05-22 09:55:26 --> Loader Class Initialized
INFO - 2016-05-22 09:55:26 --> Helper loaded: url_helper
INFO - 2016-05-22 09:55:26 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:55:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:55:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:55:26 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:55:26 --> Helper loaded: form_helper
INFO - 2016-05-22 09:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:55:26 --> Form Validation Class Initialized
INFO - 2016-05-22 09:55:26 --> Controller Class Initialized
DEBUG - 2016-05-22 09:55:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-22 09:55:26 --> Model Class Initialized
INFO - 2016-05-22 09:55:26 --> Database Driver Class Initialized
INFO - 2016-05-22 09:55:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-22 09:55:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 09:55:26 --> Final output sent to browser
DEBUG - 2016-05-22 09:55:26 --> Total execution time: 0.0841
INFO - 2016-05-22 09:55:27 --> Config Class Initialized
INFO - 2016-05-22 09:55:27 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:55:27 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:55:27 --> Utf8 Class Initialized
INFO - 2016-05-22 09:55:27 --> URI Class Initialized
INFO - 2016-05-22 09:55:27 --> Router Class Initialized
INFO - 2016-05-22 09:55:27 --> Output Class Initialized
INFO - 2016-05-22 09:55:27 --> Security Class Initialized
DEBUG - 2016-05-22 09:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:55:27 --> Input Class Initialized
INFO - 2016-05-22 09:55:27 --> Language Class Initialized
INFO - 2016-05-22 09:55:27 --> Loader Class Initialized
INFO - 2016-05-22 09:55:27 --> Helper loaded: url_helper
INFO - 2016-05-22 09:55:27 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:55:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:55:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:55:27 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:55:27 --> Helper loaded: form_helper
INFO - 2016-05-22 09:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:55:27 --> Form Validation Class Initialized
INFO - 2016-05-22 09:55:27 --> Controller Class Initialized
INFO - 2016-05-22 09:55:27 --> Model Class Initialized
INFO - 2016-05-22 09:55:27 --> Database Driver Class Initialized
INFO - 2016-05-22 09:55:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:55:27 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:55:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:55:27 --> Final output sent to browser
DEBUG - 2016-05-22 09:55:27 --> Total execution time: 0.1069
INFO - 2016-05-22 09:56:09 --> Config Class Initialized
INFO - 2016-05-22 09:56:09 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:56:09 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:56:09 --> Utf8 Class Initialized
INFO - 2016-05-22 09:56:09 --> URI Class Initialized
INFO - 2016-05-22 09:56:09 --> Router Class Initialized
INFO - 2016-05-22 09:56:09 --> Output Class Initialized
INFO - 2016-05-22 09:56:09 --> Security Class Initialized
DEBUG - 2016-05-22 09:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:56:09 --> Input Class Initialized
INFO - 2016-05-22 09:56:09 --> Language Class Initialized
INFO - 2016-05-22 09:56:09 --> Loader Class Initialized
INFO - 2016-05-22 09:56:09 --> Helper loaded: url_helper
INFO - 2016-05-22 09:56:09 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:56:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:56:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:56:09 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:56:09 --> Helper loaded: form_helper
INFO - 2016-05-22 09:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:56:09 --> Form Validation Class Initialized
INFO - 2016-05-22 09:56:09 --> Controller Class Initialized
DEBUG - 2016-05-22 09:56:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-22 09:56:09 --> Model Class Initialized
INFO - 2016-05-22 09:56:09 --> Database Driver Class Initialized
ERROR - 2016-05-22 09:56:09 --> Severity: Notice --> Undefined variable: plant_admin_activa C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php 21
ERROR - 2016-05-22 09:56:09 --> Severity: Notice --> Undefined variable: plant_admin_activa C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php 25
ERROR - 2016-05-22 09:56:09 --> Severity: Notice --> Undefined variable: plant_admin_activa C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php 21
ERROR - 2016-05-22 09:56:09 --> Severity: Notice --> Undefined variable: plant_admin_activa C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php 25
INFO - 2016-05-22 09:56:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-22 09:56:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 09:56:09 --> Final output sent to browser
DEBUG - 2016-05-22 09:56:09 --> Total execution time: 0.0873
INFO - 2016-05-22 09:56:09 --> Config Class Initialized
INFO - 2016-05-22 09:56:09 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:56:09 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:56:09 --> Utf8 Class Initialized
INFO - 2016-05-22 09:56:09 --> URI Class Initialized
INFO - 2016-05-22 09:56:09 --> Router Class Initialized
INFO - 2016-05-22 09:56:09 --> Output Class Initialized
INFO - 2016-05-22 09:56:09 --> Security Class Initialized
DEBUG - 2016-05-22 09:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:56:09 --> Input Class Initialized
INFO - 2016-05-22 09:56:09 --> Language Class Initialized
INFO - 2016-05-22 09:56:09 --> Loader Class Initialized
INFO - 2016-05-22 09:56:09 --> Helper loaded: url_helper
INFO - 2016-05-22 09:56:09 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:56:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:56:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:56:09 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:56:09 --> Helper loaded: form_helper
INFO - 2016-05-22 09:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:56:09 --> Form Validation Class Initialized
INFO - 2016-05-22 09:56:09 --> Controller Class Initialized
INFO - 2016-05-22 09:56:09 --> Model Class Initialized
INFO - 2016-05-22 09:56:09 --> Database Driver Class Initialized
INFO - 2016-05-22 09:56:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:56:09 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:56:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:56:09 --> Final output sent to browser
DEBUG - 2016-05-22 09:56:09 --> Total execution time: 0.0916
INFO - 2016-05-22 09:56:34 --> Config Class Initialized
INFO - 2016-05-22 09:56:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:56:34 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:56:34 --> Utf8 Class Initialized
INFO - 2016-05-22 09:56:34 --> URI Class Initialized
INFO - 2016-05-22 09:56:34 --> Router Class Initialized
INFO - 2016-05-22 09:56:34 --> Output Class Initialized
INFO - 2016-05-22 09:56:34 --> Security Class Initialized
DEBUG - 2016-05-22 09:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:56:34 --> Input Class Initialized
INFO - 2016-05-22 09:56:34 --> Language Class Initialized
INFO - 2016-05-22 09:56:34 --> Loader Class Initialized
INFO - 2016-05-22 09:56:34 --> Helper loaded: url_helper
INFO - 2016-05-22 09:56:34 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:56:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:56:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:56:34 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:56:34 --> Helper loaded: form_helper
INFO - 2016-05-22 09:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:56:34 --> Form Validation Class Initialized
INFO - 2016-05-22 09:56:34 --> Controller Class Initialized
DEBUG - 2016-05-22 09:56:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-22 09:56:34 --> Model Class Initialized
INFO - 2016-05-22 09:56:34 --> Database Driver Class Initialized
INFO - 2016-05-22 09:56:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-22 09:56:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 09:56:34 --> Final output sent to browser
DEBUG - 2016-05-22 09:56:34 --> Total execution time: 0.0862
INFO - 2016-05-22 09:56:35 --> Config Class Initialized
INFO - 2016-05-22 09:56:35 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:56:35 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:56:35 --> Utf8 Class Initialized
INFO - 2016-05-22 09:56:35 --> URI Class Initialized
INFO - 2016-05-22 09:56:35 --> Router Class Initialized
INFO - 2016-05-22 09:56:35 --> Output Class Initialized
INFO - 2016-05-22 09:56:35 --> Security Class Initialized
DEBUG - 2016-05-22 09:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:56:35 --> Input Class Initialized
INFO - 2016-05-22 09:56:35 --> Language Class Initialized
INFO - 2016-05-22 09:56:35 --> Loader Class Initialized
INFO - 2016-05-22 09:56:35 --> Helper loaded: url_helper
INFO - 2016-05-22 09:56:35 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:56:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:56:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:56:35 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:56:35 --> Helper loaded: form_helper
INFO - 2016-05-22 09:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:56:35 --> Form Validation Class Initialized
INFO - 2016-05-22 09:56:35 --> Controller Class Initialized
INFO - 2016-05-22 09:56:35 --> Model Class Initialized
INFO - 2016-05-22 09:56:35 --> Database Driver Class Initialized
INFO - 2016-05-22 09:56:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:56:35 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:56:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:56:35 --> Final output sent to browser
DEBUG - 2016-05-22 09:56:35 --> Total execution time: 0.0914
INFO - 2016-05-22 09:56:47 --> Config Class Initialized
INFO - 2016-05-22 09:56:47 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:56:47 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:56:47 --> Utf8 Class Initialized
INFO - 2016-05-22 09:56:47 --> URI Class Initialized
INFO - 2016-05-22 09:56:47 --> Router Class Initialized
INFO - 2016-05-22 09:56:47 --> Output Class Initialized
INFO - 2016-05-22 09:56:47 --> Security Class Initialized
DEBUG - 2016-05-22 09:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:56:47 --> Input Class Initialized
INFO - 2016-05-22 09:56:47 --> Language Class Initialized
INFO - 2016-05-22 09:56:47 --> Loader Class Initialized
INFO - 2016-05-22 09:56:47 --> Helper loaded: url_helper
INFO - 2016-05-22 09:56:47 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:56:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:56:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:56:47 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:56:47 --> Helper loaded: form_helper
INFO - 2016-05-22 09:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:56:47 --> Form Validation Class Initialized
INFO - 2016-05-22 09:56:47 --> Controller Class Initialized
DEBUG - 2016-05-22 09:56:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-22 09:56:47 --> Model Class Initialized
INFO - 2016-05-22 09:56:47 --> Database Driver Class Initialized
INFO - 2016-05-22 09:56:47 --> Config Class Initialized
INFO - 2016-05-22 09:56:47 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:56:47 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:56:47 --> Utf8 Class Initialized
INFO - 2016-05-22 09:56:47 --> URI Class Initialized
INFO - 2016-05-22 09:56:47 --> Router Class Initialized
INFO - 2016-05-22 09:56:47 --> Output Class Initialized
INFO - 2016-05-22 09:56:47 --> Security Class Initialized
DEBUG - 2016-05-22 09:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:56:47 --> Input Class Initialized
INFO - 2016-05-22 09:56:47 --> Language Class Initialized
INFO - 2016-05-22 09:56:47 --> Loader Class Initialized
INFO - 2016-05-22 09:56:47 --> Helper loaded: url_helper
INFO - 2016-05-22 09:56:47 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:56:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:56:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:56:47 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:56:47 --> Helper loaded: form_helper
INFO - 2016-05-22 09:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:56:47 --> Form Validation Class Initialized
INFO - 2016-05-22 09:56:47 --> Controller Class Initialized
DEBUG - 2016-05-22 09:56:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-22 09:56:47 --> Model Class Initialized
INFO - 2016-05-22 09:56:47 --> Database Driver Class Initialized
INFO - 2016-05-22 09:56:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-22 09:56:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-22 09:56:47 --> Final output sent to browser
DEBUG - 2016-05-22 09:56:47 --> Total execution time: 0.0856
INFO - 2016-05-22 09:56:47 --> Config Class Initialized
INFO - 2016-05-22 09:56:47 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:56:47 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:56:47 --> Utf8 Class Initialized
INFO - 2016-05-22 09:56:47 --> URI Class Initialized
INFO - 2016-05-22 09:56:47 --> Router Class Initialized
INFO - 2016-05-22 09:56:47 --> Output Class Initialized
INFO - 2016-05-22 09:56:47 --> Security Class Initialized
DEBUG - 2016-05-22 09:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:56:47 --> Input Class Initialized
INFO - 2016-05-22 09:56:47 --> Language Class Initialized
INFO - 2016-05-22 09:56:47 --> Loader Class Initialized
INFO - 2016-05-22 09:56:47 --> Helper loaded: url_helper
INFO - 2016-05-22 09:56:47 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:56:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:56:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:56:47 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:56:47 --> Helper loaded: form_helper
INFO - 2016-05-22 09:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:56:47 --> Form Validation Class Initialized
INFO - 2016-05-22 09:56:47 --> Controller Class Initialized
INFO - 2016-05-22 09:56:47 --> Model Class Initialized
INFO - 2016-05-22 09:56:47 --> Database Driver Class Initialized
INFO - 2016-05-22 09:56:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:56:47 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:56:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:56:47 --> Final output sent to browser
DEBUG - 2016-05-22 09:56:47 --> Total execution time: 0.0857
INFO - 2016-05-22 09:56:57 --> Config Class Initialized
INFO - 2016-05-22 09:56:57 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:56:57 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:56:57 --> Utf8 Class Initialized
INFO - 2016-05-22 09:56:57 --> URI Class Initialized
INFO - 2016-05-22 09:56:57 --> Router Class Initialized
INFO - 2016-05-22 09:56:57 --> Output Class Initialized
INFO - 2016-05-22 09:56:57 --> Security Class Initialized
DEBUG - 2016-05-22 09:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:56:57 --> Input Class Initialized
INFO - 2016-05-22 09:56:57 --> Language Class Initialized
INFO - 2016-05-22 09:56:57 --> Loader Class Initialized
INFO - 2016-05-22 09:56:57 --> Helper loaded: url_helper
INFO - 2016-05-22 09:56:57 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:56:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:56:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:56:57 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:56:57 --> Helper loaded: form_helper
INFO - 2016-05-22 09:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:56:57 --> Form Validation Class Initialized
INFO - 2016-05-22 09:56:57 --> Controller Class Initialized
DEBUG - 2016-05-22 09:56:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-22 09:56:57 --> Model Class Initialized
INFO - 2016-05-22 09:56:57 --> Database Driver Class Initialized
INFO - 2016-05-22 09:56:57 --> Config Class Initialized
INFO - 2016-05-22 09:56:57 --> Hooks Class Initialized
INFO - 2016-05-22 09:56:57 --> Config Class Initialized
INFO - 2016-05-22 09:56:57 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:56:57 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:56:57 --> Utf8 Class Initialized
INFO - 2016-05-22 09:56:57 --> URI Class Initialized
DEBUG - 2016-05-22 09:56:57 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:56:57 --> Utf8 Class Initialized
INFO - 2016-05-22 09:56:57 --> Router Class Initialized
INFO - 2016-05-22 09:56:57 --> URI Class Initialized
INFO - 2016-05-22 09:56:57 --> Output Class Initialized
INFO - 2016-05-22 09:56:57 --> Router Class Initialized
INFO - 2016-05-22 09:56:57 --> Security Class Initialized
INFO - 2016-05-22 09:56:57 --> Output Class Initialized
DEBUG - 2016-05-22 09:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:56:57 --> Input Class Initialized
INFO - 2016-05-22 09:56:57 --> Language Class Initialized
INFO - 2016-05-22 09:56:57 --> Security Class Initialized
DEBUG - 2016-05-22 09:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:56:57 --> Input Class Initialized
INFO - 2016-05-22 09:56:57 --> Loader Class Initialized
INFO - 2016-05-22 09:56:57 --> Language Class Initialized
INFO - 2016-05-22 09:56:57 --> Helper loaded: url_helper
INFO - 2016-05-22 09:56:57 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:56:57 --> Loader Class Initialized
INFO - 2016-05-22 09:56:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:56:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:56:57 --> Helper loaded: url_helper
INFO - 2016-05-22 09:56:57 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:56:57 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:56:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:56:57 --> Helper loaded: form_helper
INFO - 2016-05-22 09:56:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:56:57 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:56:57 --> Helper loaded: form_helper
INFO - 2016-05-22 09:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:56:57 --> Form Validation Class Initialized
INFO - 2016-05-22 09:56:57 --> Controller Class Initialized
DEBUG - 2016-05-22 09:56:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-22 09:56:57 --> Model Class Initialized
INFO - 2016-05-22 09:56:57 --> Database Driver Class Initialized
INFO - 2016-05-22 09:56:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-22 09:56:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-22 09:56:57 --> Final output sent to browser
DEBUG - 2016-05-22 09:56:57 --> Total execution time: 0.1252
INFO - 2016-05-22 09:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:56:57 --> Form Validation Class Initialized
INFO - 2016-05-22 09:56:57 --> Controller Class Initialized
DEBUG - 2016-05-22 09:56:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-22 09:56:57 --> Model Class Initialized
INFO - 2016-05-22 09:56:57 --> Database Driver Class Initialized
INFO - 2016-05-22 09:56:58 --> Config Class Initialized
INFO - 2016-05-22 09:56:58 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:56:58 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:56:58 --> Utf8 Class Initialized
INFO - 2016-05-22 09:56:58 --> URI Class Initialized
INFO - 2016-05-22 09:56:58 --> Router Class Initialized
INFO - 2016-05-22 09:56:58 --> Output Class Initialized
INFO - 2016-05-22 09:56:58 --> Security Class Initialized
DEBUG - 2016-05-22 09:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:56:58 --> Input Class Initialized
INFO - 2016-05-22 09:56:58 --> Language Class Initialized
INFO - 2016-05-22 09:56:58 --> Loader Class Initialized
INFO - 2016-05-22 09:56:58 --> Helper loaded: url_helper
INFO - 2016-05-22 09:56:58 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:56:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:56:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:56:58 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:56:58 --> Helper loaded: form_helper
INFO - 2016-05-22 09:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:56:58 --> Form Validation Class Initialized
INFO - 2016-05-22 09:56:58 --> Controller Class Initialized
DEBUG - 2016-05-22 09:56:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-22 09:56:58 --> Model Class Initialized
INFO - 2016-05-22 09:56:58 --> Database Driver Class Initialized
INFO - 2016-05-22 09:56:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-22 09:56:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-22 09:56:58 --> Final output sent to browser
DEBUG - 2016-05-22 09:56:58 --> Total execution time: 0.0726
INFO - 2016-05-22 09:56:58 --> Config Class Initialized
INFO - 2016-05-22 09:56:58 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:56:58 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:56:58 --> Utf8 Class Initialized
INFO - 2016-05-22 09:56:58 --> URI Class Initialized
INFO - 2016-05-22 09:56:58 --> Router Class Initialized
INFO - 2016-05-22 09:56:58 --> Output Class Initialized
INFO - 2016-05-22 09:56:58 --> Security Class Initialized
DEBUG - 2016-05-22 09:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:56:58 --> Input Class Initialized
INFO - 2016-05-22 09:56:58 --> Language Class Initialized
INFO - 2016-05-22 09:56:58 --> Loader Class Initialized
INFO - 2016-05-22 09:56:58 --> Helper loaded: url_helper
INFO - 2016-05-22 09:56:58 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:56:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:56:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:56:58 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:56:58 --> Helper loaded: form_helper
INFO - 2016-05-22 09:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:56:58 --> Form Validation Class Initialized
INFO - 2016-05-22 09:56:58 --> Controller Class Initialized
INFO - 2016-05-22 09:56:58 --> Model Class Initialized
INFO - 2016-05-22 09:56:58 --> Database Driver Class Initialized
INFO - 2016-05-22 09:56:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:56:58 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:56:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:56:58 --> Final output sent to browser
DEBUG - 2016-05-22 09:56:58 --> Total execution time: 0.0974
INFO - 2016-05-22 09:57:00 --> Config Class Initialized
INFO - 2016-05-22 09:57:00 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:57:00 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:57:00 --> Utf8 Class Initialized
INFO - 2016-05-22 09:57:00 --> URI Class Initialized
INFO - 2016-05-22 09:57:00 --> Router Class Initialized
INFO - 2016-05-22 09:57:00 --> Output Class Initialized
INFO - 2016-05-22 09:57:00 --> Security Class Initialized
DEBUG - 2016-05-22 09:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:57:00 --> Input Class Initialized
INFO - 2016-05-22 09:57:00 --> Language Class Initialized
INFO - 2016-05-22 09:57:00 --> Loader Class Initialized
INFO - 2016-05-22 09:57:00 --> Helper loaded: url_helper
INFO - 2016-05-22 09:57:00 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:57:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:57:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:57:00 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:57:00 --> Helper loaded: form_helper
INFO - 2016-05-22 09:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:57:00 --> Form Validation Class Initialized
INFO - 2016-05-22 09:57:00 --> Controller Class Initialized
DEBUG - 2016-05-22 09:57:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-22 09:57:00 --> Model Class Initialized
INFO - 2016-05-22 09:57:00 --> Database Driver Class Initialized
INFO - 2016-05-22 09:57:00 --> Config Class Initialized
INFO - 2016-05-22 09:57:00 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:57:00 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:57:00 --> Utf8 Class Initialized
INFO - 2016-05-22 09:57:00 --> URI Class Initialized
INFO - 2016-05-22 09:57:00 --> Router Class Initialized
INFO - 2016-05-22 09:57:00 --> Output Class Initialized
INFO - 2016-05-22 09:57:00 --> Security Class Initialized
DEBUG - 2016-05-22 09:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:57:00 --> Input Class Initialized
INFO - 2016-05-22 09:57:00 --> Language Class Initialized
INFO - 2016-05-22 09:57:00 --> Loader Class Initialized
INFO - 2016-05-22 09:57:00 --> Helper loaded: url_helper
INFO - 2016-05-22 09:57:00 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:57:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:57:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:57:00 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:57:00 --> Helper loaded: form_helper
INFO - 2016-05-22 09:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:57:00 --> Form Validation Class Initialized
INFO - 2016-05-22 09:57:00 --> Controller Class Initialized
DEBUG - 2016-05-22 09:57:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-22 09:57:00 --> Model Class Initialized
INFO - 2016-05-22 09:57:00 --> Database Driver Class Initialized
INFO - 2016-05-22 09:57:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-22 09:57:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 09:57:00 --> Final output sent to browser
DEBUG - 2016-05-22 09:57:00 --> Total execution time: 0.0771
INFO - 2016-05-22 09:57:00 --> Config Class Initialized
INFO - 2016-05-22 09:57:00 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:57:00 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:57:00 --> Utf8 Class Initialized
INFO - 2016-05-22 09:57:00 --> URI Class Initialized
INFO - 2016-05-22 09:57:00 --> Router Class Initialized
INFO - 2016-05-22 09:57:00 --> Output Class Initialized
INFO - 2016-05-22 09:57:00 --> Security Class Initialized
DEBUG - 2016-05-22 09:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:57:00 --> Input Class Initialized
INFO - 2016-05-22 09:57:00 --> Language Class Initialized
INFO - 2016-05-22 09:57:00 --> Loader Class Initialized
INFO - 2016-05-22 09:57:00 --> Helper loaded: url_helper
INFO - 2016-05-22 09:57:00 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:57:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:57:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:57:00 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:57:00 --> Helper loaded: form_helper
INFO - 2016-05-22 09:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:57:01 --> Form Validation Class Initialized
INFO - 2016-05-22 09:57:01 --> Controller Class Initialized
INFO - 2016-05-22 09:57:01 --> Model Class Initialized
INFO - 2016-05-22 09:57:01 --> Database Driver Class Initialized
INFO - 2016-05-22 09:57:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:57:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:57:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:57:01 --> Final output sent to browser
DEBUG - 2016-05-22 09:57:01 --> Total execution time: 0.0990
INFO - 2016-05-22 09:58:01 --> Config Class Initialized
INFO - 2016-05-22 09:58:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:58:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:58:01 --> Utf8 Class Initialized
INFO - 2016-05-22 09:58:01 --> URI Class Initialized
INFO - 2016-05-22 09:58:01 --> Router Class Initialized
INFO - 2016-05-22 09:58:01 --> Output Class Initialized
INFO - 2016-05-22 09:58:01 --> Security Class Initialized
DEBUG - 2016-05-22 09:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:58:01 --> Input Class Initialized
INFO - 2016-05-22 09:58:01 --> Language Class Initialized
INFO - 2016-05-22 09:58:01 --> Loader Class Initialized
INFO - 2016-05-22 09:58:01 --> Helper loaded: url_helper
INFO - 2016-05-22 09:58:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:58:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:58:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:58:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:58:01 --> Helper loaded: form_helper
INFO - 2016-05-22 09:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:58:01 --> Form Validation Class Initialized
INFO - 2016-05-22 09:58:01 --> Controller Class Initialized
INFO - 2016-05-22 09:58:01 --> Model Class Initialized
INFO - 2016-05-22 09:58:01 --> Database Driver Class Initialized
INFO - 2016-05-22 09:58:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:58:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:58:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:58:01 --> Final output sent to browser
DEBUG - 2016-05-22 09:58:01 --> Total execution time: 0.0808
INFO - 2016-05-22 09:59:01 --> Config Class Initialized
INFO - 2016-05-22 09:59:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 09:59:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 09:59:01 --> Utf8 Class Initialized
INFO - 2016-05-22 09:59:01 --> URI Class Initialized
INFO - 2016-05-22 09:59:01 --> Router Class Initialized
INFO - 2016-05-22 09:59:01 --> Output Class Initialized
INFO - 2016-05-22 09:59:01 --> Security Class Initialized
DEBUG - 2016-05-22 09:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 09:59:01 --> Input Class Initialized
INFO - 2016-05-22 09:59:01 --> Language Class Initialized
INFO - 2016-05-22 09:59:01 --> Loader Class Initialized
INFO - 2016-05-22 09:59:01 --> Helper loaded: url_helper
INFO - 2016-05-22 09:59:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 09:59:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 09:59:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 09:59:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 09:59:01 --> Helper loaded: form_helper
INFO - 2016-05-22 09:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 09:59:01 --> Form Validation Class Initialized
INFO - 2016-05-22 09:59:01 --> Controller Class Initialized
INFO - 2016-05-22 09:59:01 --> Model Class Initialized
INFO - 2016-05-22 09:59:01 --> Database Driver Class Initialized
INFO - 2016-05-22 09:59:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 09:59:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 09:59:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 09:59:01 --> Final output sent to browser
DEBUG - 2016-05-22 09:59:01 --> Total execution time: 0.0809
INFO - 2016-05-22 10:00:01 --> Config Class Initialized
INFO - 2016-05-22 10:00:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:00:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:00:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:00:01 --> URI Class Initialized
INFO - 2016-05-22 10:00:01 --> Router Class Initialized
INFO - 2016-05-22 10:00:01 --> Output Class Initialized
INFO - 2016-05-22 10:00:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:00:01 --> Input Class Initialized
INFO - 2016-05-22 10:00:01 --> Language Class Initialized
INFO - 2016-05-22 10:00:01 --> Loader Class Initialized
INFO - 2016-05-22 10:00:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:00:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:00:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:00:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:00:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:00:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:00:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:00:01 --> Controller Class Initialized
INFO - 2016-05-22 10:00:01 --> Model Class Initialized
INFO - 2016-05-22 10:00:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:00:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:00:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:00:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:00:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:00:01 --> Total execution time: 0.0915
INFO - 2016-05-22 10:01:01 --> Config Class Initialized
INFO - 2016-05-22 10:01:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:01:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:01:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:01:01 --> URI Class Initialized
INFO - 2016-05-22 10:01:01 --> Router Class Initialized
INFO - 2016-05-22 10:01:01 --> Output Class Initialized
INFO - 2016-05-22 10:01:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:01:01 --> Input Class Initialized
INFO - 2016-05-22 10:01:01 --> Language Class Initialized
INFO - 2016-05-22 10:01:01 --> Loader Class Initialized
INFO - 2016-05-22 10:01:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:01:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:01:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:01:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:01:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:01:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:01:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:01:01 --> Controller Class Initialized
INFO - 2016-05-22 10:01:01 --> Model Class Initialized
INFO - 2016-05-22 10:01:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:01:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:01:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:01:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:01:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:01:01 --> Total execution time: 0.1004
INFO - 2016-05-22 10:02:01 --> Config Class Initialized
INFO - 2016-05-22 10:02:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:02:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:02:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:02:01 --> URI Class Initialized
INFO - 2016-05-22 10:02:01 --> Router Class Initialized
INFO - 2016-05-22 10:02:01 --> Output Class Initialized
INFO - 2016-05-22 10:02:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:02:01 --> Input Class Initialized
INFO - 2016-05-22 10:02:01 --> Language Class Initialized
INFO - 2016-05-22 10:02:01 --> Loader Class Initialized
INFO - 2016-05-22 10:02:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:02:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:02:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:02:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:02:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:02:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:02:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:02:01 --> Controller Class Initialized
INFO - 2016-05-22 10:02:01 --> Model Class Initialized
INFO - 2016-05-22 10:02:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:02:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:02:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:02:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:02:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:02:01 --> Total execution time: 0.0933
INFO - 2016-05-22 10:03:01 --> Config Class Initialized
INFO - 2016-05-22 10:03:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:03:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:03:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:03:01 --> URI Class Initialized
INFO - 2016-05-22 10:03:01 --> Router Class Initialized
INFO - 2016-05-22 10:03:01 --> Output Class Initialized
INFO - 2016-05-22 10:03:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:03:01 --> Input Class Initialized
INFO - 2016-05-22 10:03:01 --> Language Class Initialized
INFO - 2016-05-22 10:03:01 --> Loader Class Initialized
INFO - 2016-05-22 10:03:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:03:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:03:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:03:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:03:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:03:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:03:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:03:01 --> Controller Class Initialized
INFO - 2016-05-22 10:03:01 --> Model Class Initialized
INFO - 2016-05-22 10:03:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:03:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:03:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:03:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:03:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:03:01 --> Total execution time: 0.1179
INFO - 2016-05-22 10:04:01 --> Config Class Initialized
INFO - 2016-05-22 10:04:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:04:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:04:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:04:01 --> URI Class Initialized
INFO - 2016-05-22 10:04:01 --> Router Class Initialized
INFO - 2016-05-22 10:04:01 --> Output Class Initialized
INFO - 2016-05-22 10:04:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:04:01 --> Input Class Initialized
INFO - 2016-05-22 10:04:01 --> Language Class Initialized
INFO - 2016-05-22 10:04:01 --> Loader Class Initialized
INFO - 2016-05-22 10:04:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:04:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:04:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:04:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:04:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:04:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:04:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:04:01 --> Controller Class Initialized
INFO - 2016-05-22 10:04:01 --> Model Class Initialized
INFO - 2016-05-22 10:04:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:04:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:04:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:04:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:04:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:04:01 --> Total execution time: 0.0834
INFO - 2016-05-22 10:05:01 --> Config Class Initialized
INFO - 2016-05-22 10:05:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:05:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:05:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:05:01 --> URI Class Initialized
INFO - 2016-05-22 10:05:01 --> Router Class Initialized
INFO - 2016-05-22 10:05:01 --> Output Class Initialized
INFO - 2016-05-22 10:05:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:05:01 --> Input Class Initialized
INFO - 2016-05-22 10:05:01 --> Language Class Initialized
INFO - 2016-05-22 10:05:01 --> Loader Class Initialized
INFO - 2016-05-22 10:05:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:05:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:05:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:05:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:05:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:05:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:05:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:05:01 --> Controller Class Initialized
INFO - 2016-05-22 10:05:01 --> Model Class Initialized
INFO - 2016-05-22 10:05:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:05:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:05:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:05:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:05:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:05:01 --> Total execution time: 0.0823
INFO - 2016-05-22 10:06:01 --> Config Class Initialized
INFO - 2016-05-22 10:06:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:06:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:06:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:06:01 --> URI Class Initialized
INFO - 2016-05-22 10:06:01 --> Router Class Initialized
INFO - 2016-05-22 10:06:01 --> Output Class Initialized
INFO - 2016-05-22 10:06:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:06:01 --> Input Class Initialized
INFO - 2016-05-22 10:06:01 --> Language Class Initialized
INFO - 2016-05-22 10:06:01 --> Loader Class Initialized
INFO - 2016-05-22 10:06:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:06:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:06:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:06:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:06:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:06:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:06:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:06:01 --> Controller Class Initialized
INFO - 2016-05-22 10:06:01 --> Model Class Initialized
INFO - 2016-05-22 10:06:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:06:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:06:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:06:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:06:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:06:01 --> Total execution time: 0.0795
INFO - 2016-05-22 10:07:01 --> Config Class Initialized
INFO - 2016-05-22 10:07:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:07:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:07:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:07:01 --> URI Class Initialized
INFO - 2016-05-22 10:07:01 --> Router Class Initialized
INFO - 2016-05-22 10:07:01 --> Output Class Initialized
INFO - 2016-05-22 10:07:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:07:01 --> Input Class Initialized
INFO - 2016-05-22 10:07:01 --> Language Class Initialized
INFO - 2016-05-22 10:07:01 --> Loader Class Initialized
INFO - 2016-05-22 10:07:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:07:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:07:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:07:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:07:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:07:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:07:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:07:01 --> Controller Class Initialized
INFO - 2016-05-22 10:07:01 --> Model Class Initialized
INFO - 2016-05-22 10:07:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:07:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:07:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:07:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:07:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:07:01 --> Total execution time: 0.1125
INFO - 2016-05-22 10:08:01 --> Config Class Initialized
INFO - 2016-05-22 10:08:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:08:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:08:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:08:01 --> URI Class Initialized
INFO - 2016-05-22 10:08:01 --> Router Class Initialized
INFO - 2016-05-22 10:08:01 --> Output Class Initialized
INFO - 2016-05-22 10:08:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:08:01 --> Input Class Initialized
INFO - 2016-05-22 10:08:01 --> Language Class Initialized
INFO - 2016-05-22 10:08:01 --> Loader Class Initialized
INFO - 2016-05-22 10:08:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:08:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:08:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:08:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:08:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:08:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:08:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:08:01 --> Controller Class Initialized
INFO - 2016-05-22 10:08:01 --> Model Class Initialized
INFO - 2016-05-22 10:08:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:08:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:08:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:08:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:08:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:08:01 --> Total execution time: 0.0765
INFO - 2016-05-22 10:09:01 --> Config Class Initialized
INFO - 2016-05-22 10:09:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:09:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:09:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:09:01 --> URI Class Initialized
INFO - 2016-05-22 10:09:01 --> Router Class Initialized
INFO - 2016-05-22 10:09:01 --> Output Class Initialized
INFO - 2016-05-22 10:09:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:09:01 --> Input Class Initialized
INFO - 2016-05-22 10:09:01 --> Language Class Initialized
INFO - 2016-05-22 10:09:01 --> Loader Class Initialized
INFO - 2016-05-22 10:09:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:09:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:09:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:09:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:09:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:09:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:09:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:09:01 --> Controller Class Initialized
INFO - 2016-05-22 10:09:01 --> Model Class Initialized
INFO - 2016-05-22 10:09:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:09:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:09:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:09:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:09:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:09:01 --> Total execution time: 0.0771
INFO - 2016-05-22 10:10:01 --> Config Class Initialized
INFO - 2016-05-22 10:10:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:10:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:10:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:10:01 --> URI Class Initialized
INFO - 2016-05-22 10:10:01 --> Router Class Initialized
INFO - 2016-05-22 10:10:01 --> Output Class Initialized
INFO - 2016-05-22 10:10:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:10:01 --> Input Class Initialized
INFO - 2016-05-22 10:10:01 --> Language Class Initialized
INFO - 2016-05-22 10:10:01 --> Loader Class Initialized
INFO - 2016-05-22 10:10:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:10:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:10:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:10:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:10:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:10:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:10:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:10:01 --> Controller Class Initialized
INFO - 2016-05-22 10:10:01 --> Model Class Initialized
INFO - 2016-05-22 10:10:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:10:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:10:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:10:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:10:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:10:01 --> Total execution time: 0.0838
INFO - 2016-05-22 10:11:01 --> Config Class Initialized
INFO - 2016-05-22 10:11:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:11:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:11:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:11:01 --> URI Class Initialized
INFO - 2016-05-22 10:11:01 --> Router Class Initialized
INFO - 2016-05-22 10:11:01 --> Output Class Initialized
INFO - 2016-05-22 10:11:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:11:01 --> Input Class Initialized
INFO - 2016-05-22 10:11:01 --> Language Class Initialized
INFO - 2016-05-22 10:11:01 --> Loader Class Initialized
INFO - 2016-05-22 10:11:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:11:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:11:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:11:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:11:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:11:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:11:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:11:01 --> Controller Class Initialized
INFO - 2016-05-22 10:11:01 --> Model Class Initialized
INFO - 2016-05-22 10:11:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:11:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:11:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:11:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:11:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:11:01 --> Total execution time: 0.0778
INFO - 2016-05-22 10:12:01 --> Config Class Initialized
INFO - 2016-05-22 10:12:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:12:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:12:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:12:01 --> URI Class Initialized
INFO - 2016-05-22 10:12:01 --> Router Class Initialized
INFO - 2016-05-22 10:12:01 --> Output Class Initialized
INFO - 2016-05-22 10:12:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:12:01 --> Input Class Initialized
INFO - 2016-05-22 10:12:01 --> Language Class Initialized
INFO - 2016-05-22 10:12:01 --> Loader Class Initialized
INFO - 2016-05-22 10:12:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:12:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:12:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:12:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:12:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:12:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:12:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:12:01 --> Controller Class Initialized
INFO - 2016-05-22 10:12:01 --> Model Class Initialized
INFO - 2016-05-22 10:12:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:12:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:12:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:12:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:12:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:12:01 --> Total execution time: 0.0757
INFO - 2016-05-22 10:13:04 --> Config Class Initialized
INFO - 2016-05-22 10:13:04 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:13:04 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:13:04 --> Utf8 Class Initialized
INFO - 2016-05-22 10:13:04 --> URI Class Initialized
INFO - 2016-05-22 10:13:04 --> Router Class Initialized
INFO - 2016-05-22 10:13:04 --> Output Class Initialized
INFO - 2016-05-22 10:13:04 --> Security Class Initialized
DEBUG - 2016-05-22 10:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:13:04 --> Input Class Initialized
INFO - 2016-05-22 10:13:04 --> Language Class Initialized
INFO - 2016-05-22 10:13:04 --> Loader Class Initialized
INFO - 2016-05-22 10:13:04 --> Helper loaded: url_helper
INFO - 2016-05-22 10:13:04 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:13:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:13:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:13:04 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:13:04 --> Helper loaded: form_helper
INFO - 2016-05-22 10:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:13:04 --> Form Validation Class Initialized
INFO - 2016-05-22 10:13:04 --> Controller Class Initialized
INFO - 2016-05-22 10:13:04 --> Model Class Initialized
INFO - 2016-05-22 10:13:05 --> Database Driver Class Initialized
INFO - 2016-05-22 10:13:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:13:05 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:13:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:13:05 --> Final output sent to browser
DEBUG - 2016-05-22 10:13:05 --> Total execution time: 1.2768
INFO - 2016-05-22 10:14:01 --> Config Class Initialized
INFO - 2016-05-22 10:14:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:14:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:14:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:14:01 --> URI Class Initialized
INFO - 2016-05-22 10:14:01 --> Router Class Initialized
INFO - 2016-05-22 10:14:01 --> Output Class Initialized
INFO - 2016-05-22 10:14:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:14:01 --> Input Class Initialized
INFO - 2016-05-22 10:14:01 --> Language Class Initialized
INFO - 2016-05-22 10:14:01 --> Loader Class Initialized
INFO - 2016-05-22 10:14:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:14:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:14:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:14:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:14:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:14:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:14:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:14:01 --> Controller Class Initialized
INFO - 2016-05-22 10:14:01 --> Model Class Initialized
INFO - 2016-05-22 10:14:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:14:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:14:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:14:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:14:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:14:01 --> Total execution time: 0.0798
INFO - 2016-05-22 10:15:01 --> Config Class Initialized
INFO - 2016-05-22 10:15:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:15:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:15:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:15:01 --> URI Class Initialized
INFO - 2016-05-22 10:15:01 --> Router Class Initialized
INFO - 2016-05-22 10:15:01 --> Output Class Initialized
INFO - 2016-05-22 10:15:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:15:01 --> Input Class Initialized
INFO - 2016-05-22 10:15:01 --> Language Class Initialized
INFO - 2016-05-22 10:15:01 --> Loader Class Initialized
INFO - 2016-05-22 10:15:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:15:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:15:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:15:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:15:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:15:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:15:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:15:01 --> Controller Class Initialized
INFO - 2016-05-22 10:15:01 --> Model Class Initialized
INFO - 2016-05-22 10:15:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:15:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:15:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:15:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:15:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:15:01 --> Total execution time: 0.0846
INFO - 2016-05-22 10:16:01 --> Config Class Initialized
INFO - 2016-05-22 10:16:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:16:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:16:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:16:01 --> URI Class Initialized
INFO - 2016-05-22 10:16:01 --> Router Class Initialized
INFO - 2016-05-22 10:16:01 --> Output Class Initialized
INFO - 2016-05-22 10:16:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:16:01 --> Input Class Initialized
INFO - 2016-05-22 10:16:01 --> Language Class Initialized
INFO - 2016-05-22 10:16:01 --> Loader Class Initialized
INFO - 2016-05-22 10:16:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:16:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:16:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:16:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:16:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:16:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:16:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:16:01 --> Controller Class Initialized
INFO - 2016-05-22 10:16:01 --> Model Class Initialized
INFO - 2016-05-22 10:16:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:16:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:16:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:16:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:16:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:16:01 --> Total execution time: 0.0740
INFO - 2016-05-22 10:17:01 --> Config Class Initialized
INFO - 2016-05-22 10:17:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:17:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:17:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:17:01 --> URI Class Initialized
INFO - 2016-05-22 10:17:01 --> Router Class Initialized
INFO - 2016-05-22 10:17:01 --> Output Class Initialized
INFO - 2016-05-22 10:17:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:17:01 --> Input Class Initialized
INFO - 2016-05-22 10:17:01 --> Language Class Initialized
INFO - 2016-05-22 10:17:01 --> Loader Class Initialized
INFO - 2016-05-22 10:17:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:17:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:17:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:17:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:17:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:17:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:17:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:17:01 --> Controller Class Initialized
INFO - 2016-05-22 10:17:01 --> Model Class Initialized
INFO - 2016-05-22 10:17:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:17:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:17:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:17:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:17:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:17:01 --> Total execution time: 0.0714
INFO - 2016-05-22 10:18:01 --> Config Class Initialized
INFO - 2016-05-22 10:18:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:18:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:18:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:18:01 --> URI Class Initialized
INFO - 2016-05-22 10:18:01 --> Router Class Initialized
INFO - 2016-05-22 10:18:01 --> Output Class Initialized
INFO - 2016-05-22 10:18:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:18:01 --> Input Class Initialized
INFO - 2016-05-22 10:18:01 --> Language Class Initialized
INFO - 2016-05-22 10:18:01 --> Loader Class Initialized
INFO - 2016-05-22 10:18:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:18:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:18:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:18:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:18:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:18:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:18:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:18:01 --> Controller Class Initialized
INFO - 2016-05-22 10:18:01 --> Model Class Initialized
INFO - 2016-05-22 10:18:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:18:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:18:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:18:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:18:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:18:01 --> Total execution time: 0.0740
INFO - 2016-05-22 10:19:01 --> Config Class Initialized
INFO - 2016-05-22 10:19:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:19:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:19:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:19:01 --> URI Class Initialized
INFO - 2016-05-22 10:19:01 --> Router Class Initialized
INFO - 2016-05-22 10:19:01 --> Output Class Initialized
INFO - 2016-05-22 10:19:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:19:01 --> Input Class Initialized
INFO - 2016-05-22 10:19:01 --> Language Class Initialized
INFO - 2016-05-22 10:19:01 --> Loader Class Initialized
INFO - 2016-05-22 10:19:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:19:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:19:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:19:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:19:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:19:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:19:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:19:01 --> Controller Class Initialized
INFO - 2016-05-22 10:19:01 --> Model Class Initialized
INFO - 2016-05-22 10:19:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:19:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:19:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:19:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:19:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:19:01 --> Total execution time: 0.0740
INFO - 2016-05-22 10:20:01 --> Config Class Initialized
INFO - 2016-05-22 10:20:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:20:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:20:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:20:01 --> URI Class Initialized
INFO - 2016-05-22 10:20:01 --> Router Class Initialized
INFO - 2016-05-22 10:20:01 --> Output Class Initialized
INFO - 2016-05-22 10:20:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:20:01 --> Input Class Initialized
INFO - 2016-05-22 10:20:01 --> Language Class Initialized
INFO - 2016-05-22 10:20:01 --> Loader Class Initialized
INFO - 2016-05-22 10:20:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:20:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:20:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:20:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:20:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:20:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:20:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:20:01 --> Controller Class Initialized
INFO - 2016-05-22 10:20:01 --> Model Class Initialized
INFO - 2016-05-22 10:20:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:20:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:20:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:20:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:20:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:20:01 --> Total execution time: 0.0801
INFO - 2016-05-22 10:21:01 --> Config Class Initialized
INFO - 2016-05-22 10:21:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:21:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:21:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:21:01 --> URI Class Initialized
INFO - 2016-05-22 10:21:01 --> Router Class Initialized
INFO - 2016-05-22 10:21:01 --> Output Class Initialized
INFO - 2016-05-22 10:21:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:21:01 --> Input Class Initialized
INFO - 2016-05-22 10:21:01 --> Language Class Initialized
INFO - 2016-05-22 10:21:01 --> Loader Class Initialized
INFO - 2016-05-22 10:21:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:21:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:21:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:21:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:21:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:21:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:21:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:21:01 --> Controller Class Initialized
INFO - 2016-05-22 10:21:01 --> Model Class Initialized
INFO - 2016-05-22 10:21:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:21:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:21:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:21:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:21:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:21:01 --> Total execution time: 0.0739
INFO - 2016-05-22 10:22:01 --> Config Class Initialized
INFO - 2016-05-22 10:22:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:22:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:22:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:22:01 --> URI Class Initialized
INFO - 2016-05-22 10:22:01 --> Router Class Initialized
INFO - 2016-05-22 10:22:01 --> Output Class Initialized
INFO - 2016-05-22 10:22:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:22:01 --> Input Class Initialized
INFO - 2016-05-22 10:22:01 --> Language Class Initialized
INFO - 2016-05-22 10:22:01 --> Loader Class Initialized
INFO - 2016-05-22 10:22:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:22:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:22:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:22:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:22:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:22:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:22:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:22:01 --> Controller Class Initialized
INFO - 2016-05-22 10:22:01 --> Model Class Initialized
INFO - 2016-05-22 10:22:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:22:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:22:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:22:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:22:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:22:01 --> Total execution time: 0.0708
INFO - 2016-05-22 10:23:01 --> Config Class Initialized
INFO - 2016-05-22 10:23:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:23:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:23:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:23:01 --> URI Class Initialized
INFO - 2016-05-22 10:23:01 --> Router Class Initialized
INFO - 2016-05-22 10:23:01 --> Output Class Initialized
INFO - 2016-05-22 10:23:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:23:01 --> Input Class Initialized
INFO - 2016-05-22 10:23:01 --> Language Class Initialized
INFO - 2016-05-22 10:23:01 --> Loader Class Initialized
INFO - 2016-05-22 10:23:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:23:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:23:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:23:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:23:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:23:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:23:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:23:01 --> Controller Class Initialized
INFO - 2016-05-22 10:23:01 --> Model Class Initialized
INFO - 2016-05-22 10:23:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:23:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:23:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:23:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:23:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:23:01 --> Total execution time: 0.0757
INFO - 2016-05-22 10:24:01 --> Config Class Initialized
INFO - 2016-05-22 10:24:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:24:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:24:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:24:01 --> URI Class Initialized
INFO - 2016-05-22 10:24:01 --> Router Class Initialized
INFO - 2016-05-22 10:24:01 --> Output Class Initialized
INFO - 2016-05-22 10:24:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:24:01 --> Input Class Initialized
INFO - 2016-05-22 10:24:01 --> Language Class Initialized
INFO - 2016-05-22 10:24:01 --> Loader Class Initialized
INFO - 2016-05-22 10:24:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:24:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:24:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:24:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:24:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:24:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:24:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:24:01 --> Controller Class Initialized
INFO - 2016-05-22 10:24:01 --> Model Class Initialized
INFO - 2016-05-22 10:24:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:24:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:24:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:24:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:24:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:24:01 --> Total execution time: 0.0755
INFO - 2016-05-22 10:25:01 --> Config Class Initialized
INFO - 2016-05-22 10:25:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:25:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:25:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:25:01 --> URI Class Initialized
INFO - 2016-05-22 10:25:01 --> Router Class Initialized
INFO - 2016-05-22 10:25:01 --> Output Class Initialized
INFO - 2016-05-22 10:25:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:25:01 --> Input Class Initialized
INFO - 2016-05-22 10:25:01 --> Language Class Initialized
INFO - 2016-05-22 10:25:01 --> Loader Class Initialized
INFO - 2016-05-22 10:25:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:25:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:25:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:25:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:25:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:25:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:25:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:25:01 --> Controller Class Initialized
INFO - 2016-05-22 10:25:01 --> Model Class Initialized
INFO - 2016-05-22 10:25:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:25:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:25:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:25:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:25:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:25:01 --> Total execution time: 0.0759
INFO - 2016-05-22 10:26:01 --> Config Class Initialized
INFO - 2016-05-22 10:26:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:26:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:26:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:26:01 --> URI Class Initialized
INFO - 2016-05-22 10:26:01 --> Router Class Initialized
INFO - 2016-05-22 10:26:01 --> Output Class Initialized
INFO - 2016-05-22 10:26:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:26:01 --> Input Class Initialized
INFO - 2016-05-22 10:26:01 --> Language Class Initialized
INFO - 2016-05-22 10:26:01 --> Loader Class Initialized
INFO - 2016-05-22 10:26:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:26:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:26:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:26:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:26:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:26:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:26:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:26:01 --> Controller Class Initialized
INFO - 2016-05-22 10:26:01 --> Model Class Initialized
INFO - 2016-05-22 10:26:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:26:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:26:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:26:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:26:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:26:01 --> Total execution time: 0.0751
INFO - 2016-05-22 10:27:01 --> Config Class Initialized
INFO - 2016-05-22 10:27:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:27:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:27:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:27:01 --> URI Class Initialized
INFO - 2016-05-22 10:27:01 --> Router Class Initialized
INFO - 2016-05-22 10:27:01 --> Output Class Initialized
INFO - 2016-05-22 10:27:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:27:01 --> Input Class Initialized
INFO - 2016-05-22 10:27:01 --> Language Class Initialized
INFO - 2016-05-22 10:27:01 --> Loader Class Initialized
INFO - 2016-05-22 10:27:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:27:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:27:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:27:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:27:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:27:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:27:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:27:01 --> Controller Class Initialized
INFO - 2016-05-22 10:27:01 --> Model Class Initialized
INFO - 2016-05-22 10:27:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:27:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:27:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:27:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:27:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:27:01 --> Total execution time: 0.0820
INFO - 2016-05-22 10:28:06 --> Config Class Initialized
INFO - 2016-05-22 10:28:06 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:28:07 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:28:07 --> Utf8 Class Initialized
INFO - 2016-05-22 10:28:07 --> URI Class Initialized
INFO - 2016-05-22 10:28:08 --> Router Class Initialized
INFO - 2016-05-22 10:28:08 --> Output Class Initialized
INFO - 2016-05-22 10:28:09 --> Security Class Initialized
DEBUG - 2016-05-22 10:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:28:10 --> Input Class Initialized
INFO - 2016-05-22 10:28:10 --> Language Class Initialized
INFO - 2016-05-22 10:28:10 --> Loader Class Initialized
INFO - 2016-05-22 10:28:10 --> Helper loaded: url_helper
INFO - 2016-05-22 10:28:10 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:28:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:28:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:28:11 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:28:12 --> Helper loaded: form_helper
INFO - 2016-05-22 10:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:28:12 --> Form Validation Class Initialized
INFO - 2016-05-22 10:28:12 --> Controller Class Initialized
INFO - 2016-05-22 10:28:12 --> Model Class Initialized
INFO - 2016-05-22 10:28:12 --> Database Driver Class Initialized
INFO - 2016-05-22 10:28:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:28:12 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:28:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:28:12 --> Final output sent to browser
DEBUG - 2016-05-22 10:28:12 --> Total execution time: 6.8555
INFO - 2016-05-22 10:29:01 --> Config Class Initialized
INFO - 2016-05-22 10:29:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:29:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:29:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:29:01 --> URI Class Initialized
INFO - 2016-05-22 10:29:01 --> Router Class Initialized
INFO - 2016-05-22 10:29:01 --> Output Class Initialized
INFO - 2016-05-22 10:29:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:29:01 --> Input Class Initialized
INFO - 2016-05-22 10:29:01 --> Language Class Initialized
INFO - 2016-05-22 10:29:01 --> Loader Class Initialized
INFO - 2016-05-22 10:29:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:29:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:29:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:29:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:29:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:29:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:29:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:29:01 --> Controller Class Initialized
INFO - 2016-05-22 10:29:01 --> Model Class Initialized
INFO - 2016-05-22 10:29:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:29:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:29:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:29:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:29:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:29:01 --> Total execution time: 0.2025
INFO - 2016-05-22 10:30:01 --> Config Class Initialized
INFO - 2016-05-22 10:30:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:30:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:30:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:30:01 --> URI Class Initialized
INFO - 2016-05-22 10:30:01 --> Router Class Initialized
INFO - 2016-05-22 10:30:01 --> Output Class Initialized
INFO - 2016-05-22 10:30:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:30:01 --> Input Class Initialized
INFO - 2016-05-22 10:30:01 --> Language Class Initialized
INFO - 2016-05-22 10:30:01 --> Loader Class Initialized
INFO - 2016-05-22 10:30:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:30:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:30:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:30:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:30:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:30:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:30:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:30:01 --> Controller Class Initialized
INFO - 2016-05-22 10:30:01 --> Model Class Initialized
INFO - 2016-05-22 10:30:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:30:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:30:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:30:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:30:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:30:01 --> Total execution time: 0.0720
INFO - 2016-05-22 10:31:01 --> Config Class Initialized
INFO - 2016-05-22 10:31:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:31:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:31:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:31:01 --> URI Class Initialized
INFO - 2016-05-22 10:31:01 --> Router Class Initialized
INFO - 2016-05-22 10:31:01 --> Output Class Initialized
INFO - 2016-05-22 10:31:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:31:01 --> Input Class Initialized
INFO - 2016-05-22 10:31:01 --> Language Class Initialized
INFO - 2016-05-22 10:31:01 --> Loader Class Initialized
INFO - 2016-05-22 10:31:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:31:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:31:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:31:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:31:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:31:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:31:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:31:01 --> Controller Class Initialized
INFO - 2016-05-22 10:31:01 --> Model Class Initialized
INFO - 2016-05-22 10:31:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:31:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:31:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:31:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:31:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:31:01 --> Total execution time: 0.0763
INFO - 2016-05-22 10:32:01 --> Config Class Initialized
INFO - 2016-05-22 10:32:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:32:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:32:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:32:01 --> URI Class Initialized
INFO - 2016-05-22 10:32:01 --> Router Class Initialized
INFO - 2016-05-22 10:32:01 --> Output Class Initialized
INFO - 2016-05-22 10:32:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:32:01 --> Input Class Initialized
INFO - 2016-05-22 10:32:01 --> Language Class Initialized
INFO - 2016-05-22 10:32:01 --> Loader Class Initialized
INFO - 2016-05-22 10:32:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:32:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:32:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:32:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:32:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:32:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:32:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:32:01 --> Controller Class Initialized
INFO - 2016-05-22 10:32:01 --> Model Class Initialized
INFO - 2016-05-22 10:32:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:32:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:32:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:32:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:32:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:32:01 --> Total execution time: 0.0714
INFO - 2016-05-22 10:33:01 --> Config Class Initialized
INFO - 2016-05-22 10:33:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:33:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:33:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:33:01 --> URI Class Initialized
INFO - 2016-05-22 10:33:01 --> Router Class Initialized
INFO - 2016-05-22 10:33:01 --> Output Class Initialized
INFO - 2016-05-22 10:33:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:33:01 --> Input Class Initialized
INFO - 2016-05-22 10:33:01 --> Language Class Initialized
INFO - 2016-05-22 10:33:01 --> Loader Class Initialized
INFO - 2016-05-22 10:33:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:33:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:33:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:33:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:33:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:33:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:33:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:33:01 --> Controller Class Initialized
INFO - 2016-05-22 10:33:01 --> Model Class Initialized
INFO - 2016-05-22 10:33:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:33:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:33:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:33:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:33:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:33:01 --> Total execution time: 0.0726
INFO - 2016-05-22 10:34:01 --> Config Class Initialized
INFO - 2016-05-22 10:34:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:34:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:34:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:34:01 --> URI Class Initialized
INFO - 2016-05-22 10:34:01 --> Router Class Initialized
INFO - 2016-05-22 10:34:01 --> Output Class Initialized
INFO - 2016-05-22 10:34:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:34:01 --> Input Class Initialized
INFO - 2016-05-22 10:34:01 --> Language Class Initialized
INFO - 2016-05-22 10:34:01 --> Loader Class Initialized
INFO - 2016-05-22 10:34:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:34:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:34:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:34:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:34:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:34:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:34:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:34:01 --> Controller Class Initialized
INFO - 2016-05-22 10:34:01 --> Model Class Initialized
INFO - 2016-05-22 10:34:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:34:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:34:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:34:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:34:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:34:01 --> Total execution time: 0.1164
INFO - 2016-05-22 10:35:01 --> Config Class Initialized
INFO - 2016-05-22 10:35:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:35:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:35:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:35:01 --> URI Class Initialized
INFO - 2016-05-22 10:35:01 --> Router Class Initialized
INFO - 2016-05-22 10:35:01 --> Output Class Initialized
INFO - 2016-05-22 10:35:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:35:01 --> Input Class Initialized
INFO - 2016-05-22 10:35:01 --> Language Class Initialized
INFO - 2016-05-22 10:35:01 --> Loader Class Initialized
INFO - 2016-05-22 10:35:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:35:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:35:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:35:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:35:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:35:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:35:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:35:01 --> Controller Class Initialized
INFO - 2016-05-22 10:35:01 --> Model Class Initialized
INFO - 2016-05-22 10:35:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:35:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:35:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:35:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:35:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:35:01 --> Total execution time: 0.0804
INFO - 2016-05-22 10:36:01 --> Config Class Initialized
INFO - 2016-05-22 10:36:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:36:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:36:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:36:01 --> URI Class Initialized
INFO - 2016-05-22 10:36:01 --> Router Class Initialized
INFO - 2016-05-22 10:36:01 --> Output Class Initialized
INFO - 2016-05-22 10:36:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:36:01 --> Input Class Initialized
INFO - 2016-05-22 10:36:01 --> Language Class Initialized
INFO - 2016-05-22 10:36:01 --> Loader Class Initialized
INFO - 2016-05-22 10:36:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:36:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:36:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:36:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:36:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:36:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:36:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:36:01 --> Controller Class Initialized
INFO - 2016-05-22 10:36:01 --> Model Class Initialized
INFO - 2016-05-22 10:36:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:36:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:36:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:36:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:36:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:36:01 --> Total execution time: 0.0783
INFO - 2016-05-22 10:37:01 --> Config Class Initialized
INFO - 2016-05-22 10:37:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:37:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:37:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:37:01 --> URI Class Initialized
INFO - 2016-05-22 10:37:01 --> Router Class Initialized
INFO - 2016-05-22 10:37:01 --> Output Class Initialized
INFO - 2016-05-22 10:37:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:37:01 --> Input Class Initialized
INFO - 2016-05-22 10:37:01 --> Language Class Initialized
INFO - 2016-05-22 10:37:01 --> Loader Class Initialized
INFO - 2016-05-22 10:37:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:37:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:37:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:37:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:37:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:37:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:37:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:37:01 --> Controller Class Initialized
INFO - 2016-05-22 10:37:01 --> Model Class Initialized
INFO - 2016-05-22 10:37:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:37:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:37:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:37:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:37:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:37:01 --> Total execution time: 0.0776
INFO - 2016-05-22 10:38:01 --> Config Class Initialized
INFO - 2016-05-22 10:38:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:38:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:38:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:38:01 --> URI Class Initialized
INFO - 2016-05-22 10:38:01 --> Router Class Initialized
INFO - 2016-05-22 10:38:01 --> Output Class Initialized
INFO - 2016-05-22 10:38:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:38:01 --> Input Class Initialized
INFO - 2016-05-22 10:38:01 --> Language Class Initialized
INFO - 2016-05-22 10:38:01 --> Loader Class Initialized
INFO - 2016-05-22 10:38:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:38:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:38:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:38:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:38:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:38:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:38:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:38:01 --> Controller Class Initialized
INFO - 2016-05-22 10:38:01 --> Model Class Initialized
INFO - 2016-05-22 10:38:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:38:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:38:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:38:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:38:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:38:01 --> Total execution time: 0.0833
INFO - 2016-05-22 10:39:01 --> Config Class Initialized
INFO - 2016-05-22 10:39:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:39:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:39:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:39:01 --> URI Class Initialized
INFO - 2016-05-22 10:39:01 --> Router Class Initialized
INFO - 2016-05-22 10:39:01 --> Output Class Initialized
INFO - 2016-05-22 10:39:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:39:01 --> Input Class Initialized
INFO - 2016-05-22 10:39:01 --> Language Class Initialized
INFO - 2016-05-22 10:39:01 --> Loader Class Initialized
INFO - 2016-05-22 10:39:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:39:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:39:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:39:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:39:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:39:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:39:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:39:01 --> Controller Class Initialized
INFO - 2016-05-22 10:39:01 --> Model Class Initialized
INFO - 2016-05-22 10:39:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:39:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:39:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:39:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:39:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:39:01 --> Total execution time: 0.0723
INFO - 2016-05-22 10:40:01 --> Config Class Initialized
INFO - 2016-05-22 10:40:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:40:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:40:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:40:01 --> URI Class Initialized
INFO - 2016-05-22 10:40:01 --> Router Class Initialized
INFO - 2016-05-22 10:40:01 --> Output Class Initialized
INFO - 2016-05-22 10:40:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:40:01 --> Input Class Initialized
INFO - 2016-05-22 10:40:01 --> Language Class Initialized
INFO - 2016-05-22 10:40:01 --> Loader Class Initialized
INFO - 2016-05-22 10:40:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:40:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:40:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:40:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:40:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:40:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:40:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:40:01 --> Controller Class Initialized
INFO - 2016-05-22 10:40:01 --> Model Class Initialized
INFO - 2016-05-22 10:40:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:40:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:40:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:40:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:40:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:40:01 --> Total execution time: 0.0733
INFO - 2016-05-22 10:41:07 --> Config Class Initialized
INFO - 2016-05-22 10:41:07 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:41:07 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:41:07 --> Utf8 Class Initialized
INFO - 2016-05-22 10:41:07 --> URI Class Initialized
INFO - 2016-05-22 10:41:07 --> Router Class Initialized
INFO - 2016-05-22 10:41:07 --> Output Class Initialized
INFO - 2016-05-22 10:41:07 --> Security Class Initialized
DEBUG - 2016-05-22 10:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:41:07 --> Input Class Initialized
INFO - 2016-05-22 10:41:07 --> Language Class Initialized
INFO - 2016-05-22 10:41:07 --> Loader Class Initialized
INFO - 2016-05-22 10:41:07 --> Helper loaded: url_helper
INFO - 2016-05-22 10:41:07 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:41:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:41:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:41:07 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:41:07 --> Helper loaded: form_helper
INFO - 2016-05-22 10:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:41:07 --> Form Validation Class Initialized
INFO - 2016-05-22 10:41:07 --> Controller Class Initialized
INFO - 2016-05-22 10:41:07 --> Model Class Initialized
INFO - 2016-05-22 10:41:07 --> Database Driver Class Initialized
INFO - 2016-05-22 10:41:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:41:07 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:41:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:41:07 --> Final output sent to browser
DEBUG - 2016-05-22 10:41:07 --> Total execution time: 0.9493
INFO - 2016-05-22 10:42:01 --> Config Class Initialized
INFO - 2016-05-22 10:42:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:42:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:42:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:42:01 --> URI Class Initialized
INFO - 2016-05-22 10:42:01 --> Router Class Initialized
INFO - 2016-05-22 10:42:01 --> Output Class Initialized
INFO - 2016-05-22 10:42:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:42:01 --> Input Class Initialized
INFO - 2016-05-22 10:42:01 --> Language Class Initialized
INFO - 2016-05-22 10:42:01 --> Loader Class Initialized
INFO - 2016-05-22 10:42:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:42:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:42:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:42:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:42:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:42:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:42:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:42:01 --> Controller Class Initialized
INFO - 2016-05-22 10:42:01 --> Model Class Initialized
INFO - 2016-05-22 10:42:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:42:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:42:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:42:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:42:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:42:01 --> Total execution time: 0.0779
INFO - 2016-05-22 10:43:01 --> Config Class Initialized
INFO - 2016-05-22 10:43:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:43:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:43:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:43:01 --> URI Class Initialized
INFO - 2016-05-22 10:43:01 --> Router Class Initialized
INFO - 2016-05-22 10:43:01 --> Output Class Initialized
INFO - 2016-05-22 10:43:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:43:01 --> Input Class Initialized
INFO - 2016-05-22 10:43:01 --> Language Class Initialized
INFO - 2016-05-22 10:43:01 --> Loader Class Initialized
INFO - 2016-05-22 10:43:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:43:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:43:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:43:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:43:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:43:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:43:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:43:01 --> Controller Class Initialized
INFO - 2016-05-22 10:43:01 --> Model Class Initialized
INFO - 2016-05-22 10:43:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:43:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:43:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:43:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:43:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:43:01 --> Total execution time: 0.0707
INFO - 2016-05-22 10:44:01 --> Config Class Initialized
INFO - 2016-05-22 10:44:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:44:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:44:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:44:01 --> URI Class Initialized
INFO - 2016-05-22 10:44:01 --> Router Class Initialized
INFO - 2016-05-22 10:44:01 --> Output Class Initialized
INFO - 2016-05-22 10:44:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:44:01 --> Input Class Initialized
INFO - 2016-05-22 10:44:01 --> Language Class Initialized
INFO - 2016-05-22 10:44:01 --> Loader Class Initialized
INFO - 2016-05-22 10:44:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:44:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:44:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:44:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:44:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:44:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:44:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:44:01 --> Controller Class Initialized
INFO - 2016-05-22 10:44:01 --> Model Class Initialized
INFO - 2016-05-22 10:44:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:44:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:44:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:44:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:44:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:44:01 --> Total execution time: 0.0778
INFO - 2016-05-22 10:45:01 --> Config Class Initialized
INFO - 2016-05-22 10:45:01 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:45:01 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:45:01 --> Utf8 Class Initialized
INFO - 2016-05-22 10:45:01 --> URI Class Initialized
INFO - 2016-05-22 10:45:01 --> Router Class Initialized
INFO - 2016-05-22 10:45:01 --> Output Class Initialized
INFO - 2016-05-22 10:45:01 --> Security Class Initialized
DEBUG - 2016-05-22 10:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:45:01 --> Input Class Initialized
INFO - 2016-05-22 10:45:01 --> Language Class Initialized
INFO - 2016-05-22 10:45:01 --> Loader Class Initialized
INFO - 2016-05-22 10:45:01 --> Helper loaded: url_helper
INFO - 2016-05-22 10:45:01 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:45:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:45:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:45:01 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:45:01 --> Helper loaded: form_helper
INFO - 2016-05-22 10:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:45:01 --> Form Validation Class Initialized
INFO - 2016-05-22 10:45:01 --> Controller Class Initialized
INFO - 2016-05-22 10:45:01 --> Model Class Initialized
INFO - 2016-05-22 10:45:01 --> Database Driver Class Initialized
INFO - 2016-05-22 10:45:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:45:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:45:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:45:01 --> Final output sent to browser
DEBUG - 2016-05-22 10:45:01 --> Total execution time: 0.0822
INFO - 2016-05-22 10:45:37 --> Config Class Initialized
INFO - 2016-05-22 10:45:37 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:45:37 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:45:37 --> Utf8 Class Initialized
INFO - 2016-05-22 10:45:37 --> URI Class Initialized
INFO - 2016-05-22 10:45:37 --> Router Class Initialized
INFO - 2016-05-22 10:45:37 --> Output Class Initialized
INFO - 2016-05-22 10:45:37 --> Security Class Initialized
DEBUG - 2016-05-22 10:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:45:37 --> Input Class Initialized
INFO - 2016-05-22 10:45:37 --> Language Class Initialized
INFO - 2016-05-22 10:45:37 --> Loader Class Initialized
INFO - 2016-05-22 10:45:37 --> Helper loaded: url_helper
INFO - 2016-05-22 10:45:37 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:45:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:45:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:45:37 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:45:37 --> Helper loaded: form_helper
INFO - 2016-05-22 10:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:45:37 --> Form Validation Class Initialized
INFO - 2016-05-22 10:45:37 --> Controller Class Initialized
INFO - 2016-05-22 10:45:37 --> Model Class Initialized
INFO - 2016-05-22 10:45:37 --> Database Driver Class Initialized
INFO - 2016-05-22 10:45:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:45:38 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:45:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:45:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 10:45:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 10:45:38 --> Final output sent to browser
DEBUG - 2016-05-22 10:45:38 --> Total execution time: 0.1831
INFO - 2016-05-22 10:45:38 --> Config Class Initialized
INFO - 2016-05-22 10:45:38 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:45:38 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:45:38 --> Utf8 Class Initialized
INFO - 2016-05-22 10:45:38 --> URI Class Initialized
INFO - 2016-05-22 10:45:38 --> Router Class Initialized
INFO - 2016-05-22 10:45:38 --> Output Class Initialized
INFO - 2016-05-22 10:45:38 --> Security Class Initialized
DEBUG - 2016-05-22 10:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:45:38 --> Input Class Initialized
INFO - 2016-05-22 10:45:38 --> Language Class Initialized
INFO - 2016-05-22 10:45:38 --> Loader Class Initialized
INFO - 2016-05-22 10:45:38 --> Helper loaded: url_helper
INFO - 2016-05-22 10:45:38 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:45:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:45:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:45:38 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:45:38 --> Helper loaded: form_helper
INFO - 2016-05-22 10:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:45:38 --> Form Validation Class Initialized
INFO - 2016-05-22 10:45:38 --> Controller Class Initialized
INFO - 2016-05-22 10:45:38 --> Model Class Initialized
INFO - 2016-05-22 10:45:38 --> Database Driver Class Initialized
INFO - 2016-05-22 10:45:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:45:38 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:45:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:45:38 --> Final output sent to browser
DEBUG - 2016-05-22 10:45:38 --> Total execution time: 0.0834
INFO - 2016-05-22 10:46:39 --> Config Class Initialized
INFO - 2016-05-22 10:46:39 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:46:39 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:46:39 --> Utf8 Class Initialized
INFO - 2016-05-22 10:46:39 --> URI Class Initialized
INFO - 2016-05-22 10:46:39 --> Router Class Initialized
INFO - 2016-05-22 10:46:39 --> Output Class Initialized
INFO - 2016-05-22 10:46:39 --> Security Class Initialized
DEBUG - 2016-05-22 10:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:46:39 --> Input Class Initialized
INFO - 2016-05-22 10:46:39 --> Language Class Initialized
INFO - 2016-05-22 10:46:39 --> Loader Class Initialized
INFO - 2016-05-22 10:46:39 --> Helper loaded: url_helper
INFO - 2016-05-22 10:46:39 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:46:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:46:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:46:39 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:46:39 --> Helper loaded: form_helper
INFO - 2016-05-22 10:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:46:39 --> Form Validation Class Initialized
INFO - 2016-05-22 10:46:39 --> Controller Class Initialized
INFO - 2016-05-22 10:46:39 --> Model Class Initialized
INFO - 2016-05-22 10:46:39 --> Database Driver Class Initialized
INFO - 2016-05-22 10:46:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 10:46:39 --> Pagination Class Initialized
DEBUG - 2016-05-22 10:46:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 10:46:39 --> Final output sent to browser
DEBUG - 2016-05-22 10:46:39 --> Total execution time: 0.0737
INFO - 2016-05-22 10:47:13 --> Config Class Initialized
INFO - 2016-05-22 10:47:13 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:47:13 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:47:13 --> Utf8 Class Initialized
INFO - 2016-05-22 10:47:13 --> URI Class Initialized
INFO - 2016-05-22 10:47:13 --> Router Class Initialized
INFO - 2016-05-22 10:47:13 --> Output Class Initialized
INFO - 2016-05-22 10:47:13 --> Security Class Initialized
DEBUG - 2016-05-22 10:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:47:13 --> Input Class Initialized
INFO - 2016-05-22 10:47:13 --> Language Class Initialized
INFO - 2016-05-22 10:47:13 --> Loader Class Initialized
INFO - 2016-05-22 10:47:13 --> Helper loaded: url_helper
INFO - 2016-05-22 10:47:13 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:47:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:47:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:47:13 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:47:13 --> Helper loaded: form_helper
INFO - 2016-05-22 10:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:47:13 --> Form Validation Class Initialized
INFO - 2016-05-22 10:47:13 --> Controller Class Initialized
INFO - 2016-05-22 10:47:13 --> Model Class Initialized
INFO - 2016-05-22 10:47:13 --> Database Driver Class Initialized
INFO - 2016-05-22 10:47:13 --> Final output sent to browser
DEBUG - 2016-05-22 10:47:13 --> Total execution time: 0.2891
INFO - 2016-05-22 10:47:13 --> Config Class Initialized
INFO - 2016-05-22 10:47:13 --> Hooks Class Initialized
DEBUG - 2016-05-22 10:47:13 --> UTF-8 Support Enabled
INFO - 2016-05-22 10:47:13 --> Utf8 Class Initialized
INFO - 2016-05-22 10:47:13 --> URI Class Initialized
INFO - 2016-05-22 10:47:13 --> Router Class Initialized
INFO - 2016-05-22 10:47:13 --> Output Class Initialized
INFO - 2016-05-22 10:47:13 --> Security Class Initialized
DEBUG - 2016-05-22 10:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 10:47:13 --> Input Class Initialized
INFO - 2016-05-22 10:47:13 --> Language Class Initialized
INFO - 2016-05-22 10:47:13 --> Loader Class Initialized
INFO - 2016-05-22 10:47:13 --> Helper loaded: url_helper
INFO - 2016-05-22 10:47:13 --> Helper loaded: sesion_helper
INFO - 2016-05-22 10:47:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 10:47:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 10:47:13 --> Helper loaded: redondear_helper
INFO - 2016-05-22 10:47:13 --> Helper loaded: form_helper
INFO - 2016-05-22 10:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 10:47:13 --> Form Validation Class Initialized
INFO - 2016-05-22 10:47:13 --> Controller Class Initialized
INFO - 2016-05-22 10:47:13 --> Model Class Initialized
INFO - 2016-05-22 10:47:13 --> Database Driver Class Initialized
INFO - 2016-05-22 10:47:13 --> Final output sent to browser
DEBUG - 2016-05-22 10:47:13 --> Total execution time: 0.1456
INFO - 2016-05-22 11:10:04 --> Config Class Initialized
INFO - 2016-05-22 11:10:04 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:04 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:04 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:04 --> URI Class Initialized
INFO - 2016-05-22 11:10:04 --> Router Class Initialized
INFO - 2016-05-22 11:10:05 --> Output Class Initialized
INFO - 2016-05-22 11:10:05 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:05 --> Input Class Initialized
INFO - 2016-05-22 11:10:05 --> Language Class Initialized
INFO - 2016-05-22 11:10:05 --> Loader Class Initialized
INFO - 2016-05-22 11:10:05 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:05 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:05 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:05 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:05 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:05 --> Controller Class Initialized
INFO - 2016-05-22 11:10:05 --> Model Class Initialized
INFO - 2016-05-22 11:10:05 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:05 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:10:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:10:05 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:05 --> Total execution time: 0.3791
INFO - 2016-05-22 11:10:05 --> Config Class Initialized
INFO - 2016-05-22 11:10:05 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:05 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:05 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:05 --> URI Class Initialized
INFO - 2016-05-22 11:10:05 --> Router Class Initialized
INFO - 2016-05-22 11:10:05 --> Output Class Initialized
INFO - 2016-05-22 11:10:05 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:05 --> Input Class Initialized
INFO - 2016-05-22 11:10:05 --> Language Class Initialized
INFO - 2016-05-22 11:10:05 --> Loader Class Initialized
INFO - 2016-05-22 11:10:05 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:05 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:05 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:05 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:05 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:05 --> Controller Class Initialized
INFO - 2016-05-22 11:10:05 --> Model Class Initialized
INFO - 2016-05-22 11:10:05 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:05 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:05 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:05 --> Total execution time: 0.1159
INFO - 2016-05-22 11:10:08 --> Config Class Initialized
INFO - 2016-05-22 11:10:08 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:08 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:08 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:08 --> URI Class Initialized
INFO - 2016-05-22 11:10:08 --> Router Class Initialized
INFO - 2016-05-22 11:10:08 --> Output Class Initialized
INFO - 2016-05-22 11:10:08 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:08 --> Input Class Initialized
INFO - 2016-05-22 11:10:08 --> Language Class Initialized
INFO - 2016-05-22 11:10:08 --> Loader Class Initialized
INFO - 2016-05-22 11:10:08 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:08 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:08 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:08 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:08 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:08 --> Controller Class Initialized
INFO - 2016-05-22 11:10:08 --> Model Class Initialized
INFO - 2016-05-22 11:10:08 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:08 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:10:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:10:08 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:08 --> Total execution time: 0.0819
INFO - 2016-05-22 11:10:09 --> Config Class Initialized
INFO - 2016-05-22 11:10:09 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:09 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:09 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:09 --> URI Class Initialized
INFO - 2016-05-22 11:10:09 --> Router Class Initialized
INFO - 2016-05-22 11:10:09 --> Output Class Initialized
INFO - 2016-05-22 11:10:09 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:09 --> Input Class Initialized
INFO - 2016-05-22 11:10:09 --> Language Class Initialized
INFO - 2016-05-22 11:10:09 --> Loader Class Initialized
INFO - 2016-05-22 11:10:09 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:09 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:09 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:09 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:09 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:09 --> Controller Class Initialized
INFO - 2016-05-22 11:10:09 --> Model Class Initialized
INFO - 2016-05-22 11:10:09 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:09 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:09 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:09 --> Total execution time: 0.0888
INFO - 2016-05-22 11:10:26 --> Config Class Initialized
INFO - 2016-05-22 11:10:26 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:26 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:26 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:26 --> URI Class Initialized
INFO - 2016-05-22 11:10:26 --> Router Class Initialized
INFO - 2016-05-22 11:10:26 --> Output Class Initialized
INFO - 2016-05-22 11:10:26 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:26 --> Input Class Initialized
INFO - 2016-05-22 11:10:26 --> Language Class Initialized
INFO - 2016-05-22 11:10:26 --> Loader Class Initialized
INFO - 2016-05-22 11:10:26 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:26 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:26 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:26 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:26 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:26 --> Controller Class Initialized
INFO - 2016-05-22 11:10:26 --> Model Class Initialized
INFO - 2016-05-22 11:10:26 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:26 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:26 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 11:10:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:10:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:10:26 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:26 --> Total execution time: 0.2215
INFO - 2016-05-22 11:10:26 --> Config Class Initialized
INFO - 2016-05-22 11:10:26 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:26 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:26 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:26 --> URI Class Initialized
INFO - 2016-05-22 11:10:26 --> Router Class Initialized
INFO - 2016-05-22 11:10:26 --> Output Class Initialized
INFO - 2016-05-22 11:10:26 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:26 --> Input Class Initialized
INFO - 2016-05-22 11:10:26 --> Language Class Initialized
INFO - 2016-05-22 11:10:26 --> Loader Class Initialized
INFO - 2016-05-22 11:10:26 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:26 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:26 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:26 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:26 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:26 --> Controller Class Initialized
INFO - 2016-05-22 11:10:26 --> Model Class Initialized
INFO - 2016-05-22 11:10:26 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:26 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:26 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:26 --> Total execution time: 0.0957
INFO - 2016-05-22 11:10:29 --> Config Class Initialized
INFO - 2016-05-22 11:10:29 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:29 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:29 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:29 --> URI Class Initialized
INFO - 2016-05-22 11:10:29 --> Router Class Initialized
INFO - 2016-05-22 11:10:29 --> Output Class Initialized
INFO - 2016-05-22 11:10:29 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:29 --> Input Class Initialized
INFO - 2016-05-22 11:10:29 --> Language Class Initialized
INFO - 2016-05-22 11:10:29 --> Loader Class Initialized
INFO - 2016-05-22 11:10:29 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:29 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:29 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:29 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:29 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:29 --> Controller Class Initialized
INFO - 2016-05-22 11:10:29 --> Model Class Initialized
INFO - 2016-05-22 11:10:29 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:29 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:10:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:10:29 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:29 --> Total execution time: 0.0837
INFO - 2016-05-22 11:10:29 --> Config Class Initialized
INFO - 2016-05-22 11:10:29 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:29 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:29 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:29 --> URI Class Initialized
INFO - 2016-05-22 11:10:29 --> Router Class Initialized
INFO - 2016-05-22 11:10:29 --> Output Class Initialized
INFO - 2016-05-22 11:10:29 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:29 --> Input Class Initialized
INFO - 2016-05-22 11:10:29 --> Language Class Initialized
INFO - 2016-05-22 11:10:29 --> Loader Class Initialized
INFO - 2016-05-22 11:10:29 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:29 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:29 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:29 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:29 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:29 --> Controller Class Initialized
INFO - 2016-05-22 11:10:29 --> Model Class Initialized
INFO - 2016-05-22 11:10:29 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:29 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:29 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:29 --> Total execution time: 0.0845
INFO - 2016-05-22 11:10:32 --> Config Class Initialized
INFO - 2016-05-22 11:10:32 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:32 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:32 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:32 --> URI Class Initialized
INFO - 2016-05-22 11:10:32 --> Router Class Initialized
INFO - 2016-05-22 11:10:32 --> Output Class Initialized
INFO - 2016-05-22 11:10:32 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:32 --> Input Class Initialized
INFO - 2016-05-22 11:10:32 --> Language Class Initialized
INFO - 2016-05-22 11:10:32 --> Loader Class Initialized
INFO - 2016-05-22 11:10:32 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:32 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:32 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:32 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:32 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:32 --> Controller Class Initialized
INFO - 2016-05-22 11:10:32 --> Model Class Initialized
INFO - 2016-05-22 11:10:32 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:32 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:10:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:10:32 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:32 --> Total execution time: 0.0807
INFO - 2016-05-22 11:10:32 --> Config Class Initialized
INFO - 2016-05-22 11:10:32 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:32 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:32 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:32 --> URI Class Initialized
INFO - 2016-05-22 11:10:32 --> Router Class Initialized
INFO - 2016-05-22 11:10:32 --> Output Class Initialized
INFO - 2016-05-22 11:10:32 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:32 --> Input Class Initialized
INFO - 2016-05-22 11:10:32 --> Language Class Initialized
INFO - 2016-05-22 11:10:32 --> Loader Class Initialized
INFO - 2016-05-22 11:10:32 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:32 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:32 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:32 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:32 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:32 --> Controller Class Initialized
INFO - 2016-05-22 11:10:32 --> Model Class Initialized
INFO - 2016-05-22 11:10:32 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:32 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:32 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:32 --> Total execution time: 0.1229
INFO - 2016-05-22 11:10:36 --> Config Class Initialized
INFO - 2016-05-22 11:10:36 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:36 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:36 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:36 --> URI Class Initialized
INFO - 2016-05-22 11:10:36 --> Router Class Initialized
INFO - 2016-05-22 11:10:36 --> Output Class Initialized
INFO - 2016-05-22 11:10:36 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:36 --> Input Class Initialized
INFO - 2016-05-22 11:10:36 --> Language Class Initialized
INFO - 2016-05-22 11:10:36 --> Loader Class Initialized
INFO - 2016-05-22 11:10:36 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:36 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:36 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:36 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:36 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:36 --> Controller Class Initialized
INFO - 2016-05-22 11:10:36 --> Model Class Initialized
INFO - 2016-05-22 11:10:36 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:36 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:36 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 11:10:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:10:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:10:36 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:36 --> Total execution time: 0.1624
INFO - 2016-05-22 11:10:36 --> Config Class Initialized
INFO - 2016-05-22 11:10:36 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:36 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:36 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:36 --> URI Class Initialized
INFO - 2016-05-22 11:10:36 --> Router Class Initialized
INFO - 2016-05-22 11:10:36 --> Output Class Initialized
INFO - 2016-05-22 11:10:36 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:36 --> Input Class Initialized
INFO - 2016-05-22 11:10:36 --> Language Class Initialized
INFO - 2016-05-22 11:10:36 --> Loader Class Initialized
INFO - 2016-05-22 11:10:36 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:36 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:36 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:36 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:37 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:37 --> Controller Class Initialized
INFO - 2016-05-22 11:10:37 --> Model Class Initialized
INFO - 2016-05-22 11:10:37 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:37 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:37 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:37 --> Total execution time: 0.1173
INFO - 2016-05-22 11:10:38 --> Config Class Initialized
INFO - 2016-05-22 11:10:38 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:38 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:38 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:38 --> URI Class Initialized
INFO - 2016-05-22 11:10:38 --> Router Class Initialized
INFO - 2016-05-22 11:10:38 --> Output Class Initialized
INFO - 2016-05-22 11:10:38 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:38 --> Input Class Initialized
INFO - 2016-05-22 11:10:38 --> Language Class Initialized
INFO - 2016-05-22 11:10:38 --> Loader Class Initialized
INFO - 2016-05-22 11:10:38 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:38 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:38 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:38 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:38 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:38 --> Controller Class Initialized
INFO - 2016-05-22 11:10:38 --> Model Class Initialized
INFO - 2016-05-22 11:10:38 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:38 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:38 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 11:10:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:10:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:10:38 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:38 --> Total execution time: 0.2677
INFO - 2016-05-22 11:10:38 --> Config Class Initialized
INFO - 2016-05-22 11:10:38 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:38 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:38 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:38 --> URI Class Initialized
INFO - 2016-05-22 11:10:38 --> Router Class Initialized
INFO - 2016-05-22 11:10:38 --> Output Class Initialized
INFO - 2016-05-22 11:10:38 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:38 --> Input Class Initialized
INFO - 2016-05-22 11:10:38 --> Language Class Initialized
INFO - 2016-05-22 11:10:38 --> Loader Class Initialized
INFO - 2016-05-22 11:10:38 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:38 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:38 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:38 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:38 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:38 --> Controller Class Initialized
INFO - 2016-05-22 11:10:38 --> Model Class Initialized
INFO - 2016-05-22 11:10:38 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:38 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:38 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:38 --> Total execution time: 0.1352
INFO - 2016-05-22 11:10:39 --> Config Class Initialized
INFO - 2016-05-22 11:10:39 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:39 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:39 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:39 --> URI Class Initialized
INFO - 2016-05-22 11:10:39 --> Router Class Initialized
INFO - 2016-05-22 11:10:39 --> Output Class Initialized
INFO - 2016-05-22 11:10:39 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:39 --> Input Class Initialized
INFO - 2016-05-22 11:10:39 --> Language Class Initialized
INFO - 2016-05-22 11:10:39 --> Loader Class Initialized
INFO - 2016-05-22 11:10:39 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:39 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:39 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:39 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:39 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:39 --> Controller Class Initialized
INFO - 2016-05-22 11:10:39 --> Model Class Initialized
INFO - 2016-05-22 11:10:39 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:39 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:10:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:10:39 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:39 --> Total execution time: 0.0806
INFO - 2016-05-22 11:10:39 --> Config Class Initialized
INFO - 2016-05-22 11:10:39 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:39 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:39 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:39 --> URI Class Initialized
INFO - 2016-05-22 11:10:39 --> Router Class Initialized
INFO - 2016-05-22 11:10:39 --> Output Class Initialized
INFO - 2016-05-22 11:10:39 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:39 --> Input Class Initialized
INFO - 2016-05-22 11:10:39 --> Language Class Initialized
INFO - 2016-05-22 11:10:39 --> Loader Class Initialized
INFO - 2016-05-22 11:10:39 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:39 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:39 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:39 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:39 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:39 --> Controller Class Initialized
INFO - 2016-05-22 11:10:39 --> Model Class Initialized
INFO - 2016-05-22 11:10:39 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:39 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:39 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:39 --> Total execution time: 0.0947
INFO - 2016-05-22 11:10:43 --> Config Class Initialized
INFO - 2016-05-22 11:10:43 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:43 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:43 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:43 --> URI Class Initialized
INFO - 2016-05-22 11:10:43 --> Router Class Initialized
INFO - 2016-05-22 11:10:43 --> Output Class Initialized
INFO - 2016-05-22 11:10:43 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:43 --> Input Class Initialized
INFO - 2016-05-22 11:10:43 --> Language Class Initialized
INFO - 2016-05-22 11:10:43 --> Loader Class Initialized
INFO - 2016-05-22 11:10:43 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:43 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:43 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:43 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:43 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:43 --> Controller Class Initialized
INFO - 2016-05-22 11:10:43 --> Model Class Initialized
INFO - 2016-05-22 11:10:43 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:43 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:10:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:10:43 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:43 --> Total execution time: 0.0791
INFO - 2016-05-22 11:10:43 --> Config Class Initialized
INFO - 2016-05-22 11:10:43 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:43 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:43 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:43 --> URI Class Initialized
INFO - 2016-05-22 11:10:43 --> Router Class Initialized
INFO - 2016-05-22 11:10:43 --> Output Class Initialized
INFO - 2016-05-22 11:10:43 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:43 --> Input Class Initialized
INFO - 2016-05-22 11:10:43 --> Language Class Initialized
INFO - 2016-05-22 11:10:43 --> Loader Class Initialized
INFO - 2016-05-22 11:10:43 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:43 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:43 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:43 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:43 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:43 --> Controller Class Initialized
INFO - 2016-05-22 11:10:43 --> Model Class Initialized
INFO - 2016-05-22 11:10:43 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:43 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:43 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:43 --> Total execution time: 0.1163
INFO - 2016-05-22 11:10:44 --> Config Class Initialized
INFO - 2016-05-22 11:10:44 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:44 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:44 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:44 --> URI Class Initialized
INFO - 2016-05-22 11:10:44 --> Router Class Initialized
INFO - 2016-05-22 11:10:44 --> Output Class Initialized
INFO - 2016-05-22 11:10:44 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:44 --> Input Class Initialized
INFO - 2016-05-22 11:10:44 --> Language Class Initialized
INFO - 2016-05-22 11:10:44 --> Loader Class Initialized
INFO - 2016-05-22 11:10:44 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:44 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:45 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:45 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:45 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:45 --> Controller Class Initialized
INFO - 2016-05-22 11:10:45 --> Model Class Initialized
INFO - 2016-05-22 11:10:45 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:45 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:10:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:10:45 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:45 --> Total execution time: 0.0868
INFO - 2016-05-22 11:10:45 --> Config Class Initialized
INFO - 2016-05-22 11:10:45 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:45 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:45 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:45 --> URI Class Initialized
INFO - 2016-05-22 11:10:45 --> Router Class Initialized
INFO - 2016-05-22 11:10:45 --> Output Class Initialized
INFO - 2016-05-22 11:10:45 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:45 --> Input Class Initialized
INFO - 2016-05-22 11:10:45 --> Language Class Initialized
INFO - 2016-05-22 11:10:45 --> Loader Class Initialized
INFO - 2016-05-22 11:10:45 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:45 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:45 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:45 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:45 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:45 --> Controller Class Initialized
INFO - 2016-05-22 11:10:45 --> Model Class Initialized
INFO - 2016-05-22 11:10:45 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:45 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:45 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:45 --> Total execution time: 0.0911
INFO - 2016-05-22 11:10:46 --> Config Class Initialized
INFO - 2016-05-22 11:10:46 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:46 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:46 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:46 --> URI Class Initialized
INFO - 2016-05-22 11:10:46 --> Router Class Initialized
INFO - 2016-05-22 11:10:46 --> Output Class Initialized
INFO - 2016-05-22 11:10:46 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:46 --> Input Class Initialized
INFO - 2016-05-22 11:10:46 --> Language Class Initialized
INFO - 2016-05-22 11:10:46 --> Loader Class Initialized
INFO - 2016-05-22 11:10:46 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:46 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:46 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:46 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:46 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:46 --> Controller Class Initialized
INFO - 2016-05-22 11:10:46 --> Model Class Initialized
INFO - 2016-05-22 11:10:46 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:46 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:10:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:10:46 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:46 --> Total execution time: 0.0954
INFO - 2016-05-22 11:10:46 --> Config Class Initialized
INFO - 2016-05-22 11:10:46 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:46 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:46 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:46 --> URI Class Initialized
INFO - 2016-05-22 11:10:46 --> Router Class Initialized
INFO - 2016-05-22 11:10:46 --> Output Class Initialized
INFO - 2016-05-22 11:10:46 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:46 --> Input Class Initialized
INFO - 2016-05-22 11:10:46 --> Language Class Initialized
INFO - 2016-05-22 11:10:46 --> Loader Class Initialized
INFO - 2016-05-22 11:10:46 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:46 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:46 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:46 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:47 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:47 --> Controller Class Initialized
INFO - 2016-05-22 11:10:47 --> Model Class Initialized
INFO - 2016-05-22 11:10:47 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:47 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:47 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:47 --> Total execution time: 0.1172
INFO - 2016-05-22 11:10:47 --> Config Class Initialized
INFO - 2016-05-22 11:10:47 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:47 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:47 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:47 --> URI Class Initialized
INFO - 2016-05-22 11:10:47 --> Router Class Initialized
INFO - 2016-05-22 11:10:47 --> Output Class Initialized
INFO - 2016-05-22 11:10:47 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:47 --> Input Class Initialized
INFO - 2016-05-22 11:10:47 --> Language Class Initialized
INFO - 2016-05-22 11:10:47 --> Loader Class Initialized
INFO - 2016-05-22 11:10:47 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:47 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:47 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:47 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:47 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:47 --> Controller Class Initialized
INFO - 2016-05-22 11:10:47 --> Model Class Initialized
INFO - 2016-05-22 11:10:47 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:47 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:10:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:10:47 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:47 --> Total execution time: 0.0839
INFO - 2016-05-22 11:10:47 --> Config Class Initialized
INFO - 2016-05-22 11:10:47 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:47 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:47 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:47 --> URI Class Initialized
INFO - 2016-05-22 11:10:47 --> Router Class Initialized
INFO - 2016-05-22 11:10:47 --> Output Class Initialized
INFO - 2016-05-22 11:10:47 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:47 --> Input Class Initialized
INFO - 2016-05-22 11:10:47 --> Language Class Initialized
INFO - 2016-05-22 11:10:47 --> Loader Class Initialized
INFO - 2016-05-22 11:10:47 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:47 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:47 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:47 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:48 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:48 --> Controller Class Initialized
INFO - 2016-05-22 11:10:48 --> Model Class Initialized
INFO - 2016-05-22 11:10:48 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:10:48 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:10:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:10:48 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:48 --> Total execution time: 0.1073
INFO - 2016-05-22 11:10:53 --> Config Class Initialized
INFO - 2016-05-22 11:10:53 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:10:53 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:10:53 --> Utf8 Class Initialized
INFO - 2016-05-22 11:10:53 --> URI Class Initialized
INFO - 2016-05-22 11:10:53 --> Router Class Initialized
INFO - 2016-05-22 11:10:53 --> Output Class Initialized
INFO - 2016-05-22 11:10:53 --> Security Class Initialized
DEBUG - 2016-05-22 11:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:10:53 --> Input Class Initialized
INFO - 2016-05-22 11:10:53 --> Language Class Initialized
INFO - 2016-05-22 11:10:53 --> Loader Class Initialized
INFO - 2016-05-22 11:10:53 --> Helper loaded: url_helper
INFO - 2016-05-22 11:10:53 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:10:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:10:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:10:53 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:10:53 --> Helper loaded: form_helper
INFO - 2016-05-22 11:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:10:53 --> Form Validation Class Initialized
INFO - 2016-05-22 11:10:53 --> Controller Class Initialized
INFO - 2016-05-22 11:10:53 --> Model Class Initialized
INFO - 2016-05-22 11:10:53 --> Database Driver Class Initialized
INFO - 2016-05-22 11:10:54 --> Final output sent to browser
DEBUG - 2016-05-22 11:10:54 --> Total execution time: 0.2230
INFO - 2016-05-22 11:11:00 --> Config Class Initialized
INFO - 2016-05-22 11:11:00 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:11:00 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:11:00 --> Utf8 Class Initialized
INFO - 2016-05-22 11:11:00 --> URI Class Initialized
INFO - 2016-05-22 11:11:00 --> Router Class Initialized
INFO - 2016-05-22 11:11:00 --> Output Class Initialized
INFO - 2016-05-22 11:11:00 --> Security Class Initialized
DEBUG - 2016-05-22 11:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:11:00 --> Input Class Initialized
INFO - 2016-05-22 11:11:00 --> Language Class Initialized
INFO - 2016-05-22 11:11:00 --> Loader Class Initialized
INFO - 2016-05-22 11:11:00 --> Helper loaded: url_helper
INFO - 2016-05-22 11:11:00 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:11:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:11:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:11:00 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:11:00 --> Helper loaded: form_helper
INFO - 2016-05-22 11:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:11:00 --> Form Validation Class Initialized
INFO - 2016-05-22 11:11:00 --> Controller Class Initialized
INFO - 2016-05-22 11:11:00 --> Model Class Initialized
INFO - 2016-05-22 11:11:00 --> Database Driver Class Initialized
INFO - 2016-05-22 11:11:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:11:00 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:11:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:11:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:11:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:11:00 --> Final output sent to browser
DEBUG - 2016-05-22 11:11:00 --> Total execution time: 0.1042
INFO - 2016-05-22 11:11:00 --> Config Class Initialized
INFO - 2016-05-22 11:11:00 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:11:00 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:11:00 --> Utf8 Class Initialized
INFO - 2016-05-22 11:11:00 --> URI Class Initialized
INFO - 2016-05-22 11:11:00 --> Router Class Initialized
INFO - 2016-05-22 11:11:00 --> Output Class Initialized
INFO - 2016-05-22 11:11:00 --> Security Class Initialized
DEBUG - 2016-05-22 11:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:11:00 --> Input Class Initialized
INFO - 2016-05-22 11:11:00 --> Language Class Initialized
INFO - 2016-05-22 11:11:00 --> Loader Class Initialized
INFO - 2016-05-22 11:11:00 --> Helper loaded: url_helper
INFO - 2016-05-22 11:11:00 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:11:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:11:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:11:00 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:11:00 --> Helper loaded: form_helper
INFO - 2016-05-22 11:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:11:00 --> Form Validation Class Initialized
INFO - 2016-05-22 11:11:00 --> Controller Class Initialized
INFO - 2016-05-22 11:11:00 --> Model Class Initialized
INFO - 2016-05-22 11:11:00 --> Database Driver Class Initialized
INFO - 2016-05-22 11:11:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:11:00 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:11:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:11:00 --> Final output sent to browser
DEBUG - 2016-05-22 11:11:00 --> Total execution time: 0.0980
INFO - 2016-05-22 11:11:02 --> Config Class Initialized
INFO - 2016-05-22 11:11:02 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:11:02 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:11:02 --> Utf8 Class Initialized
INFO - 2016-05-22 11:11:02 --> URI Class Initialized
INFO - 2016-05-22 11:11:02 --> Router Class Initialized
INFO - 2016-05-22 11:11:02 --> Output Class Initialized
INFO - 2016-05-22 11:11:02 --> Security Class Initialized
DEBUG - 2016-05-22 11:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:11:02 --> Input Class Initialized
INFO - 2016-05-22 11:11:02 --> Language Class Initialized
INFO - 2016-05-22 11:11:02 --> Loader Class Initialized
INFO - 2016-05-22 11:11:02 --> Helper loaded: url_helper
INFO - 2016-05-22 11:11:02 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:11:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:11:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:11:02 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:11:02 --> Helper loaded: form_helper
INFO - 2016-05-22 11:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:11:02 --> Form Validation Class Initialized
INFO - 2016-05-22 11:11:02 --> Controller Class Initialized
INFO - 2016-05-22 11:11:02 --> Model Class Initialized
INFO - 2016-05-22 11:11:02 --> Database Driver Class Initialized
INFO - 2016-05-22 11:11:02 --> Final output sent to browser
DEBUG - 2016-05-22 11:11:02 --> Total execution time: 0.1878
INFO - 2016-05-22 11:11:11 --> Config Class Initialized
INFO - 2016-05-22 11:11:11 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:11:11 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:11:11 --> Utf8 Class Initialized
INFO - 2016-05-22 11:11:11 --> URI Class Initialized
INFO - 2016-05-22 11:11:11 --> Router Class Initialized
INFO - 2016-05-22 11:11:11 --> Output Class Initialized
INFO - 2016-05-22 11:11:11 --> Security Class Initialized
DEBUG - 2016-05-22 11:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:11:11 --> Input Class Initialized
INFO - 2016-05-22 11:11:11 --> Language Class Initialized
INFO - 2016-05-22 11:11:11 --> Loader Class Initialized
INFO - 2016-05-22 11:11:11 --> Helper loaded: url_helper
INFO - 2016-05-22 11:11:11 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:11:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:11:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:11:11 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:11:11 --> Helper loaded: form_helper
INFO - 2016-05-22 11:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:11:11 --> Form Validation Class Initialized
INFO - 2016-05-22 11:11:11 --> Controller Class Initialized
INFO - 2016-05-22 11:11:11 --> Model Class Initialized
INFO - 2016-05-22 11:11:11 --> Database Driver Class Initialized
INFO - 2016-05-22 11:11:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:11:11 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:11:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:11:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:11:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:11:11 --> Final output sent to browser
DEBUG - 2016-05-22 11:11:11 --> Total execution time: 0.1066
INFO - 2016-05-22 11:11:11 --> Config Class Initialized
INFO - 2016-05-22 11:11:11 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:11:11 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:11:11 --> Utf8 Class Initialized
INFO - 2016-05-22 11:11:11 --> URI Class Initialized
INFO - 2016-05-22 11:11:11 --> Router Class Initialized
INFO - 2016-05-22 11:11:11 --> Output Class Initialized
INFO - 2016-05-22 11:11:11 --> Security Class Initialized
DEBUG - 2016-05-22 11:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:11:11 --> Input Class Initialized
INFO - 2016-05-22 11:11:11 --> Language Class Initialized
INFO - 2016-05-22 11:11:11 --> Loader Class Initialized
INFO - 2016-05-22 11:11:11 --> Helper loaded: url_helper
INFO - 2016-05-22 11:11:11 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:11:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:11:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:11:11 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:11:11 --> Helper loaded: form_helper
INFO - 2016-05-22 11:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:11:11 --> Form Validation Class Initialized
INFO - 2016-05-22 11:11:11 --> Controller Class Initialized
INFO - 2016-05-22 11:11:11 --> Model Class Initialized
INFO - 2016-05-22 11:11:11 --> Database Driver Class Initialized
INFO - 2016-05-22 11:11:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:11:11 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:11:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:11:11 --> Final output sent to browser
DEBUG - 2016-05-22 11:11:11 --> Total execution time: 0.0909
INFO - 2016-05-22 11:11:15 --> Config Class Initialized
INFO - 2016-05-22 11:11:15 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:11:15 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:11:15 --> Utf8 Class Initialized
INFO - 2016-05-22 11:11:15 --> URI Class Initialized
INFO - 2016-05-22 11:11:15 --> Router Class Initialized
INFO - 2016-05-22 11:11:15 --> Output Class Initialized
INFO - 2016-05-22 11:11:15 --> Security Class Initialized
DEBUG - 2016-05-22 11:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:11:15 --> Input Class Initialized
INFO - 2016-05-22 11:11:15 --> Language Class Initialized
INFO - 2016-05-22 11:11:15 --> Loader Class Initialized
INFO - 2016-05-22 11:11:15 --> Helper loaded: url_helper
INFO - 2016-05-22 11:11:15 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:11:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:11:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:11:15 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:11:15 --> Helper loaded: form_helper
INFO - 2016-05-22 11:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:11:15 --> Form Validation Class Initialized
INFO - 2016-05-22 11:11:15 --> Controller Class Initialized
INFO - 2016-05-22 11:11:15 --> Model Class Initialized
INFO - 2016-05-22 11:11:15 --> Database Driver Class Initialized
INFO - 2016-05-22 11:11:15 --> Final output sent to browser
DEBUG - 2016-05-22 11:11:15 --> Total execution time: 0.1225
INFO - 2016-05-22 11:11:18 --> Config Class Initialized
INFO - 2016-05-22 11:11:18 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:11:18 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:11:18 --> Utf8 Class Initialized
INFO - 2016-05-22 11:11:18 --> URI Class Initialized
INFO - 2016-05-22 11:11:18 --> Router Class Initialized
INFO - 2016-05-22 11:11:18 --> Output Class Initialized
INFO - 2016-05-22 11:11:18 --> Security Class Initialized
DEBUG - 2016-05-22 11:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:11:18 --> Input Class Initialized
INFO - 2016-05-22 11:11:18 --> Language Class Initialized
INFO - 2016-05-22 11:11:18 --> Loader Class Initialized
INFO - 2016-05-22 11:11:18 --> Helper loaded: url_helper
INFO - 2016-05-22 11:11:18 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:11:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:11:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:11:18 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:11:18 --> Helper loaded: form_helper
INFO - 2016-05-22 11:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:11:18 --> Form Validation Class Initialized
INFO - 2016-05-22 11:11:18 --> Controller Class Initialized
INFO - 2016-05-22 11:11:18 --> Model Class Initialized
INFO - 2016-05-22 11:11:18 --> Database Driver Class Initialized
INFO - 2016-05-22 11:11:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:11:18 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:11:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:11:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:11:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:11:18 --> Final output sent to browser
DEBUG - 2016-05-22 11:11:18 --> Total execution time: 0.1037
INFO - 2016-05-22 11:11:18 --> Config Class Initialized
INFO - 2016-05-22 11:11:18 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:11:18 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:11:18 --> Utf8 Class Initialized
INFO - 2016-05-22 11:11:18 --> URI Class Initialized
INFO - 2016-05-22 11:11:18 --> Router Class Initialized
INFO - 2016-05-22 11:11:18 --> Output Class Initialized
INFO - 2016-05-22 11:11:18 --> Security Class Initialized
DEBUG - 2016-05-22 11:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:11:18 --> Input Class Initialized
INFO - 2016-05-22 11:11:18 --> Language Class Initialized
INFO - 2016-05-22 11:11:18 --> Loader Class Initialized
INFO - 2016-05-22 11:11:18 --> Helper loaded: url_helper
INFO - 2016-05-22 11:11:18 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:11:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:11:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:11:18 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:11:18 --> Helper loaded: form_helper
INFO - 2016-05-22 11:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:11:18 --> Form Validation Class Initialized
INFO - 2016-05-22 11:11:18 --> Controller Class Initialized
INFO - 2016-05-22 11:11:18 --> Model Class Initialized
INFO - 2016-05-22 11:11:18 --> Database Driver Class Initialized
INFO - 2016-05-22 11:11:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:11:19 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:11:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:11:19 --> Final output sent to browser
DEBUG - 2016-05-22 11:11:19 --> Total execution time: 0.0938
INFO - 2016-05-22 11:12:19 --> Config Class Initialized
INFO - 2016-05-22 11:12:19 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:12:19 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:12:19 --> Utf8 Class Initialized
INFO - 2016-05-22 11:12:19 --> URI Class Initialized
INFO - 2016-05-22 11:12:19 --> Router Class Initialized
INFO - 2016-05-22 11:12:19 --> Output Class Initialized
INFO - 2016-05-22 11:12:19 --> Security Class Initialized
DEBUG - 2016-05-22 11:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:12:19 --> Input Class Initialized
INFO - 2016-05-22 11:12:19 --> Language Class Initialized
INFO - 2016-05-22 11:12:19 --> Loader Class Initialized
INFO - 2016-05-22 11:12:19 --> Helper loaded: url_helper
INFO - 2016-05-22 11:12:19 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:12:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:12:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:12:19 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:12:19 --> Helper loaded: form_helper
INFO - 2016-05-22 11:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:12:19 --> Form Validation Class Initialized
INFO - 2016-05-22 11:12:19 --> Controller Class Initialized
INFO - 2016-05-22 11:12:19 --> Model Class Initialized
INFO - 2016-05-22 11:12:19 --> Database Driver Class Initialized
INFO - 2016-05-22 11:12:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:12:19 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:12:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:12:19 --> Final output sent to browser
DEBUG - 2016-05-22 11:12:19 --> Total execution time: 0.0769
INFO - 2016-05-22 11:13:18 --> Config Class Initialized
INFO - 2016-05-22 11:13:18 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:13:18 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:13:18 --> Utf8 Class Initialized
INFO - 2016-05-22 11:13:18 --> URI Class Initialized
INFO - 2016-05-22 11:13:18 --> Router Class Initialized
INFO - 2016-05-22 11:13:18 --> Output Class Initialized
INFO - 2016-05-22 11:13:18 --> Security Class Initialized
DEBUG - 2016-05-22 11:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:13:18 --> Input Class Initialized
INFO - 2016-05-22 11:13:18 --> Language Class Initialized
INFO - 2016-05-22 11:13:18 --> Loader Class Initialized
INFO - 2016-05-22 11:13:18 --> Helper loaded: url_helper
INFO - 2016-05-22 11:13:18 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:13:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:13:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:13:18 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:13:18 --> Helper loaded: form_helper
INFO - 2016-05-22 11:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:13:19 --> Form Validation Class Initialized
INFO - 2016-05-22 11:13:19 --> Controller Class Initialized
INFO - 2016-05-22 11:13:19 --> Model Class Initialized
INFO - 2016-05-22 11:13:19 --> Database Driver Class Initialized
INFO - 2016-05-22 11:13:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:13:19 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:13:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:13:19 --> Final output sent to browser
DEBUG - 2016-05-22 11:13:19 --> Total execution time: 0.0921
INFO - 2016-05-22 11:14:18 --> Config Class Initialized
INFO - 2016-05-22 11:14:18 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:14:18 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:14:18 --> Utf8 Class Initialized
INFO - 2016-05-22 11:14:18 --> URI Class Initialized
INFO - 2016-05-22 11:14:18 --> Router Class Initialized
INFO - 2016-05-22 11:14:18 --> Output Class Initialized
INFO - 2016-05-22 11:14:18 --> Security Class Initialized
DEBUG - 2016-05-22 11:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:14:18 --> Input Class Initialized
INFO - 2016-05-22 11:14:18 --> Language Class Initialized
INFO - 2016-05-22 11:14:18 --> Loader Class Initialized
INFO - 2016-05-22 11:14:18 --> Helper loaded: url_helper
INFO - 2016-05-22 11:14:18 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:14:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:14:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:14:18 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:14:18 --> Helper loaded: form_helper
INFO - 2016-05-22 11:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:14:18 --> Form Validation Class Initialized
INFO - 2016-05-22 11:14:18 --> Controller Class Initialized
INFO - 2016-05-22 11:14:18 --> Model Class Initialized
INFO - 2016-05-22 11:14:19 --> Database Driver Class Initialized
INFO - 2016-05-22 11:14:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:14:19 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:14:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:14:19 --> Final output sent to browser
DEBUG - 2016-05-22 11:14:19 --> Total execution time: 0.0752
INFO - 2016-05-22 11:15:18 --> Config Class Initialized
INFO - 2016-05-22 11:15:18 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:15:18 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:15:18 --> Utf8 Class Initialized
INFO - 2016-05-22 11:15:18 --> URI Class Initialized
INFO - 2016-05-22 11:15:18 --> Router Class Initialized
INFO - 2016-05-22 11:15:18 --> Output Class Initialized
INFO - 2016-05-22 11:15:18 --> Security Class Initialized
DEBUG - 2016-05-22 11:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:15:18 --> Input Class Initialized
INFO - 2016-05-22 11:15:18 --> Language Class Initialized
INFO - 2016-05-22 11:15:18 --> Loader Class Initialized
INFO - 2016-05-22 11:15:18 --> Helper loaded: url_helper
INFO - 2016-05-22 11:15:18 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:15:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:15:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:15:18 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:15:18 --> Helper loaded: form_helper
INFO - 2016-05-22 11:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:15:18 --> Form Validation Class Initialized
INFO - 2016-05-22 11:15:18 --> Controller Class Initialized
INFO - 2016-05-22 11:15:18 --> Model Class Initialized
INFO - 2016-05-22 11:15:19 --> Database Driver Class Initialized
INFO - 2016-05-22 11:15:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:15:19 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:15:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:15:19 --> Final output sent to browser
DEBUG - 2016-05-22 11:15:19 --> Total execution time: 0.0824
INFO - 2016-05-22 11:15:55 --> Config Class Initialized
INFO - 2016-05-22 11:15:55 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:15:55 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:15:55 --> Utf8 Class Initialized
INFO - 2016-05-22 11:15:55 --> URI Class Initialized
INFO - 2016-05-22 11:15:55 --> Router Class Initialized
INFO - 2016-05-22 11:15:55 --> Output Class Initialized
INFO - 2016-05-22 11:15:55 --> Security Class Initialized
DEBUG - 2016-05-22 11:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:15:55 --> Input Class Initialized
INFO - 2016-05-22 11:15:55 --> Language Class Initialized
INFO - 2016-05-22 11:15:55 --> Loader Class Initialized
INFO - 2016-05-22 11:15:55 --> Helper loaded: url_helper
INFO - 2016-05-22 11:15:55 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:15:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:15:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:15:55 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:15:55 --> Helper loaded: form_helper
INFO - 2016-05-22 11:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:15:55 --> Form Validation Class Initialized
INFO - 2016-05-22 11:15:55 --> Controller Class Initialized
INFO - 2016-05-22 11:15:55 --> Model Class Initialized
INFO - 2016-05-22 11:15:55 --> Database Driver Class Initialized
INFO - 2016-05-22 11:15:55 --> Final output sent to browser
DEBUG - 2016-05-22 11:15:55 --> Total execution time: 0.1221
INFO - 2016-05-22 11:25:38 --> Config Class Initialized
INFO - 2016-05-22 11:25:38 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:25:38 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:25:38 --> Utf8 Class Initialized
INFO - 2016-05-22 11:25:38 --> URI Class Initialized
INFO - 2016-05-22 11:25:38 --> Router Class Initialized
INFO - 2016-05-22 11:25:38 --> Output Class Initialized
INFO - 2016-05-22 11:25:38 --> Security Class Initialized
DEBUG - 2016-05-22 11:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:25:38 --> Input Class Initialized
INFO - 2016-05-22 11:25:38 --> Language Class Initialized
INFO - 2016-05-22 11:25:38 --> Loader Class Initialized
INFO - 2016-05-22 11:25:38 --> Helper loaded: url_helper
INFO - 2016-05-22 11:25:38 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:25:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:25:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:25:38 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:25:38 --> Helper loaded: form_helper
INFO - 2016-05-22 11:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:25:38 --> Form Validation Class Initialized
INFO - 2016-05-22 11:25:38 --> Controller Class Initialized
INFO - 2016-05-22 11:25:38 --> Model Class Initialized
INFO - 2016-05-22 11:25:38 --> Database Driver Class Initialized
ERROR - 2016-05-22 11:25:38 --> Query error: Unknown column 'importe_toal_descuento' in 'field list' - Invalid query: SELECT importe_total, cantidad_total, importe_bruto, ifnull(descuento, 0) 'descuento', base_imponible, cantidad_iva, importe_toal_descuento FROM factura f INNER JOIN provincia p ON f.idProvincia=p.idProvincia WHERE f.idFactura = 18 
INFO - 2016-05-22 11:25:38 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-22 11:25:39 --> Config Class Initialized
INFO - 2016-05-22 11:25:39 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:25:39 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:25:39 --> Utf8 Class Initialized
INFO - 2016-05-22 11:25:39 --> URI Class Initialized
INFO - 2016-05-22 11:25:39 --> Router Class Initialized
INFO - 2016-05-22 11:25:39 --> Output Class Initialized
INFO - 2016-05-22 11:25:39 --> Security Class Initialized
DEBUG - 2016-05-22 11:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:25:39 --> Input Class Initialized
INFO - 2016-05-22 11:25:39 --> Language Class Initialized
INFO - 2016-05-22 11:25:39 --> Loader Class Initialized
INFO - 2016-05-22 11:25:39 --> Helper loaded: url_helper
INFO - 2016-05-22 11:25:39 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:25:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:25:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:25:39 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:25:39 --> Helper loaded: form_helper
INFO - 2016-05-22 11:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:25:39 --> Form Validation Class Initialized
INFO - 2016-05-22 11:25:39 --> Controller Class Initialized
INFO - 2016-05-22 11:25:39 --> Model Class Initialized
INFO - 2016-05-22 11:25:39 --> Database Driver Class Initialized
ERROR - 2016-05-22 11:25:39 --> Query error: Unknown column 'importe_toal_descuento' in 'field list' - Invalid query: SELECT importe_total, cantidad_total, importe_bruto, ifnull(descuento, 0) 'descuento', base_imponible, cantidad_iva, importe_toal_descuento FROM factura f INNER JOIN provincia p ON f.idProvincia=p.idProvincia WHERE f.idFactura = 18 
INFO - 2016-05-22 11:25:39 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-22 11:25:57 --> Config Class Initialized
INFO - 2016-05-22 11:25:57 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:25:57 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:25:57 --> Utf8 Class Initialized
INFO - 2016-05-22 11:25:57 --> URI Class Initialized
INFO - 2016-05-22 11:25:57 --> Router Class Initialized
INFO - 2016-05-22 11:25:57 --> Output Class Initialized
INFO - 2016-05-22 11:25:57 --> Security Class Initialized
DEBUG - 2016-05-22 11:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:25:57 --> Input Class Initialized
INFO - 2016-05-22 11:25:57 --> Language Class Initialized
INFO - 2016-05-22 11:25:57 --> Loader Class Initialized
INFO - 2016-05-22 11:25:57 --> Helper loaded: url_helper
INFO - 2016-05-22 11:25:57 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:25:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:25:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:25:57 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:25:57 --> Helper loaded: form_helper
INFO - 2016-05-22 11:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:25:57 --> Form Validation Class Initialized
INFO - 2016-05-22 11:25:57 --> Controller Class Initialized
INFO - 2016-05-22 11:25:57 --> Model Class Initialized
INFO - 2016-05-22 11:25:57 --> Database Driver Class Initialized
INFO - 2016-05-22 11:25:57 --> Final output sent to browser
DEBUG - 2016-05-22 11:25:57 --> Total execution time: 0.1317
INFO - 2016-05-22 11:26:18 --> Config Class Initialized
INFO - 2016-05-22 11:26:18 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:26:18 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:26:18 --> Utf8 Class Initialized
INFO - 2016-05-22 11:26:18 --> URI Class Initialized
INFO - 2016-05-22 11:26:18 --> Router Class Initialized
INFO - 2016-05-22 11:26:18 --> Output Class Initialized
INFO - 2016-05-22 11:26:18 --> Security Class Initialized
DEBUG - 2016-05-22 11:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:26:18 --> Input Class Initialized
INFO - 2016-05-22 11:26:18 --> Language Class Initialized
INFO - 2016-05-22 11:26:18 --> Loader Class Initialized
INFO - 2016-05-22 11:26:18 --> Helper loaded: url_helper
INFO - 2016-05-22 11:26:18 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:26:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:26:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:26:18 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:26:18 --> Helper loaded: form_helper
INFO - 2016-05-22 11:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:26:18 --> Form Validation Class Initialized
INFO - 2016-05-22 11:26:18 --> Controller Class Initialized
INFO - 2016-05-22 11:26:18 --> Model Class Initialized
INFO - 2016-05-22 11:26:18 --> Database Driver Class Initialized
INFO - 2016-05-22 11:26:19 --> Final output sent to browser
DEBUG - 2016-05-22 11:26:19 --> Total execution time: 0.1860
INFO - 2016-05-22 11:34:35 --> Config Class Initialized
INFO - 2016-05-22 11:34:35 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:34:35 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:34:35 --> Utf8 Class Initialized
INFO - 2016-05-22 11:34:35 --> URI Class Initialized
INFO - 2016-05-22 11:34:35 --> Router Class Initialized
INFO - 2016-05-22 11:34:35 --> Output Class Initialized
INFO - 2016-05-22 11:34:35 --> Security Class Initialized
DEBUG - 2016-05-22 11:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:34:35 --> Input Class Initialized
INFO - 2016-05-22 11:34:35 --> Language Class Initialized
INFO - 2016-05-22 11:34:35 --> Loader Class Initialized
INFO - 2016-05-22 11:34:35 --> Helper loaded: url_helper
INFO - 2016-05-22 11:34:35 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:34:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:34:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:34:35 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:34:35 --> Helper loaded: form_helper
INFO - 2016-05-22 11:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:34:35 --> Form Validation Class Initialized
INFO - 2016-05-22 11:34:35 --> Controller Class Initialized
INFO - 2016-05-22 11:34:35 --> Model Class Initialized
INFO - 2016-05-22 11:34:35 --> Database Driver Class Initialized
INFO - 2016-05-22 11:34:35 --> Final output sent to browser
DEBUG - 2016-05-22 11:34:35 --> Total execution time: 0.1274
INFO - 2016-05-22 11:34:38 --> Config Class Initialized
INFO - 2016-05-22 11:34:38 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:34:38 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:34:38 --> Utf8 Class Initialized
INFO - 2016-05-22 11:34:39 --> URI Class Initialized
INFO - 2016-05-22 11:34:39 --> Router Class Initialized
INFO - 2016-05-22 11:34:39 --> Output Class Initialized
INFO - 2016-05-22 11:34:39 --> Security Class Initialized
DEBUG - 2016-05-22 11:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:34:39 --> Input Class Initialized
INFO - 2016-05-22 11:34:39 --> Language Class Initialized
INFO - 2016-05-22 11:34:39 --> Loader Class Initialized
INFO - 2016-05-22 11:34:39 --> Helper loaded: url_helper
INFO - 2016-05-22 11:34:39 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:34:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:34:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:34:39 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:34:39 --> Helper loaded: form_helper
INFO - 2016-05-22 11:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:34:39 --> Form Validation Class Initialized
INFO - 2016-05-22 11:34:39 --> Controller Class Initialized
INFO - 2016-05-22 11:34:39 --> Model Class Initialized
INFO - 2016-05-22 11:34:39 --> Database Driver Class Initialized
INFO - 2016-05-22 11:34:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:34:39 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:34:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:34:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:34:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:34:39 --> Final output sent to browser
DEBUG - 2016-05-22 11:34:39 --> Total execution time: 0.0841
INFO - 2016-05-22 11:34:39 --> Config Class Initialized
INFO - 2016-05-22 11:34:39 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:34:39 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:34:39 --> Utf8 Class Initialized
INFO - 2016-05-22 11:34:39 --> URI Class Initialized
INFO - 2016-05-22 11:34:39 --> Router Class Initialized
INFO - 2016-05-22 11:34:39 --> Output Class Initialized
INFO - 2016-05-22 11:34:39 --> Security Class Initialized
DEBUG - 2016-05-22 11:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:34:39 --> Input Class Initialized
INFO - 2016-05-22 11:34:39 --> Language Class Initialized
INFO - 2016-05-22 11:34:39 --> Loader Class Initialized
INFO - 2016-05-22 11:34:39 --> Helper loaded: url_helper
INFO - 2016-05-22 11:34:39 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:34:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:34:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:34:39 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:34:39 --> Helper loaded: form_helper
INFO - 2016-05-22 11:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:34:39 --> Form Validation Class Initialized
INFO - 2016-05-22 11:34:39 --> Controller Class Initialized
INFO - 2016-05-22 11:34:39 --> Model Class Initialized
INFO - 2016-05-22 11:34:39 --> Database Driver Class Initialized
INFO - 2016-05-22 11:34:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:34:39 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:34:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:34:39 --> Final output sent to browser
DEBUG - 2016-05-22 11:34:39 --> Total execution time: 0.0938
INFO - 2016-05-22 11:34:41 --> Config Class Initialized
INFO - 2016-05-22 11:34:41 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:34:41 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:34:41 --> Utf8 Class Initialized
INFO - 2016-05-22 11:34:41 --> URI Class Initialized
INFO - 2016-05-22 11:34:41 --> Router Class Initialized
INFO - 2016-05-22 11:34:41 --> Output Class Initialized
INFO - 2016-05-22 11:34:41 --> Security Class Initialized
DEBUG - 2016-05-22 11:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:34:41 --> Input Class Initialized
INFO - 2016-05-22 11:34:41 --> Language Class Initialized
INFO - 2016-05-22 11:34:41 --> Loader Class Initialized
INFO - 2016-05-22 11:34:41 --> Helper loaded: url_helper
INFO - 2016-05-22 11:34:41 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:34:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:34:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:34:41 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:34:41 --> Helper loaded: form_helper
INFO - 2016-05-22 11:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:34:41 --> Form Validation Class Initialized
INFO - 2016-05-22 11:34:41 --> Controller Class Initialized
INFO - 2016-05-22 11:34:41 --> Model Class Initialized
INFO - 2016-05-22 11:34:41 --> Database Driver Class Initialized
INFO - 2016-05-22 11:34:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:34:41 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:34:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:34:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:34:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:34:41 --> Final output sent to browser
DEBUG - 2016-05-22 11:34:41 --> Total execution time: 0.0833
INFO - 2016-05-22 11:34:42 --> Config Class Initialized
INFO - 2016-05-22 11:34:42 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:34:42 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:34:42 --> Utf8 Class Initialized
INFO - 2016-05-22 11:34:42 --> URI Class Initialized
INFO - 2016-05-22 11:34:42 --> Router Class Initialized
INFO - 2016-05-22 11:34:42 --> Output Class Initialized
INFO - 2016-05-22 11:34:42 --> Security Class Initialized
DEBUG - 2016-05-22 11:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:34:42 --> Input Class Initialized
INFO - 2016-05-22 11:34:42 --> Language Class Initialized
INFO - 2016-05-22 11:34:42 --> Loader Class Initialized
INFO - 2016-05-22 11:34:42 --> Helper loaded: url_helper
INFO - 2016-05-22 11:34:42 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:34:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:34:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:34:42 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:34:42 --> Helper loaded: form_helper
INFO - 2016-05-22 11:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:34:42 --> Form Validation Class Initialized
INFO - 2016-05-22 11:34:42 --> Controller Class Initialized
INFO - 2016-05-22 11:34:42 --> Model Class Initialized
INFO - 2016-05-22 11:34:42 --> Database Driver Class Initialized
INFO - 2016-05-22 11:34:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:34:42 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:34:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:34:42 --> Final output sent to browser
DEBUG - 2016-05-22 11:34:42 --> Total execution time: 0.0975
INFO - 2016-05-22 11:34:45 --> Config Class Initialized
INFO - 2016-05-22 11:34:45 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:34:45 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:34:45 --> Utf8 Class Initialized
INFO - 2016-05-22 11:34:45 --> URI Class Initialized
INFO - 2016-05-22 11:34:45 --> Router Class Initialized
INFO - 2016-05-22 11:34:45 --> Output Class Initialized
INFO - 2016-05-22 11:34:45 --> Security Class Initialized
DEBUG - 2016-05-22 11:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:34:45 --> Input Class Initialized
INFO - 2016-05-22 11:34:45 --> Language Class Initialized
INFO - 2016-05-22 11:34:45 --> Loader Class Initialized
INFO - 2016-05-22 11:34:45 --> Helper loaded: url_helper
INFO - 2016-05-22 11:34:45 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:34:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:34:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:34:45 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:34:45 --> Helper loaded: form_helper
INFO - 2016-05-22 11:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:34:45 --> Form Validation Class Initialized
INFO - 2016-05-22 11:34:45 --> Controller Class Initialized
INFO - 2016-05-22 11:34:45 --> Model Class Initialized
INFO - 2016-05-22 11:34:45 --> Database Driver Class Initialized
INFO - 2016-05-22 11:34:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:34:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:34:45 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:34:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:34:45 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:34:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-22 11:34:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:34:45 --> Final output sent to browser
DEBUG - 2016-05-22 11:34:45 --> Total execution time: 0.2392
INFO - 2016-05-22 11:34:45 --> Config Class Initialized
INFO - 2016-05-22 11:34:45 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:34:45 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:34:45 --> Utf8 Class Initialized
INFO - 2016-05-22 11:34:45 --> URI Class Initialized
INFO - 2016-05-22 11:34:45 --> Router Class Initialized
INFO - 2016-05-22 11:34:45 --> Output Class Initialized
INFO - 2016-05-22 11:34:45 --> Security Class Initialized
DEBUG - 2016-05-22 11:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:34:45 --> Input Class Initialized
INFO - 2016-05-22 11:34:45 --> Language Class Initialized
INFO - 2016-05-22 11:34:45 --> Loader Class Initialized
INFO - 2016-05-22 11:34:45 --> Helper loaded: url_helper
INFO - 2016-05-22 11:34:45 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:34:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:34:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:34:45 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:34:45 --> Helper loaded: form_helper
INFO - 2016-05-22 11:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:34:45 --> Form Validation Class Initialized
INFO - 2016-05-22 11:34:45 --> Controller Class Initialized
INFO - 2016-05-22 11:34:45 --> Model Class Initialized
INFO - 2016-05-22 11:34:45 --> Database Driver Class Initialized
INFO - 2016-05-22 11:34:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:34:45 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:34:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:34:45 --> Final output sent to browser
DEBUG - 2016-05-22 11:34:45 --> Total execution time: 0.1326
INFO - 2016-05-22 11:35:02 --> Config Class Initialized
INFO - 2016-05-22 11:35:02 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:35:02 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:35:02 --> Utf8 Class Initialized
INFO - 2016-05-22 11:35:02 --> URI Class Initialized
INFO - 2016-05-22 11:35:02 --> Router Class Initialized
INFO - 2016-05-22 11:35:02 --> Output Class Initialized
INFO - 2016-05-22 11:35:02 --> Security Class Initialized
DEBUG - 2016-05-22 11:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:35:02 --> Input Class Initialized
INFO - 2016-05-22 11:35:02 --> Language Class Initialized
INFO - 2016-05-22 11:35:02 --> Loader Class Initialized
INFO - 2016-05-22 11:35:02 --> Helper loaded: url_helper
INFO - 2016-05-22 11:35:02 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:35:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:35:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:35:02 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:35:02 --> Helper loaded: form_helper
INFO - 2016-05-22 11:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:35:02 --> Form Validation Class Initialized
INFO - 2016-05-22 11:35:02 --> Controller Class Initialized
INFO - 2016-05-22 11:35:02 --> Model Class Initialized
INFO - 2016-05-22 11:35:02 --> Database Driver Class Initialized
INFO - 2016-05-22 11:35:02 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:35:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:35:02 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:35:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:35:02 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:35:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-22 11:35:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:35:02 --> Final output sent to browser
DEBUG - 2016-05-22 11:35:02 --> Total execution time: 0.1245
INFO - 2016-05-22 11:35:02 --> Config Class Initialized
INFO - 2016-05-22 11:35:02 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:35:02 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:35:02 --> Utf8 Class Initialized
INFO - 2016-05-22 11:35:02 --> URI Class Initialized
INFO - 2016-05-22 11:35:02 --> Router Class Initialized
INFO - 2016-05-22 11:35:02 --> Output Class Initialized
INFO - 2016-05-22 11:35:02 --> Security Class Initialized
DEBUG - 2016-05-22 11:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:35:02 --> Input Class Initialized
INFO - 2016-05-22 11:35:02 --> Language Class Initialized
INFO - 2016-05-22 11:35:02 --> Loader Class Initialized
INFO - 2016-05-22 11:35:02 --> Helper loaded: url_helper
INFO - 2016-05-22 11:35:02 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:35:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:35:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:35:02 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:35:02 --> Helper loaded: form_helper
INFO - 2016-05-22 11:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:35:02 --> Form Validation Class Initialized
INFO - 2016-05-22 11:35:02 --> Controller Class Initialized
INFO - 2016-05-22 11:35:02 --> Model Class Initialized
INFO - 2016-05-22 11:35:02 --> Database Driver Class Initialized
INFO - 2016-05-22 11:35:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:35:02 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:35:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:35:02 --> Final output sent to browser
DEBUG - 2016-05-22 11:35:02 --> Total execution time: 0.0916
INFO - 2016-05-22 11:35:08 --> Config Class Initialized
INFO - 2016-05-22 11:35:08 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:35:08 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:35:08 --> Utf8 Class Initialized
INFO - 2016-05-22 11:35:08 --> URI Class Initialized
INFO - 2016-05-22 11:35:08 --> Router Class Initialized
INFO - 2016-05-22 11:35:08 --> Output Class Initialized
INFO - 2016-05-22 11:35:08 --> Security Class Initialized
DEBUG - 2016-05-22 11:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:35:08 --> Input Class Initialized
INFO - 2016-05-22 11:35:08 --> Language Class Initialized
INFO - 2016-05-22 11:35:08 --> Loader Class Initialized
INFO - 2016-05-22 11:35:08 --> Helper loaded: url_helper
INFO - 2016-05-22 11:35:08 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:35:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:35:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:35:08 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:35:08 --> Helper loaded: form_helper
INFO - 2016-05-22 11:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:35:08 --> Form Validation Class Initialized
INFO - 2016-05-22 11:35:08 --> Controller Class Initialized
INFO - 2016-05-22 11:35:08 --> Model Class Initialized
INFO - 2016-05-22 11:35:08 --> Database Driver Class Initialized
INFO - 2016-05-22 11:35:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:35:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:35:08 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:35:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:35:08 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:35:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-22 11:35:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:35:08 --> Final output sent to browser
DEBUG - 2016-05-22 11:35:08 --> Total execution time: 0.0870
INFO - 2016-05-22 11:35:08 --> Config Class Initialized
INFO - 2016-05-22 11:35:08 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:35:08 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:35:08 --> Utf8 Class Initialized
INFO - 2016-05-22 11:35:08 --> URI Class Initialized
INFO - 2016-05-22 11:35:08 --> Router Class Initialized
INFO - 2016-05-22 11:35:08 --> Output Class Initialized
INFO - 2016-05-22 11:35:08 --> Security Class Initialized
DEBUG - 2016-05-22 11:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:35:08 --> Input Class Initialized
INFO - 2016-05-22 11:35:08 --> Language Class Initialized
INFO - 2016-05-22 11:35:08 --> Loader Class Initialized
INFO - 2016-05-22 11:35:08 --> Helper loaded: url_helper
INFO - 2016-05-22 11:35:08 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:35:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:35:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:35:08 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:35:08 --> Helper loaded: form_helper
INFO - 2016-05-22 11:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:35:08 --> Form Validation Class Initialized
INFO - 2016-05-22 11:35:08 --> Controller Class Initialized
INFO - 2016-05-22 11:35:08 --> Model Class Initialized
INFO - 2016-05-22 11:35:08 --> Database Driver Class Initialized
INFO - 2016-05-22 11:35:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:35:08 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:35:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:35:08 --> Final output sent to browser
DEBUG - 2016-05-22 11:35:08 --> Total execution time: 0.0880
INFO - 2016-05-22 11:36:08 --> Config Class Initialized
INFO - 2016-05-22 11:36:08 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:36:08 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:36:08 --> Utf8 Class Initialized
INFO - 2016-05-22 11:36:08 --> URI Class Initialized
INFO - 2016-05-22 11:36:08 --> Router Class Initialized
INFO - 2016-05-22 11:36:08 --> Output Class Initialized
INFO - 2016-05-22 11:36:08 --> Security Class Initialized
DEBUG - 2016-05-22 11:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:36:08 --> Input Class Initialized
INFO - 2016-05-22 11:36:08 --> Language Class Initialized
INFO - 2016-05-22 11:36:08 --> Loader Class Initialized
INFO - 2016-05-22 11:36:08 --> Helper loaded: url_helper
INFO - 2016-05-22 11:36:08 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:36:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:36:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:36:08 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:36:08 --> Helper loaded: form_helper
INFO - 2016-05-22 11:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:36:08 --> Form Validation Class Initialized
INFO - 2016-05-22 11:36:08 --> Controller Class Initialized
INFO - 2016-05-22 11:36:08 --> Model Class Initialized
INFO - 2016-05-22 11:36:08 --> Database Driver Class Initialized
INFO - 2016-05-22 11:36:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:36:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:36:08 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:36:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:36:08 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:36:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-22 11:36:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:36:08 --> Final output sent to browser
DEBUG - 2016-05-22 11:36:08 --> Total execution time: 0.0962
INFO - 2016-05-22 11:36:08 --> Config Class Initialized
INFO - 2016-05-22 11:36:08 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:36:08 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:36:08 --> Utf8 Class Initialized
INFO - 2016-05-22 11:36:08 --> URI Class Initialized
INFO - 2016-05-22 11:36:08 --> Router Class Initialized
INFO - 2016-05-22 11:36:08 --> Output Class Initialized
INFO - 2016-05-22 11:36:08 --> Security Class Initialized
DEBUG - 2016-05-22 11:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:36:08 --> Input Class Initialized
INFO - 2016-05-22 11:36:08 --> Language Class Initialized
INFO - 2016-05-22 11:36:08 --> Loader Class Initialized
INFO - 2016-05-22 11:36:08 --> Helper loaded: url_helper
INFO - 2016-05-22 11:36:08 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:36:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:36:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:36:08 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:36:08 --> Helper loaded: form_helper
INFO - 2016-05-22 11:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:36:08 --> Form Validation Class Initialized
INFO - 2016-05-22 11:36:08 --> Controller Class Initialized
INFO - 2016-05-22 11:36:08 --> Model Class Initialized
INFO - 2016-05-22 11:36:08 --> Database Driver Class Initialized
INFO - 2016-05-22 11:36:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:36:08 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:36:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:36:08 --> Final output sent to browser
DEBUG - 2016-05-22 11:36:08 --> Total execution time: 0.1074
INFO - 2016-05-22 11:36:28 --> Config Class Initialized
INFO - 2016-05-22 11:36:28 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:36:28 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:36:28 --> Utf8 Class Initialized
INFO - 2016-05-22 11:36:28 --> URI Class Initialized
INFO - 2016-05-22 11:36:28 --> Router Class Initialized
INFO - 2016-05-22 11:36:28 --> Output Class Initialized
INFO - 2016-05-22 11:36:28 --> Security Class Initialized
DEBUG - 2016-05-22 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:36:28 --> Input Class Initialized
INFO - 2016-05-22 11:36:28 --> Language Class Initialized
INFO - 2016-05-22 11:36:28 --> Loader Class Initialized
INFO - 2016-05-22 11:36:28 --> Helper loaded: url_helper
INFO - 2016-05-22 11:36:28 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:36:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:36:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:36:28 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:36:28 --> Helper loaded: form_helper
INFO - 2016-05-22 11:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:36:28 --> Form Validation Class Initialized
INFO - 2016-05-22 11:36:28 --> Controller Class Initialized
INFO - 2016-05-22 11:36:28 --> Model Class Initialized
INFO - 2016-05-22 11:36:28 --> Database Driver Class Initialized
INFO - 2016-05-22 11:36:28 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:36:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:36:28 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:36:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:36:28 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:36:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-22 11:36:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:36:28 --> Final output sent to browser
DEBUG - 2016-05-22 11:36:28 --> Total execution time: 0.0860
INFO - 2016-05-22 11:36:28 --> Config Class Initialized
INFO - 2016-05-22 11:36:28 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:36:28 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:36:29 --> Utf8 Class Initialized
INFO - 2016-05-22 11:36:29 --> URI Class Initialized
INFO - 2016-05-22 11:36:29 --> Router Class Initialized
INFO - 2016-05-22 11:36:29 --> Output Class Initialized
INFO - 2016-05-22 11:36:29 --> Security Class Initialized
DEBUG - 2016-05-22 11:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:36:29 --> Input Class Initialized
INFO - 2016-05-22 11:36:29 --> Language Class Initialized
INFO - 2016-05-22 11:36:29 --> Loader Class Initialized
INFO - 2016-05-22 11:36:29 --> Helper loaded: url_helper
INFO - 2016-05-22 11:36:29 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:36:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:36:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:36:29 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:36:29 --> Helper loaded: form_helper
INFO - 2016-05-22 11:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:36:29 --> Form Validation Class Initialized
INFO - 2016-05-22 11:36:29 --> Controller Class Initialized
INFO - 2016-05-22 11:36:29 --> Model Class Initialized
INFO - 2016-05-22 11:36:29 --> Database Driver Class Initialized
INFO - 2016-05-22 11:36:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:36:29 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:36:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:36:29 --> Final output sent to browser
DEBUG - 2016-05-22 11:36:29 --> Total execution time: 0.0850
INFO - 2016-05-22 11:36:39 --> Config Class Initialized
INFO - 2016-05-22 11:36:39 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:36:39 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:36:39 --> Utf8 Class Initialized
INFO - 2016-05-22 11:36:39 --> URI Class Initialized
INFO - 2016-05-22 11:36:39 --> Router Class Initialized
INFO - 2016-05-22 11:36:39 --> Output Class Initialized
INFO - 2016-05-22 11:36:39 --> Security Class Initialized
DEBUG - 2016-05-22 11:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:36:39 --> Input Class Initialized
INFO - 2016-05-22 11:36:39 --> Language Class Initialized
INFO - 2016-05-22 11:36:39 --> Loader Class Initialized
INFO - 2016-05-22 11:36:39 --> Helper loaded: url_helper
INFO - 2016-05-22 11:36:39 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:36:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:36:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:36:39 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:36:39 --> Helper loaded: form_helper
INFO - 2016-05-22 11:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:36:39 --> Form Validation Class Initialized
INFO - 2016-05-22 11:36:39 --> Controller Class Initialized
INFO - 2016-05-22 11:36:39 --> Model Class Initialized
INFO - 2016-05-22 11:36:39 --> Database Driver Class Initialized
INFO - 2016-05-22 11:36:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:36:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:36:39 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:36:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:36:39 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:36:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-22 11:36:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:36:39 --> Final output sent to browser
DEBUG - 2016-05-22 11:36:39 --> Total execution time: 0.0852
INFO - 2016-05-22 11:36:39 --> Config Class Initialized
INFO - 2016-05-22 11:36:39 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:36:39 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:36:39 --> Utf8 Class Initialized
INFO - 2016-05-22 11:36:39 --> URI Class Initialized
INFO - 2016-05-22 11:36:39 --> Router Class Initialized
INFO - 2016-05-22 11:36:39 --> Output Class Initialized
INFO - 2016-05-22 11:36:39 --> Security Class Initialized
DEBUG - 2016-05-22 11:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:36:39 --> Input Class Initialized
INFO - 2016-05-22 11:36:39 --> Language Class Initialized
INFO - 2016-05-22 11:36:39 --> Loader Class Initialized
INFO - 2016-05-22 11:36:39 --> Helper loaded: url_helper
INFO - 2016-05-22 11:36:39 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:36:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:36:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:36:39 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:36:39 --> Helper loaded: form_helper
INFO - 2016-05-22 11:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:36:39 --> Form Validation Class Initialized
INFO - 2016-05-22 11:36:39 --> Controller Class Initialized
INFO - 2016-05-22 11:36:39 --> Model Class Initialized
INFO - 2016-05-22 11:36:39 --> Database Driver Class Initialized
INFO - 2016-05-22 11:36:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:36:39 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:36:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:36:39 --> Final output sent to browser
DEBUG - 2016-05-22 11:36:39 --> Total execution time: 0.0931
INFO - 2016-05-22 11:37:04 --> Config Class Initialized
INFO - 2016-05-22 11:37:04 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:04 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:04 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:04 --> URI Class Initialized
INFO - 2016-05-22 11:37:04 --> Router Class Initialized
INFO - 2016-05-22 11:37:05 --> Output Class Initialized
INFO - 2016-05-22 11:37:05 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:05 --> Input Class Initialized
INFO - 2016-05-22 11:37:05 --> Language Class Initialized
INFO - 2016-05-22 11:37:05 --> Loader Class Initialized
INFO - 2016-05-22 11:37:05 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:05 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:05 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:05 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:05 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:05 --> Controller Class Initialized
INFO - 2016-05-22 11:37:05 --> Model Class Initialized
INFO - 2016-05-22 11:37:05 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:05 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-22 11:37:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:37:05 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:05 --> Total execution time: 0.1189
INFO - 2016-05-22 11:37:05 --> Config Class Initialized
INFO - 2016-05-22 11:37:05 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:05 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:05 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:05 --> URI Class Initialized
INFO - 2016-05-22 11:37:05 --> Router Class Initialized
INFO - 2016-05-22 11:37:05 --> Output Class Initialized
INFO - 2016-05-22 11:37:05 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:05 --> Input Class Initialized
INFO - 2016-05-22 11:37:05 --> Language Class Initialized
INFO - 2016-05-22 11:37:05 --> Loader Class Initialized
INFO - 2016-05-22 11:37:05 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:05 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:05 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:05 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:05 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:05 --> Controller Class Initialized
INFO - 2016-05-22 11:37:05 --> Model Class Initialized
INFO - 2016-05-22 11:37:05 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:05 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:05 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:05 --> Total execution time: 0.0915
INFO - 2016-05-22 11:37:06 --> Config Class Initialized
INFO - 2016-05-22 11:37:06 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:06 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:06 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:06 --> URI Class Initialized
INFO - 2016-05-22 11:37:06 --> Router Class Initialized
INFO - 2016-05-22 11:37:06 --> Output Class Initialized
INFO - 2016-05-22 11:37:06 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:06 --> Input Class Initialized
INFO - 2016-05-22 11:37:06 --> Language Class Initialized
INFO - 2016-05-22 11:37:06 --> Loader Class Initialized
INFO - 2016-05-22 11:37:06 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:06 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:06 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:06 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:06 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:06 --> Controller Class Initialized
INFO - 2016-05-22 11:37:06 --> Model Class Initialized
INFO - 2016-05-22 11:37:06 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:06 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-22 11:37:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:37:06 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:06 --> Total execution time: 0.1167
INFO - 2016-05-22 11:37:06 --> Config Class Initialized
INFO - 2016-05-22 11:37:06 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:06 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:06 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:06 --> URI Class Initialized
INFO - 2016-05-22 11:37:06 --> Router Class Initialized
INFO - 2016-05-22 11:37:06 --> Output Class Initialized
INFO - 2016-05-22 11:37:06 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:06 --> Input Class Initialized
INFO - 2016-05-22 11:37:06 --> Language Class Initialized
INFO - 2016-05-22 11:37:06 --> Loader Class Initialized
INFO - 2016-05-22 11:37:06 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:06 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:06 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:06 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:06 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:06 --> Controller Class Initialized
INFO - 2016-05-22 11:37:06 --> Model Class Initialized
INFO - 2016-05-22 11:37:06 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:07 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:07 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:07 --> Total execution time: 0.1056
INFO - 2016-05-22 11:37:08 --> Config Class Initialized
INFO - 2016-05-22 11:37:08 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:08 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:08 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:08 --> URI Class Initialized
INFO - 2016-05-22 11:37:08 --> Router Class Initialized
INFO - 2016-05-22 11:37:08 --> Output Class Initialized
INFO - 2016-05-22 11:37:08 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:08 --> Input Class Initialized
INFO - 2016-05-22 11:37:08 --> Language Class Initialized
INFO - 2016-05-22 11:37:08 --> Loader Class Initialized
INFO - 2016-05-22 11:37:08 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:08 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:08 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:08 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:08 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:08 --> Controller Class Initialized
INFO - 2016-05-22 11:37:08 --> Model Class Initialized
INFO - 2016-05-22 11:37:08 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:08 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-22 11:37:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:37:08 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:08 --> Total execution time: 0.1792
INFO - 2016-05-22 11:37:08 --> Config Class Initialized
INFO - 2016-05-22 11:37:08 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:08 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:08 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:08 --> URI Class Initialized
INFO - 2016-05-22 11:37:08 --> Router Class Initialized
INFO - 2016-05-22 11:37:08 --> Output Class Initialized
INFO - 2016-05-22 11:37:08 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:08 --> Input Class Initialized
INFO - 2016-05-22 11:37:08 --> Language Class Initialized
INFO - 2016-05-22 11:37:08 --> Loader Class Initialized
INFO - 2016-05-22 11:37:08 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:08 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:08 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:08 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:08 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:08 --> Controller Class Initialized
INFO - 2016-05-22 11:37:08 --> Model Class Initialized
INFO - 2016-05-22 11:37:08 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:08 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:08 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:08 --> Total execution time: 0.1383
INFO - 2016-05-22 11:37:09 --> Config Class Initialized
INFO - 2016-05-22 11:37:09 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:09 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:09 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:09 --> URI Class Initialized
INFO - 2016-05-22 11:37:09 --> Router Class Initialized
INFO - 2016-05-22 11:37:09 --> Output Class Initialized
INFO - 2016-05-22 11:37:09 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:09 --> Input Class Initialized
INFO - 2016-05-22 11:37:09 --> Language Class Initialized
INFO - 2016-05-22 11:37:09 --> Loader Class Initialized
INFO - 2016-05-22 11:37:09 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:09 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:09 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:09 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:09 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:09 --> Controller Class Initialized
INFO - 2016-05-22 11:37:09 --> Model Class Initialized
INFO - 2016-05-22 11:37:09 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:09 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:37:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:09 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:09 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:37:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-22 11:37:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:37:09 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:09 --> Total execution time: 0.1005
INFO - 2016-05-22 11:37:10 --> Config Class Initialized
INFO - 2016-05-22 11:37:10 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:10 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:10 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:10 --> URI Class Initialized
INFO - 2016-05-22 11:37:10 --> Router Class Initialized
INFO - 2016-05-22 11:37:10 --> Output Class Initialized
INFO - 2016-05-22 11:37:10 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:10 --> Input Class Initialized
INFO - 2016-05-22 11:37:10 --> Language Class Initialized
INFO - 2016-05-22 11:37:10 --> Loader Class Initialized
INFO - 2016-05-22 11:37:10 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:10 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:10 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:10 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:10 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:10 --> Controller Class Initialized
INFO - 2016-05-22 11:37:10 --> Model Class Initialized
INFO - 2016-05-22 11:37:10 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:10 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:10 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:10 --> Total execution time: 0.1049
INFO - 2016-05-22 11:37:13 --> Config Class Initialized
INFO - 2016-05-22 11:37:13 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:13 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:13 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:13 --> URI Class Initialized
INFO - 2016-05-22 11:37:13 --> Router Class Initialized
INFO - 2016-05-22 11:37:13 --> Output Class Initialized
INFO - 2016-05-22 11:37:13 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:13 --> Input Class Initialized
INFO - 2016-05-22 11:37:13 --> Language Class Initialized
INFO - 2016-05-22 11:37:13 --> Loader Class Initialized
INFO - 2016-05-22 11:37:13 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:13 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:13 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:13 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:13 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:13 --> Controller Class Initialized
INFO - 2016-05-22 11:37:13 --> Model Class Initialized
INFO - 2016-05-22 11:37:13 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:13 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-22 11:37:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:37:13 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:13 --> Total execution time: 0.1005
INFO - 2016-05-22 11:37:13 --> Config Class Initialized
INFO - 2016-05-22 11:37:13 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:13 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:13 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:13 --> URI Class Initialized
INFO - 2016-05-22 11:37:13 --> Router Class Initialized
INFO - 2016-05-22 11:37:13 --> Output Class Initialized
INFO - 2016-05-22 11:37:13 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:13 --> Input Class Initialized
INFO - 2016-05-22 11:37:13 --> Language Class Initialized
INFO - 2016-05-22 11:37:13 --> Loader Class Initialized
INFO - 2016-05-22 11:37:13 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:13 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:13 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:13 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:13 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:13 --> Controller Class Initialized
INFO - 2016-05-22 11:37:13 --> Model Class Initialized
INFO - 2016-05-22 11:37:13 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:13 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:13 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:13 --> Total execution time: 0.0865
INFO - 2016-05-22 11:37:14 --> Config Class Initialized
INFO - 2016-05-22 11:37:14 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:14 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:14 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:14 --> URI Class Initialized
INFO - 2016-05-22 11:37:14 --> Router Class Initialized
INFO - 2016-05-22 11:37:14 --> Output Class Initialized
INFO - 2016-05-22 11:37:14 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:14 --> Input Class Initialized
INFO - 2016-05-22 11:37:14 --> Language Class Initialized
INFO - 2016-05-22 11:37:14 --> Loader Class Initialized
INFO - 2016-05-22 11:37:14 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:14 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:14 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:14 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:14 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:14 --> Controller Class Initialized
INFO - 2016-05-22 11:37:14 --> Model Class Initialized
INFO - 2016-05-22 11:37:14 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:37:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:14 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:14 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:37:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-22 11:37:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:37:14 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:14 --> Total execution time: 0.0944
INFO - 2016-05-22 11:37:14 --> Config Class Initialized
INFO - 2016-05-22 11:37:14 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:14 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:14 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:14 --> URI Class Initialized
INFO - 2016-05-22 11:37:14 --> Router Class Initialized
INFO - 2016-05-22 11:37:14 --> Output Class Initialized
INFO - 2016-05-22 11:37:14 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:14 --> Input Class Initialized
INFO - 2016-05-22 11:37:15 --> Language Class Initialized
INFO - 2016-05-22 11:37:15 --> Loader Class Initialized
INFO - 2016-05-22 11:37:15 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:15 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:15 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:15 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:15 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:15 --> Controller Class Initialized
INFO - 2016-05-22 11:37:15 --> Model Class Initialized
INFO - 2016-05-22 11:37:15 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:15 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:15 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:15 --> Total execution time: 0.1206
INFO - 2016-05-22 11:37:17 --> Config Class Initialized
INFO - 2016-05-22 11:37:17 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:17 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:17 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:18 --> URI Class Initialized
INFO - 2016-05-22 11:37:18 --> Router Class Initialized
INFO - 2016-05-22 11:37:18 --> Output Class Initialized
INFO - 2016-05-22 11:37:18 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:18 --> Input Class Initialized
INFO - 2016-05-22 11:37:18 --> Language Class Initialized
INFO - 2016-05-22 11:37:18 --> Loader Class Initialized
INFO - 2016-05-22 11:37:18 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:18 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:18 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:18 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:18 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:18 --> Controller Class Initialized
INFO - 2016-05-22 11:37:18 --> Model Class Initialized
INFO - 2016-05-22 11:37:18 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:18 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:37:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:18 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-22 11:37:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:37:18 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:18 --> Total execution time: 0.2338
INFO - 2016-05-22 11:37:18 --> Config Class Initialized
INFO - 2016-05-22 11:37:18 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:18 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:18 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:18 --> URI Class Initialized
INFO - 2016-05-22 11:37:18 --> Router Class Initialized
INFO - 2016-05-22 11:37:18 --> Output Class Initialized
INFO - 2016-05-22 11:37:18 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:18 --> Input Class Initialized
INFO - 2016-05-22 11:37:18 --> Language Class Initialized
INFO - 2016-05-22 11:37:18 --> Loader Class Initialized
INFO - 2016-05-22 11:37:18 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:18 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:18 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:18 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:18 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:18 --> Controller Class Initialized
INFO - 2016-05-22 11:37:18 --> Model Class Initialized
INFO - 2016-05-22 11:37:18 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:18 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:18 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:18 --> Total execution time: 0.0867
INFO - 2016-05-22 11:37:20 --> Config Class Initialized
INFO - 2016-05-22 11:37:20 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:20 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:20 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:20 --> URI Class Initialized
INFO - 2016-05-22 11:37:20 --> Router Class Initialized
INFO - 2016-05-22 11:37:20 --> Output Class Initialized
INFO - 2016-05-22 11:37:20 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:20 --> Input Class Initialized
INFO - 2016-05-22 11:37:20 --> Language Class Initialized
INFO - 2016-05-22 11:37:20 --> Loader Class Initialized
INFO - 2016-05-22 11:37:20 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:20 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:20 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:20 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:20 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:20 --> Controller Class Initialized
INFO - 2016-05-22 11:37:20 --> Model Class Initialized
INFO - 2016-05-22 11:37:20 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:37:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:20 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-22 11:37:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:37:20 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:20 --> Total execution time: 0.1124
INFO - 2016-05-22 11:37:20 --> Config Class Initialized
INFO - 2016-05-22 11:37:20 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:20 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:20 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:20 --> URI Class Initialized
INFO - 2016-05-22 11:37:20 --> Router Class Initialized
INFO - 2016-05-22 11:37:20 --> Output Class Initialized
INFO - 2016-05-22 11:37:20 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:20 --> Input Class Initialized
INFO - 2016-05-22 11:37:20 --> Language Class Initialized
INFO - 2016-05-22 11:37:20 --> Loader Class Initialized
INFO - 2016-05-22 11:37:20 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:20 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:20 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:20 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:20 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:20 --> Controller Class Initialized
INFO - 2016-05-22 11:37:20 --> Model Class Initialized
INFO - 2016-05-22 11:37:20 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:20 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:20 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:20 --> Total execution time: 0.0895
INFO - 2016-05-22 11:37:22 --> Config Class Initialized
INFO - 2016-05-22 11:37:22 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:22 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:22 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:22 --> URI Class Initialized
INFO - 2016-05-22 11:37:22 --> Router Class Initialized
INFO - 2016-05-22 11:37:22 --> Output Class Initialized
INFO - 2016-05-22 11:37:22 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:22 --> Input Class Initialized
INFO - 2016-05-22 11:37:22 --> Language Class Initialized
INFO - 2016-05-22 11:37:22 --> Loader Class Initialized
INFO - 2016-05-22 11:37:22 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:22 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:22 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:22 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:22 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:22 --> Controller Class Initialized
INFO - 2016-05-22 11:37:22 --> Model Class Initialized
INFO - 2016-05-22 11:37:22 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:22 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:37:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:22 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-22 11:37:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:37:22 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:22 --> Total execution time: 0.1104
INFO - 2016-05-22 11:37:22 --> Config Class Initialized
INFO - 2016-05-22 11:37:22 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:22 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:22 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:23 --> URI Class Initialized
INFO - 2016-05-22 11:37:23 --> Router Class Initialized
INFO - 2016-05-22 11:37:23 --> Output Class Initialized
INFO - 2016-05-22 11:37:23 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:23 --> Input Class Initialized
INFO - 2016-05-22 11:37:23 --> Language Class Initialized
INFO - 2016-05-22 11:37:23 --> Loader Class Initialized
INFO - 2016-05-22 11:37:23 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:23 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:23 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:23 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:23 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:23 --> Controller Class Initialized
INFO - 2016-05-22 11:37:23 --> Model Class Initialized
INFO - 2016-05-22 11:37:23 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:23 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:23 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:23 --> Total execution time: 0.1102
INFO - 2016-05-22 11:37:31 --> Config Class Initialized
INFO - 2016-05-22 11:37:31 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:31 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:31 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:31 --> URI Class Initialized
INFO - 2016-05-22 11:37:31 --> Router Class Initialized
INFO - 2016-05-22 11:37:31 --> Output Class Initialized
INFO - 2016-05-22 11:37:31 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:31 --> Input Class Initialized
INFO - 2016-05-22 11:37:31 --> Language Class Initialized
INFO - 2016-05-22 11:37:31 --> Loader Class Initialized
INFO - 2016-05-22 11:37:31 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:31 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:31 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:31 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:31 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:31 --> Controller Class Initialized
INFO - 2016-05-22 11:37:31 --> Model Class Initialized
INFO - 2016-05-22 11:37:31 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:31 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:37:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:31 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:31 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:37:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-22 11:37:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:37:31 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:31 --> Total execution time: 0.0844
INFO - 2016-05-22 11:37:31 --> Config Class Initialized
INFO - 2016-05-22 11:37:31 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:31 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:31 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:31 --> URI Class Initialized
INFO - 2016-05-22 11:37:31 --> Router Class Initialized
INFO - 2016-05-22 11:37:31 --> Output Class Initialized
INFO - 2016-05-22 11:37:31 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:31 --> Input Class Initialized
INFO - 2016-05-22 11:37:31 --> Language Class Initialized
INFO - 2016-05-22 11:37:31 --> Loader Class Initialized
INFO - 2016-05-22 11:37:31 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:31 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:31 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:31 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:31 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:31 --> Controller Class Initialized
INFO - 2016-05-22 11:37:31 --> Model Class Initialized
INFO - 2016-05-22 11:37:31 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:31 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:31 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:31 --> Total execution time: 0.0873
INFO - 2016-05-22 11:37:36 --> Config Class Initialized
INFO - 2016-05-22 11:37:36 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:36 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:36 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:36 --> URI Class Initialized
INFO - 2016-05-22 11:37:36 --> Router Class Initialized
INFO - 2016-05-22 11:37:36 --> Output Class Initialized
INFO - 2016-05-22 11:37:36 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:36 --> Input Class Initialized
INFO - 2016-05-22 11:37:36 --> Language Class Initialized
INFO - 2016-05-22 11:37:36 --> Loader Class Initialized
INFO - 2016-05-22 11:37:36 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:36 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:36 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:36 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:36 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:36 --> Controller Class Initialized
INFO - 2016-05-22 11:37:36 --> Model Class Initialized
INFO - 2016-05-22 11:37:36 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:37:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:36 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:36 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:37:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-22 11:37:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:37:36 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:36 --> Total execution time: 0.0860
INFO - 2016-05-22 11:37:36 --> Config Class Initialized
INFO - 2016-05-22 11:37:36 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:36 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:36 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:36 --> URI Class Initialized
INFO - 2016-05-22 11:37:36 --> Router Class Initialized
INFO - 2016-05-22 11:37:36 --> Output Class Initialized
INFO - 2016-05-22 11:37:36 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:36 --> Input Class Initialized
INFO - 2016-05-22 11:37:36 --> Language Class Initialized
INFO - 2016-05-22 11:37:36 --> Loader Class Initialized
INFO - 2016-05-22 11:37:36 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:36 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:36 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:36 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:36 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:36 --> Controller Class Initialized
INFO - 2016-05-22 11:37:36 --> Model Class Initialized
INFO - 2016-05-22 11:37:36 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:36 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:36 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:36 --> Total execution time: 0.0915
INFO - 2016-05-22 11:37:49 --> Config Class Initialized
INFO - 2016-05-22 11:37:49 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:49 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:49 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:49 --> URI Class Initialized
INFO - 2016-05-22 11:37:49 --> Router Class Initialized
INFO - 2016-05-22 11:37:49 --> Output Class Initialized
INFO - 2016-05-22 11:37:49 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:49 --> Input Class Initialized
INFO - 2016-05-22 11:37:49 --> Language Class Initialized
INFO - 2016-05-22 11:37:49 --> Loader Class Initialized
INFO - 2016-05-22 11:37:49 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:49 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:49 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:49 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:49 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:49 --> Controller Class Initialized
INFO - 2016-05-22 11:37:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-22 11:37:49 --> Model Class Initialized
INFO - 2016-05-22 11:37:49 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:37:49 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:49 --> Total execution time: 0.0800
INFO - 2016-05-22 11:37:49 --> Config Class Initialized
INFO - 2016-05-22 11:37:49 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:37:49 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:37:49 --> Utf8 Class Initialized
INFO - 2016-05-22 11:37:49 --> URI Class Initialized
INFO - 2016-05-22 11:37:49 --> Router Class Initialized
INFO - 2016-05-22 11:37:49 --> Output Class Initialized
INFO - 2016-05-22 11:37:49 --> Security Class Initialized
DEBUG - 2016-05-22 11:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:37:49 --> Input Class Initialized
INFO - 2016-05-22 11:37:49 --> Language Class Initialized
INFO - 2016-05-22 11:37:49 --> Loader Class Initialized
INFO - 2016-05-22 11:37:49 --> Helper loaded: url_helper
INFO - 2016-05-22 11:37:49 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:37:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:37:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:37:49 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:37:49 --> Helper loaded: form_helper
INFO - 2016-05-22 11:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:37:49 --> Form Validation Class Initialized
INFO - 2016-05-22 11:37:49 --> Controller Class Initialized
INFO - 2016-05-22 11:37:49 --> Model Class Initialized
INFO - 2016-05-22 11:37:49 --> Database Driver Class Initialized
INFO - 2016-05-22 11:37:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:37:49 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:37:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:37:49 --> Final output sent to browser
DEBUG - 2016-05-22 11:37:49 --> Total execution time: 0.0857
INFO - 2016-05-22 11:38:27 --> Config Class Initialized
INFO - 2016-05-22 11:38:27 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:38:27 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:38:27 --> Utf8 Class Initialized
INFO - 2016-05-22 11:38:27 --> URI Class Initialized
INFO - 2016-05-22 11:38:27 --> Router Class Initialized
INFO - 2016-05-22 11:38:27 --> Output Class Initialized
INFO - 2016-05-22 11:38:27 --> Security Class Initialized
DEBUG - 2016-05-22 11:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:38:27 --> Input Class Initialized
INFO - 2016-05-22 11:38:27 --> Language Class Initialized
INFO - 2016-05-22 11:38:27 --> Loader Class Initialized
INFO - 2016-05-22 11:38:27 --> Helper loaded: url_helper
INFO - 2016-05-22 11:38:27 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:38:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:38:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:38:27 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:38:27 --> Helper loaded: form_helper
INFO - 2016-05-22 11:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:38:27 --> Form Validation Class Initialized
INFO - 2016-05-22 11:38:27 --> Controller Class Initialized
INFO - 2016-05-22 11:38:27 --> Model Class Initialized
INFO - 2016-05-22 11:38:27 --> Database Driver Class Initialized
INFO - 2016-05-22 11:38:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:38:27 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:38:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:38:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:38:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:38:27 --> Final output sent to browser
DEBUG - 2016-05-22 11:38:27 --> Total execution time: 0.1134
INFO - 2016-05-22 11:38:27 --> Config Class Initialized
INFO - 2016-05-22 11:38:27 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:38:27 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:38:27 --> Utf8 Class Initialized
INFO - 2016-05-22 11:38:27 --> URI Class Initialized
INFO - 2016-05-22 11:38:27 --> Router Class Initialized
INFO - 2016-05-22 11:38:27 --> Output Class Initialized
INFO - 2016-05-22 11:38:27 --> Security Class Initialized
DEBUG - 2016-05-22 11:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:38:27 --> Input Class Initialized
INFO - 2016-05-22 11:38:27 --> Language Class Initialized
INFO - 2016-05-22 11:38:27 --> Loader Class Initialized
INFO - 2016-05-22 11:38:27 --> Helper loaded: url_helper
INFO - 2016-05-22 11:38:27 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:38:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:38:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:38:27 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:38:27 --> Helper loaded: form_helper
INFO - 2016-05-22 11:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:38:27 --> Form Validation Class Initialized
INFO - 2016-05-22 11:38:27 --> Controller Class Initialized
INFO - 2016-05-22 11:38:27 --> Model Class Initialized
INFO - 2016-05-22 11:38:27 --> Database Driver Class Initialized
INFO - 2016-05-22 11:38:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:38:27 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:38:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:38:27 --> Final output sent to browser
DEBUG - 2016-05-22 11:38:27 --> Total execution time: 0.0876
INFO - 2016-05-22 11:38:37 --> Config Class Initialized
INFO - 2016-05-22 11:38:37 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:38:37 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:38:37 --> Utf8 Class Initialized
INFO - 2016-05-22 11:38:37 --> URI Class Initialized
INFO - 2016-05-22 11:38:37 --> Router Class Initialized
INFO - 2016-05-22 11:38:37 --> Output Class Initialized
INFO - 2016-05-22 11:38:37 --> Security Class Initialized
DEBUG - 2016-05-22 11:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:38:37 --> Input Class Initialized
INFO - 2016-05-22 11:38:37 --> Language Class Initialized
INFO - 2016-05-22 11:38:37 --> Loader Class Initialized
INFO - 2016-05-22 11:38:37 --> Helper loaded: url_helper
INFO - 2016-05-22 11:38:37 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:38:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:38:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:38:37 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:38:37 --> Helper loaded: form_helper
INFO - 2016-05-22 11:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:38:37 --> Form Validation Class Initialized
INFO - 2016-05-22 11:38:37 --> Controller Class Initialized
INFO - 2016-05-22 11:38:37 --> Model Class Initialized
INFO - 2016-05-22 11:38:37 --> Database Driver Class Initialized
INFO - 2016-05-22 11:38:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:38:37 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:38:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:38:37 --> Final output sent to browser
DEBUG - 2016-05-22 11:38:37 --> Total execution time: 0.0764
INFO - 2016-05-22 11:38:38 --> Config Class Initialized
INFO - 2016-05-22 11:38:38 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:38:38 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:38:38 --> Utf8 Class Initialized
INFO - 2016-05-22 11:38:38 --> URI Class Initialized
INFO - 2016-05-22 11:38:38 --> Router Class Initialized
INFO - 2016-05-22 11:38:38 --> Output Class Initialized
INFO - 2016-05-22 11:38:38 --> Security Class Initialized
DEBUG - 2016-05-22 11:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:38:38 --> Input Class Initialized
INFO - 2016-05-22 11:38:38 --> Language Class Initialized
INFO - 2016-05-22 11:38:38 --> Loader Class Initialized
INFO - 2016-05-22 11:38:38 --> Helper loaded: url_helper
INFO - 2016-05-22 11:38:38 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:38:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:38:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:38:38 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:38:38 --> Helper loaded: form_helper
INFO - 2016-05-22 11:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:38:38 --> Form Validation Class Initialized
INFO - 2016-05-22 11:38:38 --> Controller Class Initialized
INFO - 2016-05-22 11:38:38 --> Model Class Initialized
INFO - 2016-05-22 11:38:38 --> Database Driver Class Initialized
INFO - 2016-05-22 11:38:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:38:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:38:38 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:38:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:38:38 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:38:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-22 11:38:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:38:38 --> Final output sent to browser
DEBUG - 2016-05-22 11:38:38 --> Total execution time: 0.0845
INFO - 2016-05-22 11:38:38 --> Config Class Initialized
INFO - 2016-05-22 11:38:38 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:38:38 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:38:38 --> Utf8 Class Initialized
INFO - 2016-05-22 11:38:38 --> URI Class Initialized
INFO - 2016-05-22 11:38:38 --> Router Class Initialized
INFO - 2016-05-22 11:38:38 --> Output Class Initialized
INFO - 2016-05-22 11:38:38 --> Security Class Initialized
DEBUG - 2016-05-22 11:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:38:38 --> Input Class Initialized
INFO - 2016-05-22 11:38:38 --> Language Class Initialized
INFO - 2016-05-22 11:38:38 --> Loader Class Initialized
INFO - 2016-05-22 11:38:38 --> Helper loaded: url_helper
INFO - 2016-05-22 11:38:38 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:38:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:38:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:38:38 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:38:38 --> Helper loaded: form_helper
INFO - 2016-05-22 11:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:38:38 --> Form Validation Class Initialized
INFO - 2016-05-22 11:38:38 --> Controller Class Initialized
INFO - 2016-05-22 11:38:38 --> Model Class Initialized
INFO - 2016-05-22 11:38:38 --> Database Driver Class Initialized
INFO - 2016-05-22 11:38:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:38:38 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:38:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:38:38 --> Final output sent to browser
DEBUG - 2016-05-22 11:38:38 --> Total execution time: 0.1192
INFO - 2016-05-22 11:38:39 --> Config Class Initialized
INFO - 2016-05-22 11:38:39 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:38:39 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:38:39 --> Utf8 Class Initialized
INFO - 2016-05-22 11:38:39 --> URI Class Initialized
INFO - 2016-05-22 11:38:39 --> Router Class Initialized
INFO - 2016-05-22 11:38:39 --> Output Class Initialized
INFO - 2016-05-22 11:38:39 --> Security Class Initialized
DEBUG - 2016-05-22 11:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:38:39 --> Input Class Initialized
INFO - 2016-05-22 11:38:39 --> Language Class Initialized
INFO - 2016-05-22 11:38:39 --> Loader Class Initialized
INFO - 2016-05-22 11:38:39 --> Helper loaded: url_helper
INFO - 2016-05-22 11:38:39 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:38:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:38:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:38:39 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:38:39 --> Helper loaded: form_helper
INFO - 2016-05-22 11:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:38:39 --> Form Validation Class Initialized
INFO - 2016-05-22 11:38:39 --> Controller Class Initialized
INFO - 2016-05-22 11:38:39 --> Model Class Initialized
INFO - 2016-05-22 11:38:39 --> Database Driver Class Initialized
INFO - 2016-05-22 11:38:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:38:39 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:38:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:38:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:38:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:38:39 --> Final output sent to browser
DEBUG - 2016-05-22 11:38:39 --> Total execution time: 0.0839
INFO - 2016-05-22 11:38:40 --> Config Class Initialized
INFO - 2016-05-22 11:38:40 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:38:40 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:38:40 --> Utf8 Class Initialized
INFO - 2016-05-22 11:38:40 --> URI Class Initialized
INFO - 2016-05-22 11:38:40 --> Router Class Initialized
INFO - 2016-05-22 11:38:40 --> Output Class Initialized
INFO - 2016-05-22 11:38:40 --> Security Class Initialized
DEBUG - 2016-05-22 11:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:38:40 --> Input Class Initialized
INFO - 2016-05-22 11:38:40 --> Language Class Initialized
INFO - 2016-05-22 11:38:40 --> Loader Class Initialized
INFO - 2016-05-22 11:38:40 --> Helper loaded: url_helper
INFO - 2016-05-22 11:38:40 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:38:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:38:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:38:40 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:38:40 --> Helper loaded: form_helper
INFO - 2016-05-22 11:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:38:40 --> Form Validation Class Initialized
INFO - 2016-05-22 11:38:40 --> Controller Class Initialized
INFO - 2016-05-22 11:38:40 --> Model Class Initialized
INFO - 2016-05-22 11:38:40 --> Database Driver Class Initialized
INFO - 2016-05-22 11:38:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:38:40 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:38:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:38:40 --> Final output sent to browser
DEBUG - 2016-05-22 11:38:40 --> Total execution time: 0.1032
INFO - 2016-05-22 11:38:46 --> Config Class Initialized
INFO - 2016-05-22 11:38:46 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:38:46 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:38:46 --> Utf8 Class Initialized
INFO - 2016-05-22 11:38:46 --> URI Class Initialized
INFO - 2016-05-22 11:38:46 --> Router Class Initialized
INFO - 2016-05-22 11:38:46 --> Output Class Initialized
INFO - 2016-05-22 11:38:46 --> Security Class Initialized
DEBUG - 2016-05-22 11:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:38:46 --> Input Class Initialized
INFO - 2016-05-22 11:38:46 --> Language Class Initialized
INFO - 2016-05-22 11:38:46 --> Loader Class Initialized
INFO - 2016-05-22 11:38:46 --> Helper loaded: url_helper
INFO - 2016-05-22 11:38:46 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:38:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:38:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:38:46 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:38:46 --> Helper loaded: form_helper
INFO - 2016-05-22 11:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:38:46 --> Form Validation Class Initialized
INFO - 2016-05-22 11:38:46 --> Controller Class Initialized
INFO - 2016-05-22 11:38:46 --> Model Class Initialized
INFO - 2016-05-22 11:38:46 --> Database Driver Class Initialized
INFO - 2016-05-22 11:38:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:38:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:38:46 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:38:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:38:46 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:38:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-22 11:38:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:38:46 --> Final output sent to browser
DEBUG - 2016-05-22 11:38:46 --> Total execution time: 0.0841
INFO - 2016-05-22 11:38:47 --> Config Class Initialized
INFO - 2016-05-22 11:38:47 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:38:47 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:38:47 --> Utf8 Class Initialized
INFO - 2016-05-22 11:38:47 --> URI Class Initialized
INFO - 2016-05-22 11:38:47 --> Router Class Initialized
INFO - 2016-05-22 11:38:47 --> Output Class Initialized
INFO - 2016-05-22 11:38:47 --> Security Class Initialized
DEBUG - 2016-05-22 11:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:38:47 --> Input Class Initialized
INFO - 2016-05-22 11:38:47 --> Language Class Initialized
INFO - 2016-05-22 11:38:47 --> Loader Class Initialized
INFO - 2016-05-22 11:38:47 --> Helper loaded: url_helper
INFO - 2016-05-22 11:38:47 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:38:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:38:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:38:47 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:38:47 --> Helper loaded: form_helper
INFO - 2016-05-22 11:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:38:47 --> Form Validation Class Initialized
INFO - 2016-05-22 11:38:47 --> Controller Class Initialized
INFO - 2016-05-22 11:38:47 --> Model Class Initialized
INFO - 2016-05-22 11:38:47 --> Database Driver Class Initialized
INFO - 2016-05-22 11:38:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:38:47 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:38:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:38:47 --> Final output sent to browser
DEBUG - 2016-05-22 11:38:47 --> Total execution time: 0.0890
INFO - 2016-05-22 11:39:06 --> Config Class Initialized
INFO - 2016-05-22 11:39:06 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:06 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:06 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:06 --> URI Class Initialized
INFO - 2016-05-22 11:39:06 --> Router Class Initialized
INFO - 2016-05-22 11:39:06 --> Output Class Initialized
INFO - 2016-05-22 11:39:06 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:06 --> Input Class Initialized
INFO - 2016-05-22 11:39:06 --> Language Class Initialized
INFO - 2016-05-22 11:39:06 --> Loader Class Initialized
INFO - 2016-05-22 11:39:06 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:06 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:06 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:06 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:06 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:06 --> Controller Class Initialized
INFO - 2016-05-22 11:39:06 --> Model Class Initialized
INFO - 2016-05-22 11:39:06 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:06 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:39:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:06 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:06 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:39:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-22 11:39:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:39:06 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:06 --> Total execution time: 0.1516
INFO - 2016-05-22 11:39:06 --> Config Class Initialized
INFO - 2016-05-22 11:39:06 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:06 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:06 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:06 --> URI Class Initialized
INFO - 2016-05-22 11:39:06 --> Router Class Initialized
INFO - 2016-05-22 11:39:06 --> Output Class Initialized
INFO - 2016-05-22 11:39:06 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:06 --> Input Class Initialized
INFO - 2016-05-22 11:39:06 --> Language Class Initialized
INFO - 2016-05-22 11:39:06 --> Loader Class Initialized
INFO - 2016-05-22 11:39:06 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:06 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:06 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:06 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:06 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:06 --> Controller Class Initialized
INFO - 2016-05-22 11:39:06 --> Model Class Initialized
INFO - 2016-05-22 11:39:06 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:06 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:06 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:06 --> Total execution time: 0.0864
INFO - 2016-05-22 11:39:10 --> Config Class Initialized
INFO - 2016-05-22 11:39:10 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:10 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:10 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:10 --> URI Class Initialized
INFO - 2016-05-22 11:39:10 --> Router Class Initialized
INFO - 2016-05-22 11:39:10 --> Output Class Initialized
INFO - 2016-05-22 11:39:10 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:10 --> Input Class Initialized
INFO - 2016-05-22 11:39:10 --> Language Class Initialized
INFO - 2016-05-22 11:39:10 --> Loader Class Initialized
INFO - 2016-05-22 11:39:10 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:10 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:10 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:10 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:10 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:10 --> Controller Class Initialized
INFO - 2016-05-22 11:39:10 --> Model Class Initialized
INFO - 2016-05-22 11:39:10 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:39:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:10 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:10 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:39:10 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 11:39:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-22 11:39:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:39:10 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:10 --> Total execution time: 0.1661
INFO - 2016-05-22 11:39:10 --> Config Class Initialized
INFO - 2016-05-22 11:39:10 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:10 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:10 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:10 --> URI Class Initialized
INFO - 2016-05-22 11:39:10 --> Router Class Initialized
INFO - 2016-05-22 11:39:10 --> Output Class Initialized
INFO - 2016-05-22 11:39:10 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:10 --> Input Class Initialized
INFO - 2016-05-22 11:39:10 --> Language Class Initialized
INFO - 2016-05-22 11:39:10 --> Loader Class Initialized
INFO - 2016-05-22 11:39:10 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:10 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:10 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:10 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:10 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:10 --> Controller Class Initialized
INFO - 2016-05-22 11:39:10 --> Model Class Initialized
INFO - 2016-05-22 11:39:10 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:10 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:10 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:10 --> Total execution time: 0.0947
INFO - 2016-05-22 11:39:12 --> Config Class Initialized
INFO - 2016-05-22 11:39:12 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:12 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:12 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:12 --> URI Class Initialized
INFO - 2016-05-22 11:39:12 --> Router Class Initialized
INFO - 2016-05-22 11:39:12 --> Output Class Initialized
INFO - 2016-05-22 11:39:12 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:12 --> Input Class Initialized
INFO - 2016-05-22 11:39:12 --> Language Class Initialized
INFO - 2016-05-22 11:39:12 --> Loader Class Initialized
INFO - 2016-05-22 11:39:12 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:12 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:12 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:12 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:12 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:12 --> Controller Class Initialized
INFO - 2016-05-22 11:39:12 --> Model Class Initialized
INFO - 2016-05-22 11:39:12 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:39:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:12 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:12 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:39:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-22 11:39:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:39:12 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:12 --> Total execution time: 0.1091
INFO - 2016-05-22 11:39:12 --> Config Class Initialized
INFO - 2016-05-22 11:39:12 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:12 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:12 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:12 --> URI Class Initialized
INFO - 2016-05-22 11:39:12 --> Router Class Initialized
INFO - 2016-05-22 11:39:12 --> Output Class Initialized
INFO - 2016-05-22 11:39:12 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:12 --> Input Class Initialized
INFO - 2016-05-22 11:39:12 --> Language Class Initialized
INFO - 2016-05-22 11:39:12 --> Loader Class Initialized
INFO - 2016-05-22 11:39:12 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:12 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:12 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:12 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:12 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:12 --> Controller Class Initialized
INFO - 2016-05-22 11:39:12 --> Model Class Initialized
INFO - 2016-05-22 11:39:12 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:12 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:12 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:12 --> Total execution time: 0.0958
INFO - 2016-05-22 11:39:16 --> Config Class Initialized
INFO - 2016-05-22 11:39:16 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:16 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:16 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:16 --> URI Class Initialized
INFO - 2016-05-22 11:39:16 --> Router Class Initialized
INFO - 2016-05-22 11:39:16 --> Output Class Initialized
INFO - 2016-05-22 11:39:16 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:16 --> Input Class Initialized
INFO - 2016-05-22 11:39:16 --> Language Class Initialized
INFO - 2016-05-22 11:39:16 --> Loader Class Initialized
INFO - 2016-05-22 11:39:16 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:16 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:16 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:16 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:16 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:16 --> Controller Class Initialized
INFO - 2016-05-22 11:39:16 --> Model Class Initialized
INFO - 2016-05-22 11:39:16 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:16 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:39:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:16 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:16 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:39:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-22 11:39:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:39:16 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:16 --> Total execution time: 0.1007
INFO - 2016-05-22 11:39:16 --> Config Class Initialized
INFO - 2016-05-22 11:39:16 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:16 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:16 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:16 --> URI Class Initialized
INFO - 2016-05-22 11:39:16 --> Router Class Initialized
INFO - 2016-05-22 11:39:16 --> Output Class Initialized
INFO - 2016-05-22 11:39:16 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:16 --> Input Class Initialized
INFO - 2016-05-22 11:39:16 --> Language Class Initialized
INFO - 2016-05-22 11:39:16 --> Loader Class Initialized
INFO - 2016-05-22 11:39:16 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:16 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:16 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:16 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:16 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:16 --> Controller Class Initialized
INFO - 2016-05-22 11:39:16 --> Model Class Initialized
INFO - 2016-05-22 11:39:16 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:16 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:16 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:16 --> Total execution time: 0.1059
INFO - 2016-05-22 11:39:22 --> Config Class Initialized
INFO - 2016-05-22 11:39:22 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:22 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:22 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:22 --> URI Class Initialized
INFO - 2016-05-22 11:39:22 --> Router Class Initialized
INFO - 2016-05-22 11:39:22 --> Output Class Initialized
INFO - 2016-05-22 11:39:22 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:22 --> Input Class Initialized
INFO - 2016-05-22 11:39:22 --> Language Class Initialized
INFO - 2016-05-22 11:39:22 --> Loader Class Initialized
INFO - 2016-05-22 11:39:22 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:22 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:22 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:22 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:22 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:22 --> Controller Class Initialized
INFO - 2016-05-22 11:39:22 --> Model Class Initialized
INFO - 2016-05-22 11:39:22 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:22 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:39:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:22 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:22 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:39:22 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 11:39:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-22 11:39:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:39:22 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:22 --> Total execution time: 0.1625
INFO - 2016-05-22 11:39:22 --> Config Class Initialized
INFO - 2016-05-22 11:39:22 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:22 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:22 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:22 --> URI Class Initialized
INFO - 2016-05-22 11:39:22 --> Router Class Initialized
INFO - 2016-05-22 11:39:22 --> Output Class Initialized
INFO - 2016-05-22 11:39:22 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:22 --> Input Class Initialized
INFO - 2016-05-22 11:39:22 --> Language Class Initialized
INFO - 2016-05-22 11:39:22 --> Loader Class Initialized
INFO - 2016-05-22 11:39:22 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:22 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:22 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:22 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:22 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:22 --> Controller Class Initialized
INFO - 2016-05-22 11:39:22 --> Model Class Initialized
INFO - 2016-05-22 11:39:23 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:23 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:23 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:23 --> Total execution time: 0.0852
INFO - 2016-05-22 11:39:25 --> Config Class Initialized
INFO - 2016-05-22 11:39:25 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:25 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:25 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:25 --> URI Class Initialized
INFO - 2016-05-22 11:39:25 --> Router Class Initialized
INFO - 2016-05-22 11:39:25 --> Output Class Initialized
INFO - 2016-05-22 11:39:25 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:25 --> Input Class Initialized
INFO - 2016-05-22 11:39:25 --> Language Class Initialized
INFO - 2016-05-22 11:39:25 --> Loader Class Initialized
INFO - 2016-05-22 11:39:25 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:25 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:25 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:25 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:25 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:25 --> Controller Class Initialized
INFO - 2016-05-22 11:39:25 --> Model Class Initialized
INFO - 2016-05-22 11:39:25 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:25 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:39:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:25 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:25 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:39:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-22 11:39:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:39:25 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:25 --> Total execution time: 0.0993
INFO - 2016-05-22 11:39:25 --> Config Class Initialized
INFO - 2016-05-22 11:39:25 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:25 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:25 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:25 --> URI Class Initialized
INFO - 2016-05-22 11:39:25 --> Router Class Initialized
INFO - 2016-05-22 11:39:25 --> Output Class Initialized
INFO - 2016-05-22 11:39:25 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:25 --> Input Class Initialized
INFO - 2016-05-22 11:39:25 --> Language Class Initialized
INFO - 2016-05-22 11:39:25 --> Loader Class Initialized
INFO - 2016-05-22 11:39:25 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:25 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:25 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:25 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:25 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:25 --> Controller Class Initialized
INFO - 2016-05-22 11:39:25 --> Model Class Initialized
INFO - 2016-05-22 11:39:25 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:25 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:25 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:25 --> Total execution time: 0.0883
INFO - 2016-05-22 11:39:30 --> Config Class Initialized
INFO - 2016-05-22 11:39:30 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:31 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:31 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:31 --> URI Class Initialized
INFO - 2016-05-22 11:39:31 --> Router Class Initialized
INFO - 2016-05-22 11:39:31 --> Output Class Initialized
INFO - 2016-05-22 11:39:31 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:31 --> Input Class Initialized
INFO - 2016-05-22 11:39:31 --> Language Class Initialized
INFO - 2016-05-22 11:39:31 --> Loader Class Initialized
INFO - 2016-05-22 11:39:31 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:31 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:31 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:31 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:31 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:31 --> Controller Class Initialized
INFO - 2016-05-22 11:39:31 --> Model Class Initialized
INFO - 2016-05-22 11:39:31 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:31 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:39:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:31 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:31 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:39:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-22 11:39:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:39:31 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:31 --> Total execution time: 0.0852
INFO - 2016-05-22 11:39:31 --> Config Class Initialized
INFO - 2016-05-22 11:39:31 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:31 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:31 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:31 --> URI Class Initialized
INFO - 2016-05-22 11:39:31 --> Router Class Initialized
INFO - 2016-05-22 11:39:31 --> Output Class Initialized
INFO - 2016-05-22 11:39:31 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:31 --> Input Class Initialized
INFO - 2016-05-22 11:39:31 --> Language Class Initialized
INFO - 2016-05-22 11:39:31 --> Loader Class Initialized
INFO - 2016-05-22 11:39:31 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:31 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:31 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:31 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:31 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:31 --> Controller Class Initialized
INFO - 2016-05-22 11:39:31 --> Model Class Initialized
INFO - 2016-05-22 11:39:31 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:31 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:31 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:31 --> Total execution time: 0.0904
INFO - 2016-05-22 11:39:40 --> Config Class Initialized
INFO - 2016-05-22 11:39:40 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:40 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:40 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:40 --> URI Class Initialized
INFO - 2016-05-22 11:39:40 --> Router Class Initialized
INFO - 2016-05-22 11:39:40 --> Output Class Initialized
INFO - 2016-05-22 11:39:40 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:40 --> Input Class Initialized
INFO - 2016-05-22 11:39:40 --> Language Class Initialized
INFO - 2016-05-22 11:39:40 --> Loader Class Initialized
INFO - 2016-05-22 11:39:40 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:40 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:40 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:40 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:40 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:40 --> Controller Class Initialized
INFO - 2016-05-22 11:39:40 --> Model Class Initialized
INFO - 2016-05-22 11:39:40 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:40 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:40 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:40 --> Total execution time: 0.0712
INFO - 2016-05-22 11:39:45 --> Config Class Initialized
INFO - 2016-05-22 11:39:45 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:45 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:45 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:45 --> URI Class Initialized
INFO - 2016-05-22 11:39:45 --> Router Class Initialized
INFO - 2016-05-22 11:39:45 --> Output Class Initialized
INFO - 2016-05-22 11:39:45 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:45 --> Input Class Initialized
INFO - 2016-05-22 11:39:45 --> Language Class Initialized
INFO - 2016-05-22 11:39:45 --> Loader Class Initialized
INFO - 2016-05-22 11:39:45 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:45 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:45 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:45 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:45 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:45 --> Controller Class Initialized
INFO - 2016-05-22 11:39:45 --> Model Class Initialized
INFO - 2016-05-22 11:39:45 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:45 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:45 --> Total execution time: 0.1221
INFO - 2016-05-22 11:39:56 --> Config Class Initialized
INFO - 2016-05-22 11:39:56 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:56 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:56 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:56 --> URI Class Initialized
INFO - 2016-05-22 11:39:56 --> Router Class Initialized
INFO - 2016-05-22 11:39:56 --> Output Class Initialized
INFO - 2016-05-22 11:39:56 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:56 --> Input Class Initialized
INFO - 2016-05-22 11:39:56 --> Language Class Initialized
INFO - 2016-05-22 11:39:56 --> Loader Class Initialized
INFO - 2016-05-22 11:39:56 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:56 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:56 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:56 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:56 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:56 --> Controller Class Initialized
INFO - 2016-05-22 11:39:56 --> Model Class Initialized
INFO - 2016-05-22 11:39:56 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:56 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:39:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:39:56 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:56 --> Total execution time: 0.1060
INFO - 2016-05-22 11:39:56 --> Config Class Initialized
INFO - 2016-05-22 11:39:56 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:39:56 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:39:56 --> Utf8 Class Initialized
INFO - 2016-05-22 11:39:56 --> URI Class Initialized
INFO - 2016-05-22 11:39:56 --> Router Class Initialized
INFO - 2016-05-22 11:39:56 --> Output Class Initialized
INFO - 2016-05-22 11:39:56 --> Security Class Initialized
DEBUG - 2016-05-22 11:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:39:56 --> Input Class Initialized
INFO - 2016-05-22 11:39:56 --> Language Class Initialized
INFO - 2016-05-22 11:39:56 --> Loader Class Initialized
INFO - 2016-05-22 11:39:56 --> Helper loaded: url_helper
INFO - 2016-05-22 11:39:56 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:39:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:39:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:39:56 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:39:56 --> Helper loaded: form_helper
INFO - 2016-05-22 11:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:39:56 --> Form Validation Class Initialized
INFO - 2016-05-22 11:39:56 --> Controller Class Initialized
INFO - 2016-05-22 11:39:56 --> Model Class Initialized
INFO - 2016-05-22 11:39:56 --> Database Driver Class Initialized
INFO - 2016-05-22 11:39:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:39:56 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:39:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:39:56 --> Final output sent to browser
DEBUG - 2016-05-22 11:39:56 --> Total execution time: 0.0855
INFO - 2016-05-22 11:40:03 --> Config Class Initialized
INFO - 2016-05-22 11:40:03 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:40:03 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:40:03 --> Utf8 Class Initialized
INFO - 2016-05-22 11:40:03 --> URI Class Initialized
INFO - 2016-05-22 11:40:03 --> Router Class Initialized
INFO - 2016-05-22 11:40:03 --> Output Class Initialized
INFO - 2016-05-22 11:40:03 --> Security Class Initialized
DEBUG - 2016-05-22 11:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:40:03 --> Input Class Initialized
INFO - 2016-05-22 11:40:03 --> Language Class Initialized
INFO - 2016-05-22 11:40:03 --> Loader Class Initialized
INFO - 2016-05-22 11:40:03 --> Helper loaded: url_helper
INFO - 2016-05-22 11:40:03 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:40:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:40:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:40:03 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:40:03 --> Helper loaded: form_helper
INFO - 2016-05-22 11:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:40:03 --> Form Validation Class Initialized
INFO - 2016-05-22 11:40:03 --> Controller Class Initialized
INFO - 2016-05-22 11:40:03 --> Model Class Initialized
INFO - 2016-05-22 11:40:03 --> Database Driver Class Initialized
INFO - 2016-05-22 11:40:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:40:03 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:40:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:40:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:40:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:40:03 --> Final output sent to browser
DEBUG - 2016-05-22 11:40:03 --> Total execution time: 0.0854
INFO - 2016-05-22 11:40:04 --> Config Class Initialized
INFO - 2016-05-22 11:40:04 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:40:04 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:40:04 --> Utf8 Class Initialized
INFO - 2016-05-22 11:40:04 --> URI Class Initialized
INFO - 2016-05-22 11:40:04 --> Router Class Initialized
INFO - 2016-05-22 11:40:04 --> Output Class Initialized
INFO - 2016-05-22 11:40:04 --> Security Class Initialized
DEBUG - 2016-05-22 11:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:40:04 --> Input Class Initialized
INFO - 2016-05-22 11:40:04 --> Language Class Initialized
INFO - 2016-05-22 11:40:04 --> Loader Class Initialized
INFO - 2016-05-22 11:40:04 --> Helper loaded: url_helper
INFO - 2016-05-22 11:40:04 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:40:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:40:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:40:04 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:40:04 --> Helper loaded: form_helper
INFO - 2016-05-22 11:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:40:04 --> Form Validation Class Initialized
INFO - 2016-05-22 11:40:04 --> Controller Class Initialized
INFO - 2016-05-22 11:40:04 --> Model Class Initialized
INFO - 2016-05-22 11:40:04 --> Database Driver Class Initialized
INFO - 2016-05-22 11:40:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:40:04 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:40:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:40:04 --> Final output sent to browser
DEBUG - 2016-05-22 11:40:04 --> Total execution time: 0.0867
INFO - 2016-05-22 11:40:08 --> Config Class Initialized
INFO - 2016-05-22 11:40:08 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:40:08 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:40:08 --> Utf8 Class Initialized
INFO - 2016-05-22 11:40:08 --> URI Class Initialized
INFO - 2016-05-22 11:40:08 --> Router Class Initialized
INFO - 2016-05-22 11:40:08 --> Output Class Initialized
INFO - 2016-05-22 11:40:08 --> Security Class Initialized
DEBUG - 2016-05-22 11:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:40:08 --> Input Class Initialized
INFO - 2016-05-22 11:40:08 --> Language Class Initialized
INFO - 2016-05-22 11:40:08 --> Loader Class Initialized
INFO - 2016-05-22 11:40:08 --> Helper loaded: url_helper
INFO - 2016-05-22 11:40:08 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:40:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:40:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:40:08 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:40:08 --> Helper loaded: form_helper
INFO - 2016-05-22 11:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:40:08 --> Form Validation Class Initialized
INFO - 2016-05-22 11:40:08 --> Controller Class Initialized
INFO - 2016-05-22 11:40:08 --> Model Class Initialized
INFO - 2016-05-22 11:40:08 --> Database Driver Class Initialized
INFO - 2016-05-22 11:40:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-22 11:40:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:40:08 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:40:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:40:08 --> Helper loaded: nif_validate_helper
INFO - 2016-05-22 11:40:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-22 11:40:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:40:08 --> Final output sent to browser
DEBUG - 2016-05-22 11:40:08 --> Total execution time: 0.0840
INFO - 2016-05-22 11:40:09 --> Config Class Initialized
INFO - 2016-05-22 11:40:09 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:40:09 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:40:09 --> Utf8 Class Initialized
INFO - 2016-05-22 11:40:09 --> URI Class Initialized
INFO - 2016-05-22 11:40:09 --> Router Class Initialized
INFO - 2016-05-22 11:40:09 --> Output Class Initialized
INFO - 2016-05-22 11:40:09 --> Security Class Initialized
DEBUG - 2016-05-22 11:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:40:09 --> Input Class Initialized
INFO - 2016-05-22 11:40:09 --> Language Class Initialized
INFO - 2016-05-22 11:40:09 --> Loader Class Initialized
INFO - 2016-05-22 11:40:09 --> Helper loaded: url_helper
INFO - 2016-05-22 11:40:09 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:40:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:40:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:40:09 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:40:09 --> Helper loaded: form_helper
INFO - 2016-05-22 11:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:40:09 --> Form Validation Class Initialized
INFO - 2016-05-22 11:40:09 --> Controller Class Initialized
INFO - 2016-05-22 11:40:09 --> Model Class Initialized
INFO - 2016-05-22 11:40:09 --> Database Driver Class Initialized
INFO - 2016-05-22 11:40:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:40:09 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:40:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:40:09 --> Final output sent to browser
DEBUG - 2016-05-22 11:40:09 --> Total execution time: 0.0911
INFO - 2016-05-22 11:40:10 --> Config Class Initialized
INFO - 2016-05-22 11:40:10 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:40:10 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:40:10 --> Utf8 Class Initialized
INFO - 2016-05-22 11:40:10 --> URI Class Initialized
INFO - 2016-05-22 11:40:10 --> Router Class Initialized
INFO - 2016-05-22 11:40:10 --> Output Class Initialized
INFO - 2016-05-22 11:40:10 --> Security Class Initialized
DEBUG - 2016-05-22 11:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:40:10 --> Input Class Initialized
INFO - 2016-05-22 11:40:10 --> Language Class Initialized
INFO - 2016-05-22 11:40:10 --> Loader Class Initialized
INFO - 2016-05-22 11:40:10 --> Helper loaded: url_helper
INFO - 2016-05-22 11:40:10 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:40:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:40:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:40:10 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:40:10 --> Helper loaded: form_helper
INFO - 2016-05-22 11:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:40:10 --> Form Validation Class Initialized
INFO - 2016-05-22 11:40:10 --> Controller Class Initialized
INFO - 2016-05-22 11:40:10 --> Model Class Initialized
INFO - 2016-05-22 11:40:10 --> Database Driver Class Initialized
INFO - 2016-05-22 11:40:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:40:10 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:40:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:40:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:40:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:40:10 --> Final output sent to browser
DEBUG - 2016-05-22 11:40:10 --> Total execution time: 0.0849
INFO - 2016-05-22 11:40:10 --> Config Class Initialized
INFO - 2016-05-22 11:40:10 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:40:10 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:40:10 --> Utf8 Class Initialized
INFO - 2016-05-22 11:40:10 --> URI Class Initialized
INFO - 2016-05-22 11:40:10 --> Router Class Initialized
INFO - 2016-05-22 11:40:10 --> Output Class Initialized
INFO - 2016-05-22 11:40:10 --> Security Class Initialized
DEBUG - 2016-05-22 11:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:40:10 --> Input Class Initialized
INFO - 2016-05-22 11:40:10 --> Language Class Initialized
INFO - 2016-05-22 11:40:10 --> Loader Class Initialized
INFO - 2016-05-22 11:40:10 --> Helper loaded: url_helper
INFO - 2016-05-22 11:40:10 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:40:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:40:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:40:10 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:40:11 --> Helper loaded: form_helper
INFO - 2016-05-22 11:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:40:11 --> Form Validation Class Initialized
INFO - 2016-05-22 11:40:11 --> Controller Class Initialized
INFO - 2016-05-22 11:40:11 --> Model Class Initialized
INFO - 2016-05-22 11:40:11 --> Database Driver Class Initialized
INFO - 2016-05-22 11:40:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:40:11 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:40:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:40:11 --> Final output sent to browser
DEBUG - 2016-05-22 11:40:11 --> Total execution time: 0.1089
INFO - 2016-05-22 11:40:20 --> Config Class Initialized
INFO - 2016-05-22 11:40:20 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:40:20 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:40:20 --> Utf8 Class Initialized
INFO - 2016-05-22 11:40:20 --> URI Class Initialized
INFO - 2016-05-22 11:40:20 --> Router Class Initialized
INFO - 2016-05-22 11:40:20 --> Output Class Initialized
INFO - 2016-05-22 11:40:20 --> Security Class Initialized
DEBUG - 2016-05-22 11:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:40:20 --> Input Class Initialized
INFO - 2016-05-22 11:40:20 --> Language Class Initialized
INFO - 2016-05-22 11:40:20 --> Loader Class Initialized
INFO - 2016-05-22 11:40:20 --> Helper loaded: url_helper
INFO - 2016-05-22 11:40:20 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:40:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:40:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:40:20 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:40:20 --> Helper loaded: form_helper
INFO - 2016-05-22 11:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:40:20 --> Form Validation Class Initialized
INFO - 2016-05-22 11:40:20 --> Controller Class Initialized
INFO - 2016-05-22 11:40:20 --> Model Class Initialized
INFO - 2016-05-22 11:40:20 --> Database Driver Class Initialized
INFO - 2016-05-22 11:40:20 --> Final output sent to browser
DEBUG - 2016-05-22 11:40:20 --> Total execution time: 0.1238
INFO - 2016-05-22 11:40:27 --> Config Class Initialized
INFO - 2016-05-22 11:40:27 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:40:27 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:40:27 --> Utf8 Class Initialized
INFO - 2016-05-22 11:40:27 --> URI Class Initialized
INFO - 2016-05-22 11:40:27 --> Router Class Initialized
INFO - 2016-05-22 11:40:27 --> Output Class Initialized
INFO - 2016-05-22 11:40:27 --> Security Class Initialized
DEBUG - 2016-05-22 11:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:40:27 --> Input Class Initialized
INFO - 2016-05-22 11:40:27 --> Language Class Initialized
INFO - 2016-05-22 11:40:27 --> Loader Class Initialized
INFO - 2016-05-22 11:40:27 --> Helper loaded: url_helper
INFO - 2016-05-22 11:40:27 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:40:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:40:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:40:27 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:40:27 --> Helper loaded: form_helper
INFO - 2016-05-22 11:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:40:27 --> Form Validation Class Initialized
INFO - 2016-05-22 11:40:27 --> Controller Class Initialized
INFO - 2016-05-22 11:40:27 --> Model Class Initialized
INFO - 2016-05-22 11:40:27 --> Database Driver Class Initialized
INFO - 2016-05-22 11:40:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:40:27 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:40:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:40:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:40:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:40:27 --> Final output sent to browser
DEBUG - 2016-05-22 11:40:27 --> Total execution time: 0.1000
INFO - 2016-05-22 11:40:28 --> Config Class Initialized
INFO - 2016-05-22 11:40:28 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:40:28 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:40:28 --> Utf8 Class Initialized
INFO - 2016-05-22 11:40:28 --> URI Class Initialized
INFO - 2016-05-22 11:40:28 --> Router Class Initialized
INFO - 2016-05-22 11:40:28 --> Output Class Initialized
INFO - 2016-05-22 11:40:28 --> Security Class Initialized
DEBUG - 2016-05-22 11:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:40:28 --> Input Class Initialized
INFO - 2016-05-22 11:40:28 --> Language Class Initialized
INFO - 2016-05-22 11:40:28 --> Loader Class Initialized
INFO - 2016-05-22 11:40:28 --> Helper loaded: url_helper
INFO - 2016-05-22 11:40:28 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:40:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:40:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:40:28 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:40:28 --> Helper loaded: form_helper
INFO - 2016-05-22 11:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:40:28 --> Form Validation Class Initialized
INFO - 2016-05-22 11:40:28 --> Controller Class Initialized
INFO - 2016-05-22 11:40:28 --> Model Class Initialized
INFO - 2016-05-22 11:40:28 --> Database Driver Class Initialized
INFO - 2016-05-22 11:40:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:40:28 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:40:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:40:28 --> Final output sent to browser
DEBUG - 2016-05-22 11:40:28 --> Total execution time: 0.1079
INFO - 2016-05-22 11:40:31 --> Config Class Initialized
INFO - 2016-05-22 11:40:31 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:40:31 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:40:31 --> Utf8 Class Initialized
INFO - 2016-05-22 11:40:31 --> URI Class Initialized
INFO - 2016-05-22 11:40:31 --> Router Class Initialized
INFO - 2016-05-22 11:40:31 --> Output Class Initialized
INFO - 2016-05-22 11:40:31 --> Security Class Initialized
DEBUG - 2016-05-22 11:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:40:31 --> Input Class Initialized
INFO - 2016-05-22 11:40:31 --> Language Class Initialized
INFO - 2016-05-22 11:40:31 --> Loader Class Initialized
INFO - 2016-05-22 11:40:31 --> Helper loaded: url_helper
INFO - 2016-05-22 11:40:31 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:40:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:40:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:40:31 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:40:31 --> Helper loaded: form_helper
INFO - 2016-05-22 11:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:40:31 --> Form Validation Class Initialized
INFO - 2016-05-22 11:40:31 --> Controller Class Initialized
INFO - 2016-05-22 11:40:31 --> Model Class Initialized
INFO - 2016-05-22 11:40:31 --> Database Driver Class Initialized
INFO - 2016-05-22 11:40:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:40:31 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:40:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:40:31 --> Final output sent to browser
DEBUG - 2016-05-22 11:40:31 --> Total execution time: 0.0699
INFO - 2016-05-22 11:40:53 --> Config Class Initialized
INFO - 2016-05-22 11:40:53 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:40:53 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:40:53 --> Utf8 Class Initialized
INFO - 2016-05-22 11:40:53 --> URI Class Initialized
INFO - 2016-05-22 11:40:53 --> Router Class Initialized
INFO - 2016-05-22 11:40:53 --> Output Class Initialized
INFO - 2016-05-22 11:40:53 --> Security Class Initialized
DEBUG - 2016-05-22 11:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:40:53 --> Input Class Initialized
INFO - 2016-05-22 11:40:53 --> Language Class Initialized
INFO - 2016-05-22 11:40:53 --> Loader Class Initialized
INFO - 2016-05-22 11:40:53 --> Helper loaded: url_helper
INFO - 2016-05-22 11:40:53 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:40:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:40:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:40:53 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:40:53 --> Helper loaded: form_helper
INFO - 2016-05-22 11:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:40:53 --> Form Validation Class Initialized
INFO - 2016-05-22 11:40:53 --> Controller Class Initialized
INFO - 2016-05-22 11:40:53 --> Model Class Initialized
INFO - 2016-05-22 11:40:53 --> Database Driver Class Initialized
INFO - 2016-05-22 11:40:54 --> Final output sent to browser
DEBUG - 2016-05-22 11:40:54 --> Total execution time: 0.1239
INFO - 2016-05-22 11:41:31 --> Config Class Initialized
INFO - 2016-05-22 11:41:31 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:41:31 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:41:31 --> Utf8 Class Initialized
INFO - 2016-05-22 11:41:31 --> URI Class Initialized
INFO - 2016-05-22 11:41:31 --> Router Class Initialized
INFO - 2016-05-22 11:41:31 --> Output Class Initialized
INFO - 2016-05-22 11:41:31 --> Security Class Initialized
DEBUG - 2016-05-22 11:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:41:31 --> Input Class Initialized
INFO - 2016-05-22 11:41:31 --> Language Class Initialized
INFO - 2016-05-22 11:41:31 --> Loader Class Initialized
INFO - 2016-05-22 11:41:31 --> Helper loaded: url_helper
INFO - 2016-05-22 11:41:31 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:41:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:41:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:41:31 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:41:31 --> Helper loaded: form_helper
INFO - 2016-05-22 11:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:41:31 --> Form Validation Class Initialized
INFO - 2016-05-22 11:41:31 --> Controller Class Initialized
INFO - 2016-05-22 11:41:31 --> Model Class Initialized
INFO - 2016-05-22 11:41:31 --> Database Driver Class Initialized
INFO - 2016-05-22 11:41:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:41:31 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:41:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:41:31 --> Final output sent to browser
DEBUG - 2016-05-22 11:41:31 --> Total execution time: 0.0784
INFO - 2016-05-22 11:42:31 --> Config Class Initialized
INFO - 2016-05-22 11:42:31 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:42:31 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:42:31 --> Utf8 Class Initialized
INFO - 2016-05-22 11:42:31 --> URI Class Initialized
INFO - 2016-05-22 11:42:31 --> Router Class Initialized
INFO - 2016-05-22 11:42:31 --> Output Class Initialized
INFO - 2016-05-22 11:42:31 --> Security Class Initialized
DEBUG - 2016-05-22 11:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:42:31 --> Input Class Initialized
INFO - 2016-05-22 11:42:31 --> Language Class Initialized
INFO - 2016-05-22 11:42:31 --> Loader Class Initialized
INFO - 2016-05-22 11:42:31 --> Helper loaded: url_helper
INFO - 2016-05-22 11:42:31 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:42:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:42:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:42:31 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:42:31 --> Helper loaded: form_helper
INFO - 2016-05-22 11:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:42:31 --> Form Validation Class Initialized
INFO - 2016-05-22 11:42:31 --> Controller Class Initialized
INFO - 2016-05-22 11:42:31 --> Model Class Initialized
INFO - 2016-05-22 11:42:31 --> Database Driver Class Initialized
INFO - 2016-05-22 11:42:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:42:31 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:42:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:42:31 --> Final output sent to browser
DEBUG - 2016-05-22 11:42:31 --> Total execution time: 0.1104
INFO - 2016-05-22 11:43:31 --> Config Class Initialized
INFO - 2016-05-22 11:43:31 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:43:31 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:43:31 --> Utf8 Class Initialized
INFO - 2016-05-22 11:43:31 --> URI Class Initialized
INFO - 2016-05-22 11:43:31 --> Router Class Initialized
INFO - 2016-05-22 11:43:31 --> Output Class Initialized
INFO - 2016-05-22 11:43:31 --> Security Class Initialized
DEBUG - 2016-05-22 11:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:43:31 --> Input Class Initialized
INFO - 2016-05-22 11:43:31 --> Language Class Initialized
INFO - 2016-05-22 11:43:31 --> Loader Class Initialized
INFO - 2016-05-22 11:43:31 --> Helper loaded: url_helper
INFO - 2016-05-22 11:43:31 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:43:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:43:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:43:31 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:43:31 --> Helper loaded: form_helper
INFO - 2016-05-22 11:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:43:31 --> Form Validation Class Initialized
INFO - 2016-05-22 11:43:31 --> Controller Class Initialized
INFO - 2016-05-22 11:43:31 --> Model Class Initialized
INFO - 2016-05-22 11:43:31 --> Database Driver Class Initialized
INFO - 2016-05-22 11:43:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:43:31 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:43:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:43:31 --> Final output sent to browser
DEBUG - 2016-05-22 11:43:31 --> Total execution time: 0.0960
INFO - 2016-05-22 11:44:31 --> Config Class Initialized
INFO - 2016-05-22 11:44:31 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:44:31 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:44:31 --> Utf8 Class Initialized
INFO - 2016-05-22 11:44:31 --> URI Class Initialized
INFO - 2016-05-22 11:44:31 --> Router Class Initialized
INFO - 2016-05-22 11:44:31 --> Output Class Initialized
INFO - 2016-05-22 11:44:31 --> Security Class Initialized
DEBUG - 2016-05-22 11:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:44:31 --> Input Class Initialized
INFO - 2016-05-22 11:44:31 --> Language Class Initialized
INFO - 2016-05-22 11:44:31 --> Loader Class Initialized
INFO - 2016-05-22 11:44:31 --> Helper loaded: url_helper
INFO - 2016-05-22 11:44:31 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:44:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:44:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:44:31 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:44:31 --> Helper loaded: form_helper
INFO - 2016-05-22 11:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:44:31 --> Form Validation Class Initialized
INFO - 2016-05-22 11:44:31 --> Controller Class Initialized
INFO - 2016-05-22 11:44:31 --> Model Class Initialized
INFO - 2016-05-22 11:44:31 --> Database Driver Class Initialized
INFO - 2016-05-22 11:44:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:44:31 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:44:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:44:31 --> Final output sent to browser
DEBUG - 2016-05-22 11:44:31 --> Total execution time: 0.0768
INFO - 2016-05-22 11:44:50 --> Config Class Initialized
INFO - 2016-05-22 11:44:50 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:44:50 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:44:50 --> Utf8 Class Initialized
INFO - 2016-05-22 11:44:50 --> URI Class Initialized
INFO - 2016-05-22 11:44:50 --> Router Class Initialized
INFO - 2016-05-22 11:44:50 --> Output Class Initialized
INFO - 2016-05-22 11:44:50 --> Security Class Initialized
DEBUG - 2016-05-22 11:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:44:50 --> Input Class Initialized
INFO - 2016-05-22 11:44:50 --> Language Class Initialized
INFO - 2016-05-22 11:44:50 --> Loader Class Initialized
INFO - 2016-05-22 11:44:50 --> Helper loaded: url_helper
INFO - 2016-05-22 11:44:50 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:44:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:44:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:44:50 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:44:50 --> Helper loaded: form_helper
INFO - 2016-05-22 11:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:44:50 --> Form Validation Class Initialized
INFO - 2016-05-22 11:44:50 --> Controller Class Initialized
DEBUG - 2016-05-22 11:44:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-22 11:44:50 --> Model Class Initialized
INFO - 2016-05-22 11:44:50 --> Database Driver Class Initialized
INFO - 2016-05-22 11:44:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-22 11:44:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:44:50 --> Final output sent to browser
DEBUG - 2016-05-22 11:44:50 --> Total execution time: 0.0721
INFO - 2016-05-22 11:44:51 --> Config Class Initialized
INFO - 2016-05-22 11:44:51 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:44:51 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:44:51 --> Utf8 Class Initialized
INFO - 2016-05-22 11:44:51 --> URI Class Initialized
INFO - 2016-05-22 11:44:51 --> Router Class Initialized
INFO - 2016-05-22 11:44:51 --> Output Class Initialized
INFO - 2016-05-22 11:44:51 --> Security Class Initialized
DEBUG - 2016-05-22 11:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:44:51 --> Input Class Initialized
INFO - 2016-05-22 11:44:51 --> Language Class Initialized
INFO - 2016-05-22 11:44:51 --> Loader Class Initialized
INFO - 2016-05-22 11:44:51 --> Helper loaded: url_helper
INFO - 2016-05-22 11:44:51 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:44:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:44:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:44:51 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:44:51 --> Helper loaded: form_helper
INFO - 2016-05-22 11:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:44:51 --> Form Validation Class Initialized
INFO - 2016-05-22 11:44:51 --> Controller Class Initialized
INFO - 2016-05-22 11:44:51 --> Model Class Initialized
INFO - 2016-05-22 11:44:51 --> Database Driver Class Initialized
INFO - 2016-05-22 11:44:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:44:51 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:44:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:44:51 --> Final output sent to browser
DEBUG - 2016-05-22 11:44:51 --> Total execution time: 0.0905
INFO - 2016-05-22 11:44:53 --> Config Class Initialized
INFO - 2016-05-22 11:44:53 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:44:53 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:44:53 --> Utf8 Class Initialized
INFO - 2016-05-22 11:44:53 --> URI Class Initialized
INFO - 2016-05-22 11:44:53 --> Router Class Initialized
INFO - 2016-05-22 11:44:53 --> Output Class Initialized
INFO - 2016-05-22 11:44:53 --> Security Class Initialized
DEBUG - 2016-05-22 11:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:44:53 --> Input Class Initialized
INFO - 2016-05-22 11:44:53 --> Language Class Initialized
INFO - 2016-05-22 11:44:53 --> Loader Class Initialized
INFO - 2016-05-22 11:44:53 --> Helper loaded: url_helper
INFO - 2016-05-22 11:44:53 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:44:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:44:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:44:53 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:44:53 --> Helper loaded: form_helper
INFO - 2016-05-22 11:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:44:53 --> Form Validation Class Initialized
INFO - 2016-05-22 11:44:53 --> Controller Class Initialized
INFO - 2016-05-22 11:44:53 --> Model Class Initialized
INFO - 2016-05-22 11:44:53 --> Database Driver Class Initialized
INFO - 2016-05-22 11:44:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:44:53 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:44:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:44:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:44:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:44:53 --> Final output sent to browser
DEBUG - 2016-05-22 11:44:53 --> Total execution time: 0.1093
INFO - 2016-05-22 11:44:53 --> Config Class Initialized
INFO - 2016-05-22 11:44:53 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:44:53 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:44:53 --> Utf8 Class Initialized
INFO - 2016-05-22 11:44:53 --> URI Class Initialized
INFO - 2016-05-22 11:44:53 --> Router Class Initialized
INFO - 2016-05-22 11:44:53 --> Output Class Initialized
INFO - 2016-05-22 11:44:53 --> Security Class Initialized
DEBUG - 2016-05-22 11:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:44:53 --> Input Class Initialized
INFO - 2016-05-22 11:44:53 --> Language Class Initialized
INFO - 2016-05-22 11:44:53 --> Loader Class Initialized
INFO - 2016-05-22 11:44:53 --> Helper loaded: url_helper
INFO - 2016-05-22 11:44:53 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:44:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:44:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:44:53 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:44:53 --> Helper loaded: form_helper
INFO - 2016-05-22 11:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:44:53 --> Form Validation Class Initialized
INFO - 2016-05-22 11:44:53 --> Controller Class Initialized
INFO - 2016-05-22 11:44:53 --> Model Class Initialized
INFO - 2016-05-22 11:44:53 --> Database Driver Class Initialized
INFO - 2016-05-22 11:44:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:44:53 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:44:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:44:53 --> Final output sent to browser
DEBUG - 2016-05-22 11:44:53 --> Total execution time: 0.0986
INFO - 2016-05-22 11:45:53 --> Config Class Initialized
INFO - 2016-05-22 11:45:53 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:45:53 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:45:53 --> Utf8 Class Initialized
INFO - 2016-05-22 11:45:53 --> URI Class Initialized
INFO - 2016-05-22 11:45:53 --> Router Class Initialized
INFO - 2016-05-22 11:45:53 --> Output Class Initialized
INFO - 2016-05-22 11:45:53 --> Security Class Initialized
DEBUG - 2016-05-22 11:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:45:53 --> Input Class Initialized
INFO - 2016-05-22 11:45:53 --> Language Class Initialized
INFO - 2016-05-22 11:45:53 --> Loader Class Initialized
INFO - 2016-05-22 11:45:53 --> Helper loaded: url_helper
INFO - 2016-05-22 11:45:53 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:45:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:45:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:45:53 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:45:53 --> Helper loaded: form_helper
INFO - 2016-05-22 11:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:45:53 --> Form Validation Class Initialized
INFO - 2016-05-22 11:45:53 --> Controller Class Initialized
INFO - 2016-05-22 11:45:53 --> Model Class Initialized
INFO - 2016-05-22 11:45:53 --> Database Driver Class Initialized
INFO - 2016-05-22 11:45:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:45:53 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:45:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:45:53 --> Final output sent to browser
DEBUG - 2016-05-22 11:45:53 --> Total execution time: 0.0760
INFO - 2016-05-22 11:46:39 --> Config Class Initialized
INFO - 2016-05-22 11:46:39 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:46:39 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:46:39 --> Utf8 Class Initialized
INFO - 2016-05-22 11:46:39 --> URI Class Initialized
INFO - 2016-05-22 11:46:39 --> Router Class Initialized
INFO - 2016-05-22 11:46:39 --> Output Class Initialized
INFO - 2016-05-22 11:46:39 --> Security Class Initialized
DEBUG - 2016-05-22 11:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:46:39 --> Input Class Initialized
INFO - 2016-05-22 11:46:39 --> Language Class Initialized
INFO - 2016-05-22 11:46:39 --> Loader Class Initialized
INFO - 2016-05-22 11:46:39 --> Helper loaded: url_helper
INFO - 2016-05-22 11:46:39 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:46:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:46:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:46:39 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:46:39 --> Helper loaded: form_helper
INFO - 2016-05-22 11:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:46:39 --> Form Validation Class Initialized
INFO - 2016-05-22 11:46:39 --> Controller Class Initialized
INFO - 2016-05-22 11:46:39 --> Model Class Initialized
INFO - 2016-05-22 11:46:39 --> Database Driver Class Initialized
INFO - 2016-05-22 11:46:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:46:39 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:46:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:46:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:46:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:46:39 --> Final output sent to browser
DEBUG - 2016-05-22 11:46:39 --> Total execution time: 0.0890
INFO - 2016-05-22 11:46:40 --> Config Class Initialized
INFO - 2016-05-22 11:46:40 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:46:40 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:46:40 --> Utf8 Class Initialized
INFO - 2016-05-22 11:46:40 --> URI Class Initialized
INFO - 2016-05-22 11:46:40 --> Router Class Initialized
INFO - 2016-05-22 11:46:40 --> Output Class Initialized
INFO - 2016-05-22 11:46:40 --> Security Class Initialized
DEBUG - 2016-05-22 11:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:46:40 --> Input Class Initialized
INFO - 2016-05-22 11:46:40 --> Language Class Initialized
INFO - 2016-05-22 11:46:40 --> Loader Class Initialized
INFO - 2016-05-22 11:46:40 --> Helper loaded: url_helper
INFO - 2016-05-22 11:46:40 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:46:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:46:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:46:40 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:46:40 --> Helper loaded: form_helper
INFO - 2016-05-22 11:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:46:40 --> Form Validation Class Initialized
INFO - 2016-05-22 11:46:40 --> Controller Class Initialized
INFO - 2016-05-22 11:46:40 --> Model Class Initialized
INFO - 2016-05-22 11:46:40 --> Database Driver Class Initialized
INFO - 2016-05-22 11:46:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:46:40 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:46:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:46:40 --> Final output sent to browser
DEBUG - 2016-05-22 11:46:40 --> Total execution time: 0.0854
INFO - 2016-05-22 11:47:11 --> Config Class Initialized
INFO - 2016-05-22 11:47:11 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:47:11 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:47:11 --> Utf8 Class Initialized
INFO - 2016-05-22 11:47:11 --> URI Class Initialized
INFO - 2016-05-22 11:47:11 --> Router Class Initialized
INFO - 2016-05-22 11:47:11 --> Output Class Initialized
INFO - 2016-05-22 11:47:11 --> Security Class Initialized
DEBUG - 2016-05-22 11:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:47:11 --> Input Class Initialized
INFO - 2016-05-22 11:47:11 --> Language Class Initialized
INFO - 2016-05-22 11:47:11 --> Loader Class Initialized
INFO - 2016-05-22 11:47:11 --> Helper loaded: url_helper
INFO - 2016-05-22 11:47:11 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:47:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:47:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:47:11 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:47:11 --> Helper loaded: form_helper
INFO - 2016-05-22 11:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:47:11 --> Form Validation Class Initialized
INFO - 2016-05-22 11:47:11 --> Controller Class Initialized
INFO - 2016-05-22 11:47:11 --> Model Class Initialized
INFO - 2016-05-22 11:47:11 --> Database Driver Class Initialized
INFO - 2016-05-22 11:47:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:47:11 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:47:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:47:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:47:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:47:11 --> Final output sent to browser
DEBUG - 2016-05-22 11:47:11 --> Total execution time: 0.0848
INFO - 2016-05-22 11:47:12 --> Config Class Initialized
INFO - 2016-05-22 11:47:12 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:47:12 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:47:12 --> Utf8 Class Initialized
INFO - 2016-05-22 11:47:12 --> URI Class Initialized
INFO - 2016-05-22 11:47:12 --> Router Class Initialized
INFO - 2016-05-22 11:47:12 --> Output Class Initialized
INFO - 2016-05-22 11:47:12 --> Security Class Initialized
DEBUG - 2016-05-22 11:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:47:12 --> Input Class Initialized
INFO - 2016-05-22 11:47:12 --> Language Class Initialized
INFO - 2016-05-22 11:47:12 --> Loader Class Initialized
INFO - 2016-05-22 11:47:12 --> Helper loaded: url_helper
INFO - 2016-05-22 11:47:12 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:47:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:47:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:47:12 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:47:12 --> Helper loaded: form_helper
INFO - 2016-05-22 11:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:47:12 --> Form Validation Class Initialized
INFO - 2016-05-22 11:47:12 --> Controller Class Initialized
INFO - 2016-05-22 11:47:12 --> Model Class Initialized
INFO - 2016-05-22 11:47:12 --> Database Driver Class Initialized
INFO - 2016-05-22 11:47:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:47:12 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:47:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:47:12 --> Final output sent to browser
DEBUG - 2016-05-22 11:47:12 --> Total execution time: 0.0945
INFO - 2016-05-22 11:47:24 --> Config Class Initialized
INFO - 2016-05-22 11:47:24 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:47:24 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:47:24 --> Utf8 Class Initialized
INFO - 2016-05-22 11:47:24 --> URI Class Initialized
INFO - 2016-05-22 11:47:24 --> Router Class Initialized
INFO - 2016-05-22 11:47:24 --> Output Class Initialized
INFO - 2016-05-22 11:47:24 --> Security Class Initialized
DEBUG - 2016-05-22 11:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:47:24 --> Input Class Initialized
INFO - 2016-05-22 11:47:24 --> Language Class Initialized
INFO - 2016-05-22 11:47:24 --> Loader Class Initialized
INFO - 2016-05-22 11:47:24 --> Helper loaded: url_helper
INFO - 2016-05-22 11:47:24 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:47:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:47:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:47:24 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:47:24 --> Helper loaded: form_helper
INFO - 2016-05-22 11:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:47:24 --> Form Validation Class Initialized
INFO - 2016-05-22 11:47:24 --> Controller Class Initialized
INFO - 2016-05-22 11:47:24 --> Model Class Initialized
INFO - 2016-05-22 11:47:24 --> Database Driver Class Initialized
INFO - 2016-05-22 11:47:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:47:24 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:47:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:47:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:47:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:47:24 --> Final output sent to browser
DEBUG - 2016-05-22 11:47:24 --> Total execution time: 0.0865
INFO - 2016-05-22 11:47:24 --> Config Class Initialized
INFO - 2016-05-22 11:47:24 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:47:24 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:47:24 --> Utf8 Class Initialized
INFO - 2016-05-22 11:47:24 --> URI Class Initialized
INFO - 2016-05-22 11:47:24 --> Router Class Initialized
INFO - 2016-05-22 11:47:24 --> Output Class Initialized
INFO - 2016-05-22 11:47:24 --> Security Class Initialized
DEBUG - 2016-05-22 11:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:47:24 --> Input Class Initialized
INFO - 2016-05-22 11:47:24 --> Language Class Initialized
INFO - 2016-05-22 11:47:24 --> Loader Class Initialized
INFO - 2016-05-22 11:47:24 --> Helper loaded: url_helper
INFO - 2016-05-22 11:47:24 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:47:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:47:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:47:24 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:47:24 --> Helper loaded: form_helper
INFO - 2016-05-22 11:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:47:24 --> Form Validation Class Initialized
INFO - 2016-05-22 11:47:24 --> Controller Class Initialized
INFO - 2016-05-22 11:47:24 --> Model Class Initialized
INFO - 2016-05-22 11:47:24 --> Database Driver Class Initialized
INFO - 2016-05-22 11:47:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:47:24 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:47:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:47:24 --> Final output sent to browser
DEBUG - 2016-05-22 11:47:24 --> Total execution time: 0.0973
INFO - 2016-05-22 11:48:24 --> Config Class Initialized
INFO - 2016-05-22 11:48:24 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:48:24 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:48:24 --> Utf8 Class Initialized
INFO - 2016-05-22 11:48:24 --> URI Class Initialized
INFO - 2016-05-22 11:48:24 --> Router Class Initialized
INFO - 2016-05-22 11:48:24 --> Output Class Initialized
INFO - 2016-05-22 11:48:24 --> Security Class Initialized
DEBUG - 2016-05-22 11:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:48:24 --> Input Class Initialized
INFO - 2016-05-22 11:48:24 --> Language Class Initialized
INFO - 2016-05-22 11:48:24 --> Loader Class Initialized
INFO - 2016-05-22 11:48:24 --> Helper loaded: url_helper
INFO - 2016-05-22 11:48:24 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:48:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:48:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:48:24 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:48:24 --> Helper loaded: form_helper
INFO - 2016-05-22 11:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:48:24 --> Form Validation Class Initialized
INFO - 2016-05-22 11:48:24 --> Controller Class Initialized
INFO - 2016-05-22 11:48:24 --> Model Class Initialized
INFO - 2016-05-22 11:48:24 --> Database Driver Class Initialized
INFO - 2016-05-22 11:48:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:48:24 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:48:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:48:24 --> Final output sent to browser
DEBUG - 2016-05-22 11:48:24 --> Total execution time: 0.0675
INFO - 2016-05-22 11:49:24 --> Config Class Initialized
INFO - 2016-05-22 11:49:24 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:49:24 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:49:24 --> Utf8 Class Initialized
INFO - 2016-05-22 11:49:24 --> URI Class Initialized
INFO - 2016-05-22 11:49:24 --> Router Class Initialized
INFO - 2016-05-22 11:49:24 --> Output Class Initialized
INFO - 2016-05-22 11:49:24 --> Security Class Initialized
DEBUG - 2016-05-22 11:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:49:24 --> Input Class Initialized
INFO - 2016-05-22 11:49:24 --> Language Class Initialized
INFO - 2016-05-22 11:49:24 --> Loader Class Initialized
INFO - 2016-05-22 11:49:24 --> Helper loaded: url_helper
INFO - 2016-05-22 11:49:24 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:49:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:49:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:49:24 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:49:24 --> Helper loaded: form_helper
INFO - 2016-05-22 11:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:49:24 --> Form Validation Class Initialized
INFO - 2016-05-22 11:49:24 --> Controller Class Initialized
INFO - 2016-05-22 11:49:24 --> Model Class Initialized
INFO - 2016-05-22 11:49:24 --> Database Driver Class Initialized
INFO - 2016-05-22 11:49:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:49:24 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:49:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:49:24 --> Final output sent to browser
DEBUG - 2016-05-22 11:49:24 --> Total execution time: 0.0781
INFO - 2016-05-22 11:50:25 --> Config Class Initialized
INFO - 2016-05-22 11:50:25 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:50:25 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:50:25 --> Utf8 Class Initialized
INFO - 2016-05-22 11:50:25 --> URI Class Initialized
INFO - 2016-05-22 11:50:25 --> Router Class Initialized
INFO - 2016-05-22 11:50:25 --> Output Class Initialized
INFO - 2016-05-22 11:50:25 --> Security Class Initialized
DEBUG - 2016-05-22 11:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:50:25 --> Input Class Initialized
INFO - 2016-05-22 11:50:25 --> Language Class Initialized
INFO - 2016-05-22 11:50:25 --> Loader Class Initialized
INFO - 2016-05-22 11:50:25 --> Helper loaded: url_helper
INFO - 2016-05-22 11:50:25 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:50:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:50:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:50:25 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:50:25 --> Helper loaded: form_helper
INFO - 2016-05-22 11:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:50:25 --> Form Validation Class Initialized
INFO - 2016-05-22 11:50:25 --> Controller Class Initialized
INFO - 2016-05-22 11:50:25 --> Model Class Initialized
INFO - 2016-05-22 11:50:25 --> Database Driver Class Initialized
INFO - 2016-05-22 11:50:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:50:25 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:50:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:50:25 --> Final output sent to browser
DEBUG - 2016-05-22 11:50:25 --> Total execution time: 0.0829
INFO - 2016-05-22 11:51:25 --> Config Class Initialized
INFO - 2016-05-22 11:51:25 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:51:25 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:51:25 --> Utf8 Class Initialized
INFO - 2016-05-22 11:51:25 --> URI Class Initialized
INFO - 2016-05-22 11:51:25 --> Router Class Initialized
INFO - 2016-05-22 11:51:25 --> Output Class Initialized
INFO - 2016-05-22 11:51:25 --> Security Class Initialized
DEBUG - 2016-05-22 11:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:51:25 --> Input Class Initialized
INFO - 2016-05-22 11:51:25 --> Language Class Initialized
INFO - 2016-05-22 11:51:25 --> Loader Class Initialized
INFO - 2016-05-22 11:51:25 --> Helper loaded: url_helper
INFO - 2016-05-22 11:51:25 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:51:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:51:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:51:25 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:51:25 --> Helper loaded: form_helper
INFO - 2016-05-22 11:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:51:25 --> Form Validation Class Initialized
INFO - 2016-05-22 11:51:25 --> Controller Class Initialized
INFO - 2016-05-22 11:51:25 --> Model Class Initialized
INFO - 2016-05-22 11:51:25 --> Database Driver Class Initialized
INFO - 2016-05-22 11:51:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:51:25 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:51:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:51:25 --> Final output sent to browser
DEBUG - 2016-05-22 11:51:25 --> Total execution time: 0.0753
INFO - 2016-05-22 11:52:25 --> Config Class Initialized
INFO - 2016-05-22 11:52:25 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:52:25 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:52:25 --> Utf8 Class Initialized
INFO - 2016-05-22 11:52:25 --> URI Class Initialized
INFO - 2016-05-22 11:52:25 --> Router Class Initialized
INFO - 2016-05-22 11:52:25 --> Output Class Initialized
INFO - 2016-05-22 11:52:25 --> Security Class Initialized
DEBUG - 2016-05-22 11:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:52:25 --> Input Class Initialized
INFO - 2016-05-22 11:52:25 --> Language Class Initialized
INFO - 2016-05-22 11:52:25 --> Loader Class Initialized
INFO - 2016-05-22 11:52:25 --> Helper loaded: url_helper
INFO - 2016-05-22 11:52:25 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:52:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:52:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:52:25 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:52:25 --> Helper loaded: form_helper
INFO - 2016-05-22 11:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:52:25 --> Form Validation Class Initialized
INFO - 2016-05-22 11:52:25 --> Controller Class Initialized
INFO - 2016-05-22 11:52:25 --> Model Class Initialized
INFO - 2016-05-22 11:52:25 --> Database Driver Class Initialized
INFO - 2016-05-22 11:52:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:52:25 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:52:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:52:25 --> Final output sent to browser
DEBUG - 2016-05-22 11:52:25 --> Total execution time: 0.0712
INFO - 2016-05-22 11:53:25 --> Config Class Initialized
INFO - 2016-05-22 11:53:25 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:53:25 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:53:25 --> Utf8 Class Initialized
INFO - 2016-05-22 11:53:25 --> URI Class Initialized
INFO - 2016-05-22 11:53:25 --> Router Class Initialized
INFO - 2016-05-22 11:53:25 --> Output Class Initialized
INFO - 2016-05-22 11:53:25 --> Security Class Initialized
DEBUG - 2016-05-22 11:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:53:25 --> Input Class Initialized
INFO - 2016-05-22 11:53:25 --> Language Class Initialized
INFO - 2016-05-22 11:53:25 --> Loader Class Initialized
INFO - 2016-05-22 11:53:25 --> Helper loaded: url_helper
INFO - 2016-05-22 11:53:25 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:53:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:53:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:53:25 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:53:25 --> Helper loaded: form_helper
INFO - 2016-05-22 11:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:53:25 --> Form Validation Class Initialized
INFO - 2016-05-22 11:53:25 --> Controller Class Initialized
INFO - 2016-05-22 11:53:25 --> Model Class Initialized
INFO - 2016-05-22 11:53:25 --> Database Driver Class Initialized
INFO - 2016-05-22 11:53:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:53:25 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:53:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:53:25 --> Final output sent to browser
DEBUG - 2016-05-22 11:53:25 --> Total execution time: 0.0712
INFO - 2016-05-22 11:54:05 --> Config Class Initialized
INFO - 2016-05-22 11:54:05 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:54:05 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:54:05 --> Utf8 Class Initialized
INFO - 2016-05-22 11:54:05 --> URI Class Initialized
INFO - 2016-05-22 11:54:05 --> Router Class Initialized
INFO - 2016-05-22 11:54:05 --> Output Class Initialized
INFO - 2016-05-22 11:54:05 --> Security Class Initialized
DEBUG - 2016-05-22 11:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:54:05 --> Input Class Initialized
INFO - 2016-05-22 11:54:05 --> Language Class Initialized
INFO - 2016-05-22 11:54:05 --> Loader Class Initialized
INFO - 2016-05-22 11:54:05 --> Helper loaded: url_helper
INFO - 2016-05-22 11:54:05 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:54:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:54:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:54:05 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:54:05 --> Helper loaded: form_helper
INFO - 2016-05-22 11:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:54:05 --> Form Validation Class Initialized
INFO - 2016-05-22 11:54:05 --> Controller Class Initialized
INFO - 2016-05-22 11:54:05 --> Model Class Initialized
INFO - 2016-05-22 11:54:05 --> Database Driver Class Initialized
INFO - 2016-05-22 11:54:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:54:05 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:54:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:54:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:54:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:54:05 --> Final output sent to browser
DEBUG - 2016-05-22 11:54:05 --> Total execution time: 0.0860
INFO - 2016-05-22 11:54:06 --> Config Class Initialized
INFO - 2016-05-22 11:54:06 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:54:06 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:54:06 --> Utf8 Class Initialized
INFO - 2016-05-22 11:54:06 --> URI Class Initialized
INFO - 2016-05-22 11:54:06 --> Router Class Initialized
INFO - 2016-05-22 11:54:06 --> Output Class Initialized
INFO - 2016-05-22 11:54:06 --> Security Class Initialized
DEBUG - 2016-05-22 11:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:54:06 --> Input Class Initialized
INFO - 2016-05-22 11:54:06 --> Language Class Initialized
INFO - 2016-05-22 11:54:06 --> Loader Class Initialized
INFO - 2016-05-22 11:54:06 --> Helper loaded: url_helper
INFO - 2016-05-22 11:54:06 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:54:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:54:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:54:06 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:54:06 --> Helper loaded: form_helper
INFO - 2016-05-22 11:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:54:06 --> Form Validation Class Initialized
INFO - 2016-05-22 11:54:06 --> Controller Class Initialized
INFO - 2016-05-22 11:54:06 --> Model Class Initialized
INFO - 2016-05-22 11:54:06 --> Database Driver Class Initialized
INFO - 2016-05-22 11:54:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:54:06 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:54:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:54:06 --> Final output sent to browser
DEBUG - 2016-05-22 11:54:06 --> Total execution time: 0.0867
INFO - 2016-05-22 11:54:30 --> Config Class Initialized
INFO - 2016-05-22 11:54:30 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:54:30 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:54:30 --> Utf8 Class Initialized
INFO - 2016-05-22 11:54:30 --> URI Class Initialized
INFO - 2016-05-22 11:54:30 --> Router Class Initialized
INFO - 2016-05-22 11:54:30 --> Output Class Initialized
INFO - 2016-05-22 11:54:30 --> Security Class Initialized
DEBUG - 2016-05-22 11:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:54:30 --> Input Class Initialized
INFO - 2016-05-22 11:54:30 --> Language Class Initialized
INFO - 2016-05-22 11:54:30 --> Loader Class Initialized
INFO - 2016-05-22 11:54:30 --> Helper loaded: url_helper
INFO - 2016-05-22 11:54:30 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:54:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:54:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:54:30 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:54:30 --> Helper loaded: form_helper
INFO - 2016-05-22 11:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:54:30 --> Form Validation Class Initialized
INFO - 2016-05-22 11:54:30 --> Controller Class Initialized
INFO - 2016-05-22 11:54:30 --> Model Class Initialized
INFO - 2016-05-22 11:54:30 --> Database Driver Class Initialized
INFO - 2016-05-22 11:54:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:54:30 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:54:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:54:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:54:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:54:30 --> Final output sent to browser
DEBUG - 2016-05-22 11:54:30 --> Total execution time: 0.0927
INFO - 2016-05-22 11:54:31 --> Config Class Initialized
INFO - 2016-05-22 11:54:31 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:54:31 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:54:31 --> Utf8 Class Initialized
INFO - 2016-05-22 11:54:31 --> URI Class Initialized
INFO - 2016-05-22 11:54:31 --> Router Class Initialized
INFO - 2016-05-22 11:54:31 --> Output Class Initialized
INFO - 2016-05-22 11:54:31 --> Security Class Initialized
DEBUG - 2016-05-22 11:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:54:31 --> Input Class Initialized
INFO - 2016-05-22 11:54:31 --> Language Class Initialized
INFO - 2016-05-22 11:54:31 --> Loader Class Initialized
INFO - 2016-05-22 11:54:31 --> Helper loaded: url_helper
INFO - 2016-05-22 11:54:31 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:54:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:54:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:54:31 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:54:31 --> Helper loaded: form_helper
INFO - 2016-05-22 11:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:54:31 --> Form Validation Class Initialized
INFO - 2016-05-22 11:54:31 --> Controller Class Initialized
INFO - 2016-05-22 11:54:31 --> Model Class Initialized
INFO - 2016-05-22 11:54:31 --> Database Driver Class Initialized
INFO - 2016-05-22 11:54:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:54:31 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:54:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:54:31 --> Final output sent to browser
DEBUG - 2016-05-22 11:54:31 --> Total execution time: 0.0912
INFO - 2016-05-22 11:54:44 --> Config Class Initialized
INFO - 2016-05-22 11:54:44 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:54:44 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:54:44 --> Utf8 Class Initialized
INFO - 2016-05-22 11:54:44 --> URI Class Initialized
INFO - 2016-05-22 11:54:44 --> Router Class Initialized
INFO - 2016-05-22 11:54:44 --> Output Class Initialized
INFO - 2016-05-22 11:54:44 --> Security Class Initialized
DEBUG - 2016-05-22 11:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:54:44 --> Input Class Initialized
INFO - 2016-05-22 11:54:44 --> Language Class Initialized
INFO - 2016-05-22 11:54:44 --> Loader Class Initialized
INFO - 2016-05-22 11:54:44 --> Helper loaded: url_helper
INFO - 2016-05-22 11:54:44 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:54:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:54:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:54:44 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:54:44 --> Helper loaded: form_helper
INFO - 2016-05-22 11:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:54:44 --> Form Validation Class Initialized
INFO - 2016-05-22 11:54:44 --> Controller Class Initialized
INFO - 2016-05-22 11:54:44 --> Model Class Initialized
INFO - 2016-05-22 11:54:44 --> Database Driver Class Initialized
INFO - 2016-05-22 11:54:45 --> Final output sent to browser
DEBUG - 2016-05-22 11:54:45 --> Total execution time: 0.1250
INFO - 2016-05-22 11:54:49 --> Config Class Initialized
INFO - 2016-05-22 11:54:49 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:54:49 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:54:49 --> Utf8 Class Initialized
INFO - 2016-05-22 11:54:49 --> URI Class Initialized
INFO - 2016-05-22 11:54:49 --> Router Class Initialized
INFO - 2016-05-22 11:54:49 --> Output Class Initialized
INFO - 2016-05-22 11:54:49 --> Security Class Initialized
DEBUG - 2016-05-22 11:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:54:49 --> Input Class Initialized
INFO - 2016-05-22 11:54:49 --> Language Class Initialized
INFO - 2016-05-22 11:54:49 --> Loader Class Initialized
INFO - 2016-05-22 11:54:49 --> Helper loaded: url_helper
INFO - 2016-05-22 11:54:49 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:54:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:54:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:54:49 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:54:49 --> Helper loaded: form_helper
INFO - 2016-05-22 11:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:54:49 --> Form Validation Class Initialized
INFO - 2016-05-22 11:54:49 --> Controller Class Initialized
INFO - 2016-05-22 11:54:49 --> Model Class Initialized
INFO - 2016-05-22 11:54:49 --> Database Driver Class Initialized
INFO - 2016-05-22 11:54:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:54:49 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:54:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:54:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:54:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:54:49 --> Final output sent to browser
DEBUG - 2016-05-22 11:54:49 --> Total execution time: 0.1014
INFO - 2016-05-22 11:54:49 --> Config Class Initialized
INFO - 2016-05-22 11:54:49 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:54:49 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:54:49 --> Utf8 Class Initialized
INFO - 2016-05-22 11:54:49 --> URI Class Initialized
INFO - 2016-05-22 11:54:49 --> Router Class Initialized
INFO - 2016-05-22 11:54:49 --> Output Class Initialized
INFO - 2016-05-22 11:54:49 --> Security Class Initialized
DEBUG - 2016-05-22 11:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:54:49 --> Input Class Initialized
INFO - 2016-05-22 11:54:49 --> Language Class Initialized
INFO - 2016-05-22 11:54:49 --> Loader Class Initialized
INFO - 2016-05-22 11:54:49 --> Helper loaded: url_helper
INFO - 2016-05-22 11:54:49 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:54:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:54:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:54:49 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:54:49 --> Helper loaded: form_helper
INFO - 2016-05-22 11:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:54:49 --> Form Validation Class Initialized
INFO - 2016-05-22 11:54:49 --> Controller Class Initialized
INFO - 2016-05-22 11:54:49 --> Model Class Initialized
INFO - 2016-05-22 11:54:49 --> Database Driver Class Initialized
INFO - 2016-05-22 11:54:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:54:49 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:54:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:54:49 --> Final output sent to browser
DEBUG - 2016-05-22 11:54:49 --> Total execution time: 0.0841
INFO - 2016-05-22 11:54:52 --> Config Class Initialized
INFO - 2016-05-22 11:54:52 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:54:52 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:54:52 --> Utf8 Class Initialized
INFO - 2016-05-22 11:54:52 --> URI Class Initialized
INFO - 2016-05-22 11:54:52 --> Router Class Initialized
INFO - 2016-05-22 11:54:52 --> Output Class Initialized
INFO - 2016-05-22 11:54:52 --> Security Class Initialized
DEBUG - 2016-05-22 11:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:54:52 --> Input Class Initialized
INFO - 2016-05-22 11:54:52 --> Language Class Initialized
INFO - 2016-05-22 11:54:52 --> Loader Class Initialized
INFO - 2016-05-22 11:54:52 --> Helper loaded: url_helper
INFO - 2016-05-22 11:54:52 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:54:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:54:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:54:52 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:54:52 --> Helper loaded: form_helper
INFO - 2016-05-22 11:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:54:52 --> Form Validation Class Initialized
INFO - 2016-05-22 11:54:52 --> Controller Class Initialized
INFO - 2016-05-22 11:54:52 --> Model Class Initialized
INFO - 2016-05-22 11:54:52 --> Database Driver Class Initialized
INFO - 2016-05-22 11:54:52 --> Final output sent to browser
DEBUG - 2016-05-22 11:54:52 --> Total execution time: 0.1209
INFO - 2016-05-22 11:54:53 --> Config Class Initialized
INFO - 2016-05-22 11:54:53 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:54:53 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:54:53 --> Utf8 Class Initialized
INFO - 2016-05-22 11:54:53 --> URI Class Initialized
INFO - 2016-05-22 11:54:53 --> Router Class Initialized
INFO - 2016-05-22 11:54:53 --> Output Class Initialized
INFO - 2016-05-22 11:54:53 --> Security Class Initialized
DEBUG - 2016-05-22 11:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:54:53 --> Input Class Initialized
INFO - 2016-05-22 11:54:53 --> Language Class Initialized
INFO - 2016-05-22 11:54:53 --> Loader Class Initialized
INFO - 2016-05-22 11:54:53 --> Helper loaded: url_helper
INFO - 2016-05-22 11:54:53 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:54:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:54:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:54:53 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:54:53 --> Helper loaded: form_helper
INFO - 2016-05-22 11:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:54:53 --> Form Validation Class Initialized
INFO - 2016-05-22 11:54:53 --> Controller Class Initialized
INFO - 2016-05-22 11:54:53 --> Model Class Initialized
INFO - 2016-05-22 11:54:53 --> Database Driver Class Initialized
INFO - 2016-05-22 11:54:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:54:53 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:54:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:54:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:54:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:54:53 --> Final output sent to browser
DEBUG - 2016-05-22 11:54:53 --> Total execution time: 0.0851
INFO - 2016-05-22 11:54:54 --> Config Class Initialized
INFO - 2016-05-22 11:54:54 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:54:54 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:54:54 --> Utf8 Class Initialized
INFO - 2016-05-22 11:54:54 --> URI Class Initialized
INFO - 2016-05-22 11:54:54 --> Router Class Initialized
INFO - 2016-05-22 11:54:54 --> Output Class Initialized
INFO - 2016-05-22 11:54:54 --> Security Class Initialized
DEBUG - 2016-05-22 11:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:54:54 --> Input Class Initialized
INFO - 2016-05-22 11:54:54 --> Language Class Initialized
INFO - 2016-05-22 11:54:54 --> Loader Class Initialized
INFO - 2016-05-22 11:54:54 --> Helper loaded: url_helper
INFO - 2016-05-22 11:54:54 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:54:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:54:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:54:54 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:54:54 --> Helper loaded: form_helper
INFO - 2016-05-22 11:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:54:54 --> Form Validation Class Initialized
INFO - 2016-05-22 11:54:54 --> Controller Class Initialized
INFO - 2016-05-22 11:54:54 --> Model Class Initialized
INFO - 2016-05-22 11:54:54 --> Database Driver Class Initialized
INFO - 2016-05-22 11:54:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:54:54 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:54:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:54:54 --> Final output sent to browser
DEBUG - 2016-05-22 11:54:54 --> Total execution time: 0.0882
INFO - 2016-05-22 11:55:05 --> Config Class Initialized
INFO - 2016-05-22 11:55:05 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:55:05 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:55:05 --> Utf8 Class Initialized
INFO - 2016-05-22 11:55:05 --> URI Class Initialized
INFO - 2016-05-22 11:55:05 --> Router Class Initialized
INFO - 2016-05-22 11:55:05 --> Output Class Initialized
INFO - 2016-05-22 11:55:05 --> Security Class Initialized
DEBUG - 2016-05-22 11:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:55:05 --> Input Class Initialized
INFO - 2016-05-22 11:55:05 --> Language Class Initialized
INFO - 2016-05-22 11:55:05 --> Loader Class Initialized
INFO - 2016-05-22 11:55:05 --> Helper loaded: url_helper
INFO - 2016-05-22 11:55:05 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:55:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:55:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:55:05 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:55:05 --> Helper loaded: form_helper
INFO - 2016-05-22 11:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:55:05 --> Form Validation Class Initialized
INFO - 2016-05-22 11:55:05 --> Controller Class Initialized
INFO - 2016-05-22 11:55:05 --> Model Class Initialized
INFO - 2016-05-22 11:55:05 --> Database Driver Class Initialized
INFO - 2016-05-22 11:55:05 --> Final output sent to browser
DEBUG - 2016-05-22 11:55:05 --> Total execution time: 0.1206
INFO - 2016-05-22 11:55:24 --> Config Class Initialized
INFO - 2016-05-22 11:55:24 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:55:24 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:55:24 --> Utf8 Class Initialized
INFO - 2016-05-22 11:55:24 --> URI Class Initialized
INFO - 2016-05-22 11:55:24 --> Router Class Initialized
INFO - 2016-05-22 11:55:24 --> Output Class Initialized
INFO - 2016-05-22 11:55:24 --> Security Class Initialized
DEBUG - 2016-05-22 11:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:55:24 --> Input Class Initialized
INFO - 2016-05-22 11:55:24 --> Language Class Initialized
INFO - 2016-05-22 11:55:24 --> Loader Class Initialized
INFO - 2016-05-22 11:55:24 --> Helper loaded: url_helper
INFO - 2016-05-22 11:55:24 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:55:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:55:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:55:24 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:55:24 --> Helper loaded: form_helper
INFO - 2016-05-22 11:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:55:24 --> Form Validation Class Initialized
INFO - 2016-05-22 11:55:24 --> Controller Class Initialized
INFO - 2016-05-22 11:55:24 --> Model Class Initialized
INFO - 2016-05-22 11:55:24 --> Database Driver Class Initialized
INFO - 2016-05-22 11:55:24 --> Final output sent to browser
DEBUG - 2016-05-22 11:55:24 --> Total execution time: 0.1429
INFO - 2016-05-22 11:55:36 --> Config Class Initialized
INFO - 2016-05-22 11:55:36 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:55:36 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:55:36 --> Utf8 Class Initialized
INFO - 2016-05-22 11:55:36 --> URI Class Initialized
INFO - 2016-05-22 11:55:37 --> Router Class Initialized
INFO - 2016-05-22 11:55:37 --> Output Class Initialized
INFO - 2016-05-22 11:55:37 --> Security Class Initialized
DEBUG - 2016-05-22 11:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:55:37 --> Input Class Initialized
INFO - 2016-05-22 11:55:37 --> Language Class Initialized
INFO - 2016-05-22 11:55:37 --> Loader Class Initialized
INFO - 2016-05-22 11:55:37 --> Helper loaded: url_helper
INFO - 2016-05-22 11:55:37 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:55:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:55:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:55:37 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:55:37 --> Helper loaded: form_helper
INFO - 2016-05-22 11:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:55:37 --> Form Validation Class Initialized
INFO - 2016-05-22 11:55:37 --> Controller Class Initialized
INFO - 2016-05-22 11:55:37 --> Model Class Initialized
INFO - 2016-05-22 11:55:37 --> Database Driver Class Initialized
INFO - 2016-05-22 11:55:37 --> Final output sent to browser
DEBUG - 2016-05-22 11:55:37 --> Total execution time: 0.1501
INFO - 2016-05-22 11:55:46 --> Config Class Initialized
INFO - 2016-05-22 11:55:46 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:55:46 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:55:46 --> Utf8 Class Initialized
INFO - 2016-05-22 11:55:46 --> URI Class Initialized
INFO - 2016-05-22 11:55:46 --> Router Class Initialized
INFO - 2016-05-22 11:55:46 --> Output Class Initialized
INFO - 2016-05-22 11:55:46 --> Security Class Initialized
DEBUG - 2016-05-22 11:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:55:46 --> Input Class Initialized
INFO - 2016-05-22 11:55:46 --> Language Class Initialized
INFO - 2016-05-22 11:55:46 --> Loader Class Initialized
INFO - 2016-05-22 11:55:46 --> Helper loaded: url_helper
INFO - 2016-05-22 11:55:46 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:55:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:55:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:55:46 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:55:46 --> Helper loaded: form_helper
INFO - 2016-05-22 11:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:55:46 --> Form Validation Class Initialized
INFO - 2016-05-22 11:55:46 --> Controller Class Initialized
INFO - 2016-05-22 11:55:46 --> Model Class Initialized
INFO - 2016-05-22 11:55:46 --> Database Driver Class Initialized
INFO - 2016-05-22 11:55:46 --> Final output sent to browser
DEBUG - 2016-05-22 11:55:46 --> Total execution time: 0.1251
INFO - 2016-05-22 11:56:08 --> Config Class Initialized
INFO - 2016-05-22 11:56:08 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:56:08 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:56:08 --> Utf8 Class Initialized
INFO - 2016-05-22 11:56:08 --> URI Class Initialized
INFO - 2016-05-22 11:56:08 --> Router Class Initialized
INFO - 2016-05-22 11:56:08 --> Output Class Initialized
INFO - 2016-05-22 11:56:08 --> Security Class Initialized
DEBUG - 2016-05-22 11:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:56:08 --> Input Class Initialized
INFO - 2016-05-22 11:56:08 --> Language Class Initialized
INFO - 2016-05-22 11:56:08 --> Loader Class Initialized
INFO - 2016-05-22 11:56:08 --> Helper loaded: url_helper
INFO - 2016-05-22 11:56:08 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:56:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:56:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:56:08 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:56:08 --> Helper loaded: form_helper
INFO - 2016-05-22 11:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:56:08 --> Form Validation Class Initialized
INFO - 2016-05-22 11:56:08 --> Controller Class Initialized
INFO - 2016-05-22 11:56:08 --> Model Class Initialized
INFO - 2016-05-22 11:56:08 --> Database Driver Class Initialized
INFO - 2016-05-22 11:56:08 --> Final output sent to browser
DEBUG - 2016-05-22 11:56:08 --> Total execution time: 0.1593
INFO - 2016-05-22 11:56:40 --> Config Class Initialized
INFO - 2016-05-22 11:56:40 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:56:40 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:56:40 --> Utf8 Class Initialized
INFO - 2016-05-22 11:56:40 --> URI Class Initialized
INFO - 2016-05-22 11:56:40 --> Router Class Initialized
INFO - 2016-05-22 11:56:40 --> Output Class Initialized
INFO - 2016-05-22 11:56:40 --> Security Class Initialized
DEBUG - 2016-05-22 11:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:56:40 --> Input Class Initialized
INFO - 2016-05-22 11:56:40 --> Language Class Initialized
INFO - 2016-05-22 11:56:40 --> Loader Class Initialized
INFO - 2016-05-22 11:56:40 --> Helper loaded: url_helper
INFO - 2016-05-22 11:56:40 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:56:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:56:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:56:40 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:56:40 --> Helper loaded: form_helper
INFO - 2016-05-22 11:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:56:40 --> Form Validation Class Initialized
INFO - 2016-05-22 11:56:40 --> Controller Class Initialized
INFO - 2016-05-22 11:56:40 --> Model Class Initialized
INFO - 2016-05-22 11:56:40 --> Database Driver Class Initialized
INFO - 2016-05-22 11:56:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:56:40 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:56:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:56:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:56:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:56:40 --> Final output sent to browser
DEBUG - 2016-05-22 11:56:40 --> Total execution time: 0.0822
INFO - 2016-05-22 11:56:40 --> Config Class Initialized
INFO - 2016-05-22 11:56:40 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:56:40 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:56:40 --> Utf8 Class Initialized
INFO - 2016-05-22 11:56:40 --> URI Class Initialized
INFO - 2016-05-22 11:56:40 --> Router Class Initialized
INFO - 2016-05-22 11:56:40 --> Output Class Initialized
INFO - 2016-05-22 11:56:40 --> Security Class Initialized
DEBUG - 2016-05-22 11:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:56:40 --> Input Class Initialized
INFO - 2016-05-22 11:56:40 --> Language Class Initialized
INFO - 2016-05-22 11:56:40 --> Loader Class Initialized
INFO - 2016-05-22 11:56:40 --> Helper loaded: url_helper
INFO - 2016-05-22 11:56:40 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:56:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:56:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:56:40 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:56:40 --> Helper loaded: form_helper
INFO - 2016-05-22 11:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:56:40 --> Form Validation Class Initialized
INFO - 2016-05-22 11:56:40 --> Controller Class Initialized
INFO - 2016-05-22 11:56:40 --> Model Class Initialized
INFO - 2016-05-22 11:56:40 --> Database Driver Class Initialized
INFO - 2016-05-22 11:56:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:56:40 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:56:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:56:40 --> Final output sent to browser
DEBUG - 2016-05-22 11:56:40 --> Total execution time: 0.0847
INFO - 2016-05-22 11:56:44 --> Config Class Initialized
INFO - 2016-05-22 11:56:44 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:56:44 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:56:44 --> Utf8 Class Initialized
INFO - 2016-05-22 11:56:44 --> URI Class Initialized
INFO - 2016-05-22 11:56:44 --> Router Class Initialized
INFO - 2016-05-22 11:56:44 --> Output Class Initialized
INFO - 2016-05-22 11:56:44 --> Security Class Initialized
DEBUG - 2016-05-22 11:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:56:44 --> Input Class Initialized
INFO - 2016-05-22 11:56:44 --> Language Class Initialized
INFO - 2016-05-22 11:56:44 --> Loader Class Initialized
INFO - 2016-05-22 11:56:44 --> Helper loaded: url_helper
INFO - 2016-05-22 11:56:44 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:56:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:56:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:56:44 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:56:44 --> Helper loaded: form_helper
INFO - 2016-05-22 11:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:56:44 --> Form Validation Class Initialized
INFO - 2016-05-22 11:56:44 --> Controller Class Initialized
INFO - 2016-05-22 11:56:44 --> Model Class Initialized
INFO - 2016-05-22 11:56:44 --> Database Driver Class Initialized
INFO - 2016-05-22 11:56:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:56:44 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:56:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:56:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:56:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:56:44 --> Final output sent to browser
DEBUG - 2016-05-22 11:56:44 --> Total execution time: 0.0804
INFO - 2016-05-22 11:56:44 --> Config Class Initialized
INFO - 2016-05-22 11:56:44 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:56:44 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:56:44 --> Utf8 Class Initialized
INFO - 2016-05-22 11:56:44 --> URI Class Initialized
INFO - 2016-05-22 11:56:44 --> Router Class Initialized
INFO - 2016-05-22 11:56:44 --> Output Class Initialized
INFO - 2016-05-22 11:56:44 --> Security Class Initialized
DEBUG - 2016-05-22 11:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:56:44 --> Input Class Initialized
INFO - 2016-05-22 11:56:44 --> Language Class Initialized
INFO - 2016-05-22 11:56:44 --> Loader Class Initialized
INFO - 2016-05-22 11:56:44 --> Helper loaded: url_helper
INFO - 2016-05-22 11:56:44 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:56:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:56:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:56:44 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:56:44 --> Helper loaded: form_helper
INFO - 2016-05-22 11:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:56:44 --> Form Validation Class Initialized
INFO - 2016-05-22 11:56:44 --> Controller Class Initialized
INFO - 2016-05-22 11:56:44 --> Model Class Initialized
INFO - 2016-05-22 11:56:44 --> Database Driver Class Initialized
INFO - 2016-05-22 11:56:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:56:44 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:56:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:56:44 --> Final output sent to browser
DEBUG - 2016-05-22 11:56:44 --> Total execution time: 0.0944
INFO - 2016-05-22 11:56:45 --> Config Class Initialized
INFO - 2016-05-22 11:56:45 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:56:45 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:56:45 --> Utf8 Class Initialized
INFO - 2016-05-22 11:56:45 --> URI Class Initialized
INFO - 2016-05-22 11:56:45 --> Router Class Initialized
INFO - 2016-05-22 11:56:45 --> Output Class Initialized
INFO - 2016-05-22 11:56:45 --> Security Class Initialized
DEBUG - 2016-05-22 11:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:56:45 --> Input Class Initialized
INFO - 2016-05-22 11:56:45 --> Language Class Initialized
INFO - 2016-05-22 11:56:45 --> Loader Class Initialized
INFO - 2016-05-22 11:56:45 --> Helper loaded: url_helper
INFO - 2016-05-22 11:56:45 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:56:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:56:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:56:45 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:56:45 --> Helper loaded: form_helper
INFO - 2016-05-22 11:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:56:45 --> Form Validation Class Initialized
INFO - 2016-05-22 11:56:45 --> Controller Class Initialized
INFO - 2016-05-22 11:56:45 --> Model Class Initialized
INFO - 2016-05-22 11:56:45 --> Database Driver Class Initialized
INFO - 2016-05-22 11:56:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:56:45 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:56:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:56:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:56:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:56:45 --> Final output sent to browser
DEBUG - 2016-05-22 11:56:45 --> Total execution time: 0.0959
INFO - 2016-05-22 11:56:46 --> Config Class Initialized
INFO - 2016-05-22 11:56:46 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:56:46 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:56:46 --> Utf8 Class Initialized
INFO - 2016-05-22 11:56:46 --> URI Class Initialized
INFO - 2016-05-22 11:56:46 --> Router Class Initialized
INFO - 2016-05-22 11:56:46 --> Output Class Initialized
INFO - 2016-05-22 11:56:46 --> Security Class Initialized
DEBUG - 2016-05-22 11:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:56:46 --> Input Class Initialized
INFO - 2016-05-22 11:56:46 --> Language Class Initialized
INFO - 2016-05-22 11:56:46 --> Loader Class Initialized
INFO - 2016-05-22 11:56:46 --> Helper loaded: url_helper
INFO - 2016-05-22 11:56:46 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:56:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:56:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:56:46 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:56:46 --> Helper loaded: form_helper
INFO - 2016-05-22 11:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:56:46 --> Form Validation Class Initialized
INFO - 2016-05-22 11:56:46 --> Controller Class Initialized
INFO - 2016-05-22 11:56:46 --> Model Class Initialized
INFO - 2016-05-22 11:56:46 --> Database Driver Class Initialized
INFO - 2016-05-22 11:56:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:56:46 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:56:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:56:46 --> Final output sent to browser
DEBUG - 2016-05-22 11:56:46 --> Total execution time: 0.1029
INFO - 2016-05-22 11:56:51 --> Config Class Initialized
INFO - 2016-05-22 11:56:51 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:56:51 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:56:51 --> Utf8 Class Initialized
INFO - 2016-05-22 11:56:51 --> URI Class Initialized
INFO - 2016-05-22 11:56:51 --> Router Class Initialized
INFO - 2016-05-22 11:56:51 --> Output Class Initialized
INFO - 2016-05-22 11:56:51 --> Security Class Initialized
DEBUG - 2016-05-22 11:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:56:51 --> Input Class Initialized
INFO - 2016-05-22 11:56:51 --> Language Class Initialized
INFO - 2016-05-22 11:56:51 --> Loader Class Initialized
INFO - 2016-05-22 11:56:51 --> Helper loaded: url_helper
INFO - 2016-05-22 11:56:51 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:56:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:56:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:56:51 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:56:51 --> Helper loaded: form_helper
INFO - 2016-05-22 11:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:56:51 --> Form Validation Class Initialized
INFO - 2016-05-22 11:56:51 --> Controller Class Initialized
INFO - 2016-05-22 11:56:51 --> Model Class Initialized
INFO - 2016-05-22 11:56:51 --> Database Driver Class Initialized
INFO - 2016-05-22 11:56:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:56:51 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:56:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:56:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:56:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:56:51 --> Final output sent to browser
DEBUG - 2016-05-22 11:56:51 --> Total execution time: 0.0795
INFO - 2016-05-22 11:56:52 --> Config Class Initialized
INFO - 2016-05-22 11:56:52 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:56:52 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:56:52 --> Utf8 Class Initialized
INFO - 2016-05-22 11:56:52 --> URI Class Initialized
INFO - 2016-05-22 11:56:52 --> Router Class Initialized
INFO - 2016-05-22 11:56:52 --> Output Class Initialized
INFO - 2016-05-22 11:56:52 --> Security Class Initialized
DEBUG - 2016-05-22 11:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:56:52 --> Input Class Initialized
INFO - 2016-05-22 11:56:52 --> Language Class Initialized
INFO - 2016-05-22 11:56:52 --> Loader Class Initialized
INFO - 2016-05-22 11:56:52 --> Helper loaded: url_helper
INFO - 2016-05-22 11:56:52 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:56:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:56:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:56:52 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:56:52 --> Helper loaded: form_helper
INFO - 2016-05-22 11:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:56:52 --> Form Validation Class Initialized
INFO - 2016-05-22 11:56:52 --> Controller Class Initialized
INFO - 2016-05-22 11:56:52 --> Model Class Initialized
INFO - 2016-05-22 11:56:52 --> Database Driver Class Initialized
INFO - 2016-05-22 11:56:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:56:52 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:56:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:56:52 --> Final output sent to browser
DEBUG - 2016-05-22 11:56:52 --> Total execution time: 0.0973
INFO - 2016-05-22 11:57:00 --> Config Class Initialized
INFO - 2016-05-22 11:57:00 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:57:00 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:57:00 --> Utf8 Class Initialized
INFO - 2016-05-22 11:57:00 --> URI Class Initialized
INFO - 2016-05-22 11:57:00 --> Router Class Initialized
INFO - 2016-05-22 11:57:00 --> Output Class Initialized
INFO - 2016-05-22 11:57:00 --> Security Class Initialized
DEBUG - 2016-05-22 11:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:57:00 --> Input Class Initialized
INFO - 2016-05-22 11:57:00 --> Language Class Initialized
INFO - 2016-05-22 11:57:00 --> Loader Class Initialized
INFO - 2016-05-22 11:57:00 --> Helper loaded: url_helper
INFO - 2016-05-22 11:57:00 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:57:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:57:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:57:00 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:57:00 --> Helper loaded: form_helper
INFO - 2016-05-22 11:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:57:00 --> Form Validation Class Initialized
INFO - 2016-05-22 11:57:00 --> Controller Class Initialized
INFO - 2016-05-22 11:57:00 --> Model Class Initialized
INFO - 2016-05-22 11:57:00 --> Database Driver Class Initialized
INFO - 2016-05-22 11:57:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:57:00 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:57:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:57:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:57:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:57:00 --> Final output sent to browser
DEBUG - 2016-05-22 11:57:00 --> Total execution time: 0.0806
INFO - 2016-05-22 11:57:00 --> Config Class Initialized
INFO - 2016-05-22 11:57:00 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:57:00 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:57:00 --> Utf8 Class Initialized
INFO - 2016-05-22 11:57:00 --> URI Class Initialized
INFO - 2016-05-22 11:57:00 --> Router Class Initialized
INFO - 2016-05-22 11:57:00 --> Output Class Initialized
INFO - 2016-05-22 11:57:00 --> Security Class Initialized
DEBUG - 2016-05-22 11:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:57:00 --> Input Class Initialized
INFO - 2016-05-22 11:57:00 --> Language Class Initialized
INFO - 2016-05-22 11:57:00 --> Loader Class Initialized
INFO - 2016-05-22 11:57:00 --> Helper loaded: url_helper
INFO - 2016-05-22 11:57:00 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:57:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:57:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:57:00 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:57:00 --> Helper loaded: form_helper
INFO - 2016-05-22 11:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:57:00 --> Form Validation Class Initialized
INFO - 2016-05-22 11:57:00 --> Controller Class Initialized
INFO - 2016-05-22 11:57:00 --> Model Class Initialized
INFO - 2016-05-22 11:57:01 --> Database Driver Class Initialized
INFO - 2016-05-22 11:57:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:57:01 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:57:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:57:01 --> Final output sent to browser
DEBUG - 2016-05-22 11:57:01 --> Total execution time: 0.0846
INFO - 2016-05-22 11:57:31 --> Config Class Initialized
INFO - 2016-05-22 11:57:31 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:57:31 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:57:31 --> Utf8 Class Initialized
INFO - 2016-05-22 11:57:31 --> URI Class Initialized
INFO - 2016-05-22 11:57:31 --> Router Class Initialized
INFO - 2016-05-22 11:57:31 --> Output Class Initialized
INFO - 2016-05-22 11:57:31 --> Security Class Initialized
DEBUG - 2016-05-22 11:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:57:31 --> Input Class Initialized
INFO - 2016-05-22 11:57:31 --> Language Class Initialized
INFO - 2016-05-22 11:57:31 --> Loader Class Initialized
INFO - 2016-05-22 11:57:31 --> Helper loaded: url_helper
INFO - 2016-05-22 11:57:31 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:57:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:57:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:57:31 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:57:31 --> Helper loaded: form_helper
INFO - 2016-05-22 11:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:57:32 --> Form Validation Class Initialized
INFO - 2016-05-22 11:57:32 --> Controller Class Initialized
INFO - 2016-05-22 11:57:32 --> Model Class Initialized
INFO - 2016-05-22 11:57:32 --> Database Driver Class Initialized
INFO - 2016-05-22 11:57:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:57:32 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:57:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:57:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:57:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:57:32 --> Final output sent to browser
DEBUG - 2016-05-22 11:57:32 --> Total execution time: 0.0807
INFO - 2016-05-22 11:57:32 --> Config Class Initialized
INFO - 2016-05-22 11:57:32 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:57:32 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:57:32 --> Utf8 Class Initialized
INFO - 2016-05-22 11:57:32 --> URI Class Initialized
INFO - 2016-05-22 11:57:32 --> Router Class Initialized
INFO - 2016-05-22 11:57:32 --> Output Class Initialized
INFO - 2016-05-22 11:57:32 --> Security Class Initialized
DEBUG - 2016-05-22 11:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:57:32 --> Input Class Initialized
INFO - 2016-05-22 11:57:32 --> Language Class Initialized
INFO - 2016-05-22 11:57:32 --> Loader Class Initialized
INFO - 2016-05-22 11:57:32 --> Helper loaded: url_helper
INFO - 2016-05-22 11:57:32 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:57:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:57:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:57:32 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:57:32 --> Helper loaded: form_helper
INFO - 2016-05-22 11:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:57:32 --> Form Validation Class Initialized
INFO - 2016-05-22 11:57:32 --> Controller Class Initialized
INFO - 2016-05-22 11:57:32 --> Model Class Initialized
INFO - 2016-05-22 11:57:32 --> Database Driver Class Initialized
INFO - 2016-05-22 11:57:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:57:32 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:57:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:57:32 --> Final output sent to browser
DEBUG - 2016-05-22 11:57:32 --> Total execution time: 0.0921
INFO - 2016-05-22 11:57:35 --> Config Class Initialized
INFO - 2016-05-22 11:57:35 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:57:35 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:57:35 --> Utf8 Class Initialized
INFO - 2016-05-22 11:57:35 --> URI Class Initialized
INFO - 2016-05-22 11:57:35 --> Router Class Initialized
INFO - 2016-05-22 11:57:35 --> Output Class Initialized
INFO - 2016-05-22 11:57:35 --> Security Class Initialized
DEBUG - 2016-05-22 11:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:57:35 --> Input Class Initialized
INFO - 2016-05-22 11:57:35 --> Language Class Initialized
INFO - 2016-05-22 11:57:35 --> Loader Class Initialized
INFO - 2016-05-22 11:57:35 --> Helper loaded: url_helper
INFO - 2016-05-22 11:57:35 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:57:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:57:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:57:35 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:57:35 --> Helper loaded: form_helper
INFO - 2016-05-22 11:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:57:35 --> Form Validation Class Initialized
INFO - 2016-05-22 11:57:35 --> Controller Class Initialized
INFO - 2016-05-22 11:57:35 --> Model Class Initialized
INFO - 2016-05-22 11:57:35 --> Database Driver Class Initialized
INFO - 2016-05-22 11:57:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:57:35 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:57:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:57:35 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 11:57:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:57:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:57:35 --> Final output sent to browser
DEBUG - 2016-05-22 11:57:35 --> Total execution time: 0.1628
INFO - 2016-05-22 11:57:35 --> Config Class Initialized
INFO - 2016-05-22 11:57:35 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:57:35 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:57:35 --> Utf8 Class Initialized
INFO - 2016-05-22 11:57:35 --> URI Class Initialized
INFO - 2016-05-22 11:57:35 --> Router Class Initialized
INFO - 2016-05-22 11:57:35 --> Output Class Initialized
INFO - 2016-05-22 11:57:35 --> Security Class Initialized
DEBUG - 2016-05-22 11:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:57:35 --> Input Class Initialized
INFO - 2016-05-22 11:57:35 --> Language Class Initialized
INFO - 2016-05-22 11:57:35 --> Loader Class Initialized
INFO - 2016-05-22 11:57:35 --> Helper loaded: url_helper
INFO - 2016-05-22 11:57:35 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:57:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:57:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:57:35 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:57:35 --> Helper loaded: form_helper
INFO - 2016-05-22 11:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:57:35 --> Form Validation Class Initialized
INFO - 2016-05-22 11:57:35 --> Controller Class Initialized
INFO - 2016-05-22 11:57:35 --> Model Class Initialized
INFO - 2016-05-22 11:57:35 --> Database Driver Class Initialized
INFO - 2016-05-22 11:57:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:57:35 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:57:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:57:35 --> Final output sent to browser
DEBUG - 2016-05-22 11:57:35 --> Total execution time: 0.0907
INFO - 2016-05-22 11:57:38 --> Config Class Initialized
INFO - 2016-05-22 11:57:38 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:57:38 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:57:38 --> Utf8 Class Initialized
INFO - 2016-05-22 11:57:38 --> URI Class Initialized
INFO - 2016-05-22 11:57:38 --> Router Class Initialized
INFO - 2016-05-22 11:57:38 --> Output Class Initialized
INFO - 2016-05-22 11:57:38 --> Security Class Initialized
DEBUG - 2016-05-22 11:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:57:38 --> Input Class Initialized
INFO - 2016-05-22 11:57:38 --> Language Class Initialized
INFO - 2016-05-22 11:57:38 --> Loader Class Initialized
INFO - 2016-05-22 11:57:38 --> Helper loaded: url_helper
INFO - 2016-05-22 11:57:38 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:57:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:57:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:57:38 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:57:38 --> Helper loaded: form_helper
INFO - 2016-05-22 11:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:57:38 --> Form Validation Class Initialized
INFO - 2016-05-22 11:57:38 --> Controller Class Initialized
INFO - 2016-05-22 11:57:38 --> Model Class Initialized
INFO - 2016-05-22 11:57:38 --> Database Driver Class Initialized
INFO - 2016-05-22 11:57:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:57:38 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:57:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:57:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:57:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:57:38 --> Final output sent to browser
DEBUG - 2016-05-22 11:57:38 --> Total execution time: 0.0809
INFO - 2016-05-22 11:57:38 --> Config Class Initialized
INFO - 2016-05-22 11:57:38 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:57:38 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:57:38 --> Utf8 Class Initialized
INFO - 2016-05-22 11:57:38 --> URI Class Initialized
INFO - 2016-05-22 11:57:38 --> Router Class Initialized
INFO - 2016-05-22 11:57:38 --> Output Class Initialized
INFO - 2016-05-22 11:57:38 --> Security Class Initialized
DEBUG - 2016-05-22 11:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:57:38 --> Input Class Initialized
INFO - 2016-05-22 11:57:38 --> Language Class Initialized
INFO - 2016-05-22 11:57:38 --> Loader Class Initialized
INFO - 2016-05-22 11:57:38 --> Helper loaded: url_helper
INFO - 2016-05-22 11:57:38 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:57:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:57:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:57:38 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:57:38 --> Helper loaded: form_helper
INFO - 2016-05-22 11:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:57:38 --> Form Validation Class Initialized
INFO - 2016-05-22 11:57:38 --> Controller Class Initialized
INFO - 2016-05-22 11:57:38 --> Model Class Initialized
INFO - 2016-05-22 11:57:38 --> Database Driver Class Initialized
INFO - 2016-05-22 11:57:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:57:38 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:57:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:57:38 --> Final output sent to browser
DEBUG - 2016-05-22 11:57:38 --> Total execution time: 0.0922
INFO - 2016-05-22 11:57:51 --> Config Class Initialized
INFO - 2016-05-22 11:57:51 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:57:51 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:57:51 --> Utf8 Class Initialized
INFO - 2016-05-22 11:57:51 --> URI Class Initialized
INFO - 2016-05-22 11:57:51 --> Router Class Initialized
INFO - 2016-05-22 11:57:51 --> Output Class Initialized
INFO - 2016-05-22 11:57:51 --> Security Class Initialized
DEBUG - 2016-05-22 11:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:57:51 --> Input Class Initialized
INFO - 2016-05-22 11:57:51 --> Language Class Initialized
INFO - 2016-05-22 11:57:51 --> Loader Class Initialized
INFO - 2016-05-22 11:57:51 --> Helper loaded: url_helper
INFO - 2016-05-22 11:57:51 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:57:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:57:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:57:51 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:57:51 --> Helper loaded: form_helper
INFO - 2016-05-22 11:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:57:51 --> Form Validation Class Initialized
INFO - 2016-05-22 11:57:51 --> Controller Class Initialized
INFO - 2016-05-22 11:57:51 --> Model Class Initialized
INFO - 2016-05-22 11:57:51 --> Database Driver Class Initialized
INFO - 2016-05-22 11:57:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:57:51 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:57:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:57:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:57:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:57:51 --> Final output sent to browser
DEBUG - 2016-05-22 11:57:51 --> Total execution time: 0.0797
INFO - 2016-05-22 11:57:52 --> Config Class Initialized
INFO - 2016-05-22 11:57:52 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:57:52 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:57:52 --> Utf8 Class Initialized
INFO - 2016-05-22 11:57:52 --> URI Class Initialized
INFO - 2016-05-22 11:57:52 --> Router Class Initialized
INFO - 2016-05-22 11:57:52 --> Output Class Initialized
INFO - 2016-05-22 11:57:52 --> Security Class Initialized
DEBUG - 2016-05-22 11:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:57:52 --> Input Class Initialized
INFO - 2016-05-22 11:57:52 --> Language Class Initialized
INFO - 2016-05-22 11:57:52 --> Loader Class Initialized
INFO - 2016-05-22 11:57:52 --> Helper loaded: url_helper
INFO - 2016-05-22 11:57:52 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:57:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:57:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:57:52 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:57:52 --> Helper loaded: form_helper
INFO - 2016-05-22 11:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:57:52 --> Form Validation Class Initialized
INFO - 2016-05-22 11:57:52 --> Controller Class Initialized
INFO - 2016-05-22 11:57:52 --> Model Class Initialized
INFO - 2016-05-22 11:57:52 --> Database Driver Class Initialized
INFO - 2016-05-22 11:57:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:57:52 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:57:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:57:52 --> Final output sent to browser
DEBUG - 2016-05-22 11:57:52 --> Total execution time: 0.0897
INFO - 2016-05-22 11:57:57 --> Config Class Initialized
INFO - 2016-05-22 11:57:57 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:57:57 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:57:57 --> Utf8 Class Initialized
INFO - 2016-05-22 11:57:57 --> URI Class Initialized
INFO - 2016-05-22 11:57:57 --> Router Class Initialized
INFO - 2016-05-22 11:57:57 --> Output Class Initialized
INFO - 2016-05-22 11:57:57 --> Security Class Initialized
DEBUG - 2016-05-22 11:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:57:57 --> Input Class Initialized
INFO - 2016-05-22 11:57:57 --> Language Class Initialized
INFO - 2016-05-22 11:57:57 --> Loader Class Initialized
INFO - 2016-05-22 11:57:57 --> Helper loaded: url_helper
INFO - 2016-05-22 11:57:57 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:57:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:57:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:57:57 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:57:57 --> Helper loaded: form_helper
INFO - 2016-05-22 11:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:57:57 --> Form Validation Class Initialized
INFO - 2016-05-22 11:57:57 --> Controller Class Initialized
INFO - 2016-05-22 11:57:57 --> Model Class Initialized
INFO - 2016-05-22 11:57:57 --> Database Driver Class Initialized
INFO - 2016-05-22 11:57:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:57:57 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:57:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:57:57 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 11:57:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:57:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:57:57 --> Final output sent to browser
DEBUG - 2016-05-22 11:57:57 --> Total execution time: 0.1913
INFO - 2016-05-22 11:57:58 --> Config Class Initialized
INFO - 2016-05-22 11:57:58 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:57:58 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:57:58 --> Utf8 Class Initialized
INFO - 2016-05-22 11:57:58 --> URI Class Initialized
INFO - 2016-05-22 11:57:58 --> Router Class Initialized
INFO - 2016-05-22 11:57:58 --> Output Class Initialized
INFO - 2016-05-22 11:57:58 --> Security Class Initialized
DEBUG - 2016-05-22 11:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:57:58 --> Input Class Initialized
INFO - 2016-05-22 11:57:58 --> Language Class Initialized
INFO - 2016-05-22 11:57:58 --> Loader Class Initialized
INFO - 2016-05-22 11:57:58 --> Helper loaded: url_helper
INFO - 2016-05-22 11:57:58 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:57:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:57:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:57:58 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:57:58 --> Helper loaded: form_helper
INFO - 2016-05-22 11:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:57:58 --> Form Validation Class Initialized
INFO - 2016-05-22 11:57:58 --> Controller Class Initialized
INFO - 2016-05-22 11:57:58 --> Model Class Initialized
INFO - 2016-05-22 11:57:58 --> Database Driver Class Initialized
INFO - 2016-05-22 11:57:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:57:58 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:57:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:57:58 --> Final output sent to browser
DEBUG - 2016-05-22 11:57:58 --> Total execution time: 0.0935
INFO - 2016-05-22 11:58:00 --> Config Class Initialized
INFO - 2016-05-22 11:58:00 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:58:00 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:58:00 --> Utf8 Class Initialized
INFO - 2016-05-22 11:58:00 --> URI Class Initialized
INFO - 2016-05-22 11:58:00 --> Router Class Initialized
INFO - 2016-05-22 11:58:00 --> Output Class Initialized
INFO - 2016-05-22 11:58:00 --> Security Class Initialized
DEBUG - 2016-05-22 11:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:58:00 --> Input Class Initialized
INFO - 2016-05-22 11:58:00 --> Language Class Initialized
INFO - 2016-05-22 11:58:00 --> Loader Class Initialized
INFO - 2016-05-22 11:58:00 --> Helper loaded: url_helper
INFO - 2016-05-22 11:58:00 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:58:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:58:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:58:00 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:58:00 --> Helper loaded: form_helper
INFO - 2016-05-22 11:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:58:00 --> Form Validation Class Initialized
INFO - 2016-05-22 11:58:00 --> Controller Class Initialized
INFO - 2016-05-22 11:58:00 --> Model Class Initialized
INFO - 2016-05-22 11:58:00 --> Database Driver Class Initialized
INFO - 2016-05-22 11:58:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:58:00 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:58:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:58:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:58:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:58:00 --> Final output sent to browser
DEBUG - 2016-05-22 11:58:00 --> Total execution time: 0.1026
INFO - 2016-05-22 11:58:00 --> Config Class Initialized
INFO - 2016-05-22 11:58:00 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:58:00 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:58:00 --> Utf8 Class Initialized
INFO - 2016-05-22 11:58:00 --> URI Class Initialized
INFO - 2016-05-22 11:58:00 --> Router Class Initialized
INFO - 2016-05-22 11:58:00 --> Output Class Initialized
INFO - 2016-05-22 11:58:00 --> Security Class Initialized
DEBUG - 2016-05-22 11:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:58:00 --> Input Class Initialized
INFO - 2016-05-22 11:58:00 --> Language Class Initialized
INFO - 2016-05-22 11:58:00 --> Loader Class Initialized
INFO - 2016-05-22 11:58:00 --> Helper loaded: url_helper
INFO - 2016-05-22 11:58:00 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:58:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:58:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:58:00 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:58:00 --> Helper loaded: form_helper
INFO - 2016-05-22 11:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:58:00 --> Form Validation Class Initialized
INFO - 2016-05-22 11:58:00 --> Controller Class Initialized
INFO - 2016-05-22 11:58:00 --> Model Class Initialized
INFO - 2016-05-22 11:58:00 --> Database Driver Class Initialized
INFO - 2016-05-22 11:58:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:58:00 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:58:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:58:00 --> Final output sent to browser
DEBUG - 2016-05-22 11:58:00 --> Total execution time: 0.0862
INFO - 2016-05-22 11:58:18 --> Config Class Initialized
INFO - 2016-05-22 11:58:18 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:58:18 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:58:18 --> Utf8 Class Initialized
INFO - 2016-05-22 11:58:18 --> URI Class Initialized
INFO - 2016-05-22 11:58:18 --> Router Class Initialized
INFO - 2016-05-22 11:58:18 --> Output Class Initialized
INFO - 2016-05-22 11:58:18 --> Security Class Initialized
DEBUG - 2016-05-22 11:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:58:18 --> Input Class Initialized
INFO - 2016-05-22 11:58:18 --> Language Class Initialized
INFO - 2016-05-22 11:58:18 --> Loader Class Initialized
INFO - 2016-05-22 11:58:18 --> Helper loaded: url_helper
INFO - 2016-05-22 11:58:18 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:58:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:58:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:58:18 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:58:18 --> Helper loaded: form_helper
INFO - 2016-05-22 11:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:58:18 --> Form Validation Class Initialized
INFO - 2016-05-22 11:58:18 --> Controller Class Initialized
INFO - 2016-05-22 11:58:18 --> Model Class Initialized
INFO - 2016-05-22 11:58:18 --> Database Driver Class Initialized
INFO - 2016-05-22 11:58:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:58:18 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:58:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:58:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:58:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:58:18 --> Final output sent to browser
DEBUG - 2016-05-22 11:58:18 --> Total execution time: 0.0917
INFO - 2016-05-22 11:58:19 --> Config Class Initialized
INFO - 2016-05-22 11:58:19 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:58:19 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:58:19 --> Utf8 Class Initialized
INFO - 2016-05-22 11:58:19 --> URI Class Initialized
INFO - 2016-05-22 11:58:19 --> Router Class Initialized
INFO - 2016-05-22 11:58:19 --> Output Class Initialized
INFO - 2016-05-22 11:58:19 --> Security Class Initialized
DEBUG - 2016-05-22 11:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:58:19 --> Input Class Initialized
INFO - 2016-05-22 11:58:19 --> Language Class Initialized
INFO - 2016-05-22 11:58:19 --> Loader Class Initialized
INFO - 2016-05-22 11:58:19 --> Helper loaded: url_helper
INFO - 2016-05-22 11:58:19 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:58:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:58:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:58:19 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:58:19 --> Helper loaded: form_helper
INFO - 2016-05-22 11:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:58:19 --> Form Validation Class Initialized
INFO - 2016-05-22 11:58:19 --> Controller Class Initialized
INFO - 2016-05-22 11:58:19 --> Model Class Initialized
INFO - 2016-05-22 11:58:19 --> Database Driver Class Initialized
INFO - 2016-05-22 11:58:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:58:19 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:58:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:58:19 --> Final output sent to browser
DEBUG - 2016-05-22 11:58:19 --> Total execution time: 0.0893
INFO - 2016-05-22 11:58:21 --> Config Class Initialized
INFO - 2016-05-22 11:58:21 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:58:21 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:58:21 --> Utf8 Class Initialized
INFO - 2016-05-22 11:58:21 --> URI Class Initialized
INFO - 2016-05-22 11:58:21 --> Router Class Initialized
INFO - 2016-05-22 11:58:21 --> Output Class Initialized
INFO - 2016-05-22 11:58:21 --> Security Class Initialized
DEBUG - 2016-05-22 11:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:58:21 --> Input Class Initialized
INFO - 2016-05-22 11:58:21 --> Language Class Initialized
INFO - 2016-05-22 11:58:21 --> Loader Class Initialized
INFO - 2016-05-22 11:58:21 --> Helper loaded: url_helper
INFO - 2016-05-22 11:58:21 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:58:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:58:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:58:21 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:58:21 --> Helper loaded: form_helper
INFO - 2016-05-22 11:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:58:21 --> Form Validation Class Initialized
INFO - 2016-05-22 11:58:21 --> Controller Class Initialized
INFO - 2016-05-22 11:58:21 --> Model Class Initialized
INFO - 2016-05-22 11:58:21 --> Database Driver Class Initialized
INFO - 2016-05-22 11:58:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:58:21 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:58:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:58:21 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 11:58:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:58:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:58:21 --> Final output sent to browser
DEBUG - 2016-05-22 11:58:21 --> Total execution time: 0.1597
INFO - 2016-05-22 11:58:22 --> Config Class Initialized
INFO - 2016-05-22 11:58:22 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:58:22 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:58:22 --> Utf8 Class Initialized
INFO - 2016-05-22 11:58:22 --> URI Class Initialized
INFO - 2016-05-22 11:58:22 --> Router Class Initialized
INFO - 2016-05-22 11:58:22 --> Output Class Initialized
INFO - 2016-05-22 11:58:22 --> Security Class Initialized
DEBUG - 2016-05-22 11:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:58:22 --> Input Class Initialized
INFO - 2016-05-22 11:58:22 --> Language Class Initialized
INFO - 2016-05-22 11:58:22 --> Loader Class Initialized
INFO - 2016-05-22 11:58:22 --> Helper loaded: url_helper
INFO - 2016-05-22 11:58:22 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:58:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:58:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:58:22 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:58:22 --> Helper loaded: form_helper
INFO - 2016-05-22 11:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:58:22 --> Form Validation Class Initialized
INFO - 2016-05-22 11:58:22 --> Controller Class Initialized
INFO - 2016-05-22 11:58:22 --> Model Class Initialized
INFO - 2016-05-22 11:58:22 --> Database Driver Class Initialized
INFO - 2016-05-22 11:58:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:58:22 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:58:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:58:22 --> Final output sent to browser
DEBUG - 2016-05-22 11:58:22 --> Total execution time: 0.0855
INFO - 2016-05-22 11:58:24 --> Config Class Initialized
INFO - 2016-05-22 11:58:24 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:58:24 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:58:24 --> Utf8 Class Initialized
INFO - 2016-05-22 11:58:24 --> URI Class Initialized
INFO - 2016-05-22 11:58:24 --> Router Class Initialized
INFO - 2016-05-22 11:58:24 --> Output Class Initialized
INFO - 2016-05-22 11:58:24 --> Security Class Initialized
DEBUG - 2016-05-22 11:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:58:24 --> Input Class Initialized
INFO - 2016-05-22 11:58:24 --> Language Class Initialized
INFO - 2016-05-22 11:58:24 --> Loader Class Initialized
INFO - 2016-05-22 11:58:24 --> Helper loaded: url_helper
INFO - 2016-05-22 11:58:24 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:58:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:58:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:58:24 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:58:24 --> Helper loaded: form_helper
INFO - 2016-05-22 11:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:58:24 --> Form Validation Class Initialized
INFO - 2016-05-22 11:58:24 --> Controller Class Initialized
INFO - 2016-05-22 11:58:24 --> Model Class Initialized
INFO - 2016-05-22 11:58:24 --> Database Driver Class Initialized
INFO - 2016-05-22 11:58:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:58:24 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:58:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:58:24 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 11:58:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:58:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:58:24 --> Final output sent to browser
DEBUG - 2016-05-22 11:58:24 --> Total execution time: 0.2039
INFO - 2016-05-22 11:58:24 --> Config Class Initialized
INFO - 2016-05-22 11:58:24 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:58:24 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:58:24 --> Utf8 Class Initialized
INFO - 2016-05-22 11:58:24 --> URI Class Initialized
INFO - 2016-05-22 11:58:24 --> Router Class Initialized
INFO - 2016-05-22 11:58:24 --> Output Class Initialized
INFO - 2016-05-22 11:58:24 --> Security Class Initialized
DEBUG - 2016-05-22 11:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:58:24 --> Input Class Initialized
INFO - 2016-05-22 11:58:24 --> Language Class Initialized
INFO - 2016-05-22 11:58:24 --> Loader Class Initialized
INFO - 2016-05-22 11:58:24 --> Helper loaded: url_helper
INFO - 2016-05-22 11:58:24 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:58:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:58:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:58:24 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:58:24 --> Helper loaded: form_helper
INFO - 2016-05-22 11:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:58:24 --> Form Validation Class Initialized
INFO - 2016-05-22 11:58:24 --> Controller Class Initialized
INFO - 2016-05-22 11:58:24 --> Model Class Initialized
INFO - 2016-05-22 11:58:24 --> Database Driver Class Initialized
INFO - 2016-05-22 11:58:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:58:24 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:58:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:58:24 --> Final output sent to browser
DEBUG - 2016-05-22 11:58:24 --> Total execution time: 0.0939
INFO - 2016-05-22 11:58:25 --> Config Class Initialized
INFO - 2016-05-22 11:58:25 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:58:25 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:58:25 --> Utf8 Class Initialized
INFO - 2016-05-22 11:58:25 --> URI Class Initialized
INFO - 2016-05-22 11:58:25 --> Router Class Initialized
INFO - 2016-05-22 11:58:25 --> Output Class Initialized
INFO - 2016-05-22 11:58:25 --> Security Class Initialized
DEBUG - 2016-05-22 11:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:58:25 --> Input Class Initialized
INFO - 2016-05-22 11:58:25 --> Language Class Initialized
INFO - 2016-05-22 11:58:25 --> Loader Class Initialized
INFO - 2016-05-22 11:58:25 --> Helper loaded: url_helper
INFO - 2016-05-22 11:58:25 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:58:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:58:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:58:25 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:58:25 --> Helper loaded: form_helper
INFO - 2016-05-22 11:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:58:25 --> Form Validation Class Initialized
INFO - 2016-05-22 11:58:25 --> Controller Class Initialized
INFO - 2016-05-22 11:58:25 --> Model Class Initialized
INFO - 2016-05-22 11:58:25 --> Database Driver Class Initialized
INFO - 2016-05-22 11:58:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:58:25 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:58:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:58:25 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 11:58:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 11:58:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:58:25 --> Final output sent to browser
DEBUG - 2016-05-22 11:58:25 --> Total execution time: 0.1718
INFO - 2016-05-22 11:58:26 --> Config Class Initialized
INFO - 2016-05-22 11:58:26 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:58:26 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:58:26 --> Utf8 Class Initialized
INFO - 2016-05-22 11:58:26 --> URI Class Initialized
INFO - 2016-05-22 11:58:26 --> Router Class Initialized
INFO - 2016-05-22 11:58:26 --> Output Class Initialized
INFO - 2016-05-22 11:58:26 --> Security Class Initialized
DEBUG - 2016-05-22 11:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:58:26 --> Input Class Initialized
INFO - 2016-05-22 11:58:26 --> Language Class Initialized
INFO - 2016-05-22 11:58:26 --> Loader Class Initialized
INFO - 2016-05-22 11:58:26 --> Helper loaded: url_helper
INFO - 2016-05-22 11:58:26 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:58:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:58:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:58:26 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:58:26 --> Helper loaded: form_helper
INFO - 2016-05-22 11:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:58:26 --> Form Validation Class Initialized
INFO - 2016-05-22 11:58:26 --> Controller Class Initialized
INFO - 2016-05-22 11:58:26 --> Model Class Initialized
INFO - 2016-05-22 11:58:26 --> Database Driver Class Initialized
INFO - 2016-05-22 11:58:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:58:26 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:58:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:58:26 --> Final output sent to browser
DEBUG - 2016-05-22 11:58:26 --> Total execution time: 0.1075
INFO - 2016-05-22 11:58:27 --> Config Class Initialized
INFO - 2016-05-22 11:58:27 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:58:27 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:58:27 --> Utf8 Class Initialized
INFO - 2016-05-22 11:58:27 --> URI Class Initialized
INFO - 2016-05-22 11:58:27 --> Router Class Initialized
INFO - 2016-05-22 11:58:27 --> Output Class Initialized
INFO - 2016-05-22 11:58:27 --> Security Class Initialized
DEBUG - 2016-05-22 11:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:58:27 --> Input Class Initialized
INFO - 2016-05-22 11:58:27 --> Language Class Initialized
INFO - 2016-05-22 11:58:27 --> Loader Class Initialized
INFO - 2016-05-22 11:58:27 --> Helper loaded: url_helper
INFO - 2016-05-22 11:58:27 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:58:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:58:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:58:27 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:58:27 --> Helper loaded: form_helper
INFO - 2016-05-22 11:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:58:27 --> Form Validation Class Initialized
INFO - 2016-05-22 11:58:27 --> Controller Class Initialized
INFO - 2016-05-22 11:58:27 --> Model Class Initialized
INFO - 2016-05-22 11:58:27 --> Database Driver Class Initialized
INFO - 2016-05-22 11:58:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:58:27 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:58:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:58:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 11:58:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 11:58:27 --> Final output sent to browser
DEBUG - 2016-05-22 11:58:27 --> Total execution time: 0.0853
INFO - 2016-05-22 11:58:27 --> Config Class Initialized
INFO - 2016-05-22 11:58:27 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:58:27 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:58:27 --> Utf8 Class Initialized
INFO - 2016-05-22 11:58:27 --> URI Class Initialized
INFO - 2016-05-22 11:58:27 --> Router Class Initialized
INFO - 2016-05-22 11:58:27 --> Output Class Initialized
INFO - 2016-05-22 11:58:27 --> Security Class Initialized
DEBUG - 2016-05-22 11:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:58:27 --> Input Class Initialized
INFO - 2016-05-22 11:58:27 --> Language Class Initialized
INFO - 2016-05-22 11:58:27 --> Loader Class Initialized
INFO - 2016-05-22 11:58:27 --> Helper loaded: url_helper
INFO - 2016-05-22 11:58:27 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:58:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:58:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:58:27 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:58:27 --> Helper loaded: form_helper
INFO - 2016-05-22 11:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:58:27 --> Form Validation Class Initialized
INFO - 2016-05-22 11:58:27 --> Controller Class Initialized
INFO - 2016-05-22 11:58:27 --> Model Class Initialized
INFO - 2016-05-22 11:58:27 --> Database Driver Class Initialized
INFO - 2016-05-22 11:58:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:58:27 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:58:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:58:27 --> Final output sent to browser
DEBUG - 2016-05-22 11:58:27 --> Total execution time: 0.0965
INFO - 2016-05-22 11:59:27 --> Config Class Initialized
INFO - 2016-05-22 11:59:27 --> Hooks Class Initialized
DEBUG - 2016-05-22 11:59:27 --> UTF-8 Support Enabled
INFO - 2016-05-22 11:59:27 --> Utf8 Class Initialized
INFO - 2016-05-22 11:59:27 --> URI Class Initialized
INFO - 2016-05-22 11:59:27 --> Router Class Initialized
INFO - 2016-05-22 11:59:27 --> Output Class Initialized
INFO - 2016-05-22 11:59:27 --> Security Class Initialized
DEBUG - 2016-05-22 11:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 11:59:27 --> Input Class Initialized
INFO - 2016-05-22 11:59:27 --> Language Class Initialized
INFO - 2016-05-22 11:59:27 --> Loader Class Initialized
INFO - 2016-05-22 11:59:27 --> Helper loaded: url_helper
INFO - 2016-05-22 11:59:27 --> Helper loaded: sesion_helper
INFO - 2016-05-22 11:59:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 11:59:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 11:59:27 --> Helper loaded: redondear_helper
INFO - 2016-05-22 11:59:27 --> Helper loaded: form_helper
INFO - 2016-05-22 11:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 11:59:27 --> Form Validation Class Initialized
INFO - 2016-05-22 11:59:27 --> Controller Class Initialized
INFO - 2016-05-22 11:59:27 --> Model Class Initialized
INFO - 2016-05-22 11:59:27 --> Database Driver Class Initialized
INFO - 2016-05-22 11:59:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 11:59:27 --> Pagination Class Initialized
DEBUG - 2016-05-22 11:59:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 11:59:27 --> Final output sent to browser
DEBUG - 2016-05-22 11:59:27 --> Total execution time: 0.0861
INFO - 2016-05-22 12:00:27 --> Config Class Initialized
INFO - 2016-05-22 12:00:27 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:00:27 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:00:27 --> Utf8 Class Initialized
INFO - 2016-05-22 12:00:27 --> URI Class Initialized
INFO - 2016-05-22 12:00:27 --> Router Class Initialized
INFO - 2016-05-22 12:00:27 --> Output Class Initialized
INFO - 2016-05-22 12:00:27 --> Security Class Initialized
DEBUG - 2016-05-22 12:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:00:27 --> Input Class Initialized
INFO - 2016-05-22 12:00:27 --> Language Class Initialized
INFO - 2016-05-22 12:00:27 --> Loader Class Initialized
INFO - 2016-05-22 12:00:27 --> Helper loaded: url_helper
INFO - 2016-05-22 12:00:27 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:00:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:00:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:00:27 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:00:27 --> Helper loaded: form_helper
INFO - 2016-05-22 12:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:00:27 --> Form Validation Class Initialized
INFO - 2016-05-22 12:00:27 --> Controller Class Initialized
INFO - 2016-05-22 12:00:27 --> Model Class Initialized
INFO - 2016-05-22 12:00:27 --> Database Driver Class Initialized
INFO - 2016-05-22 12:00:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:00:27 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:00:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:00:27 --> Final output sent to browser
DEBUG - 2016-05-22 12:00:27 --> Total execution time: 0.0735
INFO - 2016-05-22 12:01:27 --> Config Class Initialized
INFO - 2016-05-22 12:01:27 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:01:27 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:01:27 --> Utf8 Class Initialized
INFO - 2016-05-22 12:01:27 --> URI Class Initialized
INFO - 2016-05-22 12:01:27 --> Router Class Initialized
INFO - 2016-05-22 12:01:27 --> Output Class Initialized
INFO - 2016-05-22 12:01:27 --> Security Class Initialized
DEBUG - 2016-05-22 12:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:01:27 --> Input Class Initialized
INFO - 2016-05-22 12:01:27 --> Language Class Initialized
INFO - 2016-05-22 12:01:27 --> Loader Class Initialized
INFO - 2016-05-22 12:01:27 --> Helper loaded: url_helper
INFO - 2016-05-22 12:01:27 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:01:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:01:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:01:27 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:01:27 --> Helper loaded: form_helper
INFO - 2016-05-22 12:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:01:27 --> Form Validation Class Initialized
INFO - 2016-05-22 12:01:27 --> Controller Class Initialized
INFO - 2016-05-22 12:01:27 --> Model Class Initialized
INFO - 2016-05-22 12:01:27 --> Database Driver Class Initialized
INFO - 2016-05-22 12:01:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:01:27 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:01:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:01:27 --> Final output sent to browser
DEBUG - 2016-05-22 12:01:27 --> Total execution time: 0.0701
INFO - 2016-05-22 12:01:45 --> Config Class Initialized
INFO - 2016-05-22 12:01:45 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:01:45 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:01:45 --> Utf8 Class Initialized
INFO - 2016-05-22 12:01:45 --> URI Class Initialized
INFO - 2016-05-22 12:01:45 --> Router Class Initialized
INFO - 2016-05-22 12:01:45 --> Output Class Initialized
INFO - 2016-05-22 12:01:45 --> Security Class Initialized
DEBUG - 2016-05-22 12:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:01:45 --> Input Class Initialized
INFO - 2016-05-22 12:01:45 --> Language Class Initialized
INFO - 2016-05-22 12:01:45 --> Loader Class Initialized
INFO - 2016-05-22 12:01:45 --> Helper loaded: url_helper
INFO - 2016-05-22 12:01:45 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:01:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:01:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:01:45 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:01:45 --> Helper loaded: form_helper
INFO - 2016-05-22 12:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:01:45 --> Form Validation Class Initialized
INFO - 2016-05-22 12:01:45 --> Controller Class Initialized
INFO - 2016-05-22 12:01:45 --> Model Class Initialized
INFO - 2016-05-22 12:01:45 --> Database Driver Class Initialized
INFO - 2016-05-22 12:01:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:01:45 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:01:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:01:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 12:01:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 12:01:45 --> Final output sent to browser
DEBUG - 2016-05-22 12:01:45 --> Total execution time: 0.0845
INFO - 2016-05-22 12:01:45 --> Config Class Initialized
INFO - 2016-05-22 12:01:45 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:01:45 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:01:45 --> Utf8 Class Initialized
INFO - 2016-05-22 12:01:45 --> URI Class Initialized
INFO - 2016-05-22 12:01:45 --> Router Class Initialized
INFO - 2016-05-22 12:01:45 --> Output Class Initialized
INFO - 2016-05-22 12:01:45 --> Security Class Initialized
DEBUG - 2016-05-22 12:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:01:45 --> Input Class Initialized
INFO - 2016-05-22 12:01:45 --> Language Class Initialized
INFO - 2016-05-22 12:01:45 --> Loader Class Initialized
INFO - 2016-05-22 12:01:45 --> Helper loaded: url_helper
INFO - 2016-05-22 12:01:45 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:01:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:01:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:01:45 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:01:45 --> Helper loaded: form_helper
INFO - 2016-05-22 12:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:01:45 --> Form Validation Class Initialized
INFO - 2016-05-22 12:01:45 --> Controller Class Initialized
INFO - 2016-05-22 12:01:45 --> Model Class Initialized
INFO - 2016-05-22 12:01:45 --> Database Driver Class Initialized
INFO - 2016-05-22 12:01:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:01:45 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:01:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:01:45 --> Final output sent to browser
DEBUG - 2016-05-22 12:01:45 --> Total execution time: 0.0894
INFO - 2016-05-22 12:01:47 --> Config Class Initialized
INFO - 2016-05-22 12:01:47 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:01:47 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:01:47 --> Utf8 Class Initialized
INFO - 2016-05-22 12:01:47 --> URI Class Initialized
INFO - 2016-05-22 12:01:47 --> Router Class Initialized
INFO - 2016-05-22 12:01:47 --> Output Class Initialized
INFO - 2016-05-22 12:01:47 --> Security Class Initialized
DEBUG - 2016-05-22 12:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:01:47 --> Input Class Initialized
INFO - 2016-05-22 12:01:47 --> Language Class Initialized
INFO - 2016-05-22 12:01:47 --> Loader Class Initialized
INFO - 2016-05-22 12:01:47 --> Helper loaded: url_helper
INFO - 2016-05-22 12:01:47 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:01:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:01:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:01:47 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:01:47 --> Helper loaded: form_helper
INFO - 2016-05-22 12:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:01:47 --> Form Validation Class Initialized
INFO - 2016-05-22 12:01:47 --> Controller Class Initialized
INFO - 2016-05-22 12:01:47 --> Model Class Initialized
INFO - 2016-05-22 12:01:47 --> Database Driver Class Initialized
INFO - 2016-05-22 12:01:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:01:47 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:01:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:01:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 12:01:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 12:01:47 --> Final output sent to browser
DEBUG - 2016-05-22 12:01:47 --> Total execution time: 0.0941
INFO - 2016-05-22 12:01:47 --> Config Class Initialized
INFO - 2016-05-22 12:01:47 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:01:47 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:01:47 --> Utf8 Class Initialized
INFO - 2016-05-22 12:01:47 --> URI Class Initialized
INFO - 2016-05-22 12:01:47 --> Router Class Initialized
INFO - 2016-05-22 12:01:47 --> Output Class Initialized
INFO - 2016-05-22 12:01:47 --> Security Class Initialized
DEBUG - 2016-05-22 12:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:01:47 --> Input Class Initialized
INFO - 2016-05-22 12:01:47 --> Language Class Initialized
INFO - 2016-05-22 12:01:47 --> Loader Class Initialized
INFO - 2016-05-22 12:01:47 --> Helper loaded: url_helper
INFO - 2016-05-22 12:01:47 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:01:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:01:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:01:47 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:01:47 --> Helper loaded: form_helper
INFO - 2016-05-22 12:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:01:47 --> Form Validation Class Initialized
INFO - 2016-05-22 12:01:47 --> Controller Class Initialized
INFO - 2016-05-22 12:01:47 --> Model Class Initialized
INFO - 2016-05-22 12:01:47 --> Database Driver Class Initialized
INFO - 2016-05-22 12:01:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:01:47 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:01:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:01:47 --> Final output sent to browser
DEBUG - 2016-05-22 12:01:47 --> Total execution time: 0.1010
INFO - 2016-05-22 12:01:48 --> Config Class Initialized
INFO - 2016-05-22 12:01:48 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:01:48 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:01:48 --> Utf8 Class Initialized
INFO - 2016-05-22 12:01:48 --> URI Class Initialized
INFO - 2016-05-22 12:01:48 --> Router Class Initialized
INFO - 2016-05-22 12:01:48 --> Output Class Initialized
INFO - 2016-05-22 12:01:48 --> Security Class Initialized
DEBUG - 2016-05-22 12:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:01:48 --> Input Class Initialized
INFO - 2016-05-22 12:01:48 --> Language Class Initialized
INFO - 2016-05-22 12:01:48 --> Loader Class Initialized
INFO - 2016-05-22 12:01:48 --> Helper loaded: url_helper
INFO - 2016-05-22 12:01:48 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:01:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:01:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:01:48 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:01:48 --> Helper loaded: form_helper
INFO - 2016-05-22 12:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:01:48 --> Form Validation Class Initialized
INFO - 2016-05-22 12:01:48 --> Controller Class Initialized
INFO - 2016-05-22 12:01:48 --> Model Class Initialized
INFO - 2016-05-22 12:01:48 --> Database Driver Class Initialized
INFO - 2016-05-22 12:01:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:01:48 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:01:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:01:48 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 12:01:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 12:01:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 12:01:48 --> Final output sent to browser
DEBUG - 2016-05-22 12:01:48 --> Total execution time: 0.1709
INFO - 2016-05-22 12:01:49 --> Config Class Initialized
INFO - 2016-05-22 12:01:49 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:01:49 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:01:49 --> Utf8 Class Initialized
INFO - 2016-05-22 12:01:49 --> URI Class Initialized
INFO - 2016-05-22 12:01:49 --> Router Class Initialized
INFO - 2016-05-22 12:01:49 --> Output Class Initialized
INFO - 2016-05-22 12:01:49 --> Security Class Initialized
DEBUG - 2016-05-22 12:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:01:49 --> Input Class Initialized
INFO - 2016-05-22 12:01:49 --> Language Class Initialized
INFO - 2016-05-22 12:01:49 --> Loader Class Initialized
INFO - 2016-05-22 12:01:49 --> Helper loaded: url_helper
INFO - 2016-05-22 12:01:49 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:01:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:01:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:01:49 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:01:49 --> Helper loaded: form_helper
INFO - 2016-05-22 12:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:01:49 --> Form Validation Class Initialized
INFO - 2016-05-22 12:01:49 --> Controller Class Initialized
INFO - 2016-05-22 12:01:49 --> Model Class Initialized
INFO - 2016-05-22 12:01:49 --> Database Driver Class Initialized
INFO - 2016-05-22 12:01:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:01:49 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:01:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:01:49 --> Final output sent to browser
DEBUG - 2016-05-22 12:01:49 --> Total execution time: 0.1314
INFO - 2016-05-22 12:01:50 --> Config Class Initialized
INFO - 2016-05-22 12:01:50 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:01:50 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:01:50 --> Utf8 Class Initialized
INFO - 2016-05-22 12:01:50 --> URI Class Initialized
INFO - 2016-05-22 12:01:50 --> Router Class Initialized
INFO - 2016-05-22 12:01:50 --> Output Class Initialized
INFO - 2016-05-22 12:01:50 --> Security Class Initialized
DEBUG - 2016-05-22 12:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:01:50 --> Input Class Initialized
INFO - 2016-05-22 12:01:50 --> Language Class Initialized
INFO - 2016-05-22 12:01:50 --> Loader Class Initialized
INFO - 2016-05-22 12:01:50 --> Helper loaded: url_helper
INFO - 2016-05-22 12:01:50 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:01:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:01:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:01:50 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:01:50 --> Helper loaded: form_helper
INFO - 2016-05-22 12:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:01:50 --> Form Validation Class Initialized
INFO - 2016-05-22 12:01:50 --> Controller Class Initialized
INFO - 2016-05-22 12:01:50 --> Model Class Initialized
INFO - 2016-05-22 12:01:50 --> Database Driver Class Initialized
INFO - 2016-05-22 12:01:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:01:50 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:01:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:01:50 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 12:01:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 12:01:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 12:01:50 --> Final output sent to browser
DEBUG - 2016-05-22 12:01:50 --> Total execution time: 0.2262
INFO - 2016-05-22 12:01:50 --> Config Class Initialized
INFO - 2016-05-22 12:01:50 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:01:50 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:01:50 --> Utf8 Class Initialized
INFO - 2016-05-22 12:01:50 --> URI Class Initialized
INFO - 2016-05-22 12:01:50 --> Router Class Initialized
INFO - 2016-05-22 12:01:50 --> Output Class Initialized
INFO - 2016-05-22 12:01:50 --> Security Class Initialized
DEBUG - 2016-05-22 12:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:01:50 --> Input Class Initialized
INFO - 2016-05-22 12:01:50 --> Language Class Initialized
INFO - 2016-05-22 12:01:50 --> Loader Class Initialized
INFO - 2016-05-22 12:01:50 --> Helper loaded: url_helper
INFO - 2016-05-22 12:01:50 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:01:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:01:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:01:50 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:01:50 --> Helper loaded: form_helper
INFO - 2016-05-22 12:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:01:50 --> Form Validation Class Initialized
INFO - 2016-05-22 12:01:50 --> Controller Class Initialized
INFO - 2016-05-22 12:01:50 --> Model Class Initialized
INFO - 2016-05-22 12:01:51 --> Database Driver Class Initialized
INFO - 2016-05-22 12:01:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:01:51 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:01:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:01:51 --> Final output sent to browser
DEBUG - 2016-05-22 12:01:51 --> Total execution time: 0.1141
INFO - 2016-05-22 12:01:51 --> Config Class Initialized
INFO - 2016-05-22 12:01:51 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:01:51 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:01:51 --> Utf8 Class Initialized
INFO - 2016-05-22 12:01:51 --> URI Class Initialized
INFO - 2016-05-22 12:01:51 --> Router Class Initialized
INFO - 2016-05-22 12:01:51 --> Output Class Initialized
INFO - 2016-05-22 12:01:51 --> Security Class Initialized
DEBUG - 2016-05-22 12:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:01:51 --> Input Class Initialized
INFO - 2016-05-22 12:01:51 --> Language Class Initialized
INFO - 2016-05-22 12:01:51 --> Loader Class Initialized
INFO - 2016-05-22 12:01:51 --> Helper loaded: url_helper
INFO - 2016-05-22 12:01:51 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:01:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:01:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:01:51 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:01:51 --> Helper loaded: form_helper
INFO - 2016-05-22 12:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:01:51 --> Form Validation Class Initialized
INFO - 2016-05-22 12:01:51 --> Controller Class Initialized
INFO - 2016-05-22 12:01:51 --> Model Class Initialized
INFO - 2016-05-22 12:01:51 --> Database Driver Class Initialized
INFO - 2016-05-22 12:01:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:01:51 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:01:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:01:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 12:01:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 12:01:51 --> Final output sent to browser
DEBUG - 2016-05-22 12:01:51 --> Total execution time: 0.0944
INFO - 2016-05-22 12:01:51 --> Config Class Initialized
INFO - 2016-05-22 12:01:51 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:01:51 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:01:51 --> Utf8 Class Initialized
INFO - 2016-05-22 12:01:51 --> URI Class Initialized
INFO - 2016-05-22 12:01:51 --> Router Class Initialized
INFO - 2016-05-22 12:01:51 --> Output Class Initialized
INFO - 2016-05-22 12:01:51 --> Security Class Initialized
DEBUG - 2016-05-22 12:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:01:51 --> Input Class Initialized
INFO - 2016-05-22 12:01:51 --> Language Class Initialized
INFO - 2016-05-22 12:01:51 --> Loader Class Initialized
INFO - 2016-05-22 12:01:51 --> Helper loaded: url_helper
INFO - 2016-05-22 12:01:51 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:01:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:01:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:01:51 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:01:51 --> Helper loaded: form_helper
INFO - 2016-05-22 12:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:01:51 --> Form Validation Class Initialized
INFO - 2016-05-22 12:01:51 --> Controller Class Initialized
INFO - 2016-05-22 12:01:51 --> Model Class Initialized
INFO - 2016-05-22 12:01:51 --> Database Driver Class Initialized
INFO - 2016-05-22 12:01:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:01:51 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:01:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:01:51 --> Final output sent to browser
DEBUG - 2016-05-22 12:01:51 --> Total execution time: 0.1026
INFO - 2016-05-22 12:01:55 --> Config Class Initialized
INFO - 2016-05-22 12:01:55 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:01:55 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:01:55 --> Utf8 Class Initialized
INFO - 2016-05-22 12:01:55 --> URI Class Initialized
INFO - 2016-05-22 12:01:55 --> Router Class Initialized
INFO - 2016-05-22 12:01:55 --> Output Class Initialized
INFO - 2016-05-22 12:01:55 --> Security Class Initialized
DEBUG - 2016-05-22 12:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:01:55 --> Input Class Initialized
INFO - 2016-05-22 12:01:55 --> Language Class Initialized
INFO - 2016-05-22 12:01:55 --> Loader Class Initialized
INFO - 2016-05-22 12:01:55 --> Helper loaded: url_helper
INFO - 2016-05-22 12:01:55 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:01:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:01:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:01:55 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:01:55 --> Helper loaded: form_helper
INFO - 2016-05-22 12:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:01:55 --> Form Validation Class Initialized
INFO - 2016-05-22 12:01:55 --> Controller Class Initialized
INFO - 2016-05-22 12:01:55 --> Model Class Initialized
INFO - 2016-05-22 12:01:55 --> Database Driver Class Initialized
INFO - 2016-05-22 12:01:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:01:55 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:01:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:01:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 12:01:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 12:01:56 --> Final output sent to browser
DEBUG - 2016-05-22 12:01:56 --> Total execution time: 0.0822
INFO - 2016-05-22 12:01:56 --> Config Class Initialized
INFO - 2016-05-22 12:01:56 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:01:56 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:01:56 --> Utf8 Class Initialized
INFO - 2016-05-22 12:01:56 --> URI Class Initialized
INFO - 2016-05-22 12:01:56 --> Router Class Initialized
INFO - 2016-05-22 12:01:56 --> Output Class Initialized
INFO - 2016-05-22 12:01:56 --> Security Class Initialized
DEBUG - 2016-05-22 12:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:01:56 --> Input Class Initialized
INFO - 2016-05-22 12:01:56 --> Language Class Initialized
INFO - 2016-05-22 12:01:56 --> Loader Class Initialized
INFO - 2016-05-22 12:01:56 --> Helper loaded: url_helper
INFO - 2016-05-22 12:01:56 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:01:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:01:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:01:56 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:01:56 --> Helper loaded: form_helper
INFO - 2016-05-22 12:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:01:56 --> Form Validation Class Initialized
INFO - 2016-05-22 12:01:56 --> Controller Class Initialized
INFO - 2016-05-22 12:01:56 --> Model Class Initialized
INFO - 2016-05-22 12:01:56 --> Database Driver Class Initialized
INFO - 2016-05-22 12:01:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:01:56 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:01:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:01:56 --> Final output sent to browser
DEBUG - 2016-05-22 12:01:56 --> Total execution time: 0.0931
INFO - 2016-05-22 12:02:16 --> Config Class Initialized
INFO - 2016-05-22 12:02:16 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:02:16 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:02:16 --> Utf8 Class Initialized
INFO - 2016-05-22 12:02:16 --> URI Class Initialized
INFO - 2016-05-22 12:02:16 --> Router Class Initialized
INFO - 2016-05-22 12:02:16 --> Output Class Initialized
INFO - 2016-05-22 12:02:16 --> Security Class Initialized
DEBUG - 2016-05-22 12:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:02:16 --> Input Class Initialized
INFO - 2016-05-22 12:02:16 --> Language Class Initialized
INFO - 2016-05-22 12:02:16 --> Loader Class Initialized
INFO - 2016-05-22 12:02:16 --> Helper loaded: url_helper
INFO - 2016-05-22 12:02:16 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:02:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:02:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:02:16 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:02:16 --> Helper loaded: form_helper
INFO - 2016-05-22 12:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:02:16 --> Form Validation Class Initialized
INFO - 2016-05-22 12:02:16 --> Controller Class Initialized
INFO - 2016-05-22 12:02:16 --> Model Class Initialized
INFO - 2016-05-22 12:02:16 --> Database Driver Class Initialized
INFO - 2016-05-22 12:02:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:02:16 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:02:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:02:16 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 12:02:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 12:02:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 12:02:17 --> Final output sent to browser
DEBUG - 2016-05-22 12:02:17 --> Total execution time: 0.1992
INFO - 2016-05-22 12:02:17 --> Config Class Initialized
INFO - 2016-05-22 12:02:17 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:02:17 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:02:17 --> Utf8 Class Initialized
INFO - 2016-05-22 12:02:17 --> URI Class Initialized
INFO - 2016-05-22 12:02:17 --> Router Class Initialized
INFO - 2016-05-22 12:02:17 --> Output Class Initialized
INFO - 2016-05-22 12:02:17 --> Security Class Initialized
DEBUG - 2016-05-22 12:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:02:17 --> Input Class Initialized
INFO - 2016-05-22 12:02:17 --> Language Class Initialized
INFO - 2016-05-22 12:02:17 --> Loader Class Initialized
INFO - 2016-05-22 12:02:17 --> Helper loaded: url_helper
INFO - 2016-05-22 12:02:17 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:02:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:02:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:02:17 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:02:17 --> Helper loaded: form_helper
INFO - 2016-05-22 12:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:02:17 --> Form Validation Class Initialized
INFO - 2016-05-22 12:02:17 --> Controller Class Initialized
INFO - 2016-05-22 12:02:17 --> Model Class Initialized
INFO - 2016-05-22 12:02:17 --> Database Driver Class Initialized
INFO - 2016-05-22 12:02:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:02:17 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:02:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:02:17 --> Final output sent to browser
DEBUG - 2016-05-22 12:02:17 --> Total execution time: 0.0935
INFO - 2016-05-22 12:02:41 --> Config Class Initialized
INFO - 2016-05-22 12:02:41 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:02:41 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:02:41 --> Utf8 Class Initialized
INFO - 2016-05-22 12:02:41 --> URI Class Initialized
INFO - 2016-05-22 12:02:41 --> Router Class Initialized
INFO - 2016-05-22 12:02:41 --> Output Class Initialized
INFO - 2016-05-22 12:02:41 --> Security Class Initialized
DEBUG - 2016-05-22 12:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:02:41 --> Input Class Initialized
INFO - 2016-05-22 12:02:41 --> Language Class Initialized
INFO - 2016-05-22 12:02:41 --> Loader Class Initialized
INFO - 2016-05-22 12:02:42 --> Helper loaded: url_helper
INFO - 2016-05-22 12:02:42 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:02:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:02:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:02:42 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:02:42 --> Helper loaded: form_helper
INFO - 2016-05-22 12:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:02:42 --> Form Validation Class Initialized
INFO - 2016-05-22 12:02:42 --> Controller Class Initialized
INFO - 2016-05-22 12:02:42 --> Model Class Initialized
INFO - 2016-05-22 12:02:42 --> Database Driver Class Initialized
INFO - 2016-05-22 12:02:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:02:42 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:02:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:02:42 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 12:02:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 12:02:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 12:02:42 --> Final output sent to browser
DEBUG - 2016-05-22 12:02:42 --> Total execution time: 0.1499
INFO - 2016-05-22 12:02:42 --> Config Class Initialized
INFO - 2016-05-22 12:02:42 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:02:42 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:02:42 --> Utf8 Class Initialized
INFO - 2016-05-22 12:02:42 --> URI Class Initialized
INFO - 2016-05-22 12:02:42 --> Router Class Initialized
INFO - 2016-05-22 12:02:42 --> Output Class Initialized
INFO - 2016-05-22 12:02:42 --> Security Class Initialized
DEBUG - 2016-05-22 12:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:02:42 --> Input Class Initialized
INFO - 2016-05-22 12:02:42 --> Language Class Initialized
INFO - 2016-05-22 12:02:42 --> Loader Class Initialized
INFO - 2016-05-22 12:02:42 --> Helper loaded: url_helper
INFO - 2016-05-22 12:02:42 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:02:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:02:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:02:42 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:02:42 --> Helper loaded: form_helper
INFO - 2016-05-22 12:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:02:42 --> Form Validation Class Initialized
INFO - 2016-05-22 12:02:42 --> Controller Class Initialized
INFO - 2016-05-22 12:02:42 --> Model Class Initialized
INFO - 2016-05-22 12:02:42 --> Database Driver Class Initialized
INFO - 2016-05-22 12:02:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:02:42 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:02:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:02:42 --> Final output sent to browser
DEBUG - 2016-05-22 12:02:42 --> Total execution time: 0.0890
INFO - 2016-05-22 12:02:44 --> Config Class Initialized
INFO - 2016-05-22 12:02:44 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:02:44 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:02:44 --> Utf8 Class Initialized
INFO - 2016-05-22 12:02:44 --> URI Class Initialized
INFO - 2016-05-22 12:02:44 --> Router Class Initialized
INFO - 2016-05-22 12:02:44 --> Output Class Initialized
INFO - 2016-05-22 12:02:44 --> Security Class Initialized
DEBUG - 2016-05-22 12:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:02:44 --> Input Class Initialized
INFO - 2016-05-22 12:02:44 --> Language Class Initialized
INFO - 2016-05-22 12:02:44 --> Loader Class Initialized
INFO - 2016-05-22 12:02:44 --> Helper loaded: url_helper
INFO - 2016-05-22 12:02:44 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:02:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:02:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:02:44 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:02:44 --> Helper loaded: form_helper
INFO - 2016-05-22 12:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:02:44 --> Form Validation Class Initialized
INFO - 2016-05-22 12:02:44 --> Controller Class Initialized
INFO - 2016-05-22 12:02:44 --> Model Class Initialized
INFO - 2016-05-22 12:02:44 --> Database Driver Class Initialized
INFO - 2016-05-22 12:02:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:02:44 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:02:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:02:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 12:02:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 12:02:44 --> Final output sent to browser
DEBUG - 2016-05-22 12:02:44 --> Total execution time: 0.1050
INFO - 2016-05-22 12:02:44 --> Config Class Initialized
INFO - 2016-05-22 12:02:44 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:02:44 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:02:44 --> Utf8 Class Initialized
INFO - 2016-05-22 12:02:44 --> URI Class Initialized
INFO - 2016-05-22 12:02:44 --> Router Class Initialized
INFO - 2016-05-22 12:02:44 --> Output Class Initialized
INFO - 2016-05-22 12:02:44 --> Security Class Initialized
DEBUG - 2016-05-22 12:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:02:44 --> Input Class Initialized
INFO - 2016-05-22 12:02:44 --> Language Class Initialized
INFO - 2016-05-22 12:02:44 --> Loader Class Initialized
INFO - 2016-05-22 12:02:44 --> Helper loaded: url_helper
INFO - 2016-05-22 12:02:44 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:02:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:02:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:02:44 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:02:44 --> Helper loaded: form_helper
INFO - 2016-05-22 12:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:02:44 --> Form Validation Class Initialized
INFO - 2016-05-22 12:02:44 --> Controller Class Initialized
INFO - 2016-05-22 12:02:44 --> Model Class Initialized
INFO - 2016-05-22 12:02:44 --> Database Driver Class Initialized
INFO - 2016-05-22 12:02:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:02:44 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:02:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:02:44 --> Final output sent to browser
DEBUG - 2016-05-22 12:02:44 --> Total execution time: 0.0874
INFO - 2016-05-22 12:03:44 --> Config Class Initialized
INFO - 2016-05-22 12:03:44 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:03:44 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:03:44 --> Utf8 Class Initialized
INFO - 2016-05-22 12:03:44 --> URI Class Initialized
INFO - 2016-05-22 12:03:44 --> Router Class Initialized
INFO - 2016-05-22 12:03:44 --> Output Class Initialized
INFO - 2016-05-22 12:03:44 --> Security Class Initialized
DEBUG - 2016-05-22 12:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:03:44 --> Input Class Initialized
INFO - 2016-05-22 12:03:44 --> Language Class Initialized
INFO - 2016-05-22 12:03:44 --> Loader Class Initialized
INFO - 2016-05-22 12:03:44 --> Helper loaded: url_helper
INFO - 2016-05-22 12:03:44 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:03:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:03:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:03:44 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:03:44 --> Helper loaded: form_helper
INFO - 2016-05-22 12:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:03:44 --> Form Validation Class Initialized
INFO - 2016-05-22 12:03:44 --> Controller Class Initialized
INFO - 2016-05-22 12:03:44 --> Model Class Initialized
INFO - 2016-05-22 12:03:44 --> Database Driver Class Initialized
INFO - 2016-05-22 12:03:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:03:44 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:03:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:03:44 --> Final output sent to browser
DEBUG - 2016-05-22 12:03:44 --> Total execution time: 0.0772
INFO - 2016-05-22 12:04:44 --> Config Class Initialized
INFO - 2016-05-22 12:04:44 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:04:44 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:04:44 --> Utf8 Class Initialized
INFO - 2016-05-22 12:04:44 --> URI Class Initialized
INFO - 2016-05-22 12:04:44 --> Router Class Initialized
INFO - 2016-05-22 12:04:44 --> Output Class Initialized
INFO - 2016-05-22 12:04:44 --> Security Class Initialized
DEBUG - 2016-05-22 12:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:04:44 --> Input Class Initialized
INFO - 2016-05-22 12:04:44 --> Language Class Initialized
INFO - 2016-05-22 12:04:44 --> Loader Class Initialized
INFO - 2016-05-22 12:04:44 --> Helper loaded: url_helper
INFO - 2016-05-22 12:04:44 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:04:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:04:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:04:44 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:04:44 --> Helper loaded: form_helper
INFO - 2016-05-22 12:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:04:44 --> Form Validation Class Initialized
INFO - 2016-05-22 12:04:44 --> Controller Class Initialized
INFO - 2016-05-22 12:04:44 --> Model Class Initialized
INFO - 2016-05-22 12:04:44 --> Database Driver Class Initialized
INFO - 2016-05-22 12:04:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:04:44 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:04:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:04:44 --> Final output sent to browser
DEBUG - 2016-05-22 12:04:44 --> Total execution time: 0.0773
INFO - 2016-05-22 12:05:07 --> Config Class Initialized
INFO - 2016-05-22 12:05:07 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:05:07 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:05:07 --> Utf8 Class Initialized
INFO - 2016-05-22 12:05:07 --> URI Class Initialized
INFO - 2016-05-22 12:05:07 --> Router Class Initialized
INFO - 2016-05-22 12:05:07 --> Output Class Initialized
INFO - 2016-05-22 12:05:07 --> Security Class Initialized
DEBUG - 2016-05-22 12:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:05:07 --> Input Class Initialized
INFO - 2016-05-22 12:05:07 --> Language Class Initialized
INFO - 2016-05-22 12:05:07 --> Loader Class Initialized
INFO - 2016-05-22 12:05:07 --> Helper loaded: url_helper
INFO - 2016-05-22 12:05:07 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:05:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:05:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:05:07 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:05:07 --> Helper loaded: form_helper
INFO - 2016-05-22 12:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:05:07 --> Form Validation Class Initialized
INFO - 2016-05-22 12:05:07 --> Controller Class Initialized
INFO - 2016-05-22 12:05:07 --> Model Class Initialized
INFO - 2016-05-22 12:05:07 --> Database Driver Class Initialized
INFO - 2016-05-22 12:05:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:05:07 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:05:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:05:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 12:05:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 12:05:07 --> Final output sent to browser
DEBUG - 2016-05-22 12:05:07 --> Total execution time: 0.0807
INFO - 2016-05-22 12:05:07 --> Config Class Initialized
INFO - 2016-05-22 12:05:07 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:05:07 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:05:07 --> Utf8 Class Initialized
INFO - 2016-05-22 12:05:07 --> URI Class Initialized
INFO - 2016-05-22 12:05:07 --> Router Class Initialized
INFO - 2016-05-22 12:05:07 --> Output Class Initialized
INFO - 2016-05-22 12:05:07 --> Security Class Initialized
DEBUG - 2016-05-22 12:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:05:07 --> Input Class Initialized
INFO - 2016-05-22 12:05:07 --> Language Class Initialized
INFO - 2016-05-22 12:05:07 --> Loader Class Initialized
INFO - 2016-05-22 12:05:07 --> Helper loaded: url_helper
INFO - 2016-05-22 12:05:07 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:05:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:05:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:05:07 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:05:07 --> Helper loaded: form_helper
INFO - 2016-05-22 12:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:05:07 --> Form Validation Class Initialized
INFO - 2016-05-22 12:05:07 --> Controller Class Initialized
INFO - 2016-05-22 12:05:07 --> Model Class Initialized
INFO - 2016-05-22 12:05:07 --> Database Driver Class Initialized
INFO - 2016-05-22 12:05:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:05:07 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:05:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:05:07 --> Final output sent to browser
DEBUG - 2016-05-22 12:05:07 --> Total execution time: 0.0960
INFO - 2016-05-22 12:05:15 --> Config Class Initialized
INFO - 2016-05-22 12:05:15 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:05:15 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:05:15 --> Utf8 Class Initialized
INFO - 2016-05-22 12:05:15 --> URI Class Initialized
INFO - 2016-05-22 12:05:15 --> Router Class Initialized
INFO - 2016-05-22 12:05:15 --> Output Class Initialized
INFO - 2016-05-22 12:05:15 --> Security Class Initialized
DEBUG - 2016-05-22 12:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:05:15 --> Input Class Initialized
INFO - 2016-05-22 12:05:15 --> Language Class Initialized
INFO - 2016-05-22 12:05:15 --> Loader Class Initialized
INFO - 2016-05-22 12:05:15 --> Helper loaded: url_helper
INFO - 2016-05-22 12:05:15 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:05:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:05:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:05:15 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:05:15 --> Helper loaded: form_helper
INFO - 2016-05-22 12:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:05:15 --> Form Validation Class Initialized
INFO - 2016-05-22 12:05:15 --> Controller Class Initialized
INFO - 2016-05-22 12:05:15 --> Model Class Initialized
INFO - 2016-05-22 12:05:15 --> Database Driver Class Initialized
INFO - 2016-05-22 12:05:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:05:15 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:05:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:05:15 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 12:05:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 12:05:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 12:05:15 --> Final output sent to browser
DEBUG - 2016-05-22 12:05:15 --> Total execution time: 0.0834
INFO - 2016-05-22 12:05:15 --> Config Class Initialized
INFO - 2016-05-22 12:05:15 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:05:15 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:05:15 --> Utf8 Class Initialized
INFO - 2016-05-22 12:05:15 --> URI Class Initialized
INFO - 2016-05-22 12:05:15 --> Router Class Initialized
INFO - 2016-05-22 12:05:15 --> Output Class Initialized
INFO - 2016-05-22 12:05:15 --> Security Class Initialized
DEBUG - 2016-05-22 12:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:05:15 --> Input Class Initialized
INFO - 2016-05-22 12:05:15 --> Language Class Initialized
INFO - 2016-05-22 12:05:15 --> Loader Class Initialized
INFO - 2016-05-22 12:05:15 --> Helper loaded: url_helper
INFO - 2016-05-22 12:05:15 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:05:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:05:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:05:15 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:05:15 --> Helper loaded: form_helper
INFO - 2016-05-22 12:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:05:15 --> Form Validation Class Initialized
INFO - 2016-05-22 12:05:15 --> Controller Class Initialized
INFO - 2016-05-22 12:05:15 --> Model Class Initialized
INFO - 2016-05-22 12:05:15 --> Database Driver Class Initialized
INFO - 2016-05-22 12:05:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:05:15 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:05:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:05:15 --> Final output sent to browser
DEBUG - 2016-05-22 12:05:15 --> Total execution time: 0.0828
INFO - 2016-05-22 12:05:21 --> Config Class Initialized
INFO - 2016-05-22 12:05:21 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:05:21 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:05:21 --> Utf8 Class Initialized
INFO - 2016-05-22 12:05:21 --> URI Class Initialized
INFO - 2016-05-22 12:05:21 --> Router Class Initialized
INFO - 2016-05-22 12:05:21 --> Output Class Initialized
INFO - 2016-05-22 12:05:21 --> Security Class Initialized
DEBUG - 2016-05-22 12:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:05:21 --> Input Class Initialized
INFO - 2016-05-22 12:05:21 --> Language Class Initialized
INFO - 2016-05-22 12:05:21 --> Loader Class Initialized
INFO - 2016-05-22 12:05:21 --> Helper loaded: url_helper
INFO - 2016-05-22 12:05:21 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:05:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:05:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:05:21 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:05:21 --> Helper loaded: form_helper
INFO - 2016-05-22 12:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:05:21 --> Form Validation Class Initialized
INFO - 2016-05-22 12:05:21 --> Controller Class Initialized
INFO - 2016-05-22 12:05:21 --> Model Class Initialized
INFO - 2016-05-22 12:05:21 --> Database Driver Class Initialized
INFO - 2016-05-22 12:05:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:05:21 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:05:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:05:21 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 12:05:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-22 12:05:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 12:05:21 --> Final output sent to browser
DEBUG - 2016-05-22 12:05:21 --> Total execution time: 0.1235
INFO - 2016-05-22 12:05:21 --> Config Class Initialized
INFO - 2016-05-22 12:05:21 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:05:21 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:05:21 --> Utf8 Class Initialized
INFO - 2016-05-22 12:05:21 --> URI Class Initialized
INFO - 2016-05-22 12:05:21 --> Router Class Initialized
INFO - 2016-05-22 12:05:21 --> Output Class Initialized
INFO - 2016-05-22 12:05:21 --> Security Class Initialized
DEBUG - 2016-05-22 12:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:05:21 --> Input Class Initialized
INFO - 2016-05-22 12:05:21 --> Language Class Initialized
INFO - 2016-05-22 12:05:21 --> Loader Class Initialized
INFO - 2016-05-22 12:05:21 --> Helper loaded: url_helper
INFO - 2016-05-22 12:05:21 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:05:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:05:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:05:21 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:05:21 --> Helper loaded: form_helper
INFO - 2016-05-22 12:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:05:21 --> Form Validation Class Initialized
INFO - 2016-05-22 12:05:21 --> Controller Class Initialized
INFO - 2016-05-22 12:05:21 --> Model Class Initialized
INFO - 2016-05-22 12:05:21 --> Database Driver Class Initialized
INFO - 2016-05-22 12:05:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:05:21 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:05:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:05:21 --> Final output sent to browser
DEBUG - 2016-05-22 12:05:21 --> Total execution time: 0.1130
INFO - 2016-05-22 12:05:23 --> Config Class Initialized
INFO - 2016-05-22 12:05:23 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:05:23 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:05:23 --> Utf8 Class Initialized
INFO - 2016-05-22 12:05:23 --> URI Class Initialized
INFO - 2016-05-22 12:05:23 --> Router Class Initialized
INFO - 2016-05-22 12:05:23 --> Output Class Initialized
INFO - 2016-05-22 12:05:23 --> Security Class Initialized
DEBUG - 2016-05-22 12:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:05:23 --> Input Class Initialized
INFO - 2016-05-22 12:05:23 --> Language Class Initialized
INFO - 2016-05-22 12:05:23 --> Loader Class Initialized
INFO - 2016-05-22 12:05:23 --> Helper loaded: url_helper
INFO - 2016-05-22 12:05:23 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:05:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:05:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:05:23 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:05:23 --> Helper loaded: form_helper
INFO - 2016-05-22 12:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:05:23 --> Form Validation Class Initialized
INFO - 2016-05-22 12:05:23 --> Controller Class Initialized
INFO - 2016-05-22 12:05:23 --> Model Class Initialized
INFO - 2016-05-22 12:05:24 --> Database Driver Class Initialized
INFO - 2016-05-22 12:05:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:05:24 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:05:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:05:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-22 12:05:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 12:05:24 --> Final output sent to browser
DEBUG - 2016-05-22 12:05:24 --> Total execution time: 0.0976
INFO - 2016-05-22 12:05:24 --> Config Class Initialized
INFO - 2016-05-22 12:05:24 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:05:24 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:05:24 --> Utf8 Class Initialized
INFO - 2016-05-22 12:05:24 --> URI Class Initialized
INFO - 2016-05-22 12:05:24 --> Router Class Initialized
INFO - 2016-05-22 12:05:24 --> Output Class Initialized
INFO - 2016-05-22 12:05:24 --> Security Class Initialized
DEBUG - 2016-05-22 12:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:05:24 --> Input Class Initialized
INFO - 2016-05-22 12:05:24 --> Language Class Initialized
INFO - 2016-05-22 12:05:24 --> Loader Class Initialized
INFO - 2016-05-22 12:05:24 --> Helper loaded: url_helper
INFO - 2016-05-22 12:05:24 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:05:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:05:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:05:24 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:05:24 --> Helper loaded: form_helper
INFO - 2016-05-22 12:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:05:24 --> Form Validation Class Initialized
INFO - 2016-05-22 12:05:24 --> Controller Class Initialized
INFO - 2016-05-22 12:05:24 --> Model Class Initialized
INFO - 2016-05-22 12:05:24 --> Database Driver Class Initialized
INFO - 2016-05-22 12:05:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 12:05:24 --> Pagination Class Initialized
DEBUG - 2016-05-22 12:05:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 12:05:24 --> Final output sent to browser
DEBUG - 2016-05-22 12:05:24 --> Total execution time: 0.0984
INFO - 2016-05-22 12:05:35 --> Config Class Initialized
INFO - 2016-05-22 12:05:35 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:05:35 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:05:35 --> Utf8 Class Initialized
INFO - 2016-05-22 12:05:35 --> URI Class Initialized
INFO - 2016-05-22 12:05:35 --> Router Class Initialized
INFO - 2016-05-22 12:05:35 --> Output Class Initialized
INFO - 2016-05-22 12:05:35 --> Security Class Initialized
DEBUG - 2016-05-22 12:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:05:35 --> Input Class Initialized
INFO - 2016-05-22 12:05:35 --> Language Class Initialized
INFO - 2016-05-22 12:05:35 --> Loader Class Initialized
INFO - 2016-05-22 12:05:35 --> Helper loaded: url_helper
INFO - 2016-05-22 12:05:35 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:05:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:05:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:05:35 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:05:35 --> Helper loaded: form_helper
INFO - 2016-05-22 12:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:05:35 --> Form Validation Class Initialized
INFO - 2016-05-22 12:05:35 --> Controller Class Initialized
INFO - 2016-05-22 12:05:35 --> Model Class Initialized
INFO - 2016-05-22 12:05:35 --> Database Driver Class Initialized
INFO - 2016-05-22 12:05:35 --> Final output sent to browser
DEBUG - 2016-05-22 12:05:35 --> Total execution time: 0.1240
INFO - 2016-05-22 12:06:13 --> Config Class Initialized
INFO - 2016-05-22 12:06:13 --> Hooks Class Initialized
DEBUG - 2016-05-22 12:06:13 --> UTF-8 Support Enabled
INFO - 2016-05-22 12:06:13 --> Utf8 Class Initialized
INFO - 2016-05-22 12:06:13 --> URI Class Initialized
INFO - 2016-05-22 12:06:13 --> Router Class Initialized
INFO - 2016-05-22 12:06:13 --> Output Class Initialized
INFO - 2016-05-22 12:06:13 --> Security Class Initialized
DEBUG - 2016-05-22 12:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 12:06:13 --> Input Class Initialized
INFO - 2016-05-22 12:06:13 --> Language Class Initialized
INFO - 2016-05-22 12:06:13 --> Loader Class Initialized
INFO - 2016-05-22 12:06:13 --> Helper loaded: url_helper
INFO - 2016-05-22 12:06:13 --> Helper loaded: sesion_helper
INFO - 2016-05-22 12:06:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 12:06:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 12:06:13 --> Helper loaded: redondear_helper
INFO - 2016-05-22 12:06:13 --> Helper loaded: form_helper
INFO - 2016-05-22 12:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 12:06:13 --> Form Validation Class Initialized
INFO - 2016-05-22 12:06:13 --> Controller Class Initialized
INFO - 2016-05-22 12:06:13 --> Model Class Initialized
INFO - 2016-05-22 12:06:13 --> Database Driver Class Initialized
INFO - 2016-05-22 12:06:13 --> Final output sent to browser
DEBUG - 2016-05-22 12:06:13 --> Total execution time: 0.1693
INFO - 2016-05-22 18:32:11 --> Config Class Initialized
INFO - 2016-05-22 18:32:11 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:32:11 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:32:11 --> Utf8 Class Initialized
INFO - 2016-05-22 18:32:11 --> URI Class Initialized
DEBUG - 2016-05-22 18:32:11 --> No URI present. Default controller set.
INFO - 2016-05-22 18:32:11 --> Router Class Initialized
INFO - 2016-05-22 18:32:11 --> Output Class Initialized
INFO - 2016-05-22 18:32:11 --> Security Class Initialized
DEBUG - 2016-05-22 18:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:32:11 --> Input Class Initialized
INFO - 2016-05-22 18:32:11 --> Language Class Initialized
INFO - 2016-05-22 18:32:11 --> Loader Class Initialized
INFO - 2016-05-22 18:32:11 --> Helper loaded: url_helper
INFO - 2016-05-22 18:32:11 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:32:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:32:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:32:11 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:32:11 --> Helper loaded: form_helper
INFO - 2016-05-22 18:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:32:11 --> Form Validation Class Initialized
INFO - 2016-05-22 18:32:11 --> Controller Class Initialized
INFO - 2016-05-22 18:32:11 --> Model Class Initialized
INFO - 2016-05-22 18:32:11 --> Database Driver Class Initialized
INFO - 2016-05-22 18:32:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 18:32:11 --> Pagination Class Initialized
DEBUG - 2016-05-22 18:32:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 18:32:11 --> Config Class Initialized
INFO - 2016-05-22 18:32:11 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:32:11 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:32:11 --> Utf8 Class Initialized
INFO - 2016-05-22 18:32:11 --> URI Class Initialized
INFO - 2016-05-22 18:32:11 --> Router Class Initialized
INFO - 2016-05-22 18:32:11 --> Output Class Initialized
INFO - 2016-05-22 18:32:11 --> Security Class Initialized
DEBUG - 2016-05-22 18:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:32:11 --> Input Class Initialized
INFO - 2016-05-22 18:32:11 --> Language Class Initialized
INFO - 2016-05-22 18:32:11 --> Loader Class Initialized
INFO - 2016-05-22 18:32:11 --> Helper loaded: url_helper
INFO - 2016-05-22 18:32:11 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:32:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:32:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:32:11 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:32:11 --> Helper loaded: form_helper
INFO - 2016-05-22 18:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:32:11 --> Form Validation Class Initialized
INFO - 2016-05-22 18:32:11 --> Controller Class Initialized
INFO - 2016-05-22 18:32:11 --> Model Class Initialized
INFO - 2016-05-22 18:32:11 --> Database Driver Class Initialized
INFO - 2016-05-22 18:32:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-22 18:32:11 --> Final output sent to browser
DEBUG - 2016-05-22 18:32:11 --> Total execution time: 0.0666
INFO - 2016-05-22 18:32:14 --> Config Class Initialized
INFO - 2016-05-22 18:32:14 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:32:14 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:32:14 --> Utf8 Class Initialized
INFO - 2016-05-22 18:32:14 --> URI Class Initialized
INFO - 2016-05-22 18:32:14 --> Router Class Initialized
INFO - 2016-05-22 18:32:14 --> Output Class Initialized
INFO - 2016-05-22 18:32:14 --> Security Class Initialized
DEBUG - 2016-05-22 18:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:32:14 --> Input Class Initialized
INFO - 2016-05-22 18:32:14 --> Language Class Initialized
INFO - 2016-05-22 18:32:14 --> Loader Class Initialized
INFO - 2016-05-22 18:32:14 --> Helper loaded: url_helper
INFO - 2016-05-22 18:32:14 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:32:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:32:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:32:14 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:32:14 --> Helper loaded: form_helper
INFO - 2016-05-22 18:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:32:14 --> Form Validation Class Initialized
INFO - 2016-05-22 18:32:14 --> Controller Class Initialized
INFO - 2016-05-22 18:32:14 --> Model Class Initialized
INFO - 2016-05-22 18:32:14 --> Database Driver Class Initialized
INFO - 2016-05-22 18:32:14 --> Email Class Initialized
INFO - 2016-05-22 18:33:06 --> Config Class Initialized
INFO - 2016-05-22 18:33:06 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:33:06 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:33:06 --> Utf8 Class Initialized
INFO - 2016-05-22 18:33:06 --> URI Class Initialized
INFO - 2016-05-22 18:33:06 --> Router Class Initialized
INFO - 2016-05-22 18:33:06 --> Output Class Initialized
INFO - 2016-05-22 18:33:06 --> Security Class Initialized
DEBUG - 2016-05-22 18:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:33:06 --> Input Class Initialized
INFO - 2016-05-22 18:33:06 --> Language Class Initialized
INFO - 2016-05-22 18:33:06 --> Loader Class Initialized
INFO - 2016-05-22 18:33:06 --> Helper loaded: url_helper
INFO - 2016-05-22 18:33:06 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:33:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:33:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:33:06 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:33:06 --> Helper loaded: form_helper
INFO - 2016-05-22 18:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:33:06 --> Form Validation Class Initialized
INFO - 2016-05-22 18:33:06 --> Controller Class Initialized
INFO - 2016-05-22 18:33:06 --> Model Class Initialized
INFO - 2016-05-22 18:33:06 --> Database Driver Class Initialized
INFO - 2016-05-22 18:33:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-22 18:33:06 --> Final output sent to browser
DEBUG - 2016-05-22 18:33:06 --> Total execution time: 0.0761
INFO - 2016-05-22 18:33:09 --> Config Class Initialized
INFO - 2016-05-22 18:33:09 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:33:09 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:33:09 --> Utf8 Class Initialized
INFO - 2016-05-22 18:33:09 --> URI Class Initialized
INFO - 2016-05-22 18:33:09 --> Router Class Initialized
INFO - 2016-05-22 18:33:09 --> Output Class Initialized
INFO - 2016-05-22 18:33:09 --> Security Class Initialized
DEBUG - 2016-05-22 18:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:33:09 --> Input Class Initialized
INFO - 2016-05-22 18:33:09 --> Language Class Initialized
INFO - 2016-05-22 18:33:09 --> Loader Class Initialized
INFO - 2016-05-22 18:33:09 --> Helper loaded: url_helper
INFO - 2016-05-22 18:33:09 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:33:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:33:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:33:09 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:33:09 --> Helper loaded: form_helper
INFO - 2016-05-22 18:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:33:09 --> Form Validation Class Initialized
INFO - 2016-05-22 18:33:09 --> Controller Class Initialized
INFO - 2016-05-22 18:33:09 --> Model Class Initialized
INFO - 2016-05-22 18:33:09 --> Database Driver Class Initialized
INFO - 2016-05-22 18:33:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-22 18:33:09 --> Final output sent to browser
DEBUG - 2016-05-22 18:33:09 --> Total execution time: 0.0754
INFO - 2016-05-22 18:33:10 --> Config Class Initialized
INFO - 2016-05-22 18:33:10 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:33:10 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:33:10 --> Utf8 Class Initialized
INFO - 2016-05-22 18:33:10 --> URI Class Initialized
INFO - 2016-05-22 18:33:10 --> Router Class Initialized
INFO - 2016-05-22 18:33:10 --> Output Class Initialized
INFO - 2016-05-22 18:33:10 --> Security Class Initialized
DEBUG - 2016-05-22 18:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:33:10 --> Input Class Initialized
INFO - 2016-05-22 18:33:10 --> Language Class Initialized
INFO - 2016-05-22 18:33:10 --> Loader Class Initialized
INFO - 2016-05-22 18:33:10 --> Helper loaded: url_helper
INFO - 2016-05-22 18:33:10 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:33:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:33:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:33:10 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:33:10 --> Helper loaded: form_helper
INFO - 2016-05-22 18:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:33:10 --> Form Validation Class Initialized
INFO - 2016-05-22 18:33:10 --> Controller Class Initialized
INFO - 2016-05-22 18:33:10 --> Model Class Initialized
INFO - 2016-05-22 18:33:10 --> Database Driver Class Initialized
INFO - 2016-05-22 18:33:10 --> Email Class Initialized
INFO - 2016-05-22 18:33:44 --> Config Class Initialized
INFO - 2016-05-22 18:33:44 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:33:44 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:33:44 --> Utf8 Class Initialized
INFO - 2016-05-22 18:33:44 --> URI Class Initialized
INFO - 2016-05-22 18:33:44 --> Router Class Initialized
INFO - 2016-05-22 18:33:45 --> Output Class Initialized
INFO - 2016-05-22 18:33:45 --> Security Class Initialized
DEBUG - 2016-05-22 18:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:33:45 --> Input Class Initialized
INFO - 2016-05-22 18:33:45 --> Language Class Initialized
INFO - 2016-05-22 18:33:45 --> Loader Class Initialized
INFO - 2016-05-22 18:33:45 --> Helper loaded: url_helper
INFO - 2016-05-22 18:33:45 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:33:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:33:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:33:45 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:33:45 --> Helper loaded: form_helper
INFO - 2016-05-22 18:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:33:45 --> Form Validation Class Initialized
INFO - 2016-05-22 18:33:45 --> Controller Class Initialized
INFO - 2016-05-22 18:33:45 --> Model Class Initialized
INFO - 2016-05-22 18:33:45 --> Database Driver Class Initialized
INFO - 2016-05-22 18:33:45 --> Email Class Initialized
INFO - 2016-05-22 18:34:39 --> Config Class Initialized
INFO - 2016-05-22 18:34:39 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:34:39 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:34:39 --> Utf8 Class Initialized
INFO - 2016-05-22 18:34:39 --> URI Class Initialized
INFO - 2016-05-22 18:34:39 --> Router Class Initialized
INFO - 2016-05-22 18:34:39 --> Output Class Initialized
INFO - 2016-05-22 18:34:39 --> Security Class Initialized
DEBUG - 2016-05-22 18:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:34:39 --> Input Class Initialized
INFO - 2016-05-22 18:34:39 --> Language Class Initialized
INFO - 2016-05-22 18:34:39 --> Loader Class Initialized
INFO - 2016-05-22 18:34:39 --> Helper loaded: url_helper
INFO - 2016-05-22 18:34:39 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:34:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:34:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:34:39 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:34:39 --> Helper loaded: form_helper
INFO - 2016-05-22 18:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:34:39 --> Form Validation Class Initialized
INFO - 2016-05-22 18:34:39 --> Controller Class Initialized
INFO - 2016-05-22 18:34:39 --> Model Class Initialized
INFO - 2016-05-22 18:34:39 --> Database Driver Class Initialized
INFO - 2016-05-22 18:34:39 --> Email Class Initialized
INFO - 2016-05-22 18:34:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\restablecerClave.php
INFO - 2016-05-22 18:34:39 --> Final output sent to browser
DEBUG - 2016-05-22 18:34:39 --> Total execution time: 0.0735
INFO - 2016-05-22 18:35:58 --> Config Class Initialized
INFO - 2016-05-22 18:35:58 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:35:58 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:35:58 --> Utf8 Class Initialized
INFO - 2016-05-22 18:35:58 --> URI Class Initialized
INFO - 2016-05-22 18:35:58 --> Router Class Initialized
INFO - 2016-05-22 18:35:58 --> Output Class Initialized
INFO - 2016-05-22 18:35:58 --> Security Class Initialized
DEBUG - 2016-05-22 18:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:35:58 --> Input Class Initialized
INFO - 2016-05-22 18:35:58 --> Language Class Initialized
INFO - 2016-05-22 18:35:58 --> Loader Class Initialized
INFO - 2016-05-22 18:35:58 --> Helper loaded: url_helper
INFO - 2016-05-22 18:35:58 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:35:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:35:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:35:58 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:35:58 --> Helper loaded: form_helper
INFO - 2016-05-22 18:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:35:58 --> Form Validation Class Initialized
INFO - 2016-05-22 18:35:58 --> Controller Class Initialized
INFO - 2016-05-22 18:35:58 --> Model Class Initialized
INFO - 2016-05-22 18:35:58 --> Database Driver Class Initialized
INFO - 2016-05-22 18:35:58 --> Email Class Initialized
INFO - 2016-05-22 18:35:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\restablecerClave.php
INFO - 2016-05-22 18:35:58 --> Final output sent to browser
DEBUG - 2016-05-22 18:35:58 --> Total execution time: 0.0796
INFO - 2016-05-22 18:36:36 --> Config Class Initialized
INFO - 2016-05-22 18:36:36 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:36:36 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:36:36 --> Utf8 Class Initialized
INFO - 2016-05-22 18:36:36 --> URI Class Initialized
INFO - 2016-05-22 18:36:36 --> Router Class Initialized
INFO - 2016-05-22 18:36:36 --> Output Class Initialized
INFO - 2016-05-22 18:36:36 --> Security Class Initialized
DEBUG - 2016-05-22 18:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:36:36 --> Input Class Initialized
INFO - 2016-05-22 18:36:36 --> Language Class Initialized
INFO - 2016-05-22 18:36:36 --> Loader Class Initialized
INFO - 2016-05-22 18:36:36 --> Helper loaded: url_helper
INFO - 2016-05-22 18:36:36 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:36:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:36:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:36:36 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:36:36 --> Helper loaded: form_helper
INFO - 2016-05-22 18:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:36:36 --> Form Validation Class Initialized
INFO - 2016-05-22 18:36:36 --> Controller Class Initialized
INFO - 2016-05-22 18:36:36 --> Model Class Initialized
INFO - 2016-05-22 18:36:36 --> Database Driver Class Initialized
INFO - 2016-05-22 18:36:36 --> Email Class Initialized
INFO - 2016-05-22 18:36:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_restablecerClave.php
INFO - 2016-05-22 18:36:36 --> Final output sent to browser
DEBUG - 2016-05-22 18:36:36 --> Total execution time: 0.0753
INFO - 2016-05-22 18:36:40 --> Config Class Initialized
INFO - 2016-05-22 18:36:40 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:36:40 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:36:40 --> Utf8 Class Initialized
INFO - 2016-05-22 18:36:40 --> URI Class Initialized
INFO - 2016-05-22 18:36:40 --> Router Class Initialized
INFO - 2016-05-22 18:36:40 --> Output Class Initialized
INFO - 2016-05-22 18:36:40 --> Security Class Initialized
DEBUG - 2016-05-22 18:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:36:40 --> Input Class Initialized
INFO - 2016-05-22 18:36:40 --> Language Class Initialized
INFO - 2016-05-22 18:36:40 --> Loader Class Initialized
INFO - 2016-05-22 18:36:40 --> Helper loaded: url_helper
INFO - 2016-05-22 18:36:40 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:36:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:36:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:36:40 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:36:40 --> Helper loaded: form_helper
INFO - 2016-05-22 18:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:36:40 --> Form Validation Class Initialized
INFO - 2016-05-22 18:36:40 --> Controller Class Initialized
INFO - 2016-05-22 18:36:40 --> Model Class Initialized
INFO - 2016-05-22 18:36:40 --> Database Driver Class Initialized
INFO - 2016-05-22 18:36:40 --> Email Class Initialized
INFO - 2016-05-22 18:36:40 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 18:36:40 --> Language file loaded: language/spanish/email_lang.php
INFO - 2016-05-22 18:36:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_mailIncorrecto.php
INFO - 2016-05-22 18:36:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 18:36:40 --> Final output sent to browser
DEBUG - 2016-05-22 18:36:40 --> Total execution time: 0.5835
INFO - 2016-05-22 18:36:41 --> Config Class Initialized
INFO - 2016-05-22 18:36:41 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:36:41 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:36:41 --> Utf8 Class Initialized
INFO - 2016-05-22 18:36:41 --> URI Class Initialized
INFO - 2016-05-22 18:36:41 --> Router Class Initialized
INFO - 2016-05-22 18:36:41 --> Output Class Initialized
INFO - 2016-05-22 18:36:41 --> Security Class Initialized
DEBUG - 2016-05-22 18:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:36:41 --> Input Class Initialized
INFO - 2016-05-22 18:36:41 --> Language Class Initialized
INFO - 2016-05-22 18:36:41 --> Loader Class Initialized
INFO - 2016-05-22 18:36:41 --> Helper loaded: url_helper
INFO - 2016-05-22 18:36:41 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:36:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:36:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:36:41 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:36:41 --> Helper loaded: form_helper
INFO - 2016-05-22 18:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:36:41 --> Form Validation Class Initialized
INFO - 2016-05-22 18:36:41 --> Controller Class Initialized
INFO - 2016-05-22 18:36:41 --> Model Class Initialized
INFO - 2016-05-22 18:36:41 --> Database Driver Class Initialized
INFO - 2016-05-22 18:36:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 18:36:41 --> Pagination Class Initialized
DEBUG - 2016-05-22 18:36:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 18:36:42 --> Config Class Initialized
INFO - 2016-05-22 18:36:42 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:36:42 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:36:42 --> Utf8 Class Initialized
INFO - 2016-05-22 18:36:42 --> URI Class Initialized
INFO - 2016-05-22 18:36:42 --> Router Class Initialized
INFO - 2016-05-22 18:36:42 --> Output Class Initialized
INFO - 2016-05-22 18:36:42 --> Security Class Initialized
DEBUG - 2016-05-22 18:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:36:42 --> Input Class Initialized
INFO - 2016-05-22 18:36:42 --> Language Class Initialized
INFO - 2016-05-22 18:36:42 --> Loader Class Initialized
INFO - 2016-05-22 18:36:42 --> Helper loaded: url_helper
INFO - 2016-05-22 18:36:42 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:36:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:36:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:36:42 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:36:42 --> Helper loaded: form_helper
INFO - 2016-05-22 18:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:36:42 --> Form Validation Class Initialized
INFO - 2016-05-22 18:36:42 --> Controller Class Initialized
INFO - 2016-05-22 18:36:42 --> Model Class Initialized
INFO - 2016-05-22 18:36:42 --> Database Driver Class Initialized
INFO - 2016-05-22 18:36:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-22 18:36:42 --> Final output sent to browser
DEBUG - 2016-05-22 18:36:42 --> Total execution time: 0.1041
INFO - 2016-05-22 18:36:55 --> Config Class Initialized
INFO - 2016-05-22 18:36:55 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:36:55 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:36:55 --> Utf8 Class Initialized
INFO - 2016-05-22 18:36:55 --> URI Class Initialized
INFO - 2016-05-22 18:36:55 --> Router Class Initialized
INFO - 2016-05-22 18:36:55 --> Output Class Initialized
INFO - 2016-05-22 18:36:55 --> Security Class Initialized
DEBUG - 2016-05-22 18:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:36:55 --> Input Class Initialized
INFO - 2016-05-22 18:36:55 --> Language Class Initialized
INFO - 2016-05-22 18:36:55 --> Loader Class Initialized
INFO - 2016-05-22 18:36:55 --> Helper loaded: url_helper
INFO - 2016-05-22 18:36:55 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:36:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:36:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:36:55 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:36:55 --> Helper loaded: form_helper
INFO - 2016-05-22 18:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:36:55 --> Form Validation Class Initialized
INFO - 2016-05-22 18:36:55 --> Controller Class Initialized
INFO - 2016-05-22 18:36:55 --> Model Class Initialized
INFO - 2016-05-22 18:36:55 --> Database Driver Class Initialized
INFO - 2016-05-22 18:36:55 --> Email Class Initialized
INFO - 2016-05-22 18:36:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_restablecerClave.php
INFO - 2016-05-22 18:36:55 --> Final output sent to browser
DEBUG - 2016-05-22 18:36:55 --> Total execution time: 0.0691
INFO - 2016-05-22 18:36:56 --> Config Class Initialized
INFO - 2016-05-22 18:36:56 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:36:56 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:36:56 --> Utf8 Class Initialized
INFO - 2016-05-22 18:36:56 --> URI Class Initialized
INFO - 2016-05-22 18:36:56 --> Router Class Initialized
INFO - 2016-05-22 18:36:56 --> Output Class Initialized
INFO - 2016-05-22 18:36:56 --> Security Class Initialized
DEBUG - 2016-05-22 18:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:36:56 --> Input Class Initialized
INFO - 2016-05-22 18:36:56 --> Language Class Initialized
INFO - 2016-05-22 18:36:56 --> Loader Class Initialized
INFO - 2016-05-22 18:36:56 --> Helper loaded: url_helper
INFO - 2016-05-22 18:36:56 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:36:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:36:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:36:56 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:36:56 --> Helper loaded: form_helper
INFO - 2016-05-22 18:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:36:56 --> Form Validation Class Initialized
INFO - 2016-05-22 18:36:56 --> Controller Class Initialized
INFO - 2016-05-22 18:36:56 --> Model Class Initialized
INFO - 2016-05-22 18:36:56 --> Database Driver Class Initialized
INFO - 2016-05-22 18:36:56 --> Email Class Initialized
INFO - 2016-05-22 18:36:56 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 18:36:56 --> Language file loaded: language/spanish/email_lang.php
INFO - 2016-05-22 18:36:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_mailIncorrecto.php
INFO - 2016-05-22 18:36:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 18:36:56 --> Final output sent to browser
DEBUG - 2016-05-22 18:36:56 --> Total execution time: 0.1725
INFO - 2016-05-22 18:36:57 --> Config Class Initialized
INFO - 2016-05-22 18:36:57 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:36:57 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:36:57 --> Utf8 Class Initialized
INFO - 2016-05-22 18:36:57 --> URI Class Initialized
INFO - 2016-05-22 18:36:57 --> Router Class Initialized
INFO - 2016-05-22 18:36:57 --> Output Class Initialized
INFO - 2016-05-22 18:36:57 --> Security Class Initialized
DEBUG - 2016-05-22 18:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:36:57 --> Input Class Initialized
INFO - 2016-05-22 18:36:57 --> Language Class Initialized
INFO - 2016-05-22 18:36:57 --> Loader Class Initialized
INFO - 2016-05-22 18:36:57 --> Helper loaded: url_helper
INFO - 2016-05-22 18:36:57 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:36:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:36:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:36:57 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:36:57 --> Helper loaded: form_helper
INFO - 2016-05-22 18:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:36:57 --> Form Validation Class Initialized
INFO - 2016-05-22 18:36:57 --> Controller Class Initialized
INFO - 2016-05-22 18:36:57 --> Model Class Initialized
INFO - 2016-05-22 18:36:57 --> Database Driver Class Initialized
INFO - 2016-05-22 18:36:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 18:36:57 --> Pagination Class Initialized
DEBUG - 2016-05-22 18:36:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 18:36:57 --> Config Class Initialized
INFO - 2016-05-22 18:36:57 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:36:57 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:36:57 --> Utf8 Class Initialized
INFO - 2016-05-22 18:36:57 --> URI Class Initialized
INFO - 2016-05-22 18:36:57 --> Router Class Initialized
INFO - 2016-05-22 18:36:57 --> Output Class Initialized
INFO - 2016-05-22 18:36:57 --> Security Class Initialized
DEBUG - 2016-05-22 18:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:36:57 --> Input Class Initialized
INFO - 2016-05-22 18:36:57 --> Language Class Initialized
INFO - 2016-05-22 18:36:57 --> Loader Class Initialized
INFO - 2016-05-22 18:36:57 --> Helper loaded: url_helper
INFO - 2016-05-22 18:36:57 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:36:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:36:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:36:57 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:36:57 --> Helper loaded: form_helper
INFO - 2016-05-22 18:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:36:57 --> Form Validation Class Initialized
INFO - 2016-05-22 18:36:57 --> Controller Class Initialized
INFO - 2016-05-22 18:36:57 --> Model Class Initialized
INFO - 2016-05-22 18:36:57 --> Database Driver Class Initialized
INFO - 2016-05-22 18:36:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-22 18:36:57 --> Final output sent to browser
DEBUG - 2016-05-22 18:36:57 --> Total execution time: 0.1062
INFO - 2016-05-22 18:37:57 --> Config Class Initialized
INFO - 2016-05-22 18:37:57 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:37:57 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:37:57 --> Utf8 Class Initialized
INFO - 2016-05-22 18:37:57 --> URI Class Initialized
INFO - 2016-05-22 18:37:57 --> Router Class Initialized
INFO - 2016-05-22 18:37:57 --> Output Class Initialized
INFO - 2016-05-22 18:37:57 --> Security Class Initialized
DEBUG - 2016-05-22 18:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:37:57 --> Input Class Initialized
INFO - 2016-05-22 18:37:57 --> Language Class Initialized
INFO - 2016-05-22 18:37:57 --> Loader Class Initialized
INFO - 2016-05-22 18:37:57 --> Helper loaded: url_helper
INFO - 2016-05-22 18:37:57 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:37:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:37:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:37:57 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:37:57 --> Helper loaded: form_helper
INFO - 2016-05-22 18:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:37:57 --> Form Validation Class Initialized
INFO - 2016-05-22 18:37:57 --> Controller Class Initialized
INFO - 2016-05-22 18:37:57 --> Model Class Initialized
INFO - 2016-05-22 18:37:57 --> Database Driver Class Initialized
INFO - 2016-05-22 18:37:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 18:37:57 --> Pagination Class Initialized
DEBUG - 2016-05-22 18:37:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 18:37:57 --> Config Class Initialized
INFO - 2016-05-22 18:37:57 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:37:57 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:37:57 --> Utf8 Class Initialized
INFO - 2016-05-22 18:37:57 --> URI Class Initialized
INFO - 2016-05-22 18:37:57 --> Router Class Initialized
INFO - 2016-05-22 18:37:57 --> Output Class Initialized
INFO - 2016-05-22 18:37:57 --> Security Class Initialized
DEBUG - 2016-05-22 18:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:37:57 --> Input Class Initialized
INFO - 2016-05-22 18:37:57 --> Language Class Initialized
INFO - 2016-05-22 18:37:57 --> Loader Class Initialized
INFO - 2016-05-22 18:37:57 --> Helper loaded: url_helper
INFO - 2016-05-22 18:37:57 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:37:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:37:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:37:57 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:37:57 --> Helper loaded: form_helper
INFO - 2016-05-22 18:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:37:57 --> Form Validation Class Initialized
INFO - 2016-05-22 18:37:57 --> Controller Class Initialized
INFO - 2016-05-22 18:37:57 --> Model Class Initialized
INFO - 2016-05-22 18:37:57 --> Database Driver Class Initialized
INFO - 2016-05-22 18:37:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-22 18:37:57 --> Final output sent to browser
DEBUG - 2016-05-22 18:37:57 --> Total execution time: 0.0619
INFO - 2016-05-22 18:38:57 --> Config Class Initialized
INFO - 2016-05-22 18:38:57 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:38:57 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:38:57 --> Utf8 Class Initialized
INFO - 2016-05-22 18:38:57 --> URI Class Initialized
INFO - 2016-05-22 18:38:57 --> Router Class Initialized
INFO - 2016-05-22 18:38:57 --> Output Class Initialized
INFO - 2016-05-22 18:38:57 --> Security Class Initialized
DEBUG - 2016-05-22 18:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:38:57 --> Input Class Initialized
INFO - 2016-05-22 18:38:57 --> Language Class Initialized
INFO - 2016-05-22 18:38:57 --> Loader Class Initialized
INFO - 2016-05-22 18:38:57 --> Helper loaded: url_helper
INFO - 2016-05-22 18:38:57 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:38:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:38:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:38:57 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:38:57 --> Helper loaded: form_helper
INFO - 2016-05-22 18:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:38:57 --> Form Validation Class Initialized
INFO - 2016-05-22 18:38:57 --> Controller Class Initialized
INFO - 2016-05-22 18:38:57 --> Model Class Initialized
INFO - 2016-05-22 18:38:57 --> Database Driver Class Initialized
INFO - 2016-05-22 18:38:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 18:38:57 --> Pagination Class Initialized
DEBUG - 2016-05-22 18:38:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 18:38:57 --> Config Class Initialized
INFO - 2016-05-22 18:38:57 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:38:57 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:38:57 --> Utf8 Class Initialized
INFO - 2016-05-22 18:38:57 --> URI Class Initialized
INFO - 2016-05-22 18:38:57 --> Router Class Initialized
INFO - 2016-05-22 18:38:57 --> Output Class Initialized
INFO - 2016-05-22 18:38:57 --> Security Class Initialized
DEBUG - 2016-05-22 18:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:38:57 --> Input Class Initialized
INFO - 2016-05-22 18:38:57 --> Language Class Initialized
INFO - 2016-05-22 18:38:57 --> Loader Class Initialized
INFO - 2016-05-22 18:38:58 --> Helper loaded: url_helper
INFO - 2016-05-22 18:38:58 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:38:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:38:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:38:58 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:38:58 --> Helper loaded: form_helper
INFO - 2016-05-22 18:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:38:58 --> Form Validation Class Initialized
INFO - 2016-05-22 18:38:58 --> Controller Class Initialized
INFO - 2016-05-22 18:38:58 --> Model Class Initialized
INFO - 2016-05-22 18:38:58 --> Database Driver Class Initialized
INFO - 2016-05-22 18:38:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-22 18:38:58 --> Final output sent to browser
DEBUG - 2016-05-22 18:38:58 --> Total execution time: 1.3000
INFO - 2016-05-22 18:39:57 --> Config Class Initialized
INFO - 2016-05-22 18:39:57 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:39:57 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:39:57 --> Utf8 Class Initialized
INFO - 2016-05-22 18:39:57 --> URI Class Initialized
INFO - 2016-05-22 18:39:57 --> Router Class Initialized
INFO - 2016-05-22 18:39:57 --> Output Class Initialized
INFO - 2016-05-22 18:39:57 --> Security Class Initialized
DEBUG - 2016-05-22 18:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:39:57 --> Input Class Initialized
INFO - 2016-05-22 18:39:57 --> Language Class Initialized
INFO - 2016-05-22 18:39:57 --> Loader Class Initialized
INFO - 2016-05-22 18:39:57 --> Helper loaded: url_helper
INFO - 2016-05-22 18:39:57 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:39:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:39:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:39:57 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:39:57 --> Helper loaded: form_helper
INFO - 2016-05-22 18:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:39:57 --> Form Validation Class Initialized
INFO - 2016-05-22 18:39:57 --> Controller Class Initialized
INFO - 2016-05-22 18:39:57 --> Model Class Initialized
INFO - 2016-05-22 18:39:57 --> Database Driver Class Initialized
INFO - 2016-05-22 18:39:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 18:39:57 --> Pagination Class Initialized
DEBUG - 2016-05-22 18:39:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 18:39:57 --> Config Class Initialized
INFO - 2016-05-22 18:39:57 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:39:57 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:39:57 --> Utf8 Class Initialized
INFO - 2016-05-22 18:39:57 --> URI Class Initialized
INFO - 2016-05-22 18:39:57 --> Router Class Initialized
INFO - 2016-05-22 18:39:57 --> Output Class Initialized
INFO - 2016-05-22 18:39:57 --> Security Class Initialized
DEBUG - 2016-05-22 18:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:39:57 --> Input Class Initialized
INFO - 2016-05-22 18:39:57 --> Language Class Initialized
INFO - 2016-05-22 18:39:57 --> Loader Class Initialized
INFO - 2016-05-22 18:39:57 --> Helper loaded: url_helper
INFO - 2016-05-22 18:39:57 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:39:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:39:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:39:57 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:39:57 --> Helper loaded: form_helper
INFO - 2016-05-22 18:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:39:57 --> Form Validation Class Initialized
INFO - 2016-05-22 18:39:57 --> Controller Class Initialized
INFO - 2016-05-22 18:39:57 --> Model Class Initialized
INFO - 2016-05-22 18:39:57 --> Database Driver Class Initialized
INFO - 2016-05-22 18:39:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-22 18:39:57 --> Final output sent to browser
DEBUG - 2016-05-22 18:39:57 --> Total execution time: 0.0633
INFO - 2016-05-22 18:40:31 --> Config Class Initialized
INFO - 2016-05-22 18:40:31 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:40:31 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:40:31 --> Utf8 Class Initialized
INFO - 2016-05-22 18:40:31 --> URI Class Initialized
INFO - 2016-05-22 18:40:31 --> Router Class Initialized
INFO - 2016-05-22 18:40:31 --> Output Class Initialized
INFO - 2016-05-22 18:40:31 --> Security Class Initialized
DEBUG - 2016-05-22 18:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:40:31 --> Input Class Initialized
INFO - 2016-05-22 18:40:31 --> Language Class Initialized
INFO - 2016-05-22 18:40:31 --> Loader Class Initialized
INFO - 2016-05-22 18:40:31 --> Helper loaded: url_helper
INFO - 2016-05-22 18:40:31 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:40:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:40:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:40:31 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:40:31 --> Helper loaded: form_helper
INFO - 2016-05-22 18:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:40:31 --> Form Validation Class Initialized
INFO - 2016-05-22 18:40:31 --> Controller Class Initialized
INFO - 2016-05-22 18:40:31 --> Model Class Initialized
INFO - 2016-05-22 18:40:31 --> Database Driver Class Initialized
INFO - 2016-05-22 18:40:31 --> Email Class Initialized
INFO - 2016-05-22 18:40:31 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 18:40:31 --> Language file loaded: language/spanish/email_lang.php
INFO - 2016-05-22 18:40:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_mailIncorrecto.php
INFO - 2016-05-22 18:40:31 --> Final output sent to browser
DEBUG - 2016-05-22 18:40:31 --> Total execution time: 0.1276
INFO - 2016-05-22 18:44:57 --> Config Class Initialized
INFO - 2016-05-22 18:44:57 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:44:57 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:44:57 --> Utf8 Class Initialized
INFO - 2016-05-22 18:44:57 --> URI Class Initialized
INFO - 2016-05-22 18:44:57 --> Router Class Initialized
INFO - 2016-05-22 18:44:57 --> Output Class Initialized
INFO - 2016-05-22 18:44:57 --> Security Class Initialized
DEBUG - 2016-05-22 18:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:44:57 --> Input Class Initialized
INFO - 2016-05-22 18:44:57 --> Language Class Initialized
INFO - 2016-05-22 18:44:57 --> Loader Class Initialized
INFO - 2016-05-22 18:44:57 --> Helper loaded: url_helper
INFO - 2016-05-22 18:44:57 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:44:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:44:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:44:57 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:44:57 --> Helper loaded: form_helper
INFO - 2016-05-22 18:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:44:57 --> Form Validation Class Initialized
INFO - 2016-05-22 18:44:57 --> Controller Class Initialized
INFO - 2016-05-22 18:44:57 --> Model Class Initialized
INFO - 2016-05-22 18:44:57 --> Database Driver Class Initialized
INFO - 2016-05-22 18:44:57 --> Email Class Initialized
INFO - 2016-05-22 18:44:57 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 18:44:57 --> Language file loaded: language/spanish/email_lang.php
INFO - 2016-05-22 18:44:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_mailIncorrecto.php
INFO - 2016-05-22 18:44:57 --> Final output sent to browser
DEBUG - 2016-05-22 18:44:57 --> Total execution time: 0.1189
INFO - 2016-05-22 18:45:50 --> Config Class Initialized
INFO - 2016-05-22 18:45:50 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:45:50 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:45:50 --> Utf8 Class Initialized
INFO - 2016-05-22 18:45:50 --> URI Class Initialized
INFO - 2016-05-22 18:45:50 --> Router Class Initialized
INFO - 2016-05-22 18:45:50 --> Output Class Initialized
INFO - 2016-05-22 18:45:50 --> Security Class Initialized
DEBUG - 2016-05-22 18:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:45:50 --> Input Class Initialized
INFO - 2016-05-22 18:45:50 --> Language Class Initialized
INFO - 2016-05-22 18:45:50 --> Loader Class Initialized
INFO - 2016-05-22 18:45:50 --> Helper loaded: url_helper
INFO - 2016-05-22 18:45:50 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:45:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:45:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:45:50 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:45:50 --> Helper loaded: form_helper
INFO - 2016-05-22 18:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:45:50 --> Form Validation Class Initialized
INFO - 2016-05-22 18:45:50 --> Controller Class Initialized
INFO - 2016-05-22 18:45:50 --> Model Class Initialized
INFO - 2016-05-22 18:45:50 --> Database Driver Class Initialized
INFO - 2016-05-22 18:45:50 --> Email Class Initialized
INFO - 2016-05-22 18:45:50 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 18:45:50 --> Language file loaded: language/spanish/email_lang.php
INFO - 2016-05-22 18:45:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_mailIncorrecto.php
INFO - 2016-05-22 18:45:50 --> Final output sent to browser
DEBUG - 2016-05-22 18:45:50 --> Total execution time: 0.1266
INFO - 2016-05-22 18:46:28 --> Config Class Initialized
INFO - 2016-05-22 18:46:28 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:46:28 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:46:28 --> Utf8 Class Initialized
INFO - 2016-05-22 18:46:28 --> URI Class Initialized
INFO - 2016-05-22 18:46:28 --> Router Class Initialized
INFO - 2016-05-22 18:46:28 --> Output Class Initialized
INFO - 2016-05-22 18:46:28 --> Security Class Initialized
DEBUG - 2016-05-22 18:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:46:28 --> Input Class Initialized
INFO - 2016-05-22 18:46:28 --> Language Class Initialized
INFO - 2016-05-22 18:46:28 --> Loader Class Initialized
INFO - 2016-05-22 18:46:28 --> Helper loaded: url_helper
INFO - 2016-05-22 18:46:28 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:46:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:46:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:46:28 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:46:28 --> Helper loaded: form_helper
INFO - 2016-05-22 18:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:46:28 --> Form Validation Class Initialized
INFO - 2016-05-22 18:46:28 --> Controller Class Initialized
INFO - 2016-05-22 18:46:28 --> Model Class Initialized
INFO - 2016-05-22 18:46:28 --> Database Driver Class Initialized
INFO - 2016-05-22 18:46:28 --> Email Class Initialized
INFO - 2016-05-22 18:46:28 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 18:46:28 --> Language file loaded: language/spanish/email_lang.php
INFO - 2016-05-22 18:46:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_mailIncorrecto.php
INFO - 2016-05-22 18:46:28 --> Final output sent to browser
DEBUG - 2016-05-22 18:46:28 --> Total execution time: 0.1107
INFO - 2016-05-22 18:46:36 --> Config Class Initialized
INFO - 2016-05-22 18:46:36 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:46:36 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:46:36 --> Utf8 Class Initialized
INFO - 2016-05-22 18:46:36 --> URI Class Initialized
INFO - 2016-05-22 18:46:36 --> Router Class Initialized
INFO - 2016-05-22 18:46:36 --> Output Class Initialized
INFO - 2016-05-22 18:46:36 --> Security Class Initialized
DEBUG - 2016-05-22 18:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:46:36 --> Input Class Initialized
INFO - 2016-05-22 18:46:36 --> Language Class Initialized
INFO - 2016-05-22 18:46:36 --> Loader Class Initialized
INFO - 2016-05-22 18:46:36 --> Helper loaded: url_helper
INFO - 2016-05-22 18:46:36 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:46:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:46:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:46:36 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:46:36 --> Helper loaded: form_helper
INFO - 2016-05-22 18:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:46:36 --> Form Validation Class Initialized
INFO - 2016-05-22 18:46:36 --> Controller Class Initialized
INFO - 2016-05-22 18:46:36 --> Model Class Initialized
INFO - 2016-05-22 18:46:36 --> Database Driver Class Initialized
INFO - 2016-05-22 18:46:36 --> Email Class Initialized
INFO - 2016-05-22 18:46:36 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 18:46:36 --> Language file loaded: language/spanish/email_lang.php
INFO - 2016-05-22 18:46:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_mailIncorrecto.php
INFO - 2016-05-22 18:46:36 --> Final output sent to browser
DEBUG - 2016-05-22 18:46:36 --> Total execution time: 0.1264
INFO - 2016-05-22 18:46:46 --> Config Class Initialized
INFO - 2016-05-22 18:46:46 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:46:46 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:46:46 --> Utf8 Class Initialized
INFO - 2016-05-22 18:46:46 --> URI Class Initialized
INFO - 2016-05-22 18:46:46 --> Router Class Initialized
INFO - 2016-05-22 18:46:46 --> Output Class Initialized
INFO - 2016-05-22 18:46:46 --> Security Class Initialized
DEBUG - 2016-05-22 18:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:46:46 --> Input Class Initialized
INFO - 2016-05-22 18:46:46 --> Language Class Initialized
INFO - 2016-05-22 18:46:46 --> Loader Class Initialized
INFO - 2016-05-22 18:46:46 --> Helper loaded: url_helper
INFO - 2016-05-22 18:46:46 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:46:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:46:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:46:46 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:46:46 --> Helper loaded: form_helper
INFO - 2016-05-22 18:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:46:46 --> Form Validation Class Initialized
INFO - 2016-05-22 18:46:46 --> Controller Class Initialized
INFO - 2016-05-22 18:46:46 --> Model Class Initialized
INFO - 2016-05-22 18:46:46 --> Database Driver Class Initialized
INFO - 2016-05-22 18:46:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-22 18:46:46 --> Final output sent to browser
DEBUG - 2016-05-22 18:46:46 --> Total execution time: 0.0798
INFO - 2016-05-22 18:47:34 --> Config Class Initialized
INFO - 2016-05-22 18:47:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:47:34 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:47:34 --> Utf8 Class Initialized
INFO - 2016-05-22 18:47:34 --> URI Class Initialized
INFO - 2016-05-22 18:47:34 --> Router Class Initialized
INFO - 2016-05-22 18:47:34 --> Output Class Initialized
INFO - 2016-05-22 18:47:34 --> Security Class Initialized
DEBUG - 2016-05-22 18:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:47:34 --> Input Class Initialized
INFO - 2016-05-22 18:47:34 --> Language Class Initialized
INFO - 2016-05-22 18:47:34 --> Loader Class Initialized
INFO - 2016-05-22 18:47:34 --> Helper loaded: url_helper
INFO - 2016-05-22 18:47:34 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:47:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:47:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:47:34 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:47:34 --> Helper loaded: form_helper
INFO - 2016-05-22 18:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:47:34 --> Form Validation Class Initialized
INFO - 2016-05-22 18:47:34 --> Controller Class Initialized
INFO - 2016-05-22 18:47:34 --> Model Class Initialized
INFO - 2016-05-22 18:47:34 --> Database Driver Class Initialized
INFO - 2016-05-22 18:47:34 --> Email Class Initialized
INFO - 2016-05-22 18:47:34 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 18:47:34 --> Language file loaded: language/spanish/email_lang.php
INFO - 2016-05-22 18:47:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_mailIncorrecto.php
INFO - 2016-05-22 18:47:34 --> Final output sent to browser
DEBUG - 2016-05-22 18:47:34 --> Total execution time: 0.1096
INFO - 2016-05-22 18:50:53 --> Config Class Initialized
INFO - 2016-05-22 18:50:53 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:50:53 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:50:53 --> Utf8 Class Initialized
INFO - 2016-05-22 18:50:53 --> URI Class Initialized
INFO - 2016-05-22 18:50:53 --> Router Class Initialized
INFO - 2016-05-22 18:50:53 --> Output Class Initialized
INFO - 2016-05-22 18:50:53 --> Security Class Initialized
DEBUG - 2016-05-22 18:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:50:53 --> Input Class Initialized
INFO - 2016-05-22 18:50:53 --> Language Class Initialized
INFO - 2016-05-22 18:50:53 --> Loader Class Initialized
INFO - 2016-05-22 18:50:53 --> Helper loaded: url_helper
INFO - 2016-05-22 18:50:53 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:50:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:50:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:50:53 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:50:53 --> Helper loaded: form_helper
INFO - 2016-05-22 18:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:50:53 --> Form Validation Class Initialized
INFO - 2016-05-22 18:50:53 --> Controller Class Initialized
INFO - 2016-05-22 18:50:53 --> Model Class Initialized
INFO - 2016-05-22 18:50:53 --> Database Driver Class Initialized
INFO - 2016-05-22 18:50:53 --> Email Class Initialized
INFO - 2016-05-22 18:50:53 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 18:50:53 --> Language file loaded: language/spanish/email_lang.php
INFO - 2016-05-22 18:50:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_mailIncorrecto.php
INFO - 2016-05-22 18:50:53 --> Final output sent to browser
DEBUG - 2016-05-22 18:50:53 --> Total execution time: 0.2748
INFO - 2016-05-22 18:54:53 --> Config Class Initialized
INFO - 2016-05-22 18:54:53 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:54:53 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:54:53 --> Utf8 Class Initialized
INFO - 2016-05-22 18:54:53 --> URI Class Initialized
INFO - 2016-05-22 18:54:53 --> Router Class Initialized
INFO - 2016-05-22 18:54:53 --> Output Class Initialized
INFO - 2016-05-22 18:54:53 --> Security Class Initialized
DEBUG - 2016-05-22 18:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:54:53 --> Input Class Initialized
INFO - 2016-05-22 18:54:53 --> Language Class Initialized
INFO - 2016-05-22 18:54:53 --> Loader Class Initialized
INFO - 2016-05-22 18:54:53 --> Helper loaded: url_helper
INFO - 2016-05-22 18:54:53 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:54:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:54:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:54:53 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:54:53 --> Helper loaded: form_helper
INFO - 2016-05-22 18:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:54:53 --> Form Validation Class Initialized
INFO - 2016-05-22 18:54:53 --> Controller Class Initialized
INFO - 2016-05-22 18:54:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-22 18:54:53 --> Final output sent to browser
DEBUG - 2016-05-22 18:54:53 --> Total execution time: 0.0876
INFO - 2016-05-22 18:55:42 --> Config Class Initialized
INFO - 2016-05-22 18:55:42 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:55:42 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:55:42 --> Utf8 Class Initialized
INFO - 2016-05-22 18:55:42 --> URI Class Initialized
INFO - 2016-05-22 18:55:42 --> Router Class Initialized
INFO - 2016-05-22 18:55:42 --> Output Class Initialized
INFO - 2016-05-22 18:55:42 --> Security Class Initialized
DEBUG - 2016-05-22 18:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:55:42 --> Input Class Initialized
INFO - 2016-05-22 18:55:42 --> Language Class Initialized
INFO - 2016-05-22 18:55:42 --> Loader Class Initialized
INFO - 2016-05-22 18:55:42 --> Helper loaded: url_helper
INFO - 2016-05-22 18:55:42 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:55:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:55:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:55:42 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:55:42 --> Helper loaded: form_helper
INFO - 2016-05-22 18:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:55:42 --> Form Validation Class Initialized
INFO - 2016-05-22 18:55:42 --> Controller Class Initialized
INFO - 2016-05-22 18:55:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-22 18:55:42 --> Final output sent to browser
DEBUG - 2016-05-22 18:55:42 --> Total execution time: 0.0611
INFO - 2016-05-22 18:56:06 --> Config Class Initialized
INFO - 2016-05-22 18:56:06 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:56:06 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:56:06 --> Utf8 Class Initialized
INFO - 2016-05-22 18:56:06 --> URI Class Initialized
INFO - 2016-05-22 18:56:06 --> Router Class Initialized
INFO - 2016-05-22 18:56:06 --> Output Class Initialized
INFO - 2016-05-22 18:56:06 --> Security Class Initialized
DEBUG - 2016-05-22 18:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:56:06 --> Input Class Initialized
INFO - 2016-05-22 18:56:06 --> Language Class Initialized
INFO - 2016-05-22 18:56:06 --> Loader Class Initialized
INFO - 2016-05-22 18:56:06 --> Helper loaded: url_helper
INFO - 2016-05-22 18:56:06 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:56:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:56:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:56:06 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:56:06 --> Helper loaded: form_helper
INFO - 2016-05-22 18:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:56:06 --> Form Validation Class Initialized
INFO - 2016-05-22 18:56:06 --> Controller Class Initialized
INFO - 2016-05-22 18:56:06 --> Model Class Initialized
INFO - 2016-05-22 18:56:06 --> Database Driver Class Initialized
INFO - 2016-05-22 18:56:06 --> Email Class Initialized
INFO - 2016-05-22 18:56:06 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 18:56:06 --> Language file loaded: language/spanish/email_lang.php
INFO - 2016-05-22 18:56:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_mailIncorrecto.php
INFO - 2016-05-22 18:56:06 --> Final output sent to browser
DEBUG - 2016-05-22 18:56:06 --> Total execution time: 0.1161
INFO - 2016-05-22 18:56:19 --> Config Class Initialized
INFO - 2016-05-22 18:56:19 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:56:19 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:56:19 --> Utf8 Class Initialized
INFO - 2016-05-22 18:56:19 --> URI Class Initialized
INFO - 2016-05-22 18:56:19 --> Router Class Initialized
INFO - 2016-05-22 18:56:19 --> Output Class Initialized
INFO - 2016-05-22 18:56:19 --> Security Class Initialized
DEBUG - 2016-05-22 18:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:56:19 --> Input Class Initialized
INFO - 2016-05-22 18:56:19 --> Language Class Initialized
INFO - 2016-05-22 18:56:19 --> Loader Class Initialized
INFO - 2016-05-22 18:56:19 --> Helper loaded: url_helper
INFO - 2016-05-22 18:56:19 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:56:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:56:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:56:19 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:56:19 --> Helper loaded: form_helper
INFO - 2016-05-22 18:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:56:19 --> Form Validation Class Initialized
INFO - 2016-05-22 18:56:19 --> Controller Class Initialized
INFO - 2016-05-22 18:56:19 --> Model Class Initialized
INFO - 2016-05-22 18:56:19 --> Database Driver Class Initialized
INFO - 2016-05-22 18:56:19 --> Email Class Initialized
INFO - 2016-05-22 18:56:19 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-22 18:56:19 --> Language file loaded: language/spanish/email_lang.php
INFO - 2016-05-22 18:56:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_mailIncorrecto.php
INFO - 2016-05-22 18:56:19 --> Final output sent to browser
DEBUG - 2016-05-22 18:56:19 --> Total execution time: 0.1158
INFO - 2016-05-22 18:56:32 --> Config Class Initialized
INFO - 2016-05-22 18:56:32 --> Hooks Class Initialized
DEBUG - 2016-05-22 18:56:32 --> UTF-8 Support Enabled
INFO - 2016-05-22 18:56:32 --> Utf8 Class Initialized
INFO - 2016-05-22 18:56:32 --> URI Class Initialized
INFO - 2016-05-22 18:56:32 --> Router Class Initialized
INFO - 2016-05-22 18:56:32 --> Output Class Initialized
INFO - 2016-05-22 18:56:32 --> Security Class Initialized
DEBUG - 2016-05-22 18:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 18:56:32 --> Input Class Initialized
INFO - 2016-05-22 18:56:32 --> Language Class Initialized
INFO - 2016-05-22 18:56:32 --> Loader Class Initialized
INFO - 2016-05-22 18:56:32 --> Helper loaded: url_helper
INFO - 2016-05-22 18:56:32 --> Helper loaded: sesion_helper
INFO - 2016-05-22 18:56:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 18:56:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 18:56:32 --> Helper loaded: redondear_helper
INFO - 2016-05-22 18:56:32 --> Helper loaded: form_helper
INFO - 2016-05-22 18:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 18:56:32 --> Form Validation Class Initialized
INFO - 2016-05-22 18:56:32 --> Controller Class Initialized
INFO - 2016-05-22 18:56:32 --> Model Class Initialized
INFO - 2016-05-22 18:56:32 --> Database Driver Class Initialized
INFO - 2016-05-22 18:56:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-22 18:56:32 --> Final output sent to browser
DEBUG - 2016-05-22 18:56:32 --> Total execution time: 0.0682
ERROR - 2016-05-22 19:01:55 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 27
ERROR - 2016-05-22 19:01:55 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 30
INFO - 2016-05-22 19:01:55 --> Config Class Initialized
INFO - 2016-05-22 19:01:55 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:01:55 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:01:55 --> Utf8 Class Initialized
INFO - 2016-05-22 19:01:55 --> URI Class Initialized
DEBUG - 2016-05-22 19:01:55 --> No URI present. Default controller set.
INFO - 2016-05-22 19:01:55 --> Router Class Initialized
INFO - 2016-05-22 19:01:55 --> Output Class Initialized
INFO - 2016-05-22 19:01:55 --> Security Class Initialized
DEBUG - 2016-05-22 19:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:01:55 --> Input Class Initialized
INFO - 2016-05-22 19:01:55 --> Language Class Initialized
INFO - 2016-05-22 19:01:55 --> Loader Class Initialized
INFO - 2016-05-22 19:01:55 --> Helper loaded: url_helper
INFO - 2016-05-22 19:01:55 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:01:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:01:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:01:55 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:01:55 --> Helper loaded: form_helper
INFO - 2016-05-22 19:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:01:55 --> Form Validation Class Initialized
INFO - 2016-05-22 19:01:55 --> Controller Class Initialized
INFO - 2016-05-22 19:01:55 --> Model Class Initialized
INFO - 2016-05-22 19:01:56 --> Database Driver Class Initialized
INFO - 2016-05-22 19:01:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:01:56 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:01:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-22 19:01:58 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 27
ERROR - 2016-05-22 19:01:58 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 30
INFO - 2016-05-22 19:01:58 --> Config Class Initialized
INFO - 2016-05-22 19:01:58 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:01:58 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:01:58 --> Utf8 Class Initialized
INFO - 2016-05-22 19:01:58 --> URI Class Initialized
DEBUG - 2016-05-22 19:01:58 --> No URI present. Default controller set.
INFO - 2016-05-22 19:01:58 --> Router Class Initialized
INFO - 2016-05-22 19:01:58 --> Output Class Initialized
INFO - 2016-05-22 19:01:58 --> Security Class Initialized
DEBUG - 2016-05-22 19:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:01:58 --> Input Class Initialized
INFO - 2016-05-22 19:01:58 --> Language Class Initialized
INFO - 2016-05-22 19:01:58 --> Loader Class Initialized
INFO - 2016-05-22 19:01:58 --> Helper loaded: url_helper
INFO - 2016-05-22 19:01:58 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:01:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:01:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:01:58 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:01:58 --> Helper loaded: form_helper
INFO - 2016-05-22 19:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:01:58 --> Form Validation Class Initialized
INFO - 2016-05-22 19:01:58 --> Controller Class Initialized
INFO - 2016-05-22 19:01:58 --> Model Class Initialized
INFO - 2016-05-22 19:01:58 --> Database Driver Class Initialized
INFO - 2016-05-22 19:01:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:01:58 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:01:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-22 19:01:59 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 27
ERROR - 2016-05-22 19:01:59 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 30
INFO - 2016-05-22 19:01:59 --> Config Class Initialized
INFO - 2016-05-22 19:01:59 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:01:59 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:01:59 --> Utf8 Class Initialized
INFO - 2016-05-22 19:01:59 --> URI Class Initialized
DEBUG - 2016-05-22 19:01:59 --> No URI present. Default controller set.
INFO - 2016-05-22 19:01:59 --> Router Class Initialized
INFO - 2016-05-22 19:01:59 --> Output Class Initialized
INFO - 2016-05-22 19:01:59 --> Security Class Initialized
DEBUG - 2016-05-22 19:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:01:59 --> Input Class Initialized
INFO - 2016-05-22 19:01:59 --> Language Class Initialized
INFO - 2016-05-22 19:01:59 --> Loader Class Initialized
INFO - 2016-05-22 19:01:59 --> Helper loaded: url_helper
INFO - 2016-05-22 19:01:59 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:01:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:01:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:01:59 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:01:59 --> Helper loaded: form_helper
INFO - 2016-05-22 19:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:01:59 --> Form Validation Class Initialized
INFO - 2016-05-22 19:01:59 --> Controller Class Initialized
INFO - 2016-05-22 19:01:59 --> Model Class Initialized
INFO - 2016-05-22 19:01:59 --> Database Driver Class Initialized
INFO - 2016-05-22 19:01:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:01:59 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:01:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-22 19:02:05 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 27
ERROR - 2016-05-22 19:02:05 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 30
INFO - 2016-05-22 19:02:05 --> Config Class Initialized
INFO - 2016-05-22 19:02:05 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:02:05 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:02:05 --> Utf8 Class Initialized
INFO - 2016-05-22 19:02:05 --> URI Class Initialized
DEBUG - 2016-05-22 19:02:05 --> No URI present. Default controller set.
INFO - 2016-05-22 19:02:05 --> Router Class Initialized
INFO - 2016-05-22 19:02:05 --> Output Class Initialized
INFO - 2016-05-22 19:02:05 --> Security Class Initialized
DEBUG - 2016-05-22 19:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:02:05 --> Input Class Initialized
INFO - 2016-05-22 19:02:05 --> Language Class Initialized
INFO - 2016-05-22 19:02:05 --> Loader Class Initialized
INFO - 2016-05-22 19:02:05 --> Helper loaded: url_helper
INFO - 2016-05-22 19:02:05 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:02:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:02:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:02:05 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:02:05 --> Helper loaded: form_helper
INFO - 2016-05-22 19:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:02:05 --> Form Validation Class Initialized
INFO - 2016-05-22 19:02:05 --> Controller Class Initialized
INFO - 2016-05-22 19:02:05 --> Model Class Initialized
INFO - 2016-05-22 19:02:05 --> Database Driver Class Initialized
INFO - 2016-05-22 19:02:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:02:05 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:02:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-22 19:02:05 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 27
ERROR - 2016-05-22 19:02:05 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 30
INFO - 2016-05-22 19:02:05 --> Config Class Initialized
INFO - 2016-05-22 19:02:05 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:02:06 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:02:06 --> Utf8 Class Initialized
INFO - 2016-05-22 19:02:06 --> URI Class Initialized
DEBUG - 2016-05-22 19:02:06 --> No URI present. Default controller set.
INFO - 2016-05-22 19:02:06 --> Router Class Initialized
INFO - 2016-05-22 19:02:06 --> Output Class Initialized
INFO - 2016-05-22 19:02:06 --> Security Class Initialized
DEBUG - 2016-05-22 19:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:02:06 --> Input Class Initialized
INFO - 2016-05-22 19:02:06 --> Language Class Initialized
INFO - 2016-05-22 19:02:06 --> Loader Class Initialized
INFO - 2016-05-22 19:02:06 --> Helper loaded: url_helper
INFO - 2016-05-22 19:02:06 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:02:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:02:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:02:06 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:02:06 --> Helper loaded: form_helper
INFO - 2016-05-22 19:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:02:06 --> Form Validation Class Initialized
INFO - 2016-05-22 19:02:06 --> Controller Class Initialized
INFO - 2016-05-22 19:02:06 --> Model Class Initialized
INFO - 2016-05-22 19:02:06 --> Database Driver Class Initialized
INFO - 2016-05-22 19:02:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:02:06 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:02:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-22 19:02:06 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 27
ERROR - 2016-05-22 19:02:06 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 30
INFO - 2016-05-22 19:02:06 --> Config Class Initialized
INFO - 2016-05-22 19:02:06 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:02:06 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:02:06 --> Utf8 Class Initialized
INFO - 2016-05-22 19:02:06 --> URI Class Initialized
INFO - 2016-05-22 19:02:06 --> Router Class Initialized
INFO - 2016-05-22 19:02:06 --> Output Class Initialized
INFO - 2016-05-22 19:02:06 --> Security Class Initialized
DEBUG - 2016-05-22 19:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:02:06 --> Input Class Initialized
INFO - 2016-05-22 19:02:06 --> Language Class Initialized
INFO - 2016-05-22 19:02:06 --> Loader Class Initialized
INFO - 2016-05-22 19:02:06 --> Helper loaded: url_helper
INFO - 2016-05-22 19:02:06 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:02:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:02:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:02:06 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:02:06 --> Helper loaded: form_helper
INFO - 2016-05-22 19:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:02:06 --> Form Validation Class Initialized
INFO - 2016-05-22 19:02:06 --> Controller Class Initialized
ERROR - 2016-05-22 19:02:07 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 27
ERROR - 2016-05-22 19:02:07 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 30
INFO - 2016-05-22 19:02:07 --> Config Class Initialized
INFO - 2016-05-22 19:02:07 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:02:07 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:02:07 --> Utf8 Class Initialized
INFO - 2016-05-22 19:02:07 --> URI Class Initialized
INFO - 2016-05-22 19:02:07 --> Router Class Initialized
INFO - 2016-05-22 19:02:07 --> Output Class Initialized
INFO - 2016-05-22 19:02:07 --> Security Class Initialized
DEBUG - 2016-05-22 19:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:02:07 --> Input Class Initialized
INFO - 2016-05-22 19:02:07 --> Language Class Initialized
INFO - 2016-05-22 19:02:07 --> Loader Class Initialized
INFO - 2016-05-22 19:02:07 --> Helper loaded: url_helper
INFO - 2016-05-22 19:02:07 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:02:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:02:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:02:07 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:02:07 --> Helper loaded: form_helper
INFO - 2016-05-22 19:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:02:07 --> Form Validation Class Initialized
INFO - 2016-05-22 19:02:07 --> Controller Class Initialized
ERROR - 2016-05-22 19:02:09 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 27
ERROR - 2016-05-22 19:02:09 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 30
INFO - 2016-05-22 19:02:09 --> Config Class Initialized
INFO - 2016-05-22 19:02:09 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:02:09 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:02:09 --> Utf8 Class Initialized
INFO - 2016-05-22 19:02:09 --> URI Class Initialized
DEBUG - 2016-05-22 19:02:09 --> No URI present. Default controller set.
INFO - 2016-05-22 19:02:09 --> Router Class Initialized
INFO - 2016-05-22 19:02:09 --> Output Class Initialized
INFO - 2016-05-22 19:02:09 --> Security Class Initialized
DEBUG - 2016-05-22 19:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:02:09 --> Input Class Initialized
INFO - 2016-05-22 19:02:09 --> Language Class Initialized
INFO - 2016-05-22 19:02:09 --> Loader Class Initialized
INFO - 2016-05-22 19:02:09 --> Helper loaded: url_helper
INFO - 2016-05-22 19:02:09 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:02:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:02:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:02:09 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:02:09 --> Helper loaded: form_helper
INFO - 2016-05-22 19:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:02:09 --> Form Validation Class Initialized
INFO - 2016-05-22 19:02:09 --> Controller Class Initialized
INFO - 2016-05-22 19:02:09 --> Model Class Initialized
INFO - 2016-05-22 19:02:09 --> Database Driver Class Initialized
INFO - 2016-05-22 19:02:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:02:09 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:02:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-22 19:02:09 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 27
ERROR - 2016-05-22 19:02:09 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 30
INFO - 2016-05-22 19:02:09 --> Config Class Initialized
INFO - 2016-05-22 19:02:09 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:02:09 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:02:09 --> Utf8 Class Initialized
INFO - 2016-05-22 19:02:09 --> URI Class Initialized
DEBUG - 2016-05-22 19:02:09 --> No URI present. Default controller set.
INFO - 2016-05-22 19:02:09 --> Router Class Initialized
INFO - 2016-05-22 19:02:10 --> Output Class Initialized
INFO - 2016-05-22 19:02:10 --> Security Class Initialized
DEBUG - 2016-05-22 19:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:02:10 --> Input Class Initialized
INFO - 2016-05-22 19:02:10 --> Language Class Initialized
INFO - 2016-05-22 19:02:10 --> Loader Class Initialized
INFO - 2016-05-22 19:02:10 --> Helper loaded: url_helper
INFO - 2016-05-22 19:02:10 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:02:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:02:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:02:10 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:02:10 --> Helper loaded: form_helper
INFO - 2016-05-22 19:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:02:10 --> Form Validation Class Initialized
INFO - 2016-05-22 19:02:10 --> Controller Class Initialized
INFO - 2016-05-22 19:02:10 --> Model Class Initialized
INFO - 2016-05-22 19:02:10 --> Database Driver Class Initialized
INFO - 2016-05-22 19:02:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:02:10 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:02:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-22 19:02:11 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 27
ERROR - 2016-05-22 19:02:11 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 30
INFO - 2016-05-22 19:02:11 --> Config Class Initialized
INFO - 2016-05-22 19:02:11 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:02:11 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:02:11 --> Utf8 Class Initialized
INFO - 2016-05-22 19:02:11 --> URI Class Initialized
DEBUG - 2016-05-22 19:02:11 --> No URI present. Default controller set.
INFO - 2016-05-22 19:02:11 --> Router Class Initialized
INFO - 2016-05-22 19:02:11 --> Output Class Initialized
INFO - 2016-05-22 19:02:11 --> Security Class Initialized
DEBUG - 2016-05-22 19:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:02:11 --> Input Class Initialized
INFO - 2016-05-22 19:02:11 --> Language Class Initialized
INFO - 2016-05-22 19:02:11 --> Loader Class Initialized
INFO - 2016-05-22 19:02:11 --> Helper loaded: url_helper
INFO - 2016-05-22 19:02:11 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:02:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:02:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:02:11 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:02:11 --> Helper loaded: form_helper
INFO - 2016-05-22 19:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:02:11 --> Form Validation Class Initialized
INFO - 2016-05-22 19:02:11 --> Controller Class Initialized
INFO - 2016-05-22 19:02:11 --> Model Class Initialized
INFO - 2016-05-22 19:02:11 --> Database Driver Class Initialized
INFO - 2016-05-22 19:02:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:02:11 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:02:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-22 19:02:12 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 27
ERROR - 2016-05-22 19:02:12 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 30
INFO - 2016-05-22 19:02:12 --> Config Class Initialized
INFO - 2016-05-22 19:02:12 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:02:12 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:02:12 --> Utf8 Class Initialized
INFO - 2016-05-22 19:02:12 --> URI Class Initialized
DEBUG - 2016-05-22 19:02:12 --> No URI present. Default controller set.
INFO - 2016-05-22 19:02:12 --> Router Class Initialized
INFO - 2016-05-22 19:02:12 --> Output Class Initialized
INFO - 2016-05-22 19:02:12 --> Security Class Initialized
DEBUG - 2016-05-22 19:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:02:12 --> Input Class Initialized
INFO - 2016-05-22 19:02:12 --> Language Class Initialized
INFO - 2016-05-22 19:02:12 --> Loader Class Initialized
INFO - 2016-05-22 19:02:12 --> Helper loaded: url_helper
INFO - 2016-05-22 19:02:12 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:02:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:02:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:02:12 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:02:12 --> Helper loaded: form_helper
INFO - 2016-05-22 19:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:02:12 --> Form Validation Class Initialized
INFO - 2016-05-22 19:02:12 --> Controller Class Initialized
INFO - 2016-05-22 19:02:12 --> Model Class Initialized
INFO - 2016-05-22 19:02:12 --> Database Driver Class Initialized
INFO - 2016-05-22 19:02:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:02:12 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:02:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-22 19:02:17 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 27
ERROR - 2016-05-22 19:02:17 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 30
INFO - 2016-05-22 19:02:17 --> Config Class Initialized
INFO - 2016-05-22 19:02:17 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:02:17 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:02:17 --> Utf8 Class Initialized
INFO - 2016-05-22 19:02:17 --> URI Class Initialized
DEBUG - 2016-05-22 19:02:17 --> No URI present. Default controller set.
INFO - 2016-05-22 19:02:17 --> Router Class Initialized
INFO - 2016-05-22 19:02:17 --> Output Class Initialized
INFO - 2016-05-22 19:02:17 --> Security Class Initialized
DEBUG - 2016-05-22 19:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:02:17 --> Input Class Initialized
INFO - 2016-05-22 19:02:17 --> Language Class Initialized
INFO - 2016-05-22 19:02:17 --> Loader Class Initialized
INFO - 2016-05-22 19:02:17 --> Helper loaded: url_helper
INFO - 2016-05-22 19:02:17 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:02:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:02:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:02:17 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:02:17 --> Helper loaded: form_helper
INFO - 2016-05-22 19:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:02:17 --> Form Validation Class Initialized
INFO - 2016-05-22 19:02:17 --> Controller Class Initialized
INFO - 2016-05-22 19:02:17 --> Model Class Initialized
INFO - 2016-05-22 19:02:17 --> Database Driver Class Initialized
INFO - 2016-05-22 19:02:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:02:17 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:02:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 19:04:54 --> Config Class Initialized
INFO - 2016-05-22 19:04:54 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:04:54 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:04:54 --> Utf8 Class Initialized
INFO - 2016-05-22 19:04:54 --> URI Class Initialized
INFO - 2016-05-22 19:04:54 --> Router Class Initialized
INFO - 2016-05-22 19:04:54 --> Output Class Initialized
INFO - 2016-05-22 19:04:54 --> Security Class Initialized
DEBUG - 2016-05-22 19:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:04:54 --> Input Class Initialized
INFO - 2016-05-22 19:04:54 --> Language Class Initialized
INFO - 2016-05-22 19:04:54 --> Loader Class Initialized
INFO - 2016-05-22 19:04:54 --> Helper loaded: url_helper
INFO - 2016-05-22 19:04:54 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:04:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:04:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:04:54 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:04:54 --> Helper loaded: form_helper
INFO - 2016-05-22 19:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:04:54 --> Form Validation Class Initialized
INFO - 2016-05-22 19:04:54 --> Controller Class Initialized
INFO - 2016-05-22 19:04:54 --> Model Class Initialized
INFO - 2016-05-22 19:04:54 --> Database Driver Class Initialized
INFO - 2016-05-22 19:04:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-22 19:04:54 --> Final output sent to browser
DEBUG - 2016-05-22 19:04:54 --> Total execution time: 0.0835
INFO - 2016-05-22 19:05:30 --> Config Class Initialized
INFO - 2016-05-22 19:05:30 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:05:30 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:05:30 --> Utf8 Class Initialized
INFO - 2016-05-22 19:05:30 --> URI Class Initialized
INFO - 2016-05-22 19:05:30 --> Router Class Initialized
INFO - 2016-05-22 19:05:30 --> Output Class Initialized
INFO - 2016-05-22 19:05:30 --> Security Class Initialized
DEBUG - 2016-05-22 19:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:05:30 --> Input Class Initialized
INFO - 2016-05-22 19:05:30 --> Language Class Initialized
INFO - 2016-05-22 19:05:30 --> Loader Class Initialized
INFO - 2016-05-22 19:05:30 --> Helper loaded: url_helper
INFO - 2016-05-22 19:05:30 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:05:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:05:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:05:30 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:05:30 --> Helper loaded: form_helper
INFO - 2016-05-22 19:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:05:30 --> Form Validation Class Initialized
INFO - 2016-05-22 19:05:30 --> Controller Class Initialized
INFO - 2016-05-22 19:05:31 --> Config Class Initialized
INFO - 2016-05-22 19:05:31 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:05:31 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:05:31 --> Utf8 Class Initialized
INFO - 2016-05-22 19:05:31 --> URI Class Initialized
INFO - 2016-05-22 19:05:31 --> Router Class Initialized
INFO - 2016-05-22 19:05:31 --> Output Class Initialized
INFO - 2016-05-22 19:05:31 --> Security Class Initialized
DEBUG - 2016-05-22 19:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:05:31 --> Input Class Initialized
INFO - 2016-05-22 19:05:31 --> Language Class Initialized
INFO - 2016-05-22 19:05:31 --> Loader Class Initialized
INFO - 2016-05-22 19:05:31 --> Helper loaded: url_helper
INFO - 2016-05-22 19:05:31 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:05:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:05:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:05:31 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:05:31 --> Helper loaded: form_helper
INFO - 2016-05-22 19:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:05:31 --> Form Validation Class Initialized
INFO - 2016-05-22 19:05:31 --> Controller Class Initialized
INFO - 2016-05-22 19:05:32 --> Config Class Initialized
INFO - 2016-05-22 19:05:32 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:05:32 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:05:32 --> Utf8 Class Initialized
INFO - 2016-05-22 19:05:32 --> URI Class Initialized
DEBUG - 2016-05-22 19:05:32 --> No URI present. Default controller set.
INFO - 2016-05-22 19:05:32 --> Router Class Initialized
INFO - 2016-05-22 19:05:32 --> Output Class Initialized
INFO - 2016-05-22 19:05:32 --> Security Class Initialized
DEBUG - 2016-05-22 19:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:05:32 --> Input Class Initialized
INFO - 2016-05-22 19:05:32 --> Language Class Initialized
INFO - 2016-05-22 19:05:32 --> Loader Class Initialized
INFO - 2016-05-22 19:05:32 --> Helper loaded: url_helper
INFO - 2016-05-22 19:05:32 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:05:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:05:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:05:32 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:05:32 --> Helper loaded: form_helper
INFO - 2016-05-22 19:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:05:32 --> Form Validation Class Initialized
INFO - 2016-05-22 19:05:32 --> Controller Class Initialized
INFO - 2016-05-22 19:05:32 --> Model Class Initialized
INFO - 2016-05-22 19:05:32 --> Database Driver Class Initialized
INFO - 2016-05-22 19:05:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:05:32 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:05:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 19:05:56 --> Config Class Initialized
INFO - 2016-05-22 19:05:56 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:05:56 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:05:56 --> Utf8 Class Initialized
INFO - 2016-05-22 19:05:56 --> URI Class Initialized
INFO - 2016-05-22 19:05:56 --> Router Class Initialized
INFO - 2016-05-22 19:05:56 --> Output Class Initialized
INFO - 2016-05-22 19:05:56 --> Security Class Initialized
DEBUG - 2016-05-22 19:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:05:56 --> Input Class Initialized
INFO - 2016-05-22 19:05:56 --> Language Class Initialized
INFO - 2016-05-22 19:05:56 --> Loader Class Initialized
INFO - 2016-05-22 19:05:56 --> Helper loaded: url_helper
INFO - 2016-05-22 19:05:56 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:05:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:05:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:05:56 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:05:56 --> Helper loaded: form_helper
INFO - 2016-05-22 19:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:05:56 --> Form Validation Class Initialized
INFO - 2016-05-22 19:05:56 --> Controller Class Initialized
INFO - 2016-05-22 19:05:56 --> Model Class Initialized
INFO - 2016-05-22 19:05:56 --> Database Driver Class Initialized
INFO - 2016-05-22 19:05:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-22 19:05:56 --> Final output sent to browser
DEBUG - 2016-05-22 19:05:56 --> Total execution time: 0.1491
ERROR - 2016-05-22 19:07:13 --> Severity: Warning --> define() expects at least 2 parameters, 1 given C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config\config.php 27
INFO - 2016-05-22 19:07:13 --> Config Class Initialized
INFO - 2016-05-22 19:07:13 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:07:13 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:07:13 --> Utf8 Class Initialized
INFO - 2016-05-22 19:07:13 --> URI Class Initialized
INFO - 2016-05-22 19:07:13 --> Router Class Initialized
INFO - 2016-05-22 19:07:13 --> Output Class Initialized
INFO - 2016-05-22 19:07:13 --> Security Class Initialized
DEBUG - 2016-05-22 19:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:07:13 --> Input Class Initialized
INFO - 2016-05-22 19:07:13 --> Language Class Initialized
INFO - 2016-05-22 19:07:13 --> Loader Class Initialized
INFO - 2016-05-22 19:07:13 --> Helper loaded: url_helper
INFO - 2016-05-22 19:07:13 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:07:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:07:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:07:13 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:07:13 --> Helper loaded: form_helper
INFO - 2016-05-22 19:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:07:13 --> Form Validation Class Initialized
INFO - 2016-05-22 19:07:13 --> Controller Class Initialized
INFO - 2016-05-22 19:07:13 --> Model Class Initialized
INFO - 2016-05-22 19:07:13 --> Database Driver Class Initialized
INFO - 2016-05-22 19:07:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-22 19:07:13 --> Final output sent to browser
DEBUG - 2016-05-22 19:07:13 --> Total execution time: 0.0689
INFO - 2016-05-22 19:07:25 --> Config Class Initialized
INFO - 2016-05-22 19:07:25 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:07:25 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:07:25 --> Utf8 Class Initialized
INFO - 2016-05-22 19:07:25 --> URI Class Initialized
INFO - 2016-05-22 19:07:25 --> Router Class Initialized
INFO - 2016-05-22 19:07:25 --> Output Class Initialized
INFO - 2016-05-22 19:07:25 --> Security Class Initialized
DEBUG - 2016-05-22 19:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:07:25 --> Input Class Initialized
INFO - 2016-05-22 19:07:25 --> Language Class Initialized
INFO - 2016-05-22 19:07:25 --> Loader Class Initialized
INFO - 2016-05-22 19:07:25 --> Helper loaded: url_helper
INFO - 2016-05-22 19:07:25 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:07:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:07:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:07:25 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:07:25 --> Helper loaded: form_helper
INFO - 2016-05-22 19:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:07:25 --> Form Validation Class Initialized
INFO - 2016-05-22 19:07:25 --> Controller Class Initialized
INFO - 2016-05-22 19:07:25 --> Model Class Initialized
INFO - 2016-05-22 19:07:25 --> Database Driver Class Initialized
INFO - 2016-05-22 19:07:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-22 19:07:25 --> Final output sent to browser
DEBUG - 2016-05-22 19:07:25 --> Total execution time: 0.0779
INFO - 2016-05-22 19:07:54 --> Config Class Initialized
INFO - 2016-05-22 19:07:54 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:07:54 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:07:54 --> Utf8 Class Initialized
INFO - 2016-05-22 19:07:54 --> URI Class Initialized
INFO - 2016-05-22 19:07:54 --> Router Class Initialized
INFO - 2016-05-22 19:07:54 --> Output Class Initialized
INFO - 2016-05-22 19:07:54 --> Security Class Initialized
DEBUG - 2016-05-22 19:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:07:54 --> Input Class Initialized
INFO - 2016-05-22 19:07:54 --> Language Class Initialized
INFO - 2016-05-22 19:07:54 --> Loader Class Initialized
INFO - 2016-05-22 19:07:54 --> Helper loaded: url_helper
INFO - 2016-05-22 19:07:54 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:07:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:07:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:07:54 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:07:54 --> Helper loaded: form_helper
INFO - 2016-05-22 19:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:07:54 --> Form Validation Class Initialized
INFO - 2016-05-22 19:07:54 --> Controller Class Initialized
INFO - 2016-05-22 19:07:54 --> Model Class Initialized
INFO - 2016-05-22 19:07:54 --> Database Driver Class Initialized
INFO - 2016-05-22 19:07:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-22 19:07:54 --> Final output sent to browser
DEBUG - 2016-05-22 19:07:54 --> Total execution time: 0.0736
INFO - 2016-05-22 19:08:06 --> Config Class Initialized
INFO - 2016-05-22 19:08:06 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:08:06 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:08:06 --> Utf8 Class Initialized
INFO - 2016-05-22 19:08:06 --> URI Class Initialized
INFO - 2016-05-22 19:08:06 --> Router Class Initialized
INFO - 2016-05-22 19:08:06 --> Output Class Initialized
INFO - 2016-05-22 19:08:06 --> Security Class Initialized
DEBUG - 2016-05-22 19:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:08:06 --> Input Class Initialized
INFO - 2016-05-22 19:08:06 --> Language Class Initialized
INFO - 2016-05-22 19:08:06 --> Loader Class Initialized
INFO - 2016-05-22 19:08:06 --> Helper loaded: url_helper
INFO - 2016-05-22 19:08:06 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:08:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:08:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:08:06 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:08:06 --> Helper loaded: form_helper
INFO - 2016-05-22 19:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:08:06 --> Form Validation Class Initialized
INFO - 2016-05-22 19:08:06 --> Controller Class Initialized
INFO - 2016-05-22 19:08:06 --> Model Class Initialized
INFO - 2016-05-22 19:08:06 --> Database Driver Class Initialized
INFO - 2016-05-22 19:08:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-22 19:08:06 --> Final output sent to browser
DEBUG - 2016-05-22 19:08:06 --> Total execution time: 0.0756
INFO - 2016-05-22 19:09:26 --> Config Class Initialized
INFO - 2016-05-22 19:09:26 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:09:26 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:09:26 --> Utf8 Class Initialized
INFO - 2016-05-22 19:09:26 --> URI Class Initialized
INFO - 2016-05-22 19:09:26 --> Router Class Initialized
INFO - 2016-05-22 19:09:26 --> Output Class Initialized
INFO - 2016-05-22 19:09:26 --> Security Class Initialized
DEBUG - 2016-05-22 19:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:09:26 --> Input Class Initialized
INFO - 2016-05-22 19:09:26 --> Language Class Initialized
INFO - 2016-05-22 19:09:26 --> Loader Class Initialized
INFO - 2016-05-22 19:09:26 --> Helper loaded: url_helper
INFO - 2016-05-22 19:09:26 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:09:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:09:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:09:26 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:09:26 --> Helper loaded: form_helper
INFO - 2016-05-22 19:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:09:26 --> Form Validation Class Initialized
INFO - 2016-05-22 19:09:26 --> Controller Class Initialized
INFO - 2016-05-22 19:09:26 --> Model Class Initialized
INFO - 2016-05-22 19:09:26 --> Database Driver Class Initialized
INFO - 2016-05-22 19:09:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-22 19:09:26 --> Final output sent to browser
DEBUG - 2016-05-22 19:09:26 --> Total execution time: 0.0759
INFO - 2016-05-22 19:09:29 --> Config Class Initialized
INFO - 2016-05-22 19:09:29 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:09:29 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:09:29 --> Utf8 Class Initialized
INFO - 2016-05-22 19:09:29 --> URI Class Initialized
INFO - 2016-05-22 19:09:29 --> Router Class Initialized
INFO - 2016-05-22 19:09:29 --> Output Class Initialized
INFO - 2016-05-22 19:09:29 --> Security Class Initialized
DEBUG - 2016-05-22 19:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:09:29 --> Input Class Initialized
INFO - 2016-05-22 19:09:29 --> Language Class Initialized
INFO - 2016-05-22 19:09:29 --> Loader Class Initialized
INFO - 2016-05-22 19:09:29 --> Helper loaded: url_helper
INFO - 2016-05-22 19:09:29 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:09:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:09:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:09:29 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:09:30 --> Helper loaded: form_helper
INFO - 2016-05-22 19:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:09:30 --> Form Validation Class Initialized
INFO - 2016-05-22 19:09:30 --> Controller Class Initialized
INFO - 2016-05-22 19:09:30 --> Config Class Initialized
INFO - 2016-05-22 19:09:30 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:09:30 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:09:30 --> Utf8 Class Initialized
INFO - 2016-05-22 19:09:30 --> URI Class Initialized
INFO - 2016-05-22 19:09:30 --> Router Class Initialized
INFO - 2016-05-22 19:09:30 --> Output Class Initialized
INFO - 2016-05-22 19:09:30 --> Security Class Initialized
DEBUG - 2016-05-22 19:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:09:30 --> Input Class Initialized
INFO - 2016-05-22 19:09:30 --> Language Class Initialized
INFO - 2016-05-22 19:09:30 --> Loader Class Initialized
INFO - 2016-05-22 19:09:30 --> Helper loaded: url_helper
INFO - 2016-05-22 19:09:30 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:09:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:09:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:09:30 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:09:30 --> Helper loaded: form_helper
INFO - 2016-05-22 19:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:09:30 --> Form Validation Class Initialized
INFO - 2016-05-22 19:09:30 --> Controller Class Initialized
INFO - 2016-05-22 19:09:30 --> Model Class Initialized
INFO - 2016-05-22 19:09:30 --> Database Driver Class Initialized
INFO - 2016-05-22 19:09:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-22 19:09:30 --> Final output sent to browser
DEBUG - 2016-05-22 19:09:30 --> Total execution time: 0.0980
INFO - 2016-05-22 19:09:34 --> Config Class Initialized
INFO - 2016-05-22 19:09:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:09:34 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:09:34 --> Utf8 Class Initialized
INFO - 2016-05-22 19:09:34 --> URI Class Initialized
INFO - 2016-05-22 19:09:34 --> Router Class Initialized
INFO - 2016-05-22 19:09:34 --> Output Class Initialized
INFO - 2016-05-22 19:09:34 --> Security Class Initialized
DEBUG - 2016-05-22 19:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:09:34 --> Input Class Initialized
INFO - 2016-05-22 19:09:34 --> Language Class Initialized
INFO - 2016-05-22 19:09:34 --> Loader Class Initialized
INFO - 2016-05-22 19:09:34 --> Helper loaded: url_helper
INFO - 2016-05-22 19:09:34 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:09:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:09:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:09:34 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:09:34 --> Helper loaded: form_helper
INFO - 2016-05-22 19:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:09:34 --> Form Validation Class Initialized
INFO - 2016-05-22 19:09:34 --> Controller Class Initialized
INFO - 2016-05-22 19:09:34 --> Model Class Initialized
INFO - 2016-05-22 19:09:34 --> Database Driver Class Initialized
INFO - 2016-05-22 19:09:34 --> Config Class Initialized
INFO - 2016-05-22 19:09:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:09:34 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:09:34 --> Utf8 Class Initialized
INFO - 2016-05-22 19:09:34 --> URI Class Initialized
INFO - 2016-05-22 19:09:34 --> Router Class Initialized
INFO - 2016-05-22 19:09:34 --> Output Class Initialized
INFO - 2016-05-22 19:09:34 --> Security Class Initialized
DEBUG - 2016-05-22 19:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:09:34 --> Input Class Initialized
INFO - 2016-05-22 19:09:34 --> Language Class Initialized
INFO - 2016-05-22 19:09:34 --> Loader Class Initialized
INFO - 2016-05-22 19:09:34 --> Helper loaded: url_helper
INFO - 2016-05-22 19:09:34 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:09:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:09:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:09:34 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:09:34 --> Helper loaded: form_helper
INFO - 2016-05-22 19:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:09:34 --> Form Validation Class Initialized
INFO - 2016-05-22 19:09:34 --> Controller Class Initialized
INFO - 2016-05-22 19:09:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-22 19:09:34 --> Model Class Initialized
INFO - 2016-05-22 19:09:34 --> Database Driver Class Initialized
INFO - 2016-05-22 19:09:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 19:09:34 --> Final output sent to browser
DEBUG - 2016-05-22 19:09:34 --> Total execution time: 0.0878
INFO - 2016-05-22 19:09:35 --> Config Class Initialized
INFO - 2016-05-22 19:09:35 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:09:35 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:09:35 --> Utf8 Class Initialized
INFO - 2016-05-22 19:09:35 --> URI Class Initialized
INFO - 2016-05-22 19:09:35 --> Router Class Initialized
INFO - 2016-05-22 19:09:35 --> Output Class Initialized
INFO - 2016-05-22 19:09:35 --> Security Class Initialized
DEBUG - 2016-05-22 19:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:09:35 --> Input Class Initialized
INFO - 2016-05-22 19:09:35 --> Language Class Initialized
INFO - 2016-05-22 19:09:35 --> Loader Class Initialized
INFO - 2016-05-22 19:09:35 --> Helper loaded: url_helper
INFO - 2016-05-22 19:09:35 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:09:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:09:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:09:35 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:09:35 --> Helper loaded: form_helper
INFO - 2016-05-22 19:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:09:35 --> Form Validation Class Initialized
INFO - 2016-05-22 19:09:35 --> Controller Class Initialized
INFO - 2016-05-22 19:09:35 --> Model Class Initialized
INFO - 2016-05-22 19:09:35 --> Database Driver Class Initialized
INFO - 2016-05-22 19:09:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:09:35 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:09:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 19:09:35 --> Final output sent to browser
DEBUG - 2016-05-22 19:09:35 --> Total execution time: 0.6009
INFO - 2016-05-22 19:10:59 --> Config Class Initialized
INFO - 2016-05-22 19:10:59 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:10:59 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:10:59 --> Utf8 Class Initialized
INFO - 2016-05-22 19:10:59 --> URI Class Initialized
DEBUG - 2016-05-22 19:10:59 --> No URI present. Default controller set.
INFO - 2016-05-22 19:10:59 --> Router Class Initialized
INFO - 2016-05-22 19:10:59 --> Output Class Initialized
INFO - 2016-05-22 19:10:59 --> Security Class Initialized
DEBUG - 2016-05-22 19:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:10:59 --> Input Class Initialized
INFO - 2016-05-22 19:10:59 --> Language Class Initialized
INFO - 2016-05-22 19:10:59 --> Loader Class Initialized
INFO - 2016-05-22 19:10:59 --> Helper loaded: url_helper
INFO - 2016-05-22 19:10:59 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:10:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:10:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:10:59 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:10:59 --> Helper loaded: form_helper
INFO - 2016-05-22 19:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:10:59 --> Form Validation Class Initialized
INFO - 2016-05-22 19:10:59 --> Controller Class Initialized
INFO - 2016-05-22 19:10:59 --> Model Class Initialized
INFO - 2016-05-22 19:10:59 --> Database Driver Class Initialized
INFO - 2016-05-22 19:10:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:10:59 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:10:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 19:10:59 --> Config Class Initialized
INFO - 2016-05-22 19:10:59 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:10:59 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:10:59 --> Utf8 Class Initialized
INFO - 2016-05-22 19:10:59 --> URI Class Initialized
INFO - 2016-05-22 19:10:59 --> Router Class Initialized
INFO - 2016-05-22 19:10:59 --> Output Class Initialized
INFO - 2016-05-22 19:10:59 --> Security Class Initialized
DEBUG - 2016-05-22 19:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:10:59 --> Input Class Initialized
INFO - 2016-05-22 19:10:59 --> Language Class Initialized
INFO - 2016-05-22 19:10:59 --> Loader Class Initialized
INFO - 2016-05-22 19:10:59 --> Helper loaded: url_helper
INFO - 2016-05-22 19:10:59 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:10:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:10:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:10:59 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:10:59 --> Helper loaded: form_helper
INFO - 2016-05-22 19:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:10:59 --> Form Validation Class Initialized
INFO - 2016-05-22 19:10:59 --> Controller Class Initialized
INFO - 2016-05-22 19:10:59 --> Model Class Initialized
INFO - 2016-05-22 19:10:59 --> Database Driver Class Initialized
INFO - 2016-05-22 19:10:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-22 19:10:59 --> Final output sent to browser
DEBUG - 2016-05-22 19:10:59 --> Total execution time: 0.0815
INFO - 2016-05-22 19:12:09 --> Config Class Initialized
INFO - 2016-05-22 19:12:09 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:12:09 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:12:09 --> Utf8 Class Initialized
INFO - 2016-05-22 19:12:09 --> URI Class Initialized
INFO - 2016-05-22 19:12:09 --> Router Class Initialized
INFO - 2016-05-22 19:12:09 --> Output Class Initialized
INFO - 2016-05-22 19:12:09 --> Security Class Initialized
DEBUG - 2016-05-22 19:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:12:09 --> Input Class Initialized
INFO - 2016-05-22 19:12:09 --> Language Class Initialized
INFO - 2016-05-22 19:12:09 --> Loader Class Initialized
INFO - 2016-05-22 19:12:09 --> Helper loaded: url_helper
INFO - 2016-05-22 19:12:09 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:12:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:12:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:12:09 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:12:09 --> Helper loaded: form_helper
INFO - 2016-05-22 19:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:12:09 --> Form Validation Class Initialized
INFO - 2016-05-22 19:12:09 --> Controller Class Initialized
INFO - 2016-05-22 19:12:09 --> Model Class Initialized
INFO - 2016-05-22 19:12:09 --> Database Driver Class Initialized
INFO - 2016-05-22 19:12:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-22 19:12:09 --> Final output sent to browser
DEBUG - 2016-05-22 19:12:09 --> Total execution time: 0.0718
INFO - 2016-05-22 19:12:15 --> Config Class Initialized
INFO - 2016-05-22 19:12:15 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:12:15 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:12:15 --> Utf8 Class Initialized
INFO - 2016-05-22 19:12:15 --> URI Class Initialized
INFO - 2016-05-22 19:12:15 --> Router Class Initialized
INFO - 2016-05-22 19:12:15 --> Output Class Initialized
INFO - 2016-05-22 19:12:15 --> Security Class Initialized
DEBUG - 2016-05-22 19:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:12:15 --> Input Class Initialized
INFO - 2016-05-22 19:12:15 --> Language Class Initialized
INFO - 2016-05-22 19:12:15 --> Loader Class Initialized
INFO - 2016-05-22 19:12:15 --> Helper loaded: url_helper
INFO - 2016-05-22 19:12:15 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:12:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:12:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:12:15 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:12:15 --> Helper loaded: form_helper
INFO - 2016-05-22 19:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:12:15 --> Form Validation Class Initialized
INFO - 2016-05-22 19:12:15 --> Controller Class Initialized
INFO - 2016-05-22 19:12:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-22 19:12:15 --> Model Class Initialized
INFO - 2016-05-22 19:12:15 --> Database Driver Class Initialized
INFO - 2016-05-22 19:12:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 19:12:15 --> Final output sent to browser
DEBUG - 2016-05-22 19:12:15 --> Total execution time: 0.1380
INFO - 2016-05-22 19:12:15 --> Config Class Initialized
INFO - 2016-05-22 19:12:15 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:12:15 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:12:15 --> Utf8 Class Initialized
INFO - 2016-05-22 19:12:15 --> URI Class Initialized
INFO - 2016-05-22 19:12:15 --> Router Class Initialized
INFO - 2016-05-22 19:12:15 --> Output Class Initialized
INFO - 2016-05-22 19:12:15 --> Security Class Initialized
DEBUG - 2016-05-22 19:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:12:15 --> Input Class Initialized
INFO - 2016-05-22 19:12:15 --> Language Class Initialized
INFO - 2016-05-22 19:12:15 --> Loader Class Initialized
INFO - 2016-05-22 19:12:15 --> Helper loaded: url_helper
INFO - 2016-05-22 19:12:15 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:12:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:12:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:12:15 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:12:15 --> Helper loaded: form_helper
INFO - 2016-05-22 19:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:12:15 --> Form Validation Class Initialized
INFO - 2016-05-22 19:12:15 --> Controller Class Initialized
INFO - 2016-05-22 19:12:15 --> Model Class Initialized
INFO - 2016-05-22 19:12:15 --> Database Driver Class Initialized
INFO - 2016-05-22 19:12:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:12:15 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:12:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 19:12:15 --> Final output sent to browser
DEBUG - 2016-05-22 19:12:15 --> Total execution time: 0.0984
INFO - 2016-05-22 19:12:16 --> Config Class Initialized
INFO - 2016-05-22 19:12:16 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:12:16 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:12:16 --> Utf8 Class Initialized
INFO - 2016-05-22 19:12:16 --> URI Class Initialized
INFO - 2016-05-22 19:12:16 --> Router Class Initialized
INFO - 2016-05-22 19:12:16 --> Output Class Initialized
INFO - 2016-05-22 19:12:16 --> Security Class Initialized
DEBUG - 2016-05-22 19:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:12:16 --> Input Class Initialized
INFO - 2016-05-22 19:12:16 --> Language Class Initialized
INFO - 2016-05-22 19:12:16 --> Loader Class Initialized
INFO - 2016-05-22 19:12:16 --> Helper loaded: url_helper
INFO - 2016-05-22 19:12:16 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:12:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:12:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:12:16 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:12:16 --> Helper loaded: form_helper
INFO - 2016-05-22 19:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:12:16 --> Form Validation Class Initialized
INFO - 2016-05-22 19:12:16 --> Controller Class Initialized
INFO - 2016-05-22 19:12:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-22 19:12:16 --> Model Class Initialized
INFO - 2016-05-22 19:12:16 --> Database Driver Class Initialized
INFO - 2016-05-22 19:12:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-22 19:12:16 --> Final output sent to browser
DEBUG - 2016-05-22 19:12:16 --> Total execution time: 0.0998
INFO - 2016-05-22 19:12:17 --> Config Class Initialized
INFO - 2016-05-22 19:12:17 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:12:17 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:12:17 --> Utf8 Class Initialized
INFO - 2016-05-22 19:12:17 --> URI Class Initialized
INFO - 2016-05-22 19:12:17 --> Router Class Initialized
INFO - 2016-05-22 19:12:17 --> Output Class Initialized
INFO - 2016-05-22 19:12:17 --> Security Class Initialized
DEBUG - 2016-05-22 19:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:12:17 --> Input Class Initialized
INFO - 2016-05-22 19:12:17 --> Language Class Initialized
INFO - 2016-05-22 19:12:17 --> Loader Class Initialized
INFO - 2016-05-22 19:12:17 --> Helper loaded: url_helper
INFO - 2016-05-22 19:12:17 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:12:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:12:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:12:17 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:12:17 --> Helper loaded: form_helper
INFO - 2016-05-22 19:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:12:17 --> Form Validation Class Initialized
INFO - 2016-05-22 19:12:17 --> Controller Class Initialized
INFO - 2016-05-22 19:12:17 --> Model Class Initialized
INFO - 2016-05-22 19:12:17 --> Database Driver Class Initialized
INFO - 2016-05-22 19:12:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:12:17 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:12:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-22 19:12:17 --> Final output sent to browser
DEBUG - 2016-05-22 19:12:17 --> Total execution time: 0.1367
INFO - 2016-05-22 19:12:19 --> Config Class Initialized
INFO - 2016-05-22 19:12:19 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:12:19 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:12:19 --> Utf8 Class Initialized
INFO - 2016-05-22 19:12:19 --> URI Class Initialized
INFO - 2016-05-22 19:12:20 --> Router Class Initialized
INFO - 2016-05-22 19:12:20 --> Output Class Initialized
INFO - 2016-05-22 19:12:20 --> Security Class Initialized
DEBUG - 2016-05-22 19:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:12:20 --> Input Class Initialized
INFO - 2016-05-22 19:12:20 --> Language Class Initialized
INFO - 2016-05-22 19:12:20 --> Loader Class Initialized
INFO - 2016-05-22 19:12:20 --> Helper loaded: url_helper
INFO - 2016-05-22 19:12:20 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:12:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:12:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:12:20 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:12:20 --> Helper loaded: form_helper
INFO - 2016-05-22 19:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:12:20 --> Form Validation Class Initialized
INFO - 2016-05-22 19:12:20 --> Controller Class Initialized
INFO - 2016-05-22 19:12:20 --> Model Class Initialized
INFO - 2016-05-22 19:12:20 --> Database Driver Class Initialized
INFO - 2016-05-22 19:12:20 --> Config Class Initialized
INFO - 2016-05-22 19:12:20 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:12:20 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:12:20 --> Utf8 Class Initialized
INFO - 2016-05-22 19:12:20 --> URI Class Initialized
INFO - 2016-05-22 19:12:20 --> Router Class Initialized
INFO - 2016-05-22 19:12:20 --> Output Class Initialized
INFO - 2016-05-22 19:12:20 --> Security Class Initialized
DEBUG - 2016-05-22 19:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:12:20 --> Input Class Initialized
INFO - 2016-05-22 19:12:20 --> Language Class Initialized
INFO - 2016-05-22 19:12:20 --> Loader Class Initialized
INFO - 2016-05-22 19:12:20 --> Helper loaded: url_helper
INFO - 2016-05-22 19:12:20 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:12:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:12:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:12:20 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:12:20 --> Helper loaded: form_helper
INFO - 2016-05-22 19:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:12:20 --> Form Validation Class Initialized
INFO - 2016-05-22 19:12:20 --> Controller Class Initialized
INFO - 2016-05-22 19:12:20 --> Model Class Initialized
INFO - 2016-05-22 19:12:20 --> Database Driver Class Initialized
INFO - 2016-05-22 19:12:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-22 19:12:20 --> Final output sent to browser
DEBUG - 2016-05-22 19:12:20 --> Total execution time: 0.0677
INFO - 2016-05-22 19:12:21 --> Config Class Initialized
INFO - 2016-05-22 19:12:21 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:12:21 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:12:21 --> Utf8 Class Initialized
INFO - 2016-05-22 19:12:21 --> URI Class Initialized
INFO - 2016-05-22 19:12:21 --> Router Class Initialized
INFO - 2016-05-22 19:12:21 --> Output Class Initialized
INFO - 2016-05-22 19:12:21 --> Security Class Initialized
DEBUG - 2016-05-22 19:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:12:21 --> Input Class Initialized
INFO - 2016-05-22 19:12:21 --> Language Class Initialized
INFO - 2016-05-22 19:12:21 --> Loader Class Initialized
INFO - 2016-05-22 19:12:21 --> Helper loaded: url_helper
INFO - 2016-05-22 19:12:21 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:12:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:12:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:12:21 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:12:21 --> Helper loaded: form_helper
INFO - 2016-05-22 19:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:12:21 --> Form Validation Class Initialized
INFO - 2016-05-22 19:12:21 --> Controller Class Initialized
INFO - 2016-05-22 19:12:21 --> Model Class Initialized
INFO - 2016-05-22 19:12:21 --> Database Driver Class Initialized
INFO - 2016-05-22 19:12:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-22 19:12:21 --> Final output sent to browser
DEBUG - 2016-05-22 19:12:21 --> Total execution time: 0.0843
INFO - 2016-05-22 19:12:34 --> Config Class Initialized
INFO - 2016-05-22 19:12:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:12:34 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:12:34 --> Utf8 Class Initialized
INFO - 2016-05-22 19:12:34 --> URI Class Initialized
INFO - 2016-05-22 19:12:34 --> Router Class Initialized
INFO - 2016-05-22 19:12:34 --> Output Class Initialized
INFO - 2016-05-22 19:12:34 --> Security Class Initialized
DEBUG - 2016-05-22 19:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:12:34 --> Input Class Initialized
INFO - 2016-05-22 19:12:34 --> Language Class Initialized
INFO - 2016-05-22 19:12:34 --> Loader Class Initialized
INFO - 2016-05-22 19:12:34 --> Helper loaded: url_helper
INFO - 2016-05-22 19:12:34 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:12:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:12:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:12:34 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:12:34 --> Helper loaded: form_helper
INFO - 2016-05-22 19:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:12:34 --> Form Validation Class Initialized
INFO - 2016-05-22 19:12:34 --> Controller Class Initialized
INFO - 2016-05-22 19:12:34 --> Model Class Initialized
INFO - 2016-05-22 19:12:34 --> Database Driver Class Initialized
INFO - 2016-05-22 19:12:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-22 19:12:34 --> Final output sent to browser
DEBUG - 2016-05-22 19:12:34 --> Total execution time: 0.0983
INFO - 2016-05-22 19:12:50 --> Config Class Initialized
INFO - 2016-05-22 19:12:50 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:12:50 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:12:50 --> Utf8 Class Initialized
INFO - 2016-05-22 19:12:50 --> URI Class Initialized
INFO - 2016-05-22 19:12:50 --> Router Class Initialized
INFO - 2016-05-22 19:12:50 --> Output Class Initialized
INFO - 2016-05-22 19:12:50 --> Security Class Initialized
DEBUG - 2016-05-22 19:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:12:50 --> Input Class Initialized
INFO - 2016-05-22 19:12:50 --> Language Class Initialized
INFO - 2016-05-22 19:12:50 --> Loader Class Initialized
INFO - 2016-05-22 19:12:50 --> Helper loaded: url_helper
INFO - 2016-05-22 19:12:50 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:12:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:12:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:12:50 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:12:50 --> Helper loaded: form_helper
INFO - 2016-05-22 19:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:12:50 --> Form Validation Class Initialized
INFO - 2016-05-22 19:12:50 --> Controller Class Initialized
INFO - 2016-05-22 19:12:50 --> Model Class Initialized
INFO - 2016-05-22 19:12:50 --> Database Driver Class Initialized
INFO - 2016-05-22 19:12:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-22 19:12:50 --> Final output sent to browser
DEBUG - 2016-05-22 19:12:50 --> Total execution time: 0.0844
INFO - 2016-05-22 19:14:29 --> Config Class Initialized
INFO - 2016-05-22 19:14:29 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:14:29 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:14:29 --> Utf8 Class Initialized
INFO - 2016-05-22 19:14:29 --> URI Class Initialized
INFO - 2016-05-22 19:14:29 --> Router Class Initialized
INFO - 2016-05-22 19:14:29 --> Output Class Initialized
INFO - 2016-05-22 19:14:29 --> Security Class Initialized
DEBUG - 2016-05-22 19:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:14:29 --> Input Class Initialized
INFO - 2016-05-22 19:14:29 --> Language Class Initialized
INFO - 2016-05-22 19:14:29 --> Loader Class Initialized
INFO - 2016-05-22 19:14:29 --> Helper loaded: url_helper
INFO - 2016-05-22 19:14:29 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:14:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:14:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:14:29 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:14:29 --> Helper loaded: form_helper
INFO - 2016-05-22 19:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:14:30 --> Form Validation Class Initialized
INFO - 2016-05-22 19:14:30 --> Controller Class Initialized
INFO - 2016-05-22 19:14:30 --> Model Class Initialized
INFO - 2016-05-22 19:14:30 --> Database Driver Class Initialized
ERROR - 2016-05-22 19:14:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '2daw1516_isabel'@'localhost' (using password: YES) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2016-05-22 19:14:30 --> Unable to connect to the database
INFO - 2016-05-22 19:14:30 --> Language file loaded: language/spanish/db_lang.php
ERROR - 2016-05-22 19:41:34 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
INFO - 2016-05-22 19:41:34 --> Config Class Initialized
INFO - 2016-05-22 19:41:34 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:41:34 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:41:34 --> Utf8 Class Initialized
INFO - 2016-05-22 19:41:34 --> URI Class Initialized
DEBUG - 2016-05-22 19:41:34 --> No URI present. Default controller set.
INFO - 2016-05-22 19:41:34 --> Router Class Initialized
INFO - 2016-05-22 19:41:34 --> Output Class Initialized
INFO - 2016-05-22 19:41:34 --> Security Class Initialized
DEBUG - 2016-05-22 19:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:41:34 --> Input Class Initialized
INFO - 2016-05-22 19:41:34 --> Language Class Initialized
INFO - 2016-05-22 19:41:34 --> Loader Class Initialized
INFO - 2016-05-22 19:41:34 --> Helper loaded: url_helper
INFO - 2016-05-22 19:41:34 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:41:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:41:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:41:34 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:41:34 --> Helper loaded: form_helper
ERROR - 2016-05-22 19:41:34 --> Severity: error --> Exception: Session: Configured driver 'files' was not found. Aborting. /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/system/libraries/Session/Session.php 230
INFO - 2016-05-22 19:45:03 --> Config Class Initialized
INFO - 2016-05-22 19:45:03 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:45:03 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:45:03 --> Utf8 Class Initialized
INFO - 2016-05-22 19:45:03 --> URI Class Initialized
DEBUG - 2016-05-22 19:45:03 --> No URI present. Default controller set.
INFO - 2016-05-22 19:45:03 --> Router Class Initialized
INFO - 2016-05-22 19:45:03 --> Output Class Initialized
INFO - 2016-05-22 19:45:03 --> Security Class Initialized
DEBUG - 2016-05-22 19:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:45:03 --> Input Class Initialized
INFO - 2016-05-22 19:45:03 --> Language Class Initialized
INFO - 2016-05-22 19:45:03 --> Loader Class Initialized
INFO - 2016-05-22 19:45:03 --> Helper loaded: url_helper
INFO - 2016-05-22 19:45:03 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:45:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:45:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:45:03 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:45:03 --> Helper loaded: form_helper
INFO - 2016-05-22 19:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:45:03 --> Form Validation Class Initialized
INFO - 2016-05-22 19:45:03 --> Controller Class Initialized
INFO - 2016-05-22 19:45:03 --> Model Class Initialized
INFO - 2016-05-22 19:45:03 --> Database Driver Class Initialized
INFO - 2016-05-22 19:45:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:45:03 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:45:03 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-22 19:45:03 --> Config Class Initialized
INFO - 2016-05-22 19:45:03 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:45:03 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:45:03 --> Utf8 Class Initialized
INFO - 2016-05-22 19:45:03 --> URI Class Initialized
INFO - 2016-05-22 19:45:03 --> Router Class Initialized
INFO - 2016-05-22 19:45:03 --> Output Class Initialized
INFO - 2016-05-22 19:45:03 --> Security Class Initialized
DEBUG - 2016-05-22 19:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:45:03 --> Input Class Initialized
INFO - 2016-05-22 19:45:03 --> Language Class Initialized
INFO - 2016-05-22 19:45:03 --> Loader Class Initialized
INFO - 2016-05-22 19:45:03 --> Helper loaded: url_helper
INFO - 2016-05-22 19:45:03 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:45:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:45:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:45:03 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:45:03 --> Helper loaded: form_helper
INFO - 2016-05-22 19:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:45:03 --> Form Validation Class Initialized
INFO - 2016-05-22 19:45:03 --> Controller Class Initialized
INFO - 2016-05-22 19:45:03 --> Model Class Initialized
INFO - 2016-05-22 19:45:03 --> Database Driver Class Initialized
INFO - 2016-05-22 19:45:03 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_login.php
INFO - 2016-05-22 19:45:03 --> Final output sent to browser
DEBUG - 2016-05-22 19:45:03 --> Total execution time: 0.0760
INFO - 2016-05-22 19:45:11 --> Config Class Initialized
INFO - 2016-05-22 19:45:11 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:45:11 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:45:11 --> Utf8 Class Initialized
INFO - 2016-05-22 19:45:11 --> URI Class Initialized
INFO - 2016-05-22 19:45:11 --> Router Class Initialized
INFO - 2016-05-22 19:45:11 --> Output Class Initialized
INFO - 2016-05-22 19:45:11 --> Security Class Initialized
DEBUG - 2016-05-22 19:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:45:11 --> Input Class Initialized
INFO - 2016-05-22 19:45:11 --> Language Class Initialized
INFO - 2016-05-22 19:45:11 --> Loader Class Initialized
INFO - 2016-05-22 19:45:11 --> Helper loaded: url_helper
INFO - 2016-05-22 19:45:11 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:45:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:45:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:45:11 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:45:11 --> Helper loaded: form_helper
INFO - 2016-05-22 19:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:45:11 --> Form Validation Class Initialized
INFO - 2016-05-22 19:45:11 --> Controller Class Initialized
INFO - 2016-05-22 19:45:11 --> Model Class Initialized
INFO - 2016-05-22 19:45:11 --> Database Driver Class Initialized
INFO - 2016-05-22 19:45:11 --> Config Class Initialized
INFO - 2016-05-22 19:45:11 --> Hooks Class Initialized
DEBUG - 2016-05-22 19:45:11 --> UTF-8 Support Enabled
INFO - 2016-05-22 19:45:11 --> Utf8 Class Initialized
INFO - 2016-05-22 19:45:11 --> URI Class Initialized
DEBUG - 2016-05-22 19:45:11 --> No URI present. Default controller set.
INFO - 2016-05-22 19:45:11 --> Router Class Initialized
INFO - 2016-05-22 19:45:11 --> Output Class Initialized
INFO - 2016-05-22 19:45:11 --> Security Class Initialized
DEBUG - 2016-05-22 19:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-22 19:45:11 --> Input Class Initialized
INFO - 2016-05-22 19:45:11 --> Language Class Initialized
INFO - 2016-05-22 19:45:11 --> Loader Class Initialized
INFO - 2016-05-22 19:45:11 --> Helper loaded: url_helper
INFO - 2016-05-22 19:45:11 --> Helper loaded: sesion_helper
INFO - 2016-05-22 19:45:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-22 19:45:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-22 19:45:11 --> Helper loaded: redondear_helper
INFO - 2016-05-22 19:45:11 --> Helper loaded: form_helper
INFO - 2016-05-22 19:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-22 19:45:11 --> Form Validation Class Initialized
INFO - 2016-05-22 19:45:11 --> Controller Class Initialized
INFO - 2016-05-22 19:45:11 --> Model Class Initialized
INFO - 2016-05-22 19:45:11 --> Database Driver Class Initialized
INFO - 2016-05-22 19:45:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-22 19:45:11 --> Pagination Class Initialized
DEBUG - 2016-05-22 19:45:11 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-22 19:45:11 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_index.php
INFO - 2016-05-22 19:45:11 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_template2.php
INFO - 2016-05-22 19:45:11 --> Final output sent to browser
DEBUG - 2016-05-22 19:45:11 --> Total execution time: 0.0567
