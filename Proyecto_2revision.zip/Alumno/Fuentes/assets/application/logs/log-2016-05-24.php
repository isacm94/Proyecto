<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-24 08:02:17 --> Config Class Initialized
INFO - 2016-05-24 08:02:17 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:02:17 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:02:17 --> Utf8 Class Initialized
INFO - 2016-05-24 08:02:17 --> URI Class Initialized
DEBUG - 2016-05-24 08:02:17 --> No URI present. Default controller set.
INFO - 2016-05-24 08:02:17 --> Router Class Initialized
INFO - 2016-05-24 08:02:17 --> Output Class Initialized
INFO - 2016-05-24 08:02:17 --> Security Class Initialized
DEBUG - 2016-05-24 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:02:17 --> Input Class Initialized
INFO - 2016-05-24 08:02:17 --> Language Class Initialized
INFO - 2016-05-24 08:02:17 --> Loader Class Initialized
INFO - 2016-05-24 08:02:17 --> Helper loaded: url_helper
INFO - 2016-05-24 08:02:17 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:02:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:02:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:02:17 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:02:17 --> Helper loaded: form_helper
INFO - 2016-05-24 08:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:02:17 --> Form Validation Class Initialized
INFO - 2016-05-24 08:02:17 --> Controller Class Initialized
INFO - 2016-05-24 08:02:17 --> Model Class Initialized
INFO - 2016-05-24 08:02:17 --> Database Driver Class Initialized
ERROR - 2016-05-24 08:02:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '2daw1516_isabel'@'localhost' (using password: YES) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2016-05-24 08:02:17 --> Unable to connect to the database
INFO - 2016-05-24 08:02:17 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-24 08:02:37 --> Config Class Initialized
INFO - 2016-05-24 08:02:37 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:02:37 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:02:37 --> Utf8 Class Initialized
INFO - 2016-05-24 08:02:37 --> URI Class Initialized
DEBUG - 2016-05-24 08:02:37 --> No URI present. Default controller set.
INFO - 2016-05-24 08:02:37 --> Router Class Initialized
INFO - 2016-05-24 08:02:37 --> Output Class Initialized
INFO - 2016-05-24 08:02:37 --> Security Class Initialized
DEBUG - 2016-05-24 08:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:02:37 --> Input Class Initialized
INFO - 2016-05-24 08:02:37 --> Language Class Initialized
INFO - 2016-05-24 08:02:37 --> Loader Class Initialized
INFO - 2016-05-24 08:02:37 --> Helper loaded: url_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: form_helper
INFO - 2016-05-24 08:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:02:37 --> Form Validation Class Initialized
INFO - 2016-05-24 08:02:37 --> Controller Class Initialized
INFO - 2016-05-24 08:02:37 --> Model Class Initialized
INFO - 2016-05-24 08:02:37 --> Database Driver Class Initialized
INFO - 2016-05-24 08:02:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:02:37 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:02:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:02:37 --> Config Class Initialized
INFO - 2016-05-24 08:02:37 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:02:37 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:02:37 --> Utf8 Class Initialized
INFO - 2016-05-24 08:02:37 --> URI Class Initialized
INFO - 2016-05-24 08:02:37 --> Router Class Initialized
INFO - 2016-05-24 08:02:37 --> Output Class Initialized
INFO - 2016-05-24 08:02:37 --> Security Class Initialized
DEBUG - 2016-05-24 08:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:02:37 --> Input Class Initialized
INFO - 2016-05-24 08:02:37 --> Language Class Initialized
INFO - 2016-05-24 08:02:37 --> Loader Class Initialized
INFO - 2016-05-24 08:02:37 --> Helper loaded: url_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: form_helper
INFO - 2016-05-24 08:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:02:37 --> Form Validation Class Initialized
INFO - 2016-05-24 08:02:37 --> Controller Class Initialized
INFO - 2016-05-24 08:02:37 --> Model Class Initialized
INFO - 2016-05-24 08:02:37 --> Database Driver Class Initialized
INFO - 2016-05-24 08:02:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-24 08:02:37 --> Final output sent to browser
DEBUG - 2016-05-24 08:02:37 --> Total execution time: 0.0983
INFO - 2016-05-24 08:02:46 --> Config Class Initialized
INFO - 2016-05-24 08:02:46 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:02:46 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:02:46 --> Utf8 Class Initialized
INFO - 2016-05-24 08:02:46 --> URI Class Initialized
INFO - 2016-05-24 08:02:46 --> Router Class Initialized
INFO - 2016-05-24 08:02:46 --> Output Class Initialized
INFO - 2016-05-24 08:02:46 --> Security Class Initialized
DEBUG - 2016-05-24 08:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:02:46 --> Input Class Initialized
INFO - 2016-05-24 08:02:46 --> Language Class Initialized
INFO - 2016-05-24 08:02:46 --> Loader Class Initialized
INFO - 2016-05-24 08:02:46 --> Helper loaded: url_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: form_helper
INFO - 2016-05-24 08:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:02:46 --> Form Validation Class Initialized
INFO - 2016-05-24 08:02:46 --> Controller Class Initialized
INFO - 2016-05-24 08:02:46 --> Model Class Initialized
INFO - 2016-05-24 08:02:46 --> Database Driver Class Initialized
INFO - 2016-05-24 08:02:46 --> Config Class Initialized
INFO - 2016-05-24 08:02:46 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:02:46 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:02:46 --> Utf8 Class Initialized
INFO - 2016-05-24 08:02:46 --> URI Class Initialized
DEBUG - 2016-05-24 08:02:46 --> No URI present. Default controller set.
INFO - 2016-05-24 08:02:46 --> Router Class Initialized
INFO - 2016-05-24 08:02:46 --> Output Class Initialized
INFO - 2016-05-24 08:02:46 --> Security Class Initialized
DEBUG - 2016-05-24 08:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:02:46 --> Input Class Initialized
INFO - 2016-05-24 08:02:46 --> Language Class Initialized
INFO - 2016-05-24 08:02:46 --> Loader Class Initialized
INFO - 2016-05-24 08:02:46 --> Helper loaded: url_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: form_helper
INFO - 2016-05-24 08:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:02:46 --> Form Validation Class Initialized
INFO - 2016-05-24 08:02:46 --> Controller Class Initialized
INFO - 2016-05-24 08:02:46 --> Model Class Initialized
INFO - 2016-05-24 08:02:46 --> Database Driver Class Initialized
INFO - 2016-05-24 08:02:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:02:46 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:02:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:02:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-24 08:02:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template2.php
INFO - 2016-05-24 08:02:47 --> Final output sent to browser
DEBUG - 2016-05-24 08:02:47 --> Total execution time: 0.2074
INFO - 2016-05-24 08:02:51 --> Config Class Initialized
INFO - 2016-05-24 08:02:51 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:02:51 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:02:51 --> Utf8 Class Initialized
INFO - 2016-05-24 08:02:51 --> URI Class Initialized
INFO - 2016-05-24 08:02:51 --> Router Class Initialized
INFO - 2016-05-24 08:02:51 --> Output Class Initialized
INFO - 2016-05-24 08:02:51 --> Security Class Initialized
DEBUG - 2016-05-24 08:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:02:51 --> Input Class Initialized
INFO - 2016-05-24 08:02:51 --> Language Class Initialized
INFO - 2016-05-24 08:02:51 --> Loader Class Initialized
INFO - 2016-05-24 08:02:51 --> Helper loaded: url_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: form_helper
INFO - 2016-05-24 08:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:02:51 --> Form Validation Class Initialized
INFO - 2016-05-24 08:02:51 --> Controller Class Initialized
INFO - 2016-05-24 08:02:51 --> Config Class Initialized
INFO - 2016-05-24 08:02:51 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:02:51 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:02:51 --> Utf8 Class Initialized
INFO - 2016-05-24 08:02:51 --> URI Class Initialized
INFO - 2016-05-24 08:02:51 --> Router Class Initialized
INFO - 2016-05-24 08:02:51 --> Output Class Initialized
INFO - 2016-05-24 08:02:51 --> Security Class Initialized
DEBUG - 2016-05-24 08:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:02:51 --> Input Class Initialized
INFO - 2016-05-24 08:02:51 --> Language Class Initialized
INFO - 2016-05-24 08:02:51 --> Loader Class Initialized
INFO - 2016-05-24 08:02:51 --> Helper loaded: url_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: form_helper
INFO - 2016-05-24 08:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:02:51 --> Form Validation Class Initialized
INFO - 2016-05-24 08:02:51 --> Controller Class Initialized
INFO - 2016-05-24 08:02:51 --> Model Class Initialized
INFO - 2016-05-24 08:02:51 --> Database Driver Class Initialized
INFO - 2016-05-24 08:02:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-24 08:02:51 --> Final output sent to browser
DEBUG - 2016-05-24 08:02:51 --> Total execution time: 0.0968
INFO - 2016-05-24 08:03:07 --> Config Class Initialized
INFO - 2016-05-24 08:03:07 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:07 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:07 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:07 --> URI Class Initialized
INFO - 2016-05-24 08:03:07 --> Router Class Initialized
INFO - 2016-05-24 08:03:07 --> Output Class Initialized
INFO - 2016-05-24 08:03:07 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:07 --> Input Class Initialized
INFO - 2016-05-24 08:03:07 --> Language Class Initialized
INFO - 2016-05-24 08:03:07 --> Loader Class Initialized
INFO - 2016-05-24 08:03:07 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:07 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:07 --> Controller Class Initialized
INFO - 2016-05-24 08:03:07 --> Model Class Initialized
INFO - 2016-05-24 08:03:07 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:07 --> Config Class Initialized
INFO - 2016-05-24 08:03:07 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:07 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:07 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:07 --> URI Class Initialized
INFO - 2016-05-24 08:03:07 --> Router Class Initialized
INFO - 2016-05-24 08:03:07 --> Output Class Initialized
INFO - 2016-05-24 08:03:07 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:07 --> Input Class Initialized
INFO - 2016-05-24 08:03:07 --> Language Class Initialized
INFO - 2016-05-24 08:03:07 --> Loader Class Initialized
INFO - 2016-05-24 08:03:07 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:07 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:07 --> Controller Class Initialized
INFO - 2016-05-24 08:03:07 --> Model Class Initialized
INFO - 2016-05-24 08:03:07 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:07 --> Config Class Initialized
INFO - 2016-05-24 08:03:07 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:07 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:07 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:07 --> URI Class Initialized
INFO - 2016-05-24 08:03:07 --> Router Class Initialized
INFO - 2016-05-24 08:03:07 --> Output Class Initialized
INFO - 2016-05-24 08:03:07 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:07 --> Input Class Initialized
INFO - 2016-05-24 08:03:07 --> Language Class Initialized
INFO - 2016-05-24 08:03:07 --> Loader Class Initialized
INFO - 2016-05-24 08:03:07 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:07 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:07 --> Controller Class Initialized
INFO - 2016-05-24 08:03:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-24 08:03:07 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:07 --> Total execution time: 0.0805
INFO - 2016-05-24 08:03:09 --> Config Class Initialized
INFO - 2016-05-24 08:03:09 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:09 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:09 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:09 --> URI Class Initialized
INFO - 2016-05-24 08:03:09 --> Router Class Initialized
INFO - 2016-05-24 08:03:09 --> Output Class Initialized
INFO - 2016-05-24 08:03:09 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:09 --> Input Class Initialized
INFO - 2016-05-24 08:03:09 --> Language Class Initialized
INFO - 2016-05-24 08:03:09 --> Loader Class Initialized
INFO - 2016-05-24 08:03:09 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:09 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:09 --> Controller Class Initialized
INFO - 2016-05-24 08:03:09 --> Model Class Initialized
INFO - 2016-05-24 08:03:09 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:09 --> Config Class Initialized
INFO - 2016-05-24 08:03:09 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:09 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:09 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:09 --> URI Class Initialized
INFO - 2016-05-24 08:03:09 --> Router Class Initialized
INFO - 2016-05-24 08:03:09 --> Output Class Initialized
INFO - 2016-05-24 08:03:09 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:09 --> Input Class Initialized
INFO - 2016-05-24 08:03:09 --> Language Class Initialized
INFO - 2016-05-24 08:03:09 --> Loader Class Initialized
INFO - 2016-05-24 08:03:09 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:09 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:09 --> Controller Class Initialized
INFO - 2016-05-24 08:03:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-24 08:03:09 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:09 --> Total execution time: 0.0687
INFO - 2016-05-24 08:03:14 --> Config Class Initialized
INFO - 2016-05-24 08:03:14 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:14 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:14 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:14 --> URI Class Initialized
INFO - 2016-05-24 08:03:14 --> Router Class Initialized
INFO - 2016-05-24 08:03:14 --> Output Class Initialized
INFO - 2016-05-24 08:03:14 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:14 --> Input Class Initialized
INFO - 2016-05-24 08:03:14 --> Language Class Initialized
INFO - 2016-05-24 08:03:14 --> Loader Class Initialized
INFO - 2016-05-24 08:03:14 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:14 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:14 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:14 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:14 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:14 --> Controller Class Initialized
INFO - 2016-05-24 08:03:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-24 08:03:14 --> Model Class Initialized
INFO - 2016-05-24 08:03:14 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 08:03:14 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:14 --> Total execution time: 0.0972
INFO - 2016-05-24 08:03:15 --> Config Class Initialized
INFO - 2016-05-24 08:03:15 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:15 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:15 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:15 --> URI Class Initialized
INFO - 2016-05-24 08:03:15 --> Router Class Initialized
INFO - 2016-05-24 08:03:15 --> Output Class Initialized
INFO - 2016-05-24 08:03:15 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:15 --> Input Class Initialized
INFO - 2016-05-24 08:03:15 --> Language Class Initialized
INFO - 2016-05-24 08:03:15 --> Loader Class Initialized
INFO - 2016-05-24 08:03:15 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:15 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:15 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:15 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:15 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:15 --> Controller Class Initialized
INFO - 2016-05-24 08:03:15 --> Model Class Initialized
INFO - 2016-05-24 08:03:15 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:03:15 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:03:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:03:15 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:15 --> Total execution time: 0.1097
INFO - 2016-05-24 08:03:27 --> Config Class Initialized
INFO - 2016-05-24 08:03:27 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:27 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:27 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:27 --> URI Class Initialized
INFO - 2016-05-24 08:03:27 --> Router Class Initialized
INFO - 2016-05-24 08:03:27 --> Output Class Initialized
INFO - 2016-05-24 08:03:27 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:27 --> Input Class Initialized
INFO - 2016-05-24 08:03:27 --> Language Class Initialized
INFO - 2016-05-24 08:03:27 --> Loader Class Initialized
INFO - 2016-05-24 08:03:27 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:27 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:27 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:27 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:27 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:27 --> Controller Class Initialized
DEBUG - 2016-05-24 08:03:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:03:27 --> Model Class Initialized
INFO - 2016-05-24 08:03:27 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-24 08:03:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 08:03:27 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:27 --> Total execution time: 0.0954
INFO - 2016-05-24 08:03:27 --> Config Class Initialized
INFO - 2016-05-24 08:03:27 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:27 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:27 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:27 --> URI Class Initialized
INFO - 2016-05-24 08:03:27 --> Router Class Initialized
INFO - 2016-05-24 08:03:27 --> Output Class Initialized
INFO - 2016-05-24 08:03:27 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:27 --> Input Class Initialized
INFO - 2016-05-24 08:03:27 --> Language Class Initialized
INFO - 2016-05-24 08:03:28 --> Loader Class Initialized
INFO - 2016-05-24 08:03:28 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:28 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:28 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:28 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:28 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:28 --> Controller Class Initialized
INFO - 2016-05-24 08:03:28 --> Model Class Initialized
INFO - 2016-05-24 08:03:28 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:03:28 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:03:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:03:28 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:28 --> Total execution time: 0.1303
INFO - 2016-05-24 08:03:32 --> Config Class Initialized
INFO - 2016-05-24 08:03:32 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:32 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:32 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:32 --> URI Class Initialized
INFO - 2016-05-24 08:03:32 --> Router Class Initialized
INFO - 2016-05-24 08:03:32 --> Output Class Initialized
INFO - 2016-05-24 08:03:32 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:32 --> Input Class Initialized
INFO - 2016-05-24 08:03:32 --> Language Class Initialized
INFO - 2016-05-24 08:03:32 --> Loader Class Initialized
INFO - 2016-05-24 08:03:32 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:32 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:32 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:32 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:32 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:32 --> Controller Class Initialized
DEBUG - 2016-05-24 08:03:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:03:32 --> Model Class Initialized
INFO - 2016-05-24 08:03:32 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:32 --> Config Class Initialized
INFO - 2016-05-24 08:03:32 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:32 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:32 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:32 --> URI Class Initialized
INFO - 2016-05-24 08:03:32 --> Router Class Initialized
INFO - 2016-05-24 08:03:32 --> Output Class Initialized
INFO - 2016-05-24 08:03:32 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:32 --> Input Class Initialized
INFO - 2016-05-24 08:03:32 --> Language Class Initialized
INFO - 2016-05-24 08:03:33 --> Loader Class Initialized
INFO - 2016-05-24 08:03:33 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:33 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:33 --> Controller Class Initialized
DEBUG - 2016-05-24 08:03:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:03:33 --> Model Class Initialized
INFO - 2016-05-24 08:03:33 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-24 08:03:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-24 08:03:33 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:33 --> Total execution time: 0.0872
INFO - 2016-05-24 08:03:33 --> Config Class Initialized
INFO - 2016-05-24 08:03:33 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:33 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:33 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:33 --> URI Class Initialized
INFO - 2016-05-24 08:03:33 --> Router Class Initialized
INFO - 2016-05-24 08:03:33 --> Output Class Initialized
INFO - 2016-05-24 08:03:33 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:33 --> Input Class Initialized
INFO - 2016-05-24 08:03:33 --> Language Class Initialized
INFO - 2016-05-24 08:03:33 --> Loader Class Initialized
INFO - 2016-05-24 08:03:33 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:33 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:33 --> Controller Class Initialized
INFO - 2016-05-24 08:03:33 --> Model Class Initialized
INFO - 2016-05-24 08:03:33 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:03:33 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:03:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:03:33 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:33 --> Total execution time: 0.1227
INFO - 2016-05-24 08:03:40 --> Config Class Initialized
INFO - 2016-05-24 08:03:40 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:40 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:40 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:40 --> URI Class Initialized
INFO - 2016-05-24 08:03:40 --> Router Class Initialized
INFO - 2016-05-24 08:03:40 --> Output Class Initialized
INFO - 2016-05-24 08:03:40 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:40 --> Input Class Initialized
INFO - 2016-05-24 08:03:40 --> Language Class Initialized
INFO - 2016-05-24 08:03:40 --> Loader Class Initialized
INFO - 2016-05-24 08:03:40 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:40 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:40 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:40 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:40 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:40 --> Controller Class Initialized
DEBUG - 2016-05-24 08:03:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:03:40 --> Model Class Initialized
INFO - 2016-05-24 08:03:40 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:40 --> Config Class Initialized
INFO - 2016-05-24 08:03:40 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:40 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:40 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:40 --> URI Class Initialized
INFO - 2016-05-24 08:03:40 --> Router Class Initialized
INFO - 2016-05-24 08:03:40 --> Output Class Initialized
INFO - 2016-05-24 08:03:40 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:40 --> Input Class Initialized
INFO - 2016-05-24 08:03:40 --> Language Class Initialized
INFO - 2016-05-24 08:03:41 --> Loader Class Initialized
INFO - 2016-05-24 08:03:41 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:41 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:41 --> Controller Class Initialized
DEBUG - 2016-05-24 08:03:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:03:41 --> Model Class Initialized
INFO - 2016-05-24 08:03:41 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-24 08:03:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 08:03:41 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:41 --> Total execution time: 0.0924
INFO - 2016-05-24 08:03:41 --> Config Class Initialized
INFO - 2016-05-24 08:03:41 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:41 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:41 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:41 --> URI Class Initialized
INFO - 2016-05-24 08:03:41 --> Router Class Initialized
INFO - 2016-05-24 08:03:41 --> Output Class Initialized
INFO - 2016-05-24 08:03:41 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:41 --> Input Class Initialized
INFO - 2016-05-24 08:03:41 --> Language Class Initialized
INFO - 2016-05-24 08:03:41 --> Loader Class Initialized
INFO - 2016-05-24 08:03:41 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:41 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:41 --> Controller Class Initialized
INFO - 2016-05-24 08:03:41 --> Model Class Initialized
INFO - 2016-05-24 08:03:41 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:03:41 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:03:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:03:41 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:41 --> Total execution time: 0.1239
INFO - 2016-05-24 08:03:44 --> Config Class Initialized
INFO - 2016-05-24 08:03:44 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:44 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:44 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:44 --> URI Class Initialized
INFO - 2016-05-24 08:03:44 --> Router Class Initialized
INFO - 2016-05-24 08:03:44 --> Output Class Initialized
INFO - 2016-05-24 08:03:44 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:44 --> Input Class Initialized
INFO - 2016-05-24 08:03:44 --> Language Class Initialized
INFO - 2016-05-24 08:03:44 --> Loader Class Initialized
INFO - 2016-05-24 08:03:44 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:44 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:44 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:44 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:45 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:45 --> Controller Class Initialized
DEBUG - 2016-05-24 08:03:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:03:45 --> Model Class Initialized
INFO - 2016-05-24 08:03:45 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:45 --> Config Class Initialized
INFO - 2016-05-24 08:03:45 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:45 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:45 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:45 --> URI Class Initialized
INFO - 2016-05-24 08:03:45 --> Router Class Initialized
INFO - 2016-05-24 08:03:45 --> Output Class Initialized
INFO - 2016-05-24 08:03:45 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:45 --> Input Class Initialized
INFO - 2016-05-24 08:03:45 --> Language Class Initialized
INFO - 2016-05-24 08:03:45 --> Loader Class Initialized
INFO - 2016-05-24 08:03:45 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:45 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:45 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:45 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:45 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:45 --> Controller Class Initialized
DEBUG - 2016-05-24 08:03:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:03:45 --> Model Class Initialized
INFO - 2016-05-24 08:03:45 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-24 08:03:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 08:03:45 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:45 --> Total execution time: 0.1193
INFO - 2016-05-24 08:03:46 --> Config Class Initialized
INFO - 2016-05-24 08:03:46 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:46 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:46 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:46 --> URI Class Initialized
DEBUG - 2016-05-24 08:03:46 --> No URI present. Default controller set.
INFO - 2016-05-24 08:03:46 --> Router Class Initialized
INFO - 2016-05-24 08:03:46 --> Output Class Initialized
INFO - 2016-05-24 08:03:46 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:46 --> Input Class Initialized
INFO - 2016-05-24 08:03:46 --> Language Class Initialized
INFO - 2016-05-24 08:03:46 --> Loader Class Initialized
INFO - 2016-05-24 08:03:46 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:46 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:46 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:46 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:46 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:46 --> Controller Class Initialized
INFO - 2016-05-24 08:03:46 --> Model Class Initialized
INFO - 2016-05-24 08:03:46 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:03:46 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:03:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:03:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-24 08:03:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-24 08:03:46 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:46 --> Total execution time: 0.1274
INFO - 2016-05-24 08:03:48 --> Config Class Initialized
INFO - 2016-05-24 08:03:48 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:48 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:48 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:48 --> URI Class Initialized
INFO - 2016-05-24 08:03:48 --> Router Class Initialized
INFO - 2016-05-24 08:03:48 --> Output Class Initialized
INFO - 2016-05-24 08:03:48 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:48 --> Input Class Initialized
INFO - 2016-05-24 08:03:48 --> Language Class Initialized
INFO - 2016-05-24 08:03:48 --> Loader Class Initialized
INFO - 2016-05-24 08:03:48 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:48 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:48 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:48 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:49 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:49 --> Controller Class Initialized
INFO - 2016-05-24 08:03:49 --> Model Class Initialized
INFO - 2016-05-24 08:03:49 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:03:49 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:03:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:03:49 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:49 --> Total execution time: 0.1398
INFO - 2016-05-24 08:04:11 --> Config Class Initialized
INFO - 2016-05-24 08:04:11 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:04:11 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:04:11 --> Utf8 Class Initialized
INFO - 2016-05-24 08:04:11 --> URI Class Initialized
INFO - 2016-05-24 08:04:11 --> Router Class Initialized
INFO - 2016-05-24 08:04:11 --> Output Class Initialized
INFO - 2016-05-24 08:04:11 --> Security Class Initialized
DEBUG - 2016-05-24 08:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:04:11 --> Input Class Initialized
INFO - 2016-05-24 08:04:11 --> Language Class Initialized
INFO - 2016-05-24 08:04:11 --> Loader Class Initialized
INFO - 2016-05-24 08:04:11 --> Helper loaded: url_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: form_helper
INFO - 2016-05-24 08:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:04:11 --> Form Validation Class Initialized
INFO - 2016-05-24 08:04:11 --> Controller Class Initialized
INFO - 2016-05-24 08:04:11 --> Model Class Initialized
INFO - 2016-05-24 08:04:11 --> Database Driver Class Initialized
INFO - 2016-05-24 08:04:11 --> Config Class Initialized
INFO - 2016-05-24 08:04:11 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:04:11 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:04:11 --> Utf8 Class Initialized
INFO - 2016-05-24 08:04:11 --> URI Class Initialized
INFO - 2016-05-24 08:04:11 --> Router Class Initialized
INFO - 2016-05-24 08:04:11 --> Output Class Initialized
INFO - 2016-05-24 08:04:11 --> Security Class Initialized
DEBUG - 2016-05-24 08:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:04:11 --> Input Class Initialized
INFO - 2016-05-24 08:04:11 --> Language Class Initialized
INFO - 2016-05-24 08:04:11 --> Loader Class Initialized
INFO - 2016-05-24 08:04:11 --> Helper loaded: url_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: form_helper
INFO - 2016-05-24 08:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:04:11 --> Form Validation Class Initialized
INFO - 2016-05-24 08:04:11 --> Controller Class Initialized
INFO - 2016-05-24 08:04:11 --> Model Class Initialized
INFO - 2016-05-24 08:04:11 --> Database Driver Class Initialized
INFO - 2016-05-24 08:04:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-24 08:04:11 --> Final output sent to browser
DEBUG - 2016-05-24 08:04:11 --> Total execution time: 0.1492
INFO - 2016-05-24 08:04:14 --> Config Class Initialized
INFO - 2016-05-24 08:04:14 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:04:14 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:04:14 --> Utf8 Class Initialized
INFO - 2016-05-24 08:04:14 --> URI Class Initialized
INFO - 2016-05-24 08:04:14 --> Router Class Initialized
INFO - 2016-05-24 08:04:14 --> Output Class Initialized
INFO - 2016-05-24 08:04:14 --> Security Class Initialized
DEBUG - 2016-05-24 08:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:04:14 --> Input Class Initialized
INFO - 2016-05-24 08:04:14 --> Language Class Initialized
INFO - 2016-05-24 08:04:14 --> Loader Class Initialized
INFO - 2016-05-24 08:04:14 --> Helper loaded: url_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: form_helper
INFO - 2016-05-24 08:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:04:14 --> Form Validation Class Initialized
INFO - 2016-05-24 08:04:14 --> Controller Class Initialized
INFO - 2016-05-24 08:04:14 --> Model Class Initialized
INFO - 2016-05-24 08:04:14 --> Database Driver Class Initialized
INFO - 2016-05-24 08:04:14 --> Config Class Initialized
INFO - 2016-05-24 08:04:14 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:04:14 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:04:14 --> Utf8 Class Initialized
INFO - 2016-05-24 08:04:14 --> URI Class Initialized
INFO - 2016-05-24 08:04:14 --> Router Class Initialized
INFO - 2016-05-24 08:04:14 --> Output Class Initialized
INFO - 2016-05-24 08:04:14 --> Security Class Initialized
DEBUG - 2016-05-24 08:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:04:14 --> Input Class Initialized
INFO - 2016-05-24 08:04:14 --> Language Class Initialized
INFO - 2016-05-24 08:04:14 --> Loader Class Initialized
INFO - 2016-05-24 08:04:14 --> Helper loaded: url_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: form_helper
INFO - 2016-05-24 08:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:04:14 --> Form Validation Class Initialized
INFO - 2016-05-24 08:04:14 --> Controller Class Initialized
INFO - 2016-05-24 08:04:14 --> Model Class Initialized
INFO - 2016-05-24 08:04:14 --> Database Driver Class Initialized
INFO - 2016-05-24 08:04:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-24 08:04:14 --> Final output sent to browser
DEBUG - 2016-05-24 08:04:14 --> Total execution time: 0.0947
INFO - 2016-05-24 08:04:19 --> Config Class Initialized
INFO - 2016-05-24 08:04:19 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:04:19 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:04:19 --> Utf8 Class Initialized
INFO - 2016-05-24 08:04:19 --> URI Class Initialized
INFO - 2016-05-24 08:04:19 --> Router Class Initialized
INFO - 2016-05-24 08:04:19 --> Output Class Initialized
INFO - 2016-05-24 08:04:19 --> Security Class Initialized
DEBUG - 2016-05-24 08:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:04:19 --> Input Class Initialized
INFO - 2016-05-24 08:04:19 --> Language Class Initialized
INFO - 2016-05-24 08:04:19 --> Loader Class Initialized
INFO - 2016-05-24 08:04:19 --> Helper loaded: url_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: form_helper
INFO - 2016-05-24 08:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:04:19 --> Form Validation Class Initialized
INFO - 2016-05-24 08:04:19 --> Controller Class Initialized
INFO - 2016-05-24 08:04:19 --> Model Class Initialized
INFO - 2016-05-24 08:04:19 --> Database Driver Class Initialized
INFO - 2016-05-24 08:04:19 --> Config Class Initialized
INFO - 2016-05-24 08:04:19 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:04:19 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:04:19 --> Utf8 Class Initialized
INFO - 2016-05-24 08:04:19 --> URI Class Initialized
INFO - 2016-05-24 08:04:19 --> Router Class Initialized
INFO - 2016-05-24 08:04:19 --> Output Class Initialized
INFO - 2016-05-24 08:04:19 --> Security Class Initialized
DEBUG - 2016-05-24 08:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:04:19 --> Input Class Initialized
INFO - 2016-05-24 08:04:19 --> Language Class Initialized
INFO - 2016-05-24 08:04:19 --> Loader Class Initialized
INFO - 2016-05-24 08:04:19 --> Helper loaded: url_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: form_helper
INFO - 2016-05-24 08:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:04:19 --> Form Validation Class Initialized
INFO - 2016-05-24 08:04:19 --> Controller Class Initialized
DEBUG - 2016-05-24 08:04:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:04:19 --> Model Class Initialized
INFO - 2016-05-24 08:04:19 --> Database Driver Class Initialized
INFO - 2016-05-24 08:04:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-24 08:04:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 08:04:19 --> Final output sent to browser
DEBUG - 2016-05-24 08:04:19 --> Total execution time: 0.1710
INFO - 2016-05-24 08:04:20 --> Config Class Initialized
INFO - 2016-05-24 08:04:20 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:04:20 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:04:20 --> Utf8 Class Initialized
INFO - 2016-05-24 08:04:20 --> URI Class Initialized
INFO - 2016-05-24 08:04:20 --> Router Class Initialized
INFO - 2016-05-24 08:04:20 --> Output Class Initialized
INFO - 2016-05-24 08:04:20 --> Security Class Initialized
DEBUG - 2016-05-24 08:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:04:20 --> Input Class Initialized
INFO - 2016-05-24 08:04:20 --> Language Class Initialized
INFO - 2016-05-24 08:04:20 --> Loader Class Initialized
INFO - 2016-05-24 08:04:20 --> Helper loaded: url_helper
INFO - 2016-05-24 08:04:20 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:04:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:04:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:04:20 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:04:20 --> Helper loaded: form_helper
INFO - 2016-05-24 08:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:04:20 --> Form Validation Class Initialized
INFO - 2016-05-24 08:04:20 --> Controller Class Initialized
INFO - 2016-05-24 08:04:20 --> Model Class Initialized
INFO - 2016-05-24 08:04:20 --> Database Driver Class Initialized
INFO - 2016-05-24 08:04:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:04:20 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:04:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:04:20 --> Final output sent to browser
DEBUG - 2016-05-24 08:04:20 --> Total execution time: 0.1129
INFO - 2016-05-24 18:32:00 --> Config Class Initialized
INFO - 2016-05-24 18:32:00 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:32:00 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:32:00 --> Utf8 Class Initialized
INFO - 2016-05-24 18:32:00 --> URI Class Initialized
DEBUG - 2016-05-24 18:32:00 --> No URI present. Default controller set.
INFO - 2016-05-24 18:32:00 --> Router Class Initialized
INFO - 2016-05-24 18:32:00 --> Output Class Initialized
INFO - 2016-05-24 18:32:00 --> Security Class Initialized
DEBUG - 2016-05-24 18:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:32:00 --> Input Class Initialized
INFO - 2016-05-24 18:32:00 --> Language Class Initialized
INFO - 2016-05-24 18:32:00 --> Loader Class Initialized
INFO - 2016-05-24 18:32:00 --> Helper loaded: url_helper
INFO - 2016-05-24 18:32:00 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:32:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:32:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:32:00 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:32:00 --> Helper loaded: form_helper
INFO - 2016-05-24 18:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:32:00 --> Form Validation Class Initialized
INFO - 2016-05-24 18:32:00 --> Controller Class Initialized
INFO - 2016-05-24 18:32:00 --> Model Class Initialized
INFO - 2016-05-24 18:32:00 --> Database Driver Class Initialized
INFO - 2016-05-24 18:32:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 18:32:01 --> Pagination Class Initialized
DEBUG - 2016-05-24 18:32:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 18:32:01 --> Config Class Initialized
INFO - 2016-05-24 18:32:01 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:32:01 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:32:01 --> Utf8 Class Initialized
INFO - 2016-05-24 18:32:01 --> URI Class Initialized
INFO - 2016-05-24 18:32:01 --> Router Class Initialized
INFO - 2016-05-24 18:32:01 --> Output Class Initialized
INFO - 2016-05-24 18:32:01 --> Security Class Initialized
DEBUG - 2016-05-24 18:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:32:01 --> Input Class Initialized
INFO - 2016-05-24 18:32:01 --> Language Class Initialized
INFO - 2016-05-24 18:32:01 --> Loader Class Initialized
INFO - 2016-05-24 18:32:01 --> Helper loaded: url_helper
INFO - 2016-05-24 18:32:01 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:32:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:32:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:32:01 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:32:01 --> Helper loaded: form_helper
INFO - 2016-05-24 18:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:32:01 --> Form Validation Class Initialized
INFO - 2016-05-24 18:32:01 --> Controller Class Initialized
INFO - 2016-05-24 18:32:01 --> Model Class Initialized
INFO - 2016-05-24 18:32:01 --> Database Driver Class Initialized
INFO - 2016-05-24 18:32:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-24 18:32:01 --> Final output sent to browser
DEBUG - 2016-05-24 18:32:01 --> Total execution time: 0.1253
INFO - 2016-05-24 18:32:05 --> Config Class Initialized
INFO - 2016-05-24 18:32:05 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:32:05 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:32:05 --> Utf8 Class Initialized
INFO - 2016-05-24 18:32:05 --> URI Class Initialized
INFO - 2016-05-24 18:32:05 --> Router Class Initialized
INFO - 2016-05-24 18:32:05 --> Output Class Initialized
INFO - 2016-05-24 18:32:05 --> Security Class Initialized
DEBUG - 2016-05-24 18:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:32:05 --> Input Class Initialized
INFO - 2016-05-24 18:32:05 --> Language Class Initialized
INFO - 2016-05-24 18:32:05 --> Loader Class Initialized
INFO - 2016-05-24 18:32:05 --> Helper loaded: url_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: form_helper
INFO - 2016-05-24 18:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:32:05 --> Form Validation Class Initialized
INFO - 2016-05-24 18:32:05 --> Controller Class Initialized
INFO - 2016-05-24 18:32:05 --> Config Class Initialized
INFO - 2016-05-24 18:32:05 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:32:05 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:32:05 --> Utf8 Class Initialized
INFO - 2016-05-24 18:32:05 --> URI Class Initialized
INFO - 2016-05-24 18:32:05 --> Router Class Initialized
INFO - 2016-05-24 18:32:05 --> Output Class Initialized
INFO - 2016-05-24 18:32:05 --> Security Class Initialized
DEBUG - 2016-05-24 18:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:32:05 --> Input Class Initialized
INFO - 2016-05-24 18:32:05 --> Language Class Initialized
INFO - 2016-05-24 18:32:05 --> Loader Class Initialized
INFO - 2016-05-24 18:32:05 --> Helper loaded: url_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: form_helper
INFO - 2016-05-24 18:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:32:05 --> Form Validation Class Initialized
INFO - 2016-05-24 18:32:05 --> Controller Class Initialized
INFO - 2016-05-24 18:32:05 --> Model Class Initialized
INFO - 2016-05-24 18:32:06 --> Database Driver Class Initialized
INFO - 2016-05-24 18:32:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-24 18:32:06 --> Final output sent to browser
DEBUG - 2016-05-24 18:32:06 --> Total execution time: 0.0744
INFO - 2016-05-24 18:32:12 --> Config Class Initialized
INFO - 2016-05-24 18:32:12 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:32:12 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:32:12 --> Utf8 Class Initialized
INFO - 2016-05-24 18:32:12 --> URI Class Initialized
INFO - 2016-05-24 18:32:12 --> Router Class Initialized
INFO - 2016-05-24 18:32:12 --> Output Class Initialized
INFO - 2016-05-24 18:32:12 --> Security Class Initialized
DEBUG - 2016-05-24 18:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:32:12 --> Input Class Initialized
INFO - 2016-05-24 18:32:12 --> Language Class Initialized
INFO - 2016-05-24 18:32:12 --> Loader Class Initialized
INFO - 2016-05-24 18:32:12 --> Helper loaded: url_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: form_helper
INFO - 2016-05-24 18:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:32:12 --> Form Validation Class Initialized
INFO - 2016-05-24 18:32:12 --> Controller Class Initialized
INFO - 2016-05-24 18:32:12 --> Model Class Initialized
INFO - 2016-05-24 18:32:12 --> Database Driver Class Initialized
INFO - 2016-05-24 18:32:12 --> Config Class Initialized
INFO - 2016-05-24 18:32:12 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:32:12 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:32:12 --> Utf8 Class Initialized
INFO - 2016-05-24 18:32:12 --> URI Class Initialized
INFO - 2016-05-24 18:32:12 --> Router Class Initialized
INFO - 2016-05-24 18:32:12 --> Output Class Initialized
INFO - 2016-05-24 18:32:12 --> Security Class Initialized
DEBUG - 2016-05-24 18:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:32:12 --> Input Class Initialized
INFO - 2016-05-24 18:32:12 --> Language Class Initialized
INFO - 2016-05-24 18:32:12 --> Loader Class Initialized
INFO - 2016-05-24 18:32:12 --> Helper loaded: url_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: form_helper
INFO - 2016-05-24 18:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:32:12 --> Form Validation Class Initialized
INFO - 2016-05-24 18:32:12 --> Controller Class Initialized
INFO - 2016-05-24 18:32:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-24 18:32:12 --> Model Class Initialized
INFO - 2016-05-24 18:32:12 --> Database Driver Class Initialized
INFO - 2016-05-24 18:32:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 18:32:12 --> Final output sent to browser
DEBUG - 2016-05-24 18:32:12 --> Total execution time: 0.0950
INFO - 2016-05-24 18:32:13 --> Config Class Initialized
INFO - 2016-05-24 18:32:13 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:32:13 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:32:13 --> Utf8 Class Initialized
INFO - 2016-05-24 18:32:13 --> URI Class Initialized
INFO - 2016-05-24 18:32:13 --> Router Class Initialized
INFO - 2016-05-24 18:32:13 --> Output Class Initialized
INFO - 2016-05-24 18:32:13 --> Security Class Initialized
DEBUG - 2016-05-24 18:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:32:13 --> Input Class Initialized
INFO - 2016-05-24 18:32:13 --> Language Class Initialized
INFO - 2016-05-24 18:32:13 --> Loader Class Initialized
INFO - 2016-05-24 18:32:13 --> Helper loaded: url_helper
INFO - 2016-05-24 18:32:13 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:32:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:32:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:32:13 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:32:13 --> Helper loaded: form_helper
INFO - 2016-05-24 18:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:32:13 --> Form Validation Class Initialized
INFO - 2016-05-24 18:32:13 --> Controller Class Initialized
INFO - 2016-05-24 18:32:13 --> Model Class Initialized
INFO - 2016-05-24 18:32:13 --> Database Driver Class Initialized
INFO - 2016-05-24 18:32:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 18:32:13 --> Pagination Class Initialized
DEBUG - 2016-05-24 18:32:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 18:32:13 --> Final output sent to browser
DEBUG - 2016-05-24 18:32:13 --> Total execution time: 0.1249
INFO - 2016-05-24 18:33:13 --> Config Class Initialized
INFO - 2016-05-24 18:33:13 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:33:13 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:33:13 --> Utf8 Class Initialized
INFO - 2016-05-24 18:33:13 --> URI Class Initialized
INFO - 2016-05-24 18:33:13 --> Router Class Initialized
INFO - 2016-05-24 18:33:13 --> Output Class Initialized
INFO - 2016-05-24 18:33:13 --> Security Class Initialized
DEBUG - 2016-05-24 18:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:33:13 --> Input Class Initialized
INFO - 2016-05-24 18:33:13 --> Language Class Initialized
INFO - 2016-05-24 18:33:13 --> Loader Class Initialized
INFO - 2016-05-24 18:33:13 --> Helper loaded: url_helper
INFO - 2016-05-24 18:33:13 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:33:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:33:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:33:13 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:33:13 --> Helper loaded: form_helper
INFO - 2016-05-24 18:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:33:13 --> Form Validation Class Initialized
INFO - 2016-05-24 18:33:13 --> Controller Class Initialized
INFO - 2016-05-24 18:33:13 --> Model Class Initialized
INFO - 2016-05-24 18:33:13 --> Database Driver Class Initialized
INFO - 2016-05-24 18:33:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 18:33:13 --> Pagination Class Initialized
DEBUG - 2016-05-24 18:33:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 18:33:13 --> Final output sent to browser
DEBUG - 2016-05-24 18:33:13 --> Total execution time: 0.0869
INFO - 2016-05-24 18:34:13 --> Config Class Initialized
INFO - 2016-05-24 18:34:13 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:34:13 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:34:13 --> Utf8 Class Initialized
INFO - 2016-05-24 18:34:13 --> URI Class Initialized
INFO - 2016-05-24 18:34:13 --> Router Class Initialized
INFO - 2016-05-24 18:34:13 --> Output Class Initialized
INFO - 2016-05-24 18:34:13 --> Security Class Initialized
DEBUG - 2016-05-24 18:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:34:13 --> Input Class Initialized
INFO - 2016-05-24 18:34:13 --> Language Class Initialized
INFO - 2016-05-24 18:34:13 --> Loader Class Initialized
INFO - 2016-05-24 18:34:13 --> Helper loaded: url_helper
INFO - 2016-05-24 18:34:13 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:34:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:34:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:34:13 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:34:13 --> Helper loaded: form_helper
INFO - 2016-05-24 18:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:34:13 --> Form Validation Class Initialized
INFO - 2016-05-24 18:34:13 --> Controller Class Initialized
INFO - 2016-05-24 18:34:13 --> Model Class Initialized
INFO - 2016-05-24 18:34:13 --> Database Driver Class Initialized
ERROR - 2016-05-24 18:34:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '2daw1516_isabel'@'localhost' (using password: YES) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2016-05-24 18:34:13 --> Unable to connect to the database
INFO - 2016-05-24 18:34:13 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-24 18:35:13 --> Config Class Initialized
INFO - 2016-05-24 18:35:13 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:35:13 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:35:13 --> Utf8 Class Initialized
INFO - 2016-05-24 18:35:13 --> URI Class Initialized
INFO - 2016-05-24 18:35:13 --> Router Class Initialized
INFO - 2016-05-24 18:35:13 --> Output Class Initialized
INFO - 2016-05-24 18:35:13 --> Security Class Initialized
DEBUG - 2016-05-24 18:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:35:13 --> Input Class Initialized
INFO - 2016-05-24 18:35:13 --> Language Class Initialized
INFO - 2016-05-24 18:35:13 --> Loader Class Initialized
INFO - 2016-05-24 18:35:13 --> Helper loaded: url_helper
INFO - 2016-05-24 18:35:13 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:35:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:35:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:35:13 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:35:13 --> Helper loaded: form_helper
INFO - 2016-05-24 18:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:35:13 --> Form Validation Class Initialized
INFO - 2016-05-24 18:35:13 --> Controller Class Initialized
INFO - 2016-05-24 18:35:13 --> Model Class Initialized
INFO - 2016-05-24 18:35:13 --> Database Driver Class Initialized
ERROR - 2016-05-24 18:35:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '2daw1516_isabel'@'localhost' (using password: YES) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2016-05-24 18:35:13 --> Unable to connect to the database
INFO - 2016-05-24 18:35:13 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-24 18:36:13 --> Config Class Initialized
INFO - 2016-05-24 18:36:13 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:36:13 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:36:13 --> Utf8 Class Initialized
INFO - 2016-05-24 18:36:13 --> URI Class Initialized
INFO - 2016-05-24 18:36:13 --> Router Class Initialized
INFO - 2016-05-24 18:36:13 --> Output Class Initialized
INFO - 2016-05-24 18:36:13 --> Security Class Initialized
DEBUG - 2016-05-24 18:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:36:13 --> Input Class Initialized
INFO - 2016-05-24 18:36:13 --> Language Class Initialized
INFO - 2016-05-24 18:36:13 --> Loader Class Initialized
INFO - 2016-05-24 18:36:13 --> Helper loaded: url_helper
INFO - 2016-05-24 18:36:13 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:36:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:36:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:36:13 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:36:13 --> Helper loaded: form_helper
INFO - 2016-05-24 18:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:36:13 --> Form Validation Class Initialized
INFO - 2016-05-24 18:36:13 --> Controller Class Initialized
INFO - 2016-05-24 18:36:13 --> Model Class Initialized
INFO - 2016-05-24 18:36:13 --> Database Driver Class Initialized
ERROR - 2016-05-24 18:36:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '2daw1516_isabel'@'localhost' (using password: YES) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2016-05-24 18:36:13 --> Unable to connect to the database
INFO - 2016-05-24 18:36:13 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-24 18:37:13 --> Config Class Initialized
INFO - 2016-05-24 18:37:13 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:37:13 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:37:13 --> Utf8 Class Initialized
INFO - 2016-05-24 18:37:13 --> URI Class Initialized
INFO - 2016-05-24 18:37:13 --> Router Class Initialized
INFO - 2016-05-24 18:37:13 --> Output Class Initialized
INFO - 2016-05-24 18:37:13 --> Security Class Initialized
DEBUG - 2016-05-24 18:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:37:13 --> Input Class Initialized
INFO - 2016-05-24 18:37:13 --> Language Class Initialized
INFO - 2016-05-24 18:37:13 --> Loader Class Initialized
INFO - 2016-05-24 18:37:13 --> Helper loaded: url_helper
INFO - 2016-05-24 18:37:13 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:37:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:37:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:37:13 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:37:13 --> Helper loaded: form_helper
INFO - 2016-05-24 18:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:37:13 --> Form Validation Class Initialized
INFO - 2016-05-24 18:37:13 --> Controller Class Initialized
INFO - 2016-05-24 18:37:13 --> Model Class Initialized
INFO - 2016-05-24 18:37:13 --> Database Driver Class Initialized
ERROR - 2016-05-24 18:37:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '2daw1516_isabel'@'localhost' (using password: YES) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2016-05-24 18:37:13 --> Unable to connect to the database
INFO - 2016-05-24 18:37:13 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-24 18:37:38 --> Config Class Initialized
INFO - 2016-05-24 18:37:38 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:37:38 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:37:38 --> Utf8 Class Initialized
INFO - 2016-05-24 18:37:38 --> URI Class Initialized
INFO - 2016-05-24 18:37:38 --> Router Class Initialized
INFO - 2016-05-24 18:37:38 --> Output Class Initialized
INFO - 2016-05-24 18:37:38 --> Security Class Initialized
DEBUG - 2016-05-24 18:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:37:38 --> Input Class Initialized
INFO - 2016-05-24 18:37:38 --> Language Class Initialized
INFO - 2016-05-24 18:37:38 --> Loader Class Initialized
INFO - 2016-05-24 18:37:38 --> Helper loaded: url_helper
INFO - 2016-05-24 18:37:38 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:37:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:37:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:37:38 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:37:38 --> Helper loaded: form_helper
INFO - 2016-05-24 18:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:37:39 --> Form Validation Class Initialized
INFO - 2016-05-24 18:37:39 --> Controller Class Initialized
INFO - 2016-05-24 18:37:39 --> Model Class Initialized
INFO - 2016-05-24 18:37:39 --> Database Driver Class Initialized
ERROR - 2016-05-24 18:37:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '2daw1516_isabel'@'localhost' (using password: YES) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2016-05-24 18:37:39 --> Unable to connect to the database
INFO - 2016-05-24 18:37:39 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-24 18:37:47 --> Config Class Initialized
INFO - 2016-05-24 18:37:47 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:37:47 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:37:47 --> Utf8 Class Initialized
INFO - 2016-05-24 18:37:47 --> URI Class Initialized
INFO - 2016-05-24 18:37:47 --> Router Class Initialized
INFO - 2016-05-24 18:37:47 --> Output Class Initialized
INFO - 2016-05-24 18:37:47 --> Security Class Initialized
DEBUG - 2016-05-24 18:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:37:47 --> Input Class Initialized
INFO - 2016-05-24 18:37:47 --> Language Class Initialized
INFO - 2016-05-24 18:37:47 --> Loader Class Initialized
INFO - 2016-05-24 18:37:47 --> Helper loaded: url_helper
INFO - 2016-05-24 18:37:47 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:37:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:37:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:37:47 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:37:47 --> Helper loaded: form_helper
INFO - 2016-05-24 18:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:37:47 --> Form Validation Class Initialized
INFO - 2016-05-24 18:37:47 --> Controller Class Initialized
INFO - 2016-05-24 18:37:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-24 18:37:47 --> Model Class Initialized
INFO - 2016-05-24 18:37:47 --> Database Driver Class Initialized
ERROR - 2016-05-24 18:37:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '2daw1516_isabel'@'localhost' (using password: YES) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2016-05-24 18:37:47 --> Unable to connect to the database
INFO - 2016-05-24 18:37:47 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-24 19:10:16 --> Config Class Initialized
INFO - 2016-05-24 19:10:16 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:10:16 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:10:16 --> Utf8 Class Initialized
INFO - 2016-05-24 19:10:16 --> URI Class Initialized
DEBUG - 2016-05-24 19:10:16 --> No URI present. Default controller set.
INFO - 2016-05-24 19:10:16 --> Router Class Initialized
INFO - 2016-05-24 19:10:16 --> Output Class Initialized
INFO - 2016-05-24 19:10:16 --> Security Class Initialized
DEBUG - 2016-05-24 19:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:10:16 --> Input Class Initialized
INFO - 2016-05-24 19:10:16 --> Language Class Initialized
INFO - 2016-05-24 19:10:16 --> Loader Class Initialized
INFO - 2016-05-24 19:10:16 --> Helper loaded: url_helper
INFO - 2016-05-24 19:10:16 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:10:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:10:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:10:16 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:10:16 --> Helper loaded: form_helper
INFO - 2016-05-24 19:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:10:16 --> Form Validation Class Initialized
INFO - 2016-05-24 19:10:16 --> Controller Class Initialized
INFO - 2016-05-24 19:10:16 --> Model Class Initialized
INFO - 2016-05-24 19:10:16 --> Database Driver Class Initialized
INFO - 2016-05-24 19:10:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:10:16 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:10:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:10:16 --> Config Class Initialized
INFO - 2016-05-24 19:10:16 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:10:16 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:10:16 --> Utf8 Class Initialized
INFO - 2016-05-24 19:10:16 --> URI Class Initialized
INFO - 2016-05-24 19:10:16 --> Router Class Initialized
INFO - 2016-05-24 19:10:16 --> Output Class Initialized
INFO - 2016-05-24 19:10:16 --> Security Class Initialized
DEBUG - 2016-05-24 19:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:10:16 --> Input Class Initialized
INFO - 2016-05-24 19:10:16 --> Language Class Initialized
INFO - 2016-05-24 19:10:16 --> Loader Class Initialized
INFO - 2016-05-24 19:10:16 --> Helper loaded: url_helper
INFO - 2016-05-24 19:10:16 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:10:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:10:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:10:16 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:10:16 --> Helper loaded: form_helper
INFO - 2016-05-24 19:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:10:16 --> Form Validation Class Initialized
INFO - 2016-05-24 19:10:16 --> Controller Class Initialized
INFO - 2016-05-24 19:10:16 --> Model Class Initialized
INFO - 2016-05-24 19:10:16 --> Database Driver Class Initialized
INFO - 2016-05-24 19:10:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-24 19:10:16 --> Final output sent to browser
DEBUG - 2016-05-24 19:10:16 --> Total execution time: 0.0679
INFO - 2016-05-24 19:10:21 --> Config Class Initialized
INFO - 2016-05-24 19:10:21 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:10:21 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:10:21 --> Utf8 Class Initialized
INFO - 2016-05-24 19:10:21 --> URI Class Initialized
INFO - 2016-05-24 19:10:21 --> Router Class Initialized
INFO - 2016-05-24 19:10:21 --> Output Class Initialized
INFO - 2016-05-24 19:10:21 --> Security Class Initialized
DEBUG - 2016-05-24 19:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:10:21 --> Input Class Initialized
INFO - 2016-05-24 19:10:21 --> Language Class Initialized
INFO - 2016-05-24 19:10:21 --> Loader Class Initialized
INFO - 2016-05-24 19:10:21 --> Helper loaded: url_helper
INFO - 2016-05-24 19:10:21 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:10:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:10:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:10:21 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:10:21 --> Helper loaded: form_helper
INFO - 2016-05-24 19:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:10:21 --> Form Validation Class Initialized
INFO - 2016-05-24 19:10:21 --> Controller Class Initialized
INFO - 2016-05-24 19:10:21 --> Model Class Initialized
INFO - 2016-05-24 19:10:21 --> Database Driver Class Initialized
INFO - 2016-05-24 19:10:21 --> Config Class Initialized
INFO - 2016-05-24 19:10:21 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:10:21 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:10:21 --> Utf8 Class Initialized
INFO - 2016-05-24 19:10:21 --> URI Class Initialized
DEBUG - 2016-05-24 19:10:21 --> No URI present. Default controller set.
INFO - 2016-05-24 19:10:21 --> Router Class Initialized
INFO - 2016-05-24 19:10:21 --> Output Class Initialized
INFO - 2016-05-24 19:10:21 --> Security Class Initialized
DEBUG - 2016-05-24 19:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:10:21 --> Input Class Initialized
INFO - 2016-05-24 19:10:21 --> Language Class Initialized
INFO - 2016-05-24 19:10:21 --> Loader Class Initialized
INFO - 2016-05-24 19:10:21 --> Helper loaded: url_helper
INFO - 2016-05-24 19:10:21 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:10:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:10:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:10:21 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:10:21 --> Helper loaded: form_helper
INFO - 2016-05-24 19:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:10:21 --> Form Validation Class Initialized
INFO - 2016-05-24 19:10:21 --> Controller Class Initialized
INFO - 2016-05-24 19:10:21 --> Model Class Initialized
INFO - 2016-05-24 19:10:21 --> Database Driver Class Initialized
INFO - 2016-05-24 19:10:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:10:21 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:10:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:10:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-24 19:10:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-24 19:10:21 --> Final output sent to browser
DEBUG - 2016-05-24 19:10:21 --> Total execution time: 0.2426
INFO - 2016-05-24 19:10:26 --> Config Class Initialized
INFO - 2016-05-24 19:10:26 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:10:26 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:10:26 --> Utf8 Class Initialized
INFO - 2016-05-24 19:10:26 --> URI Class Initialized
INFO - 2016-05-24 19:10:26 --> Router Class Initialized
INFO - 2016-05-24 19:10:26 --> Output Class Initialized
INFO - 2016-05-24 19:10:26 --> Security Class Initialized
DEBUG - 2016-05-24 19:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:10:26 --> Input Class Initialized
INFO - 2016-05-24 19:10:26 --> Language Class Initialized
INFO - 2016-05-24 19:10:26 --> Loader Class Initialized
INFO - 2016-05-24 19:10:26 --> Helper loaded: url_helper
INFO - 2016-05-24 19:10:26 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:10:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:10:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:10:26 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:10:26 --> Helper loaded: form_helper
INFO - 2016-05-24 19:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:10:26 --> Form Validation Class Initialized
INFO - 2016-05-24 19:10:26 --> Controller Class Initialized
INFO - 2016-05-24 19:10:26 --> Model Class Initialized
INFO - 2016-05-24 19:10:26 --> Database Driver Class Initialized
INFO - 2016-05-24 19:10:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:10:26 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:10:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:10:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_categoria.php
INFO - 2016-05-24 19:10:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-24 19:10:26 --> Final output sent to browser
DEBUG - 2016-05-24 19:10:26 --> Total execution time: 0.1165
INFO - 2016-05-24 19:10:34 --> Config Class Initialized
INFO - 2016-05-24 19:10:34 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:10:34 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:10:34 --> Utf8 Class Initialized
INFO - 2016-05-24 19:10:34 --> URI Class Initialized
INFO - 2016-05-24 19:10:34 --> Router Class Initialized
INFO - 2016-05-24 19:10:34 --> Output Class Initialized
INFO - 2016-05-24 19:10:34 --> Security Class Initialized
DEBUG - 2016-05-24 19:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:10:34 --> Input Class Initialized
INFO - 2016-05-24 19:10:34 --> Language Class Initialized
INFO - 2016-05-24 19:10:34 --> Loader Class Initialized
INFO - 2016-05-24 19:10:34 --> Helper loaded: url_helper
INFO - 2016-05-24 19:10:34 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:10:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:10:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:10:34 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:10:34 --> Helper loaded: form_helper
INFO - 2016-05-24 19:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:10:34 --> Form Validation Class Initialized
INFO - 2016-05-24 19:10:34 --> Controller Class Initialized
INFO - 2016-05-24 19:10:34 --> Model Class Initialized
INFO - 2016-05-24 19:10:34 --> Database Driver Class Initialized
INFO - 2016-05-24 19:10:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:10:34 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:10:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:10:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_categoria.php
INFO - 2016-05-24 19:10:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-24 19:10:34 --> Final output sent to browser
DEBUG - 2016-05-24 19:10:34 --> Total execution time: 0.0875
INFO - 2016-05-24 19:10:41 --> Config Class Initialized
INFO - 2016-05-24 19:10:41 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:10:41 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:10:41 --> Utf8 Class Initialized
INFO - 2016-05-24 19:10:41 --> URI Class Initialized
INFO - 2016-05-24 19:10:41 --> Router Class Initialized
INFO - 2016-05-24 19:10:41 --> Output Class Initialized
INFO - 2016-05-24 19:10:41 --> Security Class Initialized
DEBUG - 2016-05-24 19:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:10:41 --> Input Class Initialized
INFO - 2016-05-24 19:10:41 --> Language Class Initialized
INFO - 2016-05-24 19:10:41 --> Loader Class Initialized
INFO - 2016-05-24 19:10:41 --> Helper loaded: url_helper
INFO - 2016-05-24 19:10:41 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:10:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:10:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:10:41 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:10:41 --> Helper loaded: form_helper
INFO - 2016-05-24 19:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:10:41 --> Form Validation Class Initialized
INFO - 2016-05-24 19:10:41 --> Controller Class Initialized
INFO - 2016-05-24 19:10:41 --> Model Class Initialized
INFO - 2016-05-24 19:10:41 --> Database Driver Class Initialized
INFO - 2016-05-24 19:10:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:10:41 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:10:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:10:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_categoria.php
INFO - 2016-05-24 19:10:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-24 19:10:41 --> Final output sent to browser
DEBUG - 2016-05-24 19:10:41 --> Total execution time: 0.0857
INFO - 2016-05-24 19:10:44 --> Config Class Initialized
INFO - 2016-05-24 19:10:44 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:10:44 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:10:44 --> Utf8 Class Initialized
INFO - 2016-05-24 19:10:44 --> URI Class Initialized
INFO - 2016-05-24 19:10:44 --> Router Class Initialized
INFO - 2016-05-24 19:10:44 --> Output Class Initialized
INFO - 2016-05-24 19:10:44 --> Security Class Initialized
DEBUG - 2016-05-24 19:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:10:44 --> Input Class Initialized
INFO - 2016-05-24 19:10:44 --> Language Class Initialized
INFO - 2016-05-24 19:10:44 --> Loader Class Initialized
INFO - 2016-05-24 19:10:44 --> Helper loaded: url_helper
INFO - 2016-05-24 19:10:44 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:10:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:10:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:10:44 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:10:44 --> Helper loaded: form_helper
INFO - 2016-05-24 19:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:10:44 --> Form Validation Class Initialized
INFO - 2016-05-24 19:10:44 --> Controller Class Initialized
INFO - 2016-05-24 19:10:44 --> Model Class Initialized
INFO - 2016-05-24 19:10:44 --> Database Driver Class Initialized
INFO - 2016-05-24 19:10:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:10:44 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:10:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:10:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_categoria.php
INFO - 2016-05-24 19:10:44 --> Final output sent to browser
DEBUG - 2016-05-24 19:10:44 --> Total execution time: 0.0846
INFO - 2016-05-24 19:10:45 --> Config Class Initialized
INFO - 2016-05-24 19:10:45 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:10:45 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:10:45 --> Utf8 Class Initialized
INFO - 2016-05-24 19:10:45 --> URI Class Initialized
INFO - 2016-05-24 19:10:45 --> Router Class Initialized
INFO - 2016-05-24 19:10:45 --> Output Class Initialized
INFO - 2016-05-24 19:10:45 --> Security Class Initialized
DEBUG - 2016-05-24 19:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:10:45 --> Input Class Initialized
INFO - 2016-05-24 19:10:45 --> Language Class Initialized
INFO - 2016-05-24 19:10:45 --> Loader Class Initialized
INFO - 2016-05-24 19:10:45 --> Helper loaded: url_helper
INFO - 2016-05-24 19:10:45 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:10:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:10:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:10:45 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:10:45 --> Helper loaded: form_helper
INFO - 2016-05-24 19:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:10:45 --> Form Validation Class Initialized
INFO - 2016-05-24 19:10:45 --> Controller Class Initialized
INFO - 2016-05-24 19:10:45 --> Model Class Initialized
INFO - 2016-05-24 19:10:45 --> Database Driver Class Initialized
INFO - 2016-05-24 19:10:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:10:45 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:10:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:10:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_categoria.php
INFO - 2016-05-24 19:10:45 --> Final output sent to browser
DEBUG - 2016-05-24 19:10:45 --> Total execution time: 0.0948
INFO - 2016-05-24 19:10:55 --> Config Class Initialized
INFO - 2016-05-24 19:10:55 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:10:55 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:10:55 --> Utf8 Class Initialized
INFO - 2016-05-24 19:10:55 --> URI Class Initialized
INFO - 2016-05-24 19:10:55 --> Router Class Initialized
INFO - 2016-05-24 19:10:55 --> Output Class Initialized
INFO - 2016-05-24 19:10:55 --> Security Class Initialized
DEBUG - 2016-05-24 19:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:10:55 --> Input Class Initialized
INFO - 2016-05-24 19:10:55 --> Language Class Initialized
INFO - 2016-05-24 19:10:55 --> Loader Class Initialized
INFO - 2016-05-24 19:10:55 --> Helper loaded: url_helper
INFO - 2016-05-24 19:10:55 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:10:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:10:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:10:55 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:10:55 --> Helper loaded: form_helper
INFO - 2016-05-24 19:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:10:55 --> Form Validation Class Initialized
INFO - 2016-05-24 19:10:55 --> Controller Class Initialized
INFO - 2016-05-24 19:10:55 --> Model Class Initialized
INFO - 2016-05-24 19:10:55 --> Database Driver Class Initialized
INFO - 2016-05-24 19:10:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:10:55 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:10:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:10:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_categoria.php
INFO - 2016-05-24 19:10:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-24 19:10:55 --> Final output sent to browser
DEBUG - 2016-05-24 19:10:55 --> Total execution time: 0.0848
INFO - 2016-05-24 19:10:59 --> Config Class Initialized
INFO - 2016-05-24 19:10:59 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:10:59 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:10:59 --> Utf8 Class Initialized
INFO - 2016-05-24 19:10:59 --> URI Class Initialized
INFO - 2016-05-24 19:10:59 --> Router Class Initialized
INFO - 2016-05-24 19:10:59 --> Output Class Initialized
INFO - 2016-05-24 19:10:59 --> Security Class Initialized
DEBUG - 2016-05-24 19:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:10:59 --> Input Class Initialized
INFO - 2016-05-24 19:10:59 --> Language Class Initialized
INFO - 2016-05-24 19:10:59 --> Loader Class Initialized
INFO - 2016-05-24 19:10:59 --> Helper loaded: url_helper
INFO - 2016-05-24 19:10:59 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:10:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:10:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:10:59 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:10:59 --> Helper loaded: form_helper
INFO - 2016-05-24 19:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:10:59 --> Form Validation Class Initialized
INFO - 2016-05-24 19:10:59 --> Controller Class Initialized
INFO - 2016-05-24 19:10:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-24 19:10:59 --> Model Class Initialized
INFO - 2016-05-24 19:10:59 --> Database Driver Class Initialized
INFO - 2016-05-24 19:10:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:10:59 --> Final output sent to browser
DEBUG - 2016-05-24 19:10:59 --> Total execution time: 0.0923
INFO - 2016-05-24 19:11:00 --> Config Class Initialized
INFO - 2016-05-24 19:11:00 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:00 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:00 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:00 --> URI Class Initialized
INFO - 2016-05-24 19:11:00 --> Router Class Initialized
INFO - 2016-05-24 19:11:00 --> Output Class Initialized
INFO - 2016-05-24 19:11:00 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:00 --> Input Class Initialized
INFO - 2016-05-24 19:11:00 --> Language Class Initialized
INFO - 2016-05-24 19:11:00 --> Loader Class Initialized
INFO - 2016-05-24 19:11:00 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:00 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:00 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:00 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:00 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:00 --> Controller Class Initialized
INFO - 2016-05-24 19:11:00 --> Model Class Initialized
INFO - 2016-05-24 19:11:00 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:11:00 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:11:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:11:00 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:00 --> Total execution time: 0.0976
INFO - 2016-05-24 19:11:05 --> Config Class Initialized
INFO - 2016-05-24 19:11:05 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:05 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:05 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:05 --> URI Class Initialized
INFO - 2016-05-24 19:11:05 --> Router Class Initialized
INFO - 2016-05-24 19:11:05 --> Output Class Initialized
INFO - 2016-05-24 19:11:05 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:05 --> Input Class Initialized
INFO - 2016-05-24 19:11:05 --> Language Class Initialized
INFO - 2016-05-24 19:11:05 --> Loader Class Initialized
INFO - 2016-05-24 19:11:05 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:05 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:05 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:05 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:05 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:05 --> Controller Class Initialized
INFO - 2016-05-24 19:11:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-24 19:11:05 --> Model Class Initialized
INFO - 2016-05-24 19:11:05 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:11:05 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:05 --> Total execution time: 0.0793
INFO - 2016-05-24 19:11:05 --> Config Class Initialized
INFO - 2016-05-24 19:11:05 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:05 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:05 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:05 --> URI Class Initialized
INFO - 2016-05-24 19:11:05 --> Router Class Initialized
INFO - 2016-05-24 19:11:05 --> Output Class Initialized
INFO - 2016-05-24 19:11:05 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:05 --> Input Class Initialized
INFO - 2016-05-24 19:11:05 --> Language Class Initialized
INFO - 2016-05-24 19:11:05 --> Loader Class Initialized
INFO - 2016-05-24 19:11:05 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:05 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:06 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:06 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:06 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:06 --> Controller Class Initialized
INFO - 2016-05-24 19:11:06 --> Model Class Initialized
INFO - 2016-05-24 19:11:06 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:11:06 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:11:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:11:06 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:06 --> Total execution time: 0.1056
INFO - 2016-05-24 19:11:08 --> Config Class Initialized
INFO - 2016-05-24 19:11:08 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:08 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:08 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:08 --> URI Class Initialized
INFO - 2016-05-24 19:11:08 --> Router Class Initialized
INFO - 2016-05-24 19:11:08 --> Output Class Initialized
INFO - 2016-05-24 19:11:08 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:08 --> Input Class Initialized
INFO - 2016-05-24 19:11:08 --> Language Class Initialized
INFO - 2016-05-24 19:11:08 --> Loader Class Initialized
INFO - 2016-05-24 19:11:08 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:08 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:08 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:08 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:08 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:08 --> Controller Class Initialized
INFO - 2016-05-24 19:11:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-24 19:11:08 --> Model Class Initialized
INFO - 2016-05-24 19:11:08 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:11:08 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:08 --> Total execution time: 0.0717
INFO - 2016-05-24 19:11:09 --> Config Class Initialized
INFO - 2016-05-24 19:11:09 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:09 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:09 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:09 --> URI Class Initialized
INFO - 2016-05-24 19:11:09 --> Router Class Initialized
INFO - 2016-05-24 19:11:09 --> Output Class Initialized
INFO - 2016-05-24 19:11:09 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:09 --> Input Class Initialized
INFO - 2016-05-24 19:11:09 --> Language Class Initialized
INFO - 2016-05-24 19:11:09 --> Loader Class Initialized
INFO - 2016-05-24 19:11:09 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:09 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:09 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:09 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:09 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:09 --> Controller Class Initialized
INFO - 2016-05-24 19:11:09 --> Model Class Initialized
INFO - 2016-05-24 19:11:09 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:11:09 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:11:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:11:09 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:09 --> Total execution time: 0.1204
INFO - 2016-05-24 19:11:10 --> Config Class Initialized
INFO - 2016-05-24 19:11:10 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:10 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:10 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:10 --> URI Class Initialized
INFO - 2016-05-24 19:11:10 --> Router Class Initialized
INFO - 2016-05-24 19:11:10 --> Output Class Initialized
INFO - 2016-05-24 19:11:10 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:10 --> Input Class Initialized
INFO - 2016-05-24 19:11:10 --> Language Class Initialized
INFO - 2016-05-24 19:11:10 --> Loader Class Initialized
INFO - 2016-05-24 19:11:10 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:10 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:10 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:10 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:10 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:10 --> Controller Class Initialized
INFO - 2016-05-24 19:11:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 19:11:10 --> Helper loaded: nif_validate_helper
INFO - 2016-05-24 19:11:10 --> Model Class Initialized
INFO - 2016-05-24 19:11:10 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-24 19:11:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:11:11 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:11 --> Total execution time: 0.3381
INFO - 2016-05-24 19:11:11 --> Config Class Initialized
INFO - 2016-05-24 19:11:11 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:11 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:11 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:11 --> URI Class Initialized
INFO - 2016-05-24 19:11:11 --> Router Class Initialized
INFO - 2016-05-24 19:11:11 --> Output Class Initialized
INFO - 2016-05-24 19:11:11 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:11 --> Input Class Initialized
INFO - 2016-05-24 19:11:11 --> Language Class Initialized
INFO - 2016-05-24 19:11:11 --> Loader Class Initialized
INFO - 2016-05-24 19:11:11 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:11 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:11 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:11 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:11 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:11 --> Controller Class Initialized
INFO - 2016-05-24 19:11:11 --> Model Class Initialized
INFO - 2016-05-24 19:11:11 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:11:11 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:11:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:11:11 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:11 --> Total execution time: 0.1106
INFO - 2016-05-24 19:11:13 --> Config Class Initialized
INFO - 2016-05-24 19:11:13 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:13 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:13 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:13 --> URI Class Initialized
INFO - 2016-05-24 19:11:13 --> Router Class Initialized
INFO - 2016-05-24 19:11:13 --> Output Class Initialized
INFO - 2016-05-24 19:11:13 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:13 --> Input Class Initialized
INFO - 2016-05-24 19:11:13 --> Language Class Initialized
INFO - 2016-05-24 19:11:13 --> Loader Class Initialized
INFO - 2016-05-24 19:11:13 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:13 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:13 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:13 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:13 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:13 --> Controller Class Initialized
INFO - 2016-05-24 19:11:13 --> Model Class Initialized
INFO - 2016-05-24 19:11:13 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:11:13 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:11:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:11:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-24 19:11:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:11:14 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:14 --> Total execution time: 0.1082
INFO - 2016-05-24 19:11:14 --> Config Class Initialized
INFO - 2016-05-24 19:11:14 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:14 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:14 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:14 --> URI Class Initialized
INFO - 2016-05-24 19:11:14 --> Router Class Initialized
INFO - 2016-05-24 19:11:14 --> Output Class Initialized
INFO - 2016-05-24 19:11:14 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:14 --> Input Class Initialized
INFO - 2016-05-24 19:11:14 --> Language Class Initialized
INFO - 2016-05-24 19:11:14 --> Loader Class Initialized
INFO - 2016-05-24 19:11:14 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:14 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:14 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:14 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:14 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:14 --> Controller Class Initialized
INFO - 2016-05-24 19:11:14 --> Model Class Initialized
INFO - 2016-05-24 19:11:14 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:11:14 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:11:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:11:14 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:14 --> Total execution time: 0.1099
INFO - 2016-05-24 19:11:15 --> Config Class Initialized
INFO - 2016-05-24 19:11:15 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:15 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:15 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:15 --> URI Class Initialized
INFO - 2016-05-24 19:11:15 --> Router Class Initialized
INFO - 2016-05-24 19:11:15 --> Output Class Initialized
INFO - 2016-05-24 19:11:15 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:15 --> Input Class Initialized
INFO - 2016-05-24 19:11:15 --> Language Class Initialized
INFO - 2016-05-24 19:11:15 --> Loader Class Initialized
INFO - 2016-05-24 19:11:15 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:15 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:15 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:15 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:15 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:15 --> Controller Class Initialized
DEBUG - 2016-05-24 19:11:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 19:11:15 --> Model Class Initialized
INFO - 2016-05-24 19:11:15 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-24 19:11:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:11:15 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:15 --> Total execution time: 0.0885
INFO - 2016-05-24 19:11:16 --> Config Class Initialized
INFO - 2016-05-24 19:11:16 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:16 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:16 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:16 --> URI Class Initialized
INFO - 2016-05-24 19:11:16 --> Router Class Initialized
INFO - 2016-05-24 19:11:16 --> Output Class Initialized
INFO - 2016-05-24 19:11:16 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:16 --> Input Class Initialized
INFO - 2016-05-24 19:11:16 --> Language Class Initialized
INFO - 2016-05-24 19:11:16 --> Loader Class Initialized
INFO - 2016-05-24 19:11:16 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:16 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:16 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:16 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:16 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:16 --> Controller Class Initialized
INFO - 2016-05-24 19:11:16 --> Model Class Initialized
INFO - 2016-05-24 19:11:16 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:11:16 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:11:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:11:16 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:16 --> Total execution time: 0.1195
INFO - 2016-05-24 19:11:18 --> Config Class Initialized
INFO - 2016-05-24 19:11:18 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:18 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:18 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:18 --> URI Class Initialized
INFO - 2016-05-24 19:11:18 --> Router Class Initialized
INFO - 2016-05-24 19:11:18 --> Output Class Initialized
INFO - 2016-05-24 19:11:18 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:18 --> Input Class Initialized
INFO - 2016-05-24 19:11:18 --> Language Class Initialized
INFO - 2016-05-24 19:11:18 --> Loader Class Initialized
INFO - 2016-05-24 19:11:18 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:18 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:18 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:18 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:18 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:18 --> Controller Class Initialized
DEBUG - 2016-05-24 19:11:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 19:11:18 --> Model Class Initialized
INFO - 2016-05-24 19:11:18 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:18 --> Config Class Initialized
INFO - 2016-05-24 19:11:18 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:18 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:18 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:18 --> URI Class Initialized
INFO - 2016-05-24 19:11:18 --> Router Class Initialized
INFO - 2016-05-24 19:11:18 --> Output Class Initialized
INFO - 2016-05-24 19:11:18 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:18 --> Input Class Initialized
INFO - 2016-05-24 19:11:18 --> Language Class Initialized
INFO - 2016-05-24 19:11:18 --> Loader Class Initialized
INFO - 2016-05-24 19:11:18 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:18 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:18 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:18 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:18 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:18 --> Controller Class Initialized
DEBUG - 2016-05-24 19:11:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 19:11:18 --> Model Class Initialized
INFO - 2016-05-24 19:11:18 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-24 19:11:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-24 19:11:18 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:18 --> Total execution time: 0.0755
INFO - 2016-05-24 19:11:19 --> Config Class Initialized
INFO - 2016-05-24 19:11:19 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:19 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:19 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:19 --> URI Class Initialized
INFO - 2016-05-24 19:11:19 --> Router Class Initialized
INFO - 2016-05-24 19:11:19 --> Output Class Initialized
INFO - 2016-05-24 19:11:19 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:19 --> Input Class Initialized
INFO - 2016-05-24 19:11:19 --> Language Class Initialized
INFO - 2016-05-24 19:11:19 --> Loader Class Initialized
INFO - 2016-05-24 19:11:19 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:19 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:19 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:19 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:19 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:19 --> Controller Class Initialized
INFO - 2016-05-24 19:11:19 --> Model Class Initialized
INFO - 2016-05-24 19:11:19 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:11:19 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:11:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:11:19 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:19 --> Total execution time: 0.0821
INFO - 2016-05-24 19:11:21 --> Config Class Initialized
INFO - 2016-05-24 19:11:21 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:21 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:21 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:21 --> URI Class Initialized
INFO - 2016-05-24 19:11:21 --> Router Class Initialized
INFO - 2016-05-24 19:11:21 --> Output Class Initialized
INFO - 2016-05-24 19:11:21 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:21 --> Input Class Initialized
INFO - 2016-05-24 19:11:21 --> Language Class Initialized
INFO - 2016-05-24 19:11:21 --> Loader Class Initialized
INFO - 2016-05-24 19:11:21 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:21 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:21 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:21 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:21 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:21 --> Controller Class Initialized
DEBUG - 2016-05-24 19:11:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 19:11:21 --> Model Class Initialized
INFO - 2016-05-24 19:11:21 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:21 --> Config Class Initialized
INFO - 2016-05-24 19:11:21 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:21 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:21 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:21 --> URI Class Initialized
INFO - 2016-05-24 19:11:21 --> Router Class Initialized
INFO - 2016-05-24 19:11:21 --> Output Class Initialized
INFO - 2016-05-24 19:11:21 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:21 --> Input Class Initialized
INFO - 2016-05-24 19:11:21 --> Language Class Initialized
INFO - 2016-05-24 19:11:21 --> Loader Class Initialized
INFO - 2016-05-24 19:11:21 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:21 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:21 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:21 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:21 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:21 --> Controller Class Initialized
DEBUG - 2016-05-24 19:11:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 19:11:21 --> Model Class Initialized
INFO - 2016-05-24 19:11:21 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-24 19:11:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-24 19:11:21 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:21 --> Total execution time: 0.0866
INFO - 2016-05-24 19:11:22 --> Config Class Initialized
INFO - 2016-05-24 19:11:22 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:22 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:22 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:22 --> URI Class Initialized
INFO - 2016-05-24 19:11:22 --> Router Class Initialized
INFO - 2016-05-24 19:11:22 --> Output Class Initialized
INFO - 2016-05-24 19:11:22 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:22 --> Input Class Initialized
INFO - 2016-05-24 19:11:22 --> Language Class Initialized
INFO - 2016-05-24 19:11:22 --> Loader Class Initialized
INFO - 2016-05-24 19:11:22 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:22 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:22 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:22 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:22 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:22 --> Controller Class Initialized
INFO - 2016-05-24 19:11:22 --> Model Class Initialized
INFO - 2016-05-24 19:11:22 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:11:22 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:11:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:11:22 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:22 --> Total execution time: 0.0921
INFO - 2016-05-24 19:11:23 --> Config Class Initialized
INFO - 2016-05-24 19:11:23 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:23 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:23 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:23 --> URI Class Initialized
INFO - 2016-05-24 19:11:23 --> Router Class Initialized
INFO - 2016-05-24 19:11:23 --> Output Class Initialized
INFO - 2016-05-24 19:11:23 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:23 --> Input Class Initialized
INFO - 2016-05-24 19:11:23 --> Language Class Initialized
INFO - 2016-05-24 19:11:23 --> Loader Class Initialized
INFO - 2016-05-24 19:11:23 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:23 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:23 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:23 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:23 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:23 --> Controller Class Initialized
DEBUG - 2016-05-24 19:11:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 19:11:23 --> Model Class Initialized
INFO - 2016-05-24 19:11:23 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:23 --> Config Class Initialized
INFO - 2016-05-24 19:11:23 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:23 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:23 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:23 --> URI Class Initialized
INFO - 2016-05-24 19:11:23 --> Router Class Initialized
INFO - 2016-05-24 19:11:23 --> Output Class Initialized
INFO - 2016-05-24 19:11:23 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:23 --> Input Class Initialized
INFO - 2016-05-24 19:11:23 --> Language Class Initialized
INFO - 2016-05-24 19:11:23 --> Loader Class Initialized
INFO - 2016-05-24 19:11:23 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:23 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:23 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:23 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:23 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:23 --> Controller Class Initialized
DEBUG - 2016-05-24 19:11:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 19:11:23 --> Model Class Initialized
INFO - 2016-05-24 19:11:23 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-24 19:11:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:11:23 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:23 --> Total execution time: 0.0893
INFO - 2016-05-24 19:11:24 --> Config Class Initialized
INFO - 2016-05-24 19:11:24 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:24 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:24 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:24 --> URI Class Initialized
INFO - 2016-05-24 19:11:24 --> Router Class Initialized
INFO - 2016-05-24 19:11:24 --> Output Class Initialized
INFO - 2016-05-24 19:11:24 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:24 --> Input Class Initialized
INFO - 2016-05-24 19:11:24 --> Language Class Initialized
INFO - 2016-05-24 19:11:24 --> Loader Class Initialized
INFO - 2016-05-24 19:11:24 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:24 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:24 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:24 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:24 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:24 --> Controller Class Initialized
INFO - 2016-05-24 19:11:24 --> Model Class Initialized
INFO - 2016-05-24 19:11:24 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:11:24 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:11:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:11:24 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:24 --> Total execution time: 0.0935
INFO - 2016-05-24 19:11:26 --> Config Class Initialized
INFO - 2016-05-24 19:11:26 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:26 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:26 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:26 --> URI Class Initialized
INFO - 2016-05-24 19:11:26 --> Router Class Initialized
INFO - 2016-05-24 19:11:26 --> Output Class Initialized
INFO - 2016-05-24 19:11:26 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:26 --> Input Class Initialized
INFO - 2016-05-24 19:11:26 --> Language Class Initialized
INFO - 2016-05-24 19:11:26 --> Loader Class Initialized
INFO - 2016-05-24 19:11:26 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:26 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:26 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:26 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:26 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:26 --> Controller Class Initialized
INFO - 2016-05-24 19:11:26 --> Model Class Initialized
INFO - 2016-05-24 19:11:26 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_perfil.php
INFO - 2016-05-24 19:11:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:11:26 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:26 --> Total execution time: 0.0979
INFO - 2016-05-24 19:11:26 --> Config Class Initialized
INFO - 2016-05-24 19:11:26 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:26 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:26 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:26 --> URI Class Initialized
INFO - 2016-05-24 19:11:26 --> Router Class Initialized
INFO - 2016-05-24 19:11:26 --> Output Class Initialized
INFO - 2016-05-24 19:11:26 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:26 --> Input Class Initialized
INFO - 2016-05-24 19:11:26 --> Language Class Initialized
INFO - 2016-05-24 19:11:26 --> Loader Class Initialized
INFO - 2016-05-24 19:11:26 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:26 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:26 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:26 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:26 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:26 --> Controller Class Initialized
INFO - 2016-05-24 19:11:26 --> Model Class Initialized
INFO - 2016-05-24 19:11:26 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:11:26 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:11:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:11:26 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:26 --> Total execution time: 0.1224
INFO - 2016-05-24 19:11:28 --> Config Class Initialized
INFO - 2016-05-24 19:11:28 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:28 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:28 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:28 --> URI Class Initialized
INFO - 2016-05-24 19:11:28 --> Router Class Initialized
INFO - 2016-05-24 19:11:28 --> Output Class Initialized
INFO - 2016-05-24 19:11:28 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:28 --> Input Class Initialized
INFO - 2016-05-24 19:11:28 --> Language Class Initialized
INFO - 2016-05-24 19:11:28 --> Loader Class Initialized
INFO - 2016-05-24 19:11:28 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:28 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:28 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:28 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:28 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:28 --> Controller Class Initialized
INFO - 2016-05-24 19:11:28 --> Model Class Initialized
INFO - 2016-05-24 19:11:28 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modUser.php
INFO - 2016-05-24 19:11:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:11:28 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:28 --> Total execution time: 0.1325
INFO - 2016-05-24 19:11:28 --> Config Class Initialized
INFO - 2016-05-24 19:11:28 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:28 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:28 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:28 --> URI Class Initialized
INFO - 2016-05-24 19:11:28 --> Router Class Initialized
INFO - 2016-05-24 19:11:28 --> Output Class Initialized
INFO - 2016-05-24 19:11:28 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:28 --> Input Class Initialized
INFO - 2016-05-24 19:11:28 --> Language Class Initialized
INFO - 2016-05-24 19:11:28 --> Loader Class Initialized
INFO - 2016-05-24 19:11:28 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:28 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:28 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:28 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:28 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:28 --> Controller Class Initialized
INFO - 2016-05-24 19:11:28 --> Model Class Initialized
INFO - 2016-05-24 19:11:28 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:11:28 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:11:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:11:28 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:28 --> Total execution time: 0.1092
INFO - 2016-05-24 19:11:33 --> Config Class Initialized
INFO - 2016-05-24 19:11:33 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:33 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:33 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:33 --> URI Class Initialized
INFO - 2016-05-24 19:11:33 --> Router Class Initialized
INFO - 2016-05-24 19:11:33 --> Output Class Initialized
INFO - 2016-05-24 19:11:33 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:33 --> Input Class Initialized
INFO - 2016-05-24 19:11:33 --> Language Class Initialized
INFO - 2016-05-24 19:11:33 --> Loader Class Initialized
INFO - 2016-05-24 19:11:33 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:33 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:33 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:33 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:33 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:33 --> Controller Class Initialized
INFO - 2016-05-24 19:11:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 19:11:33 --> Helper loaded: nif_validate_helper
INFO - 2016-05-24 19:11:33 --> Model Class Initialized
INFO - 2016-05-24 19:11:33 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-24 19:11:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:11:33 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:33 --> Total execution time: 0.1545
INFO - 2016-05-24 19:11:34 --> Config Class Initialized
INFO - 2016-05-24 19:11:34 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:34 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:34 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:34 --> URI Class Initialized
INFO - 2016-05-24 19:11:34 --> Router Class Initialized
INFO - 2016-05-24 19:11:34 --> Output Class Initialized
INFO - 2016-05-24 19:11:34 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:34 --> Input Class Initialized
INFO - 2016-05-24 19:11:34 --> Language Class Initialized
INFO - 2016-05-24 19:11:34 --> Loader Class Initialized
INFO - 2016-05-24 19:11:34 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:34 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:34 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:34 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:34 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:34 --> Controller Class Initialized
INFO - 2016-05-24 19:11:34 --> Model Class Initialized
INFO - 2016-05-24 19:11:34 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:11:34 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:11:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:11:34 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:34 --> Total execution time: 0.1046
INFO - 2016-05-24 19:11:37 --> Config Class Initialized
INFO - 2016-05-24 19:11:37 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:37 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:37 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:37 --> URI Class Initialized
INFO - 2016-05-24 19:11:37 --> Router Class Initialized
INFO - 2016-05-24 19:11:37 --> Output Class Initialized
INFO - 2016-05-24 19:11:37 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:37 --> Input Class Initialized
INFO - 2016-05-24 19:11:37 --> Language Class Initialized
INFO - 2016-05-24 19:11:37 --> Loader Class Initialized
INFO - 2016-05-24 19:11:37 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:37 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:37 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:37 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:37 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:37 --> Controller Class Initialized
INFO - 2016-05-24 19:11:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 19:11:37 --> Helper loaded: nif_validate_helper
INFO - 2016-05-24 19:11:37 --> Model Class Initialized
INFO - 2016-05-24 19:11:37 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:37 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-24 19:11:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-24 19:11:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:11:37 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:37 --> Total execution time: 0.1253
INFO - 2016-05-24 19:11:38 --> Config Class Initialized
INFO - 2016-05-24 19:11:38 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:11:38 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:11:38 --> Utf8 Class Initialized
INFO - 2016-05-24 19:11:38 --> URI Class Initialized
INFO - 2016-05-24 19:11:38 --> Router Class Initialized
INFO - 2016-05-24 19:11:38 --> Output Class Initialized
INFO - 2016-05-24 19:11:38 --> Security Class Initialized
DEBUG - 2016-05-24 19:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:11:38 --> Input Class Initialized
INFO - 2016-05-24 19:11:38 --> Language Class Initialized
INFO - 2016-05-24 19:11:38 --> Loader Class Initialized
INFO - 2016-05-24 19:11:38 --> Helper loaded: url_helper
INFO - 2016-05-24 19:11:38 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:11:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:11:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:11:38 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:11:38 --> Helper loaded: form_helper
INFO - 2016-05-24 19:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:11:38 --> Form Validation Class Initialized
INFO - 2016-05-24 19:11:38 --> Controller Class Initialized
INFO - 2016-05-24 19:11:38 --> Model Class Initialized
INFO - 2016-05-24 19:11:38 --> Database Driver Class Initialized
INFO - 2016-05-24 19:11:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:11:38 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:11:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:11:38 --> Final output sent to browser
DEBUG - 2016-05-24 19:11:38 --> Total execution time: 0.1150
INFO - 2016-05-24 19:12:03 --> Config Class Initialized
INFO - 2016-05-24 19:12:03 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:12:03 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:12:03 --> Utf8 Class Initialized
INFO - 2016-05-24 19:12:03 --> URI Class Initialized
INFO - 2016-05-24 19:12:03 --> Router Class Initialized
INFO - 2016-05-24 19:12:03 --> Output Class Initialized
INFO - 2016-05-24 19:12:03 --> Security Class Initialized
DEBUG - 2016-05-24 19:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:12:03 --> Input Class Initialized
INFO - 2016-05-24 19:12:03 --> Language Class Initialized
INFO - 2016-05-24 19:12:03 --> Loader Class Initialized
INFO - 2016-05-24 19:12:03 --> Helper loaded: url_helper
INFO - 2016-05-24 19:12:03 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:12:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:12:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:12:03 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:12:03 --> Helper loaded: form_helper
INFO - 2016-05-24 19:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:12:03 --> Form Validation Class Initialized
INFO - 2016-05-24 19:12:03 --> Controller Class Initialized
INFO - 2016-05-24 19:12:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 19:12:03 --> Helper loaded: nif_validate_helper
INFO - 2016-05-24 19:12:03 --> Model Class Initialized
INFO - 2016-05-24 19:12:03 --> Database Driver Class Initialized
INFO - 2016-05-24 19:12:03 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-24 19:12:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-24 19:12:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:12:03 --> Final output sent to browser
DEBUG - 2016-05-24 19:12:03 --> Total execution time: 0.1199
INFO - 2016-05-24 19:12:04 --> Config Class Initialized
INFO - 2016-05-24 19:12:04 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:12:04 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:12:04 --> Utf8 Class Initialized
INFO - 2016-05-24 19:12:04 --> URI Class Initialized
INFO - 2016-05-24 19:12:04 --> Router Class Initialized
INFO - 2016-05-24 19:12:04 --> Output Class Initialized
INFO - 2016-05-24 19:12:04 --> Security Class Initialized
DEBUG - 2016-05-24 19:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:12:04 --> Input Class Initialized
INFO - 2016-05-24 19:12:04 --> Language Class Initialized
INFO - 2016-05-24 19:12:04 --> Loader Class Initialized
INFO - 2016-05-24 19:12:04 --> Helper loaded: url_helper
INFO - 2016-05-24 19:12:04 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:12:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:12:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:12:04 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:12:04 --> Helper loaded: form_helper
INFO - 2016-05-24 19:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:12:04 --> Form Validation Class Initialized
INFO - 2016-05-24 19:12:04 --> Controller Class Initialized
INFO - 2016-05-24 19:12:04 --> Model Class Initialized
INFO - 2016-05-24 19:12:04 --> Database Driver Class Initialized
INFO - 2016-05-24 19:12:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:12:04 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:12:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:12:04 --> Final output sent to browser
DEBUG - 2016-05-24 19:12:04 --> Total execution time: 0.1096
INFO - 2016-05-24 19:12:14 --> Config Class Initialized
INFO - 2016-05-24 19:12:14 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:12:14 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:12:14 --> Utf8 Class Initialized
INFO - 2016-05-24 19:12:14 --> URI Class Initialized
INFO - 2016-05-24 19:12:14 --> Router Class Initialized
INFO - 2016-05-24 19:12:14 --> Output Class Initialized
INFO - 2016-05-24 19:12:14 --> Security Class Initialized
DEBUG - 2016-05-24 19:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:12:14 --> Input Class Initialized
INFO - 2016-05-24 19:12:14 --> Language Class Initialized
INFO - 2016-05-24 19:12:14 --> Loader Class Initialized
INFO - 2016-05-24 19:12:14 --> Helper loaded: url_helper
INFO - 2016-05-24 19:12:14 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:12:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:12:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:12:14 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:12:14 --> Helper loaded: form_helper
INFO - 2016-05-24 19:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:12:14 --> Form Validation Class Initialized
INFO - 2016-05-24 19:12:14 --> Controller Class Initialized
INFO - 2016-05-24 19:12:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 19:12:14 --> Helper loaded: nif_validate_helper
INFO - 2016-05-24 19:12:14 --> Model Class Initialized
INFO - 2016-05-24 19:12:14 --> Database Driver Class Initialized
INFO - 2016-05-24 19:12:14 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-24 19:12:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-24 19:12:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:12:14 --> Final output sent to browser
DEBUG - 2016-05-24 19:12:14 --> Total execution time: 0.0840
INFO - 2016-05-24 19:12:14 --> Config Class Initialized
INFO - 2016-05-24 19:12:14 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:12:14 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:12:14 --> Utf8 Class Initialized
INFO - 2016-05-24 19:12:14 --> URI Class Initialized
INFO - 2016-05-24 19:12:14 --> Router Class Initialized
INFO - 2016-05-24 19:12:14 --> Output Class Initialized
INFO - 2016-05-24 19:12:14 --> Security Class Initialized
DEBUG - 2016-05-24 19:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:12:14 --> Input Class Initialized
INFO - 2016-05-24 19:12:14 --> Language Class Initialized
INFO - 2016-05-24 19:12:14 --> Loader Class Initialized
INFO - 2016-05-24 19:12:14 --> Helper loaded: url_helper
INFO - 2016-05-24 19:12:14 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:12:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:12:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:12:14 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:12:14 --> Helper loaded: form_helper
INFO - 2016-05-24 19:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:12:14 --> Form Validation Class Initialized
INFO - 2016-05-24 19:12:14 --> Controller Class Initialized
INFO - 2016-05-24 19:12:14 --> Model Class Initialized
INFO - 2016-05-24 19:12:14 --> Database Driver Class Initialized
INFO - 2016-05-24 19:12:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:12:14 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:12:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:12:14 --> Final output sent to browser
DEBUG - 2016-05-24 19:12:14 --> Total execution time: 0.1046
INFO - 2016-05-24 19:12:20 --> Config Class Initialized
INFO - 2016-05-24 19:12:20 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:12:20 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:12:20 --> Utf8 Class Initialized
INFO - 2016-05-24 19:12:20 --> URI Class Initialized
INFO - 2016-05-24 19:12:20 --> Router Class Initialized
INFO - 2016-05-24 19:12:20 --> Output Class Initialized
INFO - 2016-05-24 19:12:20 --> Security Class Initialized
DEBUG - 2016-05-24 19:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:12:20 --> Input Class Initialized
INFO - 2016-05-24 19:12:20 --> Language Class Initialized
INFO - 2016-05-24 19:12:20 --> Loader Class Initialized
INFO - 2016-05-24 19:12:20 --> Helper loaded: url_helper
INFO - 2016-05-24 19:12:20 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:12:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:12:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:12:20 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:12:20 --> Helper loaded: form_helper
INFO - 2016-05-24 19:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:12:20 --> Form Validation Class Initialized
INFO - 2016-05-24 19:12:20 --> Controller Class Initialized
INFO - 2016-05-24 19:12:20 --> Model Class Initialized
INFO - 2016-05-24 19:12:20 --> Database Driver Class Initialized
INFO - 2016-05-24 19:12:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 19:12:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:12:20 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:12:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:12:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-24 19:12:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:12:20 --> Final output sent to browser
DEBUG - 2016-05-24 19:12:20 --> Total execution time: 0.1159
INFO - 2016-05-24 19:12:21 --> Config Class Initialized
INFO - 2016-05-24 19:12:21 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:12:21 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:12:21 --> Utf8 Class Initialized
INFO - 2016-05-24 19:12:21 --> URI Class Initialized
INFO - 2016-05-24 19:12:21 --> Router Class Initialized
INFO - 2016-05-24 19:12:21 --> Output Class Initialized
INFO - 2016-05-24 19:12:21 --> Security Class Initialized
DEBUG - 2016-05-24 19:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:12:21 --> Input Class Initialized
INFO - 2016-05-24 19:12:21 --> Language Class Initialized
INFO - 2016-05-24 19:12:21 --> Loader Class Initialized
INFO - 2016-05-24 19:12:21 --> Helper loaded: url_helper
INFO - 2016-05-24 19:12:21 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:12:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:12:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:12:21 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:12:21 --> Helper loaded: form_helper
INFO - 2016-05-24 19:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:12:21 --> Form Validation Class Initialized
INFO - 2016-05-24 19:12:21 --> Controller Class Initialized
INFO - 2016-05-24 19:12:21 --> Model Class Initialized
INFO - 2016-05-24 19:12:21 --> Database Driver Class Initialized
INFO - 2016-05-24 19:12:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:12:21 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:12:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:12:21 --> Final output sent to browser
DEBUG - 2016-05-24 19:12:21 --> Total execution time: 0.1194
INFO - 2016-05-24 19:16:08 --> Config Class Initialized
INFO - 2016-05-24 19:16:08 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:08 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:08 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:08 --> URI Class Initialized
INFO - 2016-05-24 19:16:08 --> Router Class Initialized
INFO - 2016-05-24 19:16:08 --> Output Class Initialized
INFO - 2016-05-24 19:16:08 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:08 --> Input Class Initialized
INFO - 2016-05-24 19:16:08 --> Language Class Initialized
INFO - 2016-05-24 19:16:08 --> Loader Class Initialized
INFO - 2016-05-24 19:16:08 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:08 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:08 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:08 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:08 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:08 --> Controller Class Initialized
INFO - 2016-05-24 19:16:08 --> Model Class Initialized
INFO - 2016-05-24 19:16:08 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 19:16:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:16:08 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:16:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:16:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-24 19:16:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:16:08 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:08 --> Total execution time: 0.0971
INFO - 2016-05-24 19:16:08 --> Config Class Initialized
INFO - 2016-05-24 19:16:08 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:08 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:08 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:08 --> URI Class Initialized
INFO - 2016-05-24 19:16:08 --> Router Class Initialized
INFO - 2016-05-24 19:16:08 --> Output Class Initialized
INFO - 2016-05-24 19:16:08 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:08 --> Input Class Initialized
INFO - 2016-05-24 19:16:08 --> Language Class Initialized
INFO - 2016-05-24 19:16:08 --> Loader Class Initialized
INFO - 2016-05-24 19:16:08 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:08 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:08 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:08 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:08 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:08 --> Controller Class Initialized
INFO - 2016-05-24 19:16:08 --> Model Class Initialized
INFO - 2016-05-24 19:16:08 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:16:08 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:16:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:16:08 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:08 --> Total execution time: 0.0935
INFO - 2016-05-24 19:16:10 --> Config Class Initialized
INFO - 2016-05-24 19:16:10 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:10 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:10 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:10 --> URI Class Initialized
INFO - 2016-05-24 19:16:10 --> Router Class Initialized
INFO - 2016-05-24 19:16:10 --> Output Class Initialized
INFO - 2016-05-24 19:16:10 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:10 --> Input Class Initialized
INFO - 2016-05-24 19:16:10 --> Language Class Initialized
INFO - 2016-05-24 19:16:10 --> Loader Class Initialized
INFO - 2016-05-24 19:16:10 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:10 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:10 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:10 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:10 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:10 --> Controller Class Initialized
INFO - 2016-05-24 19:16:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 19:16:10 --> Helper loaded: nif_validate_helper
INFO - 2016-05-24 19:16:10 --> Model Class Initialized
INFO - 2016-05-24 19:16:10 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-24 19:16:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:16:10 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:10 --> Total execution time: 0.1113
INFO - 2016-05-24 19:16:10 --> Config Class Initialized
INFO - 2016-05-24 19:16:10 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:10 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:10 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:10 --> URI Class Initialized
INFO - 2016-05-24 19:16:10 --> Router Class Initialized
INFO - 2016-05-24 19:16:10 --> Output Class Initialized
INFO - 2016-05-24 19:16:10 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:10 --> Input Class Initialized
INFO - 2016-05-24 19:16:10 --> Language Class Initialized
INFO - 2016-05-24 19:16:10 --> Loader Class Initialized
INFO - 2016-05-24 19:16:10 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:10 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:10 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:10 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:10 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:10 --> Controller Class Initialized
INFO - 2016-05-24 19:16:10 --> Model Class Initialized
INFO - 2016-05-24 19:16:10 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:16:10 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:16:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:16:10 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:10 --> Total execution time: 0.1011
INFO - 2016-05-24 19:16:12 --> Config Class Initialized
INFO - 2016-05-24 19:16:12 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:12 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:12 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:12 --> URI Class Initialized
INFO - 2016-05-24 19:16:12 --> Router Class Initialized
INFO - 2016-05-24 19:16:12 --> Output Class Initialized
INFO - 2016-05-24 19:16:12 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:12 --> Input Class Initialized
INFO - 2016-05-24 19:16:12 --> Language Class Initialized
INFO - 2016-05-24 19:16:12 --> Loader Class Initialized
INFO - 2016-05-24 19:16:12 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:12 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:12 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:12 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:12 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:12 --> Controller Class Initialized
INFO - 2016-05-24 19:16:12 --> Model Class Initialized
INFO - 2016-05-24 19:16:12 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 19:16:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:16:12 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:16:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:16:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-24 19:16:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:16:12 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:12 --> Total execution time: 0.1176
INFO - 2016-05-24 19:16:12 --> Config Class Initialized
INFO - 2016-05-24 19:16:12 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:12 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:12 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:12 --> URI Class Initialized
INFO - 2016-05-24 19:16:12 --> Router Class Initialized
INFO - 2016-05-24 19:16:12 --> Output Class Initialized
INFO - 2016-05-24 19:16:12 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:12 --> Input Class Initialized
INFO - 2016-05-24 19:16:12 --> Language Class Initialized
INFO - 2016-05-24 19:16:12 --> Loader Class Initialized
INFO - 2016-05-24 19:16:12 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:12 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:12 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:12 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:12 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:12 --> Controller Class Initialized
INFO - 2016-05-24 19:16:12 --> Model Class Initialized
INFO - 2016-05-24 19:16:12 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:16:12 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:16:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:16:12 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:12 --> Total execution time: 0.1138
INFO - 2016-05-24 19:16:16 --> Config Class Initialized
INFO - 2016-05-24 19:16:16 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:16 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:16 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:16 --> URI Class Initialized
INFO - 2016-05-24 19:16:16 --> Router Class Initialized
INFO - 2016-05-24 19:16:16 --> Output Class Initialized
INFO - 2016-05-24 19:16:16 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:16 --> Input Class Initialized
INFO - 2016-05-24 19:16:16 --> Language Class Initialized
INFO - 2016-05-24 19:16:16 --> Loader Class Initialized
INFO - 2016-05-24 19:16:16 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:16 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:16 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:16 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:16 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:16 --> Controller Class Initialized
INFO - 2016-05-24 19:16:16 --> Model Class Initialized
INFO - 2016-05-24 19:16:16 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:16 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 19:16:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:16:16 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:16:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:16:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-24 19:16:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:16:16 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:16 --> Total execution time: 0.1269
INFO - 2016-05-24 19:16:16 --> Config Class Initialized
INFO - 2016-05-24 19:16:16 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:16 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:16 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:16 --> URI Class Initialized
INFO - 2016-05-24 19:16:16 --> Router Class Initialized
INFO - 2016-05-24 19:16:16 --> Output Class Initialized
INFO - 2016-05-24 19:16:16 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:16 --> Input Class Initialized
INFO - 2016-05-24 19:16:16 --> Language Class Initialized
INFO - 2016-05-24 19:16:16 --> Loader Class Initialized
INFO - 2016-05-24 19:16:16 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:16 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:16 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:16 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:16 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:16 --> Controller Class Initialized
INFO - 2016-05-24 19:16:16 --> Model Class Initialized
INFO - 2016-05-24 19:16:16 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:16:16 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:16:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:16:16 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:16 --> Total execution time: 0.1054
INFO - 2016-05-24 19:16:20 --> Config Class Initialized
INFO - 2016-05-24 19:16:20 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:20 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:20 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:20 --> URI Class Initialized
INFO - 2016-05-24 19:16:20 --> Router Class Initialized
INFO - 2016-05-24 19:16:20 --> Output Class Initialized
INFO - 2016-05-24 19:16:20 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:20 --> Input Class Initialized
INFO - 2016-05-24 19:16:20 --> Language Class Initialized
INFO - 2016-05-24 19:16:20 --> Loader Class Initialized
INFO - 2016-05-24 19:16:20 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:20 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:20 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:20 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:20 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:20 --> Controller Class Initialized
INFO - 2016-05-24 19:16:20 --> Model Class Initialized
INFO - 2016-05-24 19:16:21 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 19:16:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:16:21 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:16:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:16:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-24 19:16:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:16:21 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:21 --> Total execution time: 0.1155
INFO - 2016-05-24 19:16:21 --> Config Class Initialized
INFO - 2016-05-24 19:16:21 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:21 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:21 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:21 --> URI Class Initialized
INFO - 2016-05-24 19:16:21 --> Router Class Initialized
INFO - 2016-05-24 19:16:21 --> Output Class Initialized
INFO - 2016-05-24 19:16:21 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:21 --> Input Class Initialized
INFO - 2016-05-24 19:16:21 --> Language Class Initialized
INFO - 2016-05-24 19:16:21 --> Loader Class Initialized
INFO - 2016-05-24 19:16:21 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:21 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:21 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:21 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:21 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:21 --> Controller Class Initialized
INFO - 2016-05-24 19:16:21 --> Model Class Initialized
INFO - 2016-05-24 19:16:21 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:16:21 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:16:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:16:21 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:21 --> Total execution time: 0.1056
INFO - 2016-05-24 19:16:24 --> Config Class Initialized
INFO - 2016-05-24 19:16:24 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:24 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:24 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:24 --> URI Class Initialized
INFO - 2016-05-24 19:16:24 --> Router Class Initialized
INFO - 2016-05-24 19:16:24 --> Output Class Initialized
INFO - 2016-05-24 19:16:24 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:24 --> Input Class Initialized
INFO - 2016-05-24 19:16:24 --> Language Class Initialized
INFO - 2016-05-24 19:16:24 --> Loader Class Initialized
INFO - 2016-05-24 19:16:24 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:24 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:24 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:24 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:24 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:24 --> Controller Class Initialized
INFO - 2016-05-24 19:16:24 --> Model Class Initialized
INFO - 2016-05-24 19:16:24 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:24 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 19:16:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:16:24 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:16:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:16:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-24 19:16:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:16:24 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:24 --> Total execution time: 0.1408
INFO - 2016-05-24 19:16:25 --> Config Class Initialized
INFO - 2016-05-24 19:16:25 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:25 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:25 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:25 --> URI Class Initialized
INFO - 2016-05-24 19:16:25 --> Router Class Initialized
INFO - 2016-05-24 19:16:25 --> Output Class Initialized
INFO - 2016-05-24 19:16:25 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:25 --> Input Class Initialized
INFO - 2016-05-24 19:16:25 --> Language Class Initialized
INFO - 2016-05-24 19:16:25 --> Loader Class Initialized
INFO - 2016-05-24 19:16:25 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:25 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:25 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:25 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:25 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:25 --> Controller Class Initialized
INFO - 2016-05-24 19:16:25 --> Model Class Initialized
INFO - 2016-05-24 19:16:25 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:16:25 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:16:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:16:25 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:25 --> Total execution time: 0.1123
INFO - 2016-05-24 19:16:27 --> Config Class Initialized
INFO - 2016-05-24 19:16:27 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:27 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:27 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:27 --> URI Class Initialized
INFO - 2016-05-24 19:16:27 --> Router Class Initialized
INFO - 2016-05-24 19:16:27 --> Output Class Initialized
INFO - 2016-05-24 19:16:27 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:27 --> Input Class Initialized
INFO - 2016-05-24 19:16:27 --> Language Class Initialized
INFO - 2016-05-24 19:16:27 --> Loader Class Initialized
INFO - 2016-05-24 19:16:27 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:27 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:27 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:27 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:27 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:27 --> Controller Class Initialized
INFO - 2016-05-24 19:16:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-24 19:16:27 --> Model Class Initialized
INFO - 2016-05-24 19:16:27 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:16:27 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:27 --> Total execution time: 0.0785
INFO - 2016-05-24 19:16:27 --> Config Class Initialized
INFO - 2016-05-24 19:16:27 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:27 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:27 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:27 --> URI Class Initialized
INFO - 2016-05-24 19:16:27 --> Router Class Initialized
INFO - 2016-05-24 19:16:27 --> Output Class Initialized
INFO - 2016-05-24 19:16:27 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:27 --> Input Class Initialized
INFO - 2016-05-24 19:16:27 --> Language Class Initialized
INFO - 2016-05-24 19:16:27 --> Loader Class Initialized
INFO - 2016-05-24 19:16:27 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:27 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:27 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:27 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:27 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:27 --> Controller Class Initialized
INFO - 2016-05-24 19:16:27 --> Model Class Initialized
INFO - 2016-05-24 19:16:27 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:16:27 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:16:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:16:27 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:27 --> Total execution time: 0.1037
INFO - 2016-05-24 19:16:28 --> Config Class Initialized
INFO - 2016-05-24 19:16:28 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:28 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:28 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:28 --> URI Class Initialized
INFO - 2016-05-24 19:16:28 --> Router Class Initialized
INFO - 2016-05-24 19:16:28 --> Output Class Initialized
INFO - 2016-05-24 19:16:28 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:28 --> Input Class Initialized
INFO - 2016-05-24 19:16:28 --> Language Class Initialized
INFO - 2016-05-24 19:16:28 --> Loader Class Initialized
INFO - 2016-05-24 19:16:28 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:28 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:28 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:28 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:28 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:28 --> Controller Class Initialized
INFO - 2016-05-24 19:16:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-24 19:16:28 --> Model Class Initialized
INFO - 2016-05-24 19:16:28 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:16:28 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:28 --> Total execution time: 0.0775
INFO - 2016-05-24 19:16:29 --> Config Class Initialized
INFO - 2016-05-24 19:16:29 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:16:29 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:16:29 --> Utf8 Class Initialized
INFO - 2016-05-24 19:16:29 --> URI Class Initialized
INFO - 2016-05-24 19:16:29 --> Router Class Initialized
INFO - 2016-05-24 19:16:29 --> Output Class Initialized
INFO - 2016-05-24 19:16:29 --> Security Class Initialized
DEBUG - 2016-05-24 19:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:16:29 --> Input Class Initialized
INFO - 2016-05-24 19:16:29 --> Language Class Initialized
INFO - 2016-05-24 19:16:29 --> Loader Class Initialized
INFO - 2016-05-24 19:16:29 --> Helper loaded: url_helper
INFO - 2016-05-24 19:16:29 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:16:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:16:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:16:29 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:16:29 --> Helper loaded: form_helper
INFO - 2016-05-24 19:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:16:29 --> Form Validation Class Initialized
INFO - 2016-05-24 19:16:29 --> Controller Class Initialized
INFO - 2016-05-24 19:16:29 --> Model Class Initialized
INFO - 2016-05-24 19:16:29 --> Database Driver Class Initialized
INFO - 2016-05-24 19:16:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:16:29 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:16:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:16:29 --> Final output sent to browser
DEBUG - 2016-05-24 19:16:29 --> Total execution time: 0.1256
