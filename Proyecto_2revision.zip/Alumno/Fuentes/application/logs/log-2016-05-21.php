<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-21 09:30:29 --> Config Class Initialized
INFO - 2016-05-21 09:30:29 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:30:29 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:30:29 --> Utf8 Class Initialized
INFO - 2016-05-21 09:30:29 --> URI Class Initialized
INFO - 2016-05-21 09:30:29 --> Router Class Initialized
INFO - 2016-05-21 09:30:29 --> Output Class Initialized
INFO - 2016-05-21 09:30:29 --> Security Class Initialized
DEBUG - 2016-05-21 09:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:30:29 --> Input Class Initialized
INFO - 2016-05-21 09:30:29 --> Language Class Initialized
INFO - 2016-05-21 09:30:29 --> Loader Class Initialized
INFO - 2016-05-21 09:30:29 --> Helper loaded: url_helper
INFO - 2016-05-21 09:30:29 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:30:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:30:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:30:29 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:30:29 --> Helper loaded: form_helper
INFO - 2016-05-21 09:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:30:29 --> Form Validation Class Initialized
INFO - 2016-05-21 09:30:29 --> Controller Class Initialized
INFO - 2016-05-21 09:30:29 --> Config Class Initialized
INFO - 2016-05-21 09:30:29 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:30:29 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:30:29 --> Utf8 Class Initialized
INFO - 2016-05-21 09:30:29 --> URI Class Initialized
INFO - 2016-05-21 09:30:29 --> Router Class Initialized
INFO - 2016-05-21 09:30:29 --> Output Class Initialized
INFO - 2016-05-21 09:30:29 --> Security Class Initialized
DEBUG - 2016-05-21 09:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:30:29 --> Input Class Initialized
INFO - 2016-05-21 09:30:29 --> Language Class Initialized
INFO - 2016-05-21 09:30:29 --> Loader Class Initialized
INFO - 2016-05-21 09:30:29 --> Helper loaded: url_helper
INFO - 2016-05-21 09:30:29 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:30:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:30:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:30:29 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:30:29 --> Helper loaded: form_helper
INFO - 2016-05-21 09:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:30:29 --> Form Validation Class Initialized
INFO - 2016-05-21 09:30:29 --> Controller Class Initialized
INFO - 2016-05-21 09:30:29 --> Model Class Initialized
INFO - 2016-05-21 09:30:29 --> Database Driver Class Initialized
INFO - 2016-05-21 09:30:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-21 09:30:30 --> Final output sent to browser
DEBUG - 2016-05-21 09:30:30 --> Total execution time: 0.1074
INFO - 2016-05-21 09:30:42 --> Config Class Initialized
INFO - 2016-05-21 09:30:42 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:30:42 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:30:42 --> Utf8 Class Initialized
INFO - 2016-05-21 09:30:42 --> URI Class Initialized
INFO - 2016-05-21 09:30:42 --> Router Class Initialized
INFO - 2016-05-21 09:30:42 --> Output Class Initialized
INFO - 2016-05-21 09:30:42 --> Security Class Initialized
DEBUG - 2016-05-21 09:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:30:42 --> Input Class Initialized
INFO - 2016-05-21 09:30:42 --> Language Class Initialized
INFO - 2016-05-21 09:30:42 --> Loader Class Initialized
INFO - 2016-05-21 09:30:42 --> Helper loaded: url_helper
INFO - 2016-05-21 09:30:42 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:30:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:30:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:30:42 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:30:42 --> Helper loaded: form_helper
INFO - 2016-05-21 09:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:30:42 --> Form Validation Class Initialized
INFO - 2016-05-21 09:30:42 --> Controller Class Initialized
INFO - 2016-05-21 09:30:42 --> Model Class Initialized
INFO - 2016-05-21 09:30:42 --> Database Driver Class Initialized
INFO - 2016-05-21 09:30:42 --> Config Class Initialized
INFO - 2016-05-21 09:30:42 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:30:42 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:30:42 --> Utf8 Class Initialized
INFO - 2016-05-21 09:30:42 --> URI Class Initialized
INFO - 2016-05-21 09:30:42 --> Router Class Initialized
INFO - 2016-05-21 09:30:42 --> Output Class Initialized
INFO - 2016-05-21 09:30:42 --> Security Class Initialized
DEBUG - 2016-05-21 09:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:30:42 --> Input Class Initialized
INFO - 2016-05-21 09:30:42 --> Language Class Initialized
INFO - 2016-05-21 09:30:42 --> Loader Class Initialized
INFO - 2016-05-21 09:30:42 --> Helper loaded: url_helper
INFO - 2016-05-21 09:30:42 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:30:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:30:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:30:42 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:30:42 --> Helper loaded: form_helper
INFO - 2016-05-21 09:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:30:42 --> Form Validation Class Initialized
INFO - 2016-05-21 09:30:42 --> Controller Class Initialized
INFO - 2016-05-21 09:30:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-21 09:30:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 09:30:42 --> Final output sent to browser
DEBUG - 2016-05-21 09:30:42 --> Total execution time: 0.0516
INFO - 2016-05-21 09:30:43 --> Config Class Initialized
INFO - 2016-05-21 09:30:43 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:30:43 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:30:43 --> Utf8 Class Initialized
INFO - 2016-05-21 09:30:43 --> URI Class Initialized
INFO - 2016-05-21 09:30:43 --> Router Class Initialized
INFO - 2016-05-21 09:30:43 --> Output Class Initialized
INFO - 2016-05-21 09:30:43 --> Security Class Initialized
DEBUG - 2016-05-21 09:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:30:43 --> Input Class Initialized
INFO - 2016-05-21 09:30:43 --> Language Class Initialized
INFO - 2016-05-21 09:30:43 --> Loader Class Initialized
INFO - 2016-05-21 09:30:43 --> Helper loaded: url_helper
INFO - 2016-05-21 09:30:43 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:30:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:30:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:30:43 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:30:43 --> Helper loaded: form_helper
INFO - 2016-05-21 09:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:30:43 --> Form Validation Class Initialized
INFO - 2016-05-21 09:30:43 --> Controller Class Initialized
INFO - 2016-05-21 09:30:43 --> Model Class Initialized
INFO - 2016-05-21 09:30:43 --> Database Driver Class Initialized
INFO - 2016-05-21 09:30:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:30:43 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:30:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:30:44 --> Final output sent to browser
DEBUG - 2016-05-21 09:30:44 --> Total execution time: 0.5540
INFO - 2016-05-21 09:30:56 --> Config Class Initialized
INFO - 2016-05-21 09:30:56 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:30:56 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:30:56 --> Utf8 Class Initialized
INFO - 2016-05-21 09:30:56 --> URI Class Initialized
INFO - 2016-05-21 09:30:56 --> Router Class Initialized
INFO - 2016-05-21 09:30:56 --> Output Class Initialized
INFO - 2016-05-21 09:30:56 --> Security Class Initialized
DEBUG - 2016-05-21 09:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:30:56 --> Input Class Initialized
INFO - 2016-05-21 09:30:56 --> Language Class Initialized
INFO - 2016-05-21 09:30:56 --> Loader Class Initialized
INFO - 2016-05-21 09:30:57 --> Helper loaded: url_helper
INFO - 2016-05-21 09:30:57 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:30:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:30:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:30:57 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:30:57 --> Helper loaded: form_helper
INFO - 2016-05-21 09:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:30:57 --> Form Validation Class Initialized
INFO - 2016-05-21 09:30:57 --> Controller Class Initialized
INFO - 2016-05-21 09:30:57 --> Model Class Initialized
INFO - 2016-05-21 09:30:57 --> Database Driver Class Initialized
INFO - 2016-05-21 09:30:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:30:57 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:30:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:30:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 09:30:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 09:30:57 --> Final output sent to browser
DEBUG - 2016-05-21 09:30:57 --> Total execution time: 0.4353
INFO - 2016-05-21 09:30:57 --> Config Class Initialized
INFO - 2016-05-21 09:30:57 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:30:57 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:30:57 --> Utf8 Class Initialized
INFO - 2016-05-21 09:30:57 --> URI Class Initialized
INFO - 2016-05-21 09:30:57 --> Router Class Initialized
INFO - 2016-05-21 09:30:57 --> Output Class Initialized
INFO - 2016-05-21 09:30:57 --> Security Class Initialized
DEBUG - 2016-05-21 09:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:30:57 --> Input Class Initialized
INFO - 2016-05-21 09:30:57 --> Language Class Initialized
INFO - 2016-05-21 09:30:57 --> Loader Class Initialized
INFO - 2016-05-21 09:30:57 --> Helper loaded: url_helper
INFO - 2016-05-21 09:30:57 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:30:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:30:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:30:57 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:30:57 --> Helper loaded: form_helper
INFO - 2016-05-21 09:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:30:57 --> Form Validation Class Initialized
INFO - 2016-05-21 09:30:57 --> Controller Class Initialized
INFO - 2016-05-21 09:30:57 --> Model Class Initialized
INFO - 2016-05-21 09:30:57 --> Database Driver Class Initialized
INFO - 2016-05-21 09:30:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:30:57 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:30:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:30:57 --> Final output sent to browser
DEBUG - 2016-05-21 09:30:57 --> Total execution time: 0.0882
INFO - 2016-05-21 09:31:04 --> Config Class Initialized
INFO - 2016-05-21 09:31:04 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:31:04 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:31:04 --> Utf8 Class Initialized
INFO - 2016-05-21 09:31:04 --> URI Class Initialized
INFO - 2016-05-21 09:31:04 --> Router Class Initialized
INFO - 2016-05-21 09:31:04 --> Output Class Initialized
INFO - 2016-05-21 09:31:04 --> Security Class Initialized
DEBUG - 2016-05-21 09:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:31:04 --> Input Class Initialized
INFO - 2016-05-21 09:31:04 --> Language Class Initialized
INFO - 2016-05-21 09:31:04 --> Loader Class Initialized
INFO - 2016-05-21 09:31:04 --> Helper loaded: url_helper
INFO - 2016-05-21 09:31:04 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:31:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:31:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:31:04 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:31:04 --> Helper loaded: form_helper
INFO - 2016-05-21 09:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:31:04 --> Form Validation Class Initialized
INFO - 2016-05-21 09:31:04 --> Controller Class Initialized
INFO - 2016-05-21 09:31:04 --> Model Class Initialized
INFO - 2016-05-21 09:31:04 --> Database Driver Class Initialized
INFO - 2016-05-21 09:31:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-21 09:31:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:31:04 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:31:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:31:04 --> Helper loaded: nif_validate_helper
INFO - 2016-05-21 09:31:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-21 09:31:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 09:31:04 --> Final output sent to browser
DEBUG - 2016-05-21 09:31:04 --> Total execution time: 0.2321
INFO - 2016-05-21 09:31:04 --> Config Class Initialized
INFO - 2016-05-21 09:31:04 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:31:04 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:31:04 --> Utf8 Class Initialized
INFO - 2016-05-21 09:31:04 --> URI Class Initialized
INFO - 2016-05-21 09:31:04 --> Router Class Initialized
INFO - 2016-05-21 09:31:04 --> Output Class Initialized
INFO - 2016-05-21 09:31:04 --> Security Class Initialized
DEBUG - 2016-05-21 09:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:31:04 --> Input Class Initialized
INFO - 2016-05-21 09:31:04 --> Language Class Initialized
INFO - 2016-05-21 09:31:04 --> Loader Class Initialized
INFO - 2016-05-21 09:31:04 --> Helper loaded: url_helper
INFO - 2016-05-21 09:31:04 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:31:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:31:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:31:04 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:31:04 --> Helper loaded: form_helper
INFO - 2016-05-21 09:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:31:04 --> Form Validation Class Initialized
INFO - 2016-05-21 09:31:04 --> Controller Class Initialized
INFO - 2016-05-21 09:31:04 --> Model Class Initialized
INFO - 2016-05-21 09:31:04 --> Database Driver Class Initialized
INFO - 2016-05-21 09:31:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:31:04 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:31:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:31:04 --> Final output sent to browser
DEBUG - 2016-05-21 09:31:04 --> Total execution time: 0.0910
INFO - 2016-05-21 09:31:06 --> Config Class Initialized
INFO - 2016-05-21 09:31:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:31:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:31:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:31:06 --> URI Class Initialized
INFO - 2016-05-21 09:31:06 --> Router Class Initialized
INFO - 2016-05-21 09:31:06 --> Output Class Initialized
INFO - 2016-05-21 09:31:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:31:06 --> Input Class Initialized
INFO - 2016-05-21 09:31:06 --> Language Class Initialized
INFO - 2016-05-21 09:31:06 --> Loader Class Initialized
INFO - 2016-05-21 09:31:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:31:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:31:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:31:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:31:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:31:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:31:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:31:06 --> Controller Class Initialized
INFO - 2016-05-21 09:31:06 --> Model Class Initialized
INFO - 2016-05-21 09:31:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:31:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:31:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:31:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:31:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 09:31:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 09:31:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:31:06 --> Total execution time: 0.0842
INFO - 2016-05-21 09:31:07 --> Config Class Initialized
INFO - 2016-05-21 09:31:07 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:31:07 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:31:07 --> Utf8 Class Initialized
INFO - 2016-05-21 09:31:07 --> URI Class Initialized
INFO - 2016-05-21 09:31:07 --> Router Class Initialized
INFO - 2016-05-21 09:31:07 --> Output Class Initialized
INFO - 2016-05-21 09:31:07 --> Security Class Initialized
DEBUG - 2016-05-21 09:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:31:07 --> Input Class Initialized
INFO - 2016-05-21 09:31:07 --> Language Class Initialized
INFO - 2016-05-21 09:31:07 --> Loader Class Initialized
INFO - 2016-05-21 09:31:07 --> Helper loaded: url_helper
INFO - 2016-05-21 09:31:07 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:31:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:31:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:31:07 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:31:07 --> Helper loaded: form_helper
INFO - 2016-05-21 09:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:31:07 --> Form Validation Class Initialized
INFO - 2016-05-21 09:31:07 --> Controller Class Initialized
INFO - 2016-05-21 09:31:07 --> Model Class Initialized
INFO - 2016-05-21 09:31:07 --> Database Driver Class Initialized
INFO - 2016-05-21 09:31:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:31:07 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:31:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:31:07 --> Final output sent to browser
DEBUG - 2016-05-21 09:31:07 --> Total execution time: 0.0917
INFO - 2016-05-21 09:32:00 --> Config Class Initialized
INFO - 2016-05-21 09:32:00 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:32:00 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:32:00 --> Utf8 Class Initialized
INFO - 2016-05-21 09:32:00 --> URI Class Initialized
INFO - 2016-05-21 09:32:00 --> Router Class Initialized
INFO - 2016-05-21 09:32:00 --> Output Class Initialized
INFO - 2016-05-21 09:32:00 --> Security Class Initialized
DEBUG - 2016-05-21 09:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:32:00 --> Input Class Initialized
INFO - 2016-05-21 09:32:00 --> Language Class Initialized
INFO - 2016-05-21 09:32:00 --> Loader Class Initialized
INFO - 2016-05-21 09:32:00 --> Helper loaded: url_helper
INFO - 2016-05-21 09:32:00 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:32:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:32:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:32:00 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:32:00 --> Helper loaded: form_helper
INFO - 2016-05-21 09:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:32:00 --> Form Validation Class Initialized
INFO - 2016-05-21 09:32:00 --> Controller Class Initialized
INFO - 2016-05-21 09:32:00 --> Model Class Initialized
INFO - 2016-05-21 09:32:00 --> Database Driver Class Initialized
INFO - 2016-05-21 09:32:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:32:00 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:32:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-21 09:32:00 --> Severity: Notice --> Undefined index: nombre C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 58
ERROR - 2016-05-21 09:32:00 --> Severity: Notice --> Undefined index: nombre C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 58
ERROR - 2016-05-21 09:32:00 --> Severity: Notice --> Undefined index: nombre C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 58
ERROR - 2016-05-21 09:32:00 --> Severity: Notice --> Undefined index: nombre C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 58
ERROR - 2016-05-21 09:32:00 --> Severity: Notice --> Undefined index: nombre C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 58
ERROR - 2016-05-21 09:32:00 --> Severity: Notice --> Undefined index: nombre C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 58
INFO - 2016-05-21 09:32:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 09:32:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 09:32:00 --> Final output sent to browser
DEBUG - 2016-05-21 09:32:00 --> Total execution time: 0.2097
INFO - 2016-05-21 09:32:02 --> Config Class Initialized
INFO - 2016-05-21 09:32:02 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:32:02 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:32:02 --> Utf8 Class Initialized
INFO - 2016-05-21 09:32:02 --> URI Class Initialized
INFO - 2016-05-21 09:32:02 --> Router Class Initialized
INFO - 2016-05-21 09:32:02 --> Output Class Initialized
INFO - 2016-05-21 09:32:02 --> Security Class Initialized
DEBUG - 2016-05-21 09:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:32:02 --> Input Class Initialized
INFO - 2016-05-21 09:32:02 --> Language Class Initialized
INFO - 2016-05-21 09:32:02 --> Loader Class Initialized
INFO - 2016-05-21 09:32:02 --> Helper loaded: url_helper
INFO - 2016-05-21 09:32:02 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:32:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:32:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:32:02 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:32:02 --> Helper loaded: form_helper
INFO - 2016-05-21 09:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:32:02 --> Form Validation Class Initialized
INFO - 2016-05-21 09:32:02 --> Controller Class Initialized
INFO - 2016-05-21 09:32:02 --> Model Class Initialized
INFO - 2016-05-21 09:32:02 --> Database Driver Class Initialized
INFO - 2016-05-21 09:32:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:32:02 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:32:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:32:02 --> Final output sent to browser
DEBUG - 2016-05-21 09:32:02 --> Total execution time: 0.1153
INFO - 2016-05-21 09:33:00 --> Config Class Initialized
INFO - 2016-05-21 09:33:00 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:33:00 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:33:00 --> Utf8 Class Initialized
INFO - 2016-05-21 09:33:00 --> URI Class Initialized
INFO - 2016-05-21 09:33:00 --> Router Class Initialized
INFO - 2016-05-21 09:33:00 --> Output Class Initialized
INFO - 2016-05-21 09:33:00 --> Security Class Initialized
DEBUG - 2016-05-21 09:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:33:00 --> Input Class Initialized
INFO - 2016-05-21 09:33:00 --> Language Class Initialized
INFO - 2016-05-21 09:33:00 --> Loader Class Initialized
INFO - 2016-05-21 09:33:00 --> Helper loaded: url_helper
INFO - 2016-05-21 09:33:00 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:33:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:33:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:33:00 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:33:00 --> Helper loaded: form_helper
INFO - 2016-05-21 09:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:33:00 --> Form Validation Class Initialized
INFO - 2016-05-21 09:33:00 --> Controller Class Initialized
INFO - 2016-05-21 09:33:00 --> Model Class Initialized
INFO - 2016-05-21 09:33:00 --> Database Driver Class Initialized
INFO - 2016-05-21 09:33:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:33:00 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:33:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-21 09:33:00 --> Severity: Notice --> Undefined index: nombre C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 59
ERROR - 2016-05-21 09:33:00 --> Severity: Notice --> Undefined index: nombre C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 59
ERROR - 2016-05-21 09:33:00 --> Severity: Notice --> Undefined index: nombre C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 59
ERROR - 2016-05-21 09:33:00 --> Severity: Notice --> Undefined index: nombre C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 59
ERROR - 2016-05-21 09:33:00 --> Severity: Notice --> Undefined index: nombre C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 59
ERROR - 2016-05-21 09:33:00 --> Severity: Notice --> Undefined index: nombre C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 59
INFO - 2016-05-21 09:33:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 09:33:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 09:33:00 --> Final output sent to browser
DEBUG - 2016-05-21 09:33:00 --> Total execution time: 0.0945
INFO - 2016-05-21 09:33:00 --> Config Class Initialized
INFO - 2016-05-21 09:33:00 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:33:00 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:33:00 --> Utf8 Class Initialized
INFO - 2016-05-21 09:33:00 --> URI Class Initialized
INFO - 2016-05-21 09:33:00 --> Router Class Initialized
INFO - 2016-05-21 09:33:00 --> Output Class Initialized
INFO - 2016-05-21 09:33:00 --> Security Class Initialized
DEBUG - 2016-05-21 09:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:33:00 --> Input Class Initialized
INFO - 2016-05-21 09:33:00 --> Language Class Initialized
INFO - 2016-05-21 09:33:00 --> Loader Class Initialized
INFO - 2016-05-21 09:33:00 --> Helper loaded: url_helper
INFO - 2016-05-21 09:33:00 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:33:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:33:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:33:00 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:33:00 --> Helper loaded: form_helper
INFO - 2016-05-21 09:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:33:00 --> Form Validation Class Initialized
INFO - 2016-05-21 09:33:00 --> Controller Class Initialized
INFO - 2016-05-21 09:33:00 --> Model Class Initialized
INFO - 2016-05-21 09:33:00 --> Database Driver Class Initialized
INFO - 2016-05-21 09:33:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:33:00 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:33:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:33:00 --> Final output sent to browser
DEBUG - 2016-05-21 09:33:00 --> Total execution time: 0.0937
INFO - 2016-05-21 09:34:01 --> Config Class Initialized
INFO - 2016-05-21 09:34:01 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:34:01 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:34:01 --> Utf8 Class Initialized
INFO - 2016-05-21 09:34:01 --> URI Class Initialized
INFO - 2016-05-21 09:34:01 --> Router Class Initialized
INFO - 2016-05-21 09:34:01 --> Output Class Initialized
INFO - 2016-05-21 09:34:01 --> Security Class Initialized
DEBUG - 2016-05-21 09:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:34:01 --> Input Class Initialized
INFO - 2016-05-21 09:34:01 --> Language Class Initialized
INFO - 2016-05-21 09:34:01 --> Loader Class Initialized
INFO - 2016-05-21 09:34:01 --> Helper loaded: url_helper
INFO - 2016-05-21 09:34:01 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:34:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:34:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:34:01 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:34:01 --> Helper loaded: form_helper
INFO - 2016-05-21 09:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:34:01 --> Form Validation Class Initialized
INFO - 2016-05-21 09:34:01 --> Controller Class Initialized
INFO - 2016-05-21 09:34:01 --> Model Class Initialized
INFO - 2016-05-21 09:34:01 --> Database Driver Class Initialized
INFO - 2016-05-21 09:34:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:34:01 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:34:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:34:01 --> Final output sent to browser
DEBUG - 2016-05-21 09:34:01 --> Total execution time: 0.0839
INFO - 2016-05-21 09:34:43 --> Config Class Initialized
INFO - 2016-05-21 09:34:43 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:34:43 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:34:43 --> Utf8 Class Initialized
INFO - 2016-05-21 09:34:43 --> URI Class Initialized
INFO - 2016-05-21 09:34:43 --> Router Class Initialized
INFO - 2016-05-21 09:34:43 --> Output Class Initialized
INFO - 2016-05-21 09:34:43 --> Security Class Initialized
DEBUG - 2016-05-21 09:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:34:43 --> Input Class Initialized
INFO - 2016-05-21 09:34:43 --> Language Class Initialized
INFO - 2016-05-21 09:34:43 --> Loader Class Initialized
INFO - 2016-05-21 09:34:43 --> Helper loaded: url_helper
INFO - 2016-05-21 09:34:43 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:34:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:34:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:34:43 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:34:43 --> Helper loaded: form_helper
INFO - 2016-05-21 09:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:34:43 --> Form Validation Class Initialized
INFO - 2016-05-21 09:34:43 --> Controller Class Initialized
INFO - 2016-05-21 09:34:43 --> Model Class Initialized
INFO - 2016-05-21 09:34:43 --> Database Driver Class Initialized
INFO - 2016-05-21 09:34:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:34:43 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:34:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-21 09:34:43 --> Severity: Notice --> Undefined index: num_factura C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 59
ERROR - 2016-05-21 09:34:43 --> Severity: Notice --> Undefined index: num_factura C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 59
ERROR - 2016-05-21 09:34:43 --> Severity: Notice --> Undefined index: num_factura C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 59
ERROR - 2016-05-21 09:34:43 --> Severity: Notice --> Undefined index: num_factura C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 59
ERROR - 2016-05-21 09:34:43 --> Severity: Notice --> Undefined index: num_factura C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 59
ERROR - 2016-05-21 09:34:43 --> Severity: Notice --> Undefined index: num_factura C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 59
INFO - 2016-05-21 09:34:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 09:34:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 09:34:43 --> Final output sent to browser
DEBUG - 2016-05-21 09:34:43 --> Total execution time: 0.1266
INFO - 2016-05-21 09:34:44 --> Config Class Initialized
INFO - 2016-05-21 09:34:44 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:34:44 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:34:44 --> Utf8 Class Initialized
INFO - 2016-05-21 09:34:44 --> URI Class Initialized
INFO - 2016-05-21 09:34:44 --> Router Class Initialized
INFO - 2016-05-21 09:34:44 --> Output Class Initialized
INFO - 2016-05-21 09:34:44 --> Security Class Initialized
DEBUG - 2016-05-21 09:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:34:44 --> Input Class Initialized
INFO - 2016-05-21 09:34:44 --> Language Class Initialized
INFO - 2016-05-21 09:34:44 --> Loader Class Initialized
INFO - 2016-05-21 09:34:44 --> Helper loaded: url_helper
INFO - 2016-05-21 09:34:44 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:34:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:34:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:34:44 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:34:44 --> Helper loaded: form_helper
INFO - 2016-05-21 09:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:34:44 --> Form Validation Class Initialized
INFO - 2016-05-21 09:34:44 --> Controller Class Initialized
INFO - 2016-05-21 09:34:44 --> Model Class Initialized
INFO - 2016-05-21 09:34:44 --> Database Driver Class Initialized
INFO - 2016-05-21 09:34:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:34:44 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:34:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:34:44 --> Final output sent to browser
DEBUG - 2016-05-21 09:34:44 --> Total execution time: 0.1000
INFO - 2016-05-21 09:34:58 --> Config Class Initialized
INFO - 2016-05-21 09:34:58 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:34:58 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:34:58 --> Utf8 Class Initialized
INFO - 2016-05-21 09:34:58 --> URI Class Initialized
INFO - 2016-05-21 09:34:58 --> Router Class Initialized
INFO - 2016-05-21 09:34:58 --> Output Class Initialized
INFO - 2016-05-21 09:34:58 --> Security Class Initialized
DEBUG - 2016-05-21 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:34:58 --> Input Class Initialized
INFO - 2016-05-21 09:34:58 --> Language Class Initialized
INFO - 2016-05-21 09:34:58 --> Loader Class Initialized
INFO - 2016-05-21 09:34:58 --> Helper loaded: url_helper
INFO - 2016-05-21 09:34:58 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:34:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:34:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:34:58 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:34:58 --> Helper loaded: form_helper
INFO - 2016-05-21 09:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:34:58 --> Form Validation Class Initialized
INFO - 2016-05-21 09:34:58 --> Controller Class Initialized
INFO - 2016-05-21 09:34:58 --> Model Class Initialized
INFO - 2016-05-21 09:34:58 --> Database Driver Class Initialized
INFO - 2016-05-21 09:34:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:34:58 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:34:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:34:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 09:34:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 09:34:58 --> Final output sent to browser
DEBUG - 2016-05-21 09:34:58 --> Total execution time: 0.0908
INFO - 2016-05-21 09:34:59 --> Config Class Initialized
INFO - 2016-05-21 09:34:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:34:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:34:59 --> Utf8 Class Initialized
INFO - 2016-05-21 09:34:59 --> URI Class Initialized
INFO - 2016-05-21 09:34:59 --> Router Class Initialized
INFO - 2016-05-21 09:34:59 --> Output Class Initialized
INFO - 2016-05-21 09:34:59 --> Security Class Initialized
DEBUG - 2016-05-21 09:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:34:59 --> Input Class Initialized
INFO - 2016-05-21 09:34:59 --> Language Class Initialized
INFO - 2016-05-21 09:34:59 --> Loader Class Initialized
INFO - 2016-05-21 09:34:59 --> Helper loaded: url_helper
INFO - 2016-05-21 09:34:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:34:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:34:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:34:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:34:59 --> Helper loaded: form_helper
INFO - 2016-05-21 09:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:34:59 --> Form Validation Class Initialized
INFO - 2016-05-21 09:34:59 --> Controller Class Initialized
INFO - 2016-05-21 09:34:59 --> Model Class Initialized
INFO - 2016-05-21 09:34:59 --> Database Driver Class Initialized
INFO - 2016-05-21 09:34:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:34:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:34:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:34:59 --> Final output sent to browser
DEBUG - 2016-05-21 09:34:59 --> Total execution time: 0.0852
INFO - 2016-05-21 09:35:36 --> Config Class Initialized
INFO - 2016-05-21 09:35:36 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:35:36 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:35:36 --> Utf8 Class Initialized
INFO - 2016-05-21 09:35:36 --> URI Class Initialized
INFO - 2016-05-21 09:35:36 --> Router Class Initialized
INFO - 2016-05-21 09:35:36 --> Output Class Initialized
INFO - 2016-05-21 09:35:36 --> Security Class Initialized
DEBUG - 2016-05-21 09:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:35:36 --> Input Class Initialized
INFO - 2016-05-21 09:35:36 --> Language Class Initialized
INFO - 2016-05-21 09:35:36 --> Loader Class Initialized
INFO - 2016-05-21 09:35:36 --> Helper loaded: url_helper
INFO - 2016-05-21 09:35:36 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:35:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:35:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:35:36 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:35:36 --> Helper loaded: form_helper
INFO - 2016-05-21 09:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:35:36 --> Form Validation Class Initialized
INFO - 2016-05-21 09:35:36 --> Controller Class Initialized
INFO - 2016-05-21 09:35:36 --> Model Class Initialized
INFO - 2016-05-21 09:35:36 --> Database Driver Class Initialized
INFO - 2016-05-21 09:35:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:35:36 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:35:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:35:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 09:35:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 09:35:36 --> Final output sent to browser
DEBUG - 2016-05-21 09:35:36 --> Total execution time: 0.0778
INFO - 2016-05-21 09:35:36 --> Config Class Initialized
INFO - 2016-05-21 09:35:36 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:35:36 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:35:36 --> Utf8 Class Initialized
INFO - 2016-05-21 09:35:36 --> URI Class Initialized
INFO - 2016-05-21 09:35:36 --> Router Class Initialized
INFO - 2016-05-21 09:35:36 --> Output Class Initialized
INFO - 2016-05-21 09:35:36 --> Security Class Initialized
DEBUG - 2016-05-21 09:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:35:36 --> Input Class Initialized
INFO - 2016-05-21 09:35:36 --> Language Class Initialized
INFO - 2016-05-21 09:35:36 --> Loader Class Initialized
INFO - 2016-05-21 09:35:36 --> Helper loaded: url_helper
INFO - 2016-05-21 09:35:36 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:35:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:35:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:35:36 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:35:36 --> Helper loaded: form_helper
INFO - 2016-05-21 09:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:35:36 --> Form Validation Class Initialized
INFO - 2016-05-21 09:35:36 --> Controller Class Initialized
INFO - 2016-05-21 09:35:36 --> Model Class Initialized
INFO - 2016-05-21 09:35:36 --> Database Driver Class Initialized
INFO - 2016-05-21 09:35:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:35:37 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:35:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:35:37 --> Final output sent to browser
DEBUG - 2016-05-21 09:35:37 --> Total execution time: 0.0922
INFO - 2016-05-21 09:36:07 --> Config Class Initialized
INFO - 2016-05-21 09:36:07 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:36:07 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:36:07 --> Utf8 Class Initialized
INFO - 2016-05-21 09:36:07 --> URI Class Initialized
INFO - 2016-05-21 09:36:07 --> Router Class Initialized
INFO - 2016-05-21 09:36:07 --> Output Class Initialized
INFO - 2016-05-21 09:36:07 --> Security Class Initialized
DEBUG - 2016-05-21 09:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:36:08 --> Input Class Initialized
INFO - 2016-05-21 09:36:08 --> Language Class Initialized
INFO - 2016-05-21 09:36:08 --> Loader Class Initialized
INFO - 2016-05-21 09:36:08 --> Helper loaded: url_helper
INFO - 2016-05-21 09:36:08 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:36:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:36:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:36:08 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:36:08 --> Helper loaded: form_helper
INFO - 2016-05-21 09:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:36:08 --> Form Validation Class Initialized
INFO - 2016-05-21 09:36:08 --> Controller Class Initialized
INFO - 2016-05-21 09:36:08 --> Model Class Initialized
INFO - 2016-05-21 09:36:08 --> Database Driver Class Initialized
INFO - 2016-05-21 09:36:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:36:08 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:36:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:36:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 09:36:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 09:36:08 --> Final output sent to browser
DEBUG - 2016-05-21 09:36:08 --> Total execution time: 0.1154
INFO - 2016-05-21 09:36:08 --> Config Class Initialized
INFO - 2016-05-21 09:36:08 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:36:08 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:36:08 --> Utf8 Class Initialized
INFO - 2016-05-21 09:36:08 --> URI Class Initialized
INFO - 2016-05-21 09:36:08 --> Router Class Initialized
INFO - 2016-05-21 09:36:08 --> Output Class Initialized
INFO - 2016-05-21 09:36:08 --> Security Class Initialized
DEBUG - 2016-05-21 09:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:36:08 --> Input Class Initialized
INFO - 2016-05-21 09:36:08 --> Language Class Initialized
INFO - 2016-05-21 09:36:08 --> Loader Class Initialized
INFO - 2016-05-21 09:36:08 --> Helper loaded: url_helper
INFO - 2016-05-21 09:36:08 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:36:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:36:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:36:08 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:36:08 --> Helper loaded: form_helper
INFO - 2016-05-21 09:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:36:08 --> Form Validation Class Initialized
INFO - 2016-05-21 09:36:08 --> Controller Class Initialized
INFO - 2016-05-21 09:36:08 --> Model Class Initialized
INFO - 2016-05-21 09:36:08 --> Database Driver Class Initialized
INFO - 2016-05-21 09:36:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:36:08 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:36:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:36:08 --> Final output sent to browser
DEBUG - 2016-05-21 09:36:08 --> Total execution time: 0.1103
INFO - 2016-05-21 09:36:36 --> Config Class Initialized
INFO - 2016-05-21 09:36:36 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:36:36 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:36:36 --> Utf8 Class Initialized
INFO - 2016-05-21 09:36:36 --> URI Class Initialized
INFO - 2016-05-21 09:36:36 --> Router Class Initialized
INFO - 2016-05-21 09:36:36 --> Output Class Initialized
INFO - 2016-05-21 09:36:36 --> Security Class Initialized
DEBUG - 2016-05-21 09:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:36:36 --> Input Class Initialized
INFO - 2016-05-21 09:36:36 --> Language Class Initialized
INFO - 2016-05-21 09:36:36 --> Loader Class Initialized
INFO - 2016-05-21 09:36:36 --> Helper loaded: url_helper
INFO - 2016-05-21 09:36:36 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:36:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:36:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:36:36 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:36:36 --> Helper loaded: form_helper
INFO - 2016-05-21 09:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:36:36 --> Form Validation Class Initialized
INFO - 2016-05-21 09:36:36 --> Controller Class Initialized
INFO - 2016-05-21 09:36:36 --> Model Class Initialized
INFO - 2016-05-21 09:36:36 --> Database Driver Class Initialized
INFO - 2016-05-21 09:36:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:36:36 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:36:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:36:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 09:36:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 09:36:36 --> Final output sent to browser
DEBUG - 2016-05-21 09:36:36 --> Total execution time: 0.0824
INFO - 2016-05-21 09:36:37 --> Config Class Initialized
INFO - 2016-05-21 09:36:37 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:36:37 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:36:37 --> Utf8 Class Initialized
INFO - 2016-05-21 09:36:37 --> URI Class Initialized
INFO - 2016-05-21 09:36:37 --> Router Class Initialized
INFO - 2016-05-21 09:36:37 --> Output Class Initialized
INFO - 2016-05-21 09:36:37 --> Security Class Initialized
DEBUG - 2016-05-21 09:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:36:37 --> Input Class Initialized
INFO - 2016-05-21 09:36:37 --> Language Class Initialized
INFO - 2016-05-21 09:36:37 --> Loader Class Initialized
INFO - 2016-05-21 09:36:37 --> Helper loaded: url_helper
INFO - 2016-05-21 09:36:37 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:36:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:36:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:36:37 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:36:37 --> Helper loaded: form_helper
INFO - 2016-05-21 09:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:36:37 --> Form Validation Class Initialized
INFO - 2016-05-21 09:36:37 --> Controller Class Initialized
INFO - 2016-05-21 09:36:37 --> Model Class Initialized
INFO - 2016-05-21 09:36:37 --> Database Driver Class Initialized
INFO - 2016-05-21 09:36:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:36:37 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:36:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:36:37 --> Final output sent to browser
DEBUG - 2016-05-21 09:36:37 --> Total execution time: 0.0810
INFO - 2016-05-21 09:37:37 --> Config Class Initialized
INFO - 2016-05-21 09:37:37 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:37:37 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:37:37 --> Utf8 Class Initialized
INFO - 2016-05-21 09:37:37 --> URI Class Initialized
INFO - 2016-05-21 09:37:37 --> Router Class Initialized
INFO - 2016-05-21 09:37:37 --> Output Class Initialized
INFO - 2016-05-21 09:37:37 --> Security Class Initialized
DEBUG - 2016-05-21 09:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:37:37 --> Input Class Initialized
INFO - 2016-05-21 09:37:37 --> Language Class Initialized
INFO - 2016-05-21 09:37:37 --> Loader Class Initialized
INFO - 2016-05-21 09:37:37 --> Helper loaded: url_helper
INFO - 2016-05-21 09:37:37 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:37:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:37:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:37:37 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:37:37 --> Helper loaded: form_helper
INFO - 2016-05-21 09:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:37:37 --> Form Validation Class Initialized
INFO - 2016-05-21 09:37:37 --> Controller Class Initialized
INFO - 2016-05-21 09:37:37 --> Model Class Initialized
INFO - 2016-05-21 09:37:37 --> Database Driver Class Initialized
INFO - 2016-05-21 09:37:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:37:37 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:37:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:37:37 --> Final output sent to browser
DEBUG - 2016-05-21 09:37:37 --> Total execution time: 0.0730
INFO - 2016-05-21 09:38:37 --> Config Class Initialized
INFO - 2016-05-21 09:38:37 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:38:37 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:38:37 --> Utf8 Class Initialized
INFO - 2016-05-21 09:38:37 --> URI Class Initialized
INFO - 2016-05-21 09:38:37 --> Router Class Initialized
INFO - 2016-05-21 09:38:37 --> Output Class Initialized
INFO - 2016-05-21 09:38:37 --> Security Class Initialized
DEBUG - 2016-05-21 09:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:38:37 --> Input Class Initialized
INFO - 2016-05-21 09:38:37 --> Language Class Initialized
INFO - 2016-05-21 09:38:37 --> Loader Class Initialized
INFO - 2016-05-21 09:38:37 --> Helper loaded: url_helper
INFO - 2016-05-21 09:38:37 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:38:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:38:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:38:37 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:38:37 --> Helper loaded: form_helper
INFO - 2016-05-21 09:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:38:37 --> Form Validation Class Initialized
INFO - 2016-05-21 09:38:37 --> Controller Class Initialized
INFO - 2016-05-21 09:38:37 --> Model Class Initialized
INFO - 2016-05-21 09:38:37 --> Database Driver Class Initialized
INFO - 2016-05-21 09:38:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:38:37 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:38:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:38:37 --> Final output sent to browser
DEBUG - 2016-05-21 09:38:37 --> Total execution time: 0.0693
INFO - 2016-05-21 09:39:37 --> Config Class Initialized
INFO - 2016-05-21 09:39:37 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:39:37 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:39:37 --> Utf8 Class Initialized
INFO - 2016-05-21 09:39:37 --> URI Class Initialized
INFO - 2016-05-21 09:39:37 --> Router Class Initialized
INFO - 2016-05-21 09:39:37 --> Output Class Initialized
INFO - 2016-05-21 09:39:37 --> Security Class Initialized
DEBUG - 2016-05-21 09:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:39:37 --> Input Class Initialized
INFO - 2016-05-21 09:39:37 --> Language Class Initialized
INFO - 2016-05-21 09:39:37 --> Loader Class Initialized
INFO - 2016-05-21 09:39:37 --> Helper loaded: url_helper
INFO - 2016-05-21 09:39:37 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:39:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:39:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:39:37 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:39:37 --> Helper loaded: form_helper
INFO - 2016-05-21 09:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:39:37 --> Form Validation Class Initialized
INFO - 2016-05-21 09:39:37 --> Controller Class Initialized
INFO - 2016-05-21 09:39:37 --> Model Class Initialized
INFO - 2016-05-21 09:39:37 --> Database Driver Class Initialized
INFO - 2016-05-21 09:39:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:39:37 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:39:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:39:37 --> Final output sent to browser
DEBUG - 2016-05-21 09:39:37 --> Total execution time: 0.0718
INFO - 2016-05-21 09:40:38 --> Config Class Initialized
INFO - 2016-05-21 09:40:38 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:40:38 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:40:38 --> Utf8 Class Initialized
INFO - 2016-05-21 09:40:38 --> URI Class Initialized
INFO - 2016-05-21 09:40:38 --> Router Class Initialized
INFO - 2016-05-21 09:40:38 --> Output Class Initialized
INFO - 2016-05-21 09:40:38 --> Security Class Initialized
DEBUG - 2016-05-21 09:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:40:38 --> Input Class Initialized
INFO - 2016-05-21 09:40:38 --> Language Class Initialized
INFO - 2016-05-21 09:40:38 --> Loader Class Initialized
INFO - 2016-05-21 09:40:38 --> Helper loaded: url_helper
INFO - 2016-05-21 09:40:38 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:40:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:40:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:40:38 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:40:38 --> Helper loaded: form_helper
INFO - 2016-05-21 09:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:40:38 --> Form Validation Class Initialized
INFO - 2016-05-21 09:40:38 --> Controller Class Initialized
INFO - 2016-05-21 09:40:38 --> Model Class Initialized
INFO - 2016-05-21 09:40:38 --> Database Driver Class Initialized
INFO - 2016-05-21 09:40:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:40:38 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:40:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:40:38 --> Final output sent to browser
DEBUG - 2016-05-21 09:40:38 --> Total execution time: 0.0799
INFO - 2016-05-21 09:41:38 --> Config Class Initialized
INFO - 2016-05-21 09:41:38 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:41:38 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:41:38 --> Utf8 Class Initialized
INFO - 2016-05-21 09:41:38 --> URI Class Initialized
INFO - 2016-05-21 09:41:38 --> Router Class Initialized
INFO - 2016-05-21 09:41:38 --> Output Class Initialized
INFO - 2016-05-21 09:41:38 --> Security Class Initialized
DEBUG - 2016-05-21 09:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:41:38 --> Input Class Initialized
INFO - 2016-05-21 09:41:38 --> Language Class Initialized
INFO - 2016-05-21 09:41:38 --> Loader Class Initialized
INFO - 2016-05-21 09:41:38 --> Helper loaded: url_helper
INFO - 2016-05-21 09:41:38 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:41:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:41:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:41:38 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:41:38 --> Helper loaded: form_helper
INFO - 2016-05-21 09:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:41:38 --> Form Validation Class Initialized
INFO - 2016-05-21 09:41:38 --> Controller Class Initialized
INFO - 2016-05-21 09:41:38 --> Model Class Initialized
INFO - 2016-05-21 09:41:38 --> Database Driver Class Initialized
INFO - 2016-05-21 09:41:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:41:38 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:41:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:41:38 --> Final output sent to browser
DEBUG - 2016-05-21 09:41:38 --> Total execution time: 0.0688
INFO - 2016-05-21 09:42:05 --> Config Class Initialized
INFO - 2016-05-21 09:42:05 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:42:05 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:42:05 --> Utf8 Class Initialized
INFO - 2016-05-21 09:42:05 --> URI Class Initialized
INFO - 2016-05-21 09:42:05 --> Router Class Initialized
INFO - 2016-05-21 09:42:05 --> Output Class Initialized
INFO - 2016-05-21 09:42:05 --> Security Class Initialized
DEBUG - 2016-05-21 09:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:42:05 --> Input Class Initialized
INFO - 2016-05-21 09:42:05 --> Language Class Initialized
INFO - 2016-05-21 09:42:05 --> Loader Class Initialized
INFO - 2016-05-21 09:42:05 --> Helper loaded: url_helper
INFO - 2016-05-21 09:42:05 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:42:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:42:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:42:05 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:42:05 --> Helper loaded: form_helper
INFO - 2016-05-21 09:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:42:05 --> Form Validation Class Initialized
INFO - 2016-05-21 09:42:05 --> Controller Class Initialized
INFO - 2016-05-21 09:42:05 --> Model Class Initialized
INFO - 2016-05-21 09:42:05 --> Database Driver Class Initialized
INFO - 2016-05-21 09:42:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:42:05 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:42:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:42:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 09:42:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 09:42:05 --> Final output sent to browser
DEBUG - 2016-05-21 09:42:05 --> Total execution time: 0.0811
INFO - 2016-05-21 09:42:06 --> Config Class Initialized
INFO - 2016-05-21 09:42:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:42:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:42:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:42:06 --> URI Class Initialized
INFO - 2016-05-21 09:42:06 --> Router Class Initialized
INFO - 2016-05-21 09:42:06 --> Output Class Initialized
INFO - 2016-05-21 09:42:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:42:06 --> Input Class Initialized
INFO - 2016-05-21 09:42:06 --> Language Class Initialized
INFO - 2016-05-21 09:42:06 --> Loader Class Initialized
INFO - 2016-05-21 09:42:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:42:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:42:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:42:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:42:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:42:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:42:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:42:06 --> Controller Class Initialized
INFO - 2016-05-21 09:42:06 --> Model Class Initialized
INFO - 2016-05-21 09:42:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:42:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:42:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:42:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:42:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:42:06 --> Total execution time: 0.0999
INFO - 2016-05-21 09:43:06 --> Config Class Initialized
INFO - 2016-05-21 09:43:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:43:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:43:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:43:06 --> URI Class Initialized
INFO - 2016-05-21 09:43:06 --> Router Class Initialized
INFO - 2016-05-21 09:43:06 --> Output Class Initialized
INFO - 2016-05-21 09:43:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:43:06 --> Input Class Initialized
INFO - 2016-05-21 09:43:06 --> Language Class Initialized
INFO - 2016-05-21 09:43:06 --> Loader Class Initialized
INFO - 2016-05-21 09:43:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:43:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:43:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:43:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:43:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:43:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:43:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:43:06 --> Controller Class Initialized
INFO - 2016-05-21 09:43:06 --> Model Class Initialized
INFO - 2016-05-21 09:43:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:43:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:43:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:43:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:43:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:43:06 --> Total execution time: 0.0737
INFO - 2016-05-21 09:44:06 --> Config Class Initialized
INFO - 2016-05-21 09:44:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:44:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:44:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:44:06 --> URI Class Initialized
INFO - 2016-05-21 09:44:06 --> Router Class Initialized
INFO - 2016-05-21 09:44:06 --> Output Class Initialized
INFO - 2016-05-21 09:44:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:44:06 --> Input Class Initialized
INFO - 2016-05-21 09:44:06 --> Language Class Initialized
INFO - 2016-05-21 09:44:06 --> Loader Class Initialized
INFO - 2016-05-21 09:44:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:44:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:44:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:44:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:44:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:44:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:44:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:44:06 --> Controller Class Initialized
INFO - 2016-05-21 09:44:06 --> Model Class Initialized
INFO - 2016-05-21 09:44:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:44:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:44:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:44:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:44:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:44:06 --> Total execution time: 0.0836
INFO - 2016-05-21 09:45:06 --> Config Class Initialized
INFO - 2016-05-21 09:45:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:45:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:45:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:45:06 --> URI Class Initialized
INFO - 2016-05-21 09:45:06 --> Router Class Initialized
INFO - 2016-05-21 09:45:06 --> Output Class Initialized
INFO - 2016-05-21 09:45:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:45:06 --> Input Class Initialized
INFO - 2016-05-21 09:45:06 --> Language Class Initialized
INFO - 2016-05-21 09:45:06 --> Loader Class Initialized
INFO - 2016-05-21 09:45:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:45:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:45:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:45:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:45:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:45:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:45:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:45:06 --> Controller Class Initialized
INFO - 2016-05-21 09:45:06 --> Model Class Initialized
INFO - 2016-05-21 09:45:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:45:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:45:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:45:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:45:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:45:06 --> Total execution time: 0.0696
INFO - 2016-05-21 09:46:06 --> Config Class Initialized
INFO - 2016-05-21 09:46:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:46:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:46:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:46:06 --> URI Class Initialized
INFO - 2016-05-21 09:46:06 --> Router Class Initialized
INFO - 2016-05-21 09:46:06 --> Output Class Initialized
INFO - 2016-05-21 09:46:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:46:06 --> Input Class Initialized
INFO - 2016-05-21 09:46:06 --> Language Class Initialized
INFO - 2016-05-21 09:46:06 --> Loader Class Initialized
INFO - 2016-05-21 09:46:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:46:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:46:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:46:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:46:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:46:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:46:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:46:06 --> Controller Class Initialized
INFO - 2016-05-21 09:46:06 --> Model Class Initialized
INFO - 2016-05-21 09:46:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:46:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:46:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:46:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:46:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:46:06 --> Total execution time: 0.0791
INFO - 2016-05-21 09:47:06 --> Config Class Initialized
INFO - 2016-05-21 09:47:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:47:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:47:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:47:06 --> URI Class Initialized
INFO - 2016-05-21 09:47:06 --> Router Class Initialized
INFO - 2016-05-21 09:47:06 --> Output Class Initialized
INFO - 2016-05-21 09:47:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:47:06 --> Input Class Initialized
INFO - 2016-05-21 09:47:06 --> Language Class Initialized
INFO - 2016-05-21 09:47:06 --> Loader Class Initialized
INFO - 2016-05-21 09:47:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:47:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:47:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:47:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:47:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:47:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:47:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:47:06 --> Controller Class Initialized
INFO - 2016-05-21 09:47:06 --> Model Class Initialized
INFO - 2016-05-21 09:47:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:47:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:47:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:47:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:47:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:47:06 --> Total execution time: 0.0750
INFO - 2016-05-21 09:48:06 --> Config Class Initialized
INFO - 2016-05-21 09:48:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:48:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:48:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:48:06 --> URI Class Initialized
INFO - 2016-05-21 09:48:06 --> Router Class Initialized
INFO - 2016-05-21 09:48:06 --> Output Class Initialized
INFO - 2016-05-21 09:48:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:48:06 --> Input Class Initialized
INFO - 2016-05-21 09:48:06 --> Language Class Initialized
INFO - 2016-05-21 09:48:06 --> Loader Class Initialized
INFO - 2016-05-21 09:48:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:48:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:48:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:48:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:48:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:48:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:48:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:48:06 --> Controller Class Initialized
INFO - 2016-05-21 09:48:06 --> Model Class Initialized
INFO - 2016-05-21 09:48:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:48:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:48:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:48:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:48:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:48:06 --> Total execution time: 0.0695
INFO - 2016-05-21 09:49:06 --> Config Class Initialized
INFO - 2016-05-21 09:49:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:49:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:49:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:49:06 --> URI Class Initialized
INFO - 2016-05-21 09:49:06 --> Router Class Initialized
INFO - 2016-05-21 09:49:06 --> Output Class Initialized
INFO - 2016-05-21 09:49:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:49:06 --> Input Class Initialized
INFO - 2016-05-21 09:49:06 --> Language Class Initialized
INFO - 2016-05-21 09:49:06 --> Loader Class Initialized
INFO - 2016-05-21 09:49:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:49:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:49:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:49:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:49:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:49:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:49:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:49:06 --> Controller Class Initialized
INFO - 2016-05-21 09:49:06 --> Model Class Initialized
INFO - 2016-05-21 09:49:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:49:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:49:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:49:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:49:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:49:06 --> Total execution time: 0.0688
INFO - 2016-05-21 09:50:06 --> Config Class Initialized
INFO - 2016-05-21 09:50:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:50:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:50:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:50:06 --> URI Class Initialized
INFO - 2016-05-21 09:50:06 --> Router Class Initialized
INFO - 2016-05-21 09:50:06 --> Output Class Initialized
INFO - 2016-05-21 09:50:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:50:06 --> Input Class Initialized
INFO - 2016-05-21 09:50:06 --> Language Class Initialized
INFO - 2016-05-21 09:50:06 --> Loader Class Initialized
INFO - 2016-05-21 09:50:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:50:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:50:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:50:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:50:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:50:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:50:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:50:06 --> Controller Class Initialized
INFO - 2016-05-21 09:50:06 --> Model Class Initialized
INFO - 2016-05-21 09:50:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:50:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:50:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:50:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:50:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:50:06 --> Total execution time: 0.0744
INFO - 2016-05-21 09:51:06 --> Config Class Initialized
INFO - 2016-05-21 09:51:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:51:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:51:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:51:06 --> URI Class Initialized
INFO - 2016-05-21 09:51:06 --> Router Class Initialized
INFO - 2016-05-21 09:51:06 --> Output Class Initialized
INFO - 2016-05-21 09:51:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:51:06 --> Input Class Initialized
INFO - 2016-05-21 09:51:06 --> Language Class Initialized
INFO - 2016-05-21 09:51:06 --> Loader Class Initialized
INFO - 2016-05-21 09:51:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:51:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:51:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:51:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:51:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:51:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:51:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:51:06 --> Controller Class Initialized
INFO - 2016-05-21 09:51:06 --> Model Class Initialized
INFO - 2016-05-21 09:51:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:51:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:51:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:51:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:51:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:51:06 --> Total execution time: 0.1166
INFO - 2016-05-21 09:52:06 --> Config Class Initialized
INFO - 2016-05-21 09:52:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:52:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:52:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:52:06 --> URI Class Initialized
INFO - 2016-05-21 09:52:06 --> Router Class Initialized
INFO - 2016-05-21 09:52:06 --> Output Class Initialized
INFO - 2016-05-21 09:52:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:52:06 --> Input Class Initialized
INFO - 2016-05-21 09:52:06 --> Language Class Initialized
INFO - 2016-05-21 09:52:06 --> Loader Class Initialized
INFO - 2016-05-21 09:52:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:52:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:52:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:52:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:52:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:52:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:52:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:52:06 --> Controller Class Initialized
INFO - 2016-05-21 09:52:06 --> Model Class Initialized
INFO - 2016-05-21 09:52:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:52:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:52:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:52:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:52:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:52:06 --> Total execution time: 0.0723
INFO - 2016-05-21 09:53:06 --> Config Class Initialized
INFO - 2016-05-21 09:53:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:53:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:53:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:53:06 --> URI Class Initialized
INFO - 2016-05-21 09:53:06 --> Router Class Initialized
INFO - 2016-05-21 09:53:06 --> Output Class Initialized
INFO - 2016-05-21 09:53:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:53:06 --> Input Class Initialized
INFO - 2016-05-21 09:53:06 --> Language Class Initialized
INFO - 2016-05-21 09:53:06 --> Loader Class Initialized
INFO - 2016-05-21 09:53:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:53:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:53:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:53:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:53:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:53:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:53:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:53:06 --> Controller Class Initialized
INFO - 2016-05-21 09:53:06 --> Model Class Initialized
INFO - 2016-05-21 09:53:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:53:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:53:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:53:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:53:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:53:06 --> Total execution time: 0.0787
INFO - 2016-05-21 09:54:06 --> Config Class Initialized
INFO - 2016-05-21 09:54:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:54:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:54:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:54:06 --> URI Class Initialized
INFO - 2016-05-21 09:54:06 --> Router Class Initialized
INFO - 2016-05-21 09:54:06 --> Output Class Initialized
INFO - 2016-05-21 09:54:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:54:06 --> Input Class Initialized
INFO - 2016-05-21 09:54:06 --> Language Class Initialized
INFO - 2016-05-21 09:54:06 --> Loader Class Initialized
INFO - 2016-05-21 09:54:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:54:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:54:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:54:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:54:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:54:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:54:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:54:06 --> Controller Class Initialized
INFO - 2016-05-21 09:54:06 --> Model Class Initialized
INFO - 2016-05-21 09:54:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:54:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:54:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:54:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:54:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:54:06 --> Total execution time: 0.0780
INFO - 2016-05-21 09:55:06 --> Config Class Initialized
INFO - 2016-05-21 09:55:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:55:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:55:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:55:06 --> URI Class Initialized
INFO - 2016-05-21 09:55:06 --> Router Class Initialized
INFO - 2016-05-21 09:55:06 --> Output Class Initialized
INFO - 2016-05-21 09:55:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:55:06 --> Input Class Initialized
INFO - 2016-05-21 09:55:06 --> Language Class Initialized
INFO - 2016-05-21 09:55:06 --> Loader Class Initialized
INFO - 2016-05-21 09:55:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:55:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:55:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:55:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:55:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:55:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:55:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:55:06 --> Controller Class Initialized
INFO - 2016-05-21 09:55:06 --> Model Class Initialized
INFO - 2016-05-21 09:55:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:55:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:55:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:55:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:55:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:55:06 --> Total execution time: 0.0713
INFO - 2016-05-21 09:56:06 --> Config Class Initialized
INFO - 2016-05-21 09:56:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:56:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:56:06 --> Utf8 Class Initialized
INFO - 2016-05-21 09:56:06 --> URI Class Initialized
INFO - 2016-05-21 09:56:06 --> Router Class Initialized
INFO - 2016-05-21 09:56:06 --> Output Class Initialized
INFO - 2016-05-21 09:56:06 --> Security Class Initialized
DEBUG - 2016-05-21 09:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:56:06 --> Input Class Initialized
INFO - 2016-05-21 09:56:06 --> Language Class Initialized
INFO - 2016-05-21 09:56:06 --> Loader Class Initialized
INFO - 2016-05-21 09:56:06 --> Helper loaded: url_helper
INFO - 2016-05-21 09:56:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:56:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:56:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:56:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:56:06 --> Helper loaded: form_helper
INFO - 2016-05-21 09:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:56:06 --> Form Validation Class Initialized
INFO - 2016-05-21 09:56:06 --> Controller Class Initialized
INFO - 2016-05-21 09:56:06 --> Model Class Initialized
INFO - 2016-05-21 09:56:06 --> Database Driver Class Initialized
INFO - 2016-05-21 09:56:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:56:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:56:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:56:06 --> Final output sent to browser
DEBUG - 2016-05-21 09:56:06 --> Total execution time: 0.0770
INFO - 2016-05-21 09:56:07 --> Config Class Initialized
INFO - 2016-05-21 09:56:07 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:56:07 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:56:07 --> Utf8 Class Initialized
INFO - 2016-05-21 09:56:07 --> URI Class Initialized
INFO - 2016-05-21 09:56:07 --> Router Class Initialized
INFO - 2016-05-21 09:56:07 --> Output Class Initialized
INFO - 2016-05-21 09:56:07 --> Security Class Initialized
DEBUG - 2016-05-21 09:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:56:07 --> Input Class Initialized
INFO - 2016-05-21 09:56:07 --> Language Class Initialized
INFO - 2016-05-21 09:56:07 --> Loader Class Initialized
INFO - 2016-05-21 09:56:07 --> Helper loaded: url_helper
INFO - 2016-05-21 09:56:07 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:56:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:56:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:56:07 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:56:07 --> Helper loaded: form_helper
INFO - 2016-05-21 09:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:56:07 --> Form Validation Class Initialized
INFO - 2016-05-21 09:56:07 --> Controller Class Initialized
INFO - 2016-05-21 09:56:07 --> Model Class Initialized
INFO - 2016-05-21 09:56:07 --> Database Driver Class Initialized
INFO - 2016-05-21 09:56:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:56:07 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:56:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:56:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 09:56:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 09:56:07 --> Final output sent to browser
DEBUG - 2016-05-21 09:56:07 --> Total execution time: 0.0935
INFO - 2016-05-21 09:56:08 --> Config Class Initialized
INFO - 2016-05-21 09:56:08 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:56:08 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:56:08 --> Utf8 Class Initialized
INFO - 2016-05-21 09:56:08 --> URI Class Initialized
INFO - 2016-05-21 09:56:08 --> Router Class Initialized
INFO - 2016-05-21 09:56:08 --> Output Class Initialized
INFO - 2016-05-21 09:56:08 --> Security Class Initialized
DEBUG - 2016-05-21 09:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:56:08 --> Input Class Initialized
INFO - 2016-05-21 09:56:08 --> Language Class Initialized
INFO - 2016-05-21 09:56:08 --> Loader Class Initialized
INFO - 2016-05-21 09:56:08 --> Helper loaded: url_helper
INFO - 2016-05-21 09:56:08 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:56:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:56:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:56:08 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:56:08 --> Helper loaded: form_helper
INFO - 2016-05-21 09:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:56:08 --> Form Validation Class Initialized
INFO - 2016-05-21 09:56:08 --> Controller Class Initialized
INFO - 2016-05-21 09:56:08 --> Model Class Initialized
INFO - 2016-05-21 09:56:08 --> Database Driver Class Initialized
INFO - 2016-05-21 09:56:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:56:08 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:56:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:56:08 --> Final output sent to browser
DEBUG - 2016-05-21 09:56:08 --> Total execution time: 0.0895
INFO - 2016-05-21 09:56:10 --> Config Class Initialized
INFO - 2016-05-21 09:56:10 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:56:10 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:56:10 --> Utf8 Class Initialized
INFO - 2016-05-21 09:56:10 --> URI Class Initialized
INFO - 2016-05-21 09:56:10 --> Router Class Initialized
INFO - 2016-05-21 09:56:10 --> Output Class Initialized
INFO - 2016-05-21 09:56:10 --> Security Class Initialized
DEBUG - 2016-05-21 09:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:56:10 --> Input Class Initialized
INFO - 2016-05-21 09:56:10 --> Language Class Initialized
INFO - 2016-05-21 09:56:10 --> Loader Class Initialized
INFO - 2016-05-21 09:56:10 --> Helper loaded: url_helper
INFO - 2016-05-21 09:56:10 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:56:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:56:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:56:10 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:56:10 --> Helper loaded: form_helper
INFO - 2016-05-21 09:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:56:10 --> Form Validation Class Initialized
INFO - 2016-05-21 09:56:10 --> Controller Class Initialized
INFO - 2016-05-21 09:56:10 --> Model Class Initialized
INFO - 2016-05-21 09:56:10 --> Database Driver Class Initialized
INFO - 2016-05-21 09:56:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-21 09:56:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:56:10 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:56:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:56:10 --> Helper loaded: nif_validate_helper
INFO - 2016-05-21 09:56:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-21 09:56:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 09:56:10 --> Final output sent to browser
DEBUG - 2016-05-21 09:56:10 --> Total execution time: 0.1152
INFO - 2016-05-21 09:56:10 --> Config Class Initialized
INFO - 2016-05-21 09:56:10 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:56:10 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:56:10 --> Utf8 Class Initialized
INFO - 2016-05-21 09:56:10 --> URI Class Initialized
INFO - 2016-05-21 09:56:10 --> Router Class Initialized
INFO - 2016-05-21 09:56:10 --> Output Class Initialized
INFO - 2016-05-21 09:56:10 --> Security Class Initialized
DEBUG - 2016-05-21 09:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:56:10 --> Input Class Initialized
INFO - 2016-05-21 09:56:10 --> Language Class Initialized
INFO - 2016-05-21 09:56:10 --> Loader Class Initialized
INFO - 2016-05-21 09:56:10 --> Helper loaded: url_helper
INFO - 2016-05-21 09:56:10 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:56:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:56:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:56:10 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:56:10 --> Helper loaded: form_helper
INFO - 2016-05-21 09:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:56:10 --> Form Validation Class Initialized
INFO - 2016-05-21 09:56:10 --> Controller Class Initialized
INFO - 2016-05-21 09:56:10 --> Model Class Initialized
INFO - 2016-05-21 09:56:10 --> Database Driver Class Initialized
INFO - 2016-05-21 09:56:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:56:10 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:56:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:56:10 --> Final output sent to browser
DEBUG - 2016-05-21 09:56:10 --> Total execution time: 0.1107
INFO - 2016-05-21 09:56:11 --> Config Class Initialized
INFO - 2016-05-21 09:56:11 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:56:11 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:56:11 --> Utf8 Class Initialized
INFO - 2016-05-21 09:56:11 --> URI Class Initialized
INFO - 2016-05-21 09:56:11 --> Router Class Initialized
INFO - 2016-05-21 09:56:11 --> Output Class Initialized
INFO - 2016-05-21 09:56:11 --> Security Class Initialized
DEBUG - 2016-05-21 09:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:56:11 --> Input Class Initialized
INFO - 2016-05-21 09:56:11 --> Language Class Initialized
INFO - 2016-05-21 09:56:11 --> Loader Class Initialized
INFO - 2016-05-21 09:56:11 --> Helper loaded: url_helper
INFO - 2016-05-21 09:56:11 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:56:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:56:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:56:11 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:56:11 --> Helper loaded: form_helper
INFO - 2016-05-21 09:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:56:11 --> Form Validation Class Initialized
INFO - 2016-05-21 09:56:11 --> Controller Class Initialized
INFO - 2016-05-21 09:56:11 --> Model Class Initialized
INFO - 2016-05-21 09:56:11 --> Database Driver Class Initialized
INFO - 2016-05-21 09:56:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:56:11 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:56:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:56:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 09:56:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 09:56:11 --> Final output sent to browser
DEBUG - 2016-05-21 09:56:11 --> Total execution time: 0.0809
INFO - 2016-05-21 09:56:11 --> Config Class Initialized
INFO - 2016-05-21 09:56:11 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:56:11 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:56:11 --> Utf8 Class Initialized
INFO - 2016-05-21 09:56:11 --> URI Class Initialized
INFO - 2016-05-21 09:56:11 --> Router Class Initialized
INFO - 2016-05-21 09:56:11 --> Output Class Initialized
INFO - 2016-05-21 09:56:11 --> Security Class Initialized
DEBUG - 2016-05-21 09:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:56:11 --> Input Class Initialized
INFO - 2016-05-21 09:56:11 --> Language Class Initialized
INFO - 2016-05-21 09:56:11 --> Loader Class Initialized
INFO - 2016-05-21 09:56:11 --> Helper loaded: url_helper
INFO - 2016-05-21 09:56:11 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:56:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:56:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:56:11 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:56:11 --> Helper loaded: form_helper
INFO - 2016-05-21 09:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:56:11 --> Form Validation Class Initialized
INFO - 2016-05-21 09:56:11 --> Controller Class Initialized
INFO - 2016-05-21 09:56:11 --> Model Class Initialized
INFO - 2016-05-21 09:56:11 --> Database Driver Class Initialized
INFO - 2016-05-21 09:56:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:56:11 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:56:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:56:11 --> Final output sent to browser
DEBUG - 2016-05-21 09:56:11 --> Total execution time: 0.0956
INFO - 2016-05-21 09:56:15 --> Config Class Initialized
INFO - 2016-05-21 09:56:15 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:56:15 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:56:15 --> Utf8 Class Initialized
INFO - 2016-05-21 09:56:15 --> URI Class Initialized
INFO - 2016-05-21 09:56:15 --> Router Class Initialized
INFO - 2016-05-21 09:56:15 --> Output Class Initialized
INFO - 2016-05-21 09:56:15 --> Security Class Initialized
DEBUG - 2016-05-21 09:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 09:56:15 --> Input Class Initialized
INFO - 2016-05-21 09:56:15 --> Language Class Initialized
INFO - 2016-05-21 09:56:15 --> Loader Class Initialized
INFO - 2016-05-21 09:56:15 --> Helper loaded: url_helper
INFO - 2016-05-21 09:56:15 --> Helper loaded: sesion_helper
INFO - 2016-05-21 09:56:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 09:56:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 09:56:15 --> Helper loaded: redondear_helper
INFO - 2016-05-21 09:56:15 --> Helper loaded: form_helper
INFO - 2016-05-21 09:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 09:56:15 --> Form Validation Class Initialized
INFO - 2016-05-21 09:56:15 --> Controller Class Initialized
INFO - 2016-05-21 09:56:15 --> Model Class Initialized
INFO - 2016-05-21 09:56:15 --> Database Driver Class Initialized
INFO - 2016-05-21 09:56:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 09:56:15 --> Pagination Class Initialized
DEBUG - 2016-05-21 09:56:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 09:56:15 --> Config Class Initialized
INFO - 2016-05-21 09:56:15 --> Hooks Class Initialized
DEBUG - 2016-05-21 09:56:15 --> UTF-8 Support Enabled
INFO - 2016-05-21 09:56:15 --> Utf8 Class Initialized
INFO - 2016-05-21 10:00:50 --> Config Class Initialized
INFO - 2016-05-21 10:00:50 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:00:50 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:00:50 --> Utf8 Class Initialized
INFO - 2016-05-21 10:00:50 --> URI Class Initialized
INFO - 2016-05-21 10:00:50 --> Router Class Initialized
INFO - 2016-05-21 10:00:50 --> Output Class Initialized
INFO - 2016-05-21 10:00:50 --> Security Class Initialized
DEBUG - 2016-05-21 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:00:50 --> Input Class Initialized
INFO - 2016-05-21 10:00:50 --> Language Class Initialized
INFO - 2016-05-21 10:00:50 --> Loader Class Initialized
INFO - 2016-05-21 10:00:50 --> Helper loaded: url_helper
INFO - 2016-05-21 10:00:50 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:00:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:00:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:00:50 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:00:50 --> Helper loaded: form_helper
INFO - 2016-05-21 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:00:50 --> Form Validation Class Initialized
INFO - 2016-05-21 10:00:50 --> Controller Class Initialized
INFO - 2016-05-21 10:00:50 --> Model Class Initialized
INFO - 2016-05-21 10:00:50 --> Database Driver Class Initialized
INFO - 2016-05-21 10:00:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:00:50 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:00:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-21 10:00:50 --> Severity: Notice --> Undefined variable: mensajePagada C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Facturas.php 36
INFO - 2016-05-21 10:00:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:00:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:00:50 --> Final output sent to browser
DEBUG - 2016-05-21 10:00:50 --> Total execution time: 0.0909
INFO - 2016-05-21 10:00:50 --> Config Class Initialized
INFO - 2016-05-21 10:00:50 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:00:50 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:00:50 --> Utf8 Class Initialized
INFO - 2016-05-21 10:00:50 --> URI Class Initialized
INFO - 2016-05-21 10:00:50 --> Router Class Initialized
INFO - 2016-05-21 10:00:50 --> Output Class Initialized
INFO - 2016-05-21 10:00:50 --> Security Class Initialized
DEBUG - 2016-05-21 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:00:50 --> Input Class Initialized
INFO - 2016-05-21 10:00:50 --> Language Class Initialized
INFO - 2016-05-21 10:00:50 --> Loader Class Initialized
INFO - 2016-05-21 10:00:50 --> Helper loaded: url_helper
INFO - 2016-05-21 10:00:50 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:00:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:00:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:00:50 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:00:50 --> Helper loaded: form_helper
INFO - 2016-05-21 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:00:50 --> Form Validation Class Initialized
INFO - 2016-05-21 10:00:50 --> Controller Class Initialized
INFO - 2016-05-21 10:00:50 --> Model Class Initialized
INFO - 2016-05-21 10:00:50 --> Database Driver Class Initialized
INFO - 2016-05-21 10:00:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:00:50 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:00:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:00:50 --> Final output sent to browser
DEBUG - 2016-05-21 10:00:50 --> Total execution time: 0.0842
INFO - 2016-05-21 10:00:52 --> Config Class Initialized
INFO - 2016-05-21 10:00:52 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:00:52 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:00:52 --> Utf8 Class Initialized
INFO - 2016-05-21 10:00:52 --> URI Class Initialized
INFO - 2016-05-21 10:00:52 --> Router Class Initialized
INFO - 2016-05-21 10:00:52 --> Output Class Initialized
INFO - 2016-05-21 10:00:52 --> Security Class Initialized
DEBUG - 2016-05-21 10:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:00:52 --> Input Class Initialized
INFO - 2016-05-21 10:00:52 --> Language Class Initialized
INFO - 2016-05-21 10:00:52 --> Loader Class Initialized
INFO - 2016-05-21 10:00:52 --> Helper loaded: url_helper
INFO - 2016-05-21 10:00:52 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:00:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:00:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:00:52 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:00:52 --> Helper loaded: form_helper
INFO - 2016-05-21 10:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:00:52 --> Form Validation Class Initialized
INFO - 2016-05-21 10:00:52 --> Controller Class Initialized
INFO - 2016-05-21 10:00:52 --> Model Class Initialized
INFO - 2016-05-21 10:00:52 --> Database Driver Class Initialized
INFO - 2016-05-21 10:00:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:00:52 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:00:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-21 10:00:52 --> Severity: Notice --> Undefined variable: mensajePagada C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Facturas.php 36
INFO - 2016-05-21 10:00:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:00:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:00:52 --> Final output sent to browser
DEBUG - 2016-05-21 10:00:52 --> Total execution time: 0.0889
INFO - 2016-05-21 10:00:53 --> Config Class Initialized
INFO - 2016-05-21 10:00:53 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:00:53 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:00:53 --> Utf8 Class Initialized
INFO - 2016-05-21 10:00:53 --> URI Class Initialized
INFO - 2016-05-21 10:00:53 --> Router Class Initialized
INFO - 2016-05-21 10:00:53 --> Output Class Initialized
INFO - 2016-05-21 10:00:53 --> Security Class Initialized
DEBUG - 2016-05-21 10:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:00:53 --> Input Class Initialized
INFO - 2016-05-21 10:00:53 --> Language Class Initialized
INFO - 2016-05-21 10:00:53 --> Loader Class Initialized
INFO - 2016-05-21 10:00:53 --> Helper loaded: url_helper
INFO - 2016-05-21 10:00:53 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:00:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:00:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:00:53 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:00:53 --> Helper loaded: form_helper
INFO - 2016-05-21 10:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:00:53 --> Form Validation Class Initialized
INFO - 2016-05-21 10:00:53 --> Controller Class Initialized
INFO - 2016-05-21 10:00:53 --> Model Class Initialized
INFO - 2016-05-21 10:00:53 --> Database Driver Class Initialized
INFO - 2016-05-21 10:00:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:00:53 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:00:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:00:53 --> Final output sent to browser
DEBUG - 2016-05-21 10:00:53 --> Total execution time: 0.0821
INFO - 2016-05-21 10:01:03 --> Config Class Initialized
INFO - 2016-05-21 10:01:03 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:01:03 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:01:03 --> Utf8 Class Initialized
INFO - 2016-05-21 10:01:03 --> URI Class Initialized
INFO - 2016-05-21 10:01:03 --> Router Class Initialized
INFO - 2016-05-21 10:01:03 --> Output Class Initialized
INFO - 2016-05-21 10:01:03 --> Security Class Initialized
DEBUG - 2016-05-21 10:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:01:03 --> Input Class Initialized
INFO - 2016-05-21 10:01:03 --> Language Class Initialized
INFO - 2016-05-21 10:01:03 --> Loader Class Initialized
INFO - 2016-05-21 10:01:03 --> Helper loaded: url_helper
INFO - 2016-05-21 10:01:03 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:01:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:01:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:01:03 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:01:03 --> Helper loaded: form_helper
INFO - 2016-05-21 10:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:01:03 --> Form Validation Class Initialized
INFO - 2016-05-21 10:01:03 --> Controller Class Initialized
INFO - 2016-05-21 10:01:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-21 10:01:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:01:03 --> Final output sent to browser
DEBUG - 2016-05-21 10:01:03 --> Total execution time: 0.1278
INFO - 2016-05-21 10:01:03 --> Config Class Initialized
INFO - 2016-05-21 10:01:03 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:01:03 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:01:03 --> Utf8 Class Initialized
INFO - 2016-05-21 10:01:03 --> URI Class Initialized
INFO - 2016-05-21 10:01:03 --> Router Class Initialized
INFO - 2016-05-21 10:01:03 --> Output Class Initialized
INFO - 2016-05-21 10:01:03 --> Security Class Initialized
DEBUG - 2016-05-21 10:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:01:03 --> Input Class Initialized
INFO - 2016-05-21 10:01:03 --> Language Class Initialized
INFO - 2016-05-21 10:01:03 --> Loader Class Initialized
INFO - 2016-05-21 10:01:03 --> Helper loaded: url_helper
INFO - 2016-05-21 10:01:03 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:01:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:01:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:01:03 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:01:03 --> Helper loaded: form_helper
INFO - 2016-05-21 10:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:01:03 --> Form Validation Class Initialized
INFO - 2016-05-21 10:01:03 --> Controller Class Initialized
INFO - 2016-05-21 10:01:03 --> Model Class Initialized
INFO - 2016-05-21 10:01:03 --> Database Driver Class Initialized
INFO - 2016-05-21 10:01:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:01:03 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:01:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:01:03 --> Final output sent to browser
DEBUG - 2016-05-21 10:01:03 --> Total execution time: 0.1342
INFO - 2016-05-21 10:01:05 --> Config Class Initialized
INFO - 2016-05-21 10:01:05 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:01:05 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:01:05 --> Utf8 Class Initialized
INFO - 2016-05-21 10:01:05 --> URI Class Initialized
INFO - 2016-05-21 10:01:05 --> Router Class Initialized
INFO - 2016-05-21 10:01:05 --> Output Class Initialized
INFO - 2016-05-21 10:01:05 --> Security Class Initialized
DEBUG - 2016-05-21 10:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:01:05 --> Input Class Initialized
INFO - 2016-05-21 10:01:05 --> Language Class Initialized
INFO - 2016-05-21 10:01:05 --> Loader Class Initialized
INFO - 2016-05-21 10:01:05 --> Helper loaded: url_helper
INFO - 2016-05-21 10:01:05 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:01:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:01:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:01:05 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:01:05 --> Helper loaded: form_helper
INFO - 2016-05-21 10:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:01:05 --> Form Validation Class Initialized
INFO - 2016-05-21 10:01:05 --> Controller Class Initialized
INFO - 2016-05-21 10:01:05 --> Config Class Initialized
INFO - 2016-05-21 10:01:05 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:01:05 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:01:05 --> Utf8 Class Initialized
INFO - 2016-05-21 10:01:05 --> URI Class Initialized
INFO - 2016-05-21 10:01:05 --> Router Class Initialized
INFO - 2016-05-21 10:01:05 --> Output Class Initialized
INFO - 2016-05-21 10:01:05 --> Security Class Initialized
DEBUG - 2016-05-21 10:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:01:05 --> Input Class Initialized
INFO - 2016-05-21 10:01:05 --> Language Class Initialized
INFO - 2016-05-21 10:01:05 --> Loader Class Initialized
INFO - 2016-05-21 10:01:05 --> Helper loaded: url_helper
INFO - 2016-05-21 10:01:05 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:01:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:01:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:01:05 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:01:05 --> Helper loaded: form_helper
INFO - 2016-05-21 10:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:01:05 --> Form Validation Class Initialized
INFO - 2016-05-21 10:01:05 --> Controller Class Initialized
INFO - 2016-05-21 10:01:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-21 10:01:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 10:01:05 --> Final output sent to browser
DEBUG - 2016-05-21 10:01:05 --> Total execution time: 0.1074
INFO - 2016-05-21 10:01:06 --> Config Class Initialized
INFO - 2016-05-21 10:01:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:01:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:01:06 --> Utf8 Class Initialized
INFO - 2016-05-21 10:01:06 --> URI Class Initialized
INFO - 2016-05-21 10:01:06 --> Router Class Initialized
INFO - 2016-05-21 10:01:06 --> Output Class Initialized
INFO - 2016-05-21 10:01:06 --> Security Class Initialized
DEBUG - 2016-05-21 10:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:01:06 --> Input Class Initialized
INFO - 2016-05-21 10:01:06 --> Language Class Initialized
INFO - 2016-05-21 10:01:06 --> Loader Class Initialized
INFO - 2016-05-21 10:01:06 --> Helper loaded: url_helper
INFO - 2016-05-21 10:01:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:01:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:01:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:01:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:01:06 --> Helper loaded: form_helper
INFO - 2016-05-21 10:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:01:06 --> Form Validation Class Initialized
INFO - 2016-05-21 10:01:06 --> Controller Class Initialized
INFO - 2016-05-21 10:01:06 --> Model Class Initialized
INFO - 2016-05-21 10:01:06 --> Database Driver Class Initialized
INFO - 2016-05-21 10:01:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:01:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:01:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:01:06 --> Final output sent to browser
DEBUG - 2016-05-21 10:01:06 --> Total execution time: 0.0799
INFO - 2016-05-21 10:01:16 --> Config Class Initialized
INFO - 2016-05-21 10:01:16 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:01:16 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:01:16 --> Utf8 Class Initialized
INFO - 2016-05-21 10:01:16 --> URI Class Initialized
INFO - 2016-05-21 10:01:16 --> Router Class Initialized
INFO - 2016-05-21 10:01:16 --> Output Class Initialized
INFO - 2016-05-21 10:01:16 --> Security Class Initialized
DEBUG - 2016-05-21 10:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:01:16 --> Input Class Initialized
INFO - 2016-05-21 10:01:16 --> Language Class Initialized
INFO - 2016-05-21 10:01:16 --> Loader Class Initialized
INFO - 2016-05-21 10:01:16 --> Helper loaded: url_helper
INFO - 2016-05-21 10:01:16 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:01:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:01:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:01:16 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:01:16 --> Helper loaded: form_helper
INFO - 2016-05-21 10:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:01:16 --> Form Validation Class Initialized
INFO - 2016-05-21 10:01:16 --> Controller Class Initialized
INFO - 2016-05-21 10:01:16 --> Model Class Initialized
INFO - 2016-05-21 10:01:16 --> Database Driver Class Initialized
INFO - 2016-05-21 10:01:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:01:16 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:01:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-21 10:01:16 --> Severity: Notice --> Undefined variable: mensajePagada C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Facturas.php 36
INFO - 2016-05-21 10:01:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:01:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 10:01:16 --> Final output sent to browser
DEBUG - 2016-05-21 10:01:16 --> Total execution time: 0.1025
INFO - 2016-05-21 10:01:16 --> Config Class Initialized
INFO - 2016-05-21 10:01:16 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:01:16 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:01:16 --> Utf8 Class Initialized
INFO - 2016-05-21 10:01:16 --> URI Class Initialized
INFO - 2016-05-21 10:01:16 --> Router Class Initialized
INFO - 2016-05-21 10:01:16 --> Output Class Initialized
INFO - 2016-05-21 10:01:16 --> Security Class Initialized
DEBUG - 2016-05-21 10:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:01:16 --> Input Class Initialized
INFO - 2016-05-21 10:01:16 --> Language Class Initialized
INFO - 2016-05-21 10:01:16 --> Loader Class Initialized
INFO - 2016-05-21 10:01:16 --> Helper loaded: url_helper
INFO - 2016-05-21 10:01:16 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:01:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:01:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:01:16 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:01:16 --> Helper loaded: form_helper
INFO - 2016-05-21 10:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:01:16 --> Form Validation Class Initialized
INFO - 2016-05-21 10:01:16 --> Controller Class Initialized
INFO - 2016-05-21 10:01:16 --> Model Class Initialized
INFO - 2016-05-21 10:01:16 --> Database Driver Class Initialized
INFO - 2016-05-21 10:01:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:01:16 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:01:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:01:16 --> Final output sent to browser
DEBUG - 2016-05-21 10:01:16 --> Total execution time: 0.0900
INFO - 2016-05-21 10:01:35 --> Config Class Initialized
INFO - 2016-05-21 10:01:35 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:01:35 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:01:35 --> Utf8 Class Initialized
INFO - 2016-05-21 10:01:35 --> URI Class Initialized
INFO - 2016-05-21 10:01:35 --> Router Class Initialized
INFO - 2016-05-21 10:01:35 --> Output Class Initialized
INFO - 2016-05-21 10:01:35 --> Security Class Initialized
DEBUG - 2016-05-21 10:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:01:35 --> Input Class Initialized
INFO - 2016-05-21 10:01:35 --> Language Class Initialized
INFO - 2016-05-21 10:01:35 --> Loader Class Initialized
INFO - 2016-05-21 10:01:35 --> Helper loaded: url_helper
INFO - 2016-05-21 10:01:35 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:01:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:01:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:01:35 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:01:35 --> Helper loaded: form_helper
INFO - 2016-05-21 10:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:01:35 --> Form Validation Class Initialized
INFO - 2016-05-21 10:01:35 --> Controller Class Initialized
INFO - 2016-05-21 10:01:35 --> Model Class Initialized
INFO - 2016-05-21 10:01:35 --> Database Driver Class Initialized
INFO - 2016-05-21 10:01:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:01:35 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:01:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:01:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:01:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 10:01:35 --> Final output sent to browser
DEBUG - 2016-05-21 10:01:35 --> Total execution time: 0.0854
INFO - 2016-05-21 10:01:35 --> Config Class Initialized
INFO - 2016-05-21 10:01:35 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:01:35 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:01:35 --> Utf8 Class Initialized
INFO - 2016-05-21 10:01:35 --> URI Class Initialized
INFO - 2016-05-21 10:01:35 --> Router Class Initialized
INFO - 2016-05-21 10:01:35 --> Output Class Initialized
INFO - 2016-05-21 10:01:35 --> Security Class Initialized
DEBUG - 2016-05-21 10:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:01:35 --> Input Class Initialized
INFO - 2016-05-21 10:01:35 --> Language Class Initialized
INFO - 2016-05-21 10:01:35 --> Loader Class Initialized
INFO - 2016-05-21 10:01:35 --> Helper loaded: url_helper
INFO - 2016-05-21 10:01:35 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:01:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:01:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:01:35 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:01:35 --> Helper loaded: form_helper
INFO - 2016-05-21 10:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:01:35 --> Form Validation Class Initialized
INFO - 2016-05-21 10:01:35 --> Controller Class Initialized
INFO - 2016-05-21 10:01:35 --> Model Class Initialized
INFO - 2016-05-21 10:01:35 --> Database Driver Class Initialized
INFO - 2016-05-21 10:01:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:01:35 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:01:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:01:35 --> Final output sent to browser
DEBUG - 2016-05-21 10:01:35 --> Total execution time: 0.0859
INFO - 2016-05-21 10:02:18 --> Config Class Initialized
INFO - 2016-05-21 10:02:18 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:02:18 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:02:18 --> Utf8 Class Initialized
INFO - 2016-05-21 10:02:18 --> URI Class Initialized
INFO - 2016-05-21 10:02:18 --> Router Class Initialized
INFO - 2016-05-21 10:02:18 --> Output Class Initialized
INFO - 2016-05-21 10:02:18 --> Security Class Initialized
DEBUG - 2016-05-21 10:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:02:18 --> Input Class Initialized
INFO - 2016-05-21 10:02:18 --> Language Class Initialized
INFO - 2016-05-21 10:02:18 --> Loader Class Initialized
INFO - 2016-05-21 10:02:18 --> Helper loaded: url_helper
INFO - 2016-05-21 10:02:18 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:02:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:02:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:02:18 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:02:18 --> Helper loaded: form_helper
INFO - 2016-05-21 10:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:02:18 --> Form Validation Class Initialized
INFO - 2016-05-21 10:02:18 --> Controller Class Initialized
INFO - 2016-05-21 10:02:18 --> Model Class Initialized
INFO - 2016-05-21 10:02:18 --> Database Driver Class Initialized
INFO - 2016-05-21 10:02:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:02:18 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:02:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-21 10:02:18 --> Severity: Notice --> Undefined index: nombrecliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 63
ERROR - 2016-05-21 10:02:18 --> Severity: Notice --> Undefined index: nombrecliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 63
ERROR - 2016-05-21 10:02:18 --> Severity: Notice --> Undefined index: nombrecliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 63
ERROR - 2016-05-21 10:02:18 --> Severity: Notice --> Undefined index: nombrecliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 63
ERROR - 2016-05-21 10:02:18 --> Severity: Notice --> Undefined index: nombrecliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php 63
INFO - 2016-05-21 10:02:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:02:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 10:02:18 --> Final output sent to browser
DEBUG - 2016-05-21 10:02:18 --> Total execution time: 0.1094
INFO - 2016-05-21 10:02:19 --> Config Class Initialized
INFO - 2016-05-21 10:02:19 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:02:19 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:02:19 --> Utf8 Class Initialized
INFO - 2016-05-21 10:02:19 --> URI Class Initialized
INFO - 2016-05-21 10:02:19 --> Router Class Initialized
INFO - 2016-05-21 10:02:19 --> Output Class Initialized
INFO - 2016-05-21 10:02:19 --> Security Class Initialized
DEBUG - 2016-05-21 10:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:02:19 --> Input Class Initialized
INFO - 2016-05-21 10:02:19 --> Language Class Initialized
INFO - 2016-05-21 10:02:19 --> Loader Class Initialized
INFO - 2016-05-21 10:02:19 --> Helper loaded: url_helper
INFO - 2016-05-21 10:02:19 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:02:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:02:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:02:19 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:02:19 --> Helper loaded: form_helper
INFO - 2016-05-21 10:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:02:19 --> Form Validation Class Initialized
INFO - 2016-05-21 10:02:19 --> Controller Class Initialized
INFO - 2016-05-21 10:02:19 --> Model Class Initialized
INFO - 2016-05-21 10:02:19 --> Database Driver Class Initialized
INFO - 2016-05-21 10:02:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:02:19 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:02:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:02:19 --> Final output sent to browser
DEBUG - 2016-05-21 10:02:19 --> Total execution time: 0.0877
INFO - 2016-05-21 10:02:46 --> Config Class Initialized
INFO - 2016-05-21 10:02:46 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:02:46 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:02:46 --> Utf8 Class Initialized
INFO - 2016-05-21 10:02:46 --> URI Class Initialized
INFO - 2016-05-21 10:02:46 --> Router Class Initialized
INFO - 2016-05-21 10:02:46 --> Output Class Initialized
INFO - 2016-05-21 10:02:46 --> Security Class Initialized
DEBUG - 2016-05-21 10:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:02:46 --> Input Class Initialized
INFO - 2016-05-21 10:02:46 --> Language Class Initialized
INFO - 2016-05-21 10:02:46 --> Loader Class Initialized
INFO - 2016-05-21 10:02:46 --> Helper loaded: url_helper
INFO - 2016-05-21 10:02:46 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:02:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:02:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:02:46 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:02:46 --> Helper loaded: form_helper
INFO - 2016-05-21 10:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:02:46 --> Form Validation Class Initialized
INFO - 2016-05-21 10:02:46 --> Controller Class Initialized
INFO - 2016-05-21 10:02:46 --> Model Class Initialized
INFO - 2016-05-21 10:02:46 --> Database Driver Class Initialized
INFO - 2016-05-21 10:02:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:02:46 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:02:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:02:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:02:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 10:02:46 --> Final output sent to browser
DEBUG - 2016-05-21 10:02:46 --> Total execution time: 0.0818
INFO - 2016-05-21 10:02:46 --> Config Class Initialized
INFO - 2016-05-21 10:02:46 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:02:46 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:02:46 --> Utf8 Class Initialized
INFO - 2016-05-21 10:02:46 --> URI Class Initialized
INFO - 2016-05-21 10:02:46 --> Router Class Initialized
INFO - 2016-05-21 10:02:46 --> Output Class Initialized
INFO - 2016-05-21 10:02:46 --> Security Class Initialized
DEBUG - 2016-05-21 10:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:02:46 --> Input Class Initialized
INFO - 2016-05-21 10:02:46 --> Language Class Initialized
INFO - 2016-05-21 10:02:46 --> Loader Class Initialized
INFO - 2016-05-21 10:02:46 --> Helper loaded: url_helper
INFO - 2016-05-21 10:02:46 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:02:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:02:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:02:46 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:02:46 --> Helper loaded: form_helper
INFO - 2016-05-21 10:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:02:46 --> Form Validation Class Initialized
INFO - 2016-05-21 10:02:46 --> Controller Class Initialized
INFO - 2016-05-21 10:02:46 --> Model Class Initialized
INFO - 2016-05-21 10:02:46 --> Database Driver Class Initialized
INFO - 2016-05-21 10:02:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:02:46 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:02:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:02:46 --> Final output sent to browser
DEBUG - 2016-05-21 10:02:46 --> Total execution time: 0.0873
INFO - 2016-05-21 10:03:46 --> Config Class Initialized
INFO - 2016-05-21 10:03:46 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:03:46 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:03:46 --> Utf8 Class Initialized
INFO - 2016-05-21 10:03:46 --> URI Class Initialized
INFO - 2016-05-21 10:03:46 --> Router Class Initialized
INFO - 2016-05-21 10:03:46 --> Output Class Initialized
INFO - 2016-05-21 10:03:46 --> Security Class Initialized
DEBUG - 2016-05-21 10:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:03:46 --> Input Class Initialized
INFO - 2016-05-21 10:03:46 --> Language Class Initialized
INFO - 2016-05-21 10:03:46 --> Loader Class Initialized
INFO - 2016-05-21 10:03:46 --> Helper loaded: url_helper
INFO - 2016-05-21 10:03:46 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:03:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:03:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:03:46 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:03:46 --> Helper loaded: form_helper
INFO - 2016-05-21 10:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:03:46 --> Form Validation Class Initialized
INFO - 2016-05-21 10:03:46 --> Controller Class Initialized
INFO - 2016-05-21 10:03:46 --> Model Class Initialized
INFO - 2016-05-21 10:03:46 --> Database Driver Class Initialized
INFO - 2016-05-21 10:03:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:03:46 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:03:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:03:46 --> Final output sent to browser
DEBUG - 2016-05-21 10:03:46 --> Total execution time: 0.0735
INFO - 2016-05-21 10:04:18 --> Config Class Initialized
INFO - 2016-05-21 10:04:18 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:04:18 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:04:18 --> Utf8 Class Initialized
INFO - 2016-05-21 10:04:18 --> URI Class Initialized
INFO - 2016-05-21 10:04:18 --> Router Class Initialized
INFO - 2016-05-21 10:04:18 --> Output Class Initialized
INFO - 2016-05-21 10:04:18 --> Security Class Initialized
DEBUG - 2016-05-21 10:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:04:18 --> Input Class Initialized
INFO - 2016-05-21 10:04:18 --> Language Class Initialized
INFO - 2016-05-21 10:04:18 --> Loader Class Initialized
INFO - 2016-05-21 10:04:18 --> Helper loaded: url_helper
INFO - 2016-05-21 10:04:18 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:04:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:04:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:04:18 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:04:18 --> Helper loaded: form_helper
INFO - 2016-05-21 10:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:04:18 --> Form Validation Class Initialized
INFO - 2016-05-21 10:04:18 --> Controller Class Initialized
INFO - 2016-05-21 10:04:18 --> Model Class Initialized
INFO - 2016-05-21 10:04:18 --> Database Driver Class Initialized
INFO - 2016-05-21 10:04:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:04:18 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:04:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:04:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:04:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 10:04:18 --> Final output sent to browser
DEBUG - 2016-05-21 10:04:18 --> Total execution time: 0.0804
INFO - 2016-05-21 10:04:19 --> Config Class Initialized
INFO - 2016-05-21 10:04:19 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:04:19 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:04:19 --> Utf8 Class Initialized
INFO - 2016-05-21 10:04:19 --> URI Class Initialized
INFO - 2016-05-21 10:04:19 --> Router Class Initialized
INFO - 2016-05-21 10:04:19 --> Output Class Initialized
INFO - 2016-05-21 10:04:19 --> Security Class Initialized
DEBUG - 2016-05-21 10:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:04:19 --> Input Class Initialized
INFO - 2016-05-21 10:04:19 --> Language Class Initialized
INFO - 2016-05-21 10:04:19 --> Loader Class Initialized
INFO - 2016-05-21 10:04:19 --> Helper loaded: url_helper
INFO - 2016-05-21 10:04:19 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:04:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:04:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:04:19 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:04:19 --> Helper loaded: form_helper
INFO - 2016-05-21 10:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:04:19 --> Form Validation Class Initialized
INFO - 2016-05-21 10:04:19 --> Controller Class Initialized
INFO - 2016-05-21 10:04:19 --> Model Class Initialized
INFO - 2016-05-21 10:04:19 --> Database Driver Class Initialized
INFO - 2016-05-21 10:04:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:04:19 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:04:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:04:19 --> Final output sent to browser
DEBUG - 2016-05-21 10:04:19 --> Total execution time: 0.0878
INFO - 2016-05-21 10:04:20 --> Config Class Initialized
INFO - 2016-05-21 10:04:20 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:04:20 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:04:20 --> Utf8 Class Initialized
INFO - 2016-05-21 10:04:20 --> URI Class Initialized
INFO - 2016-05-21 10:04:20 --> Router Class Initialized
INFO - 2016-05-21 10:04:20 --> Output Class Initialized
INFO - 2016-05-21 10:04:20 --> Security Class Initialized
DEBUG - 2016-05-21 10:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:04:20 --> Input Class Initialized
INFO - 2016-05-21 10:04:20 --> Language Class Initialized
INFO - 2016-05-21 10:04:21 --> Loader Class Initialized
INFO - 2016-05-21 10:04:21 --> Helper loaded: url_helper
INFO - 2016-05-21 10:04:21 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:04:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:04:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:04:21 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:04:21 --> Helper loaded: form_helper
INFO - 2016-05-21 10:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:04:21 --> Form Validation Class Initialized
INFO - 2016-05-21 10:04:21 --> Controller Class Initialized
INFO - 2016-05-21 10:04:21 --> Model Class Initialized
INFO - 2016-05-21 10:04:21 --> Database Driver Class Initialized
INFO - 2016-05-21 10:04:21 --> Final output sent to browser
DEBUG - 2016-05-21 10:04:21 --> Total execution time: 0.4188
INFO - 2016-05-21 10:04:23 --> Config Class Initialized
INFO - 2016-05-21 10:04:23 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:04:23 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:04:23 --> Utf8 Class Initialized
INFO - 2016-05-21 10:04:23 --> URI Class Initialized
INFO - 2016-05-21 10:04:23 --> Router Class Initialized
INFO - 2016-05-21 10:04:23 --> Output Class Initialized
INFO - 2016-05-21 10:04:23 --> Security Class Initialized
DEBUG - 2016-05-21 10:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:04:23 --> Input Class Initialized
INFO - 2016-05-21 10:04:23 --> Language Class Initialized
INFO - 2016-05-21 10:04:23 --> Loader Class Initialized
INFO - 2016-05-21 10:04:23 --> Helper loaded: url_helper
INFO - 2016-05-21 10:04:23 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:04:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:04:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:04:23 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:04:23 --> Helper loaded: form_helper
INFO - 2016-05-21 10:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:04:23 --> Form Validation Class Initialized
INFO - 2016-05-21 10:04:23 --> Controller Class Initialized
INFO - 2016-05-21 10:04:23 --> Model Class Initialized
INFO - 2016-05-21 10:04:23 --> Database Driver Class Initialized
INFO - 2016-05-21 10:04:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:04:23 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:04:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:04:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:04:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 10:04:23 --> Final output sent to browser
DEBUG - 2016-05-21 10:04:23 --> Total execution time: 0.1164
INFO - 2016-05-21 10:04:24 --> Config Class Initialized
INFO - 2016-05-21 10:04:24 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:04:24 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:04:24 --> Utf8 Class Initialized
INFO - 2016-05-21 10:04:24 --> URI Class Initialized
INFO - 2016-05-21 10:04:24 --> Router Class Initialized
INFO - 2016-05-21 10:04:24 --> Output Class Initialized
INFO - 2016-05-21 10:04:24 --> Security Class Initialized
DEBUG - 2016-05-21 10:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:04:24 --> Input Class Initialized
INFO - 2016-05-21 10:04:24 --> Language Class Initialized
INFO - 2016-05-21 10:04:24 --> Loader Class Initialized
INFO - 2016-05-21 10:04:24 --> Helper loaded: url_helper
INFO - 2016-05-21 10:04:24 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:04:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:04:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:04:24 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:04:24 --> Helper loaded: form_helper
INFO - 2016-05-21 10:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:04:24 --> Form Validation Class Initialized
INFO - 2016-05-21 10:04:24 --> Controller Class Initialized
INFO - 2016-05-21 10:04:24 --> Model Class Initialized
INFO - 2016-05-21 10:04:24 --> Database Driver Class Initialized
INFO - 2016-05-21 10:04:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:04:24 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:04:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:04:24 --> Final output sent to browser
DEBUG - 2016-05-21 10:04:24 --> Total execution time: 0.1213
INFO - 2016-05-21 10:04:31 --> Config Class Initialized
INFO - 2016-05-21 10:04:31 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:04:31 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:04:31 --> Utf8 Class Initialized
INFO - 2016-05-21 10:04:31 --> URI Class Initialized
INFO - 2016-05-21 10:04:31 --> Router Class Initialized
INFO - 2016-05-21 10:04:31 --> Output Class Initialized
INFO - 2016-05-21 10:04:31 --> Security Class Initialized
DEBUG - 2016-05-21 10:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:04:31 --> Input Class Initialized
INFO - 2016-05-21 10:04:31 --> Language Class Initialized
INFO - 2016-05-21 10:04:31 --> Loader Class Initialized
INFO - 2016-05-21 10:04:31 --> Helper loaded: url_helper
INFO - 2016-05-21 10:04:31 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:04:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:04:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:04:31 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:04:31 --> Helper loaded: form_helper
INFO - 2016-05-21 10:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:04:31 --> Form Validation Class Initialized
INFO - 2016-05-21 10:04:31 --> Controller Class Initialized
INFO - 2016-05-21 10:04:31 --> Model Class Initialized
INFO - 2016-05-21 10:04:31 --> Database Driver Class Initialized
INFO - 2016-05-21 10:04:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:04:31 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:04:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:04:31 --> Config Class Initialized
INFO - 2016-05-21 10:04:31 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:04:31 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:04:31 --> Utf8 Class Initialized
INFO - 2016-05-21 10:04:31 --> URI Class Initialized
INFO - 2016-05-21 10:04:31 --> Router Class Initialized
INFO - 2016-05-21 10:04:31 --> Output Class Initialized
INFO - 2016-05-21 10:04:31 --> Security Class Initialized
DEBUG - 2016-05-21 10:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:04:31 --> Input Class Initialized
INFO - 2016-05-21 10:04:31 --> Language Class Initialized
INFO - 2016-05-21 10:04:31 --> Loader Class Initialized
INFO - 2016-05-21 10:04:31 --> Helper loaded: url_helper
INFO - 2016-05-21 10:04:31 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:04:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:04:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:04:31 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:04:31 --> Helper loaded: form_helper
INFO - 2016-05-21 10:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:04:31 --> Form Validation Class Initialized
INFO - 2016-05-21 10:04:31 --> Controller Class Initialized
INFO - 2016-05-21 10:04:31 --> Model Class Initialized
INFO - 2016-05-21 10:04:31 --> Database Driver Class Initialized
INFO - 2016-05-21 10:04:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:04:31 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:04:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:04:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:04:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 10:04:31 --> Final output sent to browser
DEBUG - 2016-05-21 10:04:31 --> Total execution time: 0.0775
INFO - 2016-05-21 10:04:31 --> Config Class Initialized
INFO - 2016-05-21 10:04:31 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:04:31 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:04:31 --> Utf8 Class Initialized
INFO - 2016-05-21 10:04:31 --> URI Class Initialized
INFO - 2016-05-21 10:04:31 --> Router Class Initialized
INFO - 2016-05-21 10:04:31 --> Output Class Initialized
INFO - 2016-05-21 10:04:31 --> Security Class Initialized
DEBUG - 2016-05-21 10:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:04:31 --> Input Class Initialized
INFO - 2016-05-21 10:04:31 --> Language Class Initialized
INFO - 2016-05-21 10:04:31 --> Loader Class Initialized
INFO - 2016-05-21 10:04:31 --> Helper loaded: url_helper
INFO - 2016-05-21 10:04:31 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:04:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:04:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:04:31 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:04:31 --> Helper loaded: form_helper
INFO - 2016-05-21 10:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:04:31 --> Form Validation Class Initialized
INFO - 2016-05-21 10:04:31 --> Controller Class Initialized
INFO - 2016-05-21 10:04:31 --> Model Class Initialized
INFO - 2016-05-21 10:04:31 --> Database Driver Class Initialized
INFO - 2016-05-21 10:04:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:04:31 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:04:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:04:31 --> Final output sent to browser
DEBUG - 2016-05-21 10:04:31 --> Total execution time: 0.0825
INFO - 2016-05-21 10:05:19 --> Config Class Initialized
INFO - 2016-05-21 10:05:19 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:05:19 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:05:19 --> Utf8 Class Initialized
INFO - 2016-05-21 10:05:19 --> URI Class Initialized
INFO - 2016-05-21 10:05:19 --> Router Class Initialized
INFO - 2016-05-21 10:05:19 --> Output Class Initialized
INFO - 2016-05-21 10:05:19 --> Security Class Initialized
DEBUG - 2016-05-21 10:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:05:19 --> Input Class Initialized
INFO - 2016-05-21 10:05:19 --> Language Class Initialized
INFO - 2016-05-21 10:05:19 --> Loader Class Initialized
INFO - 2016-05-21 10:05:19 --> Helper loaded: url_helper
INFO - 2016-05-21 10:05:19 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:05:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:05:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:05:19 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:05:19 --> Helper loaded: form_helper
INFO - 2016-05-21 10:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:05:19 --> Form Validation Class Initialized
INFO - 2016-05-21 10:05:19 --> Controller Class Initialized
INFO - 2016-05-21 10:05:19 --> Model Class Initialized
INFO - 2016-05-21 10:05:19 --> Database Driver Class Initialized
INFO - 2016-05-21 10:05:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:05:19 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:05:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:05:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:05:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 10:05:19 --> Final output sent to browser
DEBUG - 2016-05-21 10:05:19 --> Total execution time: 0.0849
INFO - 2016-05-21 10:05:19 --> Config Class Initialized
INFO - 2016-05-21 10:05:19 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:05:19 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:05:19 --> Utf8 Class Initialized
INFO - 2016-05-21 10:05:19 --> URI Class Initialized
INFO - 2016-05-21 10:05:19 --> Router Class Initialized
INFO - 2016-05-21 10:05:19 --> Output Class Initialized
INFO - 2016-05-21 10:05:19 --> Security Class Initialized
DEBUG - 2016-05-21 10:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:05:19 --> Input Class Initialized
INFO - 2016-05-21 10:05:19 --> Language Class Initialized
INFO - 2016-05-21 10:05:19 --> Loader Class Initialized
INFO - 2016-05-21 10:05:19 --> Helper loaded: url_helper
INFO - 2016-05-21 10:05:19 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:05:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:05:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:05:19 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:05:19 --> Helper loaded: form_helper
INFO - 2016-05-21 10:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:05:19 --> Form Validation Class Initialized
INFO - 2016-05-21 10:05:19 --> Controller Class Initialized
INFO - 2016-05-21 10:05:19 --> Model Class Initialized
INFO - 2016-05-21 10:05:19 --> Database Driver Class Initialized
INFO - 2016-05-21 10:05:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:05:19 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:05:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:05:19 --> Final output sent to browser
DEBUG - 2016-05-21 10:05:19 --> Total execution time: 0.0900
INFO - 2016-05-21 10:06:20 --> Config Class Initialized
INFO - 2016-05-21 10:06:20 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:06:20 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:06:20 --> Utf8 Class Initialized
INFO - 2016-05-21 10:06:20 --> URI Class Initialized
INFO - 2016-05-21 10:06:20 --> Router Class Initialized
INFO - 2016-05-21 10:06:20 --> Output Class Initialized
INFO - 2016-05-21 10:06:20 --> Security Class Initialized
DEBUG - 2016-05-21 10:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:06:20 --> Input Class Initialized
INFO - 2016-05-21 10:06:20 --> Language Class Initialized
INFO - 2016-05-21 10:06:20 --> Loader Class Initialized
INFO - 2016-05-21 10:06:20 --> Helper loaded: url_helper
INFO - 2016-05-21 10:06:20 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:06:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:06:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:06:20 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:06:20 --> Helper loaded: form_helper
INFO - 2016-05-21 10:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:06:20 --> Form Validation Class Initialized
INFO - 2016-05-21 10:06:20 --> Controller Class Initialized
INFO - 2016-05-21 10:06:20 --> Model Class Initialized
INFO - 2016-05-21 10:06:20 --> Database Driver Class Initialized
INFO - 2016-05-21 10:06:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:06:20 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:06:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:06:20 --> Final output sent to browser
DEBUG - 2016-05-21 10:06:20 --> Total execution time: 0.0766
INFO - 2016-05-21 10:07:20 --> Config Class Initialized
INFO - 2016-05-21 10:07:20 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:07:20 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:07:20 --> Utf8 Class Initialized
INFO - 2016-05-21 10:07:20 --> URI Class Initialized
INFO - 2016-05-21 10:07:20 --> Router Class Initialized
INFO - 2016-05-21 10:07:20 --> Output Class Initialized
INFO - 2016-05-21 10:07:20 --> Security Class Initialized
DEBUG - 2016-05-21 10:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:07:20 --> Input Class Initialized
INFO - 2016-05-21 10:07:20 --> Language Class Initialized
INFO - 2016-05-21 10:07:20 --> Loader Class Initialized
INFO - 2016-05-21 10:07:20 --> Helper loaded: url_helper
INFO - 2016-05-21 10:07:20 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:07:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:07:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:07:20 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:07:20 --> Helper loaded: form_helper
INFO - 2016-05-21 10:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:07:20 --> Form Validation Class Initialized
INFO - 2016-05-21 10:07:20 --> Controller Class Initialized
INFO - 2016-05-21 10:07:20 --> Model Class Initialized
INFO - 2016-05-21 10:07:20 --> Database Driver Class Initialized
INFO - 2016-05-21 10:07:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:07:20 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:07:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:07:20 --> Final output sent to browser
DEBUG - 2016-05-21 10:07:20 --> Total execution time: 0.0761
INFO - 2016-05-21 10:07:33 --> Config Class Initialized
INFO - 2016-05-21 10:07:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:07:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:07:33 --> Utf8 Class Initialized
INFO - 2016-05-21 10:07:33 --> URI Class Initialized
INFO - 2016-05-21 10:07:33 --> Router Class Initialized
INFO - 2016-05-21 10:07:33 --> Output Class Initialized
INFO - 2016-05-21 10:07:33 --> Security Class Initialized
DEBUG - 2016-05-21 10:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:07:33 --> Input Class Initialized
INFO - 2016-05-21 10:07:33 --> Language Class Initialized
INFO - 2016-05-21 10:07:33 --> Loader Class Initialized
INFO - 2016-05-21 10:07:33 --> Helper loaded: url_helper
INFO - 2016-05-21 10:07:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:07:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:07:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:07:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:07:33 --> Helper loaded: form_helper
INFO - 2016-05-21 10:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:07:33 --> Form Validation Class Initialized
INFO - 2016-05-21 10:07:33 --> Controller Class Initialized
INFO - 2016-05-21 10:07:33 --> Model Class Initialized
INFO - 2016-05-21 10:07:33 --> Database Driver Class Initialized
INFO - 2016-05-21 10:07:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:07:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:07:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:07:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:07:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 10:07:33 --> Final output sent to browser
DEBUG - 2016-05-21 10:07:33 --> Total execution time: 0.1097
INFO - 2016-05-21 10:07:34 --> Config Class Initialized
INFO - 2016-05-21 10:07:34 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:07:34 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:07:34 --> Utf8 Class Initialized
INFO - 2016-05-21 10:07:34 --> URI Class Initialized
INFO - 2016-05-21 10:07:34 --> Router Class Initialized
INFO - 2016-05-21 10:07:34 --> Output Class Initialized
INFO - 2016-05-21 10:07:34 --> Security Class Initialized
DEBUG - 2016-05-21 10:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:07:34 --> Input Class Initialized
INFO - 2016-05-21 10:07:34 --> Language Class Initialized
INFO - 2016-05-21 10:07:34 --> Loader Class Initialized
INFO - 2016-05-21 10:07:34 --> Helper loaded: url_helper
INFO - 2016-05-21 10:07:34 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:07:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:07:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:07:34 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:07:34 --> Helper loaded: form_helper
INFO - 2016-05-21 10:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:07:34 --> Form Validation Class Initialized
INFO - 2016-05-21 10:07:34 --> Controller Class Initialized
INFO - 2016-05-21 10:07:34 --> Model Class Initialized
INFO - 2016-05-21 10:07:34 --> Database Driver Class Initialized
INFO - 2016-05-21 10:07:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:07:34 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:07:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:07:34 --> Final output sent to browser
DEBUG - 2016-05-21 10:07:34 --> Total execution time: 0.0844
INFO - 2016-05-21 10:08:08 --> Config Class Initialized
INFO - 2016-05-21 10:08:08 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:08:08 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:08:08 --> Utf8 Class Initialized
INFO - 2016-05-21 10:08:08 --> URI Class Initialized
INFO - 2016-05-21 10:08:08 --> Router Class Initialized
INFO - 2016-05-21 10:08:08 --> Output Class Initialized
INFO - 2016-05-21 10:08:08 --> Security Class Initialized
DEBUG - 2016-05-21 10:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:08:08 --> Input Class Initialized
INFO - 2016-05-21 10:08:08 --> Language Class Initialized
INFO - 2016-05-21 10:08:08 --> Loader Class Initialized
INFO - 2016-05-21 10:08:08 --> Helper loaded: url_helper
INFO - 2016-05-21 10:08:08 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:08:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:08:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:08:08 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:08:08 --> Helper loaded: form_helper
INFO - 2016-05-21 10:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:08:08 --> Form Validation Class Initialized
INFO - 2016-05-21 10:08:08 --> Controller Class Initialized
INFO - 2016-05-21 10:08:08 --> Model Class Initialized
INFO - 2016-05-21 10:08:08 --> Database Driver Class Initialized
INFO - 2016-05-21 10:08:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:08:08 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:08:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:08:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:08:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 10:08:08 --> Final output sent to browser
DEBUG - 2016-05-21 10:08:08 --> Total execution time: 0.0788
INFO - 2016-05-21 10:08:09 --> Config Class Initialized
INFO - 2016-05-21 10:08:09 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:08:09 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:08:09 --> Utf8 Class Initialized
INFO - 2016-05-21 10:08:09 --> URI Class Initialized
INFO - 2016-05-21 10:08:09 --> Router Class Initialized
INFO - 2016-05-21 10:08:09 --> Output Class Initialized
INFO - 2016-05-21 10:08:09 --> Security Class Initialized
DEBUG - 2016-05-21 10:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:08:09 --> Input Class Initialized
INFO - 2016-05-21 10:08:09 --> Language Class Initialized
INFO - 2016-05-21 10:08:09 --> Loader Class Initialized
INFO - 2016-05-21 10:08:09 --> Helper loaded: url_helper
INFO - 2016-05-21 10:08:09 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:08:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:08:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:08:09 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:08:09 --> Helper loaded: form_helper
INFO - 2016-05-21 10:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:08:09 --> Form Validation Class Initialized
INFO - 2016-05-21 10:08:09 --> Controller Class Initialized
INFO - 2016-05-21 10:08:09 --> Model Class Initialized
INFO - 2016-05-21 10:08:09 --> Database Driver Class Initialized
INFO - 2016-05-21 10:08:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:08:09 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:08:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:08:09 --> Final output sent to browser
DEBUG - 2016-05-21 10:08:09 --> Total execution time: 0.0852
INFO - 2016-05-21 10:08:25 --> Config Class Initialized
INFO - 2016-05-21 10:08:25 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:08:25 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:08:25 --> Utf8 Class Initialized
INFO - 2016-05-21 10:08:25 --> URI Class Initialized
INFO - 2016-05-21 10:08:25 --> Router Class Initialized
INFO - 2016-05-21 10:08:25 --> Output Class Initialized
INFO - 2016-05-21 10:08:25 --> Security Class Initialized
DEBUG - 2016-05-21 10:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:08:25 --> Input Class Initialized
INFO - 2016-05-21 10:08:25 --> Language Class Initialized
INFO - 2016-05-21 10:08:25 --> Loader Class Initialized
INFO - 2016-05-21 10:08:25 --> Helper loaded: url_helper
INFO - 2016-05-21 10:08:25 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:08:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:08:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:08:25 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:08:25 --> Helper loaded: form_helper
INFO - 2016-05-21 10:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:08:26 --> Form Validation Class Initialized
INFO - 2016-05-21 10:08:26 --> Controller Class Initialized
INFO - 2016-05-21 10:08:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-21 10:08:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 10:08:26 --> Final output sent to browser
DEBUG - 2016-05-21 10:08:26 --> Total execution time: 0.0554
INFO - 2016-05-21 10:08:27 --> Config Class Initialized
INFO - 2016-05-21 10:08:27 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:08:27 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:08:27 --> Utf8 Class Initialized
INFO - 2016-05-21 10:08:27 --> URI Class Initialized
INFO - 2016-05-21 10:08:27 --> Router Class Initialized
INFO - 2016-05-21 10:08:27 --> Output Class Initialized
INFO - 2016-05-21 10:08:27 --> Security Class Initialized
DEBUG - 2016-05-21 10:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:08:27 --> Input Class Initialized
INFO - 2016-05-21 10:08:27 --> Language Class Initialized
INFO - 2016-05-21 10:08:27 --> Loader Class Initialized
INFO - 2016-05-21 10:08:27 --> Helper loaded: url_helper
INFO - 2016-05-21 10:08:27 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:08:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:08:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:08:27 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:08:27 --> Helper loaded: form_helper
INFO - 2016-05-21 10:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:08:27 --> Form Validation Class Initialized
INFO - 2016-05-21 10:08:27 --> Controller Class Initialized
INFO - 2016-05-21 10:08:27 --> Model Class Initialized
INFO - 2016-05-21 10:08:27 --> Database Driver Class Initialized
INFO - 2016-05-21 10:08:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:08:27 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:08:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:08:27 --> Final output sent to browser
DEBUG - 2016-05-21 10:08:27 --> Total execution time: 0.0900
INFO - 2016-05-21 10:08:29 --> Config Class Initialized
INFO - 2016-05-21 10:08:29 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:08:29 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:08:29 --> Utf8 Class Initialized
INFO - 2016-05-21 10:08:29 --> URI Class Initialized
INFO - 2016-05-21 10:08:29 --> Router Class Initialized
INFO - 2016-05-21 10:08:29 --> Output Class Initialized
INFO - 2016-05-21 10:08:29 --> Security Class Initialized
DEBUG - 2016-05-21 10:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:08:29 --> Input Class Initialized
INFO - 2016-05-21 10:08:29 --> Language Class Initialized
INFO - 2016-05-21 10:08:29 --> Loader Class Initialized
INFO - 2016-05-21 10:08:29 --> Helper loaded: url_helper
INFO - 2016-05-21 10:08:29 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:08:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:08:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:08:29 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:08:29 --> Helper loaded: form_helper
INFO - 2016-05-21 10:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:08:29 --> Form Validation Class Initialized
INFO - 2016-05-21 10:08:29 --> Controller Class Initialized
INFO - 2016-05-21 10:08:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-21 10:08:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 10:08:29 --> Final output sent to browser
DEBUG - 2016-05-21 10:08:29 --> Total execution time: 0.0599
INFO - 2016-05-21 10:08:29 --> Config Class Initialized
INFO - 2016-05-21 10:08:29 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:08:29 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:08:29 --> Utf8 Class Initialized
INFO - 2016-05-21 10:08:29 --> URI Class Initialized
INFO - 2016-05-21 10:08:29 --> Router Class Initialized
INFO - 2016-05-21 10:08:29 --> Output Class Initialized
INFO - 2016-05-21 10:08:29 --> Security Class Initialized
DEBUG - 2016-05-21 10:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:08:29 --> Input Class Initialized
INFO - 2016-05-21 10:08:29 --> Language Class Initialized
INFO - 2016-05-21 10:08:29 --> Loader Class Initialized
INFO - 2016-05-21 10:08:29 --> Helper loaded: url_helper
INFO - 2016-05-21 10:08:29 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:08:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:08:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:08:29 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:08:29 --> Helper loaded: form_helper
INFO - 2016-05-21 10:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:08:29 --> Form Validation Class Initialized
INFO - 2016-05-21 10:08:29 --> Controller Class Initialized
INFO - 2016-05-21 10:08:29 --> Model Class Initialized
INFO - 2016-05-21 10:08:29 --> Database Driver Class Initialized
INFO - 2016-05-21 10:08:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:08:29 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:08:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:08:29 --> Final output sent to browser
DEBUG - 2016-05-21 10:08:29 --> Total execution time: 0.1005
INFO - 2016-05-21 10:08:31 --> Config Class Initialized
INFO - 2016-05-21 10:08:31 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:08:31 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:08:31 --> Utf8 Class Initialized
INFO - 2016-05-21 10:08:31 --> URI Class Initialized
INFO - 2016-05-21 10:08:31 --> Router Class Initialized
INFO - 2016-05-21 10:08:31 --> Output Class Initialized
INFO - 2016-05-21 10:08:31 --> Security Class Initialized
DEBUG - 2016-05-21 10:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:08:31 --> Input Class Initialized
INFO - 2016-05-21 10:08:31 --> Language Class Initialized
INFO - 2016-05-21 10:08:31 --> Loader Class Initialized
INFO - 2016-05-21 10:08:31 --> Helper loaded: url_helper
INFO - 2016-05-21 10:08:31 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:08:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:08:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:08:31 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:08:31 --> Helper loaded: form_helper
INFO - 2016-05-21 10:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:08:31 --> Form Validation Class Initialized
INFO - 2016-05-21 10:08:31 --> Controller Class Initialized
INFO - 2016-05-21 10:08:31 --> Config Class Initialized
INFO - 2016-05-21 10:08:31 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:08:31 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:08:31 --> Utf8 Class Initialized
INFO - 2016-05-21 10:08:31 --> URI Class Initialized
INFO - 2016-05-21 10:08:31 --> Router Class Initialized
INFO - 2016-05-21 10:08:31 --> Output Class Initialized
INFO - 2016-05-21 10:08:31 --> Security Class Initialized
DEBUG - 2016-05-21 10:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:08:31 --> Input Class Initialized
INFO - 2016-05-21 10:08:31 --> Language Class Initialized
INFO - 2016-05-21 10:08:31 --> Loader Class Initialized
INFO - 2016-05-21 10:08:31 --> Helper loaded: url_helper
INFO - 2016-05-21 10:08:31 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:08:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:08:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:08:31 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:08:31 --> Helper loaded: form_helper
INFO - 2016-05-21 10:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:08:31 --> Form Validation Class Initialized
INFO - 2016-05-21 10:08:31 --> Controller Class Initialized
INFO - 2016-05-21 10:08:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-21 10:08:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 10:08:31 --> Final output sent to browser
DEBUG - 2016-05-21 10:08:31 --> Total execution time: 0.0926
INFO - 2016-05-21 10:08:31 --> Config Class Initialized
INFO - 2016-05-21 10:08:31 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:08:31 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:08:31 --> Utf8 Class Initialized
INFO - 2016-05-21 10:08:31 --> URI Class Initialized
INFO - 2016-05-21 10:08:31 --> Router Class Initialized
INFO - 2016-05-21 10:08:31 --> Output Class Initialized
INFO - 2016-05-21 10:08:31 --> Security Class Initialized
DEBUG - 2016-05-21 10:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:08:31 --> Input Class Initialized
INFO - 2016-05-21 10:08:31 --> Language Class Initialized
INFO - 2016-05-21 10:08:31 --> Loader Class Initialized
INFO - 2016-05-21 10:08:31 --> Helper loaded: url_helper
INFO - 2016-05-21 10:08:31 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:08:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:08:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:08:31 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:08:31 --> Helper loaded: form_helper
INFO - 2016-05-21 10:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:08:31 --> Form Validation Class Initialized
INFO - 2016-05-21 10:08:31 --> Controller Class Initialized
INFO - 2016-05-21 10:08:31 --> Model Class Initialized
INFO - 2016-05-21 10:08:31 --> Database Driver Class Initialized
INFO - 2016-05-21 10:08:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:08:31 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:08:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:08:31 --> Final output sent to browser
DEBUG - 2016-05-21 10:08:31 --> Total execution time: 0.1093
INFO - 2016-05-21 10:08:34 --> Config Class Initialized
INFO - 2016-05-21 10:08:34 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:08:34 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:08:34 --> Utf8 Class Initialized
INFO - 2016-05-21 10:08:34 --> URI Class Initialized
INFO - 2016-05-21 10:08:34 --> Router Class Initialized
INFO - 2016-05-21 10:08:34 --> Output Class Initialized
INFO - 2016-05-21 10:08:34 --> Security Class Initialized
DEBUG - 2016-05-21 10:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:08:34 --> Input Class Initialized
INFO - 2016-05-21 10:08:34 --> Language Class Initialized
INFO - 2016-05-21 10:08:34 --> Loader Class Initialized
INFO - 2016-05-21 10:08:34 --> Helper loaded: url_helper
INFO - 2016-05-21 10:08:34 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:08:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:08:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:08:34 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:08:34 --> Helper loaded: form_helper
INFO - 2016-05-21 10:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:08:34 --> Form Validation Class Initialized
INFO - 2016-05-21 10:08:34 --> Controller Class Initialized
INFO - 2016-05-21 10:08:34 --> Config Class Initialized
INFO - 2016-05-21 10:08:34 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:08:34 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:08:34 --> Utf8 Class Initialized
INFO - 2016-05-21 10:08:34 --> URI Class Initialized
INFO - 2016-05-21 10:08:34 --> Router Class Initialized
INFO - 2016-05-21 10:08:34 --> Output Class Initialized
INFO - 2016-05-21 10:08:34 --> Security Class Initialized
DEBUG - 2016-05-21 10:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:08:34 --> Input Class Initialized
INFO - 2016-05-21 10:08:34 --> Language Class Initialized
INFO - 2016-05-21 10:08:34 --> Loader Class Initialized
INFO - 2016-05-21 10:08:34 --> Helper loaded: url_helper
INFO - 2016-05-21 10:08:34 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:08:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:08:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:08:34 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:08:34 --> Helper loaded: form_helper
INFO - 2016-05-21 10:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:08:34 --> Form Validation Class Initialized
INFO - 2016-05-21 10:08:34 --> Controller Class Initialized
INFO - 2016-05-21 10:08:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-21 10:08:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:08:34 --> Final output sent to browser
DEBUG - 2016-05-21 10:08:34 --> Total execution time: 0.0769
INFO - 2016-05-21 10:08:34 --> Config Class Initialized
INFO - 2016-05-21 10:08:34 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:08:34 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:08:34 --> Utf8 Class Initialized
INFO - 2016-05-21 10:08:34 --> URI Class Initialized
INFO - 2016-05-21 10:08:34 --> Router Class Initialized
INFO - 2016-05-21 10:08:34 --> Output Class Initialized
INFO - 2016-05-21 10:08:34 --> Security Class Initialized
DEBUG - 2016-05-21 10:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:08:34 --> Input Class Initialized
INFO - 2016-05-21 10:08:34 --> Language Class Initialized
INFO - 2016-05-21 10:08:34 --> Loader Class Initialized
INFO - 2016-05-21 10:08:34 --> Helper loaded: url_helper
INFO - 2016-05-21 10:08:34 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:08:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:08:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:08:34 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:08:34 --> Helper loaded: form_helper
INFO - 2016-05-21 10:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:08:34 --> Form Validation Class Initialized
INFO - 2016-05-21 10:08:34 --> Controller Class Initialized
INFO - 2016-05-21 10:08:34 --> Model Class Initialized
INFO - 2016-05-21 10:08:34 --> Database Driver Class Initialized
INFO - 2016-05-21 10:08:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:08:34 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:08:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:08:34 --> Final output sent to browser
DEBUG - 2016-05-21 10:08:34 --> Total execution time: 0.0839
INFO - 2016-05-21 10:08:37 --> Config Class Initialized
INFO - 2016-05-21 10:08:37 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:08:37 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:08:37 --> Utf8 Class Initialized
INFO - 2016-05-21 10:08:37 --> URI Class Initialized
INFO - 2016-05-21 10:08:37 --> Router Class Initialized
INFO - 2016-05-21 10:08:37 --> Output Class Initialized
INFO - 2016-05-21 10:08:37 --> Security Class Initialized
DEBUG - 2016-05-21 10:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:08:37 --> Input Class Initialized
INFO - 2016-05-21 10:08:37 --> Language Class Initialized
INFO - 2016-05-21 10:08:37 --> Loader Class Initialized
INFO - 2016-05-21 10:08:37 --> Helper loaded: url_helper
INFO - 2016-05-21 10:08:37 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:08:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:08:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:08:37 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:08:37 --> Helper loaded: form_helper
INFO - 2016-05-21 10:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:08:37 --> Form Validation Class Initialized
INFO - 2016-05-21 10:08:37 --> Controller Class Initialized
INFO - 2016-05-21 10:08:37 --> Model Class Initialized
INFO - 2016-05-21 10:08:37 --> Database Driver Class Initialized
INFO - 2016-05-21 10:08:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:08:37 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:08:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:08:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:08:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:08:37 --> Final output sent to browser
DEBUG - 2016-05-21 10:08:37 --> Total execution time: 0.0831
INFO - 2016-05-21 10:08:37 --> Config Class Initialized
INFO - 2016-05-21 10:08:37 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:08:37 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:08:37 --> Utf8 Class Initialized
INFO - 2016-05-21 10:08:37 --> URI Class Initialized
INFO - 2016-05-21 10:08:37 --> Router Class Initialized
INFO - 2016-05-21 10:08:37 --> Output Class Initialized
INFO - 2016-05-21 10:08:37 --> Security Class Initialized
DEBUG - 2016-05-21 10:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:08:37 --> Input Class Initialized
INFO - 2016-05-21 10:08:37 --> Language Class Initialized
INFO - 2016-05-21 10:08:37 --> Loader Class Initialized
INFO - 2016-05-21 10:08:37 --> Helper loaded: url_helper
INFO - 2016-05-21 10:08:37 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:08:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:08:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:08:37 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:08:37 --> Helper loaded: form_helper
INFO - 2016-05-21 10:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:08:37 --> Form Validation Class Initialized
INFO - 2016-05-21 10:08:37 --> Controller Class Initialized
INFO - 2016-05-21 10:08:37 --> Model Class Initialized
INFO - 2016-05-21 10:08:37 --> Database Driver Class Initialized
INFO - 2016-05-21 10:08:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:08:37 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:08:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:08:37 --> Final output sent to browser
DEBUG - 2016-05-21 10:08:37 --> Total execution time: 0.0858
INFO - 2016-05-21 10:09:27 --> Config Class Initialized
INFO - 2016-05-21 10:09:27 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:09:27 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:09:27 --> Utf8 Class Initialized
INFO - 2016-05-21 10:09:27 --> URI Class Initialized
INFO - 2016-05-21 10:09:27 --> Router Class Initialized
INFO - 2016-05-21 10:09:27 --> Output Class Initialized
INFO - 2016-05-21 10:09:27 --> Security Class Initialized
DEBUG - 2016-05-21 10:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:09:27 --> Input Class Initialized
INFO - 2016-05-21 10:09:27 --> Language Class Initialized
INFO - 2016-05-21 10:09:27 --> Loader Class Initialized
INFO - 2016-05-21 10:09:27 --> Helper loaded: url_helper
INFO - 2016-05-21 10:09:27 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:09:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:09:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:09:27 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:09:27 --> Helper loaded: form_helper
INFO - 2016-05-21 10:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:09:27 --> Form Validation Class Initialized
INFO - 2016-05-21 10:09:27 --> Controller Class Initialized
INFO - 2016-05-21 10:09:27 --> Model Class Initialized
INFO - 2016-05-21 10:09:27 --> Database Driver Class Initialized
INFO - 2016-05-21 10:09:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:09:27 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:09:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:09:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:09:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:09:27 --> Final output sent to browser
DEBUG - 2016-05-21 10:09:27 --> Total execution time: 0.0864
INFO - 2016-05-21 10:09:27 --> Config Class Initialized
INFO - 2016-05-21 10:09:27 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:09:27 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:09:27 --> Utf8 Class Initialized
INFO - 2016-05-21 10:09:27 --> URI Class Initialized
INFO - 2016-05-21 10:09:27 --> Router Class Initialized
INFO - 2016-05-21 10:09:27 --> Output Class Initialized
INFO - 2016-05-21 10:09:27 --> Security Class Initialized
DEBUG - 2016-05-21 10:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:09:27 --> Input Class Initialized
INFO - 2016-05-21 10:09:27 --> Language Class Initialized
INFO - 2016-05-21 10:09:27 --> Loader Class Initialized
INFO - 2016-05-21 10:09:27 --> Helper loaded: url_helper
INFO - 2016-05-21 10:09:27 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:09:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:09:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:09:27 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:09:27 --> Helper loaded: form_helper
INFO - 2016-05-21 10:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:09:27 --> Form Validation Class Initialized
INFO - 2016-05-21 10:09:27 --> Controller Class Initialized
INFO - 2016-05-21 10:09:27 --> Model Class Initialized
INFO - 2016-05-21 10:09:28 --> Database Driver Class Initialized
INFO - 2016-05-21 10:09:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:09:28 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:09:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:09:28 --> Final output sent to browser
DEBUG - 2016-05-21 10:09:28 --> Total execution time: 0.0820
INFO - 2016-05-21 10:09:35 --> Config Class Initialized
INFO - 2016-05-21 10:09:35 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:09:35 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:09:35 --> Utf8 Class Initialized
INFO - 2016-05-21 10:09:35 --> URI Class Initialized
INFO - 2016-05-21 10:09:35 --> Router Class Initialized
INFO - 2016-05-21 10:09:35 --> Output Class Initialized
INFO - 2016-05-21 10:09:35 --> Security Class Initialized
DEBUG - 2016-05-21 10:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:09:35 --> Input Class Initialized
INFO - 2016-05-21 10:09:35 --> Language Class Initialized
INFO - 2016-05-21 10:09:35 --> Loader Class Initialized
INFO - 2016-05-21 10:09:35 --> Helper loaded: url_helper
INFO - 2016-05-21 10:09:35 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:09:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:09:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:09:35 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:09:35 --> Helper loaded: form_helper
INFO - 2016-05-21 10:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:09:35 --> Form Validation Class Initialized
INFO - 2016-05-21 10:09:35 --> Controller Class Initialized
INFO - 2016-05-21 10:09:35 --> Model Class Initialized
INFO - 2016-05-21 10:09:35 --> Database Driver Class Initialized
INFO - 2016-05-21 10:09:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:09:35 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:09:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:09:35 --> Final output sent to browser
DEBUG - 2016-05-21 10:09:35 --> Total execution time: 0.0700
INFO - 2016-05-21 10:10:28 --> Config Class Initialized
INFO - 2016-05-21 10:10:28 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:10:28 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:10:28 --> Utf8 Class Initialized
INFO - 2016-05-21 10:10:28 --> URI Class Initialized
INFO - 2016-05-21 10:10:28 --> Router Class Initialized
INFO - 2016-05-21 10:10:28 --> Output Class Initialized
INFO - 2016-05-21 10:10:28 --> Security Class Initialized
DEBUG - 2016-05-21 10:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:10:28 --> Input Class Initialized
INFO - 2016-05-21 10:10:28 --> Language Class Initialized
INFO - 2016-05-21 10:10:28 --> Loader Class Initialized
INFO - 2016-05-21 10:10:28 --> Helper loaded: url_helper
INFO - 2016-05-21 10:10:28 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:10:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:10:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:10:28 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:10:28 --> Helper loaded: form_helper
INFO - 2016-05-21 10:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:10:28 --> Form Validation Class Initialized
INFO - 2016-05-21 10:10:28 --> Controller Class Initialized
INFO - 2016-05-21 10:10:28 --> Model Class Initialized
INFO - 2016-05-21 10:10:28 --> Database Driver Class Initialized
INFO - 2016-05-21 10:10:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:10:28 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:10:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:10:28 --> Final output sent to browser
DEBUG - 2016-05-21 10:10:28 --> Total execution time: 0.0811
INFO - 2016-05-21 10:11:28 --> Config Class Initialized
INFO - 2016-05-21 10:11:28 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:11:28 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:11:28 --> Utf8 Class Initialized
INFO - 2016-05-21 10:11:28 --> URI Class Initialized
INFO - 2016-05-21 10:11:28 --> Router Class Initialized
INFO - 2016-05-21 10:11:28 --> Output Class Initialized
INFO - 2016-05-21 10:11:28 --> Security Class Initialized
DEBUG - 2016-05-21 10:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:11:28 --> Input Class Initialized
INFO - 2016-05-21 10:11:28 --> Language Class Initialized
INFO - 2016-05-21 10:11:28 --> Loader Class Initialized
INFO - 2016-05-21 10:11:28 --> Helper loaded: url_helper
INFO - 2016-05-21 10:11:28 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:11:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:11:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:11:28 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:11:28 --> Helper loaded: form_helper
INFO - 2016-05-21 10:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:11:28 --> Form Validation Class Initialized
INFO - 2016-05-21 10:11:28 --> Controller Class Initialized
INFO - 2016-05-21 10:11:28 --> Model Class Initialized
INFO - 2016-05-21 10:11:28 --> Database Driver Class Initialized
INFO - 2016-05-21 10:11:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:11:28 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:11:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:11:28 --> Final output sent to browser
DEBUG - 2016-05-21 10:11:28 --> Total execution time: 0.0790
INFO - 2016-05-21 10:12:28 --> Config Class Initialized
INFO - 2016-05-21 10:12:28 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:12:28 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:12:28 --> Utf8 Class Initialized
INFO - 2016-05-21 10:12:28 --> URI Class Initialized
INFO - 2016-05-21 10:12:28 --> Router Class Initialized
INFO - 2016-05-21 10:12:28 --> Output Class Initialized
INFO - 2016-05-21 10:12:28 --> Security Class Initialized
DEBUG - 2016-05-21 10:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:12:28 --> Input Class Initialized
INFO - 2016-05-21 10:12:28 --> Language Class Initialized
INFO - 2016-05-21 10:12:28 --> Loader Class Initialized
INFO - 2016-05-21 10:12:28 --> Helper loaded: url_helper
INFO - 2016-05-21 10:12:28 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:12:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:12:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:12:28 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:12:28 --> Helper loaded: form_helper
INFO - 2016-05-21 10:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:12:28 --> Form Validation Class Initialized
INFO - 2016-05-21 10:12:28 --> Controller Class Initialized
INFO - 2016-05-21 10:12:28 --> Model Class Initialized
INFO - 2016-05-21 10:12:28 --> Database Driver Class Initialized
INFO - 2016-05-21 10:12:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:12:28 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:12:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:12:28 --> Final output sent to browser
DEBUG - 2016-05-21 10:12:28 --> Total execution time: 0.0747
INFO - 2016-05-21 10:12:48 --> Config Class Initialized
INFO - 2016-05-21 10:12:48 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:12:48 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:12:48 --> Utf8 Class Initialized
INFO - 2016-05-21 10:12:48 --> URI Class Initialized
DEBUG - 2016-05-21 10:12:48 --> No URI present. Default controller set.
INFO - 2016-05-21 10:12:48 --> Router Class Initialized
INFO - 2016-05-21 10:12:48 --> Output Class Initialized
INFO - 2016-05-21 10:12:48 --> Security Class Initialized
DEBUG - 2016-05-21 10:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:12:48 --> Input Class Initialized
INFO - 2016-05-21 10:12:48 --> Language Class Initialized
INFO - 2016-05-21 10:12:48 --> Loader Class Initialized
INFO - 2016-05-21 10:12:48 --> Helper loaded: url_helper
INFO - 2016-05-21 10:12:48 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:12:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:12:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:12:48 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:12:48 --> Helper loaded: form_helper
INFO - 2016-05-21 10:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:12:48 --> Form Validation Class Initialized
INFO - 2016-05-21 10:12:48 --> Controller Class Initialized
INFO - 2016-05-21 10:12:48 --> Model Class Initialized
INFO - 2016-05-21 10:12:48 --> Database Driver Class Initialized
INFO - 2016-05-21 10:12:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:12:48 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:12:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:12:48 --> Config Class Initialized
INFO - 2016-05-21 10:12:48 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:12:48 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:12:48 --> Utf8 Class Initialized
INFO - 2016-05-21 10:12:48 --> URI Class Initialized
INFO - 2016-05-21 10:12:48 --> Router Class Initialized
INFO - 2016-05-21 10:12:48 --> Output Class Initialized
INFO - 2016-05-21 10:12:48 --> Security Class Initialized
DEBUG - 2016-05-21 10:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:12:48 --> Input Class Initialized
INFO - 2016-05-21 10:12:48 --> Language Class Initialized
INFO - 2016-05-21 10:12:48 --> Loader Class Initialized
INFO - 2016-05-21 10:12:48 --> Helper loaded: url_helper
INFO - 2016-05-21 10:12:48 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:12:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:12:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:12:48 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:12:48 --> Helper loaded: form_helper
INFO - 2016-05-21 10:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:12:48 --> Form Validation Class Initialized
INFO - 2016-05-21 10:12:48 --> Controller Class Initialized
INFO - 2016-05-21 10:12:48 --> Model Class Initialized
INFO - 2016-05-21 10:12:48 --> Database Driver Class Initialized
INFO - 2016-05-21 10:12:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-21 10:12:48 --> Final output sent to browser
DEBUG - 2016-05-21 10:12:48 --> Total execution time: 0.1353
INFO - 2016-05-21 10:12:52 --> Config Class Initialized
INFO - 2016-05-21 10:12:52 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:12:52 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:12:52 --> Utf8 Class Initialized
INFO - 2016-05-21 10:12:52 --> URI Class Initialized
INFO - 2016-05-21 10:12:52 --> Router Class Initialized
INFO - 2016-05-21 10:12:52 --> Output Class Initialized
INFO - 2016-05-21 10:12:52 --> Security Class Initialized
DEBUG - 2016-05-21 10:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:12:52 --> Input Class Initialized
INFO - 2016-05-21 10:12:52 --> Language Class Initialized
INFO - 2016-05-21 10:12:52 --> Loader Class Initialized
INFO - 2016-05-21 10:12:52 --> Helper loaded: url_helper
INFO - 2016-05-21 10:12:52 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:12:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:12:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:12:52 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:12:52 --> Helper loaded: form_helper
INFO - 2016-05-21 10:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:12:52 --> Form Validation Class Initialized
INFO - 2016-05-21 10:12:52 --> Controller Class Initialized
INFO - 2016-05-21 10:12:52 --> Model Class Initialized
INFO - 2016-05-21 10:12:52 --> Database Driver Class Initialized
INFO - 2016-05-21 10:12:52 --> Config Class Initialized
INFO - 2016-05-21 10:12:52 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:12:52 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:12:52 --> Utf8 Class Initialized
INFO - 2016-05-21 10:12:52 --> URI Class Initialized
DEBUG - 2016-05-21 10:12:52 --> No URI present. Default controller set.
INFO - 2016-05-21 10:12:52 --> Router Class Initialized
INFO - 2016-05-21 10:12:52 --> Output Class Initialized
INFO - 2016-05-21 10:12:52 --> Security Class Initialized
DEBUG - 2016-05-21 10:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:12:52 --> Input Class Initialized
INFO - 2016-05-21 10:12:52 --> Language Class Initialized
INFO - 2016-05-21 10:12:52 --> Loader Class Initialized
INFO - 2016-05-21 10:12:52 --> Helper loaded: url_helper
INFO - 2016-05-21 10:12:52 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:12:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:12:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:12:52 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:12:52 --> Helper loaded: form_helper
INFO - 2016-05-21 10:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:12:52 --> Form Validation Class Initialized
INFO - 2016-05-21 10:12:52 --> Controller Class Initialized
INFO - 2016-05-21 10:12:52 --> Model Class Initialized
INFO - 2016-05-21 10:12:52 --> Database Driver Class Initialized
INFO - 2016-05-21 10:12:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:12:52 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:12:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:12:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-21 10:12:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:12:52 --> Final output sent to browser
DEBUG - 2016-05-21 10:12:52 --> Total execution time: 0.0812
INFO - 2016-05-21 10:12:57 --> Config Class Initialized
INFO - 2016-05-21 10:12:57 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:12:57 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:12:57 --> Utf8 Class Initialized
INFO - 2016-05-21 10:12:57 --> URI Class Initialized
INFO - 2016-05-21 10:12:57 --> Router Class Initialized
INFO - 2016-05-21 10:12:57 --> Output Class Initialized
INFO - 2016-05-21 10:12:57 --> Security Class Initialized
DEBUG - 2016-05-21 10:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:12:57 --> Input Class Initialized
INFO - 2016-05-21 10:12:57 --> Language Class Initialized
INFO - 2016-05-21 10:12:57 --> Loader Class Initialized
INFO - 2016-05-21 10:12:57 --> Helper loaded: url_helper
INFO - 2016-05-21 10:12:57 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:12:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:12:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:12:57 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:12:57 --> Helper loaded: form_helper
INFO - 2016-05-21 10:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:12:57 --> Form Validation Class Initialized
INFO - 2016-05-21 10:12:57 --> Controller Class Initialized
INFO - 2016-05-21 10:12:57 --> Model Class Initialized
INFO - 2016-05-21 10:12:57 --> Database Driver Class Initialized
ERROR - 2016-05-21 10:12:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 43
ERROR - 2016-05-21 10:12:57 --> Severity: Notice --> Undefined variable: cantidad C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 51
INFO - 2016-05-21 10:12:57 --> Config Class Initialized
INFO - 2016-05-21 10:12:57 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:12:57 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:12:57 --> Utf8 Class Initialized
INFO - 2016-05-21 10:12:57 --> URI Class Initialized
INFO - 2016-05-21 10:12:57 --> Router Class Initialized
INFO - 2016-05-21 10:12:57 --> Output Class Initialized
INFO - 2016-05-21 10:12:57 --> Security Class Initialized
DEBUG - 2016-05-21 10:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:12:57 --> Input Class Initialized
INFO - 2016-05-21 10:12:57 --> Language Class Initialized
INFO - 2016-05-21 10:12:57 --> Loader Class Initialized
INFO - 2016-05-21 10:12:57 --> Helper loaded: url_helper
INFO - 2016-05-21 10:12:57 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:12:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:12:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:12:57 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:12:57 --> Helper loaded: form_helper
INFO - 2016-05-21 10:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:12:57 --> Form Validation Class Initialized
INFO - 2016-05-21 10:12:57 --> Controller Class Initialized
INFO - 2016-05-21 10:12:57 --> Model Class Initialized
INFO - 2016-05-21 10:12:57 --> Database Driver Class Initialized
INFO - 2016-05-21 10:12:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_carrito.php
INFO - 2016-05-21 10:12:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:12:57 --> Final output sent to browser
DEBUG - 2016-05-21 10:12:57 --> Total execution time: 0.0806
INFO - 2016-05-21 10:12:58 --> Config Class Initialized
INFO - 2016-05-21 10:12:58 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:12:58 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:12:58 --> Utf8 Class Initialized
INFO - 2016-05-21 10:12:58 --> URI Class Initialized
INFO - 2016-05-21 10:12:58 --> Router Class Initialized
INFO - 2016-05-21 10:12:58 --> Output Class Initialized
INFO - 2016-05-21 10:12:58 --> Security Class Initialized
DEBUG - 2016-05-21 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:12:58 --> Input Class Initialized
INFO - 2016-05-21 10:12:58 --> Language Class Initialized
INFO - 2016-05-21 10:12:59 --> Loader Class Initialized
INFO - 2016-05-21 10:12:59 --> Helper loaded: url_helper
INFO - 2016-05-21 10:12:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:12:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:12:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:12:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:12:59 --> Helper loaded: form_helper
INFO - 2016-05-21 10:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:12:59 --> Form Validation Class Initialized
INFO - 2016-05-21 10:12:59 --> Controller Class Initialized
INFO - 2016-05-21 10:12:59 --> Model Class Initialized
INFO - 2016-05-21 10:12:59 --> Database Driver Class Initialized
INFO - 2016-05-21 10:12:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_venta1.php
INFO - 2016-05-21 10:12:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:12:59 --> Final output sent to browser
DEBUG - 2016-05-21 10:12:59 --> Total execution time: 0.1266
INFO - 2016-05-21 10:13:07 --> Config Class Initialized
INFO - 2016-05-21 10:13:07 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:13:07 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:13:07 --> Utf8 Class Initialized
INFO - 2016-05-21 10:13:07 --> URI Class Initialized
INFO - 2016-05-21 10:13:07 --> Router Class Initialized
INFO - 2016-05-21 10:13:07 --> Output Class Initialized
INFO - 2016-05-21 10:13:07 --> Security Class Initialized
DEBUG - 2016-05-21 10:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:13:07 --> Input Class Initialized
INFO - 2016-05-21 10:13:07 --> Language Class Initialized
INFO - 2016-05-21 10:13:07 --> Loader Class Initialized
INFO - 2016-05-21 10:13:07 --> Helper loaded: url_helper
INFO - 2016-05-21 10:13:07 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:13:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:13:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:13:07 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:13:07 --> Helper loaded: form_helper
INFO - 2016-05-21 10:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:13:07 --> Form Validation Class Initialized
INFO - 2016-05-21 10:13:07 --> Controller Class Initialized
INFO - 2016-05-21 10:13:07 --> Model Class Initialized
INFO - 2016-05-21 10:13:07 --> Database Driver Class Initialized
INFO - 2016-05-21 10:13:07 --> Config Class Initialized
INFO - 2016-05-21 10:13:07 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:13:07 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:13:07 --> Utf8 Class Initialized
INFO - 2016-05-21 10:13:07 --> URI Class Initialized
INFO - 2016-05-21 10:13:07 --> Router Class Initialized
INFO - 2016-05-21 10:13:07 --> Output Class Initialized
INFO - 2016-05-21 10:13:07 --> Security Class Initialized
DEBUG - 2016-05-21 10:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:13:07 --> Input Class Initialized
INFO - 2016-05-21 10:13:07 --> Language Class Initialized
INFO - 2016-05-21 10:13:07 --> Loader Class Initialized
INFO - 2016-05-21 10:13:07 --> Helper loaded: url_helper
INFO - 2016-05-21 10:13:07 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:13:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:13:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:13:07 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:13:07 --> Helper loaded: form_helper
INFO - 2016-05-21 10:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:13:07 --> Form Validation Class Initialized
INFO - 2016-05-21 10:13:07 --> Controller Class Initialized
INFO - 2016-05-21 10:13:07 --> Model Class Initialized
INFO - 2016-05-21 10:13:07 --> Database Driver Class Initialized
INFO - 2016-05-21 10:13:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_resumenventa.php
INFO - 2016-05-21 10:13:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:13:07 --> Final output sent to browser
DEBUG - 2016-05-21 10:13:07 --> Total execution time: 0.1306
INFO - 2016-05-21 10:13:09 --> Config Class Initialized
INFO - 2016-05-21 10:13:09 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:13:09 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:13:09 --> Utf8 Class Initialized
INFO - 2016-05-21 10:13:09 --> URI Class Initialized
INFO - 2016-05-21 10:13:09 --> Router Class Initialized
INFO - 2016-05-21 10:13:09 --> Output Class Initialized
INFO - 2016-05-21 10:13:09 --> Security Class Initialized
DEBUG - 2016-05-21 10:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:13:09 --> Input Class Initialized
INFO - 2016-05-21 10:13:09 --> Language Class Initialized
INFO - 2016-05-21 10:13:09 --> Loader Class Initialized
INFO - 2016-05-21 10:13:09 --> Helper loaded: url_helper
INFO - 2016-05-21 10:13:09 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:13:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:13:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:13:09 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:13:09 --> Helper loaded: form_helper
INFO - 2016-05-21 10:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:13:09 --> Form Validation Class Initialized
INFO - 2016-05-21 10:13:09 --> Controller Class Initialized
INFO - 2016-05-21 10:13:09 --> Model Class Initialized
INFO - 2016-05-21 10:13:09 --> Database Driver Class Initialized
INFO - 2016-05-21 10:13:09 --> Config Class Initialized
INFO - 2016-05-21 10:13:09 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:13:09 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:13:09 --> Utf8 Class Initialized
INFO - 2016-05-21 10:13:09 --> URI Class Initialized
INFO - 2016-05-21 10:13:09 --> Router Class Initialized
INFO - 2016-05-21 10:13:09 --> Output Class Initialized
INFO - 2016-05-21 10:13:09 --> Security Class Initialized
DEBUG - 2016-05-21 10:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:13:09 --> Input Class Initialized
INFO - 2016-05-21 10:13:09 --> Language Class Initialized
INFO - 2016-05-21 10:13:09 --> Loader Class Initialized
INFO - 2016-05-21 10:13:09 --> Helper loaded: url_helper
INFO - 2016-05-21 10:13:09 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:13:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:13:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:13:09 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:13:09 --> Helper loaded: form_helper
INFO - 2016-05-21 10:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:13:09 --> Form Validation Class Initialized
INFO - 2016-05-21 10:13:09 --> Controller Class Initialized
INFO - 2016-05-21 10:13:09 --> Model Class Initialized
INFO - 2016-05-21 10:13:09 --> Database Driver Class Initialized
INFO - 2016-05-21 10:13:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-21 10:13:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:13:09 --> Final output sent to browser
DEBUG - 2016-05-21 10:13:09 --> Total execution time: 0.0923
INFO - 2016-05-21 10:13:15 --> Config Class Initialized
INFO - 2016-05-21 10:13:15 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:13:15 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:13:15 --> Utf8 Class Initialized
INFO - 2016-05-21 10:13:15 --> URI Class Initialized
INFO - 2016-05-21 10:13:15 --> Router Class Initialized
INFO - 2016-05-21 10:13:15 --> Output Class Initialized
INFO - 2016-05-21 10:13:15 --> Security Class Initialized
DEBUG - 2016-05-21 10:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:13:15 --> Input Class Initialized
INFO - 2016-05-21 10:13:15 --> Language Class Initialized
INFO - 2016-05-21 10:13:15 --> Loader Class Initialized
INFO - 2016-05-21 10:13:15 --> Helper loaded: url_helper
INFO - 2016-05-21 10:13:15 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:13:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:13:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:13:15 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:13:15 --> Helper loaded: form_helper
INFO - 2016-05-21 10:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:13:15 --> Form Validation Class Initialized
INFO - 2016-05-21 10:13:15 --> Controller Class Initialized
INFO - 2016-05-21 10:13:15 --> Model Class Initialized
INFO - 2016-05-21 10:13:15 --> Database Driver Class Initialized
INFO - 2016-05-21 10:13:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:13:15 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:13:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:13:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:13:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:13:15 --> Final output sent to browser
DEBUG - 2016-05-21 10:13:15 --> Total execution time: 0.1131
INFO - 2016-05-21 10:13:15 --> Config Class Initialized
INFO - 2016-05-21 10:13:15 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:13:15 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:13:15 --> Utf8 Class Initialized
INFO - 2016-05-21 10:13:15 --> URI Class Initialized
INFO - 2016-05-21 10:13:15 --> Router Class Initialized
INFO - 2016-05-21 10:13:15 --> Output Class Initialized
INFO - 2016-05-21 10:13:15 --> Security Class Initialized
DEBUG - 2016-05-21 10:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:13:15 --> Input Class Initialized
INFO - 2016-05-21 10:13:15 --> Language Class Initialized
INFO - 2016-05-21 10:13:15 --> Loader Class Initialized
INFO - 2016-05-21 10:13:15 --> Helper loaded: url_helper
INFO - 2016-05-21 10:13:15 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:13:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:13:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:13:15 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:13:15 --> Helper loaded: form_helper
INFO - 2016-05-21 10:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:13:15 --> Form Validation Class Initialized
INFO - 2016-05-21 10:13:15 --> Controller Class Initialized
INFO - 2016-05-21 10:13:15 --> Model Class Initialized
INFO - 2016-05-21 10:13:15 --> Database Driver Class Initialized
INFO - 2016-05-21 10:13:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:13:15 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:13:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:13:15 --> Final output sent to browser
DEBUG - 2016-05-21 10:13:15 --> Total execution time: 0.0906
INFO - 2016-05-21 10:13:32 --> Config Class Initialized
INFO - 2016-05-21 10:13:32 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:13:32 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:13:32 --> Utf8 Class Initialized
INFO - 2016-05-21 10:13:32 --> URI Class Initialized
INFO - 2016-05-21 10:13:32 --> Router Class Initialized
INFO - 2016-05-21 10:13:32 --> Output Class Initialized
INFO - 2016-05-21 10:13:32 --> Security Class Initialized
DEBUG - 2016-05-21 10:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:13:32 --> Input Class Initialized
INFO - 2016-05-21 10:13:32 --> Language Class Initialized
INFO - 2016-05-21 10:13:32 --> Loader Class Initialized
INFO - 2016-05-21 10:13:32 --> Helper loaded: url_helper
INFO - 2016-05-21 10:13:32 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:13:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:13:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:13:32 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:13:32 --> Helper loaded: form_helper
INFO - 2016-05-21 10:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:13:32 --> Form Validation Class Initialized
INFO - 2016-05-21 10:13:32 --> Controller Class Initialized
INFO - 2016-05-21 10:13:32 --> Model Class Initialized
INFO - 2016-05-21 10:13:32 --> Database Driver Class Initialized
INFO - 2016-05-21 10:13:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:13:32 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:13:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:13:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:13:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:13:32 --> Final output sent to browser
DEBUG - 2016-05-21 10:13:32 --> Total execution time: 0.0783
INFO - 2016-05-21 10:13:32 --> Config Class Initialized
INFO - 2016-05-21 10:13:32 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:13:32 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:13:32 --> Utf8 Class Initialized
INFO - 2016-05-21 10:13:32 --> URI Class Initialized
INFO - 2016-05-21 10:13:32 --> Router Class Initialized
INFO - 2016-05-21 10:13:32 --> Output Class Initialized
INFO - 2016-05-21 10:13:32 --> Security Class Initialized
DEBUG - 2016-05-21 10:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:13:32 --> Input Class Initialized
INFO - 2016-05-21 10:13:32 --> Language Class Initialized
INFO - 2016-05-21 10:13:32 --> Loader Class Initialized
INFO - 2016-05-21 10:13:32 --> Helper loaded: url_helper
INFO - 2016-05-21 10:13:32 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:13:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:13:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:13:32 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:13:32 --> Helper loaded: form_helper
INFO - 2016-05-21 10:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:13:32 --> Form Validation Class Initialized
INFO - 2016-05-21 10:13:32 --> Controller Class Initialized
INFO - 2016-05-21 10:13:32 --> Model Class Initialized
INFO - 2016-05-21 10:13:32 --> Database Driver Class Initialized
INFO - 2016-05-21 10:13:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:13:32 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:13:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:13:32 --> Final output sent to browser
DEBUG - 2016-05-21 10:13:32 --> Total execution time: 0.0900
INFO - 2016-05-21 10:14:32 --> Config Class Initialized
INFO - 2016-05-21 10:14:32 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:14:32 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:14:32 --> Utf8 Class Initialized
INFO - 2016-05-21 10:14:32 --> URI Class Initialized
INFO - 2016-05-21 10:14:32 --> Router Class Initialized
INFO - 2016-05-21 10:14:32 --> Output Class Initialized
INFO - 2016-05-21 10:14:32 --> Security Class Initialized
DEBUG - 2016-05-21 10:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:14:32 --> Input Class Initialized
INFO - 2016-05-21 10:14:32 --> Language Class Initialized
INFO - 2016-05-21 10:14:32 --> Loader Class Initialized
INFO - 2016-05-21 10:14:32 --> Helper loaded: url_helper
INFO - 2016-05-21 10:14:32 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:14:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:14:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:14:32 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:14:32 --> Helper loaded: form_helper
INFO - 2016-05-21 10:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:14:32 --> Form Validation Class Initialized
INFO - 2016-05-21 10:14:32 --> Controller Class Initialized
INFO - 2016-05-21 10:14:32 --> Model Class Initialized
INFO - 2016-05-21 10:14:32 --> Database Driver Class Initialized
INFO - 2016-05-21 10:14:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:14:32 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:14:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:14:32 --> Final output sent to browser
DEBUG - 2016-05-21 10:14:32 --> Total execution time: 0.0724
INFO - 2016-05-21 10:15:33 --> Config Class Initialized
INFO - 2016-05-21 10:15:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:15:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:15:33 --> Utf8 Class Initialized
INFO - 2016-05-21 10:15:33 --> URI Class Initialized
INFO - 2016-05-21 10:15:33 --> Router Class Initialized
INFO - 2016-05-21 10:15:33 --> Output Class Initialized
INFO - 2016-05-21 10:15:33 --> Security Class Initialized
DEBUG - 2016-05-21 10:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:15:33 --> Input Class Initialized
INFO - 2016-05-21 10:15:33 --> Language Class Initialized
INFO - 2016-05-21 10:15:33 --> Loader Class Initialized
INFO - 2016-05-21 10:15:33 --> Helper loaded: url_helper
INFO - 2016-05-21 10:15:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:15:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:15:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:15:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:15:33 --> Helper loaded: form_helper
INFO - 2016-05-21 10:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:15:33 --> Form Validation Class Initialized
INFO - 2016-05-21 10:15:33 --> Controller Class Initialized
INFO - 2016-05-21 10:15:33 --> Model Class Initialized
INFO - 2016-05-21 10:15:33 --> Database Driver Class Initialized
INFO - 2016-05-21 10:15:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:15:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:15:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:15:33 --> Final output sent to browser
DEBUG - 2016-05-21 10:15:33 --> Total execution time: 0.0803
INFO - 2016-05-21 10:16:33 --> Config Class Initialized
INFO - 2016-05-21 10:16:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:16:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:16:33 --> Utf8 Class Initialized
INFO - 2016-05-21 10:16:33 --> URI Class Initialized
INFO - 2016-05-21 10:16:33 --> Router Class Initialized
INFO - 2016-05-21 10:16:33 --> Output Class Initialized
INFO - 2016-05-21 10:16:33 --> Security Class Initialized
DEBUG - 2016-05-21 10:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:16:33 --> Input Class Initialized
INFO - 2016-05-21 10:16:33 --> Language Class Initialized
INFO - 2016-05-21 10:16:33 --> Loader Class Initialized
INFO - 2016-05-21 10:16:33 --> Helper loaded: url_helper
INFO - 2016-05-21 10:16:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:16:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:16:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:16:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:16:33 --> Helper loaded: form_helper
INFO - 2016-05-21 10:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:16:33 --> Form Validation Class Initialized
INFO - 2016-05-21 10:16:33 --> Controller Class Initialized
INFO - 2016-05-21 10:16:33 --> Model Class Initialized
INFO - 2016-05-21 10:16:33 --> Database Driver Class Initialized
INFO - 2016-05-21 10:16:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:16:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:16:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:16:33 --> Final output sent to browser
DEBUG - 2016-05-21 10:16:33 --> Total execution time: 0.0821
INFO - 2016-05-21 10:17:06 --> Config Class Initialized
INFO - 2016-05-21 10:17:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:17:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:17:06 --> Utf8 Class Initialized
INFO - 2016-05-21 10:17:06 --> URI Class Initialized
DEBUG - 2016-05-21 10:17:06 --> No URI present. Default controller set.
INFO - 2016-05-21 10:17:06 --> Router Class Initialized
INFO - 2016-05-21 10:17:06 --> Output Class Initialized
INFO - 2016-05-21 10:17:06 --> Security Class Initialized
DEBUG - 2016-05-21 10:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:17:06 --> Input Class Initialized
INFO - 2016-05-21 10:17:06 --> Language Class Initialized
INFO - 2016-05-21 10:17:06 --> Loader Class Initialized
INFO - 2016-05-21 10:17:06 --> Helper loaded: url_helper
INFO - 2016-05-21 10:17:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:17:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:17:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:17:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:17:06 --> Helper loaded: form_helper
INFO - 2016-05-21 10:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:17:07 --> Form Validation Class Initialized
INFO - 2016-05-21 10:17:07 --> Controller Class Initialized
INFO - 2016-05-21 10:17:07 --> Model Class Initialized
INFO - 2016-05-21 10:17:07 --> Database Driver Class Initialized
INFO - 2016-05-21 10:17:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:17:07 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:17:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:17:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-21 10:17:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:17:07 --> Final output sent to browser
DEBUG - 2016-05-21 10:17:07 --> Total execution time: 0.0960
INFO - 2016-05-21 10:17:09 --> Config Class Initialized
INFO - 2016-05-21 10:17:09 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:17:09 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:17:09 --> Utf8 Class Initialized
INFO - 2016-05-21 10:17:09 --> URI Class Initialized
INFO - 2016-05-21 10:17:09 --> Router Class Initialized
INFO - 2016-05-21 10:17:09 --> Output Class Initialized
INFO - 2016-05-21 10:17:09 --> Security Class Initialized
DEBUG - 2016-05-21 10:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:17:09 --> Input Class Initialized
INFO - 2016-05-21 10:17:09 --> Language Class Initialized
INFO - 2016-05-21 10:17:09 --> Loader Class Initialized
INFO - 2016-05-21 10:17:09 --> Helper loaded: url_helper
INFO - 2016-05-21 10:17:09 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:17:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:17:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:17:09 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:17:09 --> Helper loaded: form_helper
INFO - 2016-05-21 10:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:17:09 --> Form Validation Class Initialized
INFO - 2016-05-21 10:17:09 --> Controller Class Initialized
INFO - 2016-05-21 10:17:09 --> Model Class Initialized
INFO - 2016-05-21 10:17:09 --> Database Driver Class Initialized
ERROR - 2016-05-21 10:17:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 43
ERROR - 2016-05-21 10:17:09 --> Severity: Notice --> Undefined variable: cantidad C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 51
INFO - 2016-05-21 10:17:09 --> Config Class Initialized
INFO - 2016-05-21 10:17:09 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:17:09 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:17:09 --> Utf8 Class Initialized
INFO - 2016-05-21 10:17:09 --> URI Class Initialized
INFO - 2016-05-21 10:17:09 --> Router Class Initialized
INFO - 2016-05-21 10:17:09 --> Output Class Initialized
INFO - 2016-05-21 10:17:09 --> Security Class Initialized
DEBUG - 2016-05-21 10:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:17:09 --> Input Class Initialized
INFO - 2016-05-21 10:17:09 --> Language Class Initialized
INFO - 2016-05-21 10:17:09 --> Loader Class Initialized
INFO - 2016-05-21 10:17:09 --> Helper loaded: url_helper
INFO - 2016-05-21 10:17:09 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:17:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:17:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:17:09 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:17:09 --> Helper loaded: form_helper
INFO - 2016-05-21 10:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:17:09 --> Form Validation Class Initialized
INFO - 2016-05-21 10:17:09 --> Controller Class Initialized
INFO - 2016-05-21 10:17:09 --> Model Class Initialized
INFO - 2016-05-21 10:17:09 --> Database Driver Class Initialized
INFO - 2016-05-21 10:17:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_carrito.php
INFO - 2016-05-21 10:17:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:17:09 --> Final output sent to browser
DEBUG - 2016-05-21 10:17:09 --> Total execution time: 0.0850
INFO - 2016-05-21 10:17:12 --> Config Class Initialized
INFO - 2016-05-21 10:17:12 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:17:12 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:17:12 --> Utf8 Class Initialized
INFO - 2016-05-21 10:17:12 --> URI Class Initialized
INFO - 2016-05-21 10:17:12 --> Router Class Initialized
INFO - 2016-05-21 10:17:12 --> Output Class Initialized
INFO - 2016-05-21 10:17:12 --> Security Class Initialized
DEBUG - 2016-05-21 10:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:17:12 --> Input Class Initialized
INFO - 2016-05-21 10:17:12 --> Language Class Initialized
INFO - 2016-05-21 10:17:12 --> Loader Class Initialized
INFO - 2016-05-21 10:17:12 --> Helper loaded: url_helper
INFO - 2016-05-21 10:17:12 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:17:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:17:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:17:12 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:17:12 --> Helper loaded: form_helper
INFO - 2016-05-21 10:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:17:12 --> Form Validation Class Initialized
INFO - 2016-05-21 10:17:12 --> Controller Class Initialized
INFO - 2016-05-21 10:17:12 --> Model Class Initialized
INFO - 2016-05-21 10:17:12 --> Database Driver Class Initialized
INFO - 2016-05-21 10:17:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_venta1.php
INFO - 2016-05-21 10:17:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:17:12 --> Final output sent to browser
DEBUG - 2016-05-21 10:17:12 --> Total execution time: 0.0933
INFO - 2016-05-21 10:17:15 --> Config Class Initialized
INFO - 2016-05-21 10:17:15 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:17:15 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:17:15 --> Utf8 Class Initialized
INFO - 2016-05-21 10:17:15 --> URI Class Initialized
INFO - 2016-05-21 10:17:15 --> Router Class Initialized
INFO - 2016-05-21 10:17:15 --> Output Class Initialized
INFO - 2016-05-21 10:17:15 --> Security Class Initialized
DEBUG - 2016-05-21 10:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:17:15 --> Input Class Initialized
INFO - 2016-05-21 10:17:15 --> Language Class Initialized
INFO - 2016-05-21 10:17:15 --> Loader Class Initialized
INFO - 2016-05-21 10:17:15 --> Helper loaded: url_helper
INFO - 2016-05-21 10:17:15 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:17:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:17:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:17:15 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:17:15 --> Helper loaded: form_helper
INFO - 2016-05-21 10:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:17:15 --> Form Validation Class Initialized
INFO - 2016-05-21 10:17:15 --> Controller Class Initialized
INFO - 2016-05-21 10:17:15 --> Model Class Initialized
INFO - 2016-05-21 10:17:15 --> Database Driver Class Initialized
INFO - 2016-05-21 10:17:15 --> Config Class Initialized
INFO - 2016-05-21 10:17:15 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:17:15 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:17:15 --> Utf8 Class Initialized
INFO - 2016-05-21 10:17:15 --> URI Class Initialized
INFO - 2016-05-21 10:17:15 --> Router Class Initialized
INFO - 2016-05-21 10:17:15 --> Output Class Initialized
INFO - 2016-05-21 10:17:15 --> Security Class Initialized
DEBUG - 2016-05-21 10:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:17:15 --> Input Class Initialized
INFO - 2016-05-21 10:17:15 --> Language Class Initialized
INFO - 2016-05-21 10:17:15 --> Loader Class Initialized
INFO - 2016-05-21 10:17:15 --> Helper loaded: url_helper
INFO - 2016-05-21 10:17:15 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:17:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:17:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:17:15 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:17:15 --> Helper loaded: form_helper
INFO - 2016-05-21 10:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:17:15 --> Form Validation Class Initialized
INFO - 2016-05-21 10:17:15 --> Controller Class Initialized
INFO - 2016-05-21 10:17:15 --> Model Class Initialized
INFO - 2016-05-21 10:17:15 --> Database Driver Class Initialized
INFO - 2016-05-21 10:17:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_resumenventa.php
INFO - 2016-05-21 10:17:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:17:15 --> Final output sent to browser
DEBUG - 2016-05-21 10:17:15 --> Total execution time: 0.0859
INFO - 2016-05-21 10:17:17 --> Config Class Initialized
INFO - 2016-05-21 10:17:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:17:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:17:17 --> Utf8 Class Initialized
INFO - 2016-05-21 10:17:17 --> URI Class Initialized
INFO - 2016-05-21 10:17:17 --> Router Class Initialized
INFO - 2016-05-21 10:17:17 --> Output Class Initialized
INFO - 2016-05-21 10:17:17 --> Security Class Initialized
DEBUG - 2016-05-21 10:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:17:17 --> Input Class Initialized
INFO - 2016-05-21 10:17:17 --> Language Class Initialized
INFO - 2016-05-21 10:17:17 --> Loader Class Initialized
INFO - 2016-05-21 10:17:17 --> Helper loaded: url_helper
INFO - 2016-05-21 10:17:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:17:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:17:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:17:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:17:17 --> Helper loaded: form_helper
INFO - 2016-05-21 10:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:17:17 --> Form Validation Class Initialized
INFO - 2016-05-21 10:17:17 --> Controller Class Initialized
INFO - 2016-05-21 10:17:17 --> Model Class Initialized
INFO - 2016-05-21 10:17:17 --> Database Driver Class Initialized
INFO - 2016-05-21 10:17:17 --> Config Class Initialized
INFO - 2016-05-21 10:17:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:17:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:17:17 --> Utf8 Class Initialized
INFO - 2016-05-21 10:17:17 --> URI Class Initialized
INFO - 2016-05-21 10:17:17 --> Router Class Initialized
INFO - 2016-05-21 10:17:17 --> Output Class Initialized
INFO - 2016-05-21 10:17:17 --> Security Class Initialized
DEBUG - 2016-05-21 10:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:17:17 --> Input Class Initialized
INFO - 2016-05-21 10:17:17 --> Language Class Initialized
INFO - 2016-05-21 10:17:17 --> Loader Class Initialized
INFO - 2016-05-21 10:17:17 --> Helper loaded: url_helper
INFO - 2016-05-21 10:17:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:17:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:17:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:17:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:17:17 --> Helper loaded: form_helper
INFO - 2016-05-21 10:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:17:17 --> Form Validation Class Initialized
INFO - 2016-05-21 10:17:17 --> Controller Class Initialized
INFO - 2016-05-21 10:17:17 --> Model Class Initialized
INFO - 2016-05-21 10:17:17 --> Database Driver Class Initialized
INFO - 2016-05-21 10:17:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-21 10:17:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:17:17 --> Final output sent to browser
DEBUG - 2016-05-21 10:17:17 --> Total execution time: 0.0839
INFO - 2016-05-21 10:17:21 --> Config Class Initialized
INFO - 2016-05-21 10:17:21 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:17:21 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:17:21 --> Utf8 Class Initialized
INFO - 2016-05-21 10:17:21 --> URI Class Initialized
INFO - 2016-05-21 10:17:21 --> Router Class Initialized
INFO - 2016-05-21 10:17:21 --> Output Class Initialized
INFO - 2016-05-21 10:17:21 --> Security Class Initialized
DEBUG - 2016-05-21 10:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:17:21 --> Input Class Initialized
INFO - 2016-05-21 10:17:21 --> Language Class Initialized
INFO - 2016-05-21 10:17:21 --> Loader Class Initialized
INFO - 2016-05-21 10:17:21 --> Helper loaded: url_helper
INFO - 2016-05-21 10:17:21 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:17:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:17:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:17:21 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:17:21 --> Helper loaded: form_helper
INFO - 2016-05-21 10:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:17:21 --> Form Validation Class Initialized
INFO - 2016-05-21 10:17:21 --> Controller Class Initialized
INFO - 2016-05-21 10:17:21 --> Model Class Initialized
INFO - 2016-05-21 10:17:21 --> Database Driver Class Initialized
INFO - 2016-05-21 10:17:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:17:21 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:17:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:17:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:17:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:17:21 --> Final output sent to browser
DEBUG - 2016-05-21 10:17:21 --> Total execution time: 0.0865
INFO - 2016-05-21 10:17:21 --> Config Class Initialized
INFO - 2016-05-21 10:17:21 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:17:21 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:17:21 --> Utf8 Class Initialized
INFO - 2016-05-21 10:17:21 --> URI Class Initialized
INFO - 2016-05-21 10:17:21 --> Router Class Initialized
INFO - 2016-05-21 10:17:21 --> Output Class Initialized
INFO - 2016-05-21 10:17:21 --> Security Class Initialized
DEBUG - 2016-05-21 10:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:17:21 --> Input Class Initialized
INFO - 2016-05-21 10:17:21 --> Language Class Initialized
INFO - 2016-05-21 10:17:21 --> Loader Class Initialized
INFO - 2016-05-21 10:17:21 --> Helper loaded: url_helper
INFO - 2016-05-21 10:17:21 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:17:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:17:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:17:21 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:17:21 --> Helper loaded: form_helper
INFO - 2016-05-21 10:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:17:21 --> Form Validation Class Initialized
INFO - 2016-05-21 10:17:21 --> Controller Class Initialized
INFO - 2016-05-21 10:17:21 --> Model Class Initialized
INFO - 2016-05-21 10:17:21 --> Database Driver Class Initialized
INFO - 2016-05-21 10:17:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:17:21 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:17:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:17:21 --> Final output sent to browser
DEBUG - 2016-05-21 10:17:21 --> Total execution time: 0.0895
INFO - 2016-05-21 10:18:22 --> Config Class Initialized
INFO - 2016-05-21 10:18:22 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:18:22 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:18:22 --> Utf8 Class Initialized
INFO - 2016-05-21 10:18:22 --> URI Class Initialized
INFO - 2016-05-21 10:18:22 --> Router Class Initialized
INFO - 2016-05-21 10:18:22 --> Output Class Initialized
INFO - 2016-05-21 10:18:22 --> Security Class Initialized
DEBUG - 2016-05-21 10:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:18:22 --> Input Class Initialized
INFO - 2016-05-21 10:18:22 --> Language Class Initialized
INFO - 2016-05-21 10:18:22 --> Loader Class Initialized
INFO - 2016-05-21 10:18:22 --> Helper loaded: url_helper
INFO - 2016-05-21 10:18:22 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:18:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:18:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:18:22 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:18:22 --> Helper loaded: form_helper
INFO - 2016-05-21 10:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:18:22 --> Form Validation Class Initialized
INFO - 2016-05-21 10:18:22 --> Controller Class Initialized
INFO - 2016-05-21 10:18:22 --> Model Class Initialized
INFO - 2016-05-21 10:18:22 --> Database Driver Class Initialized
INFO - 2016-05-21 10:18:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:18:22 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:18:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:18:22 --> Final output sent to browser
DEBUG - 2016-05-21 10:18:22 --> Total execution time: 0.0820
INFO - 2016-05-21 10:18:31 --> Config Class Initialized
INFO - 2016-05-21 10:18:31 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:18:31 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:18:31 --> Utf8 Class Initialized
INFO - 2016-05-21 10:18:31 --> URI Class Initialized
DEBUG - 2016-05-21 10:18:31 --> No URI present. Default controller set.
INFO - 2016-05-21 10:18:31 --> Router Class Initialized
INFO - 2016-05-21 10:18:31 --> Output Class Initialized
INFO - 2016-05-21 10:18:31 --> Security Class Initialized
DEBUG - 2016-05-21 10:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:18:31 --> Input Class Initialized
INFO - 2016-05-21 10:18:31 --> Language Class Initialized
INFO - 2016-05-21 10:18:31 --> Loader Class Initialized
INFO - 2016-05-21 10:18:31 --> Helper loaded: url_helper
INFO - 2016-05-21 10:18:31 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:18:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:18:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:18:31 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:18:31 --> Helper loaded: form_helper
INFO - 2016-05-21 10:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:18:31 --> Form Validation Class Initialized
INFO - 2016-05-21 10:18:31 --> Controller Class Initialized
INFO - 2016-05-21 10:18:31 --> Model Class Initialized
INFO - 2016-05-21 10:18:31 --> Database Driver Class Initialized
INFO - 2016-05-21 10:18:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:18:31 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:18:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:18:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-21 10:18:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:18:31 --> Final output sent to browser
DEBUG - 2016-05-21 10:18:31 --> Total execution time: 0.1057
INFO - 2016-05-21 10:18:34 --> Config Class Initialized
INFO - 2016-05-21 10:18:34 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:18:34 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:18:34 --> Utf8 Class Initialized
INFO - 2016-05-21 10:18:34 --> URI Class Initialized
INFO - 2016-05-21 10:18:34 --> Router Class Initialized
INFO - 2016-05-21 10:18:34 --> Output Class Initialized
INFO - 2016-05-21 10:18:34 --> Security Class Initialized
DEBUG - 2016-05-21 10:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:18:34 --> Input Class Initialized
INFO - 2016-05-21 10:18:34 --> Language Class Initialized
INFO - 2016-05-21 10:18:34 --> Loader Class Initialized
INFO - 2016-05-21 10:18:34 --> Helper loaded: url_helper
INFO - 2016-05-21 10:18:34 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:18:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:18:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:18:34 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:18:34 --> Helper loaded: form_helper
INFO - 2016-05-21 10:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:18:34 --> Form Validation Class Initialized
INFO - 2016-05-21 10:18:34 --> Controller Class Initialized
INFO - 2016-05-21 10:18:34 --> Model Class Initialized
INFO - 2016-05-21 10:18:34 --> Database Driver Class Initialized
ERROR - 2016-05-21 10:18:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 43
ERROR - 2016-05-21 10:18:34 --> Severity: Notice --> Undefined variable: cantidad C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 51
INFO - 2016-05-21 10:18:34 --> Config Class Initialized
INFO - 2016-05-21 10:18:34 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:18:34 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:18:34 --> Utf8 Class Initialized
INFO - 2016-05-21 10:18:34 --> URI Class Initialized
INFO - 2016-05-21 10:18:34 --> Router Class Initialized
INFO - 2016-05-21 10:18:34 --> Output Class Initialized
INFO - 2016-05-21 10:18:34 --> Security Class Initialized
DEBUG - 2016-05-21 10:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:18:34 --> Input Class Initialized
INFO - 2016-05-21 10:18:34 --> Language Class Initialized
INFO - 2016-05-21 10:18:34 --> Loader Class Initialized
INFO - 2016-05-21 10:18:34 --> Helper loaded: url_helper
INFO - 2016-05-21 10:18:34 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:18:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:18:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:18:34 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:18:34 --> Helper loaded: form_helper
INFO - 2016-05-21 10:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:18:34 --> Form Validation Class Initialized
INFO - 2016-05-21 10:18:34 --> Controller Class Initialized
INFO - 2016-05-21 10:18:34 --> Model Class Initialized
INFO - 2016-05-21 10:18:34 --> Database Driver Class Initialized
INFO - 2016-05-21 10:18:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_carrito.php
INFO - 2016-05-21 10:18:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:18:34 --> Final output sent to browser
DEBUG - 2016-05-21 10:18:34 --> Total execution time: 0.0938
INFO - 2016-05-21 10:18:36 --> Config Class Initialized
INFO - 2016-05-21 10:18:36 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:18:36 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:18:36 --> Utf8 Class Initialized
INFO - 2016-05-21 10:18:36 --> URI Class Initialized
INFO - 2016-05-21 10:18:36 --> Router Class Initialized
INFO - 2016-05-21 10:18:36 --> Output Class Initialized
INFO - 2016-05-21 10:18:36 --> Security Class Initialized
DEBUG - 2016-05-21 10:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:18:36 --> Input Class Initialized
INFO - 2016-05-21 10:18:36 --> Language Class Initialized
INFO - 2016-05-21 10:18:36 --> Loader Class Initialized
INFO - 2016-05-21 10:18:36 --> Helper loaded: url_helper
INFO - 2016-05-21 10:18:36 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:18:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:18:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:18:36 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:18:36 --> Helper loaded: form_helper
INFO - 2016-05-21 10:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:18:36 --> Form Validation Class Initialized
INFO - 2016-05-21 10:18:36 --> Controller Class Initialized
INFO - 2016-05-21 10:18:36 --> Model Class Initialized
INFO - 2016-05-21 10:18:36 --> Database Driver Class Initialized
INFO - 2016-05-21 10:18:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_venta1.php
INFO - 2016-05-21 10:18:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:18:36 --> Final output sent to browser
DEBUG - 2016-05-21 10:18:36 --> Total execution time: 0.2143
INFO - 2016-05-21 10:18:39 --> Config Class Initialized
INFO - 2016-05-21 10:18:39 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:18:39 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:18:39 --> Utf8 Class Initialized
INFO - 2016-05-21 10:18:39 --> URI Class Initialized
INFO - 2016-05-21 10:18:39 --> Router Class Initialized
INFO - 2016-05-21 10:18:39 --> Output Class Initialized
INFO - 2016-05-21 10:18:39 --> Security Class Initialized
DEBUG - 2016-05-21 10:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:18:39 --> Input Class Initialized
INFO - 2016-05-21 10:18:39 --> Language Class Initialized
INFO - 2016-05-21 10:18:39 --> Loader Class Initialized
INFO - 2016-05-21 10:18:39 --> Helper loaded: url_helper
INFO - 2016-05-21 10:18:39 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:18:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:18:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:18:39 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:18:39 --> Helper loaded: form_helper
INFO - 2016-05-21 10:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:18:39 --> Form Validation Class Initialized
INFO - 2016-05-21 10:18:39 --> Controller Class Initialized
INFO - 2016-05-21 10:18:39 --> Model Class Initialized
INFO - 2016-05-21 10:18:39 --> Database Driver Class Initialized
INFO - 2016-05-21 10:18:39 --> Config Class Initialized
INFO - 2016-05-21 10:18:39 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:18:39 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:18:39 --> Utf8 Class Initialized
INFO - 2016-05-21 10:18:39 --> URI Class Initialized
INFO - 2016-05-21 10:18:39 --> Router Class Initialized
INFO - 2016-05-21 10:18:39 --> Output Class Initialized
INFO - 2016-05-21 10:18:39 --> Security Class Initialized
DEBUG - 2016-05-21 10:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:18:39 --> Input Class Initialized
INFO - 2016-05-21 10:18:39 --> Language Class Initialized
INFO - 2016-05-21 10:18:39 --> Loader Class Initialized
INFO - 2016-05-21 10:18:39 --> Helper loaded: url_helper
INFO - 2016-05-21 10:18:39 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:18:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:18:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:18:39 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:18:39 --> Helper loaded: form_helper
INFO - 2016-05-21 10:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:18:39 --> Form Validation Class Initialized
INFO - 2016-05-21 10:18:39 --> Controller Class Initialized
INFO - 2016-05-21 10:18:39 --> Model Class Initialized
INFO - 2016-05-21 10:18:39 --> Database Driver Class Initialized
INFO - 2016-05-21 10:18:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_resumenventa.php
INFO - 2016-05-21 10:18:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:18:39 --> Final output sent to browser
DEBUG - 2016-05-21 10:18:39 --> Total execution time: 0.0806
INFO - 2016-05-21 10:18:41 --> Config Class Initialized
INFO - 2016-05-21 10:18:41 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:18:41 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:18:41 --> Utf8 Class Initialized
INFO - 2016-05-21 10:18:41 --> URI Class Initialized
INFO - 2016-05-21 10:18:41 --> Router Class Initialized
INFO - 2016-05-21 10:18:41 --> Output Class Initialized
INFO - 2016-05-21 10:18:41 --> Security Class Initialized
DEBUG - 2016-05-21 10:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:18:41 --> Input Class Initialized
INFO - 2016-05-21 10:18:41 --> Language Class Initialized
INFO - 2016-05-21 10:18:41 --> Loader Class Initialized
INFO - 2016-05-21 10:18:41 --> Helper loaded: url_helper
INFO - 2016-05-21 10:18:41 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:18:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:18:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:18:41 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:18:41 --> Helper loaded: form_helper
INFO - 2016-05-21 10:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:18:41 --> Form Validation Class Initialized
INFO - 2016-05-21 10:18:41 --> Controller Class Initialized
INFO - 2016-05-21 10:18:41 --> Model Class Initialized
INFO - 2016-05-21 10:18:41 --> Database Driver Class Initialized
INFO - 2016-05-21 10:18:42 --> Config Class Initialized
INFO - 2016-05-21 10:18:42 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:18:42 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:18:42 --> Utf8 Class Initialized
INFO - 2016-05-21 10:18:42 --> URI Class Initialized
INFO - 2016-05-21 10:18:42 --> Router Class Initialized
INFO - 2016-05-21 10:18:42 --> Output Class Initialized
INFO - 2016-05-21 10:18:42 --> Security Class Initialized
DEBUG - 2016-05-21 10:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:18:42 --> Input Class Initialized
INFO - 2016-05-21 10:18:42 --> Language Class Initialized
INFO - 2016-05-21 10:18:42 --> Loader Class Initialized
INFO - 2016-05-21 10:18:42 --> Helper loaded: url_helper
INFO - 2016-05-21 10:18:42 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:18:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:18:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:18:42 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:18:42 --> Helper loaded: form_helper
INFO - 2016-05-21 10:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:18:42 --> Form Validation Class Initialized
INFO - 2016-05-21 10:18:42 --> Controller Class Initialized
INFO - 2016-05-21 10:18:42 --> Model Class Initialized
INFO - 2016-05-21 10:18:42 --> Database Driver Class Initialized
INFO - 2016-05-21 10:18:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-21 10:18:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:18:42 --> Final output sent to browser
DEBUG - 2016-05-21 10:18:42 --> Total execution time: 0.0804
INFO - 2016-05-21 10:18:43 --> Config Class Initialized
INFO - 2016-05-21 10:18:43 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:18:43 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:18:43 --> Utf8 Class Initialized
INFO - 2016-05-21 10:18:43 --> URI Class Initialized
INFO - 2016-05-21 10:18:43 --> Router Class Initialized
INFO - 2016-05-21 10:18:43 --> Output Class Initialized
INFO - 2016-05-21 10:18:43 --> Security Class Initialized
DEBUG - 2016-05-21 10:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:18:43 --> Input Class Initialized
INFO - 2016-05-21 10:18:43 --> Language Class Initialized
INFO - 2016-05-21 10:18:43 --> Loader Class Initialized
INFO - 2016-05-21 10:18:43 --> Helper loaded: url_helper
INFO - 2016-05-21 10:18:43 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:18:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:18:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:18:43 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:18:43 --> Helper loaded: form_helper
INFO - 2016-05-21 10:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:18:43 --> Form Validation Class Initialized
INFO - 2016-05-21 10:18:43 --> Controller Class Initialized
INFO - 2016-05-21 10:18:43 --> Model Class Initialized
INFO - 2016-05-21 10:18:43 --> Database Driver Class Initialized
INFO - 2016-05-21 10:18:44 --> Final output sent to browser
DEBUG - 2016-05-21 10:18:44 --> Total execution time: 0.1946
INFO - 2016-05-21 10:18:52 --> Config Class Initialized
INFO - 2016-05-21 10:18:52 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:18:52 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:18:52 --> Utf8 Class Initialized
INFO - 2016-05-21 10:18:52 --> URI Class Initialized
INFO - 2016-05-21 10:18:52 --> Router Class Initialized
INFO - 2016-05-21 10:18:52 --> Output Class Initialized
INFO - 2016-05-21 10:18:52 --> Security Class Initialized
DEBUG - 2016-05-21 10:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:18:52 --> Input Class Initialized
INFO - 2016-05-21 10:18:52 --> Language Class Initialized
INFO - 2016-05-21 10:18:52 --> Loader Class Initialized
INFO - 2016-05-21 10:18:52 --> Helper loaded: url_helper
INFO - 2016-05-21 10:18:52 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:18:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:18:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:18:52 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:18:52 --> Helper loaded: form_helper
INFO - 2016-05-21 10:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:18:52 --> Form Validation Class Initialized
INFO - 2016-05-21 10:18:52 --> Controller Class Initialized
INFO - 2016-05-21 10:18:52 --> Model Class Initialized
INFO - 2016-05-21 10:18:52 --> Database Driver Class Initialized
INFO - 2016-05-21 10:18:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:18:52 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:18:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:18:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:18:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:18:52 --> Final output sent to browser
DEBUG - 2016-05-21 10:18:52 --> Total execution time: 0.0835
INFO - 2016-05-21 10:18:53 --> Config Class Initialized
INFO - 2016-05-21 10:18:53 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:18:53 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:18:53 --> Utf8 Class Initialized
INFO - 2016-05-21 10:18:53 --> URI Class Initialized
INFO - 2016-05-21 10:18:53 --> Router Class Initialized
INFO - 2016-05-21 10:18:53 --> Output Class Initialized
INFO - 2016-05-21 10:18:53 --> Security Class Initialized
DEBUG - 2016-05-21 10:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:18:53 --> Input Class Initialized
INFO - 2016-05-21 10:18:53 --> Language Class Initialized
INFO - 2016-05-21 10:18:53 --> Loader Class Initialized
INFO - 2016-05-21 10:18:53 --> Helper loaded: url_helper
INFO - 2016-05-21 10:18:53 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:18:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:18:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:18:53 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:18:53 --> Helper loaded: form_helper
INFO - 2016-05-21 10:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:18:53 --> Form Validation Class Initialized
INFO - 2016-05-21 10:18:53 --> Controller Class Initialized
INFO - 2016-05-21 10:18:53 --> Model Class Initialized
INFO - 2016-05-21 10:18:53 --> Database Driver Class Initialized
INFO - 2016-05-21 10:18:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:18:53 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:18:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:18:53 --> Final output sent to browser
DEBUG - 2016-05-21 10:18:53 --> Total execution time: 0.0877
INFO - 2016-05-21 10:19:54 --> Config Class Initialized
INFO - 2016-05-21 10:19:54 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:19:54 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:19:54 --> Utf8 Class Initialized
INFO - 2016-05-21 10:19:54 --> URI Class Initialized
INFO - 2016-05-21 10:19:54 --> Router Class Initialized
INFO - 2016-05-21 10:19:54 --> Output Class Initialized
INFO - 2016-05-21 10:19:54 --> Security Class Initialized
DEBUG - 2016-05-21 10:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:19:54 --> Input Class Initialized
INFO - 2016-05-21 10:19:54 --> Language Class Initialized
INFO - 2016-05-21 10:19:54 --> Loader Class Initialized
INFO - 2016-05-21 10:19:54 --> Helper loaded: url_helper
INFO - 2016-05-21 10:19:54 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:19:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:19:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:19:54 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:19:54 --> Helper loaded: form_helper
INFO - 2016-05-21 10:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:19:54 --> Form Validation Class Initialized
INFO - 2016-05-21 10:19:54 --> Controller Class Initialized
INFO - 2016-05-21 10:19:54 --> Model Class Initialized
INFO - 2016-05-21 10:19:54 --> Database Driver Class Initialized
INFO - 2016-05-21 10:19:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:19:54 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:19:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:19:54 --> Final output sent to browser
DEBUG - 2016-05-21 10:19:54 --> Total execution time: 0.1144
INFO - 2016-05-21 10:20:42 --> Config Class Initialized
INFO - 2016-05-21 10:20:42 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:20:42 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:20:42 --> Utf8 Class Initialized
INFO - 2016-05-21 10:20:42 --> URI Class Initialized
DEBUG - 2016-05-21 10:20:42 --> No URI present. Default controller set.
INFO - 2016-05-21 10:20:42 --> Router Class Initialized
INFO - 2016-05-21 10:20:42 --> Output Class Initialized
INFO - 2016-05-21 10:20:42 --> Security Class Initialized
DEBUG - 2016-05-21 10:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:20:42 --> Input Class Initialized
INFO - 2016-05-21 10:20:42 --> Language Class Initialized
INFO - 2016-05-21 10:20:42 --> Loader Class Initialized
INFO - 2016-05-21 10:20:42 --> Helper loaded: url_helper
INFO - 2016-05-21 10:20:42 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:20:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:20:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:20:42 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:20:42 --> Helper loaded: form_helper
INFO - 2016-05-21 10:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:20:42 --> Form Validation Class Initialized
INFO - 2016-05-21 10:20:42 --> Controller Class Initialized
INFO - 2016-05-21 10:20:42 --> Model Class Initialized
INFO - 2016-05-21 10:20:42 --> Database Driver Class Initialized
INFO - 2016-05-21 10:20:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:20:42 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:20:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:20:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-21 10:20:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:20:42 --> Final output sent to browser
DEBUG - 2016-05-21 10:20:42 --> Total execution time: 0.0919
INFO - 2016-05-21 10:20:46 --> Config Class Initialized
INFO - 2016-05-21 10:20:46 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:20:46 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:20:46 --> Utf8 Class Initialized
INFO - 2016-05-21 10:20:46 --> URI Class Initialized
INFO - 2016-05-21 10:20:46 --> Router Class Initialized
INFO - 2016-05-21 10:20:46 --> Output Class Initialized
INFO - 2016-05-21 10:20:46 --> Security Class Initialized
DEBUG - 2016-05-21 10:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:20:46 --> Input Class Initialized
INFO - 2016-05-21 10:20:46 --> Language Class Initialized
INFO - 2016-05-21 10:20:46 --> Loader Class Initialized
INFO - 2016-05-21 10:20:46 --> Helper loaded: url_helper
INFO - 2016-05-21 10:20:46 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:20:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:20:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:20:46 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:20:46 --> Helper loaded: form_helper
INFO - 2016-05-21 10:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:20:46 --> Form Validation Class Initialized
INFO - 2016-05-21 10:20:46 --> Controller Class Initialized
INFO - 2016-05-21 10:20:46 --> Model Class Initialized
INFO - 2016-05-21 10:20:46 --> Database Driver Class Initialized
ERROR - 2016-05-21 10:20:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 43
ERROR - 2016-05-21 10:20:46 --> Severity: Notice --> Undefined variable: cantidad C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 51
INFO - 2016-05-21 10:20:46 --> Config Class Initialized
INFO - 2016-05-21 10:20:46 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:20:46 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:20:46 --> Utf8 Class Initialized
INFO - 2016-05-21 10:20:46 --> URI Class Initialized
INFO - 2016-05-21 10:20:46 --> Router Class Initialized
INFO - 2016-05-21 10:20:46 --> Output Class Initialized
INFO - 2016-05-21 10:20:46 --> Security Class Initialized
DEBUG - 2016-05-21 10:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:20:46 --> Input Class Initialized
INFO - 2016-05-21 10:20:46 --> Language Class Initialized
INFO - 2016-05-21 10:20:46 --> Loader Class Initialized
INFO - 2016-05-21 10:20:46 --> Helper loaded: url_helper
INFO - 2016-05-21 10:20:46 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:20:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:20:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:20:46 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:20:46 --> Helper loaded: form_helper
INFO - 2016-05-21 10:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:20:46 --> Form Validation Class Initialized
INFO - 2016-05-21 10:20:46 --> Controller Class Initialized
INFO - 2016-05-21 10:20:46 --> Model Class Initialized
INFO - 2016-05-21 10:20:46 --> Database Driver Class Initialized
INFO - 2016-05-21 10:20:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_carrito.php
INFO - 2016-05-21 10:20:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:20:46 --> Final output sent to browser
DEBUG - 2016-05-21 10:20:46 --> Total execution time: 0.0820
INFO - 2016-05-21 10:20:47 --> Config Class Initialized
INFO - 2016-05-21 10:20:47 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:20:47 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:20:47 --> Utf8 Class Initialized
INFO - 2016-05-21 10:20:47 --> URI Class Initialized
INFO - 2016-05-21 10:20:47 --> Router Class Initialized
INFO - 2016-05-21 10:20:47 --> Output Class Initialized
INFO - 2016-05-21 10:20:47 --> Security Class Initialized
DEBUG - 2016-05-21 10:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:20:47 --> Input Class Initialized
INFO - 2016-05-21 10:20:47 --> Language Class Initialized
INFO - 2016-05-21 10:20:47 --> Loader Class Initialized
INFO - 2016-05-21 10:20:47 --> Helper loaded: url_helper
INFO - 2016-05-21 10:20:47 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:20:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:20:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:20:47 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:20:47 --> Helper loaded: form_helper
INFO - 2016-05-21 10:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:20:47 --> Form Validation Class Initialized
INFO - 2016-05-21 10:20:47 --> Controller Class Initialized
INFO - 2016-05-21 10:20:47 --> Model Class Initialized
INFO - 2016-05-21 10:20:47 --> Database Driver Class Initialized
INFO - 2016-05-21 10:20:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_venta1.php
INFO - 2016-05-21 10:20:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:20:47 --> Final output sent to browser
DEBUG - 2016-05-21 10:20:47 --> Total execution time: 0.0970
INFO - 2016-05-21 10:20:50 --> Config Class Initialized
INFO - 2016-05-21 10:20:50 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:20:50 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:20:50 --> Utf8 Class Initialized
INFO - 2016-05-21 10:20:50 --> URI Class Initialized
INFO - 2016-05-21 10:20:50 --> Router Class Initialized
INFO - 2016-05-21 10:20:50 --> Output Class Initialized
INFO - 2016-05-21 10:20:50 --> Security Class Initialized
DEBUG - 2016-05-21 10:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:20:50 --> Input Class Initialized
INFO - 2016-05-21 10:20:50 --> Language Class Initialized
INFO - 2016-05-21 10:20:50 --> Loader Class Initialized
INFO - 2016-05-21 10:20:50 --> Helper loaded: url_helper
INFO - 2016-05-21 10:20:50 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:20:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:20:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:20:50 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:20:50 --> Helper loaded: form_helper
INFO - 2016-05-21 10:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:20:50 --> Form Validation Class Initialized
INFO - 2016-05-21 10:20:50 --> Controller Class Initialized
INFO - 2016-05-21 10:20:50 --> Model Class Initialized
INFO - 2016-05-21 10:20:50 --> Database Driver Class Initialized
INFO - 2016-05-21 10:20:50 --> Config Class Initialized
INFO - 2016-05-21 10:20:50 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:20:50 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:20:50 --> Utf8 Class Initialized
INFO - 2016-05-21 10:20:50 --> URI Class Initialized
INFO - 2016-05-21 10:20:50 --> Router Class Initialized
INFO - 2016-05-21 10:20:50 --> Output Class Initialized
INFO - 2016-05-21 10:20:50 --> Security Class Initialized
DEBUG - 2016-05-21 10:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:20:50 --> Input Class Initialized
INFO - 2016-05-21 10:20:50 --> Language Class Initialized
INFO - 2016-05-21 10:20:50 --> Loader Class Initialized
INFO - 2016-05-21 10:20:50 --> Helper loaded: url_helper
INFO - 2016-05-21 10:20:50 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:20:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:20:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:20:50 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:20:50 --> Helper loaded: form_helper
INFO - 2016-05-21 10:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:20:50 --> Form Validation Class Initialized
INFO - 2016-05-21 10:20:50 --> Controller Class Initialized
INFO - 2016-05-21 10:20:50 --> Model Class Initialized
INFO - 2016-05-21 10:20:50 --> Database Driver Class Initialized
INFO - 2016-05-21 10:20:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_resumenventa.php
INFO - 2016-05-21 10:20:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:20:51 --> Final output sent to browser
DEBUG - 2016-05-21 10:20:51 --> Total execution time: 0.0836
INFO - 2016-05-21 10:20:52 --> Config Class Initialized
INFO - 2016-05-21 10:20:52 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:20:52 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:20:52 --> Utf8 Class Initialized
INFO - 2016-05-21 10:20:52 --> URI Class Initialized
INFO - 2016-05-21 10:20:52 --> Router Class Initialized
INFO - 2016-05-21 10:20:52 --> Output Class Initialized
INFO - 2016-05-21 10:20:52 --> Security Class Initialized
DEBUG - 2016-05-21 10:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:20:52 --> Input Class Initialized
INFO - 2016-05-21 10:20:52 --> Language Class Initialized
INFO - 2016-05-21 10:20:52 --> Loader Class Initialized
INFO - 2016-05-21 10:20:52 --> Helper loaded: url_helper
INFO - 2016-05-21 10:20:52 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:20:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:20:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:20:52 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:20:52 --> Helper loaded: form_helper
INFO - 2016-05-21 10:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:20:52 --> Form Validation Class Initialized
INFO - 2016-05-21 10:20:52 --> Controller Class Initialized
INFO - 2016-05-21 10:20:52 --> Model Class Initialized
INFO - 2016-05-21 10:20:52 --> Database Driver Class Initialized
INFO - 2016-05-21 10:20:52 --> Config Class Initialized
INFO - 2016-05-21 10:20:52 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:20:52 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:20:52 --> Utf8 Class Initialized
INFO - 2016-05-21 10:20:52 --> URI Class Initialized
INFO - 2016-05-21 10:20:52 --> Router Class Initialized
INFO - 2016-05-21 10:20:52 --> Output Class Initialized
INFO - 2016-05-21 10:20:52 --> Security Class Initialized
DEBUG - 2016-05-21 10:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:20:52 --> Input Class Initialized
INFO - 2016-05-21 10:20:52 --> Language Class Initialized
INFO - 2016-05-21 10:20:52 --> Loader Class Initialized
INFO - 2016-05-21 10:20:52 --> Helper loaded: url_helper
INFO - 2016-05-21 10:20:52 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:20:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:20:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:20:52 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:20:52 --> Helper loaded: form_helper
INFO - 2016-05-21 10:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:20:52 --> Form Validation Class Initialized
INFO - 2016-05-21 10:20:52 --> Controller Class Initialized
INFO - 2016-05-21 10:20:52 --> Model Class Initialized
INFO - 2016-05-21 10:20:52 --> Database Driver Class Initialized
INFO - 2016-05-21 10:20:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-21 10:20:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:20:52 --> Final output sent to browser
DEBUG - 2016-05-21 10:20:52 --> Total execution time: 0.1056
INFO - 2016-05-21 10:20:54 --> Config Class Initialized
INFO - 2016-05-21 10:20:54 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:20:54 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:20:54 --> Utf8 Class Initialized
INFO - 2016-05-21 10:20:54 --> URI Class Initialized
INFO - 2016-05-21 10:20:54 --> Router Class Initialized
INFO - 2016-05-21 10:20:54 --> Output Class Initialized
INFO - 2016-05-21 10:20:54 --> Security Class Initialized
DEBUG - 2016-05-21 10:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:20:54 --> Input Class Initialized
INFO - 2016-05-21 10:20:54 --> Language Class Initialized
INFO - 2016-05-21 10:20:54 --> Loader Class Initialized
INFO - 2016-05-21 10:20:54 --> Helper loaded: url_helper
INFO - 2016-05-21 10:20:54 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:20:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:20:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:20:54 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:20:54 --> Helper loaded: form_helper
INFO - 2016-05-21 10:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:20:54 --> Form Validation Class Initialized
INFO - 2016-05-21 10:20:54 --> Controller Class Initialized
INFO - 2016-05-21 10:20:54 --> Model Class Initialized
INFO - 2016-05-21 10:20:54 --> Database Driver Class Initialized
INFO - 2016-05-21 10:20:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:20:54 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:20:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:20:54 --> Final output sent to browser
DEBUG - 2016-05-21 10:20:54 --> Total execution time: 0.0964
INFO - 2016-05-21 10:20:56 --> Config Class Initialized
INFO - 2016-05-21 10:20:56 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:20:57 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:20:57 --> Utf8 Class Initialized
INFO - 2016-05-21 10:20:57 --> URI Class Initialized
INFO - 2016-05-21 10:20:57 --> Router Class Initialized
INFO - 2016-05-21 10:20:57 --> Output Class Initialized
INFO - 2016-05-21 10:20:57 --> Security Class Initialized
DEBUG - 2016-05-21 10:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:20:57 --> Input Class Initialized
INFO - 2016-05-21 10:20:57 --> Language Class Initialized
INFO - 2016-05-21 10:20:57 --> Loader Class Initialized
INFO - 2016-05-21 10:20:57 --> Helper loaded: url_helper
INFO - 2016-05-21 10:20:57 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:20:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:20:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:20:57 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:20:57 --> Helper loaded: form_helper
INFO - 2016-05-21 10:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:20:57 --> Form Validation Class Initialized
INFO - 2016-05-21 10:20:57 --> Controller Class Initialized
INFO - 2016-05-21 10:20:57 --> Model Class Initialized
INFO - 2016-05-21 10:20:57 --> Database Driver Class Initialized
INFO - 2016-05-21 10:20:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:20:57 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:20:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:20:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:20:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:20:57 --> Final output sent to browser
DEBUG - 2016-05-21 10:20:57 --> Total execution time: 0.0865
INFO - 2016-05-21 10:20:57 --> Config Class Initialized
INFO - 2016-05-21 10:20:57 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:20:57 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:20:57 --> Utf8 Class Initialized
INFO - 2016-05-21 10:20:57 --> URI Class Initialized
INFO - 2016-05-21 10:20:57 --> Router Class Initialized
INFO - 2016-05-21 10:20:57 --> Output Class Initialized
INFO - 2016-05-21 10:20:57 --> Security Class Initialized
DEBUG - 2016-05-21 10:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:20:57 --> Input Class Initialized
INFO - 2016-05-21 10:20:57 --> Language Class Initialized
INFO - 2016-05-21 10:20:57 --> Loader Class Initialized
INFO - 2016-05-21 10:20:57 --> Helper loaded: url_helper
INFO - 2016-05-21 10:20:57 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:20:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:20:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:20:57 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:20:57 --> Helper loaded: form_helper
INFO - 2016-05-21 10:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:20:57 --> Form Validation Class Initialized
INFO - 2016-05-21 10:20:57 --> Controller Class Initialized
INFO - 2016-05-21 10:20:57 --> Model Class Initialized
INFO - 2016-05-21 10:20:57 --> Database Driver Class Initialized
INFO - 2016-05-21 10:20:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:20:57 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:20:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:20:57 --> Final output sent to browser
DEBUG - 2016-05-21 10:20:57 --> Total execution time: 0.0898
INFO - 2016-05-21 10:21:08 --> Config Class Initialized
INFO - 2016-05-21 10:21:08 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:21:08 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:21:08 --> Utf8 Class Initialized
INFO - 2016-05-21 10:21:08 --> URI Class Initialized
INFO - 2016-05-21 10:21:08 --> Router Class Initialized
INFO - 2016-05-21 10:21:08 --> Output Class Initialized
INFO - 2016-05-21 10:21:08 --> Security Class Initialized
DEBUG - 2016-05-21 10:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:21:08 --> Input Class Initialized
INFO - 2016-05-21 10:21:08 --> Language Class Initialized
INFO - 2016-05-21 10:21:08 --> Loader Class Initialized
INFO - 2016-05-21 10:21:08 --> Helper loaded: url_helper
INFO - 2016-05-21 10:21:08 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:21:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:21:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:21:08 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:21:08 --> Helper loaded: form_helper
INFO - 2016-05-21 10:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:21:08 --> Form Validation Class Initialized
INFO - 2016-05-21 10:21:08 --> Controller Class Initialized
INFO - 2016-05-21 10:21:08 --> Model Class Initialized
INFO - 2016-05-21 10:21:08 --> Database Driver Class Initialized
INFO - 2016-05-21 10:21:08 --> Final output sent to browser
DEBUG - 2016-05-21 10:21:08 --> Total execution time: 0.1506
INFO - 2016-05-21 10:21:58 --> Config Class Initialized
INFO - 2016-05-21 10:21:58 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:21:58 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:21:58 --> Utf8 Class Initialized
INFO - 2016-05-21 10:21:58 --> URI Class Initialized
INFO - 2016-05-21 10:21:58 --> Router Class Initialized
INFO - 2016-05-21 10:21:58 --> Output Class Initialized
INFO - 2016-05-21 10:21:58 --> Security Class Initialized
DEBUG - 2016-05-21 10:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:21:58 --> Input Class Initialized
INFO - 2016-05-21 10:21:58 --> Language Class Initialized
INFO - 2016-05-21 10:21:58 --> Loader Class Initialized
INFO - 2016-05-21 10:21:58 --> Helper loaded: url_helper
INFO - 2016-05-21 10:21:58 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:21:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:21:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:21:58 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:21:58 --> Helper loaded: form_helper
INFO - 2016-05-21 10:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:21:58 --> Form Validation Class Initialized
INFO - 2016-05-21 10:21:58 --> Controller Class Initialized
INFO - 2016-05-21 10:21:58 --> Model Class Initialized
INFO - 2016-05-21 10:21:58 --> Database Driver Class Initialized
INFO - 2016-05-21 10:21:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:21:58 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:21:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:21:58 --> Final output sent to browser
DEBUG - 2016-05-21 10:21:58 --> Total execution time: 0.0831
INFO - 2016-05-21 10:22:27 --> Config Class Initialized
INFO - 2016-05-21 10:22:27 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:22:27 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:22:27 --> Utf8 Class Initialized
INFO - 2016-05-21 10:22:27 --> URI Class Initialized
DEBUG - 2016-05-21 10:22:27 --> No URI present. Default controller set.
INFO - 2016-05-21 10:22:27 --> Router Class Initialized
INFO - 2016-05-21 10:22:27 --> Output Class Initialized
INFO - 2016-05-21 10:22:27 --> Security Class Initialized
DEBUG - 2016-05-21 10:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:22:27 --> Input Class Initialized
INFO - 2016-05-21 10:22:27 --> Language Class Initialized
INFO - 2016-05-21 10:22:27 --> Loader Class Initialized
INFO - 2016-05-21 10:22:27 --> Helper loaded: url_helper
INFO - 2016-05-21 10:22:27 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:22:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:22:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:22:27 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:22:27 --> Helper loaded: form_helper
INFO - 2016-05-21 10:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:22:27 --> Form Validation Class Initialized
INFO - 2016-05-21 10:22:27 --> Controller Class Initialized
INFO - 2016-05-21 10:22:27 --> Model Class Initialized
INFO - 2016-05-21 10:22:27 --> Database Driver Class Initialized
INFO - 2016-05-21 10:22:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:22:27 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:22:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:22:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-21 10:22:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:22:27 --> Final output sent to browser
DEBUG - 2016-05-21 10:22:27 --> Total execution time: 0.0912
INFO - 2016-05-21 10:22:29 --> Config Class Initialized
INFO - 2016-05-21 10:22:29 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:22:29 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:22:29 --> Utf8 Class Initialized
INFO - 2016-05-21 10:22:29 --> URI Class Initialized
INFO - 2016-05-21 10:22:29 --> Router Class Initialized
INFO - 2016-05-21 10:22:29 --> Output Class Initialized
INFO - 2016-05-21 10:22:29 --> Security Class Initialized
DEBUG - 2016-05-21 10:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:22:29 --> Input Class Initialized
INFO - 2016-05-21 10:22:29 --> Language Class Initialized
INFO - 2016-05-21 10:22:29 --> Loader Class Initialized
INFO - 2016-05-21 10:22:29 --> Helper loaded: url_helper
INFO - 2016-05-21 10:22:29 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:22:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:22:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:22:29 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:22:29 --> Helper loaded: form_helper
INFO - 2016-05-21 10:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:22:29 --> Form Validation Class Initialized
INFO - 2016-05-21 10:22:29 --> Controller Class Initialized
INFO - 2016-05-21 10:22:29 --> Model Class Initialized
INFO - 2016-05-21 10:22:29 --> Database Driver Class Initialized
ERROR - 2016-05-21 10:22:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 43
ERROR - 2016-05-21 10:22:29 --> Severity: Notice --> Undefined variable: cantidad C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 51
INFO - 2016-05-21 10:22:29 --> Config Class Initialized
INFO - 2016-05-21 10:22:29 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:22:29 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:22:29 --> Utf8 Class Initialized
INFO - 2016-05-21 10:22:29 --> URI Class Initialized
INFO - 2016-05-21 10:22:29 --> Router Class Initialized
INFO - 2016-05-21 10:22:29 --> Output Class Initialized
INFO - 2016-05-21 10:22:29 --> Security Class Initialized
DEBUG - 2016-05-21 10:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:22:29 --> Input Class Initialized
INFO - 2016-05-21 10:22:29 --> Language Class Initialized
INFO - 2016-05-21 10:22:29 --> Loader Class Initialized
INFO - 2016-05-21 10:22:29 --> Helper loaded: url_helper
INFO - 2016-05-21 10:22:29 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:22:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:22:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:22:29 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:22:29 --> Helper loaded: form_helper
INFO - 2016-05-21 10:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:22:29 --> Form Validation Class Initialized
INFO - 2016-05-21 10:22:29 --> Controller Class Initialized
INFO - 2016-05-21 10:22:29 --> Model Class Initialized
INFO - 2016-05-21 10:22:29 --> Database Driver Class Initialized
INFO - 2016-05-21 10:22:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_carrito.php
INFO - 2016-05-21 10:22:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:22:29 --> Final output sent to browser
DEBUG - 2016-05-21 10:22:29 --> Total execution time: 0.0828
INFO - 2016-05-21 10:22:31 --> Config Class Initialized
INFO - 2016-05-21 10:22:31 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:22:31 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:22:31 --> Utf8 Class Initialized
INFO - 2016-05-21 10:22:31 --> URI Class Initialized
INFO - 2016-05-21 10:22:31 --> Router Class Initialized
INFO - 2016-05-21 10:22:31 --> Output Class Initialized
INFO - 2016-05-21 10:22:31 --> Security Class Initialized
DEBUG - 2016-05-21 10:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:22:31 --> Input Class Initialized
INFO - 2016-05-21 10:22:31 --> Language Class Initialized
INFO - 2016-05-21 10:22:31 --> Loader Class Initialized
INFO - 2016-05-21 10:22:31 --> Helper loaded: url_helper
INFO - 2016-05-21 10:22:31 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:22:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:22:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:22:31 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:22:31 --> Helper loaded: form_helper
INFO - 2016-05-21 10:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:22:31 --> Form Validation Class Initialized
INFO - 2016-05-21 10:22:31 --> Controller Class Initialized
INFO - 2016-05-21 10:22:31 --> Model Class Initialized
INFO - 2016-05-21 10:22:31 --> Database Driver Class Initialized
INFO - 2016-05-21 10:22:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_venta1.php
INFO - 2016-05-21 10:22:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:22:31 --> Final output sent to browser
DEBUG - 2016-05-21 10:22:31 --> Total execution time: 0.1068
INFO - 2016-05-21 10:22:34 --> Config Class Initialized
INFO - 2016-05-21 10:22:34 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:22:34 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:22:34 --> Utf8 Class Initialized
INFO - 2016-05-21 10:22:34 --> URI Class Initialized
INFO - 2016-05-21 10:22:34 --> Router Class Initialized
INFO - 2016-05-21 10:22:34 --> Output Class Initialized
INFO - 2016-05-21 10:22:34 --> Security Class Initialized
DEBUG - 2016-05-21 10:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:22:34 --> Input Class Initialized
INFO - 2016-05-21 10:22:34 --> Language Class Initialized
INFO - 2016-05-21 10:22:34 --> Loader Class Initialized
INFO - 2016-05-21 10:22:34 --> Helper loaded: url_helper
INFO - 2016-05-21 10:22:34 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:22:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:22:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:22:34 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:22:34 --> Helper loaded: form_helper
INFO - 2016-05-21 10:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:22:34 --> Form Validation Class Initialized
INFO - 2016-05-21 10:22:34 --> Controller Class Initialized
INFO - 2016-05-21 10:22:34 --> Model Class Initialized
INFO - 2016-05-21 10:22:34 --> Database Driver Class Initialized
INFO - 2016-05-21 10:22:34 --> Config Class Initialized
INFO - 2016-05-21 10:22:34 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:22:34 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:22:34 --> Utf8 Class Initialized
INFO - 2016-05-21 10:22:34 --> URI Class Initialized
INFO - 2016-05-21 10:22:34 --> Router Class Initialized
INFO - 2016-05-21 10:22:34 --> Output Class Initialized
INFO - 2016-05-21 10:22:34 --> Security Class Initialized
DEBUG - 2016-05-21 10:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:22:34 --> Input Class Initialized
INFO - 2016-05-21 10:22:34 --> Language Class Initialized
INFO - 2016-05-21 10:22:34 --> Loader Class Initialized
INFO - 2016-05-21 10:22:34 --> Helper loaded: url_helper
INFO - 2016-05-21 10:22:34 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:22:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:22:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:22:34 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:22:34 --> Helper loaded: form_helper
INFO - 2016-05-21 10:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:22:34 --> Form Validation Class Initialized
INFO - 2016-05-21 10:22:34 --> Controller Class Initialized
INFO - 2016-05-21 10:22:34 --> Model Class Initialized
INFO - 2016-05-21 10:22:35 --> Database Driver Class Initialized
INFO - 2016-05-21 10:22:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_resumenventa.php
INFO - 2016-05-21 10:22:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:22:35 --> Final output sent to browser
DEBUG - 2016-05-21 10:22:35 --> Total execution time: 0.0939
INFO - 2016-05-21 10:22:36 --> Config Class Initialized
INFO - 2016-05-21 10:22:36 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:22:36 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:22:36 --> Utf8 Class Initialized
INFO - 2016-05-21 10:22:36 --> URI Class Initialized
INFO - 2016-05-21 10:22:36 --> Router Class Initialized
INFO - 2016-05-21 10:22:36 --> Output Class Initialized
INFO - 2016-05-21 10:22:36 --> Security Class Initialized
DEBUG - 2016-05-21 10:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:22:36 --> Input Class Initialized
INFO - 2016-05-21 10:22:36 --> Language Class Initialized
INFO - 2016-05-21 10:22:36 --> Loader Class Initialized
INFO - 2016-05-21 10:22:36 --> Helper loaded: url_helper
INFO - 2016-05-21 10:22:36 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:22:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:22:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:22:36 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:22:36 --> Helper loaded: form_helper
INFO - 2016-05-21 10:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:22:36 --> Form Validation Class Initialized
INFO - 2016-05-21 10:22:36 --> Controller Class Initialized
INFO - 2016-05-21 10:22:36 --> Model Class Initialized
INFO - 2016-05-21 10:22:36 --> Database Driver Class Initialized
INFO - 2016-05-21 10:22:36 --> Config Class Initialized
INFO - 2016-05-21 10:22:36 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:22:36 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:22:36 --> Utf8 Class Initialized
INFO - 2016-05-21 10:22:36 --> URI Class Initialized
INFO - 2016-05-21 10:22:36 --> Router Class Initialized
INFO - 2016-05-21 10:22:36 --> Output Class Initialized
INFO - 2016-05-21 10:22:36 --> Security Class Initialized
DEBUG - 2016-05-21 10:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:22:36 --> Input Class Initialized
INFO - 2016-05-21 10:22:36 --> Language Class Initialized
INFO - 2016-05-21 10:22:36 --> Loader Class Initialized
INFO - 2016-05-21 10:22:36 --> Helper loaded: url_helper
INFO - 2016-05-21 10:22:36 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:22:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:22:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:22:36 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:22:36 --> Helper loaded: form_helper
INFO - 2016-05-21 10:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:22:36 --> Form Validation Class Initialized
INFO - 2016-05-21 10:22:36 --> Controller Class Initialized
INFO - 2016-05-21 10:22:36 --> Model Class Initialized
INFO - 2016-05-21 10:22:36 --> Database Driver Class Initialized
INFO - 2016-05-21 10:22:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-21 10:22:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:22:36 --> Final output sent to browser
DEBUG - 2016-05-21 10:22:36 --> Total execution time: 0.0902
INFO - 2016-05-21 10:22:43 --> Config Class Initialized
INFO - 2016-05-21 10:22:43 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:22:43 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:22:43 --> Utf8 Class Initialized
INFO - 2016-05-21 10:22:43 --> URI Class Initialized
INFO - 2016-05-21 10:22:43 --> Router Class Initialized
INFO - 2016-05-21 10:22:43 --> Output Class Initialized
INFO - 2016-05-21 10:22:43 --> Security Class Initialized
DEBUG - 2016-05-21 10:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:22:43 --> Input Class Initialized
INFO - 2016-05-21 10:22:43 --> Language Class Initialized
INFO - 2016-05-21 10:22:43 --> Loader Class Initialized
INFO - 2016-05-21 10:22:43 --> Helper loaded: url_helper
INFO - 2016-05-21 10:22:43 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:22:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:22:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:22:43 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:22:43 --> Helper loaded: form_helper
INFO - 2016-05-21 10:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:22:43 --> Form Validation Class Initialized
INFO - 2016-05-21 10:22:43 --> Controller Class Initialized
INFO - 2016-05-21 10:22:43 --> Model Class Initialized
INFO - 2016-05-21 10:22:43 --> Database Driver Class Initialized
INFO - 2016-05-21 10:22:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:22:43 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:22:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:22:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:22:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:22:43 --> Final output sent to browser
DEBUG - 2016-05-21 10:22:43 --> Total execution time: 0.0867
INFO - 2016-05-21 10:22:44 --> Config Class Initialized
INFO - 2016-05-21 10:22:44 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:22:44 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:22:44 --> Utf8 Class Initialized
INFO - 2016-05-21 10:22:44 --> URI Class Initialized
INFO - 2016-05-21 10:22:44 --> Router Class Initialized
INFO - 2016-05-21 10:22:44 --> Output Class Initialized
INFO - 2016-05-21 10:22:44 --> Security Class Initialized
DEBUG - 2016-05-21 10:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:22:44 --> Input Class Initialized
INFO - 2016-05-21 10:22:44 --> Language Class Initialized
INFO - 2016-05-21 10:22:44 --> Loader Class Initialized
INFO - 2016-05-21 10:22:44 --> Helper loaded: url_helper
INFO - 2016-05-21 10:22:44 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:22:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:22:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:22:44 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:22:44 --> Helper loaded: form_helper
INFO - 2016-05-21 10:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:22:44 --> Form Validation Class Initialized
INFO - 2016-05-21 10:22:44 --> Controller Class Initialized
INFO - 2016-05-21 10:22:44 --> Model Class Initialized
INFO - 2016-05-21 10:22:44 --> Database Driver Class Initialized
INFO - 2016-05-21 10:22:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:22:44 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:22:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:22:44 --> Final output sent to browser
DEBUG - 2016-05-21 10:22:44 --> Total execution time: 0.0830
INFO - 2016-05-21 10:23:44 --> Config Class Initialized
INFO - 2016-05-21 10:23:44 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:23:44 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:23:44 --> Utf8 Class Initialized
INFO - 2016-05-21 10:23:44 --> URI Class Initialized
INFO - 2016-05-21 10:23:44 --> Router Class Initialized
INFO - 2016-05-21 10:23:44 --> Output Class Initialized
INFO - 2016-05-21 10:23:44 --> Security Class Initialized
DEBUG - 2016-05-21 10:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:23:44 --> Input Class Initialized
INFO - 2016-05-21 10:23:44 --> Language Class Initialized
INFO - 2016-05-21 10:23:44 --> Loader Class Initialized
INFO - 2016-05-21 10:23:44 --> Helper loaded: url_helper
INFO - 2016-05-21 10:23:44 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:23:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:23:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:23:44 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:23:44 --> Helper loaded: form_helper
INFO - 2016-05-21 10:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:23:44 --> Form Validation Class Initialized
INFO - 2016-05-21 10:23:44 --> Controller Class Initialized
INFO - 2016-05-21 10:23:44 --> Model Class Initialized
INFO - 2016-05-21 10:23:44 --> Database Driver Class Initialized
INFO - 2016-05-21 10:23:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:23:44 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:23:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:23:44 --> Final output sent to browser
DEBUG - 2016-05-21 10:23:44 --> Total execution time: 0.0696
INFO - 2016-05-21 10:24:44 --> Config Class Initialized
INFO - 2016-05-21 10:24:44 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:24:44 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:24:44 --> Utf8 Class Initialized
INFO - 2016-05-21 10:24:44 --> URI Class Initialized
INFO - 2016-05-21 10:24:44 --> Router Class Initialized
INFO - 2016-05-21 10:24:44 --> Output Class Initialized
INFO - 2016-05-21 10:24:44 --> Security Class Initialized
DEBUG - 2016-05-21 10:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:24:44 --> Input Class Initialized
INFO - 2016-05-21 10:24:44 --> Language Class Initialized
INFO - 2016-05-21 10:24:44 --> Loader Class Initialized
INFO - 2016-05-21 10:24:44 --> Helper loaded: url_helper
INFO - 2016-05-21 10:24:44 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:24:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:24:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:24:44 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:24:44 --> Helper loaded: form_helper
INFO - 2016-05-21 10:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:24:44 --> Form Validation Class Initialized
INFO - 2016-05-21 10:24:44 --> Controller Class Initialized
INFO - 2016-05-21 10:24:44 --> Model Class Initialized
INFO - 2016-05-21 10:24:44 --> Database Driver Class Initialized
INFO - 2016-05-21 10:24:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:24:44 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:24:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:24:44 --> Final output sent to browser
DEBUG - 2016-05-21 10:24:44 --> Total execution time: 0.0685
INFO - 2016-05-21 10:25:39 --> Config Class Initialized
INFO - 2016-05-21 10:25:39 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:25:39 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:25:39 --> Utf8 Class Initialized
INFO - 2016-05-21 10:25:39 --> URI Class Initialized
DEBUG - 2016-05-21 10:25:39 --> No URI present. Default controller set.
INFO - 2016-05-21 10:25:39 --> Router Class Initialized
INFO - 2016-05-21 10:25:39 --> Output Class Initialized
INFO - 2016-05-21 10:25:40 --> Security Class Initialized
DEBUG - 2016-05-21 10:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:25:40 --> Input Class Initialized
INFO - 2016-05-21 10:25:40 --> Language Class Initialized
INFO - 2016-05-21 10:25:40 --> Loader Class Initialized
INFO - 2016-05-21 10:25:40 --> Helper loaded: url_helper
INFO - 2016-05-21 10:25:40 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:25:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:25:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:25:40 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:25:40 --> Helper loaded: form_helper
INFO - 2016-05-21 10:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:25:40 --> Form Validation Class Initialized
INFO - 2016-05-21 10:25:40 --> Controller Class Initialized
INFO - 2016-05-21 10:25:40 --> Model Class Initialized
INFO - 2016-05-21 10:25:40 --> Database Driver Class Initialized
INFO - 2016-05-21 10:25:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:25:40 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:25:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:25:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-21 10:25:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:25:40 --> Final output sent to browser
DEBUG - 2016-05-21 10:25:40 --> Total execution time: 0.0895
INFO - 2016-05-21 10:25:44 --> Config Class Initialized
INFO - 2016-05-21 10:25:44 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:25:44 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:25:44 --> Utf8 Class Initialized
INFO - 2016-05-21 10:25:44 --> URI Class Initialized
INFO - 2016-05-21 10:25:44 --> Router Class Initialized
INFO - 2016-05-21 10:25:44 --> Output Class Initialized
INFO - 2016-05-21 10:25:44 --> Security Class Initialized
DEBUG - 2016-05-21 10:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:25:44 --> Config Class Initialized
INFO - 2016-05-21 10:25:44 --> Input Class Initialized
INFO - 2016-05-21 10:25:44 --> Hooks Class Initialized
INFO - 2016-05-21 10:25:44 --> Language Class Initialized
INFO - 2016-05-21 10:25:44 --> Loader Class Initialized
DEBUG - 2016-05-21 10:25:44 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:25:44 --> Utf8 Class Initialized
INFO - 2016-05-21 10:25:44 --> URI Class Initialized
INFO - 2016-05-21 10:25:44 --> Helper loaded: url_helper
INFO - 2016-05-21 10:25:44 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:25:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:25:44 --> Router Class Initialized
INFO - 2016-05-21 10:25:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:25:44 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:25:44 --> Output Class Initialized
INFO - 2016-05-21 10:25:44 --> Helper loaded: form_helper
INFO - 2016-05-21 10:25:44 --> Security Class Initialized
DEBUG - 2016-05-21 10:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:25:44 --> Input Class Initialized
INFO - 2016-05-21 10:25:44 --> Language Class Initialized
INFO - 2016-05-21 10:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:25:44 --> Loader Class Initialized
INFO - 2016-05-21 10:25:44 --> Form Validation Class Initialized
INFO - 2016-05-21 10:25:44 --> Controller Class Initialized
INFO - 2016-05-21 10:25:44 --> Model Class Initialized
INFO - 2016-05-21 10:25:44 --> Helper loaded: url_helper
INFO - 2016-05-21 10:25:44 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:25:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:25:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:25:44 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:25:44 --> Helper loaded: form_helper
INFO - 2016-05-21 10:25:44 --> Database Driver Class Initialized
ERROR - 2016-05-21 10:25:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 43
ERROR - 2016-05-21 10:25:44 --> Severity: Notice --> Undefined variable: cantidad C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 51
INFO - 2016-05-21 10:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:25:44 --> Form Validation Class Initialized
INFO - 2016-05-21 10:25:44 --> Controller Class Initialized
INFO - 2016-05-21 10:25:44 --> Model Class Initialized
INFO - 2016-05-21 10:25:44 --> Database Driver Class Initialized
INFO - 2016-05-21 10:25:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:25:44 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:25:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:25:44 --> Config Class Initialized
INFO - 2016-05-21 10:25:44 --> Hooks Class Initialized
INFO - 2016-05-21 10:25:44 --> Final output sent to browser
DEBUG - 2016-05-21 10:25:44 --> Total execution time: 0.1095
DEBUG - 2016-05-21 10:25:44 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:25:44 --> Utf8 Class Initialized
INFO - 2016-05-21 10:25:44 --> URI Class Initialized
INFO - 2016-05-21 10:25:44 --> Router Class Initialized
INFO - 2016-05-21 10:25:44 --> Output Class Initialized
INFO - 2016-05-21 10:25:44 --> Security Class Initialized
DEBUG - 2016-05-21 10:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:25:44 --> Input Class Initialized
INFO - 2016-05-21 10:25:44 --> Language Class Initialized
INFO - 2016-05-21 10:25:44 --> Loader Class Initialized
INFO - 2016-05-21 10:25:44 --> Helper loaded: url_helper
INFO - 2016-05-21 10:25:44 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:25:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:25:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:25:44 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:25:44 --> Helper loaded: form_helper
INFO - 2016-05-21 10:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:25:44 --> Form Validation Class Initialized
INFO - 2016-05-21 10:25:44 --> Controller Class Initialized
INFO - 2016-05-21 10:25:44 --> Model Class Initialized
INFO - 2016-05-21 10:25:44 --> Database Driver Class Initialized
INFO - 2016-05-21 10:25:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_carrito.php
INFO - 2016-05-21 10:25:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:25:44 --> Final output sent to browser
DEBUG - 2016-05-21 10:25:44 --> Total execution time: 0.0845
INFO - 2016-05-21 10:25:47 --> Config Class Initialized
INFO - 2016-05-21 10:25:47 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:25:47 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:25:47 --> Utf8 Class Initialized
INFO - 2016-05-21 10:25:47 --> URI Class Initialized
INFO - 2016-05-21 10:25:47 --> Router Class Initialized
INFO - 2016-05-21 10:25:47 --> Output Class Initialized
INFO - 2016-05-21 10:25:47 --> Security Class Initialized
DEBUG - 2016-05-21 10:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:25:47 --> Input Class Initialized
INFO - 2016-05-21 10:25:47 --> Language Class Initialized
INFO - 2016-05-21 10:25:47 --> Loader Class Initialized
INFO - 2016-05-21 10:25:47 --> Helper loaded: url_helper
INFO - 2016-05-21 10:25:47 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:25:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:25:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:25:47 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:25:47 --> Helper loaded: form_helper
INFO - 2016-05-21 10:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:25:47 --> Form Validation Class Initialized
INFO - 2016-05-21 10:25:47 --> Controller Class Initialized
INFO - 2016-05-21 10:25:47 --> Model Class Initialized
INFO - 2016-05-21 10:25:47 --> Database Driver Class Initialized
INFO - 2016-05-21 10:25:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_venta1.php
INFO - 2016-05-21 10:25:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:25:47 --> Final output sent to browser
DEBUG - 2016-05-21 10:25:47 --> Total execution time: 0.0870
INFO - 2016-05-21 10:25:51 --> Config Class Initialized
INFO - 2016-05-21 10:25:51 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:25:51 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:25:51 --> Utf8 Class Initialized
INFO - 2016-05-21 10:25:51 --> URI Class Initialized
INFO - 2016-05-21 10:25:51 --> Router Class Initialized
INFO - 2016-05-21 10:25:51 --> Output Class Initialized
INFO - 2016-05-21 10:25:51 --> Security Class Initialized
DEBUG - 2016-05-21 10:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:25:51 --> Input Class Initialized
INFO - 2016-05-21 10:25:51 --> Language Class Initialized
INFO - 2016-05-21 10:25:51 --> Loader Class Initialized
INFO - 2016-05-21 10:25:51 --> Helper loaded: url_helper
INFO - 2016-05-21 10:25:51 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:25:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:25:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:25:51 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:25:51 --> Helper loaded: form_helper
INFO - 2016-05-21 10:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:25:51 --> Form Validation Class Initialized
INFO - 2016-05-21 10:25:51 --> Controller Class Initialized
INFO - 2016-05-21 10:25:51 --> Model Class Initialized
INFO - 2016-05-21 10:25:51 --> Database Driver Class Initialized
INFO - 2016-05-21 10:25:51 --> Config Class Initialized
INFO - 2016-05-21 10:25:51 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:25:51 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:25:51 --> Utf8 Class Initialized
INFO - 2016-05-21 10:25:51 --> URI Class Initialized
INFO - 2016-05-21 10:25:51 --> Router Class Initialized
INFO - 2016-05-21 10:25:51 --> Output Class Initialized
INFO - 2016-05-21 10:25:51 --> Security Class Initialized
DEBUG - 2016-05-21 10:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:25:51 --> Input Class Initialized
INFO - 2016-05-21 10:25:51 --> Language Class Initialized
INFO - 2016-05-21 10:25:51 --> Loader Class Initialized
INFO - 2016-05-21 10:25:51 --> Helper loaded: url_helper
INFO - 2016-05-21 10:25:51 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:25:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:25:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:25:51 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:25:51 --> Helper loaded: form_helper
INFO - 2016-05-21 10:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:25:51 --> Form Validation Class Initialized
INFO - 2016-05-21 10:25:51 --> Controller Class Initialized
INFO - 2016-05-21 10:25:51 --> Model Class Initialized
INFO - 2016-05-21 10:25:51 --> Database Driver Class Initialized
INFO - 2016-05-21 10:25:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_resumenventa.php
INFO - 2016-05-21 10:25:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:25:51 --> Final output sent to browser
DEBUG - 2016-05-21 10:25:51 --> Total execution time: 0.0827
INFO - 2016-05-21 10:25:53 --> Config Class Initialized
INFO - 2016-05-21 10:25:53 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:25:53 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:25:53 --> Utf8 Class Initialized
INFO - 2016-05-21 10:25:53 --> URI Class Initialized
INFO - 2016-05-21 10:25:53 --> Router Class Initialized
INFO - 2016-05-21 10:25:53 --> Output Class Initialized
INFO - 2016-05-21 10:25:54 --> Security Class Initialized
DEBUG - 2016-05-21 10:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:25:54 --> Input Class Initialized
INFO - 2016-05-21 10:25:54 --> Language Class Initialized
INFO - 2016-05-21 10:25:54 --> Loader Class Initialized
INFO - 2016-05-21 10:25:54 --> Helper loaded: url_helper
INFO - 2016-05-21 10:25:54 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:25:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:25:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:25:54 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:25:54 --> Helper loaded: form_helper
INFO - 2016-05-21 10:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:25:54 --> Form Validation Class Initialized
INFO - 2016-05-21 10:25:54 --> Controller Class Initialized
INFO - 2016-05-21 10:25:54 --> Model Class Initialized
INFO - 2016-05-21 10:25:54 --> Database Driver Class Initialized
INFO - 2016-05-21 10:25:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_venta1.php
INFO - 2016-05-21 10:25:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:25:54 --> Final output sent to browser
DEBUG - 2016-05-21 10:25:54 --> Total execution time: 0.0770
INFO - 2016-05-21 10:25:57 --> Config Class Initialized
INFO - 2016-05-21 10:25:57 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:25:57 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:25:57 --> Utf8 Class Initialized
INFO - 2016-05-21 10:25:57 --> URI Class Initialized
INFO - 2016-05-21 10:25:57 --> Router Class Initialized
INFO - 2016-05-21 10:25:57 --> Output Class Initialized
INFO - 2016-05-21 10:25:57 --> Security Class Initialized
DEBUG - 2016-05-21 10:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:25:57 --> Input Class Initialized
INFO - 2016-05-21 10:25:57 --> Language Class Initialized
INFO - 2016-05-21 10:25:57 --> Loader Class Initialized
INFO - 2016-05-21 10:25:57 --> Helper loaded: url_helper
INFO - 2016-05-21 10:25:57 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:25:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:25:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:25:57 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:25:57 --> Helper loaded: form_helper
INFO - 2016-05-21 10:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:25:57 --> Form Validation Class Initialized
INFO - 2016-05-21 10:25:57 --> Controller Class Initialized
INFO - 2016-05-21 10:25:57 --> Model Class Initialized
INFO - 2016-05-21 10:25:57 --> Database Driver Class Initialized
INFO - 2016-05-21 10:25:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_venta2.php
INFO - 2016-05-21 10:25:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:25:57 --> Final output sent to browser
DEBUG - 2016-05-21 10:25:57 --> Total execution time: 0.1260
INFO - 2016-05-21 10:26:04 --> Config Class Initialized
INFO - 2016-05-21 10:26:04 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:26:04 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:26:04 --> Utf8 Class Initialized
INFO - 2016-05-21 10:26:04 --> URI Class Initialized
INFO - 2016-05-21 10:26:04 --> Router Class Initialized
INFO - 2016-05-21 10:26:04 --> Output Class Initialized
INFO - 2016-05-21 10:26:04 --> Security Class Initialized
DEBUG - 2016-05-21 10:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:26:04 --> Input Class Initialized
INFO - 2016-05-21 10:26:04 --> Language Class Initialized
INFO - 2016-05-21 10:26:04 --> Loader Class Initialized
INFO - 2016-05-21 10:26:04 --> Helper loaded: url_helper
INFO - 2016-05-21 10:26:04 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:26:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:26:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:26:04 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:26:04 --> Helper loaded: form_helper
INFO - 2016-05-21 10:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:26:04 --> Form Validation Class Initialized
INFO - 2016-05-21 10:26:04 --> Controller Class Initialized
INFO - 2016-05-21 10:26:04 --> Model Class Initialized
INFO - 2016-05-21 10:26:04 --> Database Driver Class Initialized
INFO - 2016-05-21 10:26:04 --> Config Class Initialized
INFO - 2016-05-21 10:26:04 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:26:04 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:26:04 --> Utf8 Class Initialized
INFO - 2016-05-21 10:26:04 --> URI Class Initialized
INFO - 2016-05-21 10:26:04 --> Router Class Initialized
INFO - 2016-05-21 10:26:04 --> Output Class Initialized
INFO - 2016-05-21 10:26:04 --> Security Class Initialized
DEBUG - 2016-05-21 10:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:26:04 --> Input Class Initialized
INFO - 2016-05-21 10:26:04 --> Language Class Initialized
INFO - 2016-05-21 10:26:04 --> Loader Class Initialized
INFO - 2016-05-21 10:26:04 --> Helper loaded: url_helper
INFO - 2016-05-21 10:26:04 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:26:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:26:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:26:04 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:26:04 --> Helper loaded: form_helper
INFO - 2016-05-21 10:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:26:04 --> Form Validation Class Initialized
INFO - 2016-05-21 10:26:04 --> Controller Class Initialized
INFO - 2016-05-21 10:26:04 --> Model Class Initialized
INFO - 2016-05-21 10:26:04 --> Database Driver Class Initialized
INFO - 2016-05-21 10:26:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_resumenventa.php
INFO - 2016-05-21 10:26:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:26:04 --> Final output sent to browser
DEBUG - 2016-05-21 10:26:04 --> Total execution time: 0.0850
INFO - 2016-05-21 10:26:06 --> Config Class Initialized
INFO - 2016-05-21 10:26:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:26:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:26:06 --> Utf8 Class Initialized
INFO - 2016-05-21 10:26:06 --> URI Class Initialized
INFO - 2016-05-21 10:26:06 --> Router Class Initialized
INFO - 2016-05-21 10:26:06 --> Output Class Initialized
INFO - 2016-05-21 10:26:06 --> Security Class Initialized
DEBUG - 2016-05-21 10:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:26:06 --> Input Class Initialized
INFO - 2016-05-21 10:26:06 --> Language Class Initialized
INFO - 2016-05-21 10:26:06 --> Loader Class Initialized
INFO - 2016-05-21 10:26:06 --> Helper loaded: url_helper
INFO - 2016-05-21 10:26:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:26:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:26:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:26:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:26:06 --> Helper loaded: form_helper
INFO - 2016-05-21 10:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:26:06 --> Form Validation Class Initialized
INFO - 2016-05-21 10:26:06 --> Controller Class Initialized
INFO - 2016-05-21 10:26:06 --> Model Class Initialized
INFO - 2016-05-21 10:26:06 --> Database Driver Class Initialized
INFO - 2016-05-21 10:26:06 --> Config Class Initialized
INFO - 2016-05-21 10:26:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:26:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:26:06 --> Utf8 Class Initialized
INFO - 2016-05-21 10:26:06 --> URI Class Initialized
INFO - 2016-05-21 10:26:06 --> Router Class Initialized
INFO - 2016-05-21 10:26:06 --> Output Class Initialized
INFO - 2016-05-21 10:26:07 --> Security Class Initialized
DEBUG - 2016-05-21 10:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:26:07 --> Input Class Initialized
INFO - 2016-05-21 10:26:07 --> Language Class Initialized
INFO - 2016-05-21 10:26:07 --> Loader Class Initialized
INFO - 2016-05-21 10:26:07 --> Helper loaded: url_helper
INFO - 2016-05-21 10:26:07 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:26:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:26:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:26:07 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:26:07 --> Helper loaded: form_helper
INFO - 2016-05-21 10:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:26:07 --> Form Validation Class Initialized
INFO - 2016-05-21 10:26:07 --> Controller Class Initialized
INFO - 2016-05-21 10:26:07 --> Model Class Initialized
INFO - 2016-05-21 10:26:07 --> Database Driver Class Initialized
INFO - 2016-05-21 10:26:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-21 10:26:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-21 10:26:07 --> Final output sent to browser
DEBUG - 2016-05-21 10:26:07 --> Total execution time: 0.0811
INFO - 2016-05-21 10:26:10 --> Config Class Initialized
INFO - 2016-05-21 10:26:10 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:26:10 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:26:10 --> Utf8 Class Initialized
INFO - 2016-05-21 10:26:10 --> URI Class Initialized
INFO - 2016-05-21 10:26:10 --> Router Class Initialized
INFO - 2016-05-21 10:26:10 --> Output Class Initialized
INFO - 2016-05-21 10:26:10 --> Security Class Initialized
DEBUG - 2016-05-21 10:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:26:10 --> Input Class Initialized
INFO - 2016-05-21 10:26:10 --> Language Class Initialized
INFO - 2016-05-21 10:26:10 --> Loader Class Initialized
INFO - 2016-05-21 10:26:10 --> Helper loaded: url_helper
INFO - 2016-05-21 10:26:10 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:26:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:26:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:26:10 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:26:10 --> Helper loaded: form_helper
INFO - 2016-05-21 10:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:26:10 --> Form Validation Class Initialized
INFO - 2016-05-21 10:26:10 --> Controller Class Initialized
INFO - 2016-05-21 10:26:10 --> Model Class Initialized
INFO - 2016-05-21 10:26:10 --> Database Driver Class Initialized
INFO - 2016-05-21 10:26:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:26:10 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:26:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:26:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:26:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:26:10 --> Final output sent to browser
DEBUG - 2016-05-21 10:26:10 --> Total execution time: 0.0813
INFO - 2016-05-21 10:26:10 --> Config Class Initialized
INFO - 2016-05-21 10:26:10 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:26:10 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:26:10 --> Utf8 Class Initialized
INFO - 2016-05-21 10:26:10 --> URI Class Initialized
INFO - 2016-05-21 10:26:10 --> Router Class Initialized
INFO - 2016-05-21 10:26:11 --> Output Class Initialized
INFO - 2016-05-21 10:26:11 --> Security Class Initialized
DEBUG - 2016-05-21 10:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:26:11 --> Input Class Initialized
INFO - 2016-05-21 10:26:11 --> Language Class Initialized
INFO - 2016-05-21 10:26:11 --> Loader Class Initialized
INFO - 2016-05-21 10:26:11 --> Helper loaded: url_helper
INFO - 2016-05-21 10:26:11 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:26:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:26:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:26:11 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:26:11 --> Helper loaded: form_helper
INFO - 2016-05-21 10:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:26:11 --> Form Validation Class Initialized
INFO - 2016-05-21 10:26:11 --> Controller Class Initialized
INFO - 2016-05-21 10:26:11 --> Model Class Initialized
INFO - 2016-05-21 10:26:11 --> Database Driver Class Initialized
INFO - 2016-05-21 10:26:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:26:11 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:26:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:26:11 --> Final output sent to browser
DEBUG - 2016-05-21 10:26:11 --> Total execution time: 0.0913
INFO - 2016-05-21 10:26:26 --> Config Class Initialized
INFO - 2016-05-21 10:26:26 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:26:26 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:26:26 --> Utf8 Class Initialized
INFO - 2016-05-21 10:26:26 --> URI Class Initialized
INFO - 2016-05-21 10:26:26 --> Router Class Initialized
INFO - 2016-05-21 10:26:26 --> Output Class Initialized
INFO - 2016-05-21 10:26:26 --> Security Class Initialized
DEBUG - 2016-05-21 10:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:26:26 --> Input Class Initialized
INFO - 2016-05-21 10:26:26 --> Language Class Initialized
INFO - 2016-05-21 10:26:26 --> Loader Class Initialized
INFO - 2016-05-21 10:26:26 --> Helper loaded: url_helper
INFO - 2016-05-21 10:26:26 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:26:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:26:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:26:26 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:26:26 --> Helper loaded: form_helper
INFO - 2016-05-21 10:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:26:26 --> Form Validation Class Initialized
INFO - 2016-05-21 10:26:26 --> Controller Class Initialized
INFO - 2016-05-21 10:26:26 --> Model Class Initialized
INFO - 2016-05-21 10:26:26 --> Database Driver Class Initialized
INFO - 2016-05-21 10:26:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:26:26 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:26:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:26:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:26:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:26:26 --> Final output sent to browser
DEBUG - 2016-05-21 10:26:26 --> Total execution time: 0.0966
INFO - 2016-05-21 10:26:27 --> Config Class Initialized
INFO - 2016-05-21 10:26:27 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:26:27 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:26:27 --> Utf8 Class Initialized
INFO - 2016-05-21 10:26:27 --> URI Class Initialized
INFO - 2016-05-21 10:26:27 --> Router Class Initialized
INFO - 2016-05-21 10:26:27 --> Output Class Initialized
INFO - 2016-05-21 10:26:27 --> Security Class Initialized
DEBUG - 2016-05-21 10:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:26:27 --> Input Class Initialized
INFO - 2016-05-21 10:26:27 --> Language Class Initialized
INFO - 2016-05-21 10:26:27 --> Loader Class Initialized
INFO - 2016-05-21 10:26:27 --> Helper loaded: url_helper
INFO - 2016-05-21 10:26:27 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:26:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:26:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:26:27 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:26:27 --> Helper loaded: form_helper
INFO - 2016-05-21 10:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:26:27 --> Form Validation Class Initialized
INFO - 2016-05-21 10:26:27 --> Controller Class Initialized
INFO - 2016-05-21 10:26:27 --> Model Class Initialized
INFO - 2016-05-21 10:26:27 --> Database Driver Class Initialized
INFO - 2016-05-21 10:26:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:26:27 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:26:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:26:27 --> Final output sent to browser
DEBUG - 2016-05-21 10:26:27 --> Total execution time: 0.0875
INFO - 2016-05-21 10:27:28 --> Config Class Initialized
INFO - 2016-05-21 10:27:28 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:27:28 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:27:28 --> Utf8 Class Initialized
INFO - 2016-05-21 10:27:28 --> URI Class Initialized
INFO - 2016-05-21 10:27:28 --> Router Class Initialized
INFO - 2016-05-21 10:27:28 --> Output Class Initialized
INFO - 2016-05-21 10:27:28 --> Security Class Initialized
DEBUG - 2016-05-21 10:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:27:28 --> Input Class Initialized
INFO - 2016-05-21 10:27:28 --> Language Class Initialized
INFO - 2016-05-21 10:27:28 --> Loader Class Initialized
INFO - 2016-05-21 10:27:28 --> Helper loaded: url_helper
INFO - 2016-05-21 10:27:28 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:27:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:27:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:27:28 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:27:28 --> Helper loaded: form_helper
INFO - 2016-05-21 10:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:27:28 --> Form Validation Class Initialized
INFO - 2016-05-21 10:27:28 --> Controller Class Initialized
INFO - 2016-05-21 10:27:28 --> Model Class Initialized
INFO - 2016-05-21 10:27:28 --> Database Driver Class Initialized
INFO - 2016-05-21 10:27:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:27:28 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:27:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:27:28 --> Final output sent to browser
DEBUG - 2016-05-21 10:27:28 --> Total execution time: 0.0863
INFO - 2016-05-21 10:28:28 --> Config Class Initialized
INFO - 2016-05-21 10:28:28 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:28:28 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:28:28 --> Utf8 Class Initialized
INFO - 2016-05-21 10:28:28 --> URI Class Initialized
INFO - 2016-05-21 10:28:28 --> Router Class Initialized
INFO - 2016-05-21 10:28:28 --> Output Class Initialized
INFO - 2016-05-21 10:28:28 --> Security Class Initialized
DEBUG - 2016-05-21 10:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:28:28 --> Input Class Initialized
INFO - 2016-05-21 10:28:28 --> Language Class Initialized
INFO - 2016-05-21 10:28:28 --> Loader Class Initialized
INFO - 2016-05-21 10:28:28 --> Helper loaded: url_helper
INFO - 2016-05-21 10:28:28 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:28:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:28:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:28:28 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:28:28 --> Helper loaded: form_helper
INFO - 2016-05-21 10:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:28:28 --> Form Validation Class Initialized
INFO - 2016-05-21 10:28:28 --> Controller Class Initialized
INFO - 2016-05-21 10:28:28 --> Model Class Initialized
INFO - 2016-05-21 10:28:28 --> Database Driver Class Initialized
INFO - 2016-05-21 10:28:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:28:28 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:28:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:28:28 --> Final output sent to browser
DEBUG - 2016-05-21 10:28:28 --> Total execution time: 0.0747
INFO - 2016-05-21 10:29:28 --> Config Class Initialized
INFO - 2016-05-21 10:29:28 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:29:28 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:29:28 --> Utf8 Class Initialized
INFO - 2016-05-21 10:29:28 --> URI Class Initialized
INFO - 2016-05-21 10:29:28 --> Router Class Initialized
INFO - 2016-05-21 10:29:28 --> Output Class Initialized
INFO - 2016-05-21 10:29:28 --> Security Class Initialized
DEBUG - 2016-05-21 10:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:29:28 --> Input Class Initialized
INFO - 2016-05-21 10:29:28 --> Language Class Initialized
INFO - 2016-05-21 10:29:28 --> Loader Class Initialized
INFO - 2016-05-21 10:29:28 --> Helper loaded: url_helper
INFO - 2016-05-21 10:29:28 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:29:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:29:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:29:28 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:29:28 --> Helper loaded: form_helper
INFO - 2016-05-21 10:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:29:28 --> Form Validation Class Initialized
INFO - 2016-05-21 10:29:28 --> Controller Class Initialized
INFO - 2016-05-21 10:29:28 --> Model Class Initialized
INFO - 2016-05-21 10:29:28 --> Database Driver Class Initialized
INFO - 2016-05-21 10:29:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:29:28 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:29:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:29:28 --> Final output sent to browser
DEBUG - 2016-05-21 10:29:28 --> Total execution time: 0.0804
INFO - 2016-05-21 10:30:28 --> Config Class Initialized
INFO - 2016-05-21 10:30:28 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:30:28 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:30:28 --> Utf8 Class Initialized
INFO - 2016-05-21 10:30:28 --> URI Class Initialized
INFO - 2016-05-21 10:30:28 --> Router Class Initialized
INFO - 2016-05-21 10:30:28 --> Output Class Initialized
INFO - 2016-05-21 10:30:28 --> Security Class Initialized
DEBUG - 2016-05-21 10:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:30:28 --> Input Class Initialized
INFO - 2016-05-21 10:30:28 --> Language Class Initialized
INFO - 2016-05-21 10:30:28 --> Loader Class Initialized
INFO - 2016-05-21 10:30:28 --> Helper loaded: url_helper
INFO - 2016-05-21 10:30:28 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:30:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:30:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:30:28 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:30:28 --> Helper loaded: form_helper
INFO - 2016-05-21 10:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:30:28 --> Form Validation Class Initialized
INFO - 2016-05-21 10:30:28 --> Controller Class Initialized
INFO - 2016-05-21 10:30:28 --> Model Class Initialized
INFO - 2016-05-21 10:30:28 --> Database Driver Class Initialized
INFO - 2016-05-21 10:30:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:30:28 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:30:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:30:28 --> Final output sent to browser
DEBUG - 2016-05-21 10:30:28 --> Total execution time: 0.0859
INFO - 2016-05-21 10:31:28 --> Config Class Initialized
INFO - 2016-05-21 10:31:28 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:31:28 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:31:28 --> Utf8 Class Initialized
INFO - 2016-05-21 10:31:28 --> URI Class Initialized
INFO - 2016-05-21 10:31:28 --> Router Class Initialized
INFO - 2016-05-21 10:31:28 --> Output Class Initialized
INFO - 2016-05-21 10:31:28 --> Security Class Initialized
DEBUG - 2016-05-21 10:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:31:28 --> Input Class Initialized
INFO - 2016-05-21 10:31:28 --> Language Class Initialized
INFO - 2016-05-21 10:31:28 --> Loader Class Initialized
INFO - 2016-05-21 10:31:28 --> Helper loaded: url_helper
INFO - 2016-05-21 10:31:28 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:31:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:31:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:31:28 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:31:28 --> Helper loaded: form_helper
INFO - 2016-05-21 10:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:31:28 --> Form Validation Class Initialized
INFO - 2016-05-21 10:31:28 --> Controller Class Initialized
INFO - 2016-05-21 10:31:28 --> Model Class Initialized
INFO - 2016-05-21 10:31:28 --> Database Driver Class Initialized
INFO - 2016-05-21 10:31:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:31:28 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:31:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:31:28 --> Final output sent to browser
DEBUG - 2016-05-21 10:31:28 --> Total execution time: 0.0746
INFO - 2016-05-21 10:32:28 --> Config Class Initialized
INFO - 2016-05-21 10:32:28 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:32:28 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:32:28 --> Utf8 Class Initialized
INFO - 2016-05-21 10:32:28 --> URI Class Initialized
INFO - 2016-05-21 10:32:28 --> Router Class Initialized
INFO - 2016-05-21 10:32:28 --> Output Class Initialized
INFO - 2016-05-21 10:32:28 --> Security Class Initialized
DEBUG - 2016-05-21 10:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:32:28 --> Input Class Initialized
INFO - 2016-05-21 10:32:28 --> Language Class Initialized
INFO - 2016-05-21 10:32:28 --> Loader Class Initialized
INFO - 2016-05-21 10:32:28 --> Helper loaded: url_helper
INFO - 2016-05-21 10:32:28 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:32:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:32:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:32:28 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:32:28 --> Helper loaded: form_helper
INFO - 2016-05-21 10:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:32:28 --> Form Validation Class Initialized
INFO - 2016-05-21 10:32:28 --> Controller Class Initialized
INFO - 2016-05-21 10:32:28 --> Model Class Initialized
INFO - 2016-05-21 10:32:28 --> Database Driver Class Initialized
INFO - 2016-05-21 10:32:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:32:28 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:32:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:32:28 --> Final output sent to browser
DEBUG - 2016-05-21 10:32:28 --> Total execution time: 0.0884
INFO - 2016-05-21 10:33:11 --> Config Class Initialized
INFO - 2016-05-21 10:33:11 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:33:11 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:33:11 --> Utf8 Class Initialized
INFO - 2016-05-21 10:33:11 --> URI Class Initialized
INFO - 2016-05-21 10:33:11 --> Router Class Initialized
INFO - 2016-05-21 10:33:11 --> Output Class Initialized
INFO - 2016-05-21 10:33:11 --> Security Class Initialized
DEBUG - 2016-05-21 10:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:33:11 --> Input Class Initialized
INFO - 2016-05-21 10:33:11 --> Language Class Initialized
INFO - 2016-05-21 10:33:11 --> Loader Class Initialized
INFO - 2016-05-21 10:33:11 --> Helper loaded: url_helper
INFO - 2016-05-21 10:33:11 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:33:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:33:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:33:11 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:33:11 --> Helper loaded: form_helper
INFO - 2016-05-21 10:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:33:11 --> Form Validation Class Initialized
INFO - 2016-05-21 10:33:11 --> Controller Class Initialized
INFO - 2016-05-21 10:33:11 --> Model Class Initialized
INFO - 2016-05-21 10:33:11 --> Database Driver Class Initialized
INFO - 2016-05-21 10:33:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:33:11 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:33:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:33:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:33:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:33:11 --> Final output sent to browser
DEBUG - 2016-05-21 10:33:11 --> Total execution time: 0.0842
INFO - 2016-05-21 10:33:12 --> Config Class Initialized
INFO - 2016-05-21 10:33:12 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:33:12 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:33:12 --> Utf8 Class Initialized
INFO - 2016-05-21 10:33:12 --> URI Class Initialized
INFO - 2016-05-21 10:33:12 --> Router Class Initialized
INFO - 2016-05-21 10:33:12 --> Output Class Initialized
INFO - 2016-05-21 10:33:12 --> Security Class Initialized
DEBUG - 2016-05-21 10:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:33:12 --> Input Class Initialized
INFO - 2016-05-21 10:33:12 --> Language Class Initialized
INFO - 2016-05-21 10:33:12 --> Loader Class Initialized
INFO - 2016-05-21 10:33:12 --> Helper loaded: url_helper
INFO - 2016-05-21 10:33:12 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:33:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:33:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:33:12 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:33:12 --> Helper loaded: form_helper
INFO - 2016-05-21 10:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:33:12 --> Form Validation Class Initialized
INFO - 2016-05-21 10:33:12 --> Controller Class Initialized
INFO - 2016-05-21 10:33:12 --> Model Class Initialized
INFO - 2016-05-21 10:33:12 --> Database Driver Class Initialized
INFO - 2016-05-21 10:33:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:33:12 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:33:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:33:12 --> Final output sent to browser
DEBUG - 2016-05-21 10:33:12 --> Total execution time: 0.0821
INFO - 2016-05-21 10:33:13 --> Config Class Initialized
INFO - 2016-05-21 10:33:13 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:33:13 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:33:13 --> Utf8 Class Initialized
INFO - 2016-05-21 10:33:13 --> URI Class Initialized
INFO - 2016-05-21 10:33:13 --> Router Class Initialized
INFO - 2016-05-21 10:33:13 --> Output Class Initialized
INFO - 2016-05-21 10:33:13 --> Security Class Initialized
DEBUG - 2016-05-21 10:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:33:13 --> Input Class Initialized
INFO - 2016-05-21 10:33:13 --> Language Class Initialized
INFO - 2016-05-21 10:33:13 --> Loader Class Initialized
INFO - 2016-05-21 10:33:13 --> Helper loaded: url_helper
INFO - 2016-05-21 10:33:13 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:33:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:33:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:33:13 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:33:13 --> Helper loaded: form_helper
INFO - 2016-05-21 10:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:33:13 --> Form Validation Class Initialized
INFO - 2016-05-21 10:33:13 --> Controller Class Initialized
INFO - 2016-05-21 10:33:13 --> Model Class Initialized
INFO - 2016-05-21 10:33:13 --> Database Driver Class Initialized
INFO - 2016-05-21 10:33:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:33:13 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:33:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:33:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:33:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:33:13 --> Final output sent to browser
DEBUG - 2016-05-21 10:33:13 --> Total execution time: 0.0938
INFO - 2016-05-21 10:33:13 --> Config Class Initialized
INFO - 2016-05-21 10:33:13 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:33:13 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:33:13 --> Utf8 Class Initialized
INFO - 2016-05-21 10:33:13 --> URI Class Initialized
INFO - 2016-05-21 10:33:13 --> Router Class Initialized
INFO - 2016-05-21 10:33:13 --> Output Class Initialized
INFO - 2016-05-21 10:33:13 --> Security Class Initialized
DEBUG - 2016-05-21 10:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:33:13 --> Input Class Initialized
INFO - 2016-05-21 10:33:13 --> Language Class Initialized
INFO - 2016-05-21 10:33:13 --> Loader Class Initialized
INFO - 2016-05-21 10:33:13 --> Helper loaded: url_helper
INFO - 2016-05-21 10:33:13 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:33:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:33:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:33:13 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:33:13 --> Helper loaded: form_helper
INFO - 2016-05-21 10:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:33:13 --> Form Validation Class Initialized
INFO - 2016-05-21 10:33:13 --> Controller Class Initialized
INFO - 2016-05-21 10:33:13 --> Model Class Initialized
INFO - 2016-05-21 10:33:13 --> Database Driver Class Initialized
INFO - 2016-05-21 10:33:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:33:13 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:33:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:33:13 --> Final output sent to browser
DEBUG - 2016-05-21 10:33:13 --> Total execution time: 0.0947
INFO - 2016-05-21 10:33:19 --> Config Class Initialized
INFO - 2016-05-21 10:33:19 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:33:19 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:33:19 --> Utf8 Class Initialized
INFO - 2016-05-21 10:33:19 --> URI Class Initialized
INFO - 2016-05-21 10:33:19 --> Router Class Initialized
INFO - 2016-05-21 10:33:19 --> Output Class Initialized
INFO - 2016-05-21 10:33:19 --> Security Class Initialized
DEBUG - 2016-05-21 10:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:33:19 --> Input Class Initialized
INFO - 2016-05-21 10:33:19 --> Language Class Initialized
INFO - 2016-05-21 10:33:19 --> Loader Class Initialized
INFO - 2016-05-21 10:33:19 --> Helper loaded: url_helper
INFO - 2016-05-21 10:33:19 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:33:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:33:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:33:19 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:33:19 --> Helper loaded: form_helper
INFO - 2016-05-21 10:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:33:19 --> Form Validation Class Initialized
INFO - 2016-05-21 10:33:19 --> Controller Class Initialized
INFO - 2016-05-21 10:33:19 --> Model Class Initialized
INFO - 2016-05-21 10:33:19 --> Database Driver Class Initialized
INFO - 2016-05-21 10:33:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:33:19 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:33:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:33:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:33:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:33:19 --> Final output sent to browser
DEBUG - 2016-05-21 10:33:19 --> Total execution time: 0.0832
INFO - 2016-05-21 10:33:19 --> Config Class Initialized
INFO - 2016-05-21 10:33:19 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:33:19 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:33:19 --> Utf8 Class Initialized
INFO - 2016-05-21 10:33:19 --> URI Class Initialized
INFO - 2016-05-21 10:33:19 --> Router Class Initialized
INFO - 2016-05-21 10:33:19 --> Output Class Initialized
INFO - 2016-05-21 10:33:19 --> Security Class Initialized
DEBUG - 2016-05-21 10:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:33:19 --> Input Class Initialized
INFO - 2016-05-21 10:33:19 --> Language Class Initialized
INFO - 2016-05-21 10:33:19 --> Loader Class Initialized
INFO - 2016-05-21 10:33:19 --> Helper loaded: url_helper
INFO - 2016-05-21 10:33:19 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:33:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:33:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:33:19 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:33:19 --> Helper loaded: form_helper
INFO - 2016-05-21 10:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:33:19 --> Form Validation Class Initialized
INFO - 2016-05-21 10:33:19 --> Controller Class Initialized
INFO - 2016-05-21 10:33:19 --> Model Class Initialized
INFO - 2016-05-21 10:33:19 --> Database Driver Class Initialized
INFO - 2016-05-21 10:33:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:33:19 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:33:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:33:19 --> Final output sent to browser
DEBUG - 2016-05-21 10:33:19 --> Total execution time: 0.0839
INFO - 2016-05-21 10:34:19 --> Config Class Initialized
INFO - 2016-05-21 10:34:19 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:34:19 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:34:19 --> Utf8 Class Initialized
INFO - 2016-05-21 10:34:19 --> URI Class Initialized
INFO - 2016-05-21 10:34:19 --> Router Class Initialized
INFO - 2016-05-21 10:34:19 --> Output Class Initialized
INFO - 2016-05-21 10:34:19 --> Security Class Initialized
DEBUG - 2016-05-21 10:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:34:19 --> Input Class Initialized
INFO - 2016-05-21 10:34:19 --> Language Class Initialized
INFO - 2016-05-21 10:34:19 --> Loader Class Initialized
INFO - 2016-05-21 10:34:19 --> Helper loaded: url_helper
INFO - 2016-05-21 10:34:19 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:34:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:34:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:34:19 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:34:19 --> Helper loaded: form_helper
INFO - 2016-05-21 10:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:34:19 --> Form Validation Class Initialized
INFO - 2016-05-21 10:34:19 --> Controller Class Initialized
INFO - 2016-05-21 10:34:19 --> Model Class Initialized
INFO - 2016-05-21 10:34:19 --> Database Driver Class Initialized
INFO - 2016-05-21 10:34:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:34:19 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:34:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:34:22 --> Config Class Initialized
INFO - 2016-05-21 10:34:22 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:34:22 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:34:22 --> Utf8 Class Initialized
INFO - 2016-05-21 10:34:22 --> URI Class Initialized
INFO - 2016-05-21 10:34:22 --> Router Class Initialized
INFO - 2016-05-21 10:34:22 --> Output Class Initialized
INFO - 2016-05-21 10:34:22 --> Security Class Initialized
DEBUG - 2016-05-21 10:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:34:22 --> Input Class Initialized
INFO - 2016-05-21 10:34:22 --> Language Class Initialized
INFO - 2016-05-21 10:34:22 --> Loader Class Initialized
INFO - 2016-05-21 10:34:22 --> Helper loaded: url_helper
INFO - 2016-05-21 10:34:22 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:34:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:34:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:34:22 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:34:22 --> Helper loaded: form_helper
INFO - 2016-05-21 10:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:34:22 --> Form Validation Class Initialized
INFO - 2016-05-21 10:34:22 --> Controller Class Initialized
INFO - 2016-05-21 10:34:22 --> Model Class Initialized
INFO - 2016-05-21 10:34:22 --> Database Driver Class Initialized
INFO - 2016-05-21 10:34:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-21 10:34:22 --> Final output sent to browser
DEBUG - 2016-05-21 10:34:22 --> Total execution time: 0.0670
INFO - 2016-05-21 10:35:19 --> Config Class Initialized
INFO - 2016-05-21 10:35:19 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:35:19 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:35:19 --> Utf8 Class Initialized
INFO - 2016-05-21 10:35:19 --> URI Class Initialized
INFO - 2016-05-21 10:35:19 --> Router Class Initialized
INFO - 2016-05-21 10:35:19 --> Output Class Initialized
INFO - 2016-05-21 10:35:19 --> Security Class Initialized
DEBUG - 2016-05-21 10:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:35:19 --> Input Class Initialized
INFO - 2016-05-21 10:35:19 --> Language Class Initialized
INFO - 2016-05-21 10:35:19 --> Loader Class Initialized
INFO - 2016-05-21 10:35:19 --> Helper loaded: url_helper
INFO - 2016-05-21 10:35:19 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:35:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:35:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:35:19 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:35:19 --> Helper loaded: form_helper
INFO - 2016-05-21 10:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:35:19 --> Form Validation Class Initialized
INFO - 2016-05-21 10:35:19 --> Controller Class Initialized
INFO - 2016-05-21 10:35:19 --> Model Class Initialized
INFO - 2016-05-21 10:35:19 --> Database Driver Class Initialized
INFO - 2016-05-21 10:35:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:35:19 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:35:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:35:19 --> Config Class Initialized
INFO - 2016-05-21 10:35:19 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:35:19 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:35:19 --> Utf8 Class Initialized
INFO - 2016-05-21 10:35:19 --> URI Class Initialized
INFO - 2016-05-21 10:35:19 --> Router Class Initialized
INFO - 2016-05-21 10:35:19 --> Output Class Initialized
INFO - 2016-05-21 10:35:19 --> Security Class Initialized
DEBUG - 2016-05-21 10:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:35:19 --> Input Class Initialized
INFO - 2016-05-21 10:35:19 --> Language Class Initialized
INFO - 2016-05-21 10:35:19 --> Loader Class Initialized
INFO - 2016-05-21 10:35:19 --> Helper loaded: url_helper
INFO - 2016-05-21 10:35:19 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:35:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:35:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:35:19 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:35:19 --> Helper loaded: form_helper
INFO - 2016-05-21 10:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:35:19 --> Form Validation Class Initialized
INFO - 2016-05-21 10:35:19 --> Controller Class Initialized
INFO - 2016-05-21 10:35:19 --> Model Class Initialized
INFO - 2016-05-21 10:35:19 --> Database Driver Class Initialized
INFO - 2016-05-21 10:35:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-21 10:35:19 --> Final output sent to browser
DEBUG - 2016-05-21 10:35:19 --> Total execution time: 0.0613
INFO - 2016-05-21 10:35:23 --> Config Class Initialized
INFO - 2016-05-21 10:35:23 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:35:23 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:35:23 --> Utf8 Class Initialized
INFO - 2016-05-21 10:35:23 --> URI Class Initialized
INFO - 2016-05-21 10:35:23 --> Router Class Initialized
INFO - 2016-05-21 10:35:23 --> Output Class Initialized
INFO - 2016-05-21 10:35:23 --> Security Class Initialized
DEBUG - 2016-05-21 10:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:35:23 --> Input Class Initialized
INFO - 2016-05-21 10:35:23 --> Language Class Initialized
INFO - 2016-05-21 10:35:23 --> Loader Class Initialized
INFO - 2016-05-21 10:35:23 --> Helper loaded: url_helper
INFO - 2016-05-21 10:35:23 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:35:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:35:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:35:23 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:35:23 --> Helper loaded: form_helper
INFO - 2016-05-21 10:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:35:23 --> Form Validation Class Initialized
INFO - 2016-05-21 10:35:23 --> Controller Class Initialized
INFO - 2016-05-21 10:35:23 --> Model Class Initialized
INFO - 2016-05-21 10:35:23 --> Database Driver Class Initialized
INFO - 2016-05-21 10:35:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:35:23 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:35:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:35:23 --> Config Class Initialized
INFO - 2016-05-21 10:35:23 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:35:23 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:35:23 --> Utf8 Class Initialized
INFO - 2016-05-21 10:35:23 --> URI Class Initialized
INFO - 2016-05-21 10:35:23 --> Router Class Initialized
INFO - 2016-05-21 10:35:23 --> Output Class Initialized
INFO - 2016-05-21 10:35:23 --> Security Class Initialized
DEBUG - 2016-05-21 10:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:35:23 --> Input Class Initialized
INFO - 2016-05-21 10:35:23 --> Language Class Initialized
INFO - 2016-05-21 10:35:23 --> Loader Class Initialized
INFO - 2016-05-21 10:35:23 --> Helper loaded: url_helper
INFO - 2016-05-21 10:35:23 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:35:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:35:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:35:23 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:35:23 --> Helper loaded: form_helper
INFO - 2016-05-21 10:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:35:23 --> Form Validation Class Initialized
INFO - 2016-05-21 10:35:23 --> Controller Class Initialized
INFO - 2016-05-21 10:35:23 --> Model Class Initialized
INFO - 2016-05-21 10:35:23 --> Database Driver Class Initialized
INFO - 2016-05-21 10:35:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-21 10:35:23 --> Final output sent to browser
DEBUG - 2016-05-21 10:35:23 --> Total execution time: 0.0671
INFO - 2016-05-21 10:35:26 --> Config Class Initialized
INFO - 2016-05-21 10:35:26 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:35:26 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:35:26 --> Utf8 Class Initialized
INFO - 2016-05-21 10:35:26 --> URI Class Initialized
INFO - 2016-05-21 10:35:26 --> Router Class Initialized
INFO - 2016-05-21 10:35:26 --> Output Class Initialized
INFO - 2016-05-21 10:35:26 --> Security Class Initialized
DEBUG - 2016-05-21 10:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:35:26 --> Input Class Initialized
INFO - 2016-05-21 10:35:26 --> Language Class Initialized
INFO - 2016-05-21 10:35:26 --> Loader Class Initialized
INFO - 2016-05-21 10:35:26 --> Helper loaded: url_helper
INFO - 2016-05-21 10:35:26 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:35:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:35:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:35:26 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:35:26 --> Helper loaded: form_helper
INFO - 2016-05-21 10:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:35:26 --> Form Validation Class Initialized
INFO - 2016-05-21 10:35:26 --> Controller Class Initialized
INFO - 2016-05-21 10:35:26 --> Model Class Initialized
INFO - 2016-05-21 10:35:26 --> Database Driver Class Initialized
INFO - 2016-05-21 10:35:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-21 10:35:26 --> Final output sent to browser
DEBUG - 2016-05-21 10:35:26 --> Total execution time: 0.0777
INFO - 2016-05-21 10:35:35 --> Config Class Initialized
INFO - 2016-05-21 10:35:35 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:35:35 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:35:35 --> Utf8 Class Initialized
INFO - 2016-05-21 10:35:35 --> URI Class Initialized
INFO - 2016-05-21 10:35:35 --> Router Class Initialized
INFO - 2016-05-21 10:35:35 --> Output Class Initialized
INFO - 2016-05-21 10:35:35 --> Security Class Initialized
DEBUG - 2016-05-21 10:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:35:35 --> Input Class Initialized
INFO - 2016-05-21 10:35:35 --> Language Class Initialized
INFO - 2016-05-21 10:35:35 --> Loader Class Initialized
INFO - 2016-05-21 10:35:35 --> Helper loaded: url_helper
INFO - 2016-05-21 10:35:35 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:35:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:35:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:35:35 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:35:35 --> Helper loaded: form_helper
INFO - 2016-05-21 10:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:35:35 --> Form Validation Class Initialized
INFO - 2016-05-21 10:35:35 --> Controller Class Initialized
INFO - 2016-05-21 10:35:35 --> Model Class Initialized
INFO - 2016-05-21 10:35:35 --> Database Driver Class Initialized
INFO - 2016-05-21 10:35:35 --> Config Class Initialized
INFO - 2016-05-21 10:35:35 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:35:35 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:35:35 --> Utf8 Class Initialized
INFO - 2016-05-21 10:35:35 --> URI Class Initialized
INFO - 2016-05-21 10:35:35 --> Router Class Initialized
INFO - 2016-05-21 10:35:35 --> Output Class Initialized
INFO - 2016-05-21 10:35:35 --> Security Class Initialized
DEBUG - 2016-05-21 10:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:35:35 --> Input Class Initialized
INFO - 2016-05-21 10:35:35 --> Language Class Initialized
INFO - 2016-05-21 10:35:35 --> Loader Class Initialized
INFO - 2016-05-21 10:35:35 --> Helper loaded: url_helper
INFO - 2016-05-21 10:35:35 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:35:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:35:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:35:35 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:35:35 --> Helper loaded: form_helper
INFO - 2016-05-21 10:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:35:35 --> Form Validation Class Initialized
INFO - 2016-05-21 10:35:35 --> Controller Class Initialized
INFO - 2016-05-21 10:35:35 --> Model Class Initialized
INFO - 2016-05-21 10:35:35 --> Database Driver Class Initialized
INFO - 2016-05-21 10:35:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:35:35 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:35:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:35:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:35:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:35:35 --> Final output sent to browser
DEBUG - 2016-05-21 10:35:35 --> Total execution time: 0.0807
INFO - 2016-05-21 10:35:35 --> Config Class Initialized
INFO - 2016-05-21 10:35:35 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:35:35 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:35:35 --> Utf8 Class Initialized
INFO - 2016-05-21 10:35:35 --> URI Class Initialized
INFO - 2016-05-21 10:35:35 --> Router Class Initialized
INFO - 2016-05-21 10:35:36 --> Output Class Initialized
INFO - 2016-05-21 10:35:36 --> Security Class Initialized
DEBUG - 2016-05-21 10:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:35:36 --> Input Class Initialized
INFO - 2016-05-21 10:35:36 --> Language Class Initialized
INFO - 2016-05-21 10:35:36 --> Loader Class Initialized
INFO - 2016-05-21 10:35:36 --> Helper loaded: url_helper
INFO - 2016-05-21 10:35:36 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:35:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:35:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:35:36 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:35:36 --> Helper loaded: form_helper
INFO - 2016-05-21 10:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:35:36 --> Form Validation Class Initialized
INFO - 2016-05-21 10:35:36 --> Controller Class Initialized
INFO - 2016-05-21 10:35:36 --> Model Class Initialized
INFO - 2016-05-21 10:35:36 --> Database Driver Class Initialized
INFO - 2016-05-21 10:35:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:35:36 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:35:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:35:36 --> Final output sent to browser
DEBUG - 2016-05-21 10:35:36 --> Total execution time: 0.0874
INFO - 2016-05-21 10:36:36 --> Config Class Initialized
INFO - 2016-05-21 10:36:36 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:36:36 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:36:36 --> Utf8 Class Initialized
INFO - 2016-05-21 10:36:36 --> URI Class Initialized
INFO - 2016-05-21 10:36:36 --> Router Class Initialized
INFO - 2016-05-21 10:36:36 --> Output Class Initialized
INFO - 2016-05-21 10:36:36 --> Security Class Initialized
DEBUG - 2016-05-21 10:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:36:36 --> Input Class Initialized
INFO - 2016-05-21 10:36:36 --> Language Class Initialized
INFO - 2016-05-21 10:36:36 --> Loader Class Initialized
INFO - 2016-05-21 10:36:36 --> Helper loaded: url_helper
INFO - 2016-05-21 10:36:36 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:36:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:36:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:36:36 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:36:36 --> Helper loaded: form_helper
INFO - 2016-05-21 10:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:36:36 --> Form Validation Class Initialized
INFO - 2016-05-21 10:36:36 --> Controller Class Initialized
INFO - 2016-05-21 10:36:36 --> Model Class Initialized
INFO - 2016-05-21 10:36:36 --> Database Driver Class Initialized
INFO - 2016-05-21 10:36:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:36:36 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:36:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:36:36 --> Final output sent to browser
DEBUG - 2016-05-21 10:36:36 --> Total execution time: 0.1150
INFO - 2016-05-21 10:37:36 --> Config Class Initialized
INFO - 2016-05-21 10:37:36 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:37:36 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:37:36 --> Utf8 Class Initialized
INFO - 2016-05-21 10:37:36 --> URI Class Initialized
INFO - 2016-05-21 10:37:36 --> Router Class Initialized
INFO - 2016-05-21 10:37:36 --> Output Class Initialized
INFO - 2016-05-21 10:37:36 --> Security Class Initialized
DEBUG - 2016-05-21 10:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:37:36 --> Input Class Initialized
INFO - 2016-05-21 10:37:36 --> Language Class Initialized
INFO - 2016-05-21 10:37:36 --> Loader Class Initialized
INFO - 2016-05-21 10:37:36 --> Helper loaded: url_helper
INFO - 2016-05-21 10:37:36 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:37:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:37:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:37:36 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:37:36 --> Helper loaded: form_helper
INFO - 2016-05-21 10:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:37:36 --> Form Validation Class Initialized
INFO - 2016-05-21 10:37:36 --> Controller Class Initialized
INFO - 2016-05-21 10:37:36 --> Model Class Initialized
INFO - 2016-05-21 10:37:36 --> Database Driver Class Initialized
INFO - 2016-05-21 10:37:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:37:36 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:37:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:37:36 --> Final output sent to browser
DEBUG - 2016-05-21 10:37:36 --> Total execution time: 0.1192
INFO - 2016-05-21 10:38:36 --> Config Class Initialized
INFO - 2016-05-21 10:38:36 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:38:36 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:38:36 --> Utf8 Class Initialized
INFO - 2016-05-21 10:38:36 --> URI Class Initialized
INFO - 2016-05-21 10:38:36 --> Router Class Initialized
INFO - 2016-05-21 10:38:36 --> Output Class Initialized
INFO - 2016-05-21 10:38:36 --> Security Class Initialized
DEBUG - 2016-05-21 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:38:36 --> Input Class Initialized
INFO - 2016-05-21 10:38:36 --> Language Class Initialized
INFO - 2016-05-21 10:38:36 --> Loader Class Initialized
INFO - 2016-05-21 10:38:36 --> Helper loaded: url_helper
INFO - 2016-05-21 10:38:36 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:38:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:38:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:38:36 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:38:36 --> Helper loaded: form_helper
INFO - 2016-05-21 10:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:38:36 --> Form Validation Class Initialized
INFO - 2016-05-21 10:38:36 --> Controller Class Initialized
INFO - 2016-05-21 10:38:36 --> Model Class Initialized
INFO - 2016-05-21 10:38:36 --> Database Driver Class Initialized
INFO - 2016-05-21 10:38:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:38:36 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:38:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:38:36 --> Final output sent to browser
DEBUG - 2016-05-21 10:38:36 --> Total execution time: 0.0697
INFO - 2016-05-21 10:39:18 --> Config Class Initialized
INFO - 2016-05-21 10:39:18 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:39:18 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:39:18 --> Utf8 Class Initialized
INFO - 2016-05-21 10:39:18 --> URI Class Initialized
INFO - 2016-05-21 10:39:18 --> Router Class Initialized
INFO - 2016-05-21 10:39:18 --> Output Class Initialized
INFO - 2016-05-21 10:39:18 --> Security Class Initialized
DEBUG - 2016-05-21 10:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:39:18 --> Input Class Initialized
INFO - 2016-05-21 10:39:18 --> Language Class Initialized
INFO - 2016-05-21 10:39:18 --> Loader Class Initialized
INFO - 2016-05-21 10:39:18 --> Helper loaded: url_helper
INFO - 2016-05-21 10:39:18 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:39:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:39:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:39:18 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:39:18 --> Helper loaded: form_helper
INFO - 2016-05-21 10:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:39:18 --> Form Validation Class Initialized
INFO - 2016-05-21 10:39:18 --> Controller Class Initialized
INFO - 2016-05-21 10:39:18 --> Model Class Initialized
INFO - 2016-05-21 10:39:18 --> Database Driver Class Initialized
INFO - 2016-05-21 10:39:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:39:18 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:39:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:39:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 10:39:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 10:39:18 --> Final output sent to browser
DEBUG - 2016-05-21 10:39:18 --> Total execution time: 0.0886
INFO - 2016-05-21 10:39:18 --> Config Class Initialized
INFO - 2016-05-21 10:39:18 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:39:18 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:39:18 --> Utf8 Class Initialized
INFO - 2016-05-21 10:39:18 --> URI Class Initialized
INFO - 2016-05-21 10:39:18 --> Router Class Initialized
INFO - 2016-05-21 10:39:18 --> Output Class Initialized
INFO - 2016-05-21 10:39:18 --> Security Class Initialized
DEBUG - 2016-05-21 10:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:39:18 --> Input Class Initialized
INFO - 2016-05-21 10:39:18 --> Language Class Initialized
INFO - 2016-05-21 10:39:18 --> Loader Class Initialized
INFO - 2016-05-21 10:39:18 --> Helper loaded: url_helper
INFO - 2016-05-21 10:39:18 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:39:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:39:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:39:18 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:39:18 --> Helper loaded: form_helper
INFO - 2016-05-21 10:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:39:18 --> Form Validation Class Initialized
INFO - 2016-05-21 10:39:19 --> Controller Class Initialized
INFO - 2016-05-21 10:39:19 --> Model Class Initialized
INFO - 2016-05-21 10:39:19 --> Database Driver Class Initialized
INFO - 2016-05-21 10:39:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:39:19 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:39:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:39:19 --> Final output sent to browser
DEBUG - 2016-05-21 10:39:19 --> Total execution time: 0.0885
INFO - 2016-05-21 10:39:22 --> Config Class Initialized
INFO - 2016-05-21 10:39:22 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:39:22 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:39:22 --> Utf8 Class Initialized
INFO - 2016-05-21 10:39:22 --> URI Class Initialized
INFO - 2016-05-21 10:39:22 --> Router Class Initialized
INFO - 2016-05-21 10:39:22 --> Output Class Initialized
INFO - 2016-05-21 10:39:22 --> Security Class Initialized
DEBUG - 2016-05-21 10:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:39:22 --> Input Class Initialized
INFO - 2016-05-21 10:39:22 --> Language Class Initialized
INFO - 2016-05-21 10:39:22 --> Loader Class Initialized
INFO - 2016-05-21 10:39:22 --> Helper loaded: url_helper
INFO - 2016-05-21 10:39:22 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:39:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:39:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:39:22 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:39:22 --> Helper loaded: form_helper
INFO - 2016-05-21 10:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:39:22 --> Form Validation Class Initialized
INFO - 2016-05-21 10:39:22 --> Controller Class Initialized
INFO - 2016-05-21 10:39:22 --> Model Class Initialized
INFO - 2016-05-21 10:39:22 --> Database Driver Class Initialized
INFO - 2016-05-21 10:39:22 --> Final output sent to browser
DEBUG - 2016-05-21 10:39:22 --> Total execution time: 0.1998
INFO - 2016-05-21 10:39:26 --> Config Class Initialized
INFO - 2016-05-21 10:39:26 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:39:26 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:39:26 --> Utf8 Class Initialized
INFO - 2016-05-21 10:39:26 --> URI Class Initialized
INFO - 2016-05-21 10:39:26 --> Router Class Initialized
INFO - 2016-05-21 10:39:26 --> Output Class Initialized
INFO - 2016-05-21 10:39:26 --> Security Class Initialized
DEBUG - 2016-05-21 10:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:39:26 --> Input Class Initialized
INFO - 2016-05-21 10:39:26 --> Language Class Initialized
INFO - 2016-05-21 10:39:26 --> Loader Class Initialized
INFO - 2016-05-21 10:39:26 --> Helper loaded: url_helper
INFO - 2016-05-21 10:39:26 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:39:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:39:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:39:26 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:39:26 --> Helper loaded: form_helper
INFO - 2016-05-21 10:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:39:26 --> Form Validation Class Initialized
INFO - 2016-05-21 10:39:26 --> Controller Class Initialized
INFO - 2016-05-21 10:39:26 --> Model Class Initialized
INFO - 2016-05-21 10:39:26 --> Database Driver Class Initialized
INFO - 2016-05-21 10:39:26 --> Final output sent to browser
DEBUG - 2016-05-21 10:39:26 --> Total execution time: 0.1231
INFO - 2016-05-21 10:40:19 --> Config Class Initialized
INFO - 2016-05-21 10:40:19 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:40:19 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:40:19 --> Utf8 Class Initialized
INFO - 2016-05-21 10:40:19 --> URI Class Initialized
INFO - 2016-05-21 10:40:19 --> Router Class Initialized
INFO - 2016-05-21 10:40:19 --> Output Class Initialized
INFO - 2016-05-21 10:40:19 --> Security Class Initialized
DEBUG - 2016-05-21 10:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:40:19 --> Input Class Initialized
INFO - 2016-05-21 10:40:19 --> Language Class Initialized
INFO - 2016-05-21 10:40:19 --> Loader Class Initialized
INFO - 2016-05-21 10:40:19 --> Helper loaded: url_helper
INFO - 2016-05-21 10:40:19 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:40:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:40:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:40:19 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:40:19 --> Helper loaded: form_helper
INFO - 2016-05-21 10:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:40:19 --> Form Validation Class Initialized
INFO - 2016-05-21 10:40:19 --> Controller Class Initialized
INFO - 2016-05-21 10:40:19 --> Model Class Initialized
INFO - 2016-05-21 10:40:19 --> Database Driver Class Initialized
INFO - 2016-05-21 10:40:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:40:19 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:40:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:40:19 --> Final output sent to browser
DEBUG - 2016-05-21 10:40:19 --> Total execution time: 0.1408
INFO - 2016-05-21 10:41:19 --> Config Class Initialized
INFO - 2016-05-21 10:41:19 --> Hooks Class Initialized
DEBUG - 2016-05-21 10:41:19 --> UTF-8 Support Enabled
INFO - 2016-05-21 10:41:19 --> Utf8 Class Initialized
INFO - 2016-05-21 10:41:19 --> URI Class Initialized
INFO - 2016-05-21 10:41:19 --> Router Class Initialized
INFO - 2016-05-21 10:41:19 --> Output Class Initialized
INFO - 2016-05-21 10:41:19 --> Security Class Initialized
DEBUG - 2016-05-21 10:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 10:41:19 --> Input Class Initialized
INFO - 2016-05-21 10:41:19 --> Language Class Initialized
INFO - 2016-05-21 10:41:19 --> Loader Class Initialized
INFO - 2016-05-21 10:41:19 --> Helper loaded: url_helper
INFO - 2016-05-21 10:41:19 --> Helper loaded: sesion_helper
INFO - 2016-05-21 10:41:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 10:41:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 10:41:19 --> Helper loaded: redondear_helper
INFO - 2016-05-21 10:41:19 --> Helper loaded: form_helper
INFO - 2016-05-21 10:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 10:41:19 --> Form Validation Class Initialized
INFO - 2016-05-21 10:41:19 --> Controller Class Initialized
INFO - 2016-05-21 10:41:19 --> Model Class Initialized
INFO - 2016-05-21 10:41:19 --> Database Driver Class Initialized
INFO - 2016-05-21 10:41:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 10:41:19 --> Pagination Class Initialized
DEBUG - 2016-05-21 10:41:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 10:41:19 --> Final output sent to browser
DEBUG - 2016-05-21 10:41:19 --> Total execution time: 0.0792
INFO - 2016-05-21 11:25:17 --> Config Class Initialized
INFO - 2016-05-21 11:25:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:25:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:25:17 --> Utf8 Class Initialized
INFO - 2016-05-21 11:25:17 --> URI Class Initialized
INFO - 2016-05-21 11:25:17 --> Router Class Initialized
INFO - 2016-05-21 11:25:17 --> Output Class Initialized
INFO - 2016-05-21 11:25:17 --> Security Class Initialized
DEBUG - 2016-05-21 11:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:25:18 --> Input Class Initialized
INFO - 2016-05-21 11:25:18 --> Language Class Initialized
INFO - 2016-05-21 11:25:18 --> Loader Class Initialized
INFO - 2016-05-21 11:25:18 --> Helper loaded: url_helper
INFO - 2016-05-21 11:25:18 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:25:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:25:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:25:18 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:25:18 --> Helper loaded: form_helper
INFO - 2016-05-21 11:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:25:18 --> Form Validation Class Initialized
INFO - 2016-05-21 11:25:18 --> Controller Class Initialized
INFO - 2016-05-21 11:25:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-21 11:25:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:25:18 --> Final output sent to browser
DEBUG - 2016-05-21 11:25:18 --> Total execution time: 0.5345
INFO - 2016-05-21 11:25:18 --> Config Class Initialized
INFO - 2016-05-21 11:25:18 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:25:18 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:25:18 --> Utf8 Class Initialized
INFO - 2016-05-21 11:25:18 --> URI Class Initialized
INFO - 2016-05-21 11:25:18 --> Router Class Initialized
INFO - 2016-05-21 11:25:18 --> Output Class Initialized
INFO - 2016-05-21 11:25:18 --> Security Class Initialized
DEBUG - 2016-05-21 11:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:25:18 --> Input Class Initialized
INFO - 2016-05-21 11:25:18 --> Language Class Initialized
INFO - 2016-05-21 11:25:18 --> Loader Class Initialized
INFO - 2016-05-21 11:25:18 --> Helper loaded: url_helper
INFO - 2016-05-21 11:25:18 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:25:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:25:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:25:18 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:25:18 --> Helper loaded: form_helper
INFO - 2016-05-21 11:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:25:18 --> Form Validation Class Initialized
INFO - 2016-05-21 11:25:18 --> Controller Class Initialized
INFO - 2016-05-21 11:25:18 --> Model Class Initialized
INFO - 2016-05-21 11:25:18 --> Database Driver Class Initialized
INFO - 2016-05-21 11:25:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:25:19 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:25:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:25:19 --> Final output sent to browser
DEBUG - 2016-05-21 11:25:19 --> Total execution time: 0.9235
INFO - 2016-05-21 11:25:23 --> Config Class Initialized
INFO - 2016-05-21 11:25:23 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:25:23 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:25:23 --> Utf8 Class Initialized
INFO - 2016-05-21 11:25:23 --> URI Class Initialized
INFO - 2016-05-21 11:25:23 --> Router Class Initialized
INFO - 2016-05-21 11:25:23 --> Output Class Initialized
INFO - 2016-05-21 11:25:23 --> Security Class Initialized
DEBUG - 2016-05-21 11:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:25:23 --> Input Class Initialized
INFO - 2016-05-21 11:25:23 --> Language Class Initialized
INFO - 2016-05-21 11:25:23 --> Loader Class Initialized
INFO - 2016-05-21 11:25:23 --> Helper loaded: url_helper
INFO - 2016-05-21 11:25:23 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:25:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:25:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:25:23 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:25:23 --> Helper loaded: form_helper
INFO - 2016-05-21 11:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:25:23 --> Form Validation Class Initialized
INFO - 2016-05-21 11:25:23 --> Controller Class Initialized
INFO - 2016-05-21 11:25:23 --> Model Class Initialized
INFO - 2016-05-21 11:25:23 --> Database Driver Class Initialized
INFO - 2016-05-21 11:25:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:25:23 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:25:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:25:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 11:25:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:25:23 --> Final output sent to browser
DEBUG - 2016-05-21 11:25:23 --> Total execution time: 0.2351
INFO - 2016-05-21 11:25:24 --> Config Class Initialized
INFO - 2016-05-21 11:25:24 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:25:24 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:25:24 --> Utf8 Class Initialized
INFO - 2016-05-21 11:25:24 --> URI Class Initialized
INFO - 2016-05-21 11:25:24 --> Router Class Initialized
INFO - 2016-05-21 11:25:24 --> Output Class Initialized
INFO - 2016-05-21 11:25:24 --> Security Class Initialized
DEBUG - 2016-05-21 11:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:25:24 --> Input Class Initialized
INFO - 2016-05-21 11:25:24 --> Language Class Initialized
INFO - 2016-05-21 11:25:24 --> Loader Class Initialized
INFO - 2016-05-21 11:25:24 --> Helper loaded: url_helper
INFO - 2016-05-21 11:25:24 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:25:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:25:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:25:24 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:25:24 --> Helper loaded: form_helper
INFO - 2016-05-21 11:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:25:24 --> Form Validation Class Initialized
INFO - 2016-05-21 11:25:24 --> Controller Class Initialized
INFO - 2016-05-21 11:25:24 --> Model Class Initialized
INFO - 2016-05-21 11:25:24 --> Database Driver Class Initialized
INFO - 2016-05-21 11:25:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:25:24 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:25:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:25:24 --> Final output sent to browser
DEBUG - 2016-05-21 11:25:24 --> Total execution time: 0.0903
INFO - 2016-05-21 11:26:24 --> Config Class Initialized
INFO - 2016-05-21 11:26:24 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:26:24 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:26:24 --> Utf8 Class Initialized
INFO - 2016-05-21 11:26:24 --> URI Class Initialized
INFO - 2016-05-21 11:26:24 --> Router Class Initialized
INFO - 2016-05-21 11:26:24 --> Output Class Initialized
INFO - 2016-05-21 11:26:24 --> Security Class Initialized
DEBUG - 2016-05-21 11:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:26:24 --> Input Class Initialized
INFO - 2016-05-21 11:26:24 --> Language Class Initialized
INFO - 2016-05-21 11:26:24 --> Loader Class Initialized
INFO - 2016-05-21 11:26:24 --> Helper loaded: url_helper
INFO - 2016-05-21 11:26:24 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:26:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:26:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:26:24 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:26:24 --> Helper loaded: form_helper
INFO - 2016-05-21 11:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:26:24 --> Form Validation Class Initialized
INFO - 2016-05-21 11:26:24 --> Controller Class Initialized
INFO - 2016-05-21 11:26:24 --> Model Class Initialized
INFO - 2016-05-21 11:26:24 --> Database Driver Class Initialized
INFO - 2016-05-21 11:26:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:26:24 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:26:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:26:24 --> Final output sent to browser
DEBUG - 2016-05-21 11:26:24 --> Total execution time: 0.1036
INFO - 2016-05-21 11:27:24 --> Config Class Initialized
INFO - 2016-05-21 11:27:24 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:27:24 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:27:24 --> Utf8 Class Initialized
INFO - 2016-05-21 11:27:24 --> URI Class Initialized
INFO - 2016-05-21 11:27:24 --> Router Class Initialized
INFO - 2016-05-21 11:27:24 --> Output Class Initialized
INFO - 2016-05-21 11:27:24 --> Security Class Initialized
DEBUG - 2016-05-21 11:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:27:24 --> Input Class Initialized
INFO - 2016-05-21 11:27:24 --> Language Class Initialized
INFO - 2016-05-21 11:27:24 --> Loader Class Initialized
INFO - 2016-05-21 11:27:24 --> Helper loaded: url_helper
INFO - 2016-05-21 11:27:24 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:27:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:27:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:27:24 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:27:24 --> Helper loaded: form_helper
INFO - 2016-05-21 11:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:27:24 --> Form Validation Class Initialized
INFO - 2016-05-21 11:27:24 --> Controller Class Initialized
INFO - 2016-05-21 11:27:24 --> Model Class Initialized
INFO - 2016-05-21 11:27:24 --> Database Driver Class Initialized
INFO - 2016-05-21 11:27:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:27:24 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:27:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:27:24 --> Final output sent to browser
DEBUG - 2016-05-21 11:27:24 --> Total execution time: 0.0748
INFO - 2016-05-21 11:27:39 --> Config Class Initialized
INFO - 2016-05-21 11:27:39 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:27:39 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:27:39 --> Utf8 Class Initialized
INFO - 2016-05-21 11:27:39 --> URI Class Initialized
INFO - 2016-05-21 11:27:39 --> Router Class Initialized
INFO - 2016-05-21 11:27:39 --> Output Class Initialized
INFO - 2016-05-21 11:27:39 --> Security Class Initialized
DEBUG - 2016-05-21 11:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:27:39 --> Input Class Initialized
INFO - 2016-05-21 11:27:39 --> Language Class Initialized
INFO - 2016-05-21 11:27:39 --> Loader Class Initialized
INFO - 2016-05-21 11:27:39 --> Helper loaded: url_helper
INFO - 2016-05-21 11:27:39 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:27:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:27:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:27:39 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:27:39 --> Helper loaded: form_helper
INFO - 2016-05-21 11:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:27:39 --> Form Validation Class Initialized
INFO - 2016-05-21 11:27:39 --> Controller Class Initialized
INFO - 2016-05-21 11:27:39 --> Model Class Initialized
INFO - 2016-05-21 11:27:40 --> Database Driver Class Initialized
INFO - 2016-05-21 11:27:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:27:40 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:27:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:27:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 11:27:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:27:40 --> Final output sent to browser
DEBUG - 2016-05-21 11:27:40 --> Total execution time: 0.1400
INFO - 2016-05-21 11:27:40 --> Config Class Initialized
INFO - 2016-05-21 11:27:40 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:27:40 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:27:40 --> Utf8 Class Initialized
INFO - 2016-05-21 11:27:40 --> URI Class Initialized
INFO - 2016-05-21 11:27:40 --> Router Class Initialized
INFO - 2016-05-21 11:27:40 --> Output Class Initialized
INFO - 2016-05-21 11:27:40 --> Security Class Initialized
DEBUG - 2016-05-21 11:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:27:40 --> Input Class Initialized
INFO - 2016-05-21 11:27:40 --> Language Class Initialized
INFO - 2016-05-21 11:27:40 --> Loader Class Initialized
INFO - 2016-05-21 11:27:40 --> Helper loaded: url_helper
INFO - 2016-05-21 11:27:40 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:27:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:27:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:27:40 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:27:40 --> Helper loaded: form_helper
INFO - 2016-05-21 11:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:27:40 --> Form Validation Class Initialized
INFO - 2016-05-21 11:27:40 --> Controller Class Initialized
INFO - 2016-05-21 11:27:40 --> Model Class Initialized
INFO - 2016-05-21 11:27:40 --> Database Driver Class Initialized
INFO - 2016-05-21 11:27:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:27:40 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:27:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:27:40 --> Final output sent to browser
DEBUG - 2016-05-21 11:27:40 --> Total execution time: 0.1193
INFO - 2016-05-21 11:28:40 --> Config Class Initialized
INFO - 2016-05-21 11:28:40 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:28:40 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:28:40 --> Utf8 Class Initialized
INFO - 2016-05-21 11:28:40 --> URI Class Initialized
INFO - 2016-05-21 11:28:40 --> Router Class Initialized
INFO - 2016-05-21 11:28:40 --> Output Class Initialized
INFO - 2016-05-21 11:28:40 --> Security Class Initialized
DEBUG - 2016-05-21 11:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:28:40 --> Input Class Initialized
INFO - 2016-05-21 11:28:40 --> Language Class Initialized
INFO - 2016-05-21 11:28:40 --> Loader Class Initialized
INFO - 2016-05-21 11:28:40 --> Helper loaded: url_helper
INFO - 2016-05-21 11:28:40 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:28:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:28:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:28:40 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:28:40 --> Helper loaded: form_helper
INFO - 2016-05-21 11:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:28:40 --> Form Validation Class Initialized
INFO - 2016-05-21 11:28:40 --> Controller Class Initialized
INFO - 2016-05-21 11:28:40 --> Model Class Initialized
INFO - 2016-05-21 11:28:40 --> Database Driver Class Initialized
INFO - 2016-05-21 11:28:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:28:40 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:28:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:28:40 --> Final output sent to browser
DEBUG - 2016-05-21 11:28:40 --> Total execution time: 0.0758
INFO - 2016-05-21 11:29:40 --> Config Class Initialized
INFO - 2016-05-21 11:29:40 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:29:40 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:29:40 --> Utf8 Class Initialized
INFO - 2016-05-21 11:29:40 --> URI Class Initialized
INFO - 2016-05-21 11:29:40 --> Router Class Initialized
INFO - 2016-05-21 11:29:40 --> Output Class Initialized
INFO - 2016-05-21 11:29:40 --> Security Class Initialized
DEBUG - 2016-05-21 11:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:29:40 --> Input Class Initialized
INFO - 2016-05-21 11:29:40 --> Language Class Initialized
INFO - 2016-05-21 11:29:40 --> Loader Class Initialized
INFO - 2016-05-21 11:29:40 --> Helper loaded: url_helper
INFO - 2016-05-21 11:29:40 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:29:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:29:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:29:40 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:29:40 --> Helper loaded: form_helper
INFO - 2016-05-21 11:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:29:40 --> Form Validation Class Initialized
INFO - 2016-05-21 11:29:40 --> Controller Class Initialized
INFO - 2016-05-21 11:29:40 --> Model Class Initialized
INFO - 2016-05-21 11:29:40 --> Database Driver Class Initialized
INFO - 2016-05-21 11:29:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:29:40 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:29:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:29:40 --> Final output sent to browser
DEBUG - 2016-05-21 11:29:40 --> Total execution time: 0.0739
INFO - 2016-05-21 11:30:40 --> Config Class Initialized
INFO - 2016-05-21 11:30:40 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:30:40 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:30:40 --> Utf8 Class Initialized
INFO - 2016-05-21 11:30:40 --> URI Class Initialized
INFO - 2016-05-21 11:30:40 --> Router Class Initialized
INFO - 2016-05-21 11:30:40 --> Output Class Initialized
INFO - 2016-05-21 11:30:40 --> Security Class Initialized
DEBUG - 2016-05-21 11:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:30:40 --> Input Class Initialized
INFO - 2016-05-21 11:30:40 --> Language Class Initialized
INFO - 2016-05-21 11:30:40 --> Loader Class Initialized
INFO - 2016-05-21 11:30:40 --> Helper loaded: url_helper
INFO - 2016-05-21 11:30:40 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:30:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:30:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:30:40 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:30:40 --> Helper loaded: form_helper
INFO - 2016-05-21 11:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:30:40 --> Form Validation Class Initialized
INFO - 2016-05-21 11:30:40 --> Controller Class Initialized
INFO - 2016-05-21 11:30:40 --> Model Class Initialized
INFO - 2016-05-21 11:30:40 --> Database Driver Class Initialized
INFO - 2016-05-21 11:30:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:30:40 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:30:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:30:40 --> Final output sent to browser
DEBUG - 2016-05-21 11:30:40 --> Total execution time: 0.0795
INFO - 2016-05-21 11:31:40 --> Config Class Initialized
INFO - 2016-05-21 11:31:40 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:31:40 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:31:40 --> Utf8 Class Initialized
INFO - 2016-05-21 11:31:40 --> URI Class Initialized
INFO - 2016-05-21 11:31:40 --> Router Class Initialized
INFO - 2016-05-21 11:31:40 --> Output Class Initialized
INFO - 2016-05-21 11:31:40 --> Security Class Initialized
DEBUG - 2016-05-21 11:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:31:40 --> Input Class Initialized
INFO - 2016-05-21 11:31:40 --> Language Class Initialized
INFO - 2016-05-21 11:31:40 --> Loader Class Initialized
INFO - 2016-05-21 11:31:40 --> Helper loaded: url_helper
INFO - 2016-05-21 11:31:40 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:31:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:31:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:31:40 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:31:40 --> Helper loaded: form_helper
INFO - 2016-05-21 11:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:31:40 --> Form Validation Class Initialized
INFO - 2016-05-21 11:31:40 --> Controller Class Initialized
INFO - 2016-05-21 11:31:40 --> Model Class Initialized
INFO - 2016-05-21 11:31:40 --> Database Driver Class Initialized
INFO - 2016-05-21 11:31:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:31:40 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:31:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:31:40 --> Final output sent to browser
DEBUG - 2016-05-21 11:31:40 --> Total execution time: 0.0730
INFO - 2016-05-21 11:32:40 --> Config Class Initialized
INFO - 2016-05-21 11:32:40 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:32:40 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:32:40 --> Utf8 Class Initialized
INFO - 2016-05-21 11:32:40 --> URI Class Initialized
INFO - 2016-05-21 11:32:40 --> Router Class Initialized
INFO - 2016-05-21 11:32:40 --> Output Class Initialized
INFO - 2016-05-21 11:32:40 --> Security Class Initialized
DEBUG - 2016-05-21 11:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:32:40 --> Input Class Initialized
INFO - 2016-05-21 11:32:40 --> Language Class Initialized
INFO - 2016-05-21 11:32:40 --> Loader Class Initialized
INFO - 2016-05-21 11:32:40 --> Helper loaded: url_helper
INFO - 2016-05-21 11:32:40 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:32:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:32:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:32:40 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:32:40 --> Helper loaded: form_helper
INFO - 2016-05-21 11:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:32:40 --> Form Validation Class Initialized
INFO - 2016-05-21 11:32:40 --> Controller Class Initialized
INFO - 2016-05-21 11:32:40 --> Model Class Initialized
INFO - 2016-05-21 11:32:40 --> Database Driver Class Initialized
INFO - 2016-05-21 11:32:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:32:40 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:32:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:32:40 --> Final output sent to browser
DEBUG - 2016-05-21 11:32:40 --> Total execution time: 0.0796
INFO - 2016-05-21 11:33:33 --> Config Class Initialized
INFO - 2016-05-21 11:33:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:33:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:33:33 --> Utf8 Class Initialized
INFO - 2016-05-21 11:33:33 --> URI Class Initialized
INFO - 2016-05-21 11:33:33 --> Router Class Initialized
INFO - 2016-05-21 11:33:33 --> Output Class Initialized
INFO - 2016-05-21 11:33:33 --> Security Class Initialized
DEBUG - 2016-05-21 11:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:33:33 --> Input Class Initialized
INFO - 2016-05-21 11:33:33 --> Language Class Initialized
INFO - 2016-05-21 11:33:33 --> Loader Class Initialized
INFO - 2016-05-21 11:33:33 --> Helper loaded: url_helper
INFO - 2016-05-21 11:33:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:33:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:33:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:33:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:33:33 --> Helper loaded: form_helper
INFO - 2016-05-21 11:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:33:33 --> Form Validation Class Initialized
INFO - 2016-05-21 11:33:33 --> Controller Class Initialized
INFO - 2016-05-21 11:33:33 --> Model Class Initialized
INFO - 2016-05-21 11:33:33 --> Database Driver Class Initialized
INFO - 2016-05-21 11:33:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:33:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:33:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:33:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 11:33:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:33:33 --> Final output sent to browser
DEBUG - 2016-05-21 11:33:33 --> Total execution time: 0.0836
INFO - 2016-05-21 11:33:34 --> Config Class Initialized
INFO - 2016-05-21 11:33:34 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:33:34 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:33:34 --> Utf8 Class Initialized
INFO - 2016-05-21 11:33:34 --> URI Class Initialized
INFO - 2016-05-21 11:33:34 --> Router Class Initialized
INFO - 2016-05-21 11:33:34 --> Output Class Initialized
INFO - 2016-05-21 11:33:34 --> Security Class Initialized
DEBUG - 2016-05-21 11:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:33:34 --> Input Class Initialized
INFO - 2016-05-21 11:33:34 --> Language Class Initialized
INFO - 2016-05-21 11:33:34 --> Loader Class Initialized
INFO - 2016-05-21 11:33:34 --> Helper loaded: url_helper
INFO - 2016-05-21 11:33:34 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:33:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:33:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:33:34 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:33:34 --> Helper loaded: form_helper
INFO - 2016-05-21 11:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:33:34 --> Form Validation Class Initialized
INFO - 2016-05-21 11:33:34 --> Controller Class Initialized
INFO - 2016-05-21 11:33:34 --> Model Class Initialized
INFO - 2016-05-21 11:33:34 --> Database Driver Class Initialized
INFO - 2016-05-21 11:33:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:33:34 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:33:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:33:34 --> Final output sent to browser
DEBUG - 2016-05-21 11:33:34 --> Total execution time: 0.0897
INFO - 2016-05-21 11:33:38 --> Config Class Initialized
INFO - 2016-05-21 11:33:38 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:33:38 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:33:38 --> Utf8 Class Initialized
INFO - 2016-05-21 11:33:38 --> URI Class Initialized
INFO - 2016-05-21 11:33:38 --> Router Class Initialized
INFO - 2016-05-21 11:33:38 --> Output Class Initialized
INFO - 2016-05-21 11:33:38 --> Security Class Initialized
DEBUG - 2016-05-21 11:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:33:38 --> Input Class Initialized
INFO - 2016-05-21 11:33:38 --> Language Class Initialized
INFO - 2016-05-21 11:33:38 --> Loader Class Initialized
INFO - 2016-05-21 11:33:38 --> Helper loaded: url_helper
INFO - 2016-05-21 11:33:38 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:33:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:33:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:33:38 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:33:38 --> Helper loaded: form_helper
INFO - 2016-05-21 11:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:33:38 --> Form Validation Class Initialized
INFO - 2016-05-21 11:33:38 --> Controller Class Initialized
INFO - 2016-05-21 11:33:38 --> Model Class Initialized
INFO - 2016-05-21 11:33:38 --> Database Driver Class Initialized
INFO - 2016-05-21 11:33:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:33:38 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:33:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:33:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:33:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:33:38 --> Final output sent to browser
DEBUG - 2016-05-21 11:33:38 --> Total execution time: 0.1279
INFO - 2016-05-21 11:33:38 --> Config Class Initialized
INFO - 2016-05-21 11:33:38 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:33:38 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:33:38 --> Utf8 Class Initialized
INFO - 2016-05-21 11:33:38 --> URI Class Initialized
INFO - 2016-05-21 11:33:38 --> Router Class Initialized
INFO - 2016-05-21 11:33:38 --> Output Class Initialized
INFO - 2016-05-21 11:33:38 --> Security Class Initialized
DEBUG - 2016-05-21 11:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:33:38 --> Input Class Initialized
INFO - 2016-05-21 11:33:38 --> Language Class Initialized
INFO - 2016-05-21 11:33:38 --> Loader Class Initialized
INFO - 2016-05-21 11:33:38 --> Helper loaded: url_helper
INFO - 2016-05-21 11:33:38 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:33:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:33:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:33:38 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:33:38 --> Helper loaded: form_helper
INFO - 2016-05-21 11:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:33:38 --> Form Validation Class Initialized
INFO - 2016-05-21 11:33:38 --> Controller Class Initialized
INFO - 2016-05-21 11:33:38 --> Model Class Initialized
INFO - 2016-05-21 11:33:38 --> Database Driver Class Initialized
INFO - 2016-05-21 11:33:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:33:38 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:33:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:33:38 --> Final output sent to browser
DEBUG - 2016-05-21 11:33:38 --> Total execution time: 0.0967
INFO - 2016-05-21 11:34:38 --> Config Class Initialized
INFO - 2016-05-21 11:34:38 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:34:38 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:34:38 --> Utf8 Class Initialized
INFO - 2016-05-21 11:34:38 --> URI Class Initialized
INFO - 2016-05-21 11:34:38 --> Router Class Initialized
INFO - 2016-05-21 11:34:38 --> Output Class Initialized
INFO - 2016-05-21 11:34:38 --> Security Class Initialized
DEBUG - 2016-05-21 11:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:34:38 --> Input Class Initialized
INFO - 2016-05-21 11:34:38 --> Language Class Initialized
INFO - 2016-05-21 11:34:38 --> Loader Class Initialized
INFO - 2016-05-21 11:34:38 --> Helper loaded: url_helper
INFO - 2016-05-21 11:34:38 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:34:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:34:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:34:38 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:34:38 --> Helper loaded: form_helper
INFO - 2016-05-21 11:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:34:38 --> Form Validation Class Initialized
INFO - 2016-05-21 11:34:38 --> Controller Class Initialized
INFO - 2016-05-21 11:34:38 --> Model Class Initialized
INFO - 2016-05-21 11:34:38 --> Database Driver Class Initialized
INFO - 2016-05-21 11:34:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:34:38 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:34:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:34:38 --> Final output sent to browser
DEBUG - 2016-05-21 11:34:38 --> Total execution time: 0.0797
INFO - 2016-05-21 11:35:38 --> Config Class Initialized
INFO - 2016-05-21 11:35:38 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:35:38 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:35:38 --> Utf8 Class Initialized
INFO - 2016-05-21 11:35:38 --> URI Class Initialized
INFO - 2016-05-21 11:35:38 --> Router Class Initialized
INFO - 2016-05-21 11:35:38 --> Output Class Initialized
INFO - 2016-05-21 11:35:38 --> Security Class Initialized
DEBUG - 2016-05-21 11:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:35:38 --> Input Class Initialized
INFO - 2016-05-21 11:35:38 --> Language Class Initialized
INFO - 2016-05-21 11:35:38 --> Loader Class Initialized
INFO - 2016-05-21 11:35:38 --> Helper loaded: url_helper
INFO - 2016-05-21 11:35:38 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:35:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:35:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:35:38 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:35:38 --> Helper loaded: form_helper
INFO - 2016-05-21 11:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:35:38 --> Form Validation Class Initialized
INFO - 2016-05-21 11:35:38 --> Controller Class Initialized
INFO - 2016-05-21 11:35:38 --> Model Class Initialized
INFO - 2016-05-21 11:35:38 --> Database Driver Class Initialized
INFO - 2016-05-21 11:35:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:35:38 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:35:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:35:38 --> Final output sent to browser
DEBUG - 2016-05-21 11:35:38 --> Total execution time: 0.0758
INFO - 2016-05-21 11:36:39 --> Config Class Initialized
INFO - 2016-05-21 11:36:39 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:36:39 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:36:39 --> Utf8 Class Initialized
INFO - 2016-05-21 11:36:39 --> URI Class Initialized
INFO - 2016-05-21 11:36:39 --> Router Class Initialized
INFO - 2016-05-21 11:36:39 --> Output Class Initialized
INFO - 2016-05-21 11:36:39 --> Security Class Initialized
DEBUG - 2016-05-21 11:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:36:39 --> Input Class Initialized
INFO - 2016-05-21 11:36:39 --> Language Class Initialized
INFO - 2016-05-21 11:36:39 --> Loader Class Initialized
INFO - 2016-05-21 11:36:39 --> Helper loaded: url_helper
INFO - 2016-05-21 11:36:39 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:36:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:36:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:36:39 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:36:39 --> Helper loaded: form_helper
INFO - 2016-05-21 11:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:36:39 --> Form Validation Class Initialized
INFO - 2016-05-21 11:36:39 --> Controller Class Initialized
INFO - 2016-05-21 11:36:39 --> Model Class Initialized
INFO - 2016-05-21 11:36:39 --> Database Driver Class Initialized
INFO - 2016-05-21 11:36:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:36:39 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:36:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:36:39 --> Final output sent to browser
DEBUG - 2016-05-21 11:36:39 --> Total execution time: 0.1073
INFO - 2016-05-21 11:37:39 --> Config Class Initialized
INFO - 2016-05-21 11:37:39 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:37:39 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:37:39 --> Utf8 Class Initialized
INFO - 2016-05-21 11:37:39 --> URI Class Initialized
INFO - 2016-05-21 11:37:39 --> Router Class Initialized
INFO - 2016-05-21 11:37:39 --> Output Class Initialized
INFO - 2016-05-21 11:37:39 --> Security Class Initialized
DEBUG - 2016-05-21 11:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:37:39 --> Input Class Initialized
INFO - 2016-05-21 11:37:39 --> Language Class Initialized
INFO - 2016-05-21 11:37:39 --> Loader Class Initialized
INFO - 2016-05-21 11:37:39 --> Helper loaded: url_helper
INFO - 2016-05-21 11:37:39 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:37:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:37:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:37:39 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:37:39 --> Helper loaded: form_helper
INFO - 2016-05-21 11:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:37:39 --> Form Validation Class Initialized
INFO - 2016-05-21 11:37:39 --> Controller Class Initialized
INFO - 2016-05-21 11:37:39 --> Model Class Initialized
INFO - 2016-05-21 11:37:39 --> Database Driver Class Initialized
INFO - 2016-05-21 11:37:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:37:39 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:37:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:37:39 --> Final output sent to browser
DEBUG - 2016-05-21 11:37:39 --> Total execution time: 0.0798
INFO - 2016-05-21 11:38:39 --> Config Class Initialized
INFO - 2016-05-21 11:38:39 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:38:39 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:38:39 --> Utf8 Class Initialized
INFO - 2016-05-21 11:38:39 --> URI Class Initialized
INFO - 2016-05-21 11:38:39 --> Router Class Initialized
INFO - 2016-05-21 11:38:39 --> Output Class Initialized
INFO - 2016-05-21 11:38:39 --> Security Class Initialized
DEBUG - 2016-05-21 11:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:38:39 --> Input Class Initialized
INFO - 2016-05-21 11:38:39 --> Language Class Initialized
INFO - 2016-05-21 11:38:39 --> Loader Class Initialized
INFO - 2016-05-21 11:38:39 --> Helper loaded: url_helper
INFO - 2016-05-21 11:38:39 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:38:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:38:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:38:39 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:38:39 --> Helper loaded: form_helper
INFO - 2016-05-21 11:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:38:39 --> Form Validation Class Initialized
INFO - 2016-05-21 11:38:39 --> Controller Class Initialized
INFO - 2016-05-21 11:38:39 --> Model Class Initialized
INFO - 2016-05-21 11:38:39 --> Database Driver Class Initialized
INFO - 2016-05-21 11:38:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:38:39 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:38:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:38:39 --> Final output sent to browser
DEBUG - 2016-05-21 11:38:39 --> Total execution time: 0.1186
INFO - 2016-05-21 11:39:39 --> Config Class Initialized
INFO - 2016-05-21 11:39:39 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:39:39 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:39:39 --> Utf8 Class Initialized
INFO - 2016-05-21 11:39:39 --> URI Class Initialized
INFO - 2016-05-21 11:39:39 --> Router Class Initialized
INFO - 2016-05-21 11:39:39 --> Output Class Initialized
INFO - 2016-05-21 11:39:39 --> Security Class Initialized
DEBUG - 2016-05-21 11:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:39:39 --> Input Class Initialized
INFO - 2016-05-21 11:39:39 --> Language Class Initialized
INFO - 2016-05-21 11:39:39 --> Loader Class Initialized
INFO - 2016-05-21 11:39:39 --> Helper loaded: url_helper
INFO - 2016-05-21 11:39:39 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:39:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:39:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:39:39 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:39:39 --> Helper loaded: form_helper
INFO - 2016-05-21 11:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:39:39 --> Form Validation Class Initialized
INFO - 2016-05-21 11:39:39 --> Controller Class Initialized
INFO - 2016-05-21 11:39:39 --> Model Class Initialized
INFO - 2016-05-21 11:39:39 --> Database Driver Class Initialized
INFO - 2016-05-21 11:39:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:39:39 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:39:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:39:39 --> Final output sent to browser
DEBUG - 2016-05-21 11:39:39 --> Total execution time: 0.0730
INFO - 2016-05-21 11:40:39 --> Config Class Initialized
INFO - 2016-05-21 11:40:39 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:40:39 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:40:39 --> Utf8 Class Initialized
INFO - 2016-05-21 11:40:39 --> URI Class Initialized
INFO - 2016-05-21 11:40:39 --> Router Class Initialized
INFO - 2016-05-21 11:40:39 --> Output Class Initialized
INFO - 2016-05-21 11:40:39 --> Security Class Initialized
DEBUG - 2016-05-21 11:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:40:39 --> Input Class Initialized
INFO - 2016-05-21 11:40:39 --> Language Class Initialized
INFO - 2016-05-21 11:40:39 --> Loader Class Initialized
INFO - 2016-05-21 11:40:39 --> Helper loaded: url_helper
INFO - 2016-05-21 11:40:39 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:40:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:40:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:40:39 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:40:39 --> Helper loaded: form_helper
INFO - 2016-05-21 11:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:40:39 --> Form Validation Class Initialized
INFO - 2016-05-21 11:40:39 --> Controller Class Initialized
INFO - 2016-05-21 11:40:39 --> Model Class Initialized
INFO - 2016-05-21 11:40:39 --> Database Driver Class Initialized
INFO - 2016-05-21 11:40:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:40:39 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:40:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:40:39 --> Final output sent to browser
DEBUG - 2016-05-21 11:40:39 --> Total execution time: 0.0733
INFO - 2016-05-21 11:41:39 --> Config Class Initialized
INFO - 2016-05-21 11:41:39 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:41:39 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:41:39 --> Utf8 Class Initialized
INFO - 2016-05-21 11:41:39 --> URI Class Initialized
INFO - 2016-05-21 11:41:39 --> Router Class Initialized
INFO - 2016-05-21 11:41:39 --> Output Class Initialized
INFO - 2016-05-21 11:41:39 --> Security Class Initialized
DEBUG - 2016-05-21 11:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:41:39 --> Input Class Initialized
INFO - 2016-05-21 11:41:39 --> Language Class Initialized
INFO - 2016-05-21 11:41:39 --> Loader Class Initialized
INFO - 2016-05-21 11:41:39 --> Helper loaded: url_helper
INFO - 2016-05-21 11:41:39 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:41:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:41:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:41:39 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:41:39 --> Helper loaded: form_helper
INFO - 2016-05-21 11:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:41:39 --> Form Validation Class Initialized
INFO - 2016-05-21 11:41:39 --> Controller Class Initialized
INFO - 2016-05-21 11:41:39 --> Model Class Initialized
INFO - 2016-05-21 11:41:39 --> Database Driver Class Initialized
INFO - 2016-05-21 11:41:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:41:39 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:41:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:41:39 --> Final output sent to browser
DEBUG - 2016-05-21 11:41:39 --> Total execution time: 0.0733
INFO - 2016-05-21 11:42:39 --> Config Class Initialized
INFO - 2016-05-21 11:42:39 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:42:39 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:42:39 --> Utf8 Class Initialized
INFO - 2016-05-21 11:42:39 --> URI Class Initialized
INFO - 2016-05-21 11:42:39 --> Router Class Initialized
INFO - 2016-05-21 11:42:39 --> Output Class Initialized
INFO - 2016-05-21 11:42:39 --> Security Class Initialized
DEBUG - 2016-05-21 11:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:42:39 --> Input Class Initialized
INFO - 2016-05-21 11:42:39 --> Language Class Initialized
INFO - 2016-05-21 11:42:39 --> Loader Class Initialized
INFO - 2016-05-21 11:42:39 --> Helper loaded: url_helper
INFO - 2016-05-21 11:42:39 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:42:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:42:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:42:39 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:42:39 --> Helper loaded: form_helper
INFO - 2016-05-21 11:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:42:39 --> Form Validation Class Initialized
INFO - 2016-05-21 11:42:39 --> Controller Class Initialized
INFO - 2016-05-21 11:42:39 --> Model Class Initialized
INFO - 2016-05-21 11:42:39 --> Database Driver Class Initialized
INFO - 2016-05-21 11:42:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:42:39 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:42:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:42:39 --> Final output sent to browser
DEBUG - 2016-05-21 11:42:39 --> Total execution time: 0.0697
INFO - 2016-05-21 11:43:39 --> Config Class Initialized
INFO - 2016-05-21 11:43:39 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:43:39 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:43:39 --> Utf8 Class Initialized
INFO - 2016-05-21 11:43:39 --> URI Class Initialized
INFO - 2016-05-21 11:43:39 --> Router Class Initialized
INFO - 2016-05-21 11:43:39 --> Output Class Initialized
INFO - 2016-05-21 11:43:39 --> Security Class Initialized
DEBUG - 2016-05-21 11:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:43:39 --> Input Class Initialized
INFO - 2016-05-21 11:43:39 --> Language Class Initialized
INFO - 2016-05-21 11:43:39 --> Loader Class Initialized
INFO - 2016-05-21 11:43:39 --> Helper loaded: url_helper
INFO - 2016-05-21 11:43:39 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:43:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:43:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:43:39 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:43:39 --> Helper loaded: form_helper
INFO - 2016-05-21 11:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:43:39 --> Form Validation Class Initialized
INFO - 2016-05-21 11:43:39 --> Controller Class Initialized
INFO - 2016-05-21 11:43:39 --> Model Class Initialized
INFO - 2016-05-21 11:43:39 --> Database Driver Class Initialized
INFO - 2016-05-21 11:43:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:43:39 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:43:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:43:39 --> Final output sent to browser
DEBUG - 2016-05-21 11:43:39 --> Total execution time: 0.0812
INFO - 2016-05-21 11:44:10 --> Config Class Initialized
INFO - 2016-05-21 11:44:10 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:44:10 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:44:10 --> Utf8 Class Initialized
INFO - 2016-05-21 11:44:10 --> URI Class Initialized
INFO - 2016-05-21 11:44:10 --> Router Class Initialized
INFO - 2016-05-21 11:44:10 --> Output Class Initialized
INFO - 2016-05-21 11:44:10 --> Security Class Initialized
DEBUG - 2016-05-21 11:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:44:10 --> Input Class Initialized
INFO - 2016-05-21 11:44:10 --> Language Class Initialized
INFO - 2016-05-21 11:44:10 --> Loader Class Initialized
INFO - 2016-05-21 11:44:10 --> Helper loaded: url_helper
INFO - 2016-05-21 11:44:10 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:44:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:44:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:44:10 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:44:10 --> Helper loaded: form_helper
INFO - 2016-05-21 11:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:44:10 --> Form Validation Class Initialized
INFO - 2016-05-21 11:44:10 --> Controller Class Initialized
INFO - 2016-05-21 11:44:10 --> Model Class Initialized
INFO - 2016-05-21 11:44:10 --> Database Driver Class Initialized
INFO - 2016-05-21 11:44:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:44:10 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:44:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-21 11:44:10 --> Severity: Notice --> Undefined variable: idCliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php 22
INFO - 2016-05-21 11:44:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:44:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:44:10 --> Final output sent to browser
DEBUG - 2016-05-21 11:44:10 --> Total execution time: 0.1225
INFO - 2016-05-21 11:44:11 --> Config Class Initialized
INFO - 2016-05-21 11:44:11 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:44:11 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:44:11 --> Utf8 Class Initialized
INFO - 2016-05-21 11:44:11 --> URI Class Initialized
INFO - 2016-05-21 11:44:11 --> Router Class Initialized
INFO - 2016-05-21 11:44:11 --> Output Class Initialized
INFO - 2016-05-21 11:44:11 --> Security Class Initialized
DEBUG - 2016-05-21 11:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:44:11 --> Input Class Initialized
INFO - 2016-05-21 11:44:11 --> Language Class Initialized
INFO - 2016-05-21 11:44:11 --> Loader Class Initialized
INFO - 2016-05-21 11:44:11 --> Helper loaded: url_helper
INFO - 2016-05-21 11:44:11 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:44:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:44:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:44:11 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:44:11 --> Helper loaded: form_helper
INFO - 2016-05-21 11:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:44:11 --> Form Validation Class Initialized
INFO - 2016-05-21 11:44:11 --> Controller Class Initialized
INFO - 2016-05-21 11:44:11 --> Model Class Initialized
INFO - 2016-05-21 11:44:11 --> Database Driver Class Initialized
INFO - 2016-05-21 11:44:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:44:11 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:44:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:44:11 --> Final output sent to browser
DEBUG - 2016-05-21 11:44:11 --> Total execution time: 0.0881
INFO - 2016-05-21 11:44:59 --> Config Class Initialized
INFO - 2016-05-21 11:44:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:44:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:44:59 --> Utf8 Class Initialized
INFO - 2016-05-21 11:44:59 --> URI Class Initialized
INFO - 2016-05-21 11:44:59 --> Router Class Initialized
INFO - 2016-05-21 11:44:59 --> Output Class Initialized
INFO - 2016-05-21 11:44:59 --> Security Class Initialized
DEBUG - 2016-05-21 11:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:44:59 --> Input Class Initialized
INFO - 2016-05-21 11:44:59 --> Language Class Initialized
INFO - 2016-05-21 11:44:59 --> Loader Class Initialized
INFO - 2016-05-21 11:44:59 --> Helper loaded: url_helper
INFO - 2016-05-21 11:44:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:44:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:44:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:44:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:44:59 --> Helper loaded: form_helper
INFO - 2016-05-21 11:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:44:59 --> Form Validation Class Initialized
INFO - 2016-05-21 11:44:59 --> Controller Class Initialized
INFO - 2016-05-21 11:44:59 --> Model Class Initialized
INFO - 2016-05-21 11:44:59 --> Database Driver Class Initialized
INFO - 2016-05-21 11:44:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:44:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:44:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:44:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:44:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:44:59 --> Final output sent to browser
DEBUG - 2016-05-21 11:44:59 --> Total execution time: 0.0824
INFO - 2016-05-21 11:45:00 --> Config Class Initialized
INFO - 2016-05-21 11:45:00 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:45:00 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:45:00 --> Utf8 Class Initialized
INFO - 2016-05-21 11:45:00 --> URI Class Initialized
INFO - 2016-05-21 11:45:00 --> Router Class Initialized
INFO - 2016-05-21 11:45:00 --> Output Class Initialized
INFO - 2016-05-21 11:45:00 --> Security Class Initialized
DEBUG - 2016-05-21 11:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:45:00 --> Input Class Initialized
INFO - 2016-05-21 11:45:00 --> Language Class Initialized
INFO - 2016-05-21 11:45:00 --> Loader Class Initialized
INFO - 2016-05-21 11:45:00 --> Helper loaded: url_helper
INFO - 2016-05-21 11:45:00 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:45:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:45:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:45:00 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:45:00 --> Helper loaded: form_helper
INFO - 2016-05-21 11:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:45:00 --> Form Validation Class Initialized
INFO - 2016-05-21 11:45:00 --> Controller Class Initialized
INFO - 2016-05-21 11:45:00 --> Model Class Initialized
INFO - 2016-05-21 11:45:00 --> Database Driver Class Initialized
INFO - 2016-05-21 11:45:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:45:00 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:45:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:45:00 --> Final output sent to browser
DEBUG - 2016-05-21 11:45:00 --> Total execution time: 0.0902
INFO - 2016-05-21 11:45:38 --> Config Class Initialized
INFO - 2016-05-21 11:45:38 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:45:38 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:45:38 --> Utf8 Class Initialized
INFO - 2016-05-21 11:45:38 --> URI Class Initialized
INFO - 2016-05-21 11:45:38 --> Router Class Initialized
INFO - 2016-05-21 11:45:38 --> Output Class Initialized
INFO - 2016-05-21 11:45:38 --> Security Class Initialized
DEBUG - 2016-05-21 11:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:45:38 --> Input Class Initialized
INFO - 2016-05-21 11:45:38 --> Language Class Initialized
INFO - 2016-05-21 11:45:38 --> Loader Class Initialized
INFO - 2016-05-21 11:45:38 --> Helper loaded: url_helper
INFO - 2016-05-21 11:45:38 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:45:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:45:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:45:38 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:45:38 --> Helper loaded: form_helper
INFO - 2016-05-21 11:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:45:38 --> Form Validation Class Initialized
INFO - 2016-05-21 11:45:38 --> Controller Class Initialized
INFO - 2016-05-21 11:45:38 --> Model Class Initialized
INFO - 2016-05-21 11:45:38 --> Database Driver Class Initialized
INFO - 2016-05-21 11:45:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:45:38 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:45:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:45:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:45:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:45:38 --> Final output sent to browser
DEBUG - 2016-05-21 11:45:38 --> Total execution time: 0.0792
INFO - 2016-05-21 11:45:38 --> Config Class Initialized
INFO - 2016-05-21 11:45:38 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:45:38 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:45:38 --> Utf8 Class Initialized
INFO - 2016-05-21 11:45:38 --> URI Class Initialized
INFO - 2016-05-21 11:45:38 --> Router Class Initialized
INFO - 2016-05-21 11:45:38 --> Output Class Initialized
INFO - 2016-05-21 11:45:38 --> Security Class Initialized
DEBUG - 2016-05-21 11:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:45:38 --> Input Class Initialized
INFO - 2016-05-21 11:45:38 --> Language Class Initialized
INFO - 2016-05-21 11:45:38 --> Loader Class Initialized
INFO - 2016-05-21 11:45:38 --> Helper loaded: url_helper
INFO - 2016-05-21 11:45:38 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:45:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:45:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:45:38 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:45:38 --> Helper loaded: form_helper
INFO - 2016-05-21 11:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:45:38 --> Form Validation Class Initialized
INFO - 2016-05-21 11:45:38 --> Controller Class Initialized
INFO - 2016-05-21 11:45:38 --> Model Class Initialized
INFO - 2016-05-21 11:45:38 --> Database Driver Class Initialized
INFO - 2016-05-21 11:45:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:45:38 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:45:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:45:38 --> Final output sent to browser
DEBUG - 2016-05-21 11:45:38 --> Total execution time: 0.1027
INFO - 2016-05-21 11:45:48 --> Config Class Initialized
INFO - 2016-05-21 11:45:48 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:45:48 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:45:48 --> Utf8 Class Initialized
INFO - 2016-05-21 11:45:48 --> URI Class Initialized
INFO - 2016-05-21 11:45:48 --> Router Class Initialized
INFO - 2016-05-21 11:45:48 --> Output Class Initialized
INFO - 2016-05-21 11:45:48 --> Security Class Initialized
DEBUG - 2016-05-21 11:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:45:48 --> Input Class Initialized
INFO - 2016-05-21 11:45:48 --> Language Class Initialized
INFO - 2016-05-21 11:45:48 --> Loader Class Initialized
INFO - 2016-05-21 11:45:48 --> Helper loaded: url_helper
INFO - 2016-05-21 11:45:48 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:45:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:45:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:45:48 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:45:48 --> Helper loaded: form_helper
INFO - 2016-05-21 11:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:45:48 --> Form Validation Class Initialized
INFO - 2016-05-21 11:45:48 --> Controller Class Initialized
INFO - 2016-05-21 11:45:48 --> Model Class Initialized
INFO - 2016-05-21 11:45:48 --> Database Driver Class Initialized
INFO - 2016-05-21 11:45:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:45:48 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:45:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:45:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:45:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:45:48 --> Final output sent to browser
DEBUG - 2016-05-21 11:45:48 --> Total execution time: 0.0789
INFO - 2016-05-21 11:45:49 --> Config Class Initialized
INFO - 2016-05-21 11:45:49 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:45:49 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:45:49 --> Utf8 Class Initialized
INFO - 2016-05-21 11:45:49 --> URI Class Initialized
INFO - 2016-05-21 11:45:49 --> Router Class Initialized
INFO - 2016-05-21 11:45:49 --> Output Class Initialized
INFO - 2016-05-21 11:45:49 --> Security Class Initialized
DEBUG - 2016-05-21 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:45:49 --> Input Class Initialized
INFO - 2016-05-21 11:45:49 --> Language Class Initialized
INFO - 2016-05-21 11:45:49 --> Loader Class Initialized
INFO - 2016-05-21 11:45:49 --> Helper loaded: url_helper
INFO - 2016-05-21 11:45:49 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:45:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:45:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:45:49 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:45:49 --> Helper loaded: form_helper
INFO - 2016-05-21 11:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:45:49 --> Form Validation Class Initialized
INFO - 2016-05-21 11:45:49 --> Controller Class Initialized
INFO - 2016-05-21 11:45:49 --> Model Class Initialized
INFO - 2016-05-21 11:45:49 --> Database Driver Class Initialized
INFO - 2016-05-21 11:45:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:45:49 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:45:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:45:49 --> Final output sent to browser
DEBUG - 2016-05-21 11:45:49 --> Total execution time: 0.0899
INFO - 2016-05-21 11:46:49 --> Config Class Initialized
INFO - 2016-05-21 11:46:49 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:46:49 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:46:49 --> Utf8 Class Initialized
INFO - 2016-05-21 11:46:49 --> URI Class Initialized
INFO - 2016-05-21 11:46:49 --> Router Class Initialized
INFO - 2016-05-21 11:46:49 --> Output Class Initialized
INFO - 2016-05-21 11:46:49 --> Security Class Initialized
DEBUG - 2016-05-21 11:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:46:49 --> Input Class Initialized
INFO - 2016-05-21 11:46:49 --> Language Class Initialized
INFO - 2016-05-21 11:46:49 --> Loader Class Initialized
INFO - 2016-05-21 11:46:49 --> Helper loaded: url_helper
INFO - 2016-05-21 11:46:49 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:46:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:46:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:46:49 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:46:49 --> Helper loaded: form_helper
INFO - 2016-05-21 11:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:46:49 --> Form Validation Class Initialized
INFO - 2016-05-21 11:46:49 --> Controller Class Initialized
INFO - 2016-05-21 11:46:49 --> Model Class Initialized
INFO - 2016-05-21 11:46:49 --> Database Driver Class Initialized
INFO - 2016-05-21 11:46:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:46:49 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:46:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:46:49 --> Final output sent to browser
DEBUG - 2016-05-21 11:46:49 --> Total execution time: 0.0714
INFO - 2016-05-21 11:47:22 --> Config Class Initialized
INFO - 2016-05-21 11:47:22 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:47:22 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:47:22 --> Utf8 Class Initialized
INFO - 2016-05-21 11:47:22 --> URI Class Initialized
INFO - 2016-05-21 11:47:22 --> Router Class Initialized
INFO - 2016-05-21 11:47:22 --> Output Class Initialized
INFO - 2016-05-21 11:47:22 --> Security Class Initialized
DEBUG - 2016-05-21 11:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:47:22 --> Input Class Initialized
INFO - 2016-05-21 11:47:22 --> Language Class Initialized
INFO - 2016-05-21 11:47:22 --> Loader Class Initialized
INFO - 2016-05-21 11:47:22 --> Helper loaded: url_helper
INFO - 2016-05-21 11:47:22 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:47:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:47:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:47:22 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:47:22 --> Helper loaded: form_helper
INFO - 2016-05-21 11:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:47:22 --> Form Validation Class Initialized
INFO - 2016-05-21 11:47:22 --> Controller Class Initialized
INFO - 2016-05-21 11:47:22 --> Model Class Initialized
INFO - 2016-05-21 11:47:22 --> Database Driver Class Initialized
INFO - 2016-05-21 11:47:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:47:22 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:47:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:47:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:47:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:47:22 --> Final output sent to browser
DEBUG - 2016-05-21 11:47:22 --> Total execution time: 0.0839
INFO - 2016-05-21 11:47:22 --> Config Class Initialized
INFO - 2016-05-21 11:47:22 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:47:22 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:47:22 --> Utf8 Class Initialized
INFO - 2016-05-21 11:47:22 --> URI Class Initialized
INFO - 2016-05-21 11:47:22 --> Router Class Initialized
INFO - 2016-05-21 11:47:22 --> Output Class Initialized
INFO - 2016-05-21 11:47:22 --> Security Class Initialized
DEBUG - 2016-05-21 11:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:47:22 --> Input Class Initialized
INFO - 2016-05-21 11:47:22 --> Language Class Initialized
INFO - 2016-05-21 11:47:22 --> Loader Class Initialized
INFO - 2016-05-21 11:47:22 --> Helper loaded: url_helper
INFO - 2016-05-21 11:47:22 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:47:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:47:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:47:22 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:47:22 --> Helper loaded: form_helper
INFO - 2016-05-21 11:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:47:22 --> Form Validation Class Initialized
INFO - 2016-05-21 11:47:22 --> Controller Class Initialized
INFO - 2016-05-21 11:47:22 --> Model Class Initialized
INFO - 2016-05-21 11:47:22 --> Database Driver Class Initialized
INFO - 2016-05-21 11:47:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:47:22 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:47:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:47:22 --> Final output sent to browser
DEBUG - 2016-05-21 11:47:22 --> Total execution time: 0.0831
INFO - 2016-05-21 11:47:53 --> Config Class Initialized
INFO - 2016-05-21 11:47:53 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:47:54 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:47:54 --> Utf8 Class Initialized
INFO - 2016-05-21 11:47:54 --> URI Class Initialized
INFO - 2016-05-21 11:47:54 --> Router Class Initialized
INFO - 2016-05-21 11:47:54 --> Output Class Initialized
INFO - 2016-05-21 11:47:54 --> Security Class Initialized
DEBUG - 2016-05-21 11:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:47:54 --> Input Class Initialized
INFO - 2016-05-21 11:47:54 --> Language Class Initialized
INFO - 2016-05-21 11:47:54 --> Loader Class Initialized
INFO - 2016-05-21 11:47:54 --> Helper loaded: url_helper
INFO - 2016-05-21 11:47:54 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:47:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:47:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:47:54 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:47:54 --> Helper loaded: form_helper
INFO - 2016-05-21 11:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:47:54 --> Form Validation Class Initialized
INFO - 2016-05-21 11:47:54 --> Controller Class Initialized
INFO - 2016-05-21 11:47:54 --> Model Class Initialized
INFO - 2016-05-21 11:47:54 --> Database Driver Class Initialized
INFO - 2016-05-21 11:47:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:47:54 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:47:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:47:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:47:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:47:54 --> Final output sent to browser
DEBUG - 2016-05-21 11:47:54 --> Total execution time: 0.0902
INFO - 2016-05-21 11:47:54 --> Config Class Initialized
INFO - 2016-05-21 11:47:54 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:47:54 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:47:54 --> Utf8 Class Initialized
INFO - 2016-05-21 11:47:54 --> URI Class Initialized
INFO - 2016-05-21 11:47:54 --> Router Class Initialized
INFO - 2016-05-21 11:47:54 --> Output Class Initialized
INFO - 2016-05-21 11:47:54 --> Security Class Initialized
DEBUG - 2016-05-21 11:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:47:54 --> Input Class Initialized
INFO - 2016-05-21 11:47:54 --> Language Class Initialized
INFO - 2016-05-21 11:47:54 --> Loader Class Initialized
INFO - 2016-05-21 11:47:54 --> Helper loaded: url_helper
INFO - 2016-05-21 11:47:54 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:47:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:47:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:47:54 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:47:54 --> Helper loaded: form_helper
INFO - 2016-05-21 11:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:47:54 --> Form Validation Class Initialized
INFO - 2016-05-21 11:47:54 --> Controller Class Initialized
INFO - 2016-05-21 11:47:54 --> Model Class Initialized
INFO - 2016-05-21 11:47:54 --> Database Driver Class Initialized
INFO - 2016-05-21 11:47:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:47:54 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:47:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:47:54 --> Final output sent to browser
DEBUG - 2016-05-21 11:47:54 --> Total execution time: 0.0872
INFO - 2016-05-21 11:48:54 --> Config Class Initialized
INFO - 2016-05-21 11:48:54 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:48:54 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:48:54 --> Utf8 Class Initialized
INFO - 2016-05-21 11:48:54 --> URI Class Initialized
INFO - 2016-05-21 11:48:54 --> Router Class Initialized
INFO - 2016-05-21 11:48:54 --> Output Class Initialized
INFO - 2016-05-21 11:48:54 --> Security Class Initialized
DEBUG - 2016-05-21 11:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:48:54 --> Input Class Initialized
INFO - 2016-05-21 11:48:54 --> Language Class Initialized
INFO - 2016-05-21 11:48:54 --> Loader Class Initialized
INFO - 2016-05-21 11:48:54 --> Helper loaded: url_helper
INFO - 2016-05-21 11:48:54 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:48:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:48:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:48:54 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:48:54 --> Helper loaded: form_helper
INFO - 2016-05-21 11:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:48:54 --> Form Validation Class Initialized
INFO - 2016-05-21 11:48:54 --> Controller Class Initialized
INFO - 2016-05-21 11:48:54 --> Model Class Initialized
INFO - 2016-05-21 11:48:54 --> Database Driver Class Initialized
INFO - 2016-05-21 11:48:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:48:54 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:48:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:48:54 --> Final output sent to browser
DEBUG - 2016-05-21 11:48:54 --> Total execution time: 0.0714
INFO - 2016-05-21 11:49:55 --> Config Class Initialized
INFO - 2016-05-21 11:49:55 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:49:55 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:49:55 --> Utf8 Class Initialized
INFO - 2016-05-21 11:49:55 --> URI Class Initialized
INFO - 2016-05-21 11:49:55 --> Router Class Initialized
INFO - 2016-05-21 11:49:55 --> Output Class Initialized
INFO - 2016-05-21 11:49:55 --> Security Class Initialized
DEBUG - 2016-05-21 11:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:49:55 --> Input Class Initialized
INFO - 2016-05-21 11:49:55 --> Language Class Initialized
INFO - 2016-05-21 11:49:55 --> Loader Class Initialized
INFO - 2016-05-21 11:49:55 --> Helper loaded: url_helper
INFO - 2016-05-21 11:49:55 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:49:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:49:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:49:55 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:49:55 --> Helper loaded: form_helper
INFO - 2016-05-21 11:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:49:55 --> Form Validation Class Initialized
INFO - 2016-05-21 11:49:55 --> Controller Class Initialized
INFO - 2016-05-21 11:49:55 --> Model Class Initialized
INFO - 2016-05-21 11:49:55 --> Database Driver Class Initialized
INFO - 2016-05-21 11:49:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:49:55 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:49:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:49:55 --> Final output sent to browser
DEBUG - 2016-05-21 11:49:55 --> Total execution time: 0.0795
INFO - 2016-05-21 11:50:03 --> Config Class Initialized
INFO - 2016-05-21 11:50:03 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:50:03 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:50:03 --> Utf8 Class Initialized
INFO - 2016-05-21 11:50:03 --> URI Class Initialized
INFO - 2016-05-21 11:50:03 --> Router Class Initialized
INFO - 2016-05-21 11:50:03 --> Output Class Initialized
INFO - 2016-05-21 11:50:03 --> Security Class Initialized
DEBUG - 2016-05-21 11:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:50:03 --> Input Class Initialized
INFO - 2016-05-21 11:50:03 --> Language Class Initialized
INFO - 2016-05-21 11:50:03 --> Loader Class Initialized
INFO - 2016-05-21 11:50:03 --> Helper loaded: url_helper
INFO - 2016-05-21 11:50:03 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:50:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:50:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:50:03 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:50:03 --> Helper loaded: form_helper
INFO - 2016-05-21 11:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:50:03 --> Form Validation Class Initialized
INFO - 2016-05-21 11:50:03 --> Controller Class Initialized
INFO - 2016-05-21 11:50:03 --> Model Class Initialized
INFO - 2016-05-21 11:50:03 --> Database Driver Class Initialized
INFO - 2016-05-21 11:50:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:50:03 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:50:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:50:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:50:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:50:03 --> Final output sent to browser
DEBUG - 2016-05-21 11:50:03 --> Total execution time: 0.0823
INFO - 2016-05-21 11:50:04 --> Config Class Initialized
INFO - 2016-05-21 11:50:04 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:50:04 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:50:04 --> Utf8 Class Initialized
INFO - 2016-05-21 11:50:04 --> URI Class Initialized
INFO - 2016-05-21 11:50:04 --> Router Class Initialized
INFO - 2016-05-21 11:50:04 --> Output Class Initialized
INFO - 2016-05-21 11:50:04 --> Security Class Initialized
DEBUG - 2016-05-21 11:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:50:04 --> Input Class Initialized
INFO - 2016-05-21 11:50:04 --> Language Class Initialized
INFO - 2016-05-21 11:50:04 --> Loader Class Initialized
INFO - 2016-05-21 11:50:04 --> Helper loaded: url_helper
INFO - 2016-05-21 11:50:04 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:50:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:50:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:50:04 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:50:04 --> Helper loaded: form_helper
INFO - 2016-05-21 11:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:50:04 --> Form Validation Class Initialized
INFO - 2016-05-21 11:50:04 --> Controller Class Initialized
INFO - 2016-05-21 11:50:04 --> Model Class Initialized
INFO - 2016-05-21 11:50:04 --> Database Driver Class Initialized
INFO - 2016-05-21 11:50:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:50:04 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:50:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:50:04 --> Final output sent to browser
DEBUG - 2016-05-21 11:50:04 --> Total execution time: 0.0966
INFO - 2016-05-21 11:51:04 --> Config Class Initialized
INFO - 2016-05-21 11:51:04 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:51:04 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:51:04 --> Utf8 Class Initialized
INFO - 2016-05-21 11:51:04 --> URI Class Initialized
INFO - 2016-05-21 11:51:04 --> Router Class Initialized
INFO - 2016-05-21 11:51:04 --> Output Class Initialized
INFO - 2016-05-21 11:51:04 --> Security Class Initialized
DEBUG - 2016-05-21 11:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:51:04 --> Input Class Initialized
INFO - 2016-05-21 11:51:04 --> Language Class Initialized
INFO - 2016-05-21 11:51:04 --> Loader Class Initialized
INFO - 2016-05-21 11:51:04 --> Helper loaded: url_helper
INFO - 2016-05-21 11:51:04 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:51:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:51:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:51:04 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:51:04 --> Helper loaded: form_helper
INFO - 2016-05-21 11:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:51:04 --> Form Validation Class Initialized
INFO - 2016-05-21 11:51:04 --> Controller Class Initialized
INFO - 2016-05-21 11:51:04 --> Model Class Initialized
INFO - 2016-05-21 11:51:04 --> Database Driver Class Initialized
INFO - 2016-05-21 11:51:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:51:04 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:51:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:51:04 --> Final output sent to browser
DEBUG - 2016-05-21 11:51:04 --> Total execution time: 0.0721
INFO - 2016-05-21 11:52:04 --> Config Class Initialized
INFO - 2016-05-21 11:52:04 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:52:04 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:52:04 --> Utf8 Class Initialized
INFO - 2016-05-21 11:52:04 --> URI Class Initialized
INFO - 2016-05-21 11:52:04 --> Router Class Initialized
INFO - 2016-05-21 11:52:04 --> Output Class Initialized
INFO - 2016-05-21 11:52:04 --> Security Class Initialized
DEBUG - 2016-05-21 11:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:52:04 --> Input Class Initialized
INFO - 2016-05-21 11:52:04 --> Language Class Initialized
INFO - 2016-05-21 11:52:04 --> Loader Class Initialized
INFO - 2016-05-21 11:52:04 --> Helper loaded: url_helper
INFO - 2016-05-21 11:52:04 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:52:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:52:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:52:04 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:52:04 --> Helper loaded: form_helper
INFO - 2016-05-21 11:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:52:04 --> Form Validation Class Initialized
INFO - 2016-05-21 11:52:04 --> Controller Class Initialized
INFO - 2016-05-21 11:52:04 --> Model Class Initialized
INFO - 2016-05-21 11:52:04 --> Database Driver Class Initialized
INFO - 2016-05-21 11:52:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:52:04 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:52:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:52:04 --> Final output sent to browser
DEBUG - 2016-05-21 11:52:04 --> Total execution time: 0.0792
INFO - 2016-05-21 11:53:04 --> Config Class Initialized
INFO - 2016-05-21 11:53:04 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:53:04 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:53:04 --> Utf8 Class Initialized
INFO - 2016-05-21 11:53:04 --> URI Class Initialized
INFO - 2016-05-21 11:53:04 --> Router Class Initialized
INFO - 2016-05-21 11:53:04 --> Output Class Initialized
INFO - 2016-05-21 11:53:04 --> Security Class Initialized
DEBUG - 2016-05-21 11:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:53:04 --> Input Class Initialized
INFO - 2016-05-21 11:53:04 --> Language Class Initialized
INFO - 2016-05-21 11:53:04 --> Loader Class Initialized
INFO - 2016-05-21 11:53:04 --> Helper loaded: url_helper
INFO - 2016-05-21 11:53:04 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:53:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:53:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:53:04 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:53:04 --> Helper loaded: form_helper
INFO - 2016-05-21 11:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:53:04 --> Form Validation Class Initialized
INFO - 2016-05-21 11:53:04 --> Controller Class Initialized
INFO - 2016-05-21 11:53:04 --> Model Class Initialized
INFO - 2016-05-21 11:53:04 --> Database Driver Class Initialized
INFO - 2016-05-21 11:53:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:53:04 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:53:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:53:04 --> Final output sent to browser
DEBUG - 2016-05-21 11:53:04 --> Total execution time: 0.1506
INFO - 2016-05-21 11:53:26 --> Config Class Initialized
INFO - 2016-05-21 11:53:26 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:53:26 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:53:26 --> Utf8 Class Initialized
INFO - 2016-05-21 11:53:26 --> URI Class Initialized
INFO - 2016-05-21 11:53:26 --> Router Class Initialized
INFO - 2016-05-21 11:53:26 --> Output Class Initialized
INFO - 2016-05-21 11:53:26 --> Security Class Initialized
DEBUG - 2016-05-21 11:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:53:26 --> Input Class Initialized
INFO - 2016-05-21 11:53:26 --> Language Class Initialized
INFO - 2016-05-21 11:53:26 --> Loader Class Initialized
INFO - 2016-05-21 11:53:26 --> Helper loaded: url_helper
INFO - 2016-05-21 11:53:26 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:53:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:53:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:53:26 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:53:26 --> Helper loaded: form_helper
INFO - 2016-05-21 11:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:53:26 --> Form Validation Class Initialized
INFO - 2016-05-21 11:53:26 --> Controller Class Initialized
INFO - 2016-05-21 11:53:26 --> Model Class Initialized
INFO - 2016-05-21 11:53:26 --> Database Driver Class Initialized
INFO - 2016-05-21 11:53:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:53:26 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:53:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:53:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:53:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:53:26 --> Final output sent to browser
DEBUG - 2016-05-21 11:53:26 --> Total execution time: 0.0971
INFO - 2016-05-21 11:53:27 --> Config Class Initialized
INFO - 2016-05-21 11:53:27 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:53:27 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:53:27 --> Utf8 Class Initialized
INFO - 2016-05-21 11:53:27 --> URI Class Initialized
INFO - 2016-05-21 11:53:27 --> Router Class Initialized
INFO - 2016-05-21 11:53:27 --> Output Class Initialized
INFO - 2016-05-21 11:53:27 --> Security Class Initialized
DEBUG - 2016-05-21 11:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:53:27 --> Input Class Initialized
INFO - 2016-05-21 11:53:27 --> Language Class Initialized
INFO - 2016-05-21 11:53:27 --> Loader Class Initialized
INFO - 2016-05-21 11:53:27 --> Helper loaded: url_helper
INFO - 2016-05-21 11:53:27 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:53:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:53:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:53:27 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:53:27 --> Helper loaded: form_helper
INFO - 2016-05-21 11:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:53:27 --> Form Validation Class Initialized
INFO - 2016-05-21 11:53:27 --> Controller Class Initialized
INFO - 2016-05-21 11:53:27 --> Model Class Initialized
INFO - 2016-05-21 11:53:27 --> Database Driver Class Initialized
INFO - 2016-05-21 11:53:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:53:27 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:53:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:53:27 --> Final output sent to browser
DEBUG - 2016-05-21 11:53:27 --> Total execution time: 0.1001
INFO - 2016-05-21 11:53:32 --> Config Class Initialized
INFO - 2016-05-21 11:53:32 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:53:32 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:53:32 --> Utf8 Class Initialized
INFO - 2016-05-21 11:53:32 --> URI Class Initialized
INFO - 2016-05-21 11:53:32 --> Router Class Initialized
INFO - 2016-05-21 11:53:32 --> Output Class Initialized
INFO - 2016-05-21 11:53:32 --> Security Class Initialized
DEBUG - 2016-05-21 11:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:53:32 --> Input Class Initialized
INFO - 2016-05-21 11:53:32 --> Language Class Initialized
INFO - 2016-05-21 11:53:32 --> Loader Class Initialized
INFO - 2016-05-21 11:53:32 --> Helper loaded: url_helper
INFO - 2016-05-21 11:53:32 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:53:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:53:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:53:32 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:53:32 --> Helper loaded: form_helper
INFO - 2016-05-21 11:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:53:32 --> Form Validation Class Initialized
INFO - 2016-05-21 11:53:32 --> Controller Class Initialized
INFO - 2016-05-21 11:53:32 --> Model Class Initialized
INFO - 2016-05-21 11:53:32 --> Database Driver Class Initialized
INFO - 2016-05-21 11:53:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:53:32 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:53:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:53:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:53:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:53:32 --> Final output sent to browser
DEBUG - 2016-05-21 11:53:32 --> Total execution time: 0.0963
INFO - 2016-05-21 11:53:33 --> Config Class Initialized
INFO - 2016-05-21 11:53:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:53:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:53:33 --> Utf8 Class Initialized
INFO - 2016-05-21 11:53:33 --> URI Class Initialized
INFO - 2016-05-21 11:53:33 --> Router Class Initialized
INFO - 2016-05-21 11:53:33 --> Output Class Initialized
INFO - 2016-05-21 11:53:33 --> Security Class Initialized
DEBUG - 2016-05-21 11:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:53:33 --> Input Class Initialized
INFO - 2016-05-21 11:53:33 --> Language Class Initialized
INFO - 2016-05-21 11:53:33 --> Loader Class Initialized
INFO - 2016-05-21 11:53:33 --> Helper loaded: url_helper
INFO - 2016-05-21 11:53:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:53:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:53:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:53:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:53:33 --> Helper loaded: form_helper
INFO - 2016-05-21 11:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:53:33 --> Form Validation Class Initialized
INFO - 2016-05-21 11:53:33 --> Controller Class Initialized
INFO - 2016-05-21 11:53:33 --> Model Class Initialized
INFO - 2016-05-21 11:53:33 --> Database Driver Class Initialized
INFO - 2016-05-21 11:53:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:53:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:53:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:53:33 --> Final output sent to browser
DEBUG - 2016-05-21 11:53:33 --> Total execution time: 0.0906
INFO - 2016-05-21 11:54:05 --> Config Class Initialized
INFO - 2016-05-21 11:54:05 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:54:05 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:54:05 --> Utf8 Class Initialized
INFO - 2016-05-21 11:54:05 --> URI Class Initialized
INFO - 2016-05-21 11:54:05 --> Router Class Initialized
INFO - 2016-05-21 11:54:05 --> Output Class Initialized
INFO - 2016-05-21 11:54:05 --> Security Class Initialized
DEBUG - 2016-05-21 11:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:54:05 --> Input Class Initialized
INFO - 2016-05-21 11:54:05 --> Language Class Initialized
INFO - 2016-05-21 11:54:05 --> Loader Class Initialized
INFO - 2016-05-21 11:54:05 --> Helper loaded: url_helper
INFO - 2016-05-21 11:54:05 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:54:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:54:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:54:05 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:54:05 --> Helper loaded: form_helper
INFO - 2016-05-21 11:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:54:05 --> Form Validation Class Initialized
INFO - 2016-05-21 11:54:05 --> Controller Class Initialized
INFO - 2016-05-21 11:54:05 --> Model Class Initialized
INFO - 2016-05-21 11:54:05 --> Database Driver Class Initialized
INFO - 2016-05-21 11:54:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:54:05 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:54:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:54:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 11:54:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:54:05 --> Final output sent to browser
DEBUG - 2016-05-21 11:54:05 --> Total execution time: 0.0802
INFO - 2016-05-21 11:54:05 --> Config Class Initialized
INFO - 2016-05-21 11:54:05 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:54:05 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:54:05 --> Utf8 Class Initialized
INFO - 2016-05-21 11:54:05 --> URI Class Initialized
INFO - 2016-05-21 11:54:05 --> Router Class Initialized
INFO - 2016-05-21 11:54:05 --> Output Class Initialized
INFO - 2016-05-21 11:54:05 --> Security Class Initialized
DEBUG - 2016-05-21 11:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:54:05 --> Input Class Initialized
INFO - 2016-05-21 11:54:05 --> Language Class Initialized
INFO - 2016-05-21 11:54:05 --> Loader Class Initialized
INFO - 2016-05-21 11:54:05 --> Helper loaded: url_helper
INFO - 2016-05-21 11:54:05 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:54:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:54:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:54:05 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:54:05 --> Helper loaded: form_helper
INFO - 2016-05-21 11:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:54:05 --> Form Validation Class Initialized
INFO - 2016-05-21 11:54:05 --> Controller Class Initialized
INFO - 2016-05-21 11:54:05 --> Model Class Initialized
INFO - 2016-05-21 11:54:05 --> Database Driver Class Initialized
INFO - 2016-05-21 11:54:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:54:05 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:54:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:54:05 --> Final output sent to browser
DEBUG - 2016-05-21 11:54:05 --> Total execution time: 0.0889
INFO - 2016-05-21 11:54:07 --> Config Class Initialized
INFO - 2016-05-21 11:54:07 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:54:07 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:54:07 --> Utf8 Class Initialized
INFO - 2016-05-21 11:54:07 --> URI Class Initialized
INFO - 2016-05-21 11:54:07 --> Router Class Initialized
INFO - 2016-05-21 11:54:07 --> Output Class Initialized
INFO - 2016-05-21 11:54:07 --> Security Class Initialized
DEBUG - 2016-05-21 11:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:54:07 --> Input Class Initialized
INFO - 2016-05-21 11:54:07 --> Language Class Initialized
INFO - 2016-05-21 11:54:07 --> Loader Class Initialized
INFO - 2016-05-21 11:54:07 --> Helper loaded: url_helper
INFO - 2016-05-21 11:54:07 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:54:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:54:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:54:07 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:54:07 --> Helper loaded: form_helper
INFO - 2016-05-21 11:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:54:07 --> Form Validation Class Initialized
INFO - 2016-05-21 11:54:07 --> Controller Class Initialized
INFO - 2016-05-21 11:54:07 --> Model Class Initialized
INFO - 2016-05-21 11:54:07 --> Database Driver Class Initialized
INFO - 2016-05-21 11:54:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:54:07 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:54:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:54:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:54:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:54:07 --> Final output sent to browser
DEBUG - 2016-05-21 11:54:07 --> Total execution time: 0.0963
INFO - 2016-05-21 11:54:07 --> Config Class Initialized
INFO - 2016-05-21 11:54:07 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:54:07 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:54:07 --> Utf8 Class Initialized
INFO - 2016-05-21 11:54:07 --> URI Class Initialized
INFO - 2016-05-21 11:54:07 --> Router Class Initialized
INFO - 2016-05-21 11:54:07 --> Output Class Initialized
INFO - 2016-05-21 11:54:07 --> Security Class Initialized
DEBUG - 2016-05-21 11:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:54:07 --> Input Class Initialized
INFO - 2016-05-21 11:54:07 --> Language Class Initialized
INFO - 2016-05-21 11:54:07 --> Loader Class Initialized
INFO - 2016-05-21 11:54:07 --> Helper loaded: url_helper
INFO - 2016-05-21 11:54:07 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:54:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:54:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:54:07 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:54:07 --> Helper loaded: form_helper
INFO - 2016-05-21 11:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:54:07 --> Form Validation Class Initialized
INFO - 2016-05-21 11:54:07 --> Controller Class Initialized
INFO - 2016-05-21 11:54:07 --> Model Class Initialized
INFO - 2016-05-21 11:54:07 --> Database Driver Class Initialized
INFO - 2016-05-21 11:54:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:54:07 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:54:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:54:07 --> Final output sent to browser
DEBUG - 2016-05-21 11:54:07 --> Total execution time: 0.0989
INFO - 2016-05-21 11:54:17 --> Config Class Initialized
INFO - 2016-05-21 11:54:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:54:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:54:17 --> Utf8 Class Initialized
INFO - 2016-05-21 11:54:17 --> URI Class Initialized
INFO - 2016-05-21 11:54:17 --> Router Class Initialized
INFO - 2016-05-21 11:54:17 --> Output Class Initialized
INFO - 2016-05-21 11:54:17 --> Security Class Initialized
DEBUG - 2016-05-21 11:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:54:17 --> Input Class Initialized
INFO - 2016-05-21 11:54:17 --> Language Class Initialized
INFO - 2016-05-21 11:54:17 --> Loader Class Initialized
INFO - 2016-05-21 11:54:17 --> Helper loaded: url_helper
INFO - 2016-05-21 11:54:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:54:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:54:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:54:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:54:17 --> Helper loaded: form_helper
INFO - 2016-05-21 11:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:54:17 --> Form Validation Class Initialized
INFO - 2016-05-21 11:54:17 --> Controller Class Initialized
INFO - 2016-05-21 11:54:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-21 11:54:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:54:17 --> Final output sent to browser
DEBUG - 2016-05-21 11:54:17 --> Total execution time: 0.0542
INFO - 2016-05-21 11:54:17 --> Config Class Initialized
INFO - 2016-05-21 11:54:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:54:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:54:17 --> Utf8 Class Initialized
INFO - 2016-05-21 11:54:17 --> URI Class Initialized
INFO - 2016-05-21 11:54:17 --> Router Class Initialized
INFO - 2016-05-21 11:54:17 --> Output Class Initialized
INFO - 2016-05-21 11:54:17 --> Security Class Initialized
DEBUG - 2016-05-21 11:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:54:17 --> Input Class Initialized
INFO - 2016-05-21 11:54:17 --> Language Class Initialized
INFO - 2016-05-21 11:54:17 --> Loader Class Initialized
INFO - 2016-05-21 11:54:17 --> Helper loaded: url_helper
INFO - 2016-05-21 11:54:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:54:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:54:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:54:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:54:17 --> Helper loaded: form_helper
INFO - 2016-05-21 11:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:54:17 --> Form Validation Class Initialized
INFO - 2016-05-21 11:54:17 --> Controller Class Initialized
INFO - 2016-05-21 11:54:17 --> Model Class Initialized
INFO - 2016-05-21 11:54:17 --> Database Driver Class Initialized
INFO - 2016-05-21 11:54:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:54:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:54:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:54:17 --> Final output sent to browser
DEBUG - 2016-05-21 11:54:17 --> Total execution time: 0.1262
INFO - 2016-05-21 11:54:19 --> Config Class Initialized
INFO - 2016-05-21 11:54:19 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:54:19 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:54:19 --> Utf8 Class Initialized
INFO - 2016-05-21 11:54:19 --> URI Class Initialized
INFO - 2016-05-21 11:54:19 --> Router Class Initialized
INFO - 2016-05-21 11:54:19 --> Output Class Initialized
INFO - 2016-05-21 11:54:19 --> Security Class Initialized
DEBUG - 2016-05-21 11:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:54:19 --> Input Class Initialized
INFO - 2016-05-21 11:54:19 --> Language Class Initialized
INFO - 2016-05-21 11:54:19 --> Loader Class Initialized
INFO - 2016-05-21 11:54:19 --> Helper loaded: url_helper
INFO - 2016-05-21 11:54:19 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:54:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:54:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:54:19 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:54:19 --> Helper loaded: form_helper
INFO - 2016-05-21 11:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:54:19 --> Form Validation Class Initialized
INFO - 2016-05-21 11:54:19 --> Controller Class Initialized
INFO - 2016-05-21 11:54:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-21 11:54:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 11:54:19 --> Final output sent to browser
DEBUG - 2016-05-21 11:54:19 --> Total execution time: 0.0839
INFO - 2016-05-21 11:54:19 --> Config Class Initialized
INFO - 2016-05-21 11:54:19 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:54:19 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:54:19 --> Utf8 Class Initialized
INFO - 2016-05-21 11:54:19 --> URI Class Initialized
INFO - 2016-05-21 11:54:19 --> Router Class Initialized
INFO - 2016-05-21 11:54:19 --> Output Class Initialized
INFO - 2016-05-21 11:54:19 --> Security Class Initialized
DEBUG - 2016-05-21 11:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:54:19 --> Input Class Initialized
INFO - 2016-05-21 11:54:19 --> Language Class Initialized
INFO - 2016-05-21 11:54:19 --> Loader Class Initialized
INFO - 2016-05-21 11:54:19 --> Helper loaded: url_helper
INFO - 2016-05-21 11:54:19 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:54:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:54:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:54:19 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:54:19 --> Helper loaded: form_helper
INFO - 2016-05-21 11:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:54:19 --> Form Validation Class Initialized
INFO - 2016-05-21 11:54:19 --> Controller Class Initialized
INFO - 2016-05-21 11:54:19 --> Model Class Initialized
INFO - 2016-05-21 11:54:19 --> Database Driver Class Initialized
INFO - 2016-05-21 11:54:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:54:19 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:54:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:54:19 --> Final output sent to browser
DEBUG - 2016-05-21 11:54:19 --> Total execution time: 0.0895
INFO - 2016-05-21 11:54:20 --> Config Class Initialized
INFO - 2016-05-21 11:54:20 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:54:20 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:54:20 --> Utf8 Class Initialized
INFO - 2016-05-21 11:54:20 --> URI Class Initialized
INFO - 2016-05-21 11:54:20 --> Router Class Initialized
INFO - 2016-05-21 11:54:20 --> Output Class Initialized
INFO - 2016-05-21 11:54:20 --> Security Class Initialized
DEBUG - 2016-05-21 11:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:54:20 --> Input Class Initialized
INFO - 2016-05-21 11:54:20 --> Language Class Initialized
INFO - 2016-05-21 11:54:20 --> Loader Class Initialized
INFO - 2016-05-21 11:54:20 --> Helper loaded: url_helper
INFO - 2016-05-21 11:54:20 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:54:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:54:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:54:20 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:54:20 --> Helper loaded: form_helper
INFO - 2016-05-21 11:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:54:20 --> Form Validation Class Initialized
INFO - 2016-05-21 11:54:20 --> Controller Class Initialized
INFO - 2016-05-21 11:54:20 --> Config Class Initialized
INFO - 2016-05-21 11:54:20 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:54:20 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:54:20 --> Utf8 Class Initialized
INFO - 2016-05-21 11:54:20 --> URI Class Initialized
INFO - 2016-05-21 11:54:20 --> Router Class Initialized
INFO - 2016-05-21 11:54:20 --> Output Class Initialized
INFO - 2016-05-21 11:54:20 --> Security Class Initialized
DEBUG - 2016-05-21 11:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:54:20 --> Input Class Initialized
INFO - 2016-05-21 11:54:20 --> Language Class Initialized
INFO - 2016-05-21 11:54:20 --> Loader Class Initialized
INFO - 2016-05-21 11:54:20 --> Helper loaded: url_helper
INFO - 2016-05-21 11:54:20 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:54:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:54:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:54:20 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:54:20 --> Helper loaded: form_helper
INFO - 2016-05-21 11:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:54:20 --> Form Validation Class Initialized
INFO - 2016-05-21 11:54:20 --> Controller Class Initialized
INFO - 2016-05-21 11:54:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-21 11:54:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 11:54:20 --> Final output sent to browser
DEBUG - 2016-05-21 11:54:20 --> Total execution time: 0.0685
INFO - 2016-05-21 11:54:21 --> Config Class Initialized
INFO - 2016-05-21 11:54:21 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:54:21 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:54:21 --> Utf8 Class Initialized
INFO - 2016-05-21 11:54:21 --> URI Class Initialized
INFO - 2016-05-21 11:54:21 --> Router Class Initialized
INFO - 2016-05-21 11:54:21 --> Output Class Initialized
INFO - 2016-05-21 11:54:21 --> Security Class Initialized
DEBUG - 2016-05-21 11:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:54:21 --> Input Class Initialized
INFO - 2016-05-21 11:54:21 --> Language Class Initialized
INFO - 2016-05-21 11:54:21 --> Loader Class Initialized
INFO - 2016-05-21 11:54:21 --> Helper loaded: url_helper
INFO - 2016-05-21 11:54:21 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:54:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:54:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:54:21 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:54:21 --> Helper loaded: form_helper
INFO - 2016-05-21 11:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:54:21 --> Form Validation Class Initialized
INFO - 2016-05-21 11:54:21 --> Controller Class Initialized
INFO - 2016-05-21 11:54:21 --> Model Class Initialized
INFO - 2016-05-21 11:54:21 --> Database Driver Class Initialized
INFO - 2016-05-21 11:54:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:54:21 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:54:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:54:21 --> Final output sent to browser
DEBUG - 2016-05-21 11:54:21 --> Total execution time: 0.1174
INFO - 2016-05-21 11:54:23 --> Config Class Initialized
INFO - 2016-05-21 11:54:23 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:54:23 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:54:23 --> Utf8 Class Initialized
INFO - 2016-05-21 11:54:23 --> URI Class Initialized
INFO - 2016-05-21 11:54:23 --> Router Class Initialized
INFO - 2016-05-21 11:54:23 --> Output Class Initialized
INFO - 2016-05-21 11:54:23 --> Security Class Initialized
DEBUG - 2016-05-21 11:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:54:23 --> Input Class Initialized
INFO - 2016-05-21 11:54:23 --> Language Class Initialized
INFO - 2016-05-21 11:54:23 --> Loader Class Initialized
INFO - 2016-05-21 11:54:23 --> Helper loaded: url_helper
INFO - 2016-05-21 11:54:23 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:54:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:54:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:54:23 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:54:23 --> Helper loaded: form_helper
INFO - 2016-05-21 11:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:54:23 --> Form Validation Class Initialized
INFO - 2016-05-21 11:54:23 --> Controller Class Initialized
INFO - 2016-05-21 11:54:23 --> Model Class Initialized
INFO - 2016-05-21 11:54:23 --> Database Driver Class Initialized
INFO - 2016-05-21 11:54:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:54:23 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:54:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:54:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:54:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 11:54:23 --> Final output sent to browser
DEBUG - 2016-05-21 11:54:23 --> Total execution time: 0.0892
INFO - 2016-05-21 11:54:23 --> Config Class Initialized
INFO - 2016-05-21 11:54:23 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:54:23 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:54:23 --> Utf8 Class Initialized
INFO - 2016-05-21 11:54:23 --> URI Class Initialized
INFO - 2016-05-21 11:54:23 --> Router Class Initialized
INFO - 2016-05-21 11:54:23 --> Output Class Initialized
INFO - 2016-05-21 11:54:23 --> Security Class Initialized
DEBUG - 2016-05-21 11:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:54:23 --> Input Class Initialized
INFO - 2016-05-21 11:54:23 --> Language Class Initialized
INFO - 2016-05-21 11:54:23 --> Loader Class Initialized
INFO - 2016-05-21 11:54:23 --> Helper loaded: url_helper
INFO - 2016-05-21 11:54:23 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:54:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:54:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:54:23 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:54:23 --> Helper loaded: form_helper
INFO - 2016-05-21 11:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:54:23 --> Form Validation Class Initialized
INFO - 2016-05-21 11:54:23 --> Controller Class Initialized
INFO - 2016-05-21 11:54:23 --> Model Class Initialized
INFO - 2016-05-21 11:54:23 --> Database Driver Class Initialized
INFO - 2016-05-21 11:54:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:54:23 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:54:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:54:23 --> Final output sent to browser
DEBUG - 2016-05-21 11:54:23 --> Total execution time: 0.1113
INFO - 2016-05-21 11:54:54 --> Config Class Initialized
INFO - 2016-05-21 11:54:54 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:54:54 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:54:54 --> Utf8 Class Initialized
INFO - 2016-05-21 11:54:54 --> URI Class Initialized
INFO - 2016-05-21 11:54:54 --> Router Class Initialized
INFO - 2016-05-21 11:54:54 --> Output Class Initialized
INFO - 2016-05-21 11:54:54 --> Security Class Initialized
DEBUG - 2016-05-21 11:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:54:54 --> Input Class Initialized
INFO - 2016-05-21 11:54:54 --> Language Class Initialized
INFO - 2016-05-21 11:54:54 --> Loader Class Initialized
INFO - 2016-05-21 11:54:54 --> Helper loaded: url_helper
INFO - 2016-05-21 11:54:54 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:54:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:54:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:54:54 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:54:54 --> Helper loaded: form_helper
INFO - 2016-05-21 11:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:54:54 --> Form Validation Class Initialized
INFO - 2016-05-21 11:54:54 --> Controller Class Initialized
INFO - 2016-05-21 11:54:54 --> Model Class Initialized
INFO - 2016-05-21 11:54:54 --> Database Driver Class Initialized
INFO - 2016-05-21 11:54:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:54:54 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:54:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:54:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:54:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 11:54:54 --> Final output sent to browser
DEBUG - 2016-05-21 11:54:54 --> Total execution time: 0.1461
INFO - 2016-05-21 11:54:55 --> Config Class Initialized
INFO - 2016-05-21 11:54:55 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:54:55 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:54:55 --> Utf8 Class Initialized
INFO - 2016-05-21 11:54:55 --> URI Class Initialized
INFO - 2016-05-21 11:54:55 --> Router Class Initialized
INFO - 2016-05-21 11:54:55 --> Output Class Initialized
INFO - 2016-05-21 11:54:55 --> Security Class Initialized
DEBUG - 2016-05-21 11:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:54:55 --> Input Class Initialized
INFO - 2016-05-21 11:54:55 --> Language Class Initialized
INFO - 2016-05-21 11:54:55 --> Loader Class Initialized
INFO - 2016-05-21 11:54:55 --> Helper loaded: url_helper
INFO - 2016-05-21 11:54:55 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:54:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:54:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:54:55 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:54:55 --> Helper loaded: form_helper
INFO - 2016-05-21 11:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:54:55 --> Form Validation Class Initialized
INFO - 2016-05-21 11:54:55 --> Controller Class Initialized
INFO - 2016-05-21 11:54:55 --> Model Class Initialized
INFO - 2016-05-21 11:54:55 --> Database Driver Class Initialized
INFO - 2016-05-21 11:54:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:54:55 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:54:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:54:55 --> Final output sent to browser
DEBUG - 2016-05-21 11:54:55 --> Total execution time: 0.0955
INFO - 2016-05-21 11:55:22 --> Config Class Initialized
INFO - 2016-05-21 11:55:22 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:55:22 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:55:22 --> Utf8 Class Initialized
INFO - 2016-05-21 11:55:22 --> URI Class Initialized
INFO - 2016-05-21 11:55:22 --> Router Class Initialized
INFO - 2016-05-21 11:55:22 --> Output Class Initialized
INFO - 2016-05-21 11:55:22 --> Security Class Initialized
DEBUG - 2016-05-21 11:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:55:22 --> Input Class Initialized
INFO - 2016-05-21 11:55:22 --> Language Class Initialized
INFO - 2016-05-21 11:55:22 --> Loader Class Initialized
INFO - 2016-05-21 11:55:22 --> Helper loaded: url_helper
INFO - 2016-05-21 11:55:22 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:55:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:55:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:55:22 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:55:22 --> Helper loaded: form_helper
INFO - 2016-05-21 11:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:55:22 --> Form Validation Class Initialized
INFO - 2016-05-21 11:55:22 --> Controller Class Initialized
INFO - 2016-05-21 11:55:22 --> Model Class Initialized
INFO - 2016-05-21 11:55:22 --> Database Driver Class Initialized
INFO - 2016-05-21 11:55:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:55:22 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:55:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:55:22 --> Final output sent to browser
DEBUG - 2016-05-21 11:55:22 --> Total execution time: 0.0702
INFO - 2016-05-21 11:55:26 --> Config Class Initialized
INFO - 2016-05-21 11:55:26 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:55:26 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:55:26 --> Utf8 Class Initialized
INFO - 2016-05-21 11:55:26 --> URI Class Initialized
INFO - 2016-05-21 11:55:26 --> Router Class Initialized
INFO - 2016-05-21 11:55:26 --> Output Class Initialized
INFO - 2016-05-21 11:55:26 --> Security Class Initialized
DEBUG - 2016-05-21 11:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:55:26 --> Input Class Initialized
INFO - 2016-05-21 11:55:26 --> Language Class Initialized
INFO - 2016-05-21 11:55:26 --> Loader Class Initialized
INFO - 2016-05-21 11:55:26 --> Helper loaded: url_helper
INFO - 2016-05-21 11:55:26 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:55:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:55:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:55:26 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:55:26 --> Helper loaded: form_helper
INFO - 2016-05-21 11:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:55:26 --> Form Validation Class Initialized
INFO - 2016-05-21 11:55:26 --> Controller Class Initialized
INFO - 2016-05-21 11:55:26 --> Model Class Initialized
INFO - 2016-05-21 11:55:26 --> Database Driver Class Initialized
INFO - 2016-05-21 11:55:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:55:26 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:55:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:55:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:55:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 11:55:26 --> Final output sent to browser
DEBUG - 2016-05-21 11:55:26 --> Total execution time: 0.1006
INFO - 2016-05-21 11:55:27 --> Config Class Initialized
INFO - 2016-05-21 11:55:27 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:55:27 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:55:27 --> Utf8 Class Initialized
INFO - 2016-05-21 11:55:27 --> URI Class Initialized
INFO - 2016-05-21 11:55:27 --> Router Class Initialized
INFO - 2016-05-21 11:55:27 --> Output Class Initialized
INFO - 2016-05-21 11:55:27 --> Security Class Initialized
DEBUG - 2016-05-21 11:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:55:27 --> Input Class Initialized
INFO - 2016-05-21 11:55:27 --> Language Class Initialized
INFO - 2016-05-21 11:55:27 --> Loader Class Initialized
INFO - 2016-05-21 11:55:27 --> Helper loaded: url_helper
INFO - 2016-05-21 11:55:27 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:55:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:55:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:55:27 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:55:27 --> Helper loaded: form_helper
INFO - 2016-05-21 11:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:55:27 --> Form Validation Class Initialized
INFO - 2016-05-21 11:55:27 --> Controller Class Initialized
INFO - 2016-05-21 11:55:27 --> Model Class Initialized
INFO - 2016-05-21 11:55:27 --> Database Driver Class Initialized
INFO - 2016-05-21 11:55:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:55:27 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:55:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:55:27 --> Final output sent to browser
DEBUG - 2016-05-21 11:55:27 --> Total execution time: 0.0934
INFO - 2016-05-21 11:55:50 --> Config Class Initialized
INFO - 2016-05-21 11:55:50 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:55:50 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:55:50 --> Utf8 Class Initialized
INFO - 2016-05-21 11:55:50 --> URI Class Initialized
INFO - 2016-05-21 11:55:50 --> Router Class Initialized
INFO - 2016-05-21 11:55:50 --> Output Class Initialized
INFO - 2016-05-21 11:55:50 --> Security Class Initialized
DEBUG - 2016-05-21 11:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:55:50 --> Input Class Initialized
INFO - 2016-05-21 11:55:50 --> Language Class Initialized
INFO - 2016-05-21 11:55:50 --> Loader Class Initialized
INFO - 2016-05-21 11:55:50 --> Helper loaded: url_helper
INFO - 2016-05-21 11:55:50 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:55:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:55:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:55:50 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:55:50 --> Helper loaded: form_helper
INFO - 2016-05-21 11:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:55:50 --> Form Validation Class Initialized
INFO - 2016-05-21 11:55:50 --> Controller Class Initialized
INFO - 2016-05-21 11:55:50 --> Model Class Initialized
INFO - 2016-05-21 11:55:50 --> Database Driver Class Initialized
INFO - 2016-05-21 11:55:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:55:50 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:55:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-21 11:55:50 --> Severity: Notice --> Undefined index: descuento C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php 12
INFO - 2016-05-21 11:55:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:55:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 11:55:50 --> Final output sent to browser
DEBUG - 2016-05-21 11:55:50 --> Total execution time: 0.0915
INFO - 2016-05-21 11:55:50 --> Config Class Initialized
INFO - 2016-05-21 11:55:50 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:55:50 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:55:50 --> Utf8 Class Initialized
INFO - 2016-05-21 11:55:50 --> URI Class Initialized
INFO - 2016-05-21 11:55:50 --> Router Class Initialized
INFO - 2016-05-21 11:55:50 --> Output Class Initialized
INFO - 2016-05-21 11:55:50 --> Security Class Initialized
DEBUG - 2016-05-21 11:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:55:50 --> Input Class Initialized
INFO - 2016-05-21 11:55:50 --> Language Class Initialized
INFO - 2016-05-21 11:55:50 --> Loader Class Initialized
INFO - 2016-05-21 11:55:50 --> Helper loaded: url_helper
INFO - 2016-05-21 11:55:50 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:55:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:55:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:55:50 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:55:50 --> Helper loaded: form_helper
INFO - 2016-05-21 11:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:55:50 --> Form Validation Class Initialized
INFO - 2016-05-21 11:55:50 --> Controller Class Initialized
INFO - 2016-05-21 11:55:50 --> Model Class Initialized
INFO - 2016-05-21 11:55:50 --> Database Driver Class Initialized
INFO - 2016-05-21 11:55:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:55:50 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:55:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:55:50 --> Final output sent to browser
DEBUG - 2016-05-21 11:55:50 --> Total execution time: 0.0882
INFO - 2016-05-21 11:56:03 --> Config Class Initialized
INFO - 2016-05-21 11:56:03 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:56:03 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:56:03 --> Utf8 Class Initialized
INFO - 2016-05-21 11:56:03 --> URI Class Initialized
INFO - 2016-05-21 11:56:03 --> Router Class Initialized
INFO - 2016-05-21 11:56:03 --> Output Class Initialized
INFO - 2016-05-21 11:56:03 --> Security Class Initialized
DEBUG - 2016-05-21 11:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:56:03 --> Input Class Initialized
INFO - 2016-05-21 11:56:03 --> Language Class Initialized
INFO - 2016-05-21 11:56:03 --> Loader Class Initialized
INFO - 2016-05-21 11:56:03 --> Helper loaded: url_helper
INFO - 2016-05-21 11:56:03 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:56:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:56:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:56:03 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:56:03 --> Helper loaded: form_helper
INFO - 2016-05-21 11:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:56:03 --> Form Validation Class Initialized
INFO - 2016-05-21 11:56:03 --> Controller Class Initialized
INFO - 2016-05-21 11:56:03 --> Model Class Initialized
INFO - 2016-05-21 11:56:03 --> Database Driver Class Initialized
INFO - 2016-05-21 11:56:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:56:03 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:56:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:56:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:56:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 11:56:03 --> Final output sent to browser
DEBUG - 2016-05-21 11:56:03 --> Total execution time: 0.0837
INFO - 2016-05-21 11:56:03 --> Config Class Initialized
INFO - 2016-05-21 11:56:03 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:56:03 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:56:03 --> Utf8 Class Initialized
INFO - 2016-05-21 11:56:03 --> URI Class Initialized
INFO - 2016-05-21 11:56:03 --> Router Class Initialized
INFO - 2016-05-21 11:56:03 --> Output Class Initialized
INFO - 2016-05-21 11:56:03 --> Security Class Initialized
DEBUG - 2016-05-21 11:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:56:03 --> Input Class Initialized
INFO - 2016-05-21 11:56:03 --> Language Class Initialized
INFO - 2016-05-21 11:56:03 --> Loader Class Initialized
INFO - 2016-05-21 11:56:03 --> Helper loaded: url_helper
INFO - 2016-05-21 11:56:03 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:56:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:56:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:56:03 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:56:03 --> Helper loaded: form_helper
INFO - 2016-05-21 11:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:56:03 --> Form Validation Class Initialized
INFO - 2016-05-21 11:56:03 --> Controller Class Initialized
INFO - 2016-05-21 11:56:03 --> Model Class Initialized
INFO - 2016-05-21 11:56:03 --> Database Driver Class Initialized
INFO - 2016-05-21 11:56:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:56:03 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:56:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:56:03 --> Final output sent to browser
DEBUG - 2016-05-21 11:56:03 --> Total execution time: 0.0894
INFO - 2016-05-21 11:56:22 --> Config Class Initialized
INFO - 2016-05-21 11:56:22 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:56:22 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:56:22 --> Utf8 Class Initialized
INFO - 2016-05-21 11:56:22 --> URI Class Initialized
INFO - 2016-05-21 11:56:22 --> Router Class Initialized
INFO - 2016-05-21 11:56:22 --> Output Class Initialized
INFO - 2016-05-21 11:56:22 --> Security Class Initialized
DEBUG - 2016-05-21 11:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:56:22 --> Input Class Initialized
INFO - 2016-05-21 11:56:22 --> Language Class Initialized
INFO - 2016-05-21 11:56:22 --> Loader Class Initialized
INFO - 2016-05-21 11:56:22 --> Helper loaded: url_helper
INFO - 2016-05-21 11:56:22 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:56:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:56:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:56:22 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:56:22 --> Helper loaded: form_helper
INFO - 2016-05-21 11:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:56:22 --> Form Validation Class Initialized
INFO - 2016-05-21 11:56:22 --> Controller Class Initialized
INFO - 2016-05-21 11:56:22 --> Model Class Initialized
INFO - 2016-05-21 11:56:22 --> Database Driver Class Initialized
INFO - 2016-05-21 11:56:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:56:22 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:56:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:56:22 --> Final output sent to browser
DEBUG - 2016-05-21 11:56:22 --> Total execution time: 0.0739
INFO - 2016-05-21 11:56:24 --> Config Class Initialized
INFO - 2016-05-21 11:56:24 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:56:24 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:56:24 --> Utf8 Class Initialized
INFO - 2016-05-21 11:56:24 --> URI Class Initialized
INFO - 2016-05-21 11:56:24 --> Router Class Initialized
INFO - 2016-05-21 11:56:24 --> Output Class Initialized
INFO - 2016-05-21 11:56:24 --> Security Class Initialized
DEBUG - 2016-05-21 11:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:56:24 --> Input Class Initialized
INFO - 2016-05-21 11:56:24 --> Language Class Initialized
INFO - 2016-05-21 11:56:24 --> Loader Class Initialized
INFO - 2016-05-21 11:56:24 --> Helper loaded: url_helper
INFO - 2016-05-21 11:56:24 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:56:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:56:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:56:24 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:56:24 --> Helper loaded: form_helper
INFO - 2016-05-21 11:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:56:24 --> Form Validation Class Initialized
INFO - 2016-05-21 11:56:24 --> Controller Class Initialized
INFO - 2016-05-21 11:56:24 --> Model Class Initialized
INFO - 2016-05-21 11:56:24 --> Database Driver Class Initialized
INFO - 2016-05-21 11:56:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:56:24 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:56:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:56:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:56:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 11:56:24 --> Final output sent to browser
DEBUG - 2016-05-21 11:56:24 --> Total execution time: 0.1144
INFO - 2016-05-21 11:56:25 --> Config Class Initialized
INFO - 2016-05-21 11:56:25 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:56:25 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:56:25 --> Utf8 Class Initialized
INFO - 2016-05-21 11:56:25 --> URI Class Initialized
INFO - 2016-05-21 11:56:25 --> Router Class Initialized
INFO - 2016-05-21 11:56:25 --> Output Class Initialized
INFO - 2016-05-21 11:56:25 --> Security Class Initialized
DEBUG - 2016-05-21 11:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:56:25 --> Input Class Initialized
INFO - 2016-05-21 11:56:25 --> Language Class Initialized
INFO - 2016-05-21 11:56:25 --> Loader Class Initialized
INFO - 2016-05-21 11:56:25 --> Helper loaded: url_helper
INFO - 2016-05-21 11:56:25 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:56:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:56:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:56:25 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:56:25 --> Helper loaded: form_helper
INFO - 2016-05-21 11:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:56:25 --> Form Validation Class Initialized
INFO - 2016-05-21 11:56:25 --> Controller Class Initialized
INFO - 2016-05-21 11:56:25 --> Model Class Initialized
INFO - 2016-05-21 11:56:25 --> Database Driver Class Initialized
INFO - 2016-05-21 11:56:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:56:25 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:56:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:56:25 --> Final output sent to browser
DEBUG - 2016-05-21 11:56:25 --> Total execution time: 0.1018
INFO - 2016-05-21 11:56:32 --> Config Class Initialized
INFO - 2016-05-21 11:56:32 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:56:32 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:56:32 --> Utf8 Class Initialized
INFO - 2016-05-21 11:56:32 --> URI Class Initialized
INFO - 2016-05-21 11:56:32 --> Router Class Initialized
INFO - 2016-05-21 11:56:32 --> Output Class Initialized
INFO - 2016-05-21 11:56:32 --> Security Class Initialized
DEBUG - 2016-05-21 11:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:56:32 --> Input Class Initialized
INFO - 2016-05-21 11:56:32 --> Language Class Initialized
INFO - 2016-05-21 11:56:32 --> Loader Class Initialized
INFO - 2016-05-21 11:56:32 --> Helper loaded: url_helper
INFO - 2016-05-21 11:56:32 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:56:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:56:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:56:32 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:56:32 --> Helper loaded: form_helper
INFO - 2016-05-21 11:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:56:32 --> Form Validation Class Initialized
INFO - 2016-05-21 11:56:32 --> Controller Class Initialized
INFO - 2016-05-21 11:56:32 --> Model Class Initialized
INFO - 2016-05-21 11:56:32 --> Database Driver Class Initialized
INFO - 2016-05-21 11:56:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:56:32 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:56:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:56:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 11:56:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 11:56:32 --> Final output sent to browser
DEBUG - 2016-05-21 11:56:32 --> Total execution time: 0.0878
INFO - 2016-05-21 11:56:32 --> Config Class Initialized
INFO - 2016-05-21 11:56:32 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:56:32 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:56:32 --> Utf8 Class Initialized
INFO - 2016-05-21 11:56:32 --> URI Class Initialized
INFO - 2016-05-21 11:56:32 --> Router Class Initialized
INFO - 2016-05-21 11:56:32 --> Output Class Initialized
INFO - 2016-05-21 11:56:32 --> Security Class Initialized
DEBUG - 2016-05-21 11:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:56:32 --> Input Class Initialized
INFO - 2016-05-21 11:56:32 --> Language Class Initialized
INFO - 2016-05-21 11:56:32 --> Loader Class Initialized
INFO - 2016-05-21 11:56:32 --> Helper loaded: url_helper
INFO - 2016-05-21 11:56:32 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:56:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:56:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:56:32 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:56:32 --> Helper loaded: form_helper
INFO - 2016-05-21 11:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:56:32 --> Form Validation Class Initialized
INFO - 2016-05-21 11:56:32 --> Controller Class Initialized
INFO - 2016-05-21 11:56:32 --> Model Class Initialized
INFO - 2016-05-21 11:56:32 --> Database Driver Class Initialized
INFO - 2016-05-21 11:56:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:56:32 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:56:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:56:32 --> Final output sent to browser
DEBUG - 2016-05-21 11:56:32 --> Total execution time: 0.0992
INFO - 2016-05-21 11:57:22 --> Config Class Initialized
INFO - 2016-05-21 11:57:22 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:57:22 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:57:22 --> Utf8 Class Initialized
INFO - 2016-05-21 11:57:22 --> URI Class Initialized
INFO - 2016-05-21 11:57:22 --> Router Class Initialized
INFO - 2016-05-21 11:57:22 --> Output Class Initialized
INFO - 2016-05-21 11:57:22 --> Security Class Initialized
DEBUG - 2016-05-21 11:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:57:22 --> Input Class Initialized
INFO - 2016-05-21 11:57:22 --> Language Class Initialized
INFO - 2016-05-21 11:57:22 --> Loader Class Initialized
INFO - 2016-05-21 11:57:22 --> Helper loaded: url_helper
INFO - 2016-05-21 11:57:22 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:57:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:57:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:57:22 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:57:22 --> Helper loaded: form_helper
INFO - 2016-05-21 11:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:57:22 --> Form Validation Class Initialized
INFO - 2016-05-21 11:57:22 --> Controller Class Initialized
INFO - 2016-05-21 11:57:22 --> Model Class Initialized
INFO - 2016-05-21 11:57:22 --> Database Driver Class Initialized
INFO - 2016-05-21 11:57:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:57:22 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:57:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:57:22 --> Final output sent to browser
DEBUG - 2016-05-21 11:57:22 --> Total execution time: 0.0712
INFO - 2016-05-21 11:57:32 --> Config Class Initialized
INFO - 2016-05-21 11:57:32 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:57:32 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:57:32 --> Utf8 Class Initialized
INFO - 2016-05-21 11:57:32 --> URI Class Initialized
INFO - 2016-05-21 11:57:32 --> Router Class Initialized
INFO - 2016-05-21 11:57:32 --> Output Class Initialized
INFO - 2016-05-21 11:57:32 --> Security Class Initialized
DEBUG - 2016-05-21 11:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:57:32 --> Input Class Initialized
INFO - 2016-05-21 11:57:32 --> Language Class Initialized
INFO - 2016-05-21 11:57:32 --> Loader Class Initialized
INFO - 2016-05-21 11:57:32 --> Helper loaded: url_helper
INFO - 2016-05-21 11:57:32 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:57:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:57:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:57:32 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:57:32 --> Helper loaded: form_helper
INFO - 2016-05-21 11:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:57:32 --> Form Validation Class Initialized
INFO - 2016-05-21 11:57:32 --> Controller Class Initialized
INFO - 2016-05-21 11:57:32 --> Model Class Initialized
INFO - 2016-05-21 11:57:32 --> Database Driver Class Initialized
INFO - 2016-05-21 11:57:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:57:32 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:57:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:57:32 --> Final output sent to browser
DEBUG - 2016-05-21 11:57:32 --> Total execution time: 0.0777
INFO - 2016-05-21 11:58:22 --> Config Class Initialized
INFO - 2016-05-21 11:58:22 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:58:22 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:58:22 --> Utf8 Class Initialized
INFO - 2016-05-21 11:58:22 --> URI Class Initialized
INFO - 2016-05-21 11:58:22 --> Router Class Initialized
INFO - 2016-05-21 11:58:22 --> Output Class Initialized
INFO - 2016-05-21 11:58:22 --> Security Class Initialized
DEBUG - 2016-05-21 11:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:58:22 --> Input Class Initialized
INFO - 2016-05-21 11:58:22 --> Language Class Initialized
INFO - 2016-05-21 11:58:22 --> Loader Class Initialized
INFO - 2016-05-21 11:58:22 --> Helper loaded: url_helper
INFO - 2016-05-21 11:58:22 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:58:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:58:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:58:22 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:58:22 --> Helper loaded: form_helper
INFO - 2016-05-21 11:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:58:22 --> Form Validation Class Initialized
INFO - 2016-05-21 11:58:22 --> Controller Class Initialized
INFO - 2016-05-21 11:58:22 --> Model Class Initialized
INFO - 2016-05-21 11:58:22 --> Database Driver Class Initialized
INFO - 2016-05-21 11:58:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:58:22 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:58:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:58:22 --> Final output sent to browser
DEBUG - 2016-05-21 11:58:22 --> Total execution time: 0.0724
INFO - 2016-05-21 11:58:32 --> Config Class Initialized
INFO - 2016-05-21 11:58:32 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:58:32 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:58:32 --> Utf8 Class Initialized
INFO - 2016-05-21 11:58:32 --> URI Class Initialized
INFO - 2016-05-21 11:58:32 --> Router Class Initialized
INFO - 2016-05-21 11:58:32 --> Output Class Initialized
INFO - 2016-05-21 11:58:32 --> Security Class Initialized
DEBUG - 2016-05-21 11:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:58:32 --> Input Class Initialized
INFO - 2016-05-21 11:58:32 --> Language Class Initialized
INFO - 2016-05-21 11:58:32 --> Loader Class Initialized
INFO - 2016-05-21 11:58:32 --> Helper loaded: url_helper
INFO - 2016-05-21 11:58:32 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:58:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:58:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:58:32 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:58:32 --> Helper loaded: form_helper
INFO - 2016-05-21 11:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:58:32 --> Form Validation Class Initialized
INFO - 2016-05-21 11:58:32 --> Controller Class Initialized
INFO - 2016-05-21 11:58:32 --> Model Class Initialized
INFO - 2016-05-21 11:58:32 --> Database Driver Class Initialized
INFO - 2016-05-21 11:58:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:58:32 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:58:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:58:32 --> Final output sent to browser
DEBUG - 2016-05-21 11:58:32 --> Total execution time: 0.0733
INFO - 2016-05-21 11:59:22 --> Config Class Initialized
INFO - 2016-05-21 11:59:22 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:59:22 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:59:22 --> Utf8 Class Initialized
INFO - 2016-05-21 11:59:22 --> URI Class Initialized
INFO - 2016-05-21 11:59:22 --> Router Class Initialized
INFO - 2016-05-21 11:59:22 --> Output Class Initialized
INFO - 2016-05-21 11:59:22 --> Security Class Initialized
DEBUG - 2016-05-21 11:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:59:22 --> Input Class Initialized
INFO - 2016-05-21 11:59:22 --> Language Class Initialized
INFO - 2016-05-21 11:59:22 --> Loader Class Initialized
INFO - 2016-05-21 11:59:22 --> Helper loaded: url_helper
INFO - 2016-05-21 11:59:22 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:59:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:59:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:59:22 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:59:22 --> Helper loaded: form_helper
INFO - 2016-05-21 11:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:59:22 --> Form Validation Class Initialized
INFO - 2016-05-21 11:59:22 --> Controller Class Initialized
INFO - 2016-05-21 11:59:22 --> Model Class Initialized
INFO - 2016-05-21 11:59:22 --> Database Driver Class Initialized
INFO - 2016-05-21 11:59:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:59:22 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:59:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:59:22 --> Final output sent to browser
DEBUG - 2016-05-21 11:59:22 --> Total execution time: 0.0717
INFO - 2016-05-21 11:59:32 --> Config Class Initialized
INFO - 2016-05-21 11:59:32 --> Hooks Class Initialized
DEBUG - 2016-05-21 11:59:32 --> UTF-8 Support Enabled
INFO - 2016-05-21 11:59:32 --> Utf8 Class Initialized
INFO - 2016-05-21 11:59:32 --> URI Class Initialized
INFO - 2016-05-21 11:59:32 --> Router Class Initialized
INFO - 2016-05-21 11:59:32 --> Output Class Initialized
INFO - 2016-05-21 11:59:32 --> Security Class Initialized
DEBUG - 2016-05-21 11:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 11:59:32 --> Input Class Initialized
INFO - 2016-05-21 11:59:32 --> Language Class Initialized
INFO - 2016-05-21 11:59:32 --> Loader Class Initialized
INFO - 2016-05-21 11:59:32 --> Helper loaded: url_helper
INFO - 2016-05-21 11:59:32 --> Helper loaded: sesion_helper
INFO - 2016-05-21 11:59:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 11:59:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 11:59:32 --> Helper loaded: redondear_helper
INFO - 2016-05-21 11:59:32 --> Helper loaded: form_helper
INFO - 2016-05-21 11:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 11:59:32 --> Form Validation Class Initialized
INFO - 2016-05-21 11:59:32 --> Controller Class Initialized
INFO - 2016-05-21 11:59:32 --> Model Class Initialized
INFO - 2016-05-21 11:59:32 --> Database Driver Class Initialized
INFO - 2016-05-21 11:59:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 11:59:32 --> Pagination Class Initialized
DEBUG - 2016-05-21 11:59:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 11:59:32 --> Final output sent to browser
DEBUG - 2016-05-21 11:59:32 --> Total execution time: 0.0734
INFO - 2016-05-21 12:00:22 --> Config Class Initialized
INFO - 2016-05-21 12:00:22 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:00:22 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:00:22 --> Utf8 Class Initialized
INFO - 2016-05-21 12:00:22 --> URI Class Initialized
INFO - 2016-05-21 12:00:22 --> Router Class Initialized
INFO - 2016-05-21 12:00:22 --> Output Class Initialized
INFO - 2016-05-21 12:00:22 --> Security Class Initialized
DEBUG - 2016-05-21 12:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:00:22 --> Input Class Initialized
INFO - 2016-05-21 12:00:22 --> Language Class Initialized
INFO - 2016-05-21 12:00:22 --> Loader Class Initialized
INFO - 2016-05-21 12:00:22 --> Helper loaded: url_helper
INFO - 2016-05-21 12:00:22 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:00:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:00:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:00:22 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:00:22 --> Helper loaded: form_helper
INFO - 2016-05-21 12:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:00:22 --> Form Validation Class Initialized
INFO - 2016-05-21 12:00:22 --> Controller Class Initialized
INFO - 2016-05-21 12:00:22 --> Model Class Initialized
INFO - 2016-05-21 12:00:22 --> Database Driver Class Initialized
INFO - 2016-05-21 12:00:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:00:22 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:00:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:00:22 --> Final output sent to browser
DEBUG - 2016-05-21 12:00:22 --> Total execution time: 0.0743
INFO - 2016-05-21 12:00:32 --> Config Class Initialized
INFO - 2016-05-21 12:00:32 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:00:32 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:00:32 --> Utf8 Class Initialized
INFO - 2016-05-21 12:00:32 --> URI Class Initialized
INFO - 2016-05-21 12:00:32 --> Router Class Initialized
INFO - 2016-05-21 12:00:32 --> Output Class Initialized
INFO - 2016-05-21 12:00:32 --> Security Class Initialized
DEBUG - 2016-05-21 12:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:00:32 --> Input Class Initialized
INFO - 2016-05-21 12:00:32 --> Language Class Initialized
INFO - 2016-05-21 12:00:32 --> Loader Class Initialized
INFO - 2016-05-21 12:00:32 --> Helper loaded: url_helper
INFO - 2016-05-21 12:00:32 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:00:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:00:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:00:32 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:00:32 --> Helper loaded: form_helper
INFO - 2016-05-21 12:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:00:32 --> Form Validation Class Initialized
INFO - 2016-05-21 12:00:32 --> Controller Class Initialized
INFO - 2016-05-21 12:00:32 --> Model Class Initialized
INFO - 2016-05-21 12:00:32 --> Database Driver Class Initialized
INFO - 2016-05-21 12:00:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:00:32 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:00:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:00:32 --> Final output sent to browser
DEBUG - 2016-05-21 12:00:32 --> Total execution time: 0.0753
INFO - 2016-05-21 12:01:22 --> Config Class Initialized
INFO - 2016-05-21 12:01:22 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:01:22 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:01:22 --> Utf8 Class Initialized
INFO - 2016-05-21 12:01:22 --> URI Class Initialized
INFO - 2016-05-21 12:01:22 --> Router Class Initialized
INFO - 2016-05-21 12:01:22 --> Output Class Initialized
INFO - 2016-05-21 12:01:22 --> Security Class Initialized
DEBUG - 2016-05-21 12:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:01:22 --> Input Class Initialized
INFO - 2016-05-21 12:01:22 --> Language Class Initialized
INFO - 2016-05-21 12:01:22 --> Loader Class Initialized
INFO - 2016-05-21 12:01:22 --> Helper loaded: url_helper
INFO - 2016-05-21 12:01:22 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:01:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:01:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:01:22 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:01:22 --> Helper loaded: form_helper
INFO - 2016-05-21 12:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:01:22 --> Form Validation Class Initialized
INFO - 2016-05-21 12:01:22 --> Controller Class Initialized
INFO - 2016-05-21 12:01:22 --> Model Class Initialized
INFO - 2016-05-21 12:01:22 --> Database Driver Class Initialized
INFO - 2016-05-21 12:01:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:01:22 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:01:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:01:22 --> Final output sent to browser
DEBUG - 2016-05-21 12:01:22 --> Total execution time: 0.0747
INFO - 2016-05-21 12:01:32 --> Config Class Initialized
INFO - 2016-05-21 12:01:32 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:01:32 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:01:32 --> Utf8 Class Initialized
INFO - 2016-05-21 12:01:32 --> URI Class Initialized
INFO - 2016-05-21 12:01:32 --> Router Class Initialized
INFO - 2016-05-21 12:01:32 --> Output Class Initialized
INFO - 2016-05-21 12:01:32 --> Security Class Initialized
DEBUG - 2016-05-21 12:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:01:32 --> Input Class Initialized
INFO - 2016-05-21 12:01:32 --> Language Class Initialized
INFO - 2016-05-21 12:01:32 --> Loader Class Initialized
INFO - 2016-05-21 12:01:32 --> Helper loaded: url_helper
INFO - 2016-05-21 12:01:32 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:01:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:01:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:01:32 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:01:32 --> Helper loaded: form_helper
INFO - 2016-05-21 12:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:01:32 --> Form Validation Class Initialized
INFO - 2016-05-21 12:01:32 --> Controller Class Initialized
INFO - 2016-05-21 12:01:32 --> Model Class Initialized
INFO - 2016-05-21 12:01:32 --> Database Driver Class Initialized
INFO - 2016-05-21 12:01:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:01:32 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:01:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:01:32 --> Final output sent to browser
DEBUG - 2016-05-21 12:01:32 --> Total execution time: 0.0690
INFO - 2016-05-21 12:02:22 --> Config Class Initialized
INFO - 2016-05-21 12:02:22 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:02:22 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:02:22 --> Utf8 Class Initialized
INFO - 2016-05-21 12:02:22 --> URI Class Initialized
INFO - 2016-05-21 12:02:22 --> Router Class Initialized
INFO - 2016-05-21 12:02:22 --> Output Class Initialized
INFO - 2016-05-21 12:02:22 --> Security Class Initialized
DEBUG - 2016-05-21 12:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:02:22 --> Input Class Initialized
INFO - 2016-05-21 12:02:22 --> Language Class Initialized
INFO - 2016-05-21 12:02:22 --> Loader Class Initialized
INFO - 2016-05-21 12:02:22 --> Helper loaded: url_helper
INFO - 2016-05-21 12:02:22 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:02:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:02:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:02:22 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:02:22 --> Helper loaded: form_helper
INFO - 2016-05-21 12:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:02:22 --> Form Validation Class Initialized
INFO - 2016-05-21 12:02:22 --> Controller Class Initialized
INFO - 2016-05-21 12:02:22 --> Model Class Initialized
INFO - 2016-05-21 12:02:22 --> Database Driver Class Initialized
INFO - 2016-05-21 12:02:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:02:22 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:02:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:02:22 --> Final output sent to browser
DEBUG - 2016-05-21 12:02:22 --> Total execution time: 0.0692
INFO - 2016-05-21 12:02:32 --> Config Class Initialized
INFO - 2016-05-21 12:02:32 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:02:32 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:02:32 --> Utf8 Class Initialized
INFO - 2016-05-21 12:02:32 --> URI Class Initialized
INFO - 2016-05-21 12:02:32 --> Router Class Initialized
INFO - 2016-05-21 12:02:32 --> Output Class Initialized
INFO - 2016-05-21 12:02:32 --> Security Class Initialized
DEBUG - 2016-05-21 12:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:02:32 --> Input Class Initialized
INFO - 2016-05-21 12:02:32 --> Language Class Initialized
INFO - 2016-05-21 12:02:32 --> Loader Class Initialized
INFO - 2016-05-21 12:02:32 --> Helper loaded: url_helper
INFO - 2016-05-21 12:02:32 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:02:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:02:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:02:32 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:02:32 --> Helper loaded: form_helper
INFO - 2016-05-21 12:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:02:32 --> Form Validation Class Initialized
INFO - 2016-05-21 12:02:32 --> Controller Class Initialized
INFO - 2016-05-21 12:02:32 --> Model Class Initialized
INFO - 2016-05-21 12:02:32 --> Database Driver Class Initialized
INFO - 2016-05-21 12:02:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:02:32 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:02:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:02:32 --> Final output sent to browser
DEBUG - 2016-05-21 12:02:32 --> Total execution time: 0.0793
INFO - 2016-05-21 12:03:22 --> Config Class Initialized
INFO - 2016-05-21 12:03:22 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:03:22 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:03:22 --> Utf8 Class Initialized
INFO - 2016-05-21 12:03:22 --> URI Class Initialized
INFO - 2016-05-21 12:03:22 --> Router Class Initialized
INFO - 2016-05-21 12:03:22 --> Output Class Initialized
INFO - 2016-05-21 12:03:22 --> Security Class Initialized
DEBUG - 2016-05-21 12:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:03:22 --> Input Class Initialized
INFO - 2016-05-21 12:03:22 --> Language Class Initialized
INFO - 2016-05-21 12:03:22 --> Loader Class Initialized
INFO - 2016-05-21 12:03:22 --> Helper loaded: url_helper
INFO - 2016-05-21 12:03:22 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:03:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:03:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:03:22 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:03:22 --> Helper loaded: form_helper
INFO - 2016-05-21 12:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:03:22 --> Form Validation Class Initialized
INFO - 2016-05-21 12:03:22 --> Controller Class Initialized
INFO - 2016-05-21 12:03:22 --> Model Class Initialized
INFO - 2016-05-21 12:03:22 --> Database Driver Class Initialized
INFO - 2016-05-21 12:03:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:03:22 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:03:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:03:22 --> Final output sent to browser
DEBUG - 2016-05-21 12:03:22 --> Total execution time: 0.0699
INFO - 2016-05-21 12:03:33 --> Config Class Initialized
INFO - 2016-05-21 12:03:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:03:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:03:33 --> Utf8 Class Initialized
INFO - 2016-05-21 12:03:33 --> URI Class Initialized
INFO - 2016-05-21 12:03:33 --> Router Class Initialized
INFO - 2016-05-21 12:03:33 --> Output Class Initialized
INFO - 2016-05-21 12:03:33 --> Security Class Initialized
DEBUG - 2016-05-21 12:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:03:33 --> Input Class Initialized
INFO - 2016-05-21 12:03:33 --> Language Class Initialized
INFO - 2016-05-21 12:03:33 --> Loader Class Initialized
INFO - 2016-05-21 12:03:33 --> Helper loaded: url_helper
INFO - 2016-05-21 12:03:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:03:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:03:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:03:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:03:33 --> Helper loaded: form_helper
INFO - 2016-05-21 12:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:03:33 --> Form Validation Class Initialized
INFO - 2016-05-21 12:03:33 --> Controller Class Initialized
INFO - 2016-05-21 12:03:33 --> Model Class Initialized
INFO - 2016-05-21 12:03:33 --> Database Driver Class Initialized
INFO - 2016-05-21 12:03:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:03:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:03:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:03:33 --> Final output sent to browser
DEBUG - 2016-05-21 12:03:33 --> Total execution time: 0.0712
INFO - 2016-05-21 12:04:22 --> Config Class Initialized
INFO - 2016-05-21 12:04:22 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:04:22 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:04:22 --> Utf8 Class Initialized
INFO - 2016-05-21 12:04:22 --> URI Class Initialized
INFO - 2016-05-21 12:04:22 --> Router Class Initialized
INFO - 2016-05-21 12:04:22 --> Output Class Initialized
INFO - 2016-05-21 12:04:22 --> Security Class Initialized
DEBUG - 2016-05-21 12:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:04:22 --> Input Class Initialized
INFO - 2016-05-21 12:04:22 --> Language Class Initialized
INFO - 2016-05-21 12:04:22 --> Loader Class Initialized
INFO - 2016-05-21 12:04:22 --> Helper loaded: url_helper
INFO - 2016-05-21 12:04:22 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:04:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:04:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:04:22 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:04:22 --> Helper loaded: form_helper
INFO - 2016-05-21 12:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:04:22 --> Form Validation Class Initialized
INFO - 2016-05-21 12:04:22 --> Controller Class Initialized
INFO - 2016-05-21 12:04:22 --> Model Class Initialized
INFO - 2016-05-21 12:04:22 --> Database Driver Class Initialized
INFO - 2016-05-21 12:04:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:04:22 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:04:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:04:22 --> Final output sent to browser
DEBUG - 2016-05-21 12:04:22 --> Total execution time: 0.0722
INFO - 2016-05-21 12:04:33 --> Config Class Initialized
INFO - 2016-05-21 12:04:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:04:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:04:33 --> Utf8 Class Initialized
INFO - 2016-05-21 12:04:33 --> URI Class Initialized
INFO - 2016-05-21 12:04:33 --> Router Class Initialized
INFO - 2016-05-21 12:04:33 --> Output Class Initialized
INFO - 2016-05-21 12:04:33 --> Security Class Initialized
DEBUG - 2016-05-21 12:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:04:33 --> Input Class Initialized
INFO - 2016-05-21 12:04:33 --> Language Class Initialized
INFO - 2016-05-21 12:04:33 --> Loader Class Initialized
INFO - 2016-05-21 12:04:33 --> Helper loaded: url_helper
INFO - 2016-05-21 12:04:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:04:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:04:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:04:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:04:33 --> Helper loaded: form_helper
INFO - 2016-05-21 12:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:04:33 --> Form Validation Class Initialized
INFO - 2016-05-21 12:04:33 --> Controller Class Initialized
INFO - 2016-05-21 12:04:33 --> Model Class Initialized
INFO - 2016-05-21 12:04:33 --> Database Driver Class Initialized
INFO - 2016-05-21 12:04:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:04:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:04:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:04:33 --> Final output sent to browser
DEBUG - 2016-05-21 12:04:33 --> Total execution time: 0.0701
INFO - 2016-05-21 12:05:33 --> Config Class Initialized
INFO - 2016-05-21 12:05:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:05:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:05:33 --> Utf8 Class Initialized
INFO - 2016-05-21 12:05:33 --> URI Class Initialized
INFO - 2016-05-21 12:05:33 --> Router Class Initialized
INFO - 2016-05-21 12:05:33 --> Output Class Initialized
INFO - 2016-05-21 12:05:33 --> Security Class Initialized
DEBUG - 2016-05-21 12:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:05:33 --> Input Class Initialized
INFO - 2016-05-21 12:05:33 --> Language Class Initialized
INFO - 2016-05-21 12:05:33 --> Loader Class Initialized
INFO - 2016-05-21 12:05:33 --> Helper loaded: url_helper
INFO - 2016-05-21 12:05:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:05:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:05:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:05:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:05:33 --> Helper loaded: form_helper
INFO - 2016-05-21 12:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:05:33 --> Form Validation Class Initialized
INFO - 2016-05-21 12:05:33 --> Controller Class Initialized
INFO - 2016-05-21 12:05:33 --> Model Class Initialized
INFO - 2016-05-21 12:05:33 --> Database Driver Class Initialized
INFO - 2016-05-21 12:05:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:05:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:05:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:05:33 --> Final output sent to browser
DEBUG - 2016-05-21 12:05:33 --> Total execution time: 0.0719
INFO - 2016-05-21 12:06:33 --> Config Class Initialized
INFO - 2016-05-21 12:06:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:06:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:06:33 --> Utf8 Class Initialized
INFO - 2016-05-21 12:06:33 --> URI Class Initialized
INFO - 2016-05-21 12:06:33 --> Router Class Initialized
INFO - 2016-05-21 12:06:33 --> Output Class Initialized
INFO - 2016-05-21 12:06:33 --> Security Class Initialized
DEBUG - 2016-05-21 12:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:06:33 --> Input Class Initialized
INFO - 2016-05-21 12:06:33 --> Language Class Initialized
INFO - 2016-05-21 12:06:33 --> Loader Class Initialized
INFO - 2016-05-21 12:06:33 --> Helper loaded: url_helper
INFO - 2016-05-21 12:06:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:06:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:06:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:06:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:06:33 --> Helper loaded: form_helper
INFO - 2016-05-21 12:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:06:33 --> Form Validation Class Initialized
INFO - 2016-05-21 12:06:33 --> Controller Class Initialized
INFO - 2016-05-21 12:06:33 --> Model Class Initialized
INFO - 2016-05-21 12:06:33 --> Database Driver Class Initialized
INFO - 2016-05-21 12:06:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:06:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:06:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:06:33 --> Final output sent to browser
DEBUG - 2016-05-21 12:06:33 --> Total execution time: 0.0806
INFO - 2016-05-21 12:07:33 --> Config Class Initialized
INFO - 2016-05-21 12:07:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:07:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:07:33 --> Utf8 Class Initialized
INFO - 2016-05-21 12:07:33 --> URI Class Initialized
INFO - 2016-05-21 12:07:33 --> Router Class Initialized
INFO - 2016-05-21 12:07:33 --> Output Class Initialized
INFO - 2016-05-21 12:07:33 --> Security Class Initialized
DEBUG - 2016-05-21 12:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:07:33 --> Input Class Initialized
INFO - 2016-05-21 12:07:33 --> Language Class Initialized
INFO - 2016-05-21 12:07:33 --> Loader Class Initialized
INFO - 2016-05-21 12:07:33 --> Helper loaded: url_helper
INFO - 2016-05-21 12:07:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:07:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:07:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:07:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:07:33 --> Helper loaded: form_helper
INFO - 2016-05-21 12:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:07:33 --> Form Validation Class Initialized
INFO - 2016-05-21 12:07:33 --> Controller Class Initialized
INFO - 2016-05-21 12:07:33 --> Model Class Initialized
INFO - 2016-05-21 12:07:33 --> Database Driver Class Initialized
INFO - 2016-05-21 12:07:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:07:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:07:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:07:33 --> Final output sent to browser
DEBUG - 2016-05-21 12:07:33 --> Total execution time: 0.0769
INFO - 2016-05-21 12:08:33 --> Config Class Initialized
INFO - 2016-05-21 12:08:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:08:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:08:33 --> Utf8 Class Initialized
INFO - 2016-05-21 12:08:33 --> URI Class Initialized
INFO - 2016-05-21 12:08:33 --> Router Class Initialized
INFO - 2016-05-21 12:08:33 --> Output Class Initialized
INFO - 2016-05-21 12:08:33 --> Security Class Initialized
DEBUG - 2016-05-21 12:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:08:33 --> Input Class Initialized
INFO - 2016-05-21 12:08:33 --> Language Class Initialized
INFO - 2016-05-21 12:08:33 --> Loader Class Initialized
INFO - 2016-05-21 12:08:33 --> Helper loaded: url_helper
INFO - 2016-05-21 12:08:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:08:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:08:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:08:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:08:33 --> Helper loaded: form_helper
INFO - 2016-05-21 12:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:08:33 --> Form Validation Class Initialized
INFO - 2016-05-21 12:08:33 --> Controller Class Initialized
INFO - 2016-05-21 12:08:33 --> Model Class Initialized
INFO - 2016-05-21 12:08:33 --> Database Driver Class Initialized
INFO - 2016-05-21 12:08:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:08:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:08:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:08:33 --> Final output sent to browser
DEBUG - 2016-05-21 12:08:33 --> Total execution time: 0.0710
INFO - 2016-05-21 12:09:33 --> Config Class Initialized
INFO - 2016-05-21 12:09:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:09:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:09:33 --> Utf8 Class Initialized
INFO - 2016-05-21 12:09:33 --> URI Class Initialized
INFO - 2016-05-21 12:09:33 --> Router Class Initialized
INFO - 2016-05-21 12:09:33 --> Output Class Initialized
INFO - 2016-05-21 12:09:33 --> Security Class Initialized
DEBUG - 2016-05-21 12:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:09:33 --> Input Class Initialized
INFO - 2016-05-21 12:09:33 --> Language Class Initialized
INFO - 2016-05-21 12:09:33 --> Loader Class Initialized
INFO - 2016-05-21 12:09:33 --> Helper loaded: url_helper
INFO - 2016-05-21 12:09:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:09:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:09:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:09:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:09:33 --> Helper loaded: form_helper
INFO - 2016-05-21 12:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:09:33 --> Form Validation Class Initialized
INFO - 2016-05-21 12:09:33 --> Controller Class Initialized
INFO - 2016-05-21 12:09:33 --> Model Class Initialized
INFO - 2016-05-21 12:09:33 --> Database Driver Class Initialized
INFO - 2016-05-21 12:09:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:09:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:09:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:09:33 --> Final output sent to browser
DEBUG - 2016-05-21 12:09:33 --> Total execution time: 0.0815
INFO - 2016-05-21 12:10:33 --> Config Class Initialized
INFO - 2016-05-21 12:10:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:10:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:10:33 --> Utf8 Class Initialized
INFO - 2016-05-21 12:10:33 --> URI Class Initialized
INFO - 2016-05-21 12:10:33 --> Router Class Initialized
INFO - 2016-05-21 12:10:33 --> Output Class Initialized
INFO - 2016-05-21 12:10:33 --> Security Class Initialized
DEBUG - 2016-05-21 12:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:10:33 --> Input Class Initialized
INFO - 2016-05-21 12:10:33 --> Language Class Initialized
INFO - 2016-05-21 12:10:33 --> Loader Class Initialized
INFO - 2016-05-21 12:10:33 --> Helper loaded: url_helper
INFO - 2016-05-21 12:10:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:10:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:10:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:10:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:10:33 --> Helper loaded: form_helper
INFO - 2016-05-21 12:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:10:33 --> Form Validation Class Initialized
INFO - 2016-05-21 12:10:33 --> Controller Class Initialized
INFO - 2016-05-21 12:10:33 --> Model Class Initialized
INFO - 2016-05-21 12:10:33 --> Database Driver Class Initialized
INFO - 2016-05-21 12:10:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:10:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:10:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:10:33 --> Final output sent to browser
DEBUG - 2016-05-21 12:10:33 --> Total execution time: 0.0768
INFO - 2016-05-21 12:11:09 --> Config Class Initialized
INFO - 2016-05-21 12:11:09 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:11:09 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:11:09 --> Utf8 Class Initialized
INFO - 2016-05-21 12:11:09 --> URI Class Initialized
INFO - 2016-05-21 12:11:09 --> Router Class Initialized
INFO - 2016-05-21 12:11:09 --> Output Class Initialized
INFO - 2016-05-21 12:11:09 --> Security Class Initialized
DEBUG - 2016-05-21 12:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:11:09 --> Input Class Initialized
INFO - 2016-05-21 12:11:09 --> Language Class Initialized
INFO - 2016-05-21 12:11:09 --> Loader Class Initialized
INFO - 2016-05-21 12:11:09 --> Helper loaded: url_helper
INFO - 2016-05-21 12:11:09 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:11:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:11:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:11:09 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:11:09 --> Helper loaded: form_helper
INFO - 2016-05-21 12:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:11:09 --> Form Validation Class Initialized
INFO - 2016-05-21 12:11:09 --> Controller Class Initialized
INFO - 2016-05-21 12:11:09 --> Model Class Initialized
INFO - 2016-05-21 12:11:09 --> Database Driver Class Initialized
INFO - 2016-05-21 12:11:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:11:09 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:11:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:11:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:11:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:11:09 --> Final output sent to browser
DEBUG - 2016-05-21 12:11:09 --> Total execution time: 0.1475
INFO - 2016-05-21 12:11:10 --> Config Class Initialized
INFO - 2016-05-21 12:11:10 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:11:10 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:11:10 --> Utf8 Class Initialized
INFO - 2016-05-21 12:11:10 --> URI Class Initialized
INFO - 2016-05-21 12:11:10 --> Router Class Initialized
INFO - 2016-05-21 12:11:10 --> Output Class Initialized
INFO - 2016-05-21 12:11:10 --> Security Class Initialized
DEBUG - 2016-05-21 12:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:11:10 --> Input Class Initialized
INFO - 2016-05-21 12:11:10 --> Language Class Initialized
INFO - 2016-05-21 12:11:10 --> Loader Class Initialized
INFO - 2016-05-21 12:11:10 --> Helper loaded: url_helper
INFO - 2016-05-21 12:11:10 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:11:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:11:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:11:10 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:11:10 --> Helper loaded: form_helper
INFO - 2016-05-21 12:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:11:10 --> Form Validation Class Initialized
INFO - 2016-05-21 12:11:10 --> Controller Class Initialized
INFO - 2016-05-21 12:11:10 --> Model Class Initialized
INFO - 2016-05-21 12:11:10 --> Database Driver Class Initialized
INFO - 2016-05-21 12:11:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:11:10 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:11:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:11:10 --> Final output sent to browser
DEBUG - 2016-05-21 12:11:10 --> Total execution time: 0.1015
INFO - 2016-05-21 12:11:11 --> Config Class Initialized
INFO - 2016-05-21 12:11:11 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:11:11 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:11:11 --> Utf8 Class Initialized
INFO - 2016-05-21 12:11:11 --> URI Class Initialized
INFO - 2016-05-21 12:11:11 --> Router Class Initialized
INFO - 2016-05-21 12:11:11 --> Output Class Initialized
INFO - 2016-05-21 12:11:11 --> Security Class Initialized
DEBUG - 2016-05-21 12:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:11:11 --> Input Class Initialized
INFO - 2016-05-21 12:11:11 --> Language Class Initialized
INFO - 2016-05-21 12:11:11 --> Loader Class Initialized
INFO - 2016-05-21 12:11:11 --> Helper loaded: url_helper
INFO - 2016-05-21 12:11:11 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:11:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:11:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:11:11 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:11:11 --> Helper loaded: form_helper
INFO - 2016-05-21 12:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:11:11 --> Form Validation Class Initialized
INFO - 2016-05-21 12:11:11 --> Controller Class Initialized
INFO - 2016-05-21 12:11:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-21 12:11:11 --> Final output sent to browser
DEBUG - 2016-05-21 12:11:11 --> Total execution time: 0.1879
INFO - 2016-05-21 12:11:18 --> Config Class Initialized
INFO - 2016-05-21 12:11:18 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:11:18 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:11:18 --> Utf8 Class Initialized
INFO - 2016-05-21 12:11:18 --> URI Class Initialized
INFO - 2016-05-21 12:11:18 --> Router Class Initialized
INFO - 2016-05-21 12:11:18 --> Output Class Initialized
INFO - 2016-05-21 12:11:18 --> Security Class Initialized
DEBUG - 2016-05-21 12:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:11:18 --> Input Class Initialized
INFO - 2016-05-21 12:11:18 --> Language Class Initialized
INFO - 2016-05-21 12:11:18 --> Loader Class Initialized
INFO - 2016-05-21 12:11:18 --> Helper loaded: url_helper
INFO - 2016-05-21 12:11:18 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:11:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:11:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:11:18 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:11:18 --> Helper loaded: form_helper
INFO - 2016-05-21 12:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:11:18 --> Form Validation Class Initialized
INFO - 2016-05-21 12:11:18 --> Controller Class Initialized
INFO - 2016-05-21 12:11:18 --> Model Class Initialized
INFO - 2016-05-21 12:11:18 --> Database Driver Class Initialized
INFO - 2016-05-21 12:11:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:11:18 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:11:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:11:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:11:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:11:18 --> Final output sent to browser
DEBUG - 2016-05-21 12:11:18 --> Total execution time: 0.0819
INFO - 2016-05-21 12:11:19 --> Config Class Initialized
INFO - 2016-05-21 12:11:19 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:11:19 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:11:19 --> Utf8 Class Initialized
INFO - 2016-05-21 12:11:19 --> URI Class Initialized
INFO - 2016-05-21 12:11:19 --> Router Class Initialized
INFO - 2016-05-21 12:11:19 --> Output Class Initialized
INFO - 2016-05-21 12:11:19 --> Security Class Initialized
DEBUG - 2016-05-21 12:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:11:19 --> Input Class Initialized
INFO - 2016-05-21 12:11:19 --> Language Class Initialized
INFO - 2016-05-21 12:11:19 --> Loader Class Initialized
INFO - 2016-05-21 12:11:19 --> Helper loaded: url_helper
INFO - 2016-05-21 12:11:19 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:11:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:11:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:11:19 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:11:19 --> Helper loaded: form_helper
INFO - 2016-05-21 12:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:11:19 --> Form Validation Class Initialized
INFO - 2016-05-21 12:11:19 --> Controller Class Initialized
INFO - 2016-05-21 12:11:19 --> Model Class Initialized
INFO - 2016-05-21 12:11:19 --> Database Driver Class Initialized
INFO - 2016-05-21 12:11:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:11:19 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:11:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:11:19 --> Final output sent to browser
DEBUG - 2016-05-21 12:11:19 --> Total execution time: 0.0931
INFO - 2016-05-21 12:11:57 --> Config Class Initialized
INFO - 2016-05-21 12:11:57 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:11:57 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:11:57 --> Utf8 Class Initialized
INFO - 2016-05-21 12:11:57 --> URI Class Initialized
INFO - 2016-05-21 12:11:57 --> Router Class Initialized
INFO - 2016-05-21 12:11:57 --> Output Class Initialized
INFO - 2016-05-21 12:11:57 --> Security Class Initialized
DEBUG - 2016-05-21 12:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:11:57 --> Input Class Initialized
INFO - 2016-05-21 12:11:57 --> Language Class Initialized
INFO - 2016-05-21 12:11:57 --> Loader Class Initialized
INFO - 2016-05-21 12:11:57 --> Helper loaded: url_helper
INFO - 2016-05-21 12:11:57 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:11:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:11:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:11:57 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:11:57 --> Helper loaded: form_helper
INFO - 2016-05-21 12:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:11:57 --> Form Validation Class Initialized
INFO - 2016-05-21 12:11:57 --> Controller Class Initialized
INFO - 2016-05-21 12:11:57 --> Model Class Initialized
INFO - 2016-05-21 12:11:57 --> Database Driver Class Initialized
INFO - 2016-05-21 12:11:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:11:57 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:11:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:11:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:11:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:11:57 --> Final output sent to browser
DEBUG - 2016-05-21 12:11:57 --> Total execution time: 0.0832
INFO - 2016-05-21 12:11:58 --> Config Class Initialized
INFO - 2016-05-21 12:11:58 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:11:58 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:11:58 --> Utf8 Class Initialized
INFO - 2016-05-21 12:11:58 --> URI Class Initialized
INFO - 2016-05-21 12:11:58 --> Router Class Initialized
INFO - 2016-05-21 12:11:58 --> Output Class Initialized
INFO - 2016-05-21 12:11:58 --> Security Class Initialized
DEBUG - 2016-05-21 12:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:11:58 --> Input Class Initialized
INFO - 2016-05-21 12:11:58 --> Language Class Initialized
INFO - 2016-05-21 12:11:58 --> Loader Class Initialized
INFO - 2016-05-21 12:11:58 --> Helper loaded: url_helper
INFO - 2016-05-21 12:11:58 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:11:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:11:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:11:58 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:11:58 --> Helper loaded: form_helper
INFO - 2016-05-21 12:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:11:58 --> Form Validation Class Initialized
INFO - 2016-05-21 12:11:58 --> Controller Class Initialized
INFO - 2016-05-21 12:11:58 --> Model Class Initialized
INFO - 2016-05-21 12:11:58 --> Database Driver Class Initialized
INFO - 2016-05-21 12:11:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:11:58 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:11:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:11:58 --> Final output sent to browser
DEBUG - 2016-05-21 12:11:58 --> Total execution time: 0.0935
INFO - 2016-05-21 12:12:00 --> Config Class Initialized
INFO - 2016-05-21 12:12:00 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:00 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:00 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:00 --> URI Class Initialized
INFO - 2016-05-21 12:12:00 --> Router Class Initialized
INFO - 2016-05-21 12:12:00 --> Output Class Initialized
INFO - 2016-05-21 12:12:00 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:00 --> Input Class Initialized
INFO - 2016-05-21 12:12:00 --> Language Class Initialized
INFO - 2016-05-21 12:12:00 --> Loader Class Initialized
INFO - 2016-05-21 12:12:00 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:00 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:00 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:00 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:00 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:00 --> Controller Class Initialized
INFO - 2016-05-21 12:12:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-21 12:12:00 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:00 --> Total execution time: 0.0956
INFO - 2016-05-21 12:12:02 --> Config Class Initialized
INFO - 2016-05-21 12:12:02 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:02 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:02 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:02 --> URI Class Initialized
INFO - 2016-05-21 12:12:02 --> Router Class Initialized
INFO - 2016-05-21 12:12:02 --> Output Class Initialized
INFO - 2016-05-21 12:12:02 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:02 --> Input Class Initialized
INFO - 2016-05-21 12:12:02 --> Language Class Initialized
INFO - 2016-05-21 12:12:02 --> Loader Class Initialized
INFO - 2016-05-21 12:12:02 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:02 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:02 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:02 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:02 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:02 --> Controller Class Initialized
INFO - 2016-05-21 12:12:02 --> Model Class Initialized
INFO - 2016-05-21 12:12:02 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:02 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:12:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:12:02 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:02 --> Total execution time: 0.0815
INFO - 2016-05-21 12:12:03 --> Config Class Initialized
INFO - 2016-05-21 12:12:03 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:03 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:03 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:03 --> URI Class Initialized
INFO - 2016-05-21 12:12:03 --> Router Class Initialized
INFO - 2016-05-21 12:12:03 --> Output Class Initialized
INFO - 2016-05-21 12:12:03 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:03 --> Input Class Initialized
INFO - 2016-05-21 12:12:03 --> Language Class Initialized
INFO - 2016-05-21 12:12:03 --> Loader Class Initialized
INFO - 2016-05-21 12:12:03 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:03 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:03 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:03 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:03 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:03 --> Controller Class Initialized
INFO - 2016-05-21 12:12:03 --> Model Class Initialized
INFO - 2016-05-21 12:12:03 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:03 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:03 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:03 --> Total execution time: 0.0974
INFO - 2016-05-21 12:12:09 --> Config Class Initialized
INFO - 2016-05-21 12:12:09 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:09 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:09 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:09 --> URI Class Initialized
INFO - 2016-05-21 12:12:09 --> Router Class Initialized
INFO - 2016-05-21 12:12:09 --> Output Class Initialized
INFO - 2016-05-21 12:12:09 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:09 --> Input Class Initialized
INFO - 2016-05-21 12:12:09 --> Language Class Initialized
INFO - 2016-05-21 12:12:09 --> Loader Class Initialized
INFO - 2016-05-21 12:12:09 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:09 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:09 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:09 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:09 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:09 --> Controller Class Initialized
INFO - 2016-05-21 12:12:09 --> Model Class Initialized
INFO - 2016-05-21 12:12:09 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:09 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:12:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:12:09 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:09 --> Total execution time: 0.0892
INFO - 2016-05-21 12:12:10 --> Config Class Initialized
INFO - 2016-05-21 12:12:10 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:10 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:10 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:10 --> URI Class Initialized
INFO - 2016-05-21 12:12:10 --> Router Class Initialized
INFO - 2016-05-21 12:12:10 --> Output Class Initialized
INFO - 2016-05-21 12:12:10 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:10 --> Input Class Initialized
INFO - 2016-05-21 12:12:10 --> Language Class Initialized
INFO - 2016-05-21 12:12:10 --> Loader Class Initialized
INFO - 2016-05-21 12:12:10 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:10 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:10 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:10 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:10 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:10 --> Controller Class Initialized
INFO - 2016-05-21 12:12:10 --> Model Class Initialized
INFO - 2016-05-21 12:12:10 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:10 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:10 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:10 --> Total execution time: 0.1268
INFO - 2016-05-21 12:12:11 --> Config Class Initialized
INFO - 2016-05-21 12:12:11 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:11 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:11 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:11 --> URI Class Initialized
INFO - 2016-05-21 12:12:11 --> Router Class Initialized
INFO - 2016-05-21 12:12:11 --> Output Class Initialized
INFO - 2016-05-21 12:12:11 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:11 --> Input Class Initialized
INFO - 2016-05-21 12:12:11 --> Language Class Initialized
INFO - 2016-05-21 12:12:11 --> Loader Class Initialized
INFO - 2016-05-21 12:12:11 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:11 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:11 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:11 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:11 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:11 --> Controller Class Initialized
INFO - 2016-05-21 12:12:11 --> Model Class Initialized
INFO - 2016-05-21 12:12:11 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:11 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:11 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:12:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:12:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:12:11 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:11 --> Total execution time: 0.1178
INFO - 2016-05-21 12:12:11 --> Config Class Initialized
INFO - 2016-05-21 12:12:11 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:11 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:11 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:11 --> URI Class Initialized
INFO - 2016-05-21 12:12:11 --> Router Class Initialized
INFO - 2016-05-21 12:12:11 --> Output Class Initialized
INFO - 2016-05-21 12:12:11 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:11 --> Input Class Initialized
INFO - 2016-05-21 12:12:11 --> Language Class Initialized
INFO - 2016-05-21 12:12:11 --> Loader Class Initialized
INFO - 2016-05-21 12:12:11 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:11 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:11 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:11 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:11 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:11 --> Controller Class Initialized
INFO - 2016-05-21 12:12:11 --> Model Class Initialized
INFO - 2016-05-21 12:12:11 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:11 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:11 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:11 --> Total execution time: 0.1136
INFO - 2016-05-21 12:12:12 --> Config Class Initialized
INFO - 2016-05-21 12:12:12 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:12 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:12 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:12 --> URI Class Initialized
INFO - 2016-05-21 12:12:12 --> Router Class Initialized
INFO - 2016-05-21 12:12:12 --> Output Class Initialized
INFO - 2016-05-21 12:12:12 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:13 --> Input Class Initialized
INFO - 2016-05-21 12:12:13 --> Language Class Initialized
INFO - 2016-05-21 12:12:13 --> Loader Class Initialized
INFO - 2016-05-21 12:12:13 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:13 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:13 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:13 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:13 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:13 --> Controller Class Initialized
INFO - 2016-05-21 12:12:13 --> Model Class Initialized
INFO - 2016-05-21 12:12:13 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:13 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:13 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:12:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:12:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:12:13 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:13 --> Total execution time: 0.1222
INFO - 2016-05-21 12:12:13 --> Config Class Initialized
INFO - 2016-05-21 12:12:13 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:13 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:13 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:13 --> URI Class Initialized
INFO - 2016-05-21 12:12:13 --> Router Class Initialized
INFO - 2016-05-21 12:12:13 --> Output Class Initialized
INFO - 2016-05-21 12:12:13 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:13 --> Input Class Initialized
INFO - 2016-05-21 12:12:13 --> Language Class Initialized
INFO - 2016-05-21 12:12:13 --> Loader Class Initialized
INFO - 2016-05-21 12:12:13 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:13 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:13 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:13 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:13 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:13 --> Controller Class Initialized
INFO - 2016-05-21 12:12:13 --> Model Class Initialized
INFO - 2016-05-21 12:12:13 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:13 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:13 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:13 --> Total execution time: 0.1107
INFO - 2016-05-21 12:12:42 --> Config Class Initialized
INFO - 2016-05-21 12:12:42 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:42 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:42 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:42 --> URI Class Initialized
INFO - 2016-05-21 12:12:42 --> Router Class Initialized
INFO - 2016-05-21 12:12:42 --> Output Class Initialized
INFO - 2016-05-21 12:12:42 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:42 --> Input Class Initialized
INFO - 2016-05-21 12:12:42 --> Language Class Initialized
INFO - 2016-05-21 12:12:42 --> Loader Class Initialized
INFO - 2016-05-21 12:12:42 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:42 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:42 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:42 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:42 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:42 --> Controller Class Initialized
INFO - 2016-05-21 12:12:42 --> Model Class Initialized
INFO - 2016-05-21 12:12:42 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:42 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:42 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:12:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:12:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:12:42 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:42 --> Total execution time: 0.1190
INFO - 2016-05-21 12:12:42 --> Config Class Initialized
INFO - 2016-05-21 12:12:42 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:42 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:42 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:42 --> URI Class Initialized
INFO - 2016-05-21 12:12:42 --> Router Class Initialized
INFO - 2016-05-21 12:12:42 --> Output Class Initialized
INFO - 2016-05-21 12:12:42 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:42 --> Input Class Initialized
INFO - 2016-05-21 12:12:42 --> Language Class Initialized
INFO - 2016-05-21 12:12:42 --> Loader Class Initialized
INFO - 2016-05-21 12:12:42 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:42 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:42 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:42 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:42 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:42 --> Controller Class Initialized
INFO - 2016-05-21 12:12:42 --> Model Class Initialized
INFO - 2016-05-21 12:12:42 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:42 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:42 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:42 --> Total execution time: 0.1001
INFO - 2016-05-21 12:12:43 --> Config Class Initialized
INFO - 2016-05-21 12:12:43 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:43 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:43 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:43 --> URI Class Initialized
INFO - 2016-05-21 12:12:43 --> Router Class Initialized
INFO - 2016-05-21 12:12:43 --> Output Class Initialized
INFO - 2016-05-21 12:12:43 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:43 --> Input Class Initialized
INFO - 2016-05-21 12:12:43 --> Language Class Initialized
INFO - 2016-05-21 12:12:43 --> Loader Class Initialized
INFO - 2016-05-21 12:12:43 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:43 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:43 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:43 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:44 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:44 --> Controller Class Initialized
INFO - 2016-05-21 12:12:44 --> Model Class Initialized
INFO - 2016-05-21 12:12:44 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:44 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:44 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:12:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:12:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:12:44 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:44 --> Total execution time: 0.1614
INFO - 2016-05-21 12:12:44 --> Config Class Initialized
INFO - 2016-05-21 12:12:44 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:44 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:44 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:44 --> URI Class Initialized
INFO - 2016-05-21 12:12:44 --> Router Class Initialized
INFO - 2016-05-21 12:12:44 --> Output Class Initialized
INFO - 2016-05-21 12:12:44 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:44 --> Input Class Initialized
INFO - 2016-05-21 12:12:44 --> Language Class Initialized
INFO - 2016-05-21 12:12:44 --> Loader Class Initialized
INFO - 2016-05-21 12:12:44 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:44 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:44 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:44 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:44 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:44 --> Controller Class Initialized
INFO - 2016-05-21 12:12:44 --> Model Class Initialized
INFO - 2016-05-21 12:12:44 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:44 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:44 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:44 --> Total execution time: 0.1035
INFO - 2016-05-21 12:12:48 --> Config Class Initialized
INFO - 2016-05-21 12:12:48 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:48 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:48 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:48 --> URI Class Initialized
INFO - 2016-05-21 12:12:48 --> Router Class Initialized
INFO - 2016-05-21 12:12:48 --> Output Class Initialized
INFO - 2016-05-21 12:12:48 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:48 --> Input Class Initialized
INFO - 2016-05-21 12:12:48 --> Language Class Initialized
INFO - 2016-05-21 12:12:48 --> Loader Class Initialized
INFO - 2016-05-21 12:12:48 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:48 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:48 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:48 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:48 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:48 --> Controller Class Initialized
INFO - 2016-05-21 12:12:48 --> Model Class Initialized
INFO - 2016-05-21 12:12:48 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:48 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:48 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:12:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:12:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:12:48 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:48 --> Total execution time: 0.1116
INFO - 2016-05-21 12:12:48 --> Config Class Initialized
INFO - 2016-05-21 12:12:48 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:48 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:48 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:48 --> URI Class Initialized
INFO - 2016-05-21 12:12:48 --> Router Class Initialized
INFO - 2016-05-21 12:12:48 --> Output Class Initialized
INFO - 2016-05-21 12:12:48 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:48 --> Input Class Initialized
INFO - 2016-05-21 12:12:48 --> Language Class Initialized
INFO - 2016-05-21 12:12:48 --> Loader Class Initialized
INFO - 2016-05-21 12:12:48 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:48 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:48 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:48 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:48 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:48 --> Controller Class Initialized
INFO - 2016-05-21 12:12:48 --> Model Class Initialized
INFO - 2016-05-21 12:12:48 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:48 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:48 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:48 --> Total execution time: 0.1082
INFO - 2016-05-21 12:12:52 --> Config Class Initialized
INFO - 2016-05-21 12:12:52 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:52 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:52 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:52 --> URI Class Initialized
INFO - 2016-05-21 12:12:52 --> Router Class Initialized
INFO - 2016-05-21 12:12:52 --> Output Class Initialized
INFO - 2016-05-21 12:12:52 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:52 --> Input Class Initialized
INFO - 2016-05-21 12:12:52 --> Language Class Initialized
INFO - 2016-05-21 12:12:52 --> Loader Class Initialized
INFO - 2016-05-21 12:12:52 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:52 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:52 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:52 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:52 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:52 --> Controller Class Initialized
INFO - 2016-05-21 12:12:52 --> Model Class Initialized
INFO - 2016-05-21 12:12:52 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:52 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:52 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:12:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:12:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:12:52 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:52 --> Total execution time: 0.0958
INFO - 2016-05-21 12:12:53 --> Config Class Initialized
INFO - 2016-05-21 12:12:53 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:53 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:53 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:53 --> URI Class Initialized
INFO - 2016-05-21 12:12:53 --> Router Class Initialized
INFO - 2016-05-21 12:12:53 --> Output Class Initialized
INFO - 2016-05-21 12:12:53 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:53 --> Input Class Initialized
INFO - 2016-05-21 12:12:53 --> Language Class Initialized
INFO - 2016-05-21 12:12:53 --> Loader Class Initialized
INFO - 2016-05-21 12:12:53 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:53 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:53 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:53 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:53 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:53 --> Controller Class Initialized
INFO - 2016-05-21 12:12:53 --> Model Class Initialized
INFO - 2016-05-21 12:12:53 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:53 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:53 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:53 --> Total execution time: 0.1106
INFO - 2016-05-21 12:12:53 --> Config Class Initialized
INFO - 2016-05-21 12:12:53 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:53 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:53 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:53 --> URI Class Initialized
INFO - 2016-05-21 12:12:53 --> Router Class Initialized
INFO - 2016-05-21 12:12:53 --> Output Class Initialized
INFO - 2016-05-21 12:12:53 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:53 --> Input Class Initialized
INFO - 2016-05-21 12:12:53 --> Language Class Initialized
INFO - 2016-05-21 12:12:53 --> Loader Class Initialized
INFO - 2016-05-21 12:12:53 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:53 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:53 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:53 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:53 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:53 --> Controller Class Initialized
INFO - 2016-05-21 12:12:53 --> Model Class Initialized
INFO - 2016-05-21 12:12:53 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:53 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:53 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:12:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:12:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:12:53 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:53 --> Total execution time: 0.0995
INFO - 2016-05-21 12:12:54 --> Config Class Initialized
INFO - 2016-05-21 12:12:54 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:12:54 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:12:54 --> Utf8 Class Initialized
INFO - 2016-05-21 12:12:54 --> URI Class Initialized
INFO - 2016-05-21 12:12:54 --> Router Class Initialized
INFO - 2016-05-21 12:12:54 --> Output Class Initialized
INFO - 2016-05-21 12:12:54 --> Security Class Initialized
DEBUG - 2016-05-21 12:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:12:54 --> Input Class Initialized
INFO - 2016-05-21 12:12:54 --> Language Class Initialized
INFO - 2016-05-21 12:12:54 --> Loader Class Initialized
INFO - 2016-05-21 12:12:54 --> Helper loaded: url_helper
INFO - 2016-05-21 12:12:54 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:12:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:12:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:12:54 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:12:54 --> Helper loaded: form_helper
INFO - 2016-05-21 12:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:12:54 --> Form Validation Class Initialized
INFO - 2016-05-21 12:12:54 --> Controller Class Initialized
INFO - 2016-05-21 12:12:54 --> Model Class Initialized
INFO - 2016-05-21 12:12:54 --> Database Driver Class Initialized
INFO - 2016-05-21 12:12:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:12:54 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:12:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:12:54 --> Final output sent to browser
DEBUG - 2016-05-21 12:12:54 --> Total execution time: 0.1114
INFO - 2016-05-21 12:13:06 --> Config Class Initialized
INFO - 2016-05-21 12:13:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:06 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:06 --> URI Class Initialized
INFO - 2016-05-21 12:13:06 --> Router Class Initialized
INFO - 2016-05-21 12:13:06 --> Output Class Initialized
INFO - 2016-05-21 12:13:06 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:06 --> Input Class Initialized
INFO - 2016-05-21 12:13:06 --> Language Class Initialized
INFO - 2016-05-21 12:13:06 --> Loader Class Initialized
INFO - 2016-05-21 12:13:06 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:06 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:06 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:06 --> Controller Class Initialized
INFO - 2016-05-21 12:13:06 --> Model Class Initialized
INFO - 2016-05-21 12:13:06 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:06 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:13:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:13:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:13:06 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:06 --> Total execution time: 0.0825
INFO - 2016-05-21 12:13:06 --> Config Class Initialized
INFO - 2016-05-21 12:13:06 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:06 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:06 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:06 --> URI Class Initialized
INFO - 2016-05-21 12:13:06 --> Router Class Initialized
INFO - 2016-05-21 12:13:06 --> Output Class Initialized
INFO - 2016-05-21 12:13:06 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:06 --> Input Class Initialized
INFO - 2016-05-21 12:13:06 --> Language Class Initialized
INFO - 2016-05-21 12:13:06 --> Loader Class Initialized
INFO - 2016-05-21 12:13:06 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:06 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:06 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:06 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:06 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:06 --> Controller Class Initialized
INFO - 2016-05-21 12:13:06 --> Model Class Initialized
INFO - 2016-05-21 12:13:06 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:06 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:06 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:06 --> Total execution time: 0.1175
INFO - 2016-05-21 12:13:09 --> Config Class Initialized
INFO - 2016-05-21 12:13:09 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:09 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:09 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:09 --> URI Class Initialized
INFO - 2016-05-21 12:13:09 --> Router Class Initialized
INFO - 2016-05-21 12:13:09 --> Output Class Initialized
INFO - 2016-05-21 12:13:09 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:09 --> Input Class Initialized
INFO - 2016-05-21 12:13:09 --> Language Class Initialized
INFO - 2016-05-21 12:13:09 --> Loader Class Initialized
INFO - 2016-05-21 12:13:09 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:09 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:09 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:09 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:09 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:09 --> Controller Class Initialized
INFO - 2016-05-21 12:13:09 --> Model Class Initialized
INFO - 2016-05-21 12:13:09 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:09 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:09 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:13:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:13:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:13:09 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:09 --> Total execution time: 0.0771
INFO - 2016-05-21 12:13:10 --> Config Class Initialized
INFO - 2016-05-21 12:13:10 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:10 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:10 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:10 --> URI Class Initialized
INFO - 2016-05-21 12:13:10 --> Router Class Initialized
INFO - 2016-05-21 12:13:10 --> Output Class Initialized
INFO - 2016-05-21 12:13:10 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:10 --> Input Class Initialized
INFO - 2016-05-21 12:13:10 --> Language Class Initialized
INFO - 2016-05-21 12:13:10 --> Loader Class Initialized
INFO - 2016-05-21 12:13:10 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:10 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:10 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:10 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:10 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:10 --> Controller Class Initialized
INFO - 2016-05-21 12:13:10 --> Model Class Initialized
INFO - 2016-05-21 12:13:10 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:10 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:10 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:10 --> Total execution time: 0.1026
INFO - 2016-05-21 12:13:13 --> Config Class Initialized
INFO - 2016-05-21 12:13:13 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:13 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:13 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:13 --> URI Class Initialized
INFO - 2016-05-21 12:13:13 --> Router Class Initialized
INFO - 2016-05-21 12:13:13 --> Output Class Initialized
INFO - 2016-05-21 12:13:13 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:13 --> Input Class Initialized
INFO - 2016-05-21 12:13:13 --> Language Class Initialized
INFO - 2016-05-21 12:13:13 --> Loader Class Initialized
INFO - 2016-05-21 12:13:13 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:13 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:13 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:13 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:13 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:13 --> Controller Class Initialized
INFO - 2016-05-21 12:13:13 --> Model Class Initialized
INFO - 2016-05-21 12:13:13 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:13 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:13 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:13:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:13:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:13:13 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:13 --> Total execution time: 0.0779
INFO - 2016-05-21 12:13:13 --> Config Class Initialized
INFO - 2016-05-21 12:13:13 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:13 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:13 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:13 --> URI Class Initialized
INFO - 2016-05-21 12:13:13 --> Router Class Initialized
INFO - 2016-05-21 12:13:13 --> Output Class Initialized
INFO - 2016-05-21 12:13:13 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:13 --> Input Class Initialized
INFO - 2016-05-21 12:13:13 --> Language Class Initialized
INFO - 2016-05-21 12:13:13 --> Loader Class Initialized
INFO - 2016-05-21 12:13:13 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:13 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:13 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:13 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:13 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:13 --> Controller Class Initialized
INFO - 2016-05-21 12:13:13 --> Model Class Initialized
INFO - 2016-05-21 12:13:13 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:13 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:13 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:13 --> Total execution time: 0.1061
INFO - 2016-05-21 12:13:18 --> Config Class Initialized
INFO - 2016-05-21 12:13:18 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:18 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:18 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:18 --> URI Class Initialized
INFO - 2016-05-21 12:13:18 --> Router Class Initialized
INFO - 2016-05-21 12:13:18 --> Output Class Initialized
INFO - 2016-05-21 12:13:18 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:18 --> Input Class Initialized
INFO - 2016-05-21 12:13:18 --> Language Class Initialized
INFO - 2016-05-21 12:13:18 --> Loader Class Initialized
INFO - 2016-05-21 12:13:18 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:18 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:18 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:18 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:18 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:18 --> Controller Class Initialized
INFO - 2016-05-21 12:13:18 --> Model Class Initialized
INFO - 2016-05-21 12:13:18 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:18 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:18 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:13:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:13:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:13:18 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:18 --> Total execution time: 0.1467
INFO - 2016-05-21 12:13:18 --> Config Class Initialized
INFO - 2016-05-21 12:13:18 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:18 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:18 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:18 --> URI Class Initialized
INFO - 2016-05-21 12:13:18 --> Router Class Initialized
INFO - 2016-05-21 12:13:18 --> Output Class Initialized
INFO - 2016-05-21 12:13:18 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:18 --> Input Class Initialized
INFO - 2016-05-21 12:13:18 --> Language Class Initialized
INFO - 2016-05-21 12:13:18 --> Loader Class Initialized
INFO - 2016-05-21 12:13:18 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:18 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:18 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:18 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:18 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:18 --> Controller Class Initialized
INFO - 2016-05-21 12:13:18 --> Model Class Initialized
INFO - 2016-05-21 12:13:18 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:18 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:18 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:18 --> Total execution time: 0.1086
INFO - 2016-05-21 12:13:23 --> Config Class Initialized
INFO - 2016-05-21 12:13:23 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:23 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:23 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:23 --> URI Class Initialized
INFO - 2016-05-21 12:13:23 --> Router Class Initialized
INFO - 2016-05-21 12:13:23 --> Output Class Initialized
INFO - 2016-05-21 12:13:23 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:23 --> Input Class Initialized
INFO - 2016-05-21 12:13:23 --> Language Class Initialized
INFO - 2016-05-21 12:13:23 --> Loader Class Initialized
INFO - 2016-05-21 12:13:23 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:23 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:23 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:23 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:23 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:23 --> Controller Class Initialized
INFO - 2016-05-21 12:13:23 --> Model Class Initialized
INFO - 2016-05-21 12:13:23 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:23 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:23 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:13:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:13:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:13:23 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:23 --> Total execution time: 0.0793
INFO - 2016-05-21 12:13:23 --> Config Class Initialized
INFO - 2016-05-21 12:13:23 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:23 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:23 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:23 --> URI Class Initialized
INFO - 2016-05-21 12:13:23 --> Router Class Initialized
INFO - 2016-05-21 12:13:23 --> Output Class Initialized
INFO - 2016-05-21 12:13:23 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:23 --> Input Class Initialized
INFO - 2016-05-21 12:13:23 --> Language Class Initialized
INFO - 2016-05-21 12:13:23 --> Loader Class Initialized
INFO - 2016-05-21 12:13:23 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:23 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:23 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:23 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:23 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:23 --> Controller Class Initialized
INFO - 2016-05-21 12:13:23 --> Model Class Initialized
INFO - 2016-05-21 12:13:23 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:23 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:23 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:23 --> Total execution time: 0.1048
INFO - 2016-05-21 12:13:25 --> Config Class Initialized
INFO - 2016-05-21 12:13:25 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:25 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:25 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:25 --> URI Class Initialized
INFO - 2016-05-21 12:13:25 --> Router Class Initialized
INFO - 2016-05-21 12:13:25 --> Output Class Initialized
INFO - 2016-05-21 12:13:25 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:25 --> Input Class Initialized
INFO - 2016-05-21 12:13:25 --> Language Class Initialized
INFO - 2016-05-21 12:13:25 --> Loader Class Initialized
INFO - 2016-05-21 12:13:25 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:25 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:25 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:25 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:25 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:25 --> Controller Class Initialized
INFO - 2016-05-21 12:13:25 --> Model Class Initialized
INFO - 2016-05-21 12:13:25 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:25 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:25 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:13:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:13:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:13:25 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:25 --> Total execution time: 0.0791
INFO - 2016-05-21 12:13:26 --> Config Class Initialized
INFO - 2016-05-21 12:13:26 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:26 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:26 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:26 --> URI Class Initialized
INFO - 2016-05-21 12:13:26 --> Router Class Initialized
INFO - 2016-05-21 12:13:26 --> Output Class Initialized
INFO - 2016-05-21 12:13:26 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:26 --> Input Class Initialized
INFO - 2016-05-21 12:13:26 --> Language Class Initialized
INFO - 2016-05-21 12:13:26 --> Loader Class Initialized
INFO - 2016-05-21 12:13:26 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:26 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:26 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:26 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:26 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:26 --> Controller Class Initialized
INFO - 2016-05-21 12:13:26 --> Model Class Initialized
INFO - 2016-05-21 12:13:26 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:26 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:26 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:26 --> Total execution time: 0.1064
INFO - 2016-05-21 12:13:33 --> Config Class Initialized
INFO - 2016-05-21 12:13:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:33 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:33 --> URI Class Initialized
INFO - 2016-05-21 12:13:33 --> Router Class Initialized
INFO - 2016-05-21 12:13:33 --> Output Class Initialized
INFO - 2016-05-21 12:13:33 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:33 --> Input Class Initialized
INFO - 2016-05-21 12:13:33 --> Language Class Initialized
INFO - 2016-05-21 12:13:33 --> Loader Class Initialized
INFO - 2016-05-21 12:13:33 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:33 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:33 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:33 --> Controller Class Initialized
INFO - 2016-05-21 12:13:33 --> Model Class Initialized
INFO - 2016-05-21 12:13:33 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:33 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:13:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:13:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:13:33 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:33 --> Total execution time: 0.0913
INFO - 2016-05-21 12:13:33 --> Config Class Initialized
INFO - 2016-05-21 12:13:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:33 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:33 --> URI Class Initialized
INFO - 2016-05-21 12:13:33 --> Router Class Initialized
INFO - 2016-05-21 12:13:33 --> Output Class Initialized
INFO - 2016-05-21 12:13:33 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:33 --> Input Class Initialized
INFO - 2016-05-21 12:13:33 --> Language Class Initialized
INFO - 2016-05-21 12:13:33 --> Loader Class Initialized
INFO - 2016-05-21 12:13:33 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:33 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:33 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:33 --> Controller Class Initialized
INFO - 2016-05-21 12:13:33 --> Model Class Initialized
INFO - 2016-05-21 12:13:33 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:33 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:33 --> Total execution time: 0.1025
INFO - 2016-05-21 12:13:53 --> Config Class Initialized
INFO - 2016-05-21 12:13:53 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:53 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:53 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:53 --> URI Class Initialized
INFO - 2016-05-21 12:13:53 --> Router Class Initialized
INFO - 2016-05-21 12:13:53 --> Output Class Initialized
INFO - 2016-05-21 12:13:53 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:53 --> Input Class Initialized
INFO - 2016-05-21 12:13:53 --> Language Class Initialized
INFO - 2016-05-21 12:13:53 --> Loader Class Initialized
INFO - 2016-05-21 12:13:53 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:53 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:53 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:53 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:53 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:53 --> Controller Class Initialized
INFO - 2016-05-21 12:13:53 --> Model Class Initialized
INFO - 2016-05-21 12:13:53 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:53 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:54 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:13:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:13:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:13:54 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:54 --> Total execution time: 0.0817
INFO - 2016-05-21 12:13:54 --> Config Class Initialized
INFO - 2016-05-21 12:13:54 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:13:54 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:13:54 --> Utf8 Class Initialized
INFO - 2016-05-21 12:13:54 --> URI Class Initialized
INFO - 2016-05-21 12:13:54 --> Router Class Initialized
INFO - 2016-05-21 12:13:54 --> Output Class Initialized
INFO - 2016-05-21 12:13:54 --> Security Class Initialized
DEBUG - 2016-05-21 12:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:13:54 --> Input Class Initialized
INFO - 2016-05-21 12:13:54 --> Language Class Initialized
INFO - 2016-05-21 12:13:54 --> Loader Class Initialized
INFO - 2016-05-21 12:13:54 --> Helper loaded: url_helper
INFO - 2016-05-21 12:13:54 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:13:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:13:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:13:54 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:13:54 --> Helper loaded: form_helper
INFO - 2016-05-21 12:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:13:54 --> Form Validation Class Initialized
INFO - 2016-05-21 12:13:54 --> Controller Class Initialized
INFO - 2016-05-21 12:13:54 --> Model Class Initialized
INFO - 2016-05-21 12:13:54 --> Database Driver Class Initialized
INFO - 2016-05-21 12:13:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:13:54 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:13:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:13:54 --> Final output sent to browser
DEBUG - 2016-05-21 12:13:54 --> Total execution time: 0.0934
INFO - 2016-05-21 12:14:55 --> Config Class Initialized
INFO - 2016-05-21 12:14:55 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:14:55 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:14:55 --> Utf8 Class Initialized
INFO - 2016-05-21 12:14:55 --> URI Class Initialized
INFO - 2016-05-21 12:14:55 --> Router Class Initialized
INFO - 2016-05-21 12:14:55 --> Output Class Initialized
INFO - 2016-05-21 12:14:55 --> Security Class Initialized
DEBUG - 2016-05-21 12:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:14:55 --> Input Class Initialized
INFO - 2016-05-21 12:14:55 --> Language Class Initialized
INFO - 2016-05-21 12:14:55 --> Loader Class Initialized
INFO - 2016-05-21 12:14:55 --> Helper loaded: url_helper
INFO - 2016-05-21 12:14:55 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:14:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:14:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:14:55 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:14:55 --> Helper loaded: form_helper
INFO - 2016-05-21 12:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:14:55 --> Form Validation Class Initialized
INFO - 2016-05-21 12:14:55 --> Controller Class Initialized
INFO - 2016-05-21 12:14:55 --> Model Class Initialized
INFO - 2016-05-21 12:14:55 --> Database Driver Class Initialized
INFO - 2016-05-21 12:14:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:14:55 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:14:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:14:55 --> Final output sent to browser
DEBUG - 2016-05-21 12:14:55 --> Total execution time: 0.0713
INFO - 2016-05-21 12:15:55 --> Config Class Initialized
INFO - 2016-05-21 12:15:55 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:15:55 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:15:55 --> Utf8 Class Initialized
INFO - 2016-05-21 12:15:55 --> URI Class Initialized
INFO - 2016-05-21 12:15:55 --> Router Class Initialized
INFO - 2016-05-21 12:15:55 --> Output Class Initialized
INFO - 2016-05-21 12:15:55 --> Security Class Initialized
DEBUG - 2016-05-21 12:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:15:55 --> Input Class Initialized
INFO - 2016-05-21 12:15:55 --> Language Class Initialized
INFO - 2016-05-21 12:15:55 --> Loader Class Initialized
INFO - 2016-05-21 12:15:55 --> Helper loaded: url_helper
INFO - 2016-05-21 12:15:55 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:15:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:15:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:15:55 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:15:55 --> Helper loaded: form_helper
INFO - 2016-05-21 12:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:15:55 --> Form Validation Class Initialized
INFO - 2016-05-21 12:15:55 --> Controller Class Initialized
INFO - 2016-05-21 12:15:55 --> Model Class Initialized
INFO - 2016-05-21 12:15:55 --> Database Driver Class Initialized
INFO - 2016-05-21 12:15:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:15:55 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:15:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:15:55 --> Final output sent to browser
DEBUG - 2016-05-21 12:15:55 --> Total execution time: 0.0722
INFO - 2016-05-21 12:16:36 --> Config Class Initialized
INFO - 2016-05-21 12:16:36 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:16:36 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:16:36 --> Utf8 Class Initialized
INFO - 2016-05-21 12:16:36 --> URI Class Initialized
INFO - 2016-05-21 12:16:36 --> Router Class Initialized
INFO - 2016-05-21 12:16:36 --> Output Class Initialized
INFO - 2016-05-21 12:16:36 --> Security Class Initialized
DEBUG - 2016-05-21 12:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:16:36 --> Input Class Initialized
INFO - 2016-05-21 12:16:36 --> Language Class Initialized
INFO - 2016-05-21 12:16:36 --> Loader Class Initialized
INFO - 2016-05-21 12:16:36 --> Helper loaded: url_helper
INFO - 2016-05-21 12:16:36 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:16:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:16:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:16:36 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:16:36 --> Helper loaded: form_helper
INFO - 2016-05-21 12:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:16:37 --> Form Validation Class Initialized
INFO - 2016-05-21 12:16:37 --> Controller Class Initialized
INFO - 2016-05-21 12:16:37 --> Model Class Initialized
INFO - 2016-05-21 12:16:37 --> Database Driver Class Initialized
INFO - 2016-05-21 12:16:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:16:37 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:16:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:16:37 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:16:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:16:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:16:37 --> Final output sent to browser
DEBUG - 2016-05-21 12:16:37 --> Total execution time: 0.4574
INFO - 2016-05-21 12:16:37 --> Config Class Initialized
INFO - 2016-05-21 12:16:37 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:16:37 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:16:37 --> Utf8 Class Initialized
INFO - 2016-05-21 12:16:37 --> URI Class Initialized
INFO - 2016-05-21 12:16:37 --> Router Class Initialized
INFO - 2016-05-21 12:16:37 --> Output Class Initialized
INFO - 2016-05-21 12:16:37 --> Security Class Initialized
DEBUG - 2016-05-21 12:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:16:37 --> Input Class Initialized
INFO - 2016-05-21 12:16:37 --> Language Class Initialized
INFO - 2016-05-21 12:16:37 --> Loader Class Initialized
INFO - 2016-05-21 12:16:37 --> Helper loaded: url_helper
INFO - 2016-05-21 12:16:37 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:16:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:16:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:16:37 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:16:37 --> Helper loaded: form_helper
INFO - 2016-05-21 12:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:16:37 --> Form Validation Class Initialized
INFO - 2016-05-21 12:16:37 --> Controller Class Initialized
INFO - 2016-05-21 12:16:37 --> Model Class Initialized
INFO - 2016-05-21 12:16:37 --> Database Driver Class Initialized
INFO - 2016-05-21 12:16:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:16:37 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:16:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:16:37 --> Final output sent to browser
DEBUG - 2016-05-21 12:16:37 --> Total execution time: 0.1094
INFO - 2016-05-21 12:16:43 --> Config Class Initialized
INFO - 2016-05-21 12:16:43 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:16:43 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:16:43 --> Utf8 Class Initialized
INFO - 2016-05-21 12:16:43 --> URI Class Initialized
INFO - 2016-05-21 12:16:43 --> Router Class Initialized
INFO - 2016-05-21 12:16:43 --> Output Class Initialized
INFO - 2016-05-21 12:16:43 --> Security Class Initialized
DEBUG - 2016-05-21 12:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:16:43 --> Input Class Initialized
INFO - 2016-05-21 12:16:43 --> Language Class Initialized
INFO - 2016-05-21 12:16:43 --> Loader Class Initialized
INFO - 2016-05-21 12:16:43 --> Helper loaded: url_helper
INFO - 2016-05-21 12:16:43 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:16:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:16:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:16:43 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:16:43 --> Helper loaded: form_helper
INFO - 2016-05-21 12:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:16:43 --> Form Validation Class Initialized
INFO - 2016-05-21 12:16:43 --> Controller Class Initialized
INFO - 2016-05-21 12:16:43 --> Model Class Initialized
INFO - 2016-05-21 12:16:43 --> Database Driver Class Initialized
INFO - 2016-05-21 12:16:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:16:43 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:16:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:16:43 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:16:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:16:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:16:43 --> Final output sent to browser
DEBUG - 2016-05-21 12:16:43 --> Total execution time: 0.0800
INFO - 2016-05-21 12:16:43 --> Config Class Initialized
INFO - 2016-05-21 12:16:43 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:16:43 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:16:43 --> Utf8 Class Initialized
INFO - 2016-05-21 12:16:43 --> URI Class Initialized
INFO - 2016-05-21 12:16:43 --> Router Class Initialized
INFO - 2016-05-21 12:16:43 --> Output Class Initialized
INFO - 2016-05-21 12:16:43 --> Security Class Initialized
DEBUG - 2016-05-21 12:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:16:43 --> Input Class Initialized
INFO - 2016-05-21 12:16:43 --> Language Class Initialized
INFO - 2016-05-21 12:16:43 --> Loader Class Initialized
INFO - 2016-05-21 12:16:43 --> Helper loaded: url_helper
INFO - 2016-05-21 12:16:43 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:16:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:16:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:16:43 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:16:43 --> Helper loaded: form_helper
INFO - 2016-05-21 12:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:16:43 --> Form Validation Class Initialized
INFO - 2016-05-21 12:16:43 --> Controller Class Initialized
INFO - 2016-05-21 12:16:43 --> Model Class Initialized
INFO - 2016-05-21 12:16:43 --> Database Driver Class Initialized
INFO - 2016-05-21 12:16:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:16:43 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:16:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:16:43 --> Final output sent to browser
DEBUG - 2016-05-21 12:16:43 --> Total execution time: 0.1332
INFO - 2016-05-21 12:17:08 --> Config Class Initialized
INFO - 2016-05-21 12:17:08 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:08 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:08 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:08 --> URI Class Initialized
INFO - 2016-05-21 12:17:08 --> Router Class Initialized
INFO - 2016-05-21 12:17:08 --> Output Class Initialized
INFO - 2016-05-21 12:17:08 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:08 --> Input Class Initialized
INFO - 2016-05-21 12:17:08 --> Language Class Initialized
INFO - 2016-05-21 12:17:08 --> Loader Class Initialized
INFO - 2016-05-21 12:17:08 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:08 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:08 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:08 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:08 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:08 --> Controller Class Initialized
INFO - 2016-05-21 12:17:08 --> Model Class Initialized
INFO - 2016-05-21 12:17:08 --> Database Driver Class Initialized
INFO - 2016-05-21 12:17:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:17:08 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:17:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:17:08 --> Config Class Initialized
INFO - 2016-05-21 12:17:08 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:08 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:08 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:08 --> URI Class Initialized
INFO - 2016-05-21 12:17:08 --> Router Class Initialized
INFO - 2016-05-21 12:17:08 --> Output Class Initialized
INFO - 2016-05-21 12:17:08 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:08 --> Input Class Initialized
INFO - 2016-05-21 12:17:08 --> Language Class Initialized
INFO - 2016-05-21 12:17:08 --> Loader Class Initialized
INFO - 2016-05-21 12:17:08 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:08 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:08 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:08 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:08 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:08 --> Controller Class Initialized
INFO - 2016-05-21 12:17:08 --> Model Class Initialized
INFO - 2016-05-21 12:17:08 --> Database Driver Class Initialized
INFO - 2016-05-21 12:17:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-21 12:17:08 --> Final output sent to browser
DEBUG - 2016-05-21 12:17:08 --> Total execution time: 0.1384
INFO - 2016-05-21 12:17:13 --> Config Class Initialized
INFO - 2016-05-21 12:17:13 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:13 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:13 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:13 --> URI Class Initialized
INFO - 2016-05-21 12:17:13 --> Router Class Initialized
INFO - 2016-05-21 12:17:13 --> Output Class Initialized
INFO - 2016-05-21 12:17:13 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:13 --> Input Class Initialized
INFO - 2016-05-21 12:17:13 --> Language Class Initialized
INFO - 2016-05-21 12:17:13 --> Loader Class Initialized
INFO - 2016-05-21 12:17:13 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:13 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:13 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:13 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:13 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:13 --> Controller Class Initialized
INFO - 2016-05-21 12:17:13 --> Model Class Initialized
INFO - 2016-05-21 12:17:13 --> Database Driver Class Initialized
INFO - 2016-05-21 12:17:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-21 12:17:14 --> Final output sent to browser
DEBUG - 2016-05-21 12:17:14 --> Total execution time: 0.3798
INFO - 2016-05-21 12:17:19 --> Config Class Initialized
INFO - 2016-05-21 12:17:19 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:19 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:19 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:19 --> URI Class Initialized
INFO - 2016-05-21 12:17:19 --> Router Class Initialized
INFO - 2016-05-21 12:17:19 --> Output Class Initialized
INFO - 2016-05-21 12:17:19 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:19 --> Input Class Initialized
INFO - 2016-05-21 12:17:19 --> Language Class Initialized
INFO - 2016-05-21 12:17:19 --> Loader Class Initialized
INFO - 2016-05-21 12:17:19 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:19 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:19 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:19 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:19 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:19 --> Controller Class Initialized
INFO - 2016-05-21 12:17:19 --> Model Class Initialized
INFO - 2016-05-21 12:17:19 --> Database Driver Class Initialized
INFO - 2016-05-21 12:17:20 --> Config Class Initialized
INFO - 2016-05-21 12:17:20 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:20 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:20 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:20 --> URI Class Initialized
DEBUG - 2016-05-21 12:17:20 --> No URI present. Default controller set.
INFO - 2016-05-21 12:17:20 --> Router Class Initialized
INFO - 2016-05-21 12:17:20 --> Output Class Initialized
INFO - 2016-05-21 12:17:20 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:20 --> Input Class Initialized
INFO - 2016-05-21 12:17:20 --> Language Class Initialized
INFO - 2016-05-21 12:17:20 --> Loader Class Initialized
INFO - 2016-05-21 12:17:20 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:20 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:20 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:20 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:20 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:20 --> Controller Class Initialized
INFO - 2016-05-21 12:17:20 --> Model Class Initialized
INFO - 2016-05-21 12:17:20 --> Database Driver Class Initialized
INFO - 2016-05-21 12:17:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:17:20 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:17:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:17:20 --> Config Class Initialized
INFO - 2016-05-21 12:17:20 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:20 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:20 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:20 --> URI Class Initialized
INFO - 2016-05-21 12:17:20 --> Router Class Initialized
INFO - 2016-05-21 12:17:20 --> Output Class Initialized
INFO - 2016-05-21 12:17:20 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:20 --> Input Class Initialized
INFO - 2016-05-21 12:17:20 --> Language Class Initialized
INFO - 2016-05-21 12:17:20 --> Loader Class Initialized
INFO - 2016-05-21 12:17:20 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:20 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:20 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:20 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:20 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:20 --> Controller Class Initialized
INFO - 2016-05-21 12:17:20 --> Model Class Initialized
INFO - 2016-05-21 12:17:20 --> Database Driver Class Initialized
INFO - 2016-05-21 12:17:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-21 12:17:20 --> Final output sent to browser
DEBUG - 2016-05-21 12:17:20 --> Total execution time: 0.1461
INFO - 2016-05-21 12:17:27 --> Config Class Initialized
INFO - 2016-05-21 12:17:27 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:27 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:27 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:27 --> URI Class Initialized
INFO - 2016-05-21 12:17:27 --> Router Class Initialized
INFO - 2016-05-21 12:17:27 --> Output Class Initialized
INFO - 2016-05-21 12:17:27 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:27 --> Input Class Initialized
INFO - 2016-05-21 12:17:27 --> Language Class Initialized
INFO - 2016-05-21 12:17:27 --> Loader Class Initialized
INFO - 2016-05-21 12:17:27 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:27 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:27 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:27 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:27 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:27 --> Controller Class Initialized
INFO - 2016-05-21 12:17:27 --> Model Class Initialized
INFO - 2016-05-21 12:17:27 --> Database Driver Class Initialized
INFO - 2016-05-21 12:17:27 --> Config Class Initialized
INFO - 2016-05-21 12:17:27 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:27 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:27 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:27 --> URI Class Initialized
INFO - 2016-05-21 12:17:27 --> Router Class Initialized
INFO - 2016-05-21 12:17:27 --> Output Class Initialized
INFO - 2016-05-21 12:17:27 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:27 --> Input Class Initialized
INFO - 2016-05-21 12:17:27 --> Language Class Initialized
INFO - 2016-05-21 12:17:27 --> Loader Class Initialized
INFO - 2016-05-21 12:17:27 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:27 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:28 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:28 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:28 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:28 --> Controller Class Initialized
INFO - 2016-05-21 12:17:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-21 12:17:28 --> Final output sent to browser
DEBUG - 2016-05-21 12:17:28 --> Total execution time: 0.0540
INFO - 2016-05-21 12:17:34 --> Config Class Initialized
INFO - 2016-05-21 12:17:34 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:34 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:34 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:34 --> URI Class Initialized
INFO - 2016-05-21 12:17:34 --> Router Class Initialized
INFO - 2016-05-21 12:17:34 --> Output Class Initialized
INFO - 2016-05-21 12:17:34 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:34 --> Input Class Initialized
INFO - 2016-05-21 12:17:34 --> Language Class Initialized
INFO - 2016-05-21 12:17:34 --> Loader Class Initialized
INFO - 2016-05-21 12:17:34 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:34 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:34 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:34 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:34 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:34 --> Controller Class Initialized
INFO - 2016-05-21 12:17:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-21 12:17:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:17:34 --> Final output sent to browser
DEBUG - 2016-05-21 12:17:34 --> Total execution time: 0.0728
INFO - 2016-05-21 12:17:35 --> Config Class Initialized
INFO - 2016-05-21 12:17:35 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:35 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:35 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:35 --> URI Class Initialized
INFO - 2016-05-21 12:17:35 --> Router Class Initialized
INFO - 2016-05-21 12:17:35 --> Output Class Initialized
INFO - 2016-05-21 12:17:35 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:35 --> Input Class Initialized
INFO - 2016-05-21 12:17:35 --> Language Class Initialized
INFO - 2016-05-21 12:17:35 --> Loader Class Initialized
INFO - 2016-05-21 12:17:35 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:35 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:35 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:35 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:35 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:35 --> Controller Class Initialized
INFO - 2016-05-21 12:17:35 --> Model Class Initialized
INFO - 2016-05-21 12:17:35 --> Database Driver Class Initialized
INFO - 2016-05-21 12:17:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:17:35 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:17:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:17:35 --> Final output sent to browser
DEBUG - 2016-05-21 12:17:35 --> Total execution time: 0.1200
INFO - 2016-05-21 12:17:40 --> Config Class Initialized
INFO - 2016-05-21 12:17:40 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:40 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:40 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:40 --> URI Class Initialized
INFO - 2016-05-21 12:17:40 --> Router Class Initialized
INFO - 2016-05-21 12:17:40 --> Output Class Initialized
INFO - 2016-05-21 12:17:40 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:40 --> Input Class Initialized
INFO - 2016-05-21 12:17:40 --> Language Class Initialized
INFO - 2016-05-21 12:17:40 --> Loader Class Initialized
INFO - 2016-05-21 12:17:40 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:40 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:40 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:40 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:40 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:40 --> Controller Class Initialized
INFO - 2016-05-21 12:17:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-21 12:17:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 12:17:40 --> Final output sent to browser
DEBUG - 2016-05-21 12:17:40 --> Total execution time: 0.0597
INFO - 2016-05-21 12:17:41 --> Config Class Initialized
INFO - 2016-05-21 12:17:41 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:41 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:41 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:41 --> URI Class Initialized
INFO - 2016-05-21 12:17:41 --> Router Class Initialized
INFO - 2016-05-21 12:17:41 --> Output Class Initialized
INFO - 2016-05-21 12:17:41 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:41 --> Input Class Initialized
INFO - 2016-05-21 12:17:41 --> Language Class Initialized
INFO - 2016-05-21 12:17:41 --> Loader Class Initialized
INFO - 2016-05-21 12:17:41 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:41 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:41 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:41 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:41 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:41 --> Controller Class Initialized
INFO - 2016-05-21 12:17:41 --> Model Class Initialized
INFO - 2016-05-21 12:17:41 --> Database Driver Class Initialized
INFO - 2016-05-21 12:17:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:17:41 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:17:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:17:41 --> Final output sent to browser
DEBUG - 2016-05-21 12:17:41 --> Total execution time: 0.0842
INFO - 2016-05-21 12:17:43 --> Config Class Initialized
INFO - 2016-05-21 12:17:43 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:43 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:43 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:43 --> URI Class Initialized
INFO - 2016-05-21 12:17:43 --> Router Class Initialized
INFO - 2016-05-21 12:17:43 --> Output Class Initialized
INFO - 2016-05-21 12:17:43 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:43 --> Input Class Initialized
INFO - 2016-05-21 12:17:43 --> Language Class Initialized
INFO - 2016-05-21 12:17:43 --> Loader Class Initialized
INFO - 2016-05-21 12:17:43 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:43 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:43 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:43 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:43 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:43 --> Controller Class Initialized
INFO - 2016-05-21 12:17:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-21 12:17:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 12:17:43 --> Final output sent to browser
DEBUG - 2016-05-21 12:17:43 --> Total execution time: 0.0580
INFO - 2016-05-21 12:17:43 --> Config Class Initialized
INFO - 2016-05-21 12:17:43 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:43 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:43 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:43 --> URI Class Initialized
INFO - 2016-05-21 12:17:43 --> Router Class Initialized
INFO - 2016-05-21 12:17:43 --> Output Class Initialized
INFO - 2016-05-21 12:17:43 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:43 --> Input Class Initialized
INFO - 2016-05-21 12:17:43 --> Language Class Initialized
INFO - 2016-05-21 12:17:43 --> Loader Class Initialized
INFO - 2016-05-21 12:17:43 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:43 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:43 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:43 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:43 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:43 --> Controller Class Initialized
INFO - 2016-05-21 12:17:43 --> Model Class Initialized
INFO - 2016-05-21 12:17:43 --> Database Driver Class Initialized
INFO - 2016-05-21 12:17:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:17:43 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:17:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:17:43 --> Final output sent to browser
DEBUG - 2016-05-21 12:17:43 --> Total execution time: 0.0969
INFO - 2016-05-21 12:17:44 --> Config Class Initialized
INFO - 2016-05-21 12:17:44 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:44 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:44 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:44 --> URI Class Initialized
INFO - 2016-05-21 12:17:44 --> Router Class Initialized
INFO - 2016-05-21 12:17:44 --> Output Class Initialized
INFO - 2016-05-21 12:17:44 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:44 --> Input Class Initialized
INFO - 2016-05-21 12:17:44 --> Language Class Initialized
INFO - 2016-05-21 12:17:44 --> Loader Class Initialized
INFO - 2016-05-21 12:17:44 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:44 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:44 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:44 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:44 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:44 --> Controller Class Initialized
INFO - 2016-05-21 12:17:44 --> Model Class Initialized
INFO - 2016-05-21 12:17:44 --> Database Driver Class Initialized
INFO - 2016-05-21 12:17:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:17:44 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:17:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:17:44 --> Final output sent to browser
DEBUG - 2016-05-21 12:17:44 --> Total execution time: 0.0689
INFO - 2016-05-21 12:17:47 --> Config Class Initialized
INFO - 2016-05-21 12:17:47 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:47 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:47 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:47 --> URI Class Initialized
INFO - 2016-05-21 12:17:47 --> Router Class Initialized
INFO - 2016-05-21 12:17:47 --> Output Class Initialized
INFO - 2016-05-21 12:17:47 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:47 --> Input Class Initialized
INFO - 2016-05-21 12:17:47 --> Language Class Initialized
INFO - 2016-05-21 12:17:47 --> Loader Class Initialized
INFO - 2016-05-21 12:17:47 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:47 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:47 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:47 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:47 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:47 --> Controller Class Initialized
INFO - 2016-05-21 12:17:47 --> Model Class Initialized
INFO - 2016-05-21 12:17:47 --> Database Driver Class Initialized
INFO - 2016-05-21 12:17:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:17:47 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:17:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:17:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:17:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-21 12:17:47 --> Final output sent to browser
DEBUG - 2016-05-21 12:17:47 --> Total execution time: 0.0793
INFO - 2016-05-21 12:17:47 --> Config Class Initialized
INFO - 2016-05-21 12:17:47 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:17:47 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:17:47 --> Utf8 Class Initialized
INFO - 2016-05-21 12:17:47 --> URI Class Initialized
INFO - 2016-05-21 12:17:47 --> Router Class Initialized
INFO - 2016-05-21 12:17:47 --> Output Class Initialized
INFO - 2016-05-21 12:17:47 --> Security Class Initialized
DEBUG - 2016-05-21 12:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:17:47 --> Input Class Initialized
INFO - 2016-05-21 12:17:47 --> Language Class Initialized
INFO - 2016-05-21 12:17:47 --> Loader Class Initialized
INFO - 2016-05-21 12:17:47 --> Helper loaded: url_helper
INFO - 2016-05-21 12:17:47 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:17:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:17:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:17:47 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:17:47 --> Helper loaded: form_helper
INFO - 2016-05-21 12:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:17:47 --> Form Validation Class Initialized
INFO - 2016-05-21 12:17:47 --> Controller Class Initialized
INFO - 2016-05-21 12:17:47 --> Model Class Initialized
INFO - 2016-05-21 12:17:47 --> Database Driver Class Initialized
INFO - 2016-05-21 12:17:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:17:47 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:17:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:17:47 --> Final output sent to browser
DEBUG - 2016-05-21 12:17:47 --> Total execution time: 0.0831
INFO - 2016-05-21 12:18:43 --> Config Class Initialized
INFO - 2016-05-21 12:18:43 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:18:43 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:18:43 --> Utf8 Class Initialized
INFO - 2016-05-21 12:18:43 --> URI Class Initialized
INFO - 2016-05-21 12:18:43 --> Router Class Initialized
INFO - 2016-05-21 12:18:43 --> Output Class Initialized
INFO - 2016-05-21 12:18:43 --> Security Class Initialized
DEBUG - 2016-05-21 12:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:18:43 --> Input Class Initialized
INFO - 2016-05-21 12:18:43 --> Language Class Initialized
INFO - 2016-05-21 12:18:43 --> Loader Class Initialized
INFO - 2016-05-21 12:18:43 --> Helper loaded: url_helper
INFO - 2016-05-21 12:18:43 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:18:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:18:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:18:43 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:18:43 --> Helper loaded: form_helper
INFO - 2016-05-21 12:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:18:43 --> Form Validation Class Initialized
INFO - 2016-05-21 12:18:43 --> Controller Class Initialized
INFO - 2016-05-21 12:18:43 --> Model Class Initialized
INFO - 2016-05-21 12:18:43 --> Database Driver Class Initialized
INFO - 2016-05-21 12:18:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:18:43 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:18:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:18:43 --> Final output sent to browser
DEBUG - 2016-05-21 12:18:43 --> Total execution time: 0.0853
INFO - 2016-05-21 12:19:43 --> Config Class Initialized
INFO - 2016-05-21 12:19:43 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:19:43 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:19:43 --> Utf8 Class Initialized
INFO - 2016-05-21 12:19:43 --> URI Class Initialized
INFO - 2016-05-21 12:19:43 --> Router Class Initialized
INFO - 2016-05-21 12:19:43 --> Output Class Initialized
INFO - 2016-05-21 12:19:43 --> Security Class Initialized
DEBUG - 2016-05-21 12:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:19:43 --> Input Class Initialized
INFO - 2016-05-21 12:19:43 --> Language Class Initialized
INFO - 2016-05-21 12:19:43 --> Loader Class Initialized
INFO - 2016-05-21 12:19:43 --> Helper loaded: url_helper
INFO - 2016-05-21 12:19:43 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:19:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:19:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:19:43 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:19:43 --> Helper loaded: form_helper
INFO - 2016-05-21 12:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:19:43 --> Form Validation Class Initialized
INFO - 2016-05-21 12:19:43 --> Controller Class Initialized
INFO - 2016-05-21 12:19:43 --> Model Class Initialized
INFO - 2016-05-21 12:19:43 --> Database Driver Class Initialized
INFO - 2016-05-21 12:19:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:19:43 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:19:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:19:43 --> Final output sent to browser
DEBUG - 2016-05-21 12:19:43 --> Total execution time: 0.0752
INFO - 2016-05-21 12:20:44 --> Config Class Initialized
INFO - 2016-05-21 12:20:44 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:20:44 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:20:44 --> Utf8 Class Initialized
INFO - 2016-05-21 12:20:44 --> URI Class Initialized
INFO - 2016-05-21 12:20:44 --> Router Class Initialized
INFO - 2016-05-21 12:20:44 --> Output Class Initialized
INFO - 2016-05-21 12:20:44 --> Security Class Initialized
DEBUG - 2016-05-21 12:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:20:44 --> Input Class Initialized
INFO - 2016-05-21 12:20:44 --> Language Class Initialized
INFO - 2016-05-21 12:20:44 --> Loader Class Initialized
INFO - 2016-05-21 12:20:44 --> Helper loaded: url_helper
INFO - 2016-05-21 12:20:44 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:20:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:20:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:20:44 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:20:44 --> Helper loaded: form_helper
INFO - 2016-05-21 12:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:20:44 --> Form Validation Class Initialized
INFO - 2016-05-21 12:20:44 --> Controller Class Initialized
INFO - 2016-05-21 12:20:44 --> Model Class Initialized
INFO - 2016-05-21 12:20:44 --> Database Driver Class Initialized
INFO - 2016-05-21 12:20:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:20:44 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:20:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:20:44 --> Final output sent to browser
DEBUG - 2016-05-21 12:20:44 --> Total execution time: 0.0786
INFO - 2016-05-21 12:21:44 --> Config Class Initialized
INFO - 2016-05-21 12:21:44 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:21:44 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:21:44 --> Utf8 Class Initialized
INFO - 2016-05-21 12:21:44 --> URI Class Initialized
INFO - 2016-05-21 12:21:44 --> Router Class Initialized
INFO - 2016-05-21 12:21:44 --> Output Class Initialized
INFO - 2016-05-21 12:21:44 --> Security Class Initialized
DEBUG - 2016-05-21 12:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:21:44 --> Input Class Initialized
INFO - 2016-05-21 12:21:44 --> Language Class Initialized
INFO - 2016-05-21 12:21:44 --> Loader Class Initialized
INFO - 2016-05-21 12:21:44 --> Helper loaded: url_helper
INFO - 2016-05-21 12:21:44 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:21:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:21:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:21:44 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:21:44 --> Helper loaded: form_helper
INFO - 2016-05-21 12:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:21:44 --> Form Validation Class Initialized
INFO - 2016-05-21 12:21:44 --> Controller Class Initialized
INFO - 2016-05-21 12:21:44 --> Model Class Initialized
INFO - 2016-05-21 12:21:44 --> Database Driver Class Initialized
INFO - 2016-05-21 12:21:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:21:44 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:21:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:21:44 --> Final output sent to browser
DEBUG - 2016-05-21 12:21:44 --> Total execution time: 0.0722
INFO - 2016-05-21 12:21:57 --> Config Class Initialized
INFO - 2016-05-21 12:21:57 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:21:57 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:21:57 --> Utf8 Class Initialized
INFO - 2016-05-21 12:21:57 --> URI Class Initialized
INFO - 2016-05-21 12:21:57 --> Router Class Initialized
INFO - 2016-05-21 12:21:57 --> Output Class Initialized
INFO - 2016-05-21 12:21:57 --> Security Class Initialized
DEBUG - 2016-05-21 12:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:21:57 --> Input Class Initialized
INFO - 2016-05-21 12:21:57 --> Language Class Initialized
INFO - 2016-05-21 12:21:57 --> Loader Class Initialized
INFO - 2016-05-21 12:21:57 --> Helper loaded: url_helper
INFO - 2016-05-21 12:21:57 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:21:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:21:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:21:57 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:21:57 --> Helper loaded: form_helper
INFO - 2016-05-21 12:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:21:57 --> Form Validation Class Initialized
INFO - 2016-05-21 12:21:57 --> Controller Class Initialized
INFO - 2016-05-21 12:21:57 --> Model Class Initialized
INFO - 2016-05-21 12:21:57 --> Database Driver Class Initialized
INFO - 2016-05-21 12:21:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:21:57 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:21:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:21:57 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:21:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:21:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:21:57 --> Final output sent to browser
DEBUG - 2016-05-21 12:21:57 --> Total execution time: 0.2107
INFO - 2016-05-21 12:21:58 --> Config Class Initialized
INFO - 2016-05-21 12:21:58 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:21:58 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:21:58 --> Utf8 Class Initialized
INFO - 2016-05-21 12:21:58 --> URI Class Initialized
INFO - 2016-05-21 12:21:58 --> Router Class Initialized
INFO - 2016-05-21 12:21:58 --> Output Class Initialized
INFO - 2016-05-21 12:21:58 --> Security Class Initialized
DEBUG - 2016-05-21 12:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:21:58 --> Input Class Initialized
INFO - 2016-05-21 12:21:58 --> Language Class Initialized
INFO - 2016-05-21 12:21:58 --> Loader Class Initialized
INFO - 2016-05-21 12:21:58 --> Helper loaded: url_helper
INFO - 2016-05-21 12:21:58 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:21:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:21:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:21:58 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:21:58 --> Helper loaded: form_helper
INFO - 2016-05-21 12:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:21:58 --> Form Validation Class Initialized
INFO - 2016-05-21 12:21:58 --> Controller Class Initialized
INFO - 2016-05-21 12:21:58 --> Model Class Initialized
INFO - 2016-05-21 12:21:58 --> Database Driver Class Initialized
INFO - 2016-05-21 12:21:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:21:58 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:21:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:21:58 --> Final output sent to browser
DEBUG - 2016-05-21 12:21:58 --> Total execution time: 0.1043
INFO - 2016-05-21 12:22:03 --> Config Class Initialized
INFO - 2016-05-21 12:22:03 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:22:03 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:22:03 --> Utf8 Class Initialized
INFO - 2016-05-21 12:22:03 --> URI Class Initialized
INFO - 2016-05-21 12:22:03 --> Router Class Initialized
INFO - 2016-05-21 12:22:03 --> Output Class Initialized
INFO - 2016-05-21 12:22:03 --> Security Class Initialized
DEBUG - 2016-05-21 12:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:22:03 --> Input Class Initialized
INFO - 2016-05-21 12:22:03 --> Language Class Initialized
INFO - 2016-05-21 12:22:03 --> Loader Class Initialized
INFO - 2016-05-21 12:22:03 --> Helper loaded: url_helper
INFO - 2016-05-21 12:22:03 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:22:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:22:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:22:03 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:22:03 --> Helper loaded: form_helper
INFO - 2016-05-21 12:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:22:03 --> Form Validation Class Initialized
INFO - 2016-05-21 12:22:03 --> Controller Class Initialized
INFO - 2016-05-21 12:22:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-21 12:22:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:22:03 --> Final output sent to browser
DEBUG - 2016-05-21 12:22:03 --> Total execution time: 0.0586
INFO - 2016-05-21 12:22:04 --> Config Class Initialized
INFO - 2016-05-21 12:22:04 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:22:04 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:22:04 --> Utf8 Class Initialized
INFO - 2016-05-21 12:22:04 --> URI Class Initialized
INFO - 2016-05-21 12:22:04 --> Router Class Initialized
INFO - 2016-05-21 12:22:04 --> Output Class Initialized
INFO - 2016-05-21 12:22:04 --> Security Class Initialized
DEBUG - 2016-05-21 12:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:22:04 --> Input Class Initialized
INFO - 2016-05-21 12:22:04 --> Language Class Initialized
INFO - 2016-05-21 12:22:04 --> Loader Class Initialized
INFO - 2016-05-21 12:22:04 --> Helper loaded: url_helper
INFO - 2016-05-21 12:22:04 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:22:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:22:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:22:04 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:22:04 --> Helper loaded: form_helper
INFO - 2016-05-21 12:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:22:04 --> Form Validation Class Initialized
INFO - 2016-05-21 12:22:04 --> Controller Class Initialized
INFO - 2016-05-21 12:22:04 --> Model Class Initialized
INFO - 2016-05-21 12:22:04 --> Database Driver Class Initialized
INFO - 2016-05-21 12:22:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:22:04 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:22:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:22:04 --> Final output sent to browser
DEBUG - 2016-05-21 12:22:04 --> Total execution time: 0.1029
INFO - 2016-05-21 12:22:10 --> Config Class Initialized
INFO - 2016-05-21 12:22:10 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:22:10 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:22:10 --> Utf8 Class Initialized
INFO - 2016-05-21 12:22:10 --> URI Class Initialized
INFO - 2016-05-21 12:22:10 --> Router Class Initialized
INFO - 2016-05-21 12:22:10 --> Output Class Initialized
INFO - 2016-05-21 12:22:10 --> Security Class Initialized
DEBUG - 2016-05-21 12:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:22:10 --> Input Class Initialized
INFO - 2016-05-21 12:22:10 --> Language Class Initialized
INFO - 2016-05-21 12:22:10 --> Loader Class Initialized
INFO - 2016-05-21 12:22:10 --> Helper loaded: url_helper
INFO - 2016-05-21 12:22:10 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:22:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:22:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:22:10 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:22:10 --> Helper loaded: form_helper
INFO - 2016-05-21 12:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:22:10 --> Form Validation Class Initialized
INFO - 2016-05-21 12:22:10 --> Controller Class Initialized
INFO - 2016-05-21 12:22:10 --> Model Class Initialized
INFO - 2016-05-21 12:22:10 --> Database Driver Class Initialized
INFO - 2016-05-21 12:22:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:22:10 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:22:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:22:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:22:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:22:10 --> Final output sent to browser
DEBUG - 2016-05-21 12:22:10 --> Total execution time: 0.1130
INFO - 2016-05-21 12:22:11 --> Config Class Initialized
INFO - 2016-05-21 12:22:11 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:22:11 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:22:11 --> Utf8 Class Initialized
INFO - 2016-05-21 12:22:11 --> URI Class Initialized
INFO - 2016-05-21 12:22:11 --> Router Class Initialized
INFO - 2016-05-21 12:22:11 --> Output Class Initialized
INFO - 2016-05-21 12:22:11 --> Security Class Initialized
DEBUG - 2016-05-21 12:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:22:11 --> Input Class Initialized
INFO - 2016-05-21 12:22:11 --> Language Class Initialized
INFO - 2016-05-21 12:22:11 --> Loader Class Initialized
INFO - 2016-05-21 12:22:11 --> Helper loaded: url_helper
INFO - 2016-05-21 12:22:11 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:22:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:22:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:22:11 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:22:11 --> Helper loaded: form_helper
INFO - 2016-05-21 12:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:22:11 --> Form Validation Class Initialized
INFO - 2016-05-21 12:22:11 --> Controller Class Initialized
INFO - 2016-05-21 12:22:11 --> Model Class Initialized
INFO - 2016-05-21 12:22:11 --> Database Driver Class Initialized
INFO - 2016-05-21 12:22:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:22:11 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:22:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:22:11 --> Final output sent to browser
DEBUG - 2016-05-21 12:22:11 --> Total execution time: 0.0912
INFO - 2016-05-21 12:22:59 --> Config Class Initialized
INFO - 2016-05-21 12:22:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:22:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:22:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:22:59 --> URI Class Initialized
INFO - 2016-05-21 12:22:59 --> Router Class Initialized
INFO - 2016-05-21 12:22:59 --> Output Class Initialized
INFO - 2016-05-21 12:22:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:22:59 --> Input Class Initialized
INFO - 2016-05-21 12:22:59 --> Language Class Initialized
INFO - 2016-05-21 12:22:59 --> Loader Class Initialized
INFO - 2016-05-21 12:22:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:22:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:22:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:22:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:22:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:22:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:22:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:22:59 --> Controller Class Initialized
INFO - 2016-05-21 12:22:59 --> Model Class Initialized
INFO - 2016-05-21 12:22:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:22:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:22:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:22:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:22:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:22:59 --> Total execution time: 0.0754
INFO - 2016-05-21 12:23:11 --> Config Class Initialized
INFO - 2016-05-21 12:23:11 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:23:11 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:23:11 --> Utf8 Class Initialized
INFO - 2016-05-21 12:23:11 --> URI Class Initialized
INFO - 2016-05-21 12:23:11 --> Router Class Initialized
INFO - 2016-05-21 12:23:11 --> Output Class Initialized
INFO - 2016-05-21 12:23:11 --> Security Class Initialized
DEBUG - 2016-05-21 12:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:23:11 --> Input Class Initialized
INFO - 2016-05-21 12:23:11 --> Language Class Initialized
INFO - 2016-05-21 12:23:11 --> Loader Class Initialized
INFO - 2016-05-21 12:23:11 --> Helper loaded: url_helper
INFO - 2016-05-21 12:23:11 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:23:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:23:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:23:11 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:23:11 --> Helper loaded: form_helper
INFO - 2016-05-21 12:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:23:11 --> Form Validation Class Initialized
INFO - 2016-05-21 12:23:11 --> Controller Class Initialized
INFO - 2016-05-21 12:23:11 --> Model Class Initialized
INFO - 2016-05-21 12:23:11 --> Database Driver Class Initialized
INFO - 2016-05-21 12:23:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:23:11 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:23:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:23:11 --> Final output sent to browser
DEBUG - 2016-05-21 12:23:11 --> Total execution time: 0.0751
INFO - 2016-05-21 12:23:18 --> Config Class Initialized
INFO - 2016-05-21 12:23:18 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:23:18 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:23:18 --> Utf8 Class Initialized
INFO - 2016-05-21 12:23:18 --> URI Class Initialized
INFO - 2016-05-21 12:23:18 --> Router Class Initialized
INFO - 2016-05-21 12:23:18 --> Output Class Initialized
INFO - 2016-05-21 12:23:18 --> Security Class Initialized
DEBUG - 2016-05-21 12:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:23:18 --> Input Class Initialized
INFO - 2016-05-21 12:23:18 --> Language Class Initialized
INFO - 2016-05-21 12:23:18 --> Loader Class Initialized
INFO - 2016-05-21 12:23:18 --> Helper loaded: url_helper
INFO - 2016-05-21 12:23:18 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:23:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:23:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:23:18 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:23:18 --> Helper loaded: form_helper
INFO - 2016-05-21 12:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:23:18 --> Form Validation Class Initialized
INFO - 2016-05-21 12:23:18 --> Controller Class Initialized
INFO - 2016-05-21 12:23:18 --> Model Class Initialized
INFO - 2016-05-21 12:23:18 --> Database Driver Class Initialized
INFO - 2016-05-21 12:23:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:23:18 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:23:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:23:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:23:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:23:18 --> Final output sent to browser
DEBUG - 2016-05-21 12:23:18 --> Total execution time: 0.0830
INFO - 2016-05-21 12:23:18 --> Config Class Initialized
INFO - 2016-05-21 12:23:18 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:23:18 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:23:18 --> Utf8 Class Initialized
INFO - 2016-05-21 12:23:18 --> URI Class Initialized
INFO - 2016-05-21 12:23:18 --> Router Class Initialized
INFO - 2016-05-21 12:23:18 --> Output Class Initialized
INFO - 2016-05-21 12:23:18 --> Security Class Initialized
DEBUG - 2016-05-21 12:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:23:18 --> Input Class Initialized
INFO - 2016-05-21 12:23:18 --> Language Class Initialized
INFO - 2016-05-21 12:23:18 --> Loader Class Initialized
INFO - 2016-05-21 12:23:18 --> Helper loaded: url_helper
INFO - 2016-05-21 12:23:18 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:23:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:23:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:23:18 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:23:18 --> Helper loaded: form_helper
INFO - 2016-05-21 12:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:23:18 --> Form Validation Class Initialized
INFO - 2016-05-21 12:23:18 --> Controller Class Initialized
INFO - 2016-05-21 12:23:18 --> Model Class Initialized
INFO - 2016-05-21 12:23:18 --> Database Driver Class Initialized
INFO - 2016-05-21 12:23:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:23:18 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:23:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:23:18 --> Final output sent to browser
DEBUG - 2016-05-21 12:23:18 --> Total execution time: 0.0894
INFO - 2016-05-21 12:23:23 --> Config Class Initialized
INFO - 2016-05-21 12:23:23 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:23:23 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:23:23 --> Utf8 Class Initialized
INFO - 2016-05-21 12:23:23 --> URI Class Initialized
INFO - 2016-05-21 12:23:23 --> Router Class Initialized
INFO - 2016-05-21 12:23:23 --> Output Class Initialized
INFO - 2016-05-21 12:23:23 --> Security Class Initialized
DEBUG - 2016-05-21 12:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:23:23 --> Input Class Initialized
INFO - 2016-05-21 12:23:23 --> Language Class Initialized
INFO - 2016-05-21 12:23:23 --> Loader Class Initialized
INFO - 2016-05-21 12:23:23 --> Helper loaded: url_helper
INFO - 2016-05-21 12:23:23 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:23:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:23:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:23:23 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:23:23 --> Helper loaded: form_helper
INFO - 2016-05-21 12:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:23:23 --> Form Validation Class Initialized
INFO - 2016-05-21 12:23:23 --> Controller Class Initialized
INFO - 2016-05-21 12:23:23 --> Model Class Initialized
INFO - 2016-05-21 12:23:23 --> Database Driver Class Initialized
INFO - 2016-05-21 12:23:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:23:23 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:23:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:23:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:23:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:23:23 --> Final output sent to browser
DEBUG - 2016-05-21 12:23:23 --> Total execution time: 0.0800
INFO - 2016-05-21 12:23:23 --> Config Class Initialized
INFO - 2016-05-21 12:23:23 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:23:23 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:23:23 --> Utf8 Class Initialized
INFO - 2016-05-21 12:23:23 --> URI Class Initialized
INFO - 2016-05-21 12:23:24 --> Router Class Initialized
INFO - 2016-05-21 12:23:24 --> Output Class Initialized
INFO - 2016-05-21 12:23:24 --> Security Class Initialized
DEBUG - 2016-05-21 12:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:23:24 --> Input Class Initialized
INFO - 2016-05-21 12:23:24 --> Language Class Initialized
INFO - 2016-05-21 12:23:24 --> Loader Class Initialized
INFO - 2016-05-21 12:23:24 --> Helper loaded: url_helper
INFO - 2016-05-21 12:23:24 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:23:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:23:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:23:24 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:23:24 --> Helper loaded: form_helper
INFO - 2016-05-21 12:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:23:24 --> Form Validation Class Initialized
INFO - 2016-05-21 12:23:24 --> Controller Class Initialized
INFO - 2016-05-21 12:23:24 --> Model Class Initialized
INFO - 2016-05-21 12:23:24 --> Database Driver Class Initialized
INFO - 2016-05-21 12:23:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:23:24 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:23:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:23:24 --> Final output sent to browser
DEBUG - 2016-05-21 12:23:24 --> Total execution time: 0.1042
INFO - 2016-05-21 12:23:56 --> Config Class Initialized
INFO - 2016-05-21 12:23:56 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:23:56 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:23:56 --> Utf8 Class Initialized
INFO - 2016-05-21 12:23:56 --> URI Class Initialized
INFO - 2016-05-21 12:23:56 --> Router Class Initialized
INFO - 2016-05-21 12:23:56 --> Output Class Initialized
INFO - 2016-05-21 12:23:56 --> Security Class Initialized
DEBUG - 2016-05-21 12:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:23:56 --> Input Class Initialized
INFO - 2016-05-21 12:23:56 --> Language Class Initialized
INFO - 2016-05-21 12:23:56 --> Loader Class Initialized
INFO - 2016-05-21 12:23:56 --> Helper loaded: url_helper
INFO - 2016-05-21 12:23:56 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:23:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:23:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:23:56 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:23:56 --> Helper loaded: form_helper
INFO - 2016-05-21 12:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:23:56 --> Form Validation Class Initialized
INFO - 2016-05-21 12:23:56 --> Controller Class Initialized
INFO - 2016-05-21 12:23:56 --> Model Class Initialized
INFO - 2016-05-21 12:23:56 --> Database Driver Class Initialized
INFO - 2016-05-21 12:23:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:23:56 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:23:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:23:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:23:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:23:56 --> Final output sent to browser
DEBUG - 2016-05-21 12:23:56 --> Total execution time: 0.0805
INFO - 2016-05-21 12:23:56 --> Config Class Initialized
INFO - 2016-05-21 12:23:56 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:23:56 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:23:56 --> Utf8 Class Initialized
INFO - 2016-05-21 12:23:56 --> URI Class Initialized
INFO - 2016-05-21 12:23:56 --> Router Class Initialized
INFO - 2016-05-21 12:23:56 --> Output Class Initialized
INFO - 2016-05-21 12:23:56 --> Security Class Initialized
DEBUG - 2016-05-21 12:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:23:56 --> Input Class Initialized
INFO - 2016-05-21 12:23:56 --> Language Class Initialized
INFO - 2016-05-21 12:23:56 --> Loader Class Initialized
INFO - 2016-05-21 12:23:56 --> Helper loaded: url_helper
INFO - 2016-05-21 12:23:56 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:23:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:23:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:23:56 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:23:56 --> Helper loaded: form_helper
INFO - 2016-05-21 12:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:23:56 --> Form Validation Class Initialized
INFO - 2016-05-21 12:23:56 --> Controller Class Initialized
INFO - 2016-05-21 12:23:56 --> Model Class Initialized
INFO - 2016-05-21 12:23:56 --> Database Driver Class Initialized
INFO - 2016-05-21 12:23:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:23:56 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:23:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:23:56 --> Final output sent to browser
DEBUG - 2016-05-21 12:23:56 --> Total execution time: 0.0891
INFO - 2016-05-21 12:23:59 --> Config Class Initialized
INFO - 2016-05-21 12:23:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:23:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:23:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:23:59 --> URI Class Initialized
INFO - 2016-05-21 12:23:59 --> Router Class Initialized
INFO - 2016-05-21 12:23:59 --> Output Class Initialized
INFO - 2016-05-21 12:23:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:23:59 --> Input Class Initialized
INFO - 2016-05-21 12:23:59 --> Language Class Initialized
INFO - 2016-05-21 12:23:59 --> Loader Class Initialized
INFO - 2016-05-21 12:23:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:23:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:23:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:23:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:23:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:23:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:23:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:23:59 --> Controller Class Initialized
INFO - 2016-05-21 12:23:59 --> Model Class Initialized
INFO - 2016-05-21 12:23:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:23:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:23:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:23:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:23:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:23:59 --> Total execution time: 0.0862
INFO - 2016-05-21 12:24:27 --> Config Class Initialized
INFO - 2016-05-21 12:24:27 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:24:27 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:24:27 --> Utf8 Class Initialized
INFO - 2016-05-21 12:24:27 --> URI Class Initialized
INFO - 2016-05-21 12:24:27 --> Router Class Initialized
INFO - 2016-05-21 12:24:27 --> Output Class Initialized
INFO - 2016-05-21 12:24:27 --> Security Class Initialized
DEBUG - 2016-05-21 12:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:24:27 --> Input Class Initialized
INFO - 2016-05-21 12:24:27 --> Language Class Initialized
INFO - 2016-05-21 12:24:27 --> Loader Class Initialized
INFO - 2016-05-21 12:24:27 --> Helper loaded: url_helper
INFO - 2016-05-21 12:24:27 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:24:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:24:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:24:27 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:24:27 --> Helper loaded: form_helper
INFO - 2016-05-21 12:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:24:27 --> Form Validation Class Initialized
INFO - 2016-05-21 12:24:27 --> Controller Class Initialized
INFO - 2016-05-21 12:24:27 --> Model Class Initialized
INFO - 2016-05-21 12:24:27 --> Database Driver Class Initialized
INFO - 2016-05-21 12:24:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:24:27 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:24:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:24:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:24:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:24:27 --> Final output sent to browser
DEBUG - 2016-05-21 12:24:27 --> Total execution time: 0.0824
INFO - 2016-05-21 12:24:28 --> Config Class Initialized
INFO - 2016-05-21 12:24:28 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:24:28 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:24:28 --> Utf8 Class Initialized
INFO - 2016-05-21 12:24:28 --> URI Class Initialized
INFO - 2016-05-21 12:24:28 --> Router Class Initialized
INFO - 2016-05-21 12:24:28 --> Output Class Initialized
INFO - 2016-05-21 12:24:28 --> Security Class Initialized
DEBUG - 2016-05-21 12:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:24:28 --> Input Class Initialized
INFO - 2016-05-21 12:24:28 --> Language Class Initialized
INFO - 2016-05-21 12:24:28 --> Loader Class Initialized
INFO - 2016-05-21 12:24:28 --> Helper loaded: url_helper
INFO - 2016-05-21 12:24:28 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:24:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:24:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:24:28 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:24:28 --> Helper loaded: form_helper
INFO - 2016-05-21 12:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:24:28 --> Form Validation Class Initialized
INFO - 2016-05-21 12:24:28 --> Controller Class Initialized
INFO - 2016-05-21 12:24:28 --> Model Class Initialized
INFO - 2016-05-21 12:24:28 --> Database Driver Class Initialized
INFO - 2016-05-21 12:24:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:24:28 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:24:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:24:28 --> Final output sent to browser
DEBUG - 2016-05-21 12:24:28 --> Total execution time: 0.0850
INFO - 2016-05-21 12:24:59 --> Config Class Initialized
INFO - 2016-05-21 12:24:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:24:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:24:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:24:59 --> URI Class Initialized
INFO - 2016-05-21 12:24:59 --> Router Class Initialized
INFO - 2016-05-21 12:24:59 --> Output Class Initialized
INFO - 2016-05-21 12:24:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:24:59 --> Input Class Initialized
INFO - 2016-05-21 12:24:59 --> Language Class Initialized
INFO - 2016-05-21 12:24:59 --> Loader Class Initialized
INFO - 2016-05-21 12:24:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:24:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:24:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:24:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:24:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:24:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:24:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:24:59 --> Controller Class Initialized
INFO - 2016-05-21 12:24:59 --> Model Class Initialized
INFO - 2016-05-21 12:24:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:24:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:24:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:24:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:24:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:24:59 --> Total execution time: 0.0753
INFO - 2016-05-21 12:25:29 --> Config Class Initialized
INFO - 2016-05-21 12:25:29 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:25:29 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:25:29 --> Utf8 Class Initialized
INFO - 2016-05-21 12:25:29 --> URI Class Initialized
INFO - 2016-05-21 12:25:29 --> Router Class Initialized
INFO - 2016-05-21 12:25:29 --> Output Class Initialized
INFO - 2016-05-21 12:25:29 --> Security Class Initialized
DEBUG - 2016-05-21 12:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:25:29 --> Input Class Initialized
INFO - 2016-05-21 12:25:29 --> Language Class Initialized
INFO - 2016-05-21 12:25:29 --> Loader Class Initialized
INFO - 2016-05-21 12:25:29 --> Helper loaded: url_helper
INFO - 2016-05-21 12:25:29 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:25:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:25:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:25:29 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:25:29 --> Helper loaded: form_helper
INFO - 2016-05-21 12:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:25:29 --> Form Validation Class Initialized
INFO - 2016-05-21 12:25:29 --> Controller Class Initialized
INFO - 2016-05-21 12:25:29 --> Model Class Initialized
INFO - 2016-05-21 12:25:29 --> Database Driver Class Initialized
INFO - 2016-05-21 12:25:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:25:29 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:25:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:25:29 --> Final output sent to browser
DEBUG - 2016-05-21 12:25:29 --> Total execution time: 0.0716
INFO - 2016-05-21 12:25:59 --> Config Class Initialized
INFO - 2016-05-21 12:25:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:25:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:25:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:25:59 --> URI Class Initialized
INFO - 2016-05-21 12:25:59 --> Router Class Initialized
INFO - 2016-05-21 12:25:59 --> Output Class Initialized
INFO - 2016-05-21 12:25:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:25:59 --> Input Class Initialized
INFO - 2016-05-21 12:25:59 --> Language Class Initialized
INFO - 2016-05-21 12:25:59 --> Loader Class Initialized
INFO - 2016-05-21 12:25:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:25:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:25:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:25:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:25:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:25:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:25:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:25:59 --> Controller Class Initialized
INFO - 2016-05-21 12:25:59 --> Model Class Initialized
INFO - 2016-05-21 12:25:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:25:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:25:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:25:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:25:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:25:59 --> Total execution time: 0.0731
INFO - 2016-05-21 12:26:29 --> Config Class Initialized
INFO - 2016-05-21 12:26:29 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:26:29 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:26:29 --> Utf8 Class Initialized
INFO - 2016-05-21 12:26:29 --> URI Class Initialized
INFO - 2016-05-21 12:26:29 --> Router Class Initialized
INFO - 2016-05-21 12:26:29 --> Output Class Initialized
INFO - 2016-05-21 12:26:29 --> Security Class Initialized
DEBUG - 2016-05-21 12:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:26:29 --> Input Class Initialized
INFO - 2016-05-21 12:26:29 --> Language Class Initialized
INFO - 2016-05-21 12:26:29 --> Loader Class Initialized
INFO - 2016-05-21 12:26:29 --> Helper loaded: url_helper
INFO - 2016-05-21 12:26:29 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:26:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:26:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:26:29 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:26:29 --> Helper loaded: form_helper
INFO - 2016-05-21 12:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:26:29 --> Form Validation Class Initialized
INFO - 2016-05-21 12:26:29 --> Controller Class Initialized
INFO - 2016-05-21 12:26:29 --> Model Class Initialized
INFO - 2016-05-21 12:26:29 --> Database Driver Class Initialized
INFO - 2016-05-21 12:26:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:26:29 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:26:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:26:29 --> Final output sent to browser
DEBUG - 2016-05-21 12:26:29 --> Total execution time: 0.1181
INFO - 2016-05-21 12:26:59 --> Config Class Initialized
INFO - 2016-05-21 12:26:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:26:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:26:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:26:59 --> URI Class Initialized
INFO - 2016-05-21 12:26:59 --> Router Class Initialized
INFO - 2016-05-21 12:26:59 --> Output Class Initialized
INFO - 2016-05-21 12:26:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:26:59 --> Input Class Initialized
INFO - 2016-05-21 12:26:59 --> Language Class Initialized
INFO - 2016-05-21 12:26:59 --> Loader Class Initialized
INFO - 2016-05-21 12:26:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:26:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:26:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:26:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:26:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:26:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:26:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:26:59 --> Controller Class Initialized
INFO - 2016-05-21 12:26:59 --> Model Class Initialized
INFO - 2016-05-21 12:26:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:26:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:26:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:26:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:26:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:26:59 --> Total execution time: 0.0703
INFO - 2016-05-21 12:27:29 --> Config Class Initialized
INFO - 2016-05-21 12:27:29 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:27:29 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:27:29 --> Utf8 Class Initialized
INFO - 2016-05-21 12:27:29 --> URI Class Initialized
INFO - 2016-05-21 12:27:29 --> Router Class Initialized
INFO - 2016-05-21 12:27:29 --> Output Class Initialized
INFO - 2016-05-21 12:27:29 --> Security Class Initialized
DEBUG - 2016-05-21 12:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:27:29 --> Input Class Initialized
INFO - 2016-05-21 12:27:29 --> Language Class Initialized
INFO - 2016-05-21 12:27:29 --> Loader Class Initialized
INFO - 2016-05-21 12:27:29 --> Helper loaded: url_helper
INFO - 2016-05-21 12:27:29 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:27:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:27:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:27:29 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:27:29 --> Helper loaded: form_helper
INFO - 2016-05-21 12:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:27:29 --> Form Validation Class Initialized
INFO - 2016-05-21 12:27:29 --> Controller Class Initialized
INFO - 2016-05-21 12:27:29 --> Model Class Initialized
INFO - 2016-05-21 12:27:29 --> Database Driver Class Initialized
INFO - 2016-05-21 12:27:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:27:29 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:27:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:27:29 --> Final output sent to browser
DEBUG - 2016-05-21 12:27:29 --> Total execution time: 0.0704
INFO - 2016-05-21 12:27:40 --> Config Class Initialized
INFO - 2016-05-21 12:27:40 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:27:40 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:27:40 --> Utf8 Class Initialized
INFO - 2016-05-21 12:27:40 --> URI Class Initialized
INFO - 2016-05-21 12:27:40 --> Router Class Initialized
INFO - 2016-05-21 12:27:40 --> Output Class Initialized
INFO - 2016-05-21 12:27:40 --> Security Class Initialized
DEBUG - 2016-05-21 12:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:27:40 --> Input Class Initialized
INFO - 2016-05-21 12:27:40 --> Language Class Initialized
INFO - 2016-05-21 12:27:40 --> Loader Class Initialized
INFO - 2016-05-21 12:27:40 --> Helper loaded: url_helper
INFO - 2016-05-21 12:27:40 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:27:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:27:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:27:40 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:27:40 --> Helper loaded: form_helper
INFO - 2016-05-21 12:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:27:40 --> Form Validation Class Initialized
INFO - 2016-05-21 12:27:40 --> Controller Class Initialized
INFO - 2016-05-21 12:27:40 --> Model Class Initialized
INFO - 2016-05-21 12:27:40 --> Database Driver Class Initialized
INFO - 2016-05-21 12:27:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:27:40 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:27:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:27:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:27:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:27:40 --> Final output sent to browser
DEBUG - 2016-05-21 12:27:40 --> Total execution time: 0.0835
INFO - 2016-05-21 12:27:41 --> Config Class Initialized
INFO - 2016-05-21 12:27:41 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:27:41 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:27:41 --> Utf8 Class Initialized
INFO - 2016-05-21 12:27:41 --> URI Class Initialized
INFO - 2016-05-21 12:27:41 --> Router Class Initialized
INFO - 2016-05-21 12:27:41 --> Output Class Initialized
INFO - 2016-05-21 12:27:41 --> Security Class Initialized
DEBUG - 2016-05-21 12:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:27:41 --> Input Class Initialized
INFO - 2016-05-21 12:27:41 --> Language Class Initialized
INFO - 2016-05-21 12:27:41 --> Loader Class Initialized
INFO - 2016-05-21 12:27:41 --> Helper loaded: url_helper
INFO - 2016-05-21 12:27:41 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:27:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:27:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:27:41 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:27:41 --> Helper loaded: form_helper
INFO - 2016-05-21 12:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:27:41 --> Form Validation Class Initialized
INFO - 2016-05-21 12:27:41 --> Controller Class Initialized
INFO - 2016-05-21 12:27:41 --> Model Class Initialized
INFO - 2016-05-21 12:27:41 --> Database Driver Class Initialized
INFO - 2016-05-21 12:27:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:27:41 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:27:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:27:41 --> Final output sent to browser
DEBUG - 2016-05-21 12:27:41 --> Total execution time: 0.0894
INFO - 2016-05-21 12:27:59 --> Config Class Initialized
INFO - 2016-05-21 12:27:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:27:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:27:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:27:59 --> URI Class Initialized
INFO - 2016-05-21 12:27:59 --> Router Class Initialized
INFO - 2016-05-21 12:27:59 --> Output Class Initialized
INFO - 2016-05-21 12:27:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:27:59 --> Input Class Initialized
INFO - 2016-05-21 12:27:59 --> Language Class Initialized
INFO - 2016-05-21 12:27:59 --> Loader Class Initialized
INFO - 2016-05-21 12:27:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:27:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:27:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:27:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:27:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:27:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:27:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:27:59 --> Controller Class Initialized
INFO - 2016-05-21 12:27:59 --> Model Class Initialized
INFO - 2016-05-21 12:27:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:27:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:27:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:27:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:27:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:27:59 --> Total execution time: 0.0736
INFO - 2016-05-21 12:28:03 --> Config Class Initialized
INFO - 2016-05-21 12:28:03 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:28:03 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:28:03 --> Utf8 Class Initialized
INFO - 2016-05-21 12:28:03 --> URI Class Initialized
INFO - 2016-05-21 12:28:03 --> Router Class Initialized
INFO - 2016-05-21 12:28:03 --> Output Class Initialized
INFO - 2016-05-21 12:28:03 --> Security Class Initialized
DEBUG - 2016-05-21 12:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:28:03 --> Input Class Initialized
INFO - 2016-05-21 12:28:03 --> Language Class Initialized
INFO - 2016-05-21 12:28:03 --> Loader Class Initialized
INFO - 2016-05-21 12:28:03 --> Helper loaded: url_helper
INFO - 2016-05-21 12:28:03 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:28:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:28:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:28:03 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:28:03 --> Helper loaded: form_helper
INFO - 2016-05-21 12:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:28:03 --> Form Validation Class Initialized
INFO - 2016-05-21 12:28:03 --> Controller Class Initialized
INFO - 2016-05-21 12:28:03 --> Model Class Initialized
INFO - 2016-05-21 12:28:03 --> Database Driver Class Initialized
INFO - 2016-05-21 12:28:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:28:03 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:28:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:28:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:28:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:28:03 --> Final output sent to browser
DEBUG - 2016-05-21 12:28:03 --> Total execution time: 0.0799
INFO - 2016-05-21 12:28:03 --> Config Class Initialized
INFO - 2016-05-21 12:28:03 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:28:03 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:28:03 --> Utf8 Class Initialized
INFO - 2016-05-21 12:28:03 --> URI Class Initialized
INFO - 2016-05-21 12:28:03 --> Router Class Initialized
INFO - 2016-05-21 12:28:03 --> Output Class Initialized
INFO - 2016-05-21 12:28:03 --> Security Class Initialized
DEBUG - 2016-05-21 12:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:28:03 --> Input Class Initialized
INFO - 2016-05-21 12:28:03 --> Language Class Initialized
INFO - 2016-05-21 12:28:03 --> Loader Class Initialized
INFO - 2016-05-21 12:28:03 --> Helper loaded: url_helper
INFO - 2016-05-21 12:28:03 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:28:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:28:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:28:03 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:28:03 --> Helper loaded: form_helper
INFO - 2016-05-21 12:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:28:03 --> Form Validation Class Initialized
INFO - 2016-05-21 12:28:03 --> Controller Class Initialized
INFO - 2016-05-21 12:28:03 --> Model Class Initialized
INFO - 2016-05-21 12:28:03 --> Database Driver Class Initialized
INFO - 2016-05-21 12:28:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:28:03 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:28:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:28:03 --> Final output sent to browser
DEBUG - 2016-05-21 12:28:03 --> Total execution time: 0.0971
INFO - 2016-05-21 12:28:59 --> Config Class Initialized
INFO - 2016-05-21 12:28:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:28:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:28:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:28:59 --> URI Class Initialized
INFO - 2016-05-21 12:28:59 --> Router Class Initialized
INFO - 2016-05-21 12:28:59 --> Output Class Initialized
INFO - 2016-05-21 12:28:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:28:59 --> Input Class Initialized
INFO - 2016-05-21 12:28:59 --> Language Class Initialized
INFO - 2016-05-21 12:28:59 --> Loader Class Initialized
INFO - 2016-05-21 12:28:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:28:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:28:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:28:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:28:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:28:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:28:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:28:59 --> Controller Class Initialized
INFO - 2016-05-21 12:28:59 --> Model Class Initialized
INFO - 2016-05-21 12:28:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:28:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:28:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:28:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:28:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:28:59 --> Total execution time: 0.0704
INFO - 2016-05-21 12:29:04 --> Config Class Initialized
INFO - 2016-05-21 12:29:04 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:29:04 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:29:04 --> Utf8 Class Initialized
INFO - 2016-05-21 12:29:04 --> URI Class Initialized
INFO - 2016-05-21 12:29:04 --> Router Class Initialized
INFO - 2016-05-21 12:29:04 --> Output Class Initialized
INFO - 2016-05-21 12:29:04 --> Security Class Initialized
DEBUG - 2016-05-21 12:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:29:04 --> Input Class Initialized
INFO - 2016-05-21 12:29:04 --> Language Class Initialized
INFO - 2016-05-21 12:29:04 --> Loader Class Initialized
INFO - 2016-05-21 12:29:04 --> Helper loaded: url_helper
INFO - 2016-05-21 12:29:04 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:29:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:29:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:29:04 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:29:04 --> Helper loaded: form_helper
INFO - 2016-05-21 12:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:29:04 --> Form Validation Class Initialized
INFO - 2016-05-21 12:29:04 --> Controller Class Initialized
INFO - 2016-05-21 12:29:04 --> Model Class Initialized
INFO - 2016-05-21 12:29:04 --> Database Driver Class Initialized
INFO - 2016-05-21 12:29:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:29:04 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:29:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:29:04 --> Final output sent to browser
DEBUG - 2016-05-21 12:29:04 --> Total execution time: 0.0676
INFO - 2016-05-21 12:29:59 --> Config Class Initialized
INFO - 2016-05-21 12:29:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:29:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:29:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:29:59 --> URI Class Initialized
INFO - 2016-05-21 12:29:59 --> Router Class Initialized
INFO - 2016-05-21 12:29:59 --> Output Class Initialized
INFO - 2016-05-21 12:29:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:29:59 --> Input Class Initialized
INFO - 2016-05-21 12:29:59 --> Language Class Initialized
INFO - 2016-05-21 12:29:59 --> Loader Class Initialized
INFO - 2016-05-21 12:29:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:29:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:29:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:29:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:29:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:29:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:29:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:29:59 --> Controller Class Initialized
INFO - 2016-05-21 12:29:59 --> Model Class Initialized
INFO - 2016-05-21 12:29:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:29:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:29:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:29:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:29:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:29:59 --> Total execution time: 0.0970
INFO - 2016-05-21 12:30:03 --> Config Class Initialized
INFO - 2016-05-21 12:30:03 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:30:03 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:30:03 --> Utf8 Class Initialized
INFO - 2016-05-21 12:30:03 --> URI Class Initialized
INFO - 2016-05-21 12:30:03 --> Router Class Initialized
INFO - 2016-05-21 12:30:03 --> Output Class Initialized
INFO - 2016-05-21 12:30:03 --> Security Class Initialized
DEBUG - 2016-05-21 12:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:30:03 --> Input Class Initialized
INFO - 2016-05-21 12:30:03 --> Language Class Initialized
INFO - 2016-05-21 12:30:03 --> Loader Class Initialized
INFO - 2016-05-21 12:30:03 --> Helper loaded: url_helper
INFO - 2016-05-21 12:30:03 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:30:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:30:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:30:03 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:30:03 --> Helper loaded: form_helper
INFO - 2016-05-21 12:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:30:03 --> Form Validation Class Initialized
INFO - 2016-05-21 12:30:03 --> Controller Class Initialized
INFO - 2016-05-21 12:30:03 --> Model Class Initialized
INFO - 2016-05-21 12:30:03 --> Database Driver Class Initialized
INFO - 2016-05-21 12:30:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:30:03 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:30:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:30:03 --> Final output sent to browser
DEBUG - 2016-05-21 12:30:03 --> Total execution time: 0.0765
INFO - 2016-05-21 12:30:30 --> Config Class Initialized
INFO - 2016-05-21 12:30:30 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:30:30 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:30:30 --> Utf8 Class Initialized
INFO - 2016-05-21 12:30:30 --> URI Class Initialized
INFO - 2016-05-21 12:30:30 --> Router Class Initialized
INFO - 2016-05-21 12:30:30 --> Output Class Initialized
INFO - 2016-05-21 12:30:30 --> Security Class Initialized
DEBUG - 2016-05-21 12:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:30:30 --> Input Class Initialized
INFO - 2016-05-21 12:30:30 --> Language Class Initialized
INFO - 2016-05-21 12:30:30 --> Loader Class Initialized
INFO - 2016-05-21 12:30:30 --> Helper loaded: url_helper
INFO - 2016-05-21 12:30:30 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:30:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:30:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:30:30 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:30:30 --> Helper loaded: form_helper
INFO - 2016-05-21 12:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:30:30 --> Form Validation Class Initialized
INFO - 2016-05-21 12:30:30 --> Controller Class Initialized
INFO - 2016-05-21 12:30:30 --> Model Class Initialized
INFO - 2016-05-21 12:30:30 --> Database Driver Class Initialized
INFO - 2016-05-21 12:30:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:30:30 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:30:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:30:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:30:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:30:30 --> Final output sent to browser
DEBUG - 2016-05-21 12:30:30 --> Total execution time: 0.1234
INFO - 2016-05-21 12:30:30 --> Config Class Initialized
INFO - 2016-05-21 12:30:30 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:30:30 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:30:30 --> Utf8 Class Initialized
INFO - 2016-05-21 12:30:30 --> URI Class Initialized
INFO - 2016-05-21 12:30:30 --> Router Class Initialized
INFO - 2016-05-21 12:30:30 --> Output Class Initialized
INFO - 2016-05-21 12:30:30 --> Security Class Initialized
DEBUG - 2016-05-21 12:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:30:30 --> Input Class Initialized
INFO - 2016-05-21 12:30:30 --> Language Class Initialized
INFO - 2016-05-21 12:30:30 --> Loader Class Initialized
INFO - 2016-05-21 12:30:30 --> Helper loaded: url_helper
INFO - 2016-05-21 12:30:30 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:30:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:30:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:30:30 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:30:30 --> Helper loaded: form_helper
INFO - 2016-05-21 12:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:30:30 --> Form Validation Class Initialized
INFO - 2016-05-21 12:30:30 --> Controller Class Initialized
INFO - 2016-05-21 12:30:30 --> Model Class Initialized
INFO - 2016-05-21 12:30:30 --> Database Driver Class Initialized
INFO - 2016-05-21 12:30:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:30:30 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:30:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:30:30 --> Final output sent to browser
DEBUG - 2016-05-21 12:30:30 --> Total execution time: 0.0867
INFO - 2016-05-21 12:30:59 --> Config Class Initialized
INFO - 2016-05-21 12:30:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:30:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:30:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:30:59 --> URI Class Initialized
INFO - 2016-05-21 12:30:59 --> Router Class Initialized
INFO - 2016-05-21 12:30:59 --> Output Class Initialized
INFO - 2016-05-21 12:30:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:30:59 --> Input Class Initialized
INFO - 2016-05-21 12:30:59 --> Language Class Initialized
INFO - 2016-05-21 12:30:59 --> Loader Class Initialized
INFO - 2016-05-21 12:30:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:30:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:30:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:30:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:30:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:30:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:30:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:30:59 --> Controller Class Initialized
INFO - 2016-05-21 12:30:59 --> Model Class Initialized
INFO - 2016-05-21 12:30:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:30:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:30:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:30:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:30:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:30:59 --> Total execution time: 0.0705
INFO - 2016-05-21 12:31:16 --> Config Class Initialized
INFO - 2016-05-21 12:31:16 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:31:16 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:31:16 --> Utf8 Class Initialized
INFO - 2016-05-21 12:31:16 --> URI Class Initialized
INFO - 2016-05-21 12:31:16 --> Router Class Initialized
INFO - 2016-05-21 12:31:16 --> Output Class Initialized
INFO - 2016-05-21 12:31:16 --> Security Class Initialized
DEBUG - 2016-05-21 12:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:31:16 --> Input Class Initialized
INFO - 2016-05-21 12:31:16 --> Language Class Initialized
INFO - 2016-05-21 12:31:16 --> Loader Class Initialized
INFO - 2016-05-21 12:31:16 --> Helper loaded: url_helper
INFO - 2016-05-21 12:31:16 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:31:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:31:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:31:16 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:31:16 --> Helper loaded: form_helper
INFO - 2016-05-21 12:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:31:16 --> Form Validation Class Initialized
INFO - 2016-05-21 12:31:16 --> Controller Class Initialized
INFO - 2016-05-21 12:31:16 --> Model Class Initialized
INFO - 2016-05-21 12:31:16 --> Database Driver Class Initialized
INFO - 2016-05-21 12:31:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:31:16 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:31:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:31:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:31:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:31:16 --> Final output sent to browser
DEBUG - 2016-05-21 12:31:16 --> Total execution time: 0.1117
INFO - 2016-05-21 12:31:17 --> Config Class Initialized
INFO - 2016-05-21 12:31:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:31:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:31:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:31:17 --> URI Class Initialized
INFO - 2016-05-21 12:31:17 --> Router Class Initialized
INFO - 2016-05-21 12:31:17 --> Output Class Initialized
INFO - 2016-05-21 12:31:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:31:17 --> Input Class Initialized
INFO - 2016-05-21 12:31:17 --> Language Class Initialized
INFO - 2016-05-21 12:31:17 --> Loader Class Initialized
INFO - 2016-05-21 12:31:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:31:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:31:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:31:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:31:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:31:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:31:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:31:17 --> Controller Class Initialized
INFO - 2016-05-21 12:31:17 --> Model Class Initialized
INFO - 2016-05-21 12:31:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:31:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:31:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:31:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:31:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:31:17 --> Total execution time: 0.1050
INFO - 2016-05-21 12:31:24 --> Config Class Initialized
INFO - 2016-05-21 12:31:24 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:31:24 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:31:24 --> Utf8 Class Initialized
INFO - 2016-05-21 12:31:24 --> URI Class Initialized
INFO - 2016-05-21 12:31:24 --> Router Class Initialized
INFO - 2016-05-21 12:31:24 --> Output Class Initialized
INFO - 2016-05-21 12:31:24 --> Security Class Initialized
DEBUG - 2016-05-21 12:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:31:24 --> Input Class Initialized
INFO - 2016-05-21 12:31:24 --> Language Class Initialized
INFO - 2016-05-21 12:31:24 --> Loader Class Initialized
INFO - 2016-05-21 12:31:24 --> Helper loaded: url_helper
INFO - 2016-05-21 12:31:24 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:31:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:31:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:31:24 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:31:24 --> Helper loaded: form_helper
INFO - 2016-05-21 12:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:31:24 --> Form Validation Class Initialized
INFO - 2016-05-21 12:31:24 --> Controller Class Initialized
INFO - 2016-05-21 12:31:24 --> Model Class Initialized
INFO - 2016-05-21 12:31:24 --> Database Driver Class Initialized
INFO - 2016-05-21 12:31:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:31:24 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:31:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:31:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:31:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:31:24 --> Final output sent to browser
DEBUG - 2016-05-21 12:31:24 --> Total execution time: 0.1219
INFO - 2016-05-21 12:31:25 --> Config Class Initialized
INFO - 2016-05-21 12:31:25 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:31:25 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:31:25 --> Utf8 Class Initialized
INFO - 2016-05-21 12:31:25 --> URI Class Initialized
INFO - 2016-05-21 12:31:25 --> Router Class Initialized
INFO - 2016-05-21 12:31:25 --> Output Class Initialized
INFO - 2016-05-21 12:31:25 --> Security Class Initialized
DEBUG - 2016-05-21 12:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:31:25 --> Input Class Initialized
INFO - 2016-05-21 12:31:25 --> Language Class Initialized
INFO - 2016-05-21 12:31:25 --> Loader Class Initialized
INFO - 2016-05-21 12:31:25 --> Helper loaded: url_helper
INFO - 2016-05-21 12:31:25 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:31:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:31:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:31:25 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:31:25 --> Helper loaded: form_helper
INFO - 2016-05-21 12:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:31:25 --> Form Validation Class Initialized
INFO - 2016-05-21 12:31:25 --> Controller Class Initialized
INFO - 2016-05-21 12:31:25 --> Model Class Initialized
INFO - 2016-05-21 12:31:25 --> Database Driver Class Initialized
INFO - 2016-05-21 12:31:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:31:25 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:31:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:31:25 --> Final output sent to browser
DEBUG - 2016-05-21 12:31:25 --> Total execution time: 0.1122
INFO - 2016-05-21 12:31:27 --> Config Class Initialized
INFO - 2016-05-21 12:31:27 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:31:27 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:31:27 --> Utf8 Class Initialized
INFO - 2016-05-21 12:31:27 --> URI Class Initialized
INFO - 2016-05-21 12:31:27 --> Router Class Initialized
INFO - 2016-05-21 12:31:27 --> Output Class Initialized
INFO - 2016-05-21 12:31:27 --> Security Class Initialized
DEBUG - 2016-05-21 12:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:31:27 --> Input Class Initialized
INFO - 2016-05-21 12:31:27 --> Language Class Initialized
INFO - 2016-05-21 12:31:27 --> Loader Class Initialized
INFO - 2016-05-21 12:31:27 --> Helper loaded: url_helper
INFO - 2016-05-21 12:31:27 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:31:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:31:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:31:27 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:31:27 --> Helper loaded: form_helper
INFO - 2016-05-21 12:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:31:27 --> Form Validation Class Initialized
INFO - 2016-05-21 12:31:27 --> Controller Class Initialized
INFO - 2016-05-21 12:31:27 --> Model Class Initialized
INFO - 2016-05-21 12:31:27 --> Database Driver Class Initialized
INFO - 2016-05-21 12:31:28 --> Final output sent to browser
DEBUG - 2016-05-21 12:31:28 --> Total execution time: 1.4212
INFO - 2016-05-21 12:31:43 --> Config Class Initialized
INFO - 2016-05-21 12:31:43 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:31:43 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:31:43 --> Utf8 Class Initialized
INFO - 2016-05-21 12:31:43 --> URI Class Initialized
INFO - 2016-05-21 12:31:43 --> Router Class Initialized
INFO - 2016-05-21 12:31:43 --> Output Class Initialized
INFO - 2016-05-21 12:31:43 --> Security Class Initialized
DEBUG - 2016-05-21 12:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:31:43 --> Input Class Initialized
INFO - 2016-05-21 12:31:43 --> Language Class Initialized
INFO - 2016-05-21 12:31:43 --> Loader Class Initialized
INFO - 2016-05-21 12:31:43 --> Helper loaded: url_helper
INFO - 2016-05-21 12:31:43 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:31:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:31:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:31:43 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:31:43 --> Helper loaded: form_helper
INFO - 2016-05-21 12:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:31:43 --> Form Validation Class Initialized
INFO - 2016-05-21 12:31:43 --> Controller Class Initialized
INFO - 2016-05-21 12:31:43 --> Model Class Initialized
INFO - 2016-05-21 12:31:43 --> Database Driver Class Initialized
INFO - 2016-05-21 12:31:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:31:43 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:31:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:31:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:31:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:31:43 --> Final output sent to browser
DEBUG - 2016-05-21 12:31:43 --> Total execution time: 0.1016
INFO - 2016-05-21 12:31:43 --> Config Class Initialized
INFO - 2016-05-21 12:31:43 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:31:43 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:31:43 --> Utf8 Class Initialized
INFO - 2016-05-21 12:31:43 --> URI Class Initialized
INFO - 2016-05-21 12:31:43 --> Router Class Initialized
INFO - 2016-05-21 12:31:43 --> Output Class Initialized
INFO - 2016-05-21 12:31:43 --> Security Class Initialized
DEBUG - 2016-05-21 12:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:31:43 --> Input Class Initialized
INFO - 2016-05-21 12:31:43 --> Language Class Initialized
INFO - 2016-05-21 12:31:43 --> Loader Class Initialized
INFO - 2016-05-21 12:31:43 --> Helper loaded: url_helper
INFO - 2016-05-21 12:31:43 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:31:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:31:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:31:43 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:31:43 --> Helper loaded: form_helper
INFO - 2016-05-21 12:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:31:43 --> Form Validation Class Initialized
INFO - 2016-05-21 12:31:43 --> Controller Class Initialized
INFO - 2016-05-21 12:31:43 --> Model Class Initialized
INFO - 2016-05-21 12:31:43 --> Database Driver Class Initialized
INFO - 2016-05-21 12:31:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:31:43 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:31:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:31:43 --> Final output sent to browser
DEBUG - 2016-05-21 12:31:43 --> Total execution time: 0.0821
INFO - 2016-05-21 12:31:51 --> Config Class Initialized
INFO - 2016-05-21 12:31:51 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:31:51 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:31:51 --> Utf8 Class Initialized
INFO - 2016-05-21 12:31:51 --> URI Class Initialized
INFO - 2016-05-21 12:31:51 --> Router Class Initialized
INFO - 2016-05-21 12:31:51 --> Output Class Initialized
INFO - 2016-05-21 12:31:51 --> Security Class Initialized
DEBUG - 2016-05-21 12:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:31:51 --> Input Class Initialized
INFO - 2016-05-21 12:31:51 --> Language Class Initialized
INFO - 2016-05-21 12:31:51 --> Loader Class Initialized
INFO - 2016-05-21 12:31:51 --> Helper loaded: url_helper
INFO - 2016-05-21 12:31:51 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:31:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:31:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:31:51 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:31:51 --> Helper loaded: form_helper
INFO - 2016-05-21 12:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:31:51 --> Form Validation Class Initialized
INFO - 2016-05-21 12:31:51 --> Controller Class Initialized
INFO - 2016-05-21 12:31:51 --> Model Class Initialized
INFO - 2016-05-21 12:31:52 --> Database Driver Class Initialized
INFO - 2016-05-21 12:31:52 --> Final output sent to browser
DEBUG - 2016-05-21 12:31:52 --> Total execution time: 0.1535
INFO - 2016-05-21 12:31:55 --> Config Class Initialized
INFO - 2016-05-21 12:31:55 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:31:55 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:31:55 --> Utf8 Class Initialized
INFO - 2016-05-21 12:31:55 --> URI Class Initialized
INFO - 2016-05-21 12:31:55 --> Router Class Initialized
INFO - 2016-05-21 12:31:55 --> Output Class Initialized
INFO - 2016-05-21 12:31:55 --> Security Class Initialized
DEBUG - 2016-05-21 12:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:31:55 --> Input Class Initialized
INFO - 2016-05-21 12:31:55 --> Language Class Initialized
INFO - 2016-05-21 12:31:55 --> Loader Class Initialized
INFO - 2016-05-21 12:31:55 --> Helper loaded: url_helper
INFO - 2016-05-21 12:31:55 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:31:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:31:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:31:55 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:31:55 --> Helper loaded: form_helper
INFO - 2016-05-21 12:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:31:56 --> Form Validation Class Initialized
INFO - 2016-05-21 12:31:56 --> Controller Class Initialized
INFO - 2016-05-21 12:31:56 --> Model Class Initialized
INFO - 2016-05-21 12:31:56 --> Database Driver Class Initialized
INFO - 2016-05-21 12:31:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:31:56 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:31:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:31:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:31:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:31:56 --> Final output sent to browser
DEBUG - 2016-05-21 12:31:56 --> Total execution time: 0.0992
INFO - 2016-05-21 12:31:56 --> Config Class Initialized
INFO - 2016-05-21 12:31:56 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:31:56 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:31:56 --> Utf8 Class Initialized
INFO - 2016-05-21 12:31:56 --> URI Class Initialized
INFO - 2016-05-21 12:31:56 --> Router Class Initialized
INFO - 2016-05-21 12:31:56 --> Output Class Initialized
INFO - 2016-05-21 12:31:56 --> Security Class Initialized
DEBUG - 2016-05-21 12:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:31:56 --> Input Class Initialized
INFO - 2016-05-21 12:31:56 --> Language Class Initialized
INFO - 2016-05-21 12:31:56 --> Loader Class Initialized
INFO - 2016-05-21 12:31:56 --> Helper loaded: url_helper
INFO - 2016-05-21 12:31:56 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:31:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:31:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:31:56 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:31:56 --> Helper loaded: form_helper
INFO - 2016-05-21 12:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:31:56 --> Form Validation Class Initialized
INFO - 2016-05-21 12:31:56 --> Controller Class Initialized
INFO - 2016-05-21 12:31:56 --> Model Class Initialized
INFO - 2016-05-21 12:31:56 --> Database Driver Class Initialized
INFO - 2016-05-21 12:31:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:31:56 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:31:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:31:56 --> Final output sent to browser
DEBUG - 2016-05-21 12:31:56 --> Total execution time: 0.0869
INFO - 2016-05-21 12:31:59 --> Config Class Initialized
INFO - 2016-05-21 12:31:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:31:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:31:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:31:59 --> URI Class Initialized
INFO - 2016-05-21 12:31:59 --> Router Class Initialized
INFO - 2016-05-21 12:31:59 --> Output Class Initialized
INFO - 2016-05-21 12:31:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:31:59 --> Input Class Initialized
INFO - 2016-05-21 12:31:59 --> Language Class Initialized
INFO - 2016-05-21 12:31:59 --> Loader Class Initialized
INFO - 2016-05-21 12:31:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:31:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:31:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:31:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:31:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:31:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:31:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:31:59 --> Controller Class Initialized
INFO - 2016-05-21 12:31:59 --> Model Class Initialized
INFO - 2016-05-21 12:31:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:31:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:31:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:31:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:31:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:31:59 --> Total execution time: 0.0718
INFO - 2016-05-21 12:32:04 --> Config Class Initialized
INFO - 2016-05-21 12:32:04 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:32:04 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:32:04 --> Utf8 Class Initialized
INFO - 2016-05-21 12:32:04 --> URI Class Initialized
INFO - 2016-05-21 12:32:04 --> Router Class Initialized
INFO - 2016-05-21 12:32:04 --> Output Class Initialized
INFO - 2016-05-21 12:32:04 --> Security Class Initialized
DEBUG - 2016-05-21 12:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:32:04 --> Input Class Initialized
INFO - 2016-05-21 12:32:04 --> Language Class Initialized
INFO - 2016-05-21 12:32:04 --> Loader Class Initialized
INFO - 2016-05-21 12:32:04 --> Helper loaded: url_helper
INFO - 2016-05-21 12:32:04 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:32:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:32:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:32:04 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:32:04 --> Helper loaded: form_helper
INFO - 2016-05-21 12:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:32:04 --> Form Validation Class Initialized
INFO - 2016-05-21 12:32:04 --> Controller Class Initialized
INFO - 2016-05-21 12:32:04 --> Model Class Initialized
INFO - 2016-05-21 12:32:04 --> Database Driver Class Initialized
INFO - 2016-05-21 12:32:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:32:04 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:32:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:32:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:32:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:32:04 --> Final output sent to browser
DEBUG - 2016-05-21 12:32:04 --> Total execution time: 0.0971
INFO - 2016-05-21 12:32:04 --> Config Class Initialized
INFO - 2016-05-21 12:32:04 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:32:04 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:32:04 --> Utf8 Class Initialized
INFO - 2016-05-21 12:32:04 --> URI Class Initialized
INFO - 2016-05-21 12:32:04 --> Router Class Initialized
INFO - 2016-05-21 12:32:04 --> Output Class Initialized
INFO - 2016-05-21 12:32:04 --> Security Class Initialized
DEBUG - 2016-05-21 12:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:32:04 --> Input Class Initialized
INFO - 2016-05-21 12:32:05 --> Language Class Initialized
INFO - 2016-05-21 12:32:05 --> Loader Class Initialized
INFO - 2016-05-21 12:32:05 --> Helper loaded: url_helper
INFO - 2016-05-21 12:32:05 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:32:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:32:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:32:05 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:32:05 --> Helper loaded: form_helper
INFO - 2016-05-21 12:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:32:05 --> Form Validation Class Initialized
INFO - 2016-05-21 12:32:05 --> Controller Class Initialized
INFO - 2016-05-21 12:32:05 --> Model Class Initialized
INFO - 2016-05-21 12:32:05 --> Database Driver Class Initialized
INFO - 2016-05-21 12:32:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:32:05 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:32:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:32:05 --> Final output sent to browser
DEBUG - 2016-05-21 12:32:05 --> Total execution time: 0.1048
INFO - 2016-05-21 12:32:15 --> Config Class Initialized
INFO - 2016-05-21 12:32:15 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:32:15 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:32:15 --> Utf8 Class Initialized
INFO - 2016-05-21 12:32:15 --> URI Class Initialized
INFO - 2016-05-21 12:32:15 --> Router Class Initialized
INFO - 2016-05-21 12:32:15 --> Output Class Initialized
INFO - 2016-05-21 12:32:15 --> Security Class Initialized
DEBUG - 2016-05-21 12:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:32:15 --> Input Class Initialized
INFO - 2016-05-21 12:32:15 --> Language Class Initialized
INFO - 2016-05-21 12:32:15 --> Loader Class Initialized
INFO - 2016-05-21 12:32:15 --> Helper loaded: url_helper
INFO - 2016-05-21 12:32:15 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:32:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:32:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:32:15 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:32:15 --> Helper loaded: form_helper
INFO - 2016-05-21 12:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:32:15 --> Form Validation Class Initialized
INFO - 2016-05-21 12:32:15 --> Controller Class Initialized
INFO - 2016-05-21 12:32:15 --> Model Class Initialized
INFO - 2016-05-21 12:32:15 --> Database Driver Class Initialized
INFO - 2016-05-21 12:32:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:32:15 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:32:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:32:15 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:32:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:32:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:32:15 --> Final output sent to browser
DEBUG - 2016-05-21 12:32:15 --> Total execution time: 0.1309
INFO - 2016-05-21 12:32:15 --> Config Class Initialized
INFO - 2016-05-21 12:32:15 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:32:15 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:32:15 --> Utf8 Class Initialized
INFO - 2016-05-21 12:32:15 --> URI Class Initialized
INFO - 2016-05-21 12:32:15 --> Router Class Initialized
INFO - 2016-05-21 12:32:15 --> Output Class Initialized
INFO - 2016-05-21 12:32:15 --> Security Class Initialized
DEBUG - 2016-05-21 12:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:32:15 --> Input Class Initialized
INFO - 2016-05-21 12:32:15 --> Language Class Initialized
INFO - 2016-05-21 12:32:15 --> Loader Class Initialized
INFO - 2016-05-21 12:32:15 --> Helper loaded: url_helper
INFO - 2016-05-21 12:32:15 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:32:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:32:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:32:15 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:32:15 --> Helper loaded: form_helper
INFO - 2016-05-21 12:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:32:15 --> Form Validation Class Initialized
INFO - 2016-05-21 12:32:15 --> Controller Class Initialized
INFO - 2016-05-21 12:32:15 --> Model Class Initialized
INFO - 2016-05-21 12:32:15 --> Database Driver Class Initialized
INFO - 2016-05-21 12:32:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:32:15 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:32:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:32:15 --> Final output sent to browser
DEBUG - 2016-05-21 12:32:15 --> Total execution time: 0.1045
INFO - 2016-05-21 12:32:17 --> Config Class Initialized
INFO - 2016-05-21 12:32:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:32:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:32:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:32:17 --> URI Class Initialized
INFO - 2016-05-21 12:32:17 --> Router Class Initialized
INFO - 2016-05-21 12:32:17 --> Output Class Initialized
INFO - 2016-05-21 12:32:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:32:17 --> Input Class Initialized
INFO - 2016-05-21 12:32:17 --> Language Class Initialized
INFO - 2016-05-21 12:32:17 --> Loader Class Initialized
INFO - 2016-05-21 12:32:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:32:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:32:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:32:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:32:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:32:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:32:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:32:17 --> Controller Class Initialized
INFO - 2016-05-21 12:32:17 --> Model Class Initialized
INFO - 2016-05-21 12:32:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:32:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:32:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:32:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:32:17 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:32:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:32:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:32:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:32:17 --> Total execution time: 0.2713
INFO - 2016-05-21 12:32:17 --> Config Class Initialized
INFO - 2016-05-21 12:32:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:32:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:32:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:32:17 --> URI Class Initialized
INFO - 2016-05-21 12:32:17 --> Router Class Initialized
INFO - 2016-05-21 12:32:17 --> Output Class Initialized
INFO - 2016-05-21 12:32:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:32:17 --> Input Class Initialized
INFO - 2016-05-21 12:32:17 --> Language Class Initialized
INFO - 2016-05-21 12:32:17 --> Loader Class Initialized
INFO - 2016-05-21 12:32:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:32:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:32:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:32:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:32:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:32:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:32:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:32:17 --> Controller Class Initialized
INFO - 2016-05-21 12:32:17 --> Model Class Initialized
INFO - 2016-05-21 12:32:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:32:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:32:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:32:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:32:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:32:17 --> Total execution time: 0.1190
INFO - 2016-05-21 12:32:59 --> Config Class Initialized
INFO - 2016-05-21 12:32:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:32:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:32:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:32:59 --> URI Class Initialized
INFO - 2016-05-21 12:32:59 --> Router Class Initialized
INFO - 2016-05-21 12:32:59 --> Output Class Initialized
INFO - 2016-05-21 12:32:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:32:59 --> Input Class Initialized
INFO - 2016-05-21 12:32:59 --> Language Class Initialized
INFO - 2016-05-21 12:32:59 --> Loader Class Initialized
INFO - 2016-05-21 12:32:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:32:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:32:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:32:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:32:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:32:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:32:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:32:59 --> Controller Class Initialized
INFO - 2016-05-21 12:32:59 --> Model Class Initialized
INFO - 2016-05-21 12:32:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:32:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:32:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:32:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:32:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:32:59 --> Total execution time: 0.0737
INFO - 2016-05-21 12:33:17 --> Config Class Initialized
INFO - 2016-05-21 12:33:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:33:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:33:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:33:17 --> URI Class Initialized
INFO - 2016-05-21 12:33:17 --> Router Class Initialized
INFO - 2016-05-21 12:33:17 --> Output Class Initialized
INFO - 2016-05-21 12:33:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:33:17 --> Input Class Initialized
INFO - 2016-05-21 12:33:17 --> Language Class Initialized
INFO - 2016-05-21 12:33:17 --> Loader Class Initialized
INFO - 2016-05-21 12:33:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:33:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:33:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:33:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:33:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:33:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:33:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:33:17 --> Controller Class Initialized
INFO - 2016-05-21 12:33:17 --> Model Class Initialized
INFO - 2016-05-21 12:33:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:33:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:33:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:33:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:33:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:33:17 --> Total execution time: 0.0868
INFO - 2016-05-21 12:33:46 --> Config Class Initialized
INFO - 2016-05-21 12:33:46 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:33:46 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:33:46 --> Utf8 Class Initialized
INFO - 2016-05-21 12:33:46 --> URI Class Initialized
INFO - 2016-05-21 12:33:46 --> Router Class Initialized
INFO - 2016-05-21 12:33:46 --> Output Class Initialized
INFO - 2016-05-21 12:33:46 --> Security Class Initialized
DEBUG - 2016-05-21 12:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:33:46 --> Input Class Initialized
INFO - 2016-05-21 12:33:46 --> Language Class Initialized
INFO - 2016-05-21 12:33:46 --> Loader Class Initialized
INFO - 2016-05-21 12:33:46 --> Helper loaded: url_helper
INFO - 2016-05-21 12:33:46 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:33:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:33:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:33:46 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:33:46 --> Helper loaded: form_helper
INFO - 2016-05-21 12:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:33:46 --> Form Validation Class Initialized
INFO - 2016-05-21 12:33:46 --> Controller Class Initialized
INFO - 2016-05-21 12:33:46 --> Model Class Initialized
INFO - 2016-05-21 12:33:46 --> Database Driver Class Initialized
INFO - 2016-05-21 12:33:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:33:46 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:33:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:33:46 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:33:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:33:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:33:46 --> Final output sent to browser
DEBUG - 2016-05-21 12:33:46 --> Total execution time: 0.1335
INFO - 2016-05-21 12:33:46 --> Config Class Initialized
INFO - 2016-05-21 12:33:46 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:33:46 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:33:46 --> Utf8 Class Initialized
INFO - 2016-05-21 12:33:46 --> URI Class Initialized
INFO - 2016-05-21 12:33:46 --> Router Class Initialized
INFO - 2016-05-21 12:33:46 --> Output Class Initialized
INFO - 2016-05-21 12:33:46 --> Security Class Initialized
DEBUG - 2016-05-21 12:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:33:46 --> Input Class Initialized
INFO - 2016-05-21 12:33:46 --> Language Class Initialized
INFO - 2016-05-21 12:33:46 --> Loader Class Initialized
INFO - 2016-05-21 12:33:46 --> Helper loaded: url_helper
INFO - 2016-05-21 12:33:46 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:33:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:33:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:33:46 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:33:46 --> Helper loaded: form_helper
INFO - 2016-05-21 12:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:33:46 --> Form Validation Class Initialized
INFO - 2016-05-21 12:33:46 --> Controller Class Initialized
INFO - 2016-05-21 12:33:47 --> Model Class Initialized
INFO - 2016-05-21 12:33:47 --> Database Driver Class Initialized
INFO - 2016-05-21 12:33:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:33:47 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:33:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:33:47 --> Final output sent to browser
DEBUG - 2016-05-21 12:33:47 --> Total execution time: 0.1147
INFO - 2016-05-21 12:33:48 --> Config Class Initialized
INFO - 2016-05-21 12:33:48 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:33:48 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:33:48 --> Utf8 Class Initialized
INFO - 2016-05-21 12:33:48 --> URI Class Initialized
INFO - 2016-05-21 12:33:48 --> Router Class Initialized
INFO - 2016-05-21 12:33:48 --> Output Class Initialized
INFO - 2016-05-21 12:33:48 --> Security Class Initialized
DEBUG - 2016-05-21 12:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:33:48 --> Input Class Initialized
INFO - 2016-05-21 12:33:48 --> Language Class Initialized
INFO - 2016-05-21 12:33:48 --> Loader Class Initialized
INFO - 2016-05-21 12:33:48 --> Helper loaded: url_helper
INFO - 2016-05-21 12:33:48 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:33:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:33:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:33:48 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:33:48 --> Helper loaded: form_helper
INFO - 2016-05-21 12:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:33:48 --> Form Validation Class Initialized
INFO - 2016-05-21 12:33:48 --> Controller Class Initialized
INFO - 2016-05-21 12:33:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-21 12:33:48 --> Final output sent to browser
DEBUG - 2016-05-21 12:33:48 --> Total execution time: 0.0989
INFO - 2016-05-21 12:33:59 --> Config Class Initialized
INFO - 2016-05-21 12:33:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:33:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:33:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:33:59 --> URI Class Initialized
INFO - 2016-05-21 12:33:59 --> Router Class Initialized
INFO - 2016-05-21 12:33:59 --> Output Class Initialized
INFO - 2016-05-21 12:33:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:33:59 --> Input Class Initialized
INFO - 2016-05-21 12:33:59 --> Language Class Initialized
INFO - 2016-05-21 12:33:59 --> Loader Class Initialized
INFO - 2016-05-21 12:33:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:33:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:33:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:33:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:33:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:33:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:33:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:33:59 --> Controller Class Initialized
INFO - 2016-05-21 12:33:59 --> Model Class Initialized
INFO - 2016-05-21 12:33:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:33:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:33:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:33:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:33:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:33:59 --> Total execution time: 0.0931
INFO - 2016-05-21 12:34:00 --> Config Class Initialized
INFO - 2016-05-21 12:34:00 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:34:00 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:34:00 --> Utf8 Class Initialized
INFO - 2016-05-21 12:34:00 --> URI Class Initialized
INFO - 2016-05-21 12:34:00 --> Router Class Initialized
INFO - 2016-05-21 12:34:00 --> Output Class Initialized
INFO - 2016-05-21 12:34:00 --> Security Class Initialized
DEBUG - 2016-05-21 12:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:34:00 --> Input Class Initialized
INFO - 2016-05-21 12:34:00 --> Language Class Initialized
INFO - 2016-05-21 12:34:00 --> Loader Class Initialized
INFO - 2016-05-21 12:34:00 --> Helper loaded: url_helper
INFO - 2016-05-21 12:34:00 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:34:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:34:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:34:00 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:34:00 --> Helper loaded: form_helper
INFO - 2016-05-21 12:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:34:00 --> Form Validation Class Initialized
INFO - 2016-05-21 12:34:00 --> Controller Class Initialized
INFO - 2016-05-21 12:34:00 --> Model Class Initialized
INFO - 2016-05-21 12:34:00 --> Database Driver Class Initialized
INFO - 2016-05-21 12:34:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:34:00 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:34:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:34:00 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:34:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:34:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:34:00 --> Final output sent to browser
DEBUG - 2016-05-21 12:34:00 --> Total execution time: 0.2665
INFO - 2016-05-21 12:34:01 --> Config Class Initialized
INFO - 2016-05-21 12:34:01 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:34:01 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:34:01 --> Utf8 Class Initialized
INFO - 2016-05-21 12:34:01 --> URI Class Initialized
INFO - 2016-05-21 12:34:01 --> Router Class Initialized
INFO - 2016-05-21 12:34:01 --> Output Class Initialized
INFO - 2016-05-21 12:34:01 --> Security Class Initialized
DEBUG - 2016-05-21 12:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:34:01 --> Input Class Initialized
INFO - 2016-05-21 12:34:01 --> Language Class Initialized
INFO - 2016-05-21 12:34:01 --> Loader Class Initialized
INFO - 2016-05-21 12:34:01 --> Helper loaded: url_helper
INFO - 2016-05-21 12:34:01 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:34:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:34:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:34:01 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:34:01 --> Helper loaded: form_helper
INFO - 2016-05-21 12:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:34:01 --> Form Validation Class Initialized
INFO - 2016-05-21 12:34:01 --> Controller Class Initialized
INFO - 2016-05-21 12:34:01 --> Model Class Initialized
INFO - 2016-05-21 12:34:01 --> Database Driver Class Initialized
INFO - 2016-05-21 12:34:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:34:01 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:34:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:34:01 --> Final output sent to browser
DEBUG - 2016-05-21 12:34:01 --> Total execution time: 0.1177
INFO - 2016-05-21 12:34:05 --> Config Class Initialized
INFO - 2016-05-21 12:34:05 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:34:05 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:34:05 --> Utf8 Class Initialized
INFO - 2016-05-21 12:34:05 --> URI Class Initialized
INFO - 2016-05-21 12:34:05 --> Router Class Initialized
INFO - 2016-05-21 12:34:05 --> Output Class Initialized
INFO - 2016-05-21 12:34:05 --> Security Class Initialized
DEBUG - 2016-05-21 12:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:34:05 --> Input Class Initialized
INFO - 2016-05-21 12:34:05 --> Language Class Initialized
INFO - 2016-05-21 12:34:05 --> Loader Class Initialized
INFO - 2016-05-21 12:34:05 --> Helper loaded: url_helper
INFO - 2016-05-21 12:34:05 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:34:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:34:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:34:05 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:34:05 --> Helper loaded: form_helper
INFO - 2016-05-21 12:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:34:05 --> Form Validation Class Initialized
INFO - 2016-05-21 12:34:05 --> Controller Class Initialized
INFO - 2016-05-21 12:34:05 --> Model Class Initialized
INFO - 2016-05-21 12:34:05 --> Database Driver Class Initialized
INFO - 2016-05-21 12:34:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:34:05 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:34:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:34:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:34:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:34:05 --> Final output sent to browser
DEBUG - 2016-05-21 12:34:05 --> Total execution time: 0.1118
INFO - 2016-05-21 12:34:05 --> Config Class Initialized
INFO - 2016-05-21 12:34:05 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:34:05 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:34:05 --> Utf8 Class Initialized
INFO - 2016-05-21 12:34:05 --> URI Class Initialized
INFO - 2016-05-21 12:34:05 --> Router Class Initialized
INFO - 2016-05-21 12:34:05 --> Output Class Initialized
INFO - 2016-05-21 12:34:05 --> Security Class Initialized
DEBUG - 2016-05-21 12:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:34:05 --> Input Class Initialized
INFO - 2016-05-21 12:34:05 --> Language Class Initialized
INFO - 2016-05-21 12:34:05 --> Loader Class Initialized
INFO - 2016-05-21 12:34:05 --> Helper loaded: url_helper
INFO - 2016-05-21 12:34:05 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:34:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:34:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:34:05 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:34:05 --> Helper loaded: form_helper
INFO - 2016-05-21 12:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:34:05 --> Form Validation Class Initialized
INFO - 2016-05-21 12:34:05 --> Controller Class Initialized
INFO - 2016-05-21 12:34:05 --> Model Class Initialized
INFO - 2016-05-21 12:34:05 --> Database Driver Class Initialized
INFO - 2016-05-21 12:34:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:34:05 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:34:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:34:05 --> Final output sent to browser
DEBUG - 2016-05-21 12:34:05 --> Total execution time: 0.0891
INFO - 2016-05-21 12:34:09 --> Config Class Initialized
INFO - 2016-05-21 12:34:09 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:34:09 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:34:09 --> Utf8 Class Initialized
INFO - 2016-05-21 12:34:09 --> URI Class Initialized
INFO - 2016-05-21 12:34:09 --> Router Class Initialized
INFO - 2016-05-21 12:34:09 --> Output Class Initialized
INFO - 2016-05-21 12:34:09 --> Security Class Initialized
DEBUG - 2016-05-21 12:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:34:09 --> Input Class Initialized
INFO - 2016-05-21 12:34:09 --> Language Class Initialized
INFO - 2016-05-21 12:34:09 --> Loader Class Initialized
INFO - 2016-05-21 12:34:09 --> Helper loaded: url_helper
INFO - 2016-05-21 12:34:09 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:34:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:34:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:34:09 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:34:09 --> Helper loaded: form_helper
INFO - 2016-05-21 12:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:34:09 --> Form Validation Class Initialized
INFO - 2016-05-21 12:34:09 --> Controller Class Initialized
INFO - 2016-05-21 12:34:09 --> Model Class Initialized
INFO - 2016-05-21 12:34:09 --> Database Driver Class Initialized
INFO - 2016-05-21 12:34:10 --> Final output sent to browser
DEBUG - 2016-05-21 12:34:10 --> Total execution time: 0.1508
INFO - 2016-05-21 12:34:16 --> Config Class Initialized
INFO - 2016-05-21 12:34:16 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:34:16 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:34:16 --> Utf8 Class Initialized
INFO - 2016-05-21 12:34:16 --> URI Class Initialized
INFO - 2016-05-21 12:34:16 --> Router Class Initialized
INFO - 2016-05-21 12:34:16 --> Output Class Initialized
INFO - 2016-05-21 12:34:16 --> Security Class Initialized
DEBUG - 2016-05-21 12:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:34:16 --> Input Class Initialized
INFO - 2016-05-21 12:34:16 --> Language Class Initialized
INFO - 2016-05-21 12:34:16 --> Loader Class Initialized
INFO - 2016-05-21 12:34:16 --> Helper loaded: url_helper
INFO - 2016-05-21 12:34:16 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:34:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:34:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:34:16 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:34:16 --> Helper loaded: form_helper
INFO - 2016-05-21 12:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:34:16 --> Form Validation Class Initialized
INFO - 2016-05-21 12:34:16 --> Controller Class Initialized
INFO - 2016-05-21 12:34:16 --> Model Class Initialized
INFO - 2016-05-21 12:34:16 --> Database Driver Class Initialized
INFO - 2016-05-21 12:34:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:34:16 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:34:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:34:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:34:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:34:16 --> Final output sent to browser
DEBUG - 2016-05-21 12:34:16 --> Total execution time: 0.1081
INFO - 2016-05-21 12:34:17 --> Config Class Initialized
INFO - 2016-05-21 12:34:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:34:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:34:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:34:17 --> URI Class Initialized
INFO - 2016-05-21 12:34:17 --> Router Class Initialized
INFO - 2016-05-21 12:34:17 --> Output Class Initialized
INFO - 2016-05-21 12:34:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:34:17 --> Input Class Initialized
INFO - 2016-05-21 12:34:17 --> Language Class Initialized
INFO - 2016-05-21 12:34:17 --> Loader Class Initialized
INFO - 2016-05-21 12:34:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:34:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:34:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:34:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:34:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:34:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:34:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:34:17 --> Controller Class Initialized
INFO - 2016-05-21 12:34:17 --> Model Class Initialized
INFO - 2016-05-21 12:34:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:34:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:34:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:34:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:34:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:34:17 --> Total execution time: 0.0901
INFO - 2016-05-21 12:34:25 --> Config Class Initialized
INFO - 2016-05-21 12:34:25 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:34:25 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:34:25 --> Utf8 Class Initialized
INFO - 2016-05-21 12:34:25 --> URI Class Initialized
INFO - 2016-05-21 12:34:25 --> Router Class Initialized
INFO - 2016-05-21 12:34:25 --> Output Class Initialized
INFO - 2016-05-21 12:34:25 --> Security Class Initialized
DEBUG - 2016-05-21 12:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:34:25 --> Input Class Initialized
INFO - 2016-05-21 12:34:25 --> Language Class Initialized
INFO - 2016-05-21 12:34:25 --> Loader Class Initialized
INFO - 2016-05-21 12:34:25 --> Helper loaded: url_helper
INFO - 2016-05-21 12:34:25 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:34:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:34:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:34:25 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:34:25 --> Helper loaded: form_helper
INFO - 2016-05-21 12:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:34:25 --> Form Validation Class Initialized
INFO - 2016-05-21 12:34:25 --> Controller Class Initialized
INFO - 2016-05-21 12:34:25 --> Model Class Initialized
INFO - 2016-05-21 12:34:25 --> Database Driver Class Initialized
INFO - 2016-05-21 12:34:25 --> Final output sent to browser
DEBUG - 2016-05-21 12:34:25 --> Total execution time: 0.1213
INFO - 2016-05-21 12:34:59 --> Config Class Initialized
INFO - 2016-05-21 12:34:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:34:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:34:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:34:59 --> URI Class Initialized
INFO - 2016-05-21 12:34:59 --> Router Class Initialized
INFO - 2016-05-21 12:34:59 --> Output Class Initialized
INFO - 2016-05-21 12:34:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:34:59 --> Input Class Initialized
INFO - 2016-05-21 12:34:59 --> Language Class Initialized
INFO - 2016-05-21 12:34:59 --> Loader Class Initialized
INFO - 2016-05-21 12:34:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:34:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:34:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:34:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:34:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:34:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:34:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:34:59 --> Controller Class Initialized
INFO - 2016-05-21 12:34:59 --> Model Class Initialized
INFO - 2016-05-21 12:34:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:34:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:34:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:34:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:34:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:34:59 --> Total execution time: 0.0778
INFO - 2016-05-21 12:35:17 --> Config Class Initialized
INFO - 2016-05-21 12:35:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:35:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:35:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:35:17 --> URI Class Initialized
INFO - 2016-05-21 12:35:17 --> Router Class Initialized
INFO - 2016-05-21 12:35:17 --> Output Class Initialized
INFO - 2016-05-21 12:35:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:35:17 --> Input Class Initialized
INFO - 2016-05-21 12:35:17 --> Language Class Initialized
INFO - 2016-05-21 12:35:17 --> Loader Class Initialized
INFO - 2016-05-21 12:35:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:35:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:35:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:35:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:35:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:35:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:35:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:35:17 --> Controller Class Initialized
INFO - 2016-05-21 12:35:17 --> Model Class Initialized
INFO - 2016-05-21 12:35:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:35:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:35:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:35:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:35:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:35:17 --> Total execution time: 0.0740
INFO - 2016-05-21 12:35:59 --> Config Class Initialized
INFO - 2016-05-21 12:35:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:35:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:35:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:35:59 --> URI Class Initialized
INFO - 2016-05-21 12:35:59 --> Router Class Initialized
INFO - 2016-05-21 12:35:59 --> Output Class Initialized
INFO - 2016-05-21 12:35:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:35:59 --> Input Class Initialized
INFO - 2016-05-21 12:35:59 --> Language Class Initialized
INFO - 2016-05-21 12:35:59 --> Loader Class Initialized
INFO - 2016-05-21 12:35:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:35:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:35:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:35:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:35:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:35:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:35:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:35:59 --> Controller Class Initialized
INFO - 2016-05-21 12:35:59 --> Model Class Initialized
INFO - 2016-05-21 12:35:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:35:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:35:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:35:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:35:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:35:59 --> Total execution time: 0.0764
INFO - 2016-05-21 12:36:17 --> Config Class Initialized
INFO - 2016-05-21 12:36:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:36:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:36:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:36:17 --> URI Class Initialized
INFO - 2016-05-21 12:36:17 --> Router Class Initialized
INFO - 2016-05-21 12:36:17 --> Output Class Initialized
INFO - 2016-05-21 12:36:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:36:17 --> Input Class Initialized
INFO - 2016-05-21 12:36:17 --> Language Class Initialized
INFO - 2016-05-21 12:36:17 --> Loader Class Initialized
INFO - 2016-05-21 12:36:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:36:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:36:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:36:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:36:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:36:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:36:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:36:17 --> Controller Class Initialized
INFO - 2016-05-21 12:36:17 --> Model Class Initialized
INFO - 2016-05-21 12:36:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:36:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:36:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:36:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:36:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:36:17 --> Total execution time: 0.0776
INFO - 2016-05-21 12:36:59 --> Config Class Initialized
INFO - 2016-05-21 12:36:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:36:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:36:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:36:59 --> URI Class Initialized
INFO - 2016-05-21 12:36:59 --> Router Class Initialized
INFO - 2016-05-21 12:36:59 --> Output Class Initialized
INFO - 2016-05-21 12:36:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:36:59 --> Input Class Initialized
INFO - 2016-05-21 12:36:59 --> Language Class Initialized
INFO - 2016-05-21 12:36:59 --> Loader Class Initialized
INFO - 2016-05-21 12:36:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:36:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:36:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:36:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:36:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:36:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:36:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:36:59 --> Controller Class Initialized
INFO - 2016-05-21 12:36:59 --> Model Class Initialized
INFO - 2016-05-21 12:36:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:36:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:36:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:36:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:36:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:36:59 --> Total execution time: 0.0856
INFO - 2016-05-21 12:37:17 --> Config Class Initialized
INFO - 2016-05-21 12:37:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:37:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:37:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:37:17 --> URI Class Initialized
INFO - 2016-05-21 12:37:17 --> Router Class Initialized
INFO - 2016-05-21 12:37:17 --> Output Class Initialized
INFO - 2016-05-21 12:37:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:37:17 --> Input Class Initialized
INFO - 2016-05-21 12:37:17 --> Language Class Initialized
INFO - 2016-05-21 12:37:17 --> Loader Class Initialized
INFO - 2016-05-21 12:37:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:37:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:37:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:37:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:37:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:37:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:37:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:37:17 --> Controller Class Initialized
INFO - 2016-05-21 12:37:17 --> Model Class Initialized
INFO - 2016-05-21 12:37:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:37:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:37:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:37:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:37:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:37:17 --> Total execution time: 0.0777
INFO - 2016-05-21 12:37:59 --> Config Class Initialized
INFO - 2016-05-21 12:37:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:37:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:37:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:37:59 --> URI Class Initialized
INFO - 2016-05-21 12:37:59 --> Router Class Initialized
INFO - 2016-05-21 12:37:59 --> Output Class Initialized
INFO - 2016-05-21 12:37:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:37:59 --> Input Class Initialized
INFO - 2016-05-21 12:37:59 --> Language Class Initialized
INFO - 2016-05-21 12:37:59 --> Loader Class Initialized
INFO - 2016-05-21 12:37:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:37:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:37:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:37:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:37:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:37:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:37:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:37:59 --> Controller Class Initialized
INFO - 2016-05-21 12:37:59 --> Model Class Initialized
INFO - 2016-05-21 12:37:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:37:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:37:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:37:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:37:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:37:59 --> Total execution time: 0.0884
INFO - 2016-05-21 12:38:17 --> Config Class Initialized
INFO - 2016-05-21 12:38:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:38:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:38:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:38:17 --> URI Class Initialized
INFO - 2016-05-21 12:38:17 --> Router Class Initialized
INFO - 2016-05-21 12:38:17 --> Output Class Initialized
INFO - 2016-05-21 12:38:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:38:17 --> Input Class Initialized
INFO - 2016-05-21 12:38:17 --> Language Class Initialized
INFO - 2016-05-21 12:38:17 --> Loader Class Initialized
INFO - 2016-05-21 12:38:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:38:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:38:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:38:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:38:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:38:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:38:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:38:17 --> Controller Class Initialized
INFO - 2016-05-21 12:38:17 --> Model Class Initialized
INFO - 2016-05-21 12:38:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:38:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:38:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:38:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:38:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:38:17 --> Total execution time: 0.0745
INFO - 2016-05-21 12:38:59 --> Config Class Initialized
INFO - 2016-05-21 12:38:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:38:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:38:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:38:59 --> URI Class Initialized
INFO - 2016-05-21 12:38:59 --> Router Class Initialized
INFO - 2016-05-21 12:38:59 --> Output Class Initialized
INFO - 2016-05-21 12:38:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:38:59 --> Input Class Initialized
INFO - 2016-05-21 12:38:59 --> Language Class Initialized
INFO - 2016-05-21 12:38:59 --> Loader Class Initialized
INFO - 2016-05-21 12:38:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:38:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:38:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:38:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:38:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:38:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:38:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:38:59 --> Controller Class Initialized
INFO - 2016-05-21 12:38:59 --> Model Class Initialized
INFO - 2016-05-21 12:38:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:38:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:38:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:38:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:38:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:38:59 --> Total execution time: 0.0985
INFO - 2016-05-21 12:39:17 --> Config Class Initialized
INFO - 2016-05-21 12:39:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:39:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:39:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:39:17 --> URI Class Initialized
INFO - 2016-05-21 12:39:17 --> Router Class Initialized
INFO - 2016-05-21 12:39:17 --> Output Class Initialized
INFO - 2016-05-21 12:39:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:39:17 --> Input Class Initialized
INFO - 2016-05-21 12:39:17 --> Language Class Initialized
INFO - 2016-05-21 12:39:17 --> Loader Class Initialized
INFO - 2016-05-21 12:39:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:39:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:39:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:39:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:39:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:39:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:39:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:39:17 --> Controller Class Initialized
INFO - 2016-05-21 12:39:17 --> Model Class Initialized
INFO - 2016-05-21 12:39:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:39:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:39:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:39:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:39:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:39:17 --> Total execution time: 0.1060
INFO - 2016-05-21 12:39:59 --> Config Class Initialized
INFO - 2016-05-21 12:39:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:39:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:39:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:39:59 --> URI Class Initialized
INFO - 2016-05-21 12:39:59 --> Router Class Initialized
INFO - 2016-05-21 12:39:59 --> Output Class Initialized
INFO - 2016-05-21 12:39:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:39:59 --> Input Class Initialized
INFO - 2016-05-21 12:39:59 --> Language Class Initialized
INFO - 2016-05-21 12:39:59 --> Loader Class Initialized
INFO - 2016-05-21 12:39:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:39:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:39:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:39:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:39:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:39:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:39:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:39:59 --> Controller Class Initialized
INFO - 2016-05-21 12:39:59 --> Model Class Initialized
INFO - 2016-05-21 12:39:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:39:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:39:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:39:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:39:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:39:59 --> Total execution time: 0.0724
INFO - 2016-05-21 12:40:17 --> Config Class Initialized
INFO - 2016-05-21 12:40:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:40:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:40:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:40:17 --> URI Class Initialized
INFO - 2016-05-21 12:40:17 --> Router Class Initialized
INFO - 2016-05-21 12:40:17 --> Output Class Initialized
INFO - 2016-05-21 12:40:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:40:17 --> Input Class Initialized
INFO - 2016-05-21 12:40:17 --> Language Class Initialized
INFO - 2016-05-21 12:40:17 --> Loader Class Initialized
INFO - 2016-05-21 12:40:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:40:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:40:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:40:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:40:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:40:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:40:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:40:17 --> Controller Class Initialized
INFO - 2016-05-21 12:40:17 --> Model Class Initialized
INFO - 2016-05-21 12:40:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:40:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:40:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:40:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:40:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:40:17 --> Total execution time: 0.0814
INFO - 2016-05-21 12:40:45 --> Config Class Initialized
INFO - 2016-05-21 12:40:45 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:40:45 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:40:45 --> Utf8 Class Initialized
INFO - 2016-05-21 12:40:45 --> URI Class Initialized
INFO - 2016-05-21 12:40:45 --> Router Class Initialized
INFO - 2016-05-21 12:40:45 --> Output Class Initialized
INFO - 2016-05-21 12:40:45 --> Security Class Initialized
DEBUG - 2016-05-21 12:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:40:45 --> Input Class Initialized
INFO - 2016-05-21 12:40:45 --> Language Class Initialized
INFO - 2016-05-21 12:40:45 --> Loader Class Initialized
INFO - 2016-05-21 12:40:45 --> Helper loaded: url_helper
INFO - 2016-05-21 12:40:45 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:40:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:40:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:40:45 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:40:45 --> Helper loaded: form_helper
INFO - 2016-05-21 12:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:40:45 --> Form Validation Class Initialized
INFO - 2016-05-21 12:40:45 --> Controller Class Initialized
INFO - 2016-05-21 12:40:45 --> Model Class Initialized
INFO - 2016-05-21 12:40:45 --> Database Driver Class Initialized
INFO - 2016-05-21 12:40:45 --> Final output sent to browser
DEBUG - 2016-05-21 12:40:45 --> Total execution time: 0.1724
INFO - 2016-05-21 12:40:59 --> Config Class Initialized
INFO - 2016-05-21 12:40:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:40:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:40:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:40:59 --> URI Class Initialized
INFO - 2016-05-21 12:40:59 --> Router Class Initialized
INFO - 2016-05-21 12:40:59 --> Output Class Initialized
INFO - 2016-05-21 12:40:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:40:59 --> Input Class Initialized
INFO - 2016-05-21 12:40:59 --> Language Class Initialized
INFO - 2016-05-21 12:40:59 --> Loader Class Initialized
INFO - 2016-05-21 12:40:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:40:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:40:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:40:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:40:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:40:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:40:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:40:59 --> Controller Class Initialized
INFO - 2016-05-21 12:40:59 --> Model Class Initialized
INFO - 2016-05-21 12:40:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:40:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:40:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:40:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:40:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:40:59 --> Total execution time: 0.0806
INFO - 2016-05-21 12:41:17 --> Config Class Initialized
INFO - 2016-05-21 12:41:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:41:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:41:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:41:17 --> URI Class Initialized
INFO - 2016-05-21 12:41:17 --> Router Class Initialized
INFO - 2016-05-21 12:41:17 --> Output Class Initialized
INFO - 2016-05-21 12:41:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:41:17 --> Input Class Initialized
INFO - 2016-05-21 12:41:17 --> Language Class Initialized
INFO - 2016-05-21 12:41:17 --> Loader Class Initialized
INFO - 2016-05-21 12:41:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:41:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:41:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:41:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:41:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:41:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:41:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:41:17 --> Controller Class Initialized
INFO - 2016-05-21 12:41:17 --> Model Class Initialized
INFO - 2016-05-21 12:41:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:41:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:41:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:41:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:41:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:41:17 --> Total execution time: 0.0718
INFO - 2016-05-21 12:41:59 --> Config Class Initialized
INFO - 2016-05-21 12:41:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:41:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:41:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:41:59 --> URI Class Initialized
INFO - 2016-05-21 12:41:59 --> Router Class Initialized
INFO - 2016-05-21 12:41:59 --> Output Class Initialized
INFO - 2016-05-21 12:41:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:41:59 --> Input Class Initialized
INFO - 2016-05-21 12:41:59 --> Language Class Initialized
INFO - 2016-05-21 12:41:59 --> Loader Class Initialized
INFO - 2016-05-21 12:41:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:41:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:41:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:41:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:41:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:41:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:41:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:41:59 --> Controller Class Initialized
INFO - 2016-05-21 12:41:59 --> Model Class Initialized
INFO - 2016-05-21 12:41:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:41:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:41:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:41:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:41:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:41:59 --> Total execution time: 0.0725
INFO - 2016-05-21 12:42:17 --> Config Class Initialized
INFO - 2016-05-21 12:42:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:42:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:42:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:42:17 --> URI Class Initialized
INFO - 2016-05-21 12:42:17 --> Router Class Initialized
INFO - 2016-05-21 12:42:17 --> Output Class Initialized
INFO - 2016-05-21 12:42:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:42:17 --> Input Class Initialized
INFO - 2016-05-21 12:42:17 --> Language Class Initialized
INFO - 2016-05-21 12:42:17 --> Loader Class Initialized
INFO - 2016-05-21 12:42:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:42:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:42:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:42:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:42:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:42:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:42:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:42:17 --> Controller Class Initialized
INFO - 2016-05-21 12:42:17 --> Model Class Initialized
INFO - 2016-05-21 12:42:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:42:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:42:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:42:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:42:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:42:17 --> Total execution time: 0.0702
INFO - 2016-05-21 12:42:59 --> Config Class Initialized
INFO - 2016-05-21 12:42:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:42:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:42:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:42:59 --> URI Class Initialized
INFO - 2016-05-21 12:42:59 --> Router Class Initialized
INFO - 2016-05-21 12:42:59 --> Output Class Initialized
INFO - 2016-05-21 12:42:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:42:59 --> Input Class Initialized
INFO - 2016-05-21 12:42:59 --> Language Class Initialized
INFO - 2016-05-21 12:42:59 --> Loader Class Initialized
INFO - 2016-05-21 12:42:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:42:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:42:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:42:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:42:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:42:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:42:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:42:59 --> Controller Class Initialized
INFO - 2016-05-21 12:42:59 --> Model Class Initialized
INFO - 2016-05-21 12:42:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:42:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:42:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:42:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:42:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:42:59 --> Total execution time: 0.0760
INFO - 2016-05-21 12:43:08 --> Config Class Initialized
INFO - 2016-05-21 12:43:08 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:43:08 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:43:08 --> Utf8 Class Initialized
INFO - 2016-05-21 12:43:08 --> URI Class Initialized
INFO - 2016-05-21 12:43:08 --> Router Class Initialized
INFO - 2016-05-21 12:43:08 --> Output Class Initialized
INFO - 2016-05-21 12:43:08 --> Security Class Initialized
DEBUG - 2016-05-21 12:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:43:08 --> Input Class Initialized
INFO - 2016-05-21 12:43:08 --> Language Class Initialized
INFO - 2016-05-21 12:43:08 --> Loader Class Initialized
INFO - 2016-05-21 12:43:08 --> Helper loaded: url_helper
INFO - 2016-05-21 12:43:08 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:43:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:43:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:43:08 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:43:08 --> Helper loaded: form_helper
INFO - 2016-05-21 12:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:43:08 --> Form Validation Class Initialized
INFO - 2016-05-21 12:43:08 --> Controller Class Initialized
INFO - 2016-05-21 12:43:08 --> Model Class Initialized
INFO - 2016-05-21 12:43:08 --> Database Driver Class Initialized
INFO - 2016-05-21 12:43:08 --> Final output sent to browser
DEBUG - 2016-05-21 12:43:08 --> Total execution time: 0.1437
INFO - 2016-05-21 12:43:17 --> Config Class Initialized
INFO - 2016-05-21 12:43:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:43:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:43:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:43:17 --> URI Class Initialized
INFO - 2016-05-21 12:43:17 --> Router Class Initialized
INFO - 2016-05-21 12:43:17 --> Output Class Initialized
INFO - 2016-05-21 12:43:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:43:17 --> Input Class Initialized
INFO - 2016-05-21 12:43:17 --> Language Class Initialized
INFO - 2016-05-21 12:43:17 --> Loader Class Initialized
INFO - 2016-05-21 12:43:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:43:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:43:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:43:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:43:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:43:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:43:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:43:17 --> Controller Class Initialized
INFO - 2016-05-21 12:43:17 --> Model Class Initialized
INFO - 2016-05-21 12:43:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:43:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:43:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:43:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:43:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:43:17 --> Total execution time: 0.0712
INFO - 2016-05-21 12:43:59 --> Config Class Initialized
INFO - 2016-05-21 12:43:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:43:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:43:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:43:59 --> URI Class Initialized
INFO - 2016-05-21 12:43:59 --> Router Class Initialized
INFO - 2016-05-21 12:43:59 --> Output Class Initialized
INFO - 2016-05-21 12:43:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:43:59 --> Input Class Initialized
INFO - 2016-05-21 12:43:59 --> Language Class Initialized
INFO - 2016-05-21 12:43:59 --> Loader Class Initialized
INFO - 2016-05-21 12:43:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:43:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:43:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:43:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:43:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:43:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:43:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:43:59 --> Controller Class Initialized
INFO - 2016-05-21 12:43:59 --> Model Class Initialized
INFO - 2016-05-21 12:43:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:43:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:43:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:43:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:43:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:43:59 --> Total execution time: 0.0752
INFO - 2016-05-21 12:44:17 --> Config Class Initialized
INFO - 2016-05-21 12:44:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:44:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:44:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:44:17 --> URI Class Initialized
INFO - 2016-05-21 12:44:17 --> Router Class Initialized
INFO - 2016-05-21 12:44:17 --> Output Class Initialized
INFO - 2016-05-21 12:44:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:44:17 --> Input Class Initialized
INFO - 2016-05-21 12:44:17 --> Language Class Initialized
INFO - 2016-05-21 12:44:17 --> Loader Class Initialized
INFO - 2016-05-21 12:44:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:44:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:44:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:44:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:44:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:44:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:44:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:44:17 --> Controller Class Initialized
INFO - 2016-05-21 12:44:17 --> Model Class Initialized
INFO - 2016-05-21 12:44:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:44:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:44:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:44:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:44:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:44:17 --> Total execution time: 0.0758
INFO - 2016-05-21 12:44:59 --> Config Class Initialized
INFO - 2016-05-21 12:44:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:44:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:44:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:44:59 --> URI Class Initialized
INFO - 2016-05-21 12:44:59 --> Router Class Initialized
INFO - 2016-05-21 12:44:59 --> Output Class Initialized
INFO - 2016-05-21 12:44:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:44:59 --> Input Class Initialized
INFO - 2016-05-21 12:44:59 --> Language Class Initialized
INFO - 2016-05-21 12:44:59 --> Loader Class Initialized
INFO - 2016-05-21 12:44:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:44:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:44:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:44:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:44:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:44:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:44:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:44:59 --> Controller Class Initialized
INFO - 2016-05-21 12:44:59 --> Model Class Initialized
INFO - 2016-05-21 12:44:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:44:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:44:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:44:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:44:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:44:59 --> Total execution time: 0.0728
INFO - 2016-05-21 12:45:17 --> Config Class Initialized
INFO - 2016-05-21 12:45:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:45:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:45:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:45:17 --> URI Class Initialized
INFO - 2016-05-21 12:45:17 --> Router Class Initialized
INFO - 2016-05-21 12:45:17 --> Output Class Initialized
INFO - 2016-05-21 12:45:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:45:17 --> Input Class Initialized
INFO - 2016-05-21 12:45:17 --> Language Class Initialized
INFO - 2016-05-21 12:45:17 --> Loader Class Initialized
INFO - 2016-05-21 12:45:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:45:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:45:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:45:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:45:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:45:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:45:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:45:17 --> Controller Class Initialized
INFO - 2016-05-21 12:45:17 --> Model Class Initialized
INFO - 2016-05-21 12:45:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:45:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:45:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:45:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:45:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:45:17 --> Total execution time: 0.1185
INFO - 2016-05-21 12:45:59 --> Config Class Initialized
INFO - 2016-05-21 12:45:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:45:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:45:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:45:59 --> URI Class Initialized
INFO - 2016-05-21 12:45:59 --> Router Class Initialized
INFO - 2016-05-21 12:45:59 --> Output Class Initialized
INFO - 2016-05-21 12:45:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:45:59 --> Input Class Initialized
INFO - 2016-05-21 12:45:59 --> Language Class Initialized
INFO - 2016-05-21 12:45:59 --> Loader Class Initialized
INFO - 2016-05-21 12:45:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:45:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:45:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:45:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:45:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:45:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:45:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:45:59 --> Controller Class Initialized
INFO - 2016-05-21 12:45:59 --> Model Class Initialized
INFO - 2016-05-21 12:45:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:45:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:45:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:45:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:45:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:45:59 --> Total execution time: 0.0859
INFO - 2016-05-21 12:46:17 --> Config Class Initialized
INFO - 2016-05-21 12:46:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:46:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:46:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:46:17 --> URI Class Initialized
INFO - 2016-05-21 12:46:17 --> Router Class Initialized
INFO - 2016-05-21 12:46:17 --> Output Class Initialized
INFO - 2016-05-21 12:46:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:46:17 --> Input Class Initialized
INFO - 2016-05-21 12:46:17 --> Language Class Initialized
INFO - 2016-05-21 12:46:17 --> Loader Class Initialized
INFO - 2016-05-21 12:46:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:46:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:46:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:46:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:46:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:46:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:46:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:46:17 --> Controller Class Initialized
INFO - 2016-05-21 12:46:17 --> Model Class Initialized
INFO - 2016-05-21 12:46:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:46:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:46:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:46:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:46:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:46:17 --> Total execution time: 0.0792
INFO - 2016-05-21 12:46:59 --> Config Class Initialized
INFO - 2016-05-21 12:46:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:46:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:46:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:46:59 --> URI Class Initialized
INFO - 2016-05-21 12:46:59 --> Router Class Initialized
INFO - 2016-05-21 12:46:59 --> Output Class Initialized
INFO - 2016-05-21 12:46:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:46:59 --> Input Class Initialized
INFO - 2016-05-21 12:46:59 --> Language Class Initialized
INFO - 2016-05-21 12:46:59 --> Loader Class Initialized
INFO - 2016-05-21 12:46:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:46:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:46:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:46:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:46:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:46:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:46:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:46:59 --> Controller Class Initialized
INFO - 2016-05-21 12:46:59 --> Model Class Initialized
INFO - 2016-05-21 12:46:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:46:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:46:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:46:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:46:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:46:59 --> Total execution time: 0.0728
INFO - 2016-05-21 12:47:17 --> Config Class Initialized
INFO - 2016-05-21 12:47:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:47:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:47:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:47:17 --> URI Class Initialized
INFO - 2016-05-21 12:47:17 --> Router Class Initialized
INFO - 2016-05-21 12:47:17 --> Output Class Initialized
INFO - 2016-05-21 12:47:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:47:17 --> Input Class Initialized
INFO - 2016-05-21 12:47:17 --> Language Class Initialized
INFO - 2016-05-21 12:47:17 --> Loader Class Initialized
INFO - 2016-05-21 12:47:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:47:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:47:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:47:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:47:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:47:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:47:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:47:17 --> Controller Class Initialized
INFO - 2016-05-21 12:47:17 --> Model Class Initialized
INFO - 2016-05-21 12:47:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:47:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:47:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:47:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:47:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:47:17 --> Total execution time: 0.0746
INFO - 2016-05-21 12:47:59 --> Config Class Initialized
INFO - 2016-05-21 12:47:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:47:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:47:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:47:59 --> URI Class Initialized
INFO - 2016-05-21 12:47:59 --> Router Class Initialized
INFO - 2016-05-21 12:47:59 --> Output Class Initialized
INFO - 2016-05-21 12:47:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:47:59 --> Input Class Initialized
INFO - 2016-05-21 12:47:59 --> Language Class Initialized
INFO - 2016-05-21 12:47:59 --> Loader Class Initialized
INFO - 2016-05-21 12:47:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:47:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:47:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:47:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:47:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:47:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:47:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:47:59 --> Controller Class Initialized
INFO - 2016-05-21 12:47:59 --> Model Class Initialized
INFO - 2016-05-21 12:47:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:47:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:47:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:47:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:47:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:47:59 --> Total execution time: 0.0785
INFO - 2016-05-21 12:48:17 --> Config Class Initialized
INFO - 2016-05-21 12:48:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:48:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:48:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:48:17 --> URI Class Initialized
INFO - 2016-05-21 12:48:17 --> Router Class Initialized
INFO - 2016-05-21 12:48:17 --> Output Class Initialized
INFO - 2016-05-21 12:48:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:48:17 --> Input Class Initialized
INFO - 2016-05-21 12:48:17 --> Language Class Initialized
INFO - 2016-05-21 12:48:17 --> Loader Class Initialized
INFO - 2016-05-21 12:48:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:48:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:48:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:48:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:48:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:48:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:48:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:48:17 --> Controller Class Initialized
INFO - 2016-05-21 12:48:17 --> Model Class Initialized
INFO - 2016-05-21 12:48:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:48:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:48:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:48:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:48:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:48:17 --> Total execution time: 0.0760
INFO - 2016-05-21 12:48:59 --> Config Class Initialized
INFO - 2016-05-21 12:48:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:48:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:48:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:48:59 --> URI Class Initialized
INFO - 2016-05-21 12:48:59 --> Router Class Initialized
INFO - 2016-05-21 12:48:59 --> Output Class Initialized
INFO - 2016-05-21 12:48:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:48:59 --> Input Class Initialized
INFO - 2016-05-21 12:48:59 --> Language Class Initialized
INFO - 2016-05-21 12:48:59 --> Loader Class Initialized
INFO - 2016-05-21 12:48:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:48:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:48:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:48:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:48:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:48:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:48:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:48:59 --> Controller Class Initialized
INFO - 2016-05-21 12:48:59 --> Model Class Initialized
INFO - 2016-05-21 12:48:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:48:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:48:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:48:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:48:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:48:59 --> Total execution time: 0.0736
INFO - 2016-05-21 12:49:17 --> Config Class Initialized
INFO - 2016-05-21 12:49:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:49:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:49:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:49:17 --> URI Class Initialized
INFO - 2016-05-21 12:49:17 --> Router Class Initialized
INFO - 2016-05-21 12:49:17 --> Output Class Initialized
INFO - 2016-05-21 12:49:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:49:17 --> Input Class Initialized
INFO - 2016-05-21 12:49:17 --> Language Class Initialized
INFO - 2016-05-21 12:49:17 --> Loader Class Initialized
INFO - 2016-05-21 12:49:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:49:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:49:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:49:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:49:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:49:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:49:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:49:17 --> Controller Class Initialized
INFO - 2016-05-21 12:49:17 --> Model Class Initialized
INFO - 2016-05-21 12:49:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:49:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:49:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:49:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:49:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:49:17 --> Total execution time: 0.0878
INFO - 2016-05-21 12:49:54 --> Config Class Initialized
INFO - 2016-05-21 12:49:54 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:49:54 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:49:54 --> Utf8 Class Initialized
INFO - 2016-05-21 12:49:54 --> URI Class Initialized
INFO - 2016-05-21 12:49:54 --> Router Class Initialized
INFO - 2016-05-21 12:49:54 --> Output Class Initialized
INFO - 2016-05-21 12:49:54 --> Security Class Initialized
DEBUG - 2016-05-21 12:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:49:54 --> Input Class Initialized
INFO - 2016-05-21 12:49:54 --> Language Class Initialized
INFO - 2016-05-21 12:49:54 --> Loader Class Initialized
INFO - 2016-05-21 12:49:54 --> Helper loaded: url_helper
INFO - 2016-05-21 12:49:54 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:49:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:49:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:49:54 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:49:54 --> Helper loaded: form_helper
INFO - 2016-05-21 12:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:49:54 --> Form Validation Class Initialized
INFO - 2016-05-21 12:49:54 --> Controller Class Initialized
INFO - 2016-05-21 12:49:54 --> Model Class Initialized
INFO - 2016-05-21 12:49:54 --> Database Driver Class Initialized
INFO - 2016-05-21 12:49:54 --> Final output sent to browser
DEBUG - 2016-05-21 12:49:54 --> Total execution time: 0.1529
INFO - 2016-05-21 12:49:57 --> Config Class Initialized
INFO - 2016-05-21 12:49:57 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:49:57 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:49:57 --> Utf8 Class Initialized
INFO - 2016-05-21 12:49:57 --> URI Class Initialized
INFO - 2016-05-21 12:49:57 --> Router Class Initialized
INFO - 2016-05-21 12:49:57 --> Output Class Initialized
INFO - 2016-05-21 12:49:57 --> Security Class Initialized
DEBUG - 2016-05-21 12:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:49:57 --> Input Class Initialized
INFO - 2016-05-21 12:49:57 --> Language Class Initialized
INFO - 2016-05-21 12:49:57 --> Loader Class Initialized
INFO - 2016-05-21 12:49:57 --> Helper loaded: url_helper
INFO - 2016-05-21 12:49:57 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:49:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:49:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:49:58 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:49:58 --> Helper loaded: form_helper
INFO - 2016-05-21 12:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:49:58 --> Form Validation Class Initialized
INFO - 2016-05-21 12:49:58 --> Controller Class Initialized
INFO - 2016-05-21 12:49:58 --> Model Class Initialized
INFO - 2016-05-21 12:49:58 --> Database Driver Class Initialized
INFO - 2016-05-21 12:49:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:49:58 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:49:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:49:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:49:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:49:58 --> Final output sent to browser
DEBUG - 2016-05-21 12:49:58 --> Total execution time: 0.0819
INFO - 2016-05-21 12:49:58 --> Config Class Initialized
INFO - 2016-05-21 12:49:58 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:49:58 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:49:58 --> Utf8 Class Initialized
INFO - 2016-05-21 12:49:58 --> URI Class Initialized
INFO - 2016-05-21 12:49:58 --> Router Class Initialized
INFO - 2016-05-21 12:49:58 --> Output Class Initialized
INFO - 2016-05-21 12:49:58 --> Security Class Initialized
DEBUG - 2016-05-21 12:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:49:58 --> Input Class Initialized
INFO - 2016-05-21 12:49:58 --> Language Class Initialized
INFO - 2016-05-21 12:49:58 --> Loader Class Initialized
INFO - 2016-05-21 12:49:58 --> Helper loaded: url_helper
INFO - 2016-05-21 12:49:58 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:49:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:49:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:49:58 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:49:58 --> Helper loaded: form_helper
INFO - 2016-05-21 12:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:49:58 --> Form Validation Class Initialized
INFO - 2016-05-21 12:49:58 --> Controller Class Initialized
INFO - 2016-05-21 12:49:58 --> Model Class Initialized
INFO - 2016-05-21 12:49:58 --> Database Driver Class Initialized
INFO - 2016-05-21 12:49:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:49:58 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:49:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:49:58 --> Final output sent to browser
DEBUG - 2016-05-21 12:49:58 --> Total execution time: 0.0822
INFO - 2016-05-21 12:49:59 --> Config Class Initialized
INFO - 2016-05-21 12:49:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:49:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:49:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:49:59 --> URI Class Initialized
INFO - 2016-05-21 12:49:59 --> Router Class Initialized
INFO - 2016-05-21 12:49:59 --> Output Class Initialized
INFO - 2016-05-21 12:49:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:49:59 --> Input Class Initialized
INFO - 2016-05-21 12:49:59 --> Language Class Initialized
INFO - 2016-05-21 12:49:59 --> Loader Class Initialized
INFO - 2016-05-21 12:49:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:49:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:49:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:49:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:49:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:49:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:49:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:49:59 --> Controller Class Initialized
INFO - 2016-05-21 12:49:59 --> Model Class Initialized
INFO - 2016-05-21 12:49:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:49:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:49:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:49:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:49:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:49:59 --> Total execution time: 0.0961
INFO - 2016-05-21 12:50:02 --> Config Class Initialized
INFO - 2016-05-21 12:50:02 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:50:02 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:50:02 --> Utf8 Class Initialized
INFO - 2016-05-21 12:50:02 --> URI Class Initialized
INFO - 2016-05-21 12:50:02 --> Router Class Initialized
INFO - 2016-05-21 12:50:02 --> Output Class Initialized
INFO - 2016-05-21 12:50:02 --> Security Class Initialized
DEBUG - 2016-05-21 12:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:50:02 --> Input Class Initialized
INFO - 2016-05-21 12:50:02 --> Language Class Initialized
INFO - 2016-05-21 12:50:02 --> Loader Class Initialized
INFO - 2016-05-21 12:50:02 --> Helper loaded: url_helper
INFO - 2016-05-21 12:50:02 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:50:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:50:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:50:02 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:50:02 --> Helper loaded: form_helper
INFO - 2016-05-21 12:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:50:02 --> Form Validation Class Initialized
INFO - 2016-05-21 12:50:02 --> Controller Class Initialized
INFO - 2016-05-21 12:50:02 --> Model Class Initialized
INFO - 2016-05-21 12:50:02 --> Database Driver Class Initialized
INFO - 2016-05-21 12:50:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:50:02 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:50:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:50:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:50:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:50:02 --> Final output sent to browser
DEBUG - 2016-05-21 12:50:02 --> Total execution time: 0.1317
INFO - 2016-05-21 12:50:02 --> Config Class Initialized
INFO - 2016-05-21 12:50:02 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:50:02 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:50:02 --> Utf8 Class Initialized
INFO - 2016-05-21 12:50:02 --> URI Class Initialized
INFO - 2016-05-21 12:50:02 --> Router Class Initialized
INFO - 2016-05-21 12:50:02 --> Output Class Initialized
INFO - 2016-05-21 12:50:02 --> Security Class Initialized
DEBUG - 2016-05-21 12:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:50:02 --> Input Class Initialized
INFO - 2016-05-21 12:50:02 --> Language Class Initialized
INFO - 2016-05-21 12:50:02 --> Loader Class Initialized
INFO - 2016-05-21 12:50:02 --> Helper loaded: url_helper
INFO - 2016-05-21 12:50:02 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:50:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:50:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:50:02 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:50:02 --> Helper loaded: form_helper
INFO - 2016-05-21 12:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:50:02 --> Form Validation Class Initialized
INFO - 2016-05-21 12:50:02 --> Controller Class Initialized
INFO - 2016-05-21 12:50:02 --> Model Class Initialized
INFO - 2016-05-21 12:50:02 --> Database Driver Class Initialized
INFO - 2016-05-21 12:50:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:50:02 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:50:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:50:02 --> Final output sent to browser
DEBUG - 2016-05-21 12:50:02 --> Total execution time: 0.0980
INFO - 2016-05-21 12:50:07 --> Config Class Initialized
INFO - 2016-05-21 12:50:07 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:50:07 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:50:07 --> Utf8 Class Initialized
INFO - 2016-05-21 12:50:07 --> URI Class Initialized
INFO - 2016-05-21 12:50:07 --> Router Class Initialized
INFO - 2016-05-21 12:50:07 --> Output Class Initialized
INFO - 2016-05-21 12:50:07 --> Security Class Initialized
DEBUG - 2016-05-21 12:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:50:07 --> Input Class Initialized
INFO - 2016-05-21 12:50:07 --> Language Class Initialized
INFO - 2016-05-21 12:50:07 --> Loader Class Initialized
INFO - 2016-05-21 12:50:07 --> Helper loaded: url_helper
INFO - 2016-05-21 12:50:07 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:50:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:50:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:50:07 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:50:07 --> Helper loaded: form_helper
INFO - 2016-05-21 12:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:50:07 --> Form Validation Class Initialized
INFO - 2016-05-21 12:50:07 --> Controller Class Initialized
INFO - 2016-05-21 12:50:07 --> Model Class Initialized
INFO - 2016-05-21 12:50:07 --> Database Driver Class Initialized
INFO - 2016-05-21 12:50:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:50:07 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:50:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:50:07 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:50:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:50:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:50:07 --> Final output sent to browser
DEBUG - 2016-05-21 12:50:07 --> Total execution time: 0.1187
INFO - 2016-05-21 12:50:07 --> Config Class Initialized
INFO - 2016-05-21 12:50:07 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:50:07 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:50:07 --> Utf8 Class Initialized
INFO - 2016-05-21 12:50:07 --> URI Class Initialized
INFO - 2016-05-21 12:50:07 --> Router Class Initialized
INFO - 2016-05-21 12:50:07 --> Output Class Initialized
INFO - 2016-05-21 12:50:07 --> Security Class Initialized
DEBUG - 2016-05-21 12:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:50:07 --> Input Class Initialized
INFO - 2016-05-21 12:50:07 --> Language Class Initialized
INFO - 2016-05-21 12:50:07 --> Loader Class Initialized
INFO - 2016-05-21 12:50:07 --> Helper loaded: url_helper
INFO - 2016-05-21 12:50:07 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:50:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:50:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:50:07 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:50:07 --> Helper loaded: form_helper
INFO - 2016-05-21 12:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:50:07 --> Form Validation Class Initialized
INFO - 2016-05-21 12:50:07 --> Controller Class Initialized
INFO - 2016-05-21 12:50:07 --> Model Class Initialized
INFO - 2016-05-21 12:50:07 --> Database Driver Class Initialized
INFO - 2016-05-21 12:50:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:50:07 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:50:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:50:07 --> Final output sent to browser
DEBUG - 2016-05-21 12:50:07 --> Total execution time: 0.1035
INFO - 2016-05-21 12:50:10 --> Config Class Initialized
INFO - 2016-05-21 12:50:10 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:50:10 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:50:10 --> Utf8 Class Initialized
INFO - 2016-05-21 12:50:10 --> URI Class Initialized
INFO - 2016-05-21 12:50:10 --> Router Class Initialized
INFO - 2016-05-21 12:50:10 --> Output Class Initialized
INFO - 2016-05-21 12:50:10 --> Security Class Initialized
DEBUG - 2016-05-21 12:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:50:10 --> Input Class Initialized
INFO - 2016-05-21 12:50:10 --> Language Class Initialized
INFO - 2016-05-21 12:50:10 --> Loader Class Initialized
INFO - 2016-05-21 12:50:10 --> Helper loaded: url_helper
INFO - 2016-05-21 12:50:10 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:50:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:50:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:50:10 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:50:10 --> Helper loaded: form_helper
INFO - 2016-05-21 12:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:50:10 --> Form Validation Class Initialized
INFO - 2016-05-21 12:50:10 --> Controller Class Initialized
INFO - 2016-05-21 12:50:10 --> Model Class Initialized
INFO - 2016-05-21 12:50:10 --> Database Driver Class Initialized
INFO - 2016-05-21 12:50:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:50:10 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:50:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:50:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:50:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:50:10 --> Final output sent to browser
DEBUG - 2016-05-21 12:50:10 --> Total execution time: 0.0881
INFO - 2016-05-21 12:50:10 --> Config Class Initialized
INFO - 2016-05-21 12:50:10 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:50:10 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:50:10 --> Utf8 Class Initialized
INFO - 2016-05-21 12:50:10 --> URI Class Initialized
INFO - 2016-05-21 12:50:10 --> Router Class Initialized
INFO - 2016-05-21 12:50:10 --> Output Class Initialized
INFO - 2016-05-21 12:50:10 --> Security Class Initialized
DEBUG - 2016-05-21 12:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:50:10 --> Input Class Initialized
INFO - 2016-05-21 12:50:10 --> Language Class Initialized
INFO - 2016-05-21 12:50:10 --> Loader Class Initialized
INFO - 2016-05-21 12:50:10 --> Helper loaded: url_helper
INFO - 2016-05-21 12:50:10 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:50:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:50:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:50:10 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:50:10 --> Helper loaded: form_helper
INFO - 2016-05-21 12:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:50:10 --> Form Validation Class Initialized
INFO - 2016-05-21 12:50:10 --> Controller Class Initialized
INFO - 2016-05-21 12:50:10 --> Model Class Initialized
INFO - 2016-05-21 12:50:10 --> Database Driver Class Initialized
INFO - 2016-05-21 12:50:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:50:10 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:50:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:50:10 --> Final output sent to browser
DEBUG - 2016-05-21 12:50:10 --> Total execution time: 0.0868
INFO - 2016-05-21 12:50:13 --> Config Class Initialized
INFO - 2016-05-21 12:50:13 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:50:13 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:50:13 --> Utf8 Class Initialized
INFO - 2016-05-21 12:50:13 --> URI Class Initialized
INFO - 2016-05-21 12:50:13 --> Router Class Initialized
INFO - 2016-05-21 12:50:13 --> Output Class Initialized
INFO - 2016-05-21 12:50:13 --> Security Class Initialized
DEBUG - 2016-05-21 12:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:50:13 --> Input Class Initialized
INFO - 2016-05-21 12:50:13 --> Language Class Initialized
INFO - 2016-05-21 12:50:13 --> Loader Class Initialized
INFO - 2016-05-21 12:50:14 --> Helper loaded: url_helper
INFO - 2016-05-21 12:50:14 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:50:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:50:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:50:14 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:50:14 --> Helper loaded: form_helper
INFO - 2016-05-21 12:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:50:14 --> Form Validation Class Initialized
INFO - 2016-05-21 12:50:14 --> Controller Class Initialized
INFO - 2016-05-21 12:50:14 --> Model Class Initialized
INFO - 2016-05-21 12:50:14 --> Database Driver Class Initialized
INFO - 2016-05-21 12:50:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:50:14 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:50:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:50:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:50:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:50:14 --> Final output sent to browser
DEBUG - 2016-05-21 12:50:14 --> Total execution time: 0.0923
INFO - 2016-05-21 12:50:14 --> Config Class Initialized
INFO - 2016-05-21 12:50:14 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:50:14 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:50:14 --> Utf8 Class Initialized
INFO - 2016-05-21 12:50:14 --> URI Class Initialized
INFO - 2016-05-21 12:50:14 --> Router Class Initialized
INFO - 2016-05-21 12:50:14 --> Output Class Initialized
INFO - 2016-05-21 12:50:14 --> Security Class Initialized
DEBUG - 2016-05-21 12:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:50:14 --> Input Class Initialized
INFO - 2016-05-21 12:50:14 --> Language Class Initialized
INFO - 2016-05-21 12:50:14 --> Loader Class Initialized
INFO - 2016-05-21 12:50:14 --> Helper loaded: url_helper
INFO - 2016-05-21 12:50:14 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:50:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:50:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:50:14 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:50:14 --> Helper loaded: form_helper
INFO - 2016-05-21 12:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:50:14 --> Form Validation Class Initialized
INFO - 2016-05-21 12:50:14 --> Controller Class Initialized
INFO - 2016-05-21 12:50:14 --> Model Class Initialized
INFO - 2016-05-21 12:50:14 --> Database Driver Class Initialized
INFO - 2016-05-21 12:50:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:50:14 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:50:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:50:14 --> Final output sent to browser
DEBUG - 2016-05-21 12:50:14 --> Total execution time: 0.1040
INFO - 2016-05-21 12:50:21 --> Config Class Initialized
INFO - 2016-05-21 12:50:21 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:50:21 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:50:21 --> Utf8 Class Initialized
INFO - 2016-05-21 12:50:21 --> URI Class Initialized
INFO - 2016-05-21 12:50:21 --> Router Class Initialized
INFO - 2016-05-21 12:50:21 --> Output Class Initialized
INFO - 2016-05-21 12:50:21 --> Security Class Initialized
DEBUG - 2016-05-21 12:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:50:21 --> Input Class Initialized
INFO - 2016-05-21 12:50:21 --> Language Class Initialized
INFO - 2016-05-21 12:50:21 --> Loader Class Initialized
INFO - 2016-05-21 12:50:21 --> Helper loaded: url_helper
INFO - 2016-05-21 12:50:21 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:50:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:50:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:50:21 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:50:21 --> Helper loaded: form_helper
INFO - 2016-05-21 12:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:50:21 --> Form Validation Class Initialized
INFO - 2016-05-21 12:50:21 --> Controller Class Initialized
INFO - 2016-05-21 12:50:21 --> Model Class Initialized
INFO - 2016-05-21 12:50:21 --> Database Driver Class Initialized
INFO - 2016-05-21 12:50:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:50:21 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:50:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:50:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:50:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:50:21 --> Final output sent to browser
DEBUG - 2016-05-21 12:50:21 --> Total execution time: 0.0812
INFO - 2016-05-21 12:50:21 --> Config Class Initialized
INFO - 2016-05-21 12:50:21 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:50:21 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:50:21 --> Utf8 Class Initialized
INFO - 2016-05-21 12:50:21 --> URI Class Initialized
INFO - 2016-05-21 12:50:21 --> Router Class Initialized
INFO - 2016-05-21 12:50:21 --> Output Class Initialized
INFO - 2016-05-21 12:50:21 --> Security Class Initialized
DEBUG - 2016-05-21 12:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:50:21 --> Input Class Initialized
INFO - 2016-05-21 12:50:21 --> Language Class Initialized
INFO - 2016-05-21 12:50:21 --> Loader Class Initialized
INFO - 2016-05-21 12:50:21 --> Helper loaded: url_helper
INFO - 2016-05-21 12:50:21 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:50:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:50:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:50:21 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:50:21 --> Helper loaded: form_helper
INFO - 2016-05-21 12:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:50:21 --> Form Validation Class Initialized
INFO - 2016-05-21 12:50:21 --> Controller Class Initialized
INFO - 2016-05-21 12:50:21 --> Model Class Initialized
INFO - 2016-05-21 12:50:21 --> Database Driver Class Initialized
INFO - 2016-05-21 12:50:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:50:21 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:50:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:50:21 --> Final output sent to browser
DEBUG - 2016-05-21 12:50:21 --> Total execution time: 0.0927
INFO - 2016-05-21 12:50:23 --> Config Class Initialized
INFO - 2016-05-21 12:50:23 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:50:23 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:50:23 --> Utf8 Class Initialized
INFO - 2016-05-21 12:50:23 --> URI Class Initialized
INFO - 2016-05-21 12:50:23 --> Router Class Initialized
INFO - 2016-05-21 12:50:23 --> Output Class Initialized
INFO - 2016-05-21 12:50:23 --> Security Class Initialized
DEBUG - 2016-05-21 12:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:50:23 --> Input Class Initialized
INFO - 2016-05-21 12:50:23 --> Language Class Initialized
INFO - 2016-05-21 12:50:23 --> Loader Class Initialized
INFO - 2016-05-21 12:50:23 --> Helper loaded: url_helper
INFO - 2016-05-21 12:50:23 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:50:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:50:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:50:23 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:50:23 --> Helper loaded: form_helper
INFO - 2016-05-21 12:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:50:23 --> Form Validation Class Initialized
INFO - 2016-05-21 12:50:23 --> Controller Class Initialized
INFO - 2016-05-21 12:50:23 --> Model Class Initialized
INFO - 2016-05-21 12:50:23 --> Database Driver Class Initialized
INFO - 2016-05-21 12:50:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:50:23 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:50:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:50:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:50:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:50:23 --> Final output sent to browser
DEBUG - 2016-05-21 12:50:23 --> Total execution time: 0.0817
INFO - 2016-05-21 12:50:23 --> Config Class Initialized
INFO - 2016-05-21 12:50:23 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:50:23 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:50:23 --> Utf8 Class Initialized
INFO - 2016-05-21 12:50:23 --> URI Class Initialized
INFO - 2016-05-21 12:50:23 --> Router Class Initialized
INFO - 2016-05-21 12:50:23 --> Output Class Initialized
INFO - 2016-05-21 12:50:23 --> Security Class Initialized
DEBUG - 2016-05-21 12:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:50:23 --> Input Class Initialized
INFO - 2016-05-21 12:50:23 --> Language Class Initialized
INFO - 2016-05-21 12:50:23 --> Loader Class Initialized
INFO - 2016-05-21 12:50:23 --> Helper loaded: url_helper
INFO - 2016-05-21 12:50:23 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:50:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:50:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:50:23 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:50:23 --> Helper loaded: form_helper
INFO - 2016-05-21 12:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:50:23 --> Form Validation Class Initialized
INFO - 2016-05-21 12:50:23 --> Controller Class Initialized
INFO - 2016-05-21 12:50:23 --> Model Class Initialized
INFO - 2016-05-21 12:50:23 --> Database Driver Class Initialized
INFO - 2016-05-21 12:50:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:50:23 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:50:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:50:23 --> Final output sent to browser
DEBUG - 2016-05-21 12:50:23 --> Total execution time: 0.0897
INFO - 2016-05-21 12:50:27 --> Config Class Initialized
INFO - 2016-05-21 12:50:27 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:50:27 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:50:27 --> Utf8 Class Initialized
INFO - 2016-05-21 12:50:27 --> URI Class Initialized
INFO - 2016-05-21 12:50:27 --> Router Class Initialized
INFO - 2016-05-21 12:50:27 --> Output Class Initialized
INFO - 2016-05-21 12:50:27 --> Security Class Initialized
DEBUG - 2016-05-21 12:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:50:27 --> Input Class Initialized
INFO - 2016-05-21 12:50:27 --> Language Class Initialized
INFO - 2016-05-21 12:50:27 --> Loader Class Initialized
INFO - 2016-05-21 12:50:27 --> Helper loaded: url_helper
INFO - 2016-05-21 12:50:27 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:50:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:50:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:50:27 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:50:27 --> Helper loaded: form_helper
INFO - 2016-05-21 12:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:50:27 --> Form Validation Class Initialized
INFO - 2016-05-21 12:50:27 --> Controller Class Initialized
INFO - 2016-05-21 12:50:27 --> Model Class Initialized
INFO - 2016-05-21 12:50:27 --> Database Driver Class Initialized
INFO - 2016-05-21 12:50:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:50:27 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:50:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:50:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:50:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:50:27 --> Final output sent to browser
DEBUG - 2016-05-21 12:50:27 --> Total execution time: 0.0963
INFO - 2016-05-21 12:50:27 --> Config Class Initialized
INFO - 2016-05-21 12:50:27 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:50:27 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:50:27 --> Utf8 Class Initialized
INFO - 2016-05-21 12:50:27 --> URI Class Initialized
INFO - 2016-05-21 12:50:27 --> Router Class Initialized
INFO - 2016-05-21 12:50:27 --> Output Class Initialized
INFO - 2016-05-21 12:50:27 --> Security Class Initialized
DEBUG - 2016-05-21 12:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:50:27 --> Input Class Initialized
INFO - 2016-05-21 12:50:27 --> Language Class Initialized
INFO - 2016-05-21 12:50:27 --> Loader Class Initialized
INFO - 2016-05-21 12:50:27 --> Helper loaded: url_helper
INFO - 2016-05-21 12:50:27 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:50:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:50:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:50:27 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:50:27 --> Helper loaded: form_helper
INFO - 2016-05-21 12:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:50:27 --> Form Validation Class Initialized
INFO - 2016-05-21 12:50:27 --> Controller Class Initialized
INFO - 2016-05-21 12:50:27 --> Model Class Initialized
INFO - 2016-05-21 12:50:27 --> Database Driver Class Initialized
INFO - 2016-05-21 12:50:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:50:27 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:50:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:50:27 --> Final output sent to browser
DEBUG - 2016-05-21 12:50:27 --> Total execution time: 0.1068
INFO - 2016-05-21 12:50:59 --> Config Class Initialized
INFO - 2016-05-21 12:50:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:50:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:50:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:50:59 --> URI Class Initialized
INFO - 2016-05-21 12:50:59 --> Router Class Initialized
INFO - 2016-05-21 12:50:59 --> Output Class Initialized
INFO - 2016-05-21 12:50:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:50:59 --> Input Class Initialized
INFO - 2016-05-21 12:50:59 --> Language Class Initialized
INFO - 2016-05-21 12:50:59 --> Loader Class Initialized
INFO - 2016-05-21 12:50:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:50:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:50:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:50:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:50:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:50:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:50:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:50:59 --> Controller Class Initialized
INFO - 2016-05-21 12:50:59 --> Model Class Initialized
INFO - 2016-05-21 12:50:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:50:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:50:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:50:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:50:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:50:59 --> Total execution time: 0.0890
INFO - 2016-05-21 12:51:27 --> Config Class Initialized
INFO - 2016-05-21 12:51:27 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:51:27 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:51:27 --> Utf8 Class Initialized
INFO - 2016-05-21 12:51:27 --> URI Class Initialized
INFO - 2016-05-21 12:51:27 --> Router Class Initialized
INFO - 2016-05-21 12:51:27 --> Output Class Initialized
INFO - 2016-05-21 12:51:27 --> Security Class Initialized
DEBUG - 2016-05-21 12:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:51:27 --> Input Class Initialized
INFO - 2016-05-21 12:51:27 --> Language Class Initialized
INFO - 2016-05-21 12:51:27 --> Loader Class Initialized
INFO - 2016-05-21 12:51:27 --> Helper loaded: url_helper
INFO - 2016-05-21 12:51:27 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:51:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:51:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:51:27 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:51:27 --> Helper loaded: form_helper
INFO - 2016-05-21 12:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:51:27 --> Form Validation Class Initialized
INFO - 2016-05-21 12:51:27 --> Controller Class Initialized
INFO - 2016-05-21 12:51:27 --> Model Class Initialized
INFO - 2016-05-21 12:51:27 --> Database Driver Class Initialized
INFO - 2016-05-21 12:51:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:51:27 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:51:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:51:27 --> Final output sent to browser
DEBUG - 2016-05-21 12:51:27 --> Total execution time: 0.0736
INFO - 2016-05-21 12:51:29 --> Config Class Initialized
INFO - 2016-05-21 12:51:29 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:51:29 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:51:29 --> Utf8 Class Initialized
INFO - 2016-05-21 12:51:29 --> URI Class Initialized
INFO - 2016-05-21 12:51:29 --> Router Class Initialized
INFO - 2016-05-21 12:51:29 --> Output Class Initialized
INFO - 2016-05-21 12:51:29 --> Security Class Initialized
DEBUG - 2016-05-21 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:51:29 --> Input Class Initialized
INFO - 2016-05-21 12:51:29 --> Language Class Initialized
INFO - 2016-05-21 12:51:29 --> Loader Class Initialized
INFO - 2016-05-21 12:51:29 --> Helper loaded: url_helper
INFO - 2016-05-21 12:51:29 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:51:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:51:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:51:29 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:51:29 --> Helper loaded: form_helper
INFO - 2016-05-21 12:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:51:29 --> Form Validation Class Initialized
INFO - 2016-05-21 12:51:29 --> Controller Class Initialized
INFO - 2016-05-21 12:51:29 --> Model Class Initialized
INFO - 2016-05-21 12:51:29 --> Database Driver Class Initialized
INFO - 2016-05-21 12:51:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:51:29 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:51:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:51:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:51:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:51:29 --> Final output sent to browser
DEBUG - 2016-05-21 12:51:29 --> Total execution time: 0.1272
INFO - 2016-05-21 12:51:29 --> Config Class Initialized
INFO - 2016-05-21 12:51:29 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:51:29 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:51:29 --> Utf8 Class Initialized
INFO - 2016-05-21 12:51:29 --> URI Class Initialized
INFO - 2016-05-21 12:51:29 --> Router Class Initialized
INFO - 2016-05-21 12:51:29 --> Output Class Initialized
INFO - 2016-05-21 12:51:29 --> Security Class Initialized
DEBUG - 2016-05-21 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:51:29 --> Input Class Initialized
INFO - 2016-05-21 12:51:29 --> Language Class Initialized
INFO - 2016-05-21 12:51:29 --> Loader Class Initialized
INFO - 2016-05-21 12:51:29 --> Helper loaded: url_helper
INFO - 2016-05-21 12:51:29 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:51:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:51:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:51:29 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:51:29 --> Helper loaded: form_helper
INFO - 2016-05-21 12:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:51:29 --> Form Validation Class Initialized
INFO - 2016-05-21 12:51:29 --> Controller Class Initialized
INFO - 2016-05-21 12:51:29 --> Model Class Initialized
INFO - 2016-05-21 12:51:29 --> Database Driver Class Initialized
INFO - 2016-05-21 12:51:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:51:29 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:51:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:51:29 --> Final output sent to browser
DEBUG - 2016-05-21 12:51:29 --> Total execution time: 0.1101
INFO - 2016-05-21 12:51:30 --> Config Class Initialized
INFO - 2016-05-21 12:51:30 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:51:30 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:51:30 --> Utf8 Class Initialized
INFO - 2016-05-21 12:51:30 --> URI Class Initialized
INFO - 2016-05-21 12:51:30 --> Router Class Initialized
INFO - 2016-05-21 12:51:30 --> Output Class Initialized
INFO - 2016-05-21 12:51:30 --> Security Class Initialized
DEBUG - 2016-05-21 12:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:51:30 --> Input Class Initialized
INFO - 2016-05-21 12:51:30 --> Language Class Initialized
INFO - 2016-05-21 12:51:30 --> Loader Class Initialized
INFO - 2016-05-21 12:51:30 --> Helper loaded: url_helper
INFO - 2016-05-21 12:51:30 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:51:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:51:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:51:30 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:51:30 --> Helper loaded: form_helper
INFO - 2016-05-21 12:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:51:30 --> Form Validation Class Initialized
INFO - 2016-05-21 12:51:30 --> Controller Class Initialized
INFO - 2016-05-21 12:51:30 --> Model Class Initialized
INFO - 2016-05-21 12:51:30 --> Database Driver Class Initialized
INFO - 2016-05-21 12:51:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:51:30 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:51:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:51:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:51:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:51:30 --> Final output sent to browser
DEBUG - 2016-05-21 12:51:30 --> Total execution time: 0.0937
INFO - 2016-05-21 12:51:31 --> Config Class Initialized
INFO - 2016-05-21 12:51:31 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:51:31 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:51:31 --> Utf8 Class Initialized
INFO - 2016-05-21 12:51:31 --> URI Class Initialized
INFO - 2016-05-21 12:51:31 --> Router Class Initialized
INFO - 2016-05-21 12:51:31 --> Output Class Initialized
INFO - 2016-05-21 12:51:31 --> Security Class Initialized
DEBUG - 2016-05-21 12:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:51:31 --> Input Class Initialized
INFO - 2016-05-21 12:51:31 --> Language Class Initialized
INFO - 2016-05-21 12:51:31 --> Loader Class Initialized
INFO - 2016-05-21 12:51:31 --> Helper loaded: url_helper
INFO - 2016-05-21 12:51:31 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:51:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:51:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:51:31 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:51:31 --> Helper loaded: form_helper
INFO - 2016-05-21 12:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:51:31 --> Form Validation Class Initialized
INFO - 2016-05-21 12:51:31 --> Controller Class Initialized
INFO - 2016-05-21 12:51:31 --> Model Class Initialized
INFO - 2016-05-21 12:51:31 --> Database Driver Class Initialized
INFO - 2016-05-21 12:51:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:51:31 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:51:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:51:31 --> Final output sent to browser
DEBUG - 2016-05-21 12:51:31 --> Total execution time: 0.1084
INFO - 2016-05-21 12:51:35 --> Config Class Initialized
INFO - 2016-05-21 12:51:35 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:51:35 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:51:35 --> Utf8 Class Initialized
INFO - 2016-05-21 12:51:35 --> URI Class Initialized
INFO - 2016-05-21 12:51:35 --> Router Class Initialized
INFO - 2016-05-21 12:51:35 --> Output Class Initialized
INFO - 2016-05-21 12:51:35 --> Security Class Initialized
DEBUG - 2016-05-21 12:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:51:35 --> Input Class Initialized
INFO - 2016-05-21 12:51:35 --> Language Class Initialized
INFO - 2016-05-21 12:51:35 --> Loader Class Initialized
INFO - 2016-05-21 12:51:35 --> Helper loaded: url_helper
INFO - 2016-05-21 12:51:35 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:51:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:51:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:51:35 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:51:35 --> Helper loaded: form_helper
INFO - 2016-05-21 12:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:51:35 --> Form Validation Class Initialized
INFO - 2016-05-21 12:51:35 --> Controller Class Initialized
INFO - 2016-05-21 12:51:35 --> Model Class Initialized
INFO - 2016-05-21 12:51:35 --> Database Driver Class Initialized
INFO - 2016-05-21 12:51:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:51:35 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:51:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:51:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:51:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:51:35 --> Final output sent to browser
DEBUG - 2016-05-21 12:51:35 --> Total execution time: 0.0919
INFO - 2016-05-21 12:51:35 --> Config Class Initialized
INFO - 2016-05-21 12:51:35 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:51:35 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:51:35 --> Utf8 Class Initialized
INFO - 2016-05-21 12:51:35 --> URI Class Initialized
INFO - 2016-05-21 12:51:35 --> Router Class Initialized
INFO - 2016-05-21 12:51:35 --> Output Class Initialized
INFO - 2016-05-21 12:51:35 --> Security Class Initialized
DEBUG - 2016-05-21 12:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:51:35 --> Input Class Initialized
INFO - 2016-05-21 12:51:35 --> Language Class Initialized
INFO - 2016-05-21 12:51:35 --> Loader Class Initialized
INFO - 2016-05-21 12:51:35 --> Helper loaded: url_helper
INFO - 2016-05-21 12:51:35 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:51:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:51:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:51:35 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:51:35 --> Helper loaded: form_helper
INFO - 2016-05-21 12:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:51:35 --> Form Validation Class Initialized
INFO - 2016-05-21 12:51:35 --> Controller Class Initialized
INFO - 2016-05-21 12:51:35 --> Model Class Initialized
INFO - 2016-05-21 12:51:35 --> Database Driver Class Initialized
INFO - 2016-05-21 12:51:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:51:35 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:51:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:51:35 --> Final output sent to browser
DEBUG - 2016-05-21 12:51:35 --> Total execution time: 0.1052
INFO - 2016-05-21 12:51:59 --> Config Class Initialized
INFO - 2016-05-21 12:51:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:51:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:51:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:51:59 --> URI Class Initialized
INFO - 2016-05-21 12:51:59 --> Router Class Initialized
INFO - 2016-05-21 12:51:59 --> Output Class Initialized
INFO - 2016-05-21 12:51:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:51:59 --> Input Class Initialized
INFO - 2016-05-21 12:51:59 --> Language Class Initialized
INFO - 2016-05-21 12:51:59 --> Loader Class Initialized
INFO - 2016-05-21 12:51:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:51:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:51:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:51:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:51:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:51:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:51:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:51:59 --> Controller Class Initialized
INFO - 2016-05-21 12:51:59 --> Model Class Initialized
INFO - 2016-05-21 12:51:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:51:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:51:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:51:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:51:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:51:59 --> Total execution time: 0.0836
INFO - 2016-05-21 12:52:09 --> Config Class Initialized
INFO - 2016-05-21 12:52:09 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:52:09 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:52:09 --> Utf8 Class Initialized
INFO - 2016-05-21 12:52:09 --> URI Class Initialized
INFO - 2016-05-21 12:52:09 --> Router Class Initialized
INFO - 2016-05-21 12:52:09 --> Output Class Initialized
INFO - 2016-05-21 12:52:09 --> Security Class Initialized
DEBUG - 2016-05-21 12:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:52:09 --> Input Class Initialized
INFO - 2016-05-21 12:52:09 --> Language Class Initialized
INFO - 2016-05-21 12:52:09 --> Loader Class Initialized
INFO - 2016-05-21 12:52:09 --> Helper loaded: url_helper
INFO - 2016-05-21 12:52:09 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:52:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:52:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:52:09 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:52:09 --> Helper loaded: form_helper
INFO - 2016-05-21 12:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:52:09 --> Form Validation Class Initialized
INFO - 2016-05-21 12:52:09 --> Controller Class Initialized
INFO - 2016-05-21 12:52:09 --> Model Class Initialized
INFO - 2016-05-21 12:52:09 --> Database Driver Class Initialized
INFO - 2016-05-21 12:52:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:52:09 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:52:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:52:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:52:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:52:09 --> Final output sent to browser
DEBUG - 2016-05-21 12:52:09 --> Total execution time: 0.0851
INFO - 2016-05-21 12:52:10 --> Config Class Initialized
INFO - 2016-05-21 12:52:10 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:52:10 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:52:10 --> Utf8 Class Initialized
INFO - 2016-05-21 12:52:10 --> URI Class Initialized
INFO - 2016-05-21 12:52:10 --> Router Class Initialized
INFO - 2016-05-21 12:52:10 --> Output Class Initialized
INFO - 2016-05-21 12:52:10 --> Security Class Initialized
DEBUG - 2016-05-21 12:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:52:10 --> Input Class Initialized
INFO - 2016-05-21 12:52:10 --> Language Class Initialized
INFO - 2016-05-21 12:52:10 --> Loader Class Initialized
INFO - 2016-05-21 12:52:10 --> Helper loaded: url_helper
INFO - 2016-05-21 12:52:10 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:52:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:52:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:52:10 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:52:10 --> Helper loaded: form_helper
INFO - 2016-05-21 12:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:52:10 --> Form Validation Class Initialized
INFO - 2016-05-21 12:52:10 --> Controller Class Initialized
INFO - 2016-05-21 12:52:10 --> Model Class Initialized
INFO - 2016-05-21 12:52:10 --> Database Driver Class Initialized
INFO - 2016-05-21 12:52:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:52:10 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:52:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:52:10 --> Final output sent to browser
DEBUG - 2016-05-21 12:52:10 --> Total execution time: 0.1145
INFO - 2016-05-21 12:52:59 --> Config Class Initialized
INFO - 2016-05-21 12:52:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:52:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:52:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:52:59 --> URI Class Initialized
INFO - 2016-05-21 12:52:59 --> Router Class Initialized
INFO - 2016-05-21 12:52:59 --> Config Class Initialized
INFO - 2016-05-21 12:52:59 --> Hooks Class Initialized
INFO - 2016-05-21 12:52:59 --> Output Class Initialized
INFO - 2016-05-21 12:52:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-21 12:52:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:52:59 --> Input Class Initialized
INFO - 2016-05-21 12:52:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:52:59 --> Language Class Initialized
INFO - 2016-05-21 12:52:59 --> URI Class Initialized
INFO - 2016-05-21 12:52:59 --> Router Class Initialized
INFO - 2016-05-21 12:52:59 --> Loader Class Initialized
INFO - 2016-05-21 12:52:59 --> Output Class Initialized
INFO - 2016-05-21 12:52:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:52:59 --> Security Class Initialized
INFO - 2016-05-21 12:52:59 --> Helper loaded: sesion_helper
DEBUG - 2016-05-21 12:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:52:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:52:59 --> Input Class Initialized
INFO - 2016-05-21 12:52:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:52:59 --> Language Class Initialized
INFO - 2016-05-21 12:52:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:52:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:52:59 --> Loader Class Initialized
INFO - 2016-05-21 12:52:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:52:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:52:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:52:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:52:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:52:59 --> Controller Class Initialized
INFO - 2016-05-21 12:52:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:52:59 --> Model Class Initialized
INFO - 2016-05-21 12:52:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:52:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:52:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:52:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:52:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:52:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:52:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:52:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:52:59 --> Total execution time: 0.1161
INFO - 2016-05-21 12:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:52:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:52:59 --> Controller Class Initialized
INFO - 2016-05-21 12:52:59 --> Model Class Initialized
INFO - 2016-05-21 12:52:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:52:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:52:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:52:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:52:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:52:59 --> Total execution time: 0.1492
INFO - 2016-05-21 12:53:00 --> Config Class Initialized
INFO - 2016-05-21 12:53:00 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:53:00 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:53:00 --> Utf8 Class Initialized
INFO - 2016-05-21 12:53:00 --> URI Class Initialized
INFO - 2016-05-21 12:53:00 --> Router Class Initialized
INFO - 2016-05-21 12:53:00 --> Output Class Initialized
INFO - 2016-05-21 12:53:00 --> Security Class Initialized
DEBUG - 2016-05-21 12:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:53:00 --> Input Class Initialized
INFO - 2016-05-21 12:53:00 --> Language Class Initialized
INFO - 2016-05-21 12:53:00 --> Loader Class Initialized
INFO - 2016-05-21 12:53:00 --> Helper loaded: url_helper
INFO - 2016-05-21 12:53:00 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:53:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:53:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:53:00 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:53:00 --> Helper loaded: form_helper
INFO - 2016-05-21 12:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:53:00 --> Form Validation Class Initialized
INFO - 2016-05-21 12:53:00 --> Controller Class Initialized
INFO - 2016-05-21 12:53:00 --> Model Class Initialized
INFO - 2016-05-21 12:53:00 --> Database Driver Class Initialized
INFO - 2016-05-21 12:53:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:53:00 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:53:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:53:00 --> Final output sent to browser
DEBUG - 2016-05-21 12:53:00 --> Total execution time: 0.1159
INFO - 2016-05-21 12:53:26 --> Config Class Initialized
INFO - 2016-05-21 12:53:26 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:53:26 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:53:26 --> Utf8 Class Initialized
INFO - 2016-05-21 12:53:26 --> URI Class Initialized
INFO - 2016-05-21 12:53:26 --> Router Class Initialized
INFO - 2016-05-21 12:53:26 --> Output Class Initialized
INFO - 2016-05-21 12:53:26 --> Security Class Initialized
DEBUG - 2016-05-21 12:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:53:26 --> Input Class Initialized
INFO - 2016-05-21 12:53:26 --> Language Class Initialized
INFO - 2016-05-21 12:53:26 --> Loader Class Initialized
INFO - 2016-05-21 12:53:26 --> Helper loaded: url_helper
INFO - 2016-05-21 12:53:26 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:53:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:53:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:53:26 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:53:26 --> Helper loaded: form_helper
INFO - 2016-05-21 12:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:53:26 --> Form Validation Class Initialized
INFO - 2016-05-21 12:53:26 --> Controller Class Initialized
INFO - 2016-05-21 12:53:26 --> Model Class Initialized
INFO - 2016-05-21 12:53:26 --> Database Driver Class Initialized
INFO - 2016-05-21 12:53:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:53:26 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:53:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:53:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:53:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:53:26 --> Final output sent to browser
DEBUG - 2016-05-21 12:53:26 --> Total execution time: 0.0787
INFO - 2016-05-21 12:53:26 --> Config Class Initialized
INFO - 2016-05-21 12:53:26 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:53:26 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:53:26 --> Utf8 Class Initialized
INFO - 2016-05-21 12:53:26 --> URI Class Initialized
INFO - 2016-05-21 12:53:27 --> Router Class Initialized
INFO - 2016-05-21 12:53:27 --> Output Class Initialized
INFO - 2016-05-21 12:53:27 --> Security Class Initialized
DEBUG - 2016-05-21 12:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:53:27 --> Input Class Initialized
INFO - 2016-05-21 12:53:27 --> Language Class Initialized
INFO - 2016-05-21 12:53:27 --> Loader Class Initialized
INFO - 2016-05-21 12:53:27 --> Helper loaded: url_helper
INFO - 2016-05-21 12:53:27 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:53:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:53:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:53:27 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:53:27 --> Helper loaded: form_helper
INFO - 2016-05-21 12:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:53:27 --> Form Validation Class Initialized
INFO - 2016-05-21 12:53:27 --> Controller Class Initialized
INFO - 2016-05-21 12:53:27 --> Model Class Initialized
INFO - 2016-05-21 12:53:27 --> Database Driver Class Initialized
INFO - 2016-05-21 12:53:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:53:27 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:53:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:53:27 --> Final output sent to browser
DEBUG - 2016-05-21 12:53:27 --> Total execution time: 0.0983
INFO - 2016-05-21 12:53:28 --> Config Class Initialized
INFO - 2016-05-21 12:53:28 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:53:28 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:53:28 --> Utf8 Class Initialized
INFO - 2016-05-21 12:53:28 --> URI Class Initialized
INFO - 2016-05-21 12:53:28 --> Router Class Initialized
INFO - 2016-05-21 12:53:28 --> Output Class Initialized
INFO - 2016-05-21 12:53:28 --> Security Class Initialized
DEBUG - 2016-05-21 12:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:53:28 --> Input Class Initialized
INFO - 2016-05-21 12:53:28 --> Language Class Initialized
INFO - 2016-05-21 12:53:28 --> Loader Class Initialized
INFO - 2016-05-21 12:53:28 --> Helper loaded: url_helper
INFO - 2016-05-21 12:53:28 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:53:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:53:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:53:28 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:53:28 --> Helper loaded: form_helper
INFO - 2016-05-21 12:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:53:28 --> Form Validation Class Initialized
INFO - 2016-05-21 12:53:28 --> Controller Class Initialized
INFO - 2016-05-21 12:53:28 --> Model Class Initialized
INFO - 2016-05-21 12:53:28 --> Database Driver Class Initialized
INFO - 2016-05-21 12:53:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:53:28 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:53:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:53:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:53:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:53:28 --> Final output sent to browser
DEBUG - 2016-05-21 12:53:28 --> Total execution time: 0.0980
INFO - 2016-05-21 12:53:28 --> Config Class Initialized
INFO - 2016-05-21 12:53:28 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:53:28 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:53:28 --> Utf8 Class Initialized
INFO - 2016-05-21 12:53:28 --> URI Class Initialized
INFO - 2016-05-21 12:53:28 --> Router Class Initialized
INFO - 2016-05-21 12:53:28 --> Output Class Initialized
INFO - 2016-05-21 12:53:28 --> Security Class Initialized
DEBUG - 2016-05-21 12:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:53:28 --> Input Class Initialized
INFO - 2016-05-21 12:53:28 --> Language Class Initialized
INFO - 2016-05-21 12:53:28 --> Loader Class Initialized
INFO - 2016-05-21 12:53:28 --> Helper loaded: url_helper
INFO - 2016-05-21 12:53:28 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:53:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:53:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:53:28 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:53:28 --> Helper loaded: form_helper
INFO - 2016-05-21 12:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:53:28 --> Form Validation Class Initialized
INFO - 2016-05-21 12:53:28 --> Controller Class Initialized
INFO - 2016-05-21 12:53:28 --> Model Class Initialized
INFO - 2016-05-21 12:53:28 --> Database Driver Class Initialized
INFO - 2016-05-21 12:53:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:53:28 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:53:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:53:28 --> Final output sent to browser
DEBUG - 2016-05-21 12:53:28 --> Total execution time: 0.1097
INFO - 2016-05-21 12:53:58 --> Config Class Initialized
INFO - 2016-05-21 12:53:58 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:53:58 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:53:58 --> Utf8 Class Initialized
INFO - 2016-05-21 12:53:58 --> URI Class Initialized
INFO - 2016-05-21 12:53:58 --> Router Class Initialized
INFO - 2016-05-21 12:53:58 --> Output Class Initialized
INFO - 2016-05-21 12:53:58 --> Security Class Initialized
DEBUG - 2016-05-21 12:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:53:58 --> Input Class Initialized
INFO - 2016-05-21 12:53:58 --> Language Class Initialized
INFO - 2016-05-21 12:53:58 --> Loader Class Initialized
INFO - 2016-05-21 12:53:58 --> Helper loaded: url_helper
INFO - 2016-05-21 12:53:58 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:53:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:53:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:53:58 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:53:58 --> Helper loaded: form_helper
INFO - 2016-05-21 12:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:53:58 --> Form Validation Class Initialized
INFO - 2016-05-21 12:53:58 --> Controller Class Initialized
INFO - 2016-05-21 12:53:58 --> Model Class Initialized
INFO - 2016-05-21 12:53:58 --> Database Driver Class Initialized
INFO - 2016-05-21 12:53:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:53:58 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:53:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:53:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:53:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:53:58 --> Final output sent to browser
DEBUG - 2016-05-21 12:53:58 --> Total execution time: 0.0988
INFO - 2016-05-21 12:53:59 --> Config Class Initialized
INFO - 2016-05-21 12:53:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:53:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:53:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:53:59 --> URI Class Initialized
INFO - 2016-05-21 12:53:59 --> Router Class Initialized
INFO - 2016-05-21 12:53:59 --> Output Class Initialized
INFO - 2016-05-21 12:53:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:53:59 --> Input Class Initialized
INFO - 2016-05-21 12:53:59 --> Language Class Initialized
INFO - 2016-05-21 12:53:59 --> Loader Class Initialized
INFO - 2016-05-21 12:53:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:53:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:53:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:53:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:53:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:53:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:53:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:53:59 --> Controller Class Initialized
INFO - 2016-05-21 12:53:59 --> Model Class Initialized
INFO - 2016-05-21 12:53:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:53:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:53:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:53:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:53:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:53:59 --> Total execution time: 0.1688
INFO - 2016-05-21 12:53:59 --> Config Class Initialized
INFO - 2016-05-21 12:53:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:53:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:53:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:53:59 --> URI Class Initialized
INFO - 2016-05-21 12:53:59 --> Router Class Initialized
INFO - 2016-05-21 12:53:59 --> Output Class Initialized
INFO - 2016-05-21 12:53:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:53:59 --> Input Class Initialized
INFO - 2016-05-21 12:53:59 --> Language Class Initialized
INFO - 2016-05-21 12:53:59 --> Loader Class Initialized
INFO - 2016-05-21 12:53:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:53:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:53:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:53:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:53:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:53:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:53:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:53:59 --> Controller Class Initialized
INFO - 2016-05-21 12:53:59 --> Model Class Initialized
INFO - 2016-05-21 12:53:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:53:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:53:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:53:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:53:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:53:59 --> Total execution time: 0.1072
INFO - 2016-05-21 12:54:59 --> Config Class Initialized
INFO - 2016-05-21 12:54:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:54:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:54:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:54:59 --> URI Class Initialized
INFO - 2016-05-21 12:54:59 --> Router Class Initialized
INFO - 2016-05-21 12:54:59 --> Output Class Initialized
INFO - 2016-05-21 12:54:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:54:59 --> Input Class Initialized
INFO - 2016-05-21 12:54:59 --> Language Class Initialized
INFO - 2016-05-21 12:54:59 --> Loader Class Initialized
INFO - 2016-05-21 12:54:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:54:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:54:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:54:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:54:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:54:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:54:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:54:59 --> Controller Class Initialized
INFO - 2016-05-21 12:54:59 --> Model Class Initialized
INFO - 2016-05-21 12:54:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:54:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:54:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:54:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:54:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:54:59 --> Total execution time: 0.0754
INFO - 2016-05-21 12:54:59 --> Config Class Initialized
INFO - 2016-05-21 12:54:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:54:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:54:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:54:59 --> URI Class Initialized
INFO - 2016-05-21 12:54:59 --> Router Class Initialized
INFO - 2016-05-21 12:54:59 --> Output Class Initialized
INFO - 2016-05-21 12:54:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:54:59 --> Input Class Initialized
INFO - 2016-05-21 12:54:59 --> Language Class Initialized
INFO - 2016-05-21 12:54:59 --> Loader Class Initialized
INFO - 2016-05-21 12:54:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:54:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:54:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:54:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:54:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:54:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:54:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:54:59 --> Controller Class Initialized
INFO - 2016-05-21 12:54:59 --> Model Class Initialized
INFO - 2016-05-21 12:54:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:54:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:54:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:54:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:54:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:54:59 --> Total execution time: 0.1088
INFO - 2016-05-21 12:55:01 --> Config Class Initialized
INFO - 2016-05-21 12:55:01 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:55:01 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:55:01 --> Utf8 Class Initialized
INFO - 2016-05-21 12:55:01 --> URI Class Initialized
INFO - 2016-05-21 12:55:01 --> Router Class Initialized
INFO - 2016-05-21 12:55:01 --> Output Class Initialized
INFO - 2016-05-21 12:55:01 --> Security Class Initialized
DEBUG - 2016-05-21 12:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:55:01 --> Input Class Initialized
INFO - 2016-05-21 12:55:01 --> Language Class Initialized
INFO - 2016-05-21 12:55:01 --> Loader Class Initialized
INFO - 2016-05-21 12:55:01 --> Helper loaded: url_helper
INFO - 2016-05-21 12:55:01 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:55:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:55:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:55:01 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:55:01 --> Helper loaded: form_helper
INFO - 2016-05-21 12:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:55:01 --> Form Validation Class Initialized
INFO - 2016-05-21 12:55:01 --> Controller Class Initialized
INFO - 2016-05-21 12:55:01 --> Model Class Initialized
INFO - 2016-05-21 12:55:01 --> Database Driver Class Initialized
INFO - 2016-05-21 12:55:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:55:01 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:55:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:55:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:55:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:55:01 --> Final output sent to browser
DEBUG - 2016-05-21 12:55:01 --> Total execution time: 0.1220
INFO - 2016-05-21 12:55:02 --> Config Class Initialized
INFO - 2016-05-21 12:55:02 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:55:02 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:55:02 --> Utf8 Class Initialized
INFO - 2016-05-21 12:55:02 --> URI Class Initialized
INFO - 2016-05-21 12:55:02 --> Router Class Initialized
INFO - 2016-05-21 12:55:02 --> Output Class Initialized
INFO - 2016-05-21 12:55:02 --> Security Class Initialized
DEBUG - 2016-05-21 12:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:55:02 --> Input Class Initialized
INFO - 2016-05-21 12:55:02 --> Language Class Initialized
INFO - 2016-05-21 12:55:02 --> Loader Class Initialized
INFO - 2016-05-21 12:55:02 --> Helper loaded: url_helper
INFO - 2016-05-21 12:55:02 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:55:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:55:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:55:02 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:55:02 --> Helper loaded: form_helper
INFO - 2016-05-21 12:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:55:02 --> Form Validation Class Initialized
INFO - 2016-05-21 12:55:02 --> Controller Class Initialized
INFO - 2016-05-21 12:55:02 --> Model Class Initialized
INFO - 2016-05-21 12:55:02 --> Database Driver Class Initialized
INFO - 2016-05-21 12:55:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:55:02 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:55:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:55:02 --> Final output sent to browser
DEBUG - 2016-05-21 12:55:02 --> Total execution time: 0.0968
INFO - 2016-05-21 12:55:17 --> Config Class Initialized
INFO - 2016-05-21 12:55:17 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:55:17 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:55:17 --> Utf8 Class Initialized
INFO - 2016-05-21 12:55:17 --> URI Class Initialized
INFO - 2016-05-21 12:55:17 --> Router Class Initialized
INFO - 2016-05-21 12:55:17 --> Output Class Initialized
INFO - 2016-05-21 12:55:17 --> Security Class Initialized
DEBUG - 2016-05-21 12:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:55:17 --> Input Class Initialized
INFO - 2016-05-21 12:55:17 --> Language Class Initialized
INFO - 2016-05-21 12:55:17 --> Loader Class Initialized
INFO - 2016-05-21 12:55:17 --> Helper loaded: url_helper
INFO - 2016-05-21 12:55:17 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:55:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:55:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:55:17 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:55:17 --> Helper loaded: form_helper
INFO - 2016-05-21 12:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:55:17 --> Form Validation Class Initialized
INFO - 2016-05-21 12:55:17 --> Controller Class Initialized
INFO - 2016-05-21 12:55:17 --> Model Class Initialized
INFO - 2016-05-21 12:55:17 --> Database Driver Class Initialized
INFO - 2016-05-21 12:55:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:55:17 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:55:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:55:17 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:55:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:55:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:55:17 --> Final output sent to browser
DEBUG - 2016-05-21 12:55:17 --> Total execution time: 0.1886
INFO - 2016-05-21 12:55:18 --> Config Class Initialized
INFO - 2016-05-21 12:55:18 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:55:18 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:55:18 --> Utf8 Class Initialized
INFO - 2016-05-21 12:55:18 --> URI Class Initialized
INFO - 2016-05-21 12:55:18 --> Router Class Initialized
INFO - 2016-05-21 12:55:18 --> Output Class Initialized
INFO - 2016-05-21 12:55:18 --> Security Class Initialized
DEBUG - 2016-05-21 12:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:55:18 --> Input Class Initialized
INFO - 2016-05-21 12:55:18 --> Language Class Initialized
INFO - 2016-05-21 12:55:18 --> Loader Class Initialized
INFO - 2016-05-21 12:55:18 --> Helper loaded: url_helper
INFO - 2016-05-21 12:55:18 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:55:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:55:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:55:18 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:55:18 --> Helper loaded: form_helper
INFO - 2016-05-21 12:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:55:18 --> Form Validation Class Initialized
INFO - 2016-05-21 12:55:18 --> Controller Class Initialized
INFO - 2016-05-21 12:55:18 --> Model Class Initialized
INFO - 2016-05-21 12:55:18 --> Database Driver Class Initialized
INFO - 2016-05-21 12:55:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:55:18 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:55:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:55:18 --> Final output sent to browser
DEBUG - 2016-05-21 12:55:18 --> Total execution time: 0.1005
INFO - 2016-05-21 12:55:20 --> Config Class Initialized
INFO - 2016-05-21 12:55:20 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:55:20 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:55:20 --> Utf8 Class Initialized
INFO - 2016-05-21 12:55:20 --> URI Class Initialized
INFO - 2016-05-21 12:55:20 --> Router Class Initialized
INFO - 2016-05-21 12:55:20 --> Output Class Initialized
INFO - 2016-05-21 12:55:20 --> Security Class Initialized
DEBUG - 2016-05-21 12:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:55:20 --> Input Class Initialized
INFO - 2016-05-21 12:55:20 --> Language Class Initialized
INFO - 2016-05-21 12:55:20 --> Loader Class Initialized
INFO - 2016-05-21 12:55:20 --> Helper loaded: url_helper
INFO - 2016-05-21 12:55:20 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:55:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:55:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:55:20 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:55:20 --> Helper loaded: form_helper
INFO - 2016-05-21 12:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:55:20 --> Form Validation Class Initialized
INFO - 2016-05-21 12:55:20 --> Controller Class Initialized
INFO - 2016-05-21 12:55:20 --> Model Class Initialized
INFO - 2016-05-21 12:55:20 --> Database Driver Class Initialized
INFO - 2016-05-21 12:55:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:55:20 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:55:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:55:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:55:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:55:20 --> Final output sent to browser
DEBUG - 2016-05-21 12:55:20 --> Total execution time: 0.1032
INFO - 2016-05-21 12:55:20 --> Config Class Initialized
INFO - 2016-05-21 12:55:20 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:55:20 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:55:20 --> Utf8 Class Initialized
INFO - 2016-05-21 12:55:20 --> URI Class Initialized
INFO - 2016-05-21 12:55:20 --> Router Class Initialized
INFO - 2016-05-21 12:55:20 --> Output Class Initialized
INFO - 2016-05-21 12:55:20 --> Security Class Initialized
DEBUG - 2016-05-21 12:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:55:20 --> Input Class Initialized
INFO - 2016-05-21 12:55:20 --> Language Class Initialized
INFO - 2016-05-21 12:55:20 --> Loader Class Initialized
INFO - 2016-05-21 12:55:20 --> Helper loaded: url_helper
INFO - 2016-05-21 12:55:20 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:55:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:55:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:55:20 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:55:20 --> Helper loaded: form_helper
INFO - 2016-05-21 12:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:55:20 --> Form Validation Class Initialized
INFO - 2016-05-21 12:55:20 --> Controller Class Initialized
INFO - 2016-05-21 12:55:20 --> Model Class Initialized
INFO - 2016-05-21 12:55:20 --> Database Driver Class Initialized
INFO - 2016-05-21 12:55:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:55:20 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:55:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:55:20 --> Final output sent to browser
DEBUG - 2016-05-21 12:55:20 --> Total execution time: 0.0910
INFO - 2016-05-21 12:55:30 --> Config Class Initialized
INFO - 2016-05-21 12:55:30 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:55:30 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:55:30 --> Utf8 Class Initialized
INFO - 2016-05-21 12:55:30 --> URI Class Initialized
INFO - 2016-05-21 12:55:30 --> Router Class Initialized
INFO - 2016-05-21 12:55:30 --> Output Class Initialized
INFO - 2016-05-21 12:55:30 --> Security Class Initialized
DEBUG - 2016-05-21 12:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:55:30 --> Input Class Initialized
INFO - 2016-05-21 12:55:30 --> Language Class Initialized
INFO - 2016-05-21 12:55:30 --> Loader Class Initialized
INFO - 2016-05-21 12:55:30 --> Helper loaded: url_helper
INFO - 2016-05-21 12:55:30 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:55:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:55:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:55:30 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:55:30 --> Helper loaded: form_helper
INFO - 2016-05-21 12:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:55:30 --> Form Validation Class Initialized
INFO - 2016-05-21 12:55:30 --> Controller Class Initialized
INFO - 2016-05-21 12:55:30 --> Model Class Initialized
INFO - 2016-05-21 12:55:30 --> Database Driver Class Initialized
INFO - 2016-05-21 12:55:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:55:30 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:55:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:55:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:55:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:55:30 --> Final output sent to browser
DEBUG - 2016-05-21 12:55:30 --> Total execution time: 0.1091
INFO - 2016-05-21 12:55:30 --> Config Class Initialized
INFO - 2016-05-21 12:55:30 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:55:30 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:55:30 --> Utf8 Class Initialized
INFO - 2016-05-21 12:55:30 --> URI Class Initialized
INFO - 2016-05-21 12:55:30 --> Router Class Initialized
INFO - 2016-05-21 12:55:30 --> Output Class Initialized
INFO - 2016-05-21 12:55:30 --> Security Class Initialized
DEBUG - 2016-05-21 12:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:55:30 --> Input Class Initialized
INFO - 2016-05-21 12:55:30 --> Language Class Initialized
INFO - 2016-05-21 12:55:30 --> Loader Class Initialized
INFO - 2016-05-21 12:55:30 --> Helper loaded: url_helper
INFO - 2016-05-21 12:55:30 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:55:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:55:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:55:30 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:55:30 --> Helper loaded: form_helper
INFO - 2016-05-21 12:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:55:30 --> Form Validation Class Initialized
INFO - 2016-05-21 12:55:30 --> Controller Class Initialized
INFO - 2016-05-21 12:55:30 --> Model Class Initialized
INFO - 2016-05-21 12:55:30 --> Database Driver Class Initialized
INFO - 2016-05-21 12:55:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:55:30 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:55:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:55:30 --> Final output sent to browser
DEBUG - 2016-05-21 12:55:30 --> Total execution time: 0.1059
INFO - 2016-05-21 12:55:33 --> Config Class Initialized
INFO - 2016-05-21 12:55:33 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:55:33 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:55:33 --> Utf8 Class Initialized
INFO - 2016-05-21 12:55:33 --> URI Class Initialized
INFO - 2016-05-21 12:55:33 --> Router Class Initialized
INFO - 2016-05-21 12:55:33 --> Output Class Initialized
INFO - 2016-05-21 12:55:33 --> Security Class Initialized
DEBUG - 2016-05-21 12:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:55:33 --> Input Class Initialized
INFO - 2016-05-21 12:55:33 --> Language Class Initialized
INFO - 2016-05-21 12:55:33 --> Loader Class Initialized
INFO - 2016-05-21 12:55:33 --> Helper loaded: url_helper
INFO - 2016-05-21 12:55:33 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:55:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:55:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:55:33 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:55:33 --> Helper loaded: form_helper
INFO - 2016-05-21 12:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:55:33 --> Form Validation Class Initialized
INFO - 2016-05-21 12:55:33 --> Controller Class Initialized
INFO - 2016-05-21 12:55:33 --> Model Class Initialized
INFO - 2016-05-21 12:55:33 --> Database Driver Class Initialized
INFO - 2016-05-21 12:55:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:55:33 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:55:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:55:33 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-21 12:55:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarDescuento.php
INFO - 2016-05-21 12:55:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:55:34 --> Final output sent to browser
DEBUG - 2016-05-21 12:55:34 --> Total execution time: 0.1465
INFO - 2016-05-21 12:55:34 --> Config Class Initialized
INFO - 2016-05-21 12:55:34 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:55:34 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:55:34 --> Utf8 Class Initialized
INFO - 2016-05-21 12:55:34 --> URI Class Initialized
INFO - 2016-05-21 12:55:34 --> Router Class Initialized
INFO - 2016-05-21 12:55:34 --> Output Class Initialized
INFO - 2016-05-21 12:55:34 --> Security Class Initialized
DEBUG - 2016-05-21 12:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:55:34 --> Input Class Initialized
INFO - 2016-05-21 12:55:34 --> Language Class Initialized
INFO - 2016-05-21 12:55:34 --> Loader Class Initialized
INFO - 2016-05-21 12:55:34 --> Helper loaded: url_helper
INFO - 2016-05-21 12:55:34 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:55:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:55:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:55:34 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:55:34 --> Helper loaded: form_helper
INFO - 2016-05-21 12:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:55:34 --> Form Validation Class Initialized
INFO - 2016-05-21 12:55:34 --> Controller Class Initialized
INFO - 2016-05-21 12:55:34 --> Model Class Initialized
INFO - 2016-05-21 12:55:34 --> Database Driver Class Initialized
INFO - 2016-05-21 12:55:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:55:34 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:55:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:55:34 --> Final output sent to browser
DEBUG - 2016-05-21 12:55:34 --> Total execution time: 0.1108
INFO - 2016-05-21 12:55:35 --> Config Class Initialized
INFO - 2016-05-21 12:55:35 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:55:35 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:55:35 --> Utf8 Class Initialized
INFO - 2016-05-21 12:55:35 --> URI Class Initialized
INFO - 2016-05-21 12:55:35 --> Router Class Initialized
INFO - 2016-05-21 12:55:35 --> Output Class Initialized
INFO - 2016-05-21 12:55:35 --> Security Class Initialized
DEBUG - 2016-05-21 12:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:55:35 --> Input Class Initialized
INFO - 2016-05-21 12:55:35 --> Language Class Initialized
INFO - 2016-05-21 12:55:35 --> Loader Class Initialized
INFO - 2016-05-21 12:55:35 --> Helper loaded: url_helper
INFO - 2016-05-21 12:55:35 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:55:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:55:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:55:35 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:55:35 --> Helper loaded: form_helper
INFO - 2016-05-21 12:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:55:35 --> Form Validation Class Initialized
INFO - 2016-05-21 12:55:35 --> Controller Class Initialized
INFO - 2016-05-21 12:55:35 --> Model Class Initialized
INFO - 2016-05-21 12:55:35 --> Database Driver Class Initialized
INFO - 2016-05-21 12:55:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:55:35 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:55:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:55:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-21 12:55:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-21 12:55:35 --> Final output sent to browser
DEBUG - 2016-05-21 12:55:35 --> Total execution time: 0.1035
INFO - 2016-05-21 12:55:35 --> Config Class Initialized
INFO - 2016-05-21 12:55:35 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:55:35 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:55:35 --> Utf8 Class Initialized
INFO - 2016-05-21 12:55:35 --> URI Class Initialized
INFO - 2016-05-21 12:55:35 --> Router Class Initialized
INFO - 2016-05-21 12:55:35 --> Output Class Initialized
INFO - 2016-05-21 12:55:35 --> Security Class Initialized
DEBUG - 2016-05-21 12:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:55:35 --> Input Class Initialized
INFO - 2016-05-21 12:55:35 --> Language Class Initialized
INFO - 2016-05-21 12:55:35 --> Loader Class Initialized
INFO - 2016-05-21 12:55:35 --> Helper loaded: url_helper
INFO - 2016-05-21 12:55:35 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:55:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:55:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:55:35 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:55:35 --> Helper loaded: form_helper
INFO - 2016-05-21 12:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:55:35 --> Form Validation Class Initialized
INFO - 2016-05-21 12:55:35 --> Controller Class Initialized
INFO - 2016-05-21 12:55:35 --> Model Class Initialized
INFO - 2016-05-21 12:55:35 --> Database Driver Class Initialized
INFO - 2016-05-21 12:55:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:55:35 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:55:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:55:35 --> Final output sent to browser
DEBUG - 2016-05-21 12:55:35 --> Total execution time: 0.0994
INFO - 2016-05-21 12:55:38 --> Config Class Initialized
INFO - 2016-05-21 12:55:38 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:55:38 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:55:38 --> Utf8 Class Initialized
INFO - 2016-05-21 12:55:38 --> URI Class Initialized
INFO - 2016-05-21 12:55:38 --> Router Class Initialized
INFO - 2016-05-21 12:55:38 --> Output Class Initialized
INFO - 2016-05-21 12:55:38 --> Security Class Initialized
DEBUG - 2016-05-21 12:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:55:38 --> Input Class Initialized
INFO - 2016-05-21 12:55:38 --> Language Class Initialized
INFO - 2016-05-21 12:55:38 --> Loader Class Initialized
INFO - 2016-05-21 12:55:38 --> Helper loaded: url_helper
INFO - 2016-05-21 12:55:38 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:55:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:55:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:55:38 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:55:38 --> Helper loaded: form_helper
INFO - 2016-05-21 12:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:55:38 --> Form Validation Class Initialized
INFO - 2016-05-21 12:55:38 --> Controller Class Initialized
INFO - 2016-05-21 12:55:38 --> Model Class Initialized
INFO - 2016-05-21 12:55:38 --> Database Driver Class Initialized
INFO - 2016-05-21 12:55:38 --> Final output sent to browser
DEBUG - 2016-05-21 12:55:38 --> Total execution time: 0.1605
INFO - 2016-05-21 12:55:59 --> Config Class Initialized
INFO - 2016-05-21 12:55:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:55:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:55:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:55:59 --> URI Class Initialized
INFO - 2016-05-21 12:55:59 --> Router Class Initialized
INFO - 2016-05-21 12:55:59 --> Output Class Initialized
INFO - 2016-05-21 12:55:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:55:59 --> Input Class Initialized
INFO - 2016-05-21 12:55:59 --> Language Class Initialized
INFO - 2016-05-21 12:55:59 --> Loader Class Initialized
INFO - 2016-05-21 12:55:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:55:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:55:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:55:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:55:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:55:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:55:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:55:59 --> Controller Class Initialized
INFO - 2016-05-21 12:55:59 --> Model Class Initialized
INFO - 2016-05-21 12:55:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:55:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:55:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:55:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:55:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:55:59 --> Total execution time: 0.0769
INFO - 2016-05-21 12:56:59 --> Config Class Initialized
INFO - 2016-05-21 12:56:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:56:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:56:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:56:59 --> URI Class Initialized
INFO - 2016-05-21 12:56:59 --> Router Class Initialized
INFO - 2016-05-21 12:56:59 --> Output Class Initialized
INFO - 2016-05-21 12:56:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:56:59 --> Input Class Initialized
INFO - 2016-05-21 12:56:59 --> Language Class Initialized
INFO - 2016-05-21 12:56:59 --> Loader Class Initialized
INFO - 2016-05-21 12:56:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:56:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:56:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:56:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:56:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:56:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:56:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:56:59 --> Controller Class Initialized
INFO - 2016-05-21 12:56:59 --> Model Class Initialized
INFO - 2016-05-21 12:56:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:56:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:56:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:56:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:56:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:56:59 --> Total execution time: 0.1052
INFO - 2016-05-21 12:57:59 --> Config Class Initialized
INFO - 2016-05-21 12:57:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:57:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:57:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:57:59 --> URI Class Initialized
INFO - 2016-05-21 12:57:59 --> Router Class Initialized
INFO - 2016-05-21 12:57:59 --> Output Class Initialized
INFO - 2016-05-21 12:57:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:57:59 --> Input Class Initialized
INFO - 2016-05-21 12:57:59 --> Language Class Initialized
INFO - 2016-05-21 12:57:59 --> Loader Class Initialized
INFO - 2016-05-21 12:57:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:57:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:57:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:57:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:57:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:57:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:57:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:57:59 --> Controller Class Initialized
INFO - 2016-05-21 12:57:59 --> Model Class Initialized
INFO - 2016-05-21 12:57:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:57:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:57:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:57:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:57:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:57:59 --> Total execution time: 0.0756
INFO - 2016-05-21 12:58:59 --> Config Class Initialized
INFO - 2016-05-21 12:58:59 --> Hooks Class Initialized
DEBUG - 2016-05-21 12:58:59 --> UTF-8 Support Enabled
INFO - 2016-05-21 12:58:59 --> Utf8 Class Initialized
INFO - 2016-05-21 12:58:59 --> URI Class Initialized
INFO - 2016-05-21 12:58:59 --> Router Class Initialized
INFO - 2016-05-21 12:58:59 --> Output Class Initialized
INFO - 2016-05-21 12:58:59 --> Security Class Initialized
DEBUG - 2016-05-21 12:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-21 12:58:59 --> Input Class Initialized
INFO - 2016-05-21 12:58:59 --> Language Class Initialized
INFO - 2016-05-21 12:58:59 --> Loader Class Initialized
INFO - 2016-05-21 12:58:59 --> Helper loaded: url_helper
INFO - 2016-05-21 12:58:59 --> Helper loaded: sesion_helper
INFO - 2016-05-21 12:58:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-21 12:58:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-21 12:58:59 --> Helper loaded: redondear_helper
INFO - 2016-05-21 12:58:59 --> Helper loaded: form_helper
INFO - 2016-05-21 12:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-21 12:58:59 --> Form Validation Class Initialized
INFO - 2016-05-21 12:58:59 --> Controller Class Initialized
INFO - 2016-05-21 12:58:59 --> Model Class Initialized
INFO - 2016-05-21 12:58:59 --> Database Driver Class Initialized
INFO - 2016-05-21 12:58:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-21 12:58:59 --> Pagination Class Initialized
DEBUG - 2016-05-21 12:58:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-21 12:58:59 --> Final output sent to browser
DEBUG - 2016-05-21 12:58:59 --> Total execution time: 0.0740
