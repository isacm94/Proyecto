<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-16 17:41:14 --> Config Class Initialized
INFO - 2016-05-16 17:41:14 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:14 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:14 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:14 --> URI Class Initialized
DEBUG - 2016-05-16 17:41:14 --> No URI present. Default controller set.
INFO - 2016-05-16 17:41:14 --> Router Class Initialized
INFO - 2016-05-16 17:41:14 --> Output Class Initialized
INFO - 2016-05-16 17:41:14 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:14 --> Input Class Initialized
INFO - 2016-05-16 17:41:14 --> Language Class Initialized
INFO - 2016-05-16 17:41:14 --> Loader Class Initialized
INFO - 2016-05-16 17:41:14 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:14 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:14 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:14 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:14 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:14 --> Controller Class Initialized
INFO - 2016-05-16 17:41:14 --> Model Class Initialized
INFO - 2016-05-16 17:41:14 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-16 17:41:14 --> Pagination Class Initialized
DEBUG - 2016-05-16 17:41:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-16 17:41:14 --> Config Class Initialized
INFO - 2016-05-16 17:41:14 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:14 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:14 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:14 --> URI Class Initialized
INFO - 2016-05-16 17:41:14 --> Router Class Initialized
INFO - 2016-05-16 17:41:14 --> Output Class Initialized
INFO - 2016-05-16 17:41:14 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:14 --> Input Class Initialized
INFO - 2016-05-16 17:41:14 --> Language Class Initialized
INFO - 2016-05-16 17:41:14 --> Loader Class Initialized
INFO - 2016-05-16 17:41:14 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:14 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:14 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:14 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:14 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:14 --> Controller Class Initialized
INFO - 2016-05-16 17:41:14 --> Model Class Initialized
INFO - 2016-05-16 17:41:14 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-16 17:41:14 --> Final output sent to browser
DEBUG - 2016-05-16 17:41:14 --> Total execution time: 0.0746
INFO - 2016-05-16 17:41:23 --> Config Class Initialized
INFO - 2016-05-16 17:41:23 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:23 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:23 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:23 --> URI Class Initialized
INFO - 2016-05-16 17:41:23 --> Router Class Initialized
INFO - 2016-05-16 17:41:23 --> Output Class Initialized
INFO - 2016-05-16 17:41:23 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:23 --> Input Class Initialized
INFO - 2016-05-16 17:41:23 --> Language Class Initialized
INFO - 2016-05-16 17:41:23 --> Loader Class Initialized
INFO - 2016-05-16 17:41:23 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:23 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:23 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:23 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:23 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:23 --> Controller Class Initialized
INFO - 2016-05-16 17:41:23 --> Model Class Initialized
INFO - 2016-05-16 17:41:23 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:23 --> Config Class Initialized
INFO - 2016-05-16 17:41:23 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:23 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:23 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:23 --> URI Class Initialized
DEBUG - 2016-05-16 17:41:23 --> No URI present. Default controller set.
INFO - 2016-05-16 17:41:23 --> Router Class Initialized
INFO - 2016-05-16 17:41:23 --> Output Class Initialized
INFO - 2016-05-16 17:41:23 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:23 --> Input Class Initialized
INFO - 2016-05-16 17:41:23 --> Language Class Initialized
INFO - 2016-05-16 17:41:23 --> Loader Class Initialized
INFO - 2016-05-16 17:41:23 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:23 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:23 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:23 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:23 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:23 --> Controller Class Initialized
INFO - 2016-05-16 17:41:23 --> Model Class Initialized
INFO - 2016-05-16 17:41:23 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-16 17:41:23 --> Pagination Class Initialized
DEBUG - 2016-05-16 17:41:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-16 17:41:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-16 17:41:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:41:24 --> Final output sent to browser
DEBUG - 2016-05-16 17:41:24 --> Total execution time: 0.5080
INFO - 2016-05-16 17:41:29 --> Config Class Initialized
INFO - 2016-05-16 17:41:29 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:29 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:29 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:29 --> URI Class Initialized
INFO - 2016-05-16 17:41:29 --> Router Class Initialized
INFO - 2016-05-16 17:41:29 --> Output Class Initialized
INFO - 2016-05-16 17:41:29 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:29 --> Input Class Initialized
INFO - 2016-05-16 17:41:29 --> Language Class Initialized
INFO - 2016-05-16 17:41:29 --> Loader Class Initialized
INFO - 2016-05-16 17:41:29 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:29 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:29 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:29 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:29 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:29 --> Controller Class Initialized
INFO - 2016-05-16 17:41:29 --> Model Class Initialized
INFO - 2016-05-16 17:41:29 --> Database Driver Class Initialized
ERROR - 2016-05-16 17:41:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 43
ERROR - 2016-05-16 17:41:29 --> Severity: Notice --> Undefined variable: cantidad C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 51
INFO - 2016-05-16 17:41:29 --> Config Class Initialized
INFO - 2016-05-16 17:41:29 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:29 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:29 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:29 --> URI Class Initialized
INFO - 2016-05-16 17:41:29 --> Router Class Initialized
INFO - 2016-05-16 17:41:29 --> Output Class Initialized
INFO - 2016-05-16 17:41:29 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:29 --> Input Class Initialized
INFO - 2016-05-16 17:41:29 --> Language Class Initialized
INFO - 2016-05-16 17:41:29 --> Loader Class Initialized
INFO - 2016-05-16 17:41:29 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:29 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:29 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:29 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:29 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:29 --> Controller Class Initialized
INFO - 2016-05-16 17:41:29 --> Model Class Initialized
INFO - 2016-05-16 17:41:29 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_carrito.php
INFO - 2016-05-16 17:41:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:41:29 --> Final output sent to browser
DEBUG - 2016-05-16 17:41:29 --> Total execution time: 0.1105
INFO - 2016-05-16 17:41:30 --> Config Class Initialized
INFO - 2016-05-16 17:41:30 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:30 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:30 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:30 --> URI Class Initialized
DEBUG - 2016-05-16 17:41:30 --> No URI present. Default controller set.
INFO - 2016-05-16 17:41:30 --> Router Class Initialized
INFO - 2016-05-16 17:41:30 --> Output Class Initialized
INFO - 2016-05-16 17:41:30 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:30 --> Input Class Initialized
INFO - 2016-05-16 17:41:30 --> Language Class Initialized
INFO - 2016-05-16 17:41:30 --> Loader Class Initialized
INFO - 2016-05-16 17:41:30 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:30 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:30 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:30 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:30 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:30 --> Controller Class Initialized
INFO - 2016-05-16 17:41:30 --> Model Class Initialized
INFO - 2016-05-16 17:41:30 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-16 17:41:30 --> Pagination Class Initialized
DEBUG - 2016-05-16 17:41:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-16 17:41:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-16 17:41:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:41:30 --> Final output sent to browser
DEBUG - 2016-05-16 17:41:30 --> Total execution time: 0.0848
INFO - 2016-05-16 17:41:31 --> Config Class Initialized
INFO - 2016-05-16 17:41:31 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:31 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:31 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:31 --> URI Class Initialized
INFO - 2016-05-16 17:41:31 --> Router Class Initialized
INFO - 2016-05-16 17:41:31 --> Output Class Initialized
INFO - 2016-05-16 17:41:31 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:31 --> Input Class Initialized
INFO - 2016-05-16 17:41:31 --> Language Class Initialized
INFO - 2016-05-16 17:41:31 --> Loader Class Initialized
INFO - 2016-05-16 17:41:31 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:31 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:31 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:31 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:31 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:31 --> Controller Class Initialized
INFO - 2016-05-16 17:41:31 --> Model Class Initialized
INFO - 2016-05-16 17:41:31 --> Database Driver Class Initialized
ERROR - 2016-05-16 17:41:31 --> Severity: Notice --> Undefined variable: cantidad C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 51
INFO - 2016-05-16 17:41:31 --> Config Class Initialized
INFO - 2016-05-16 17:41:31 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:31 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:31 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:31 --> URI Class Initialized
INFO - 2016-05-16 17:41:31 --> Router Class Initialized
INFO - 2016-05-16 17:41:31 --> Output Class Initialized
INFO - 2016-05-16 17:41:31 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:31 --> Input Class Initialized
INFO - 2016-05-16 17:41:31 --> Language Class Initialized
INFO - 2016-05-16 17:41:31 --> Loader Class Initialized
INFO - 2016-05-16 17:41:31 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:31 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:31 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:31 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:31 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:31 --> Controller Class Initialized
INFO - 2016-05-16 17:41:31 --> Model Class Initialized
INFO - 2016-05-16 17:41:31 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_carrito.php
INFO - 2016-05-16 17:41:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:41:31 --> Final output sent to browser
DEBUG - 2016-05-16 17:41:31 --> Total execution time: 0.1044
INFO - 2016-05-16 17:41:35 --> Config Class Initialized
INFO - 2016-05-16 17:41:35 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:35 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:35 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:35 --> URI Class Initialized
DEBUG - 2016-05-16 17:41:35 --> No URI present. Default controller set.
INFO - 2016-05-16 17:41:35 --> Router Class Initialized
INFO - 2016-05-16 17:41:35 --> Output Class Initialized
INFO - 2016-05-16 17:41:35 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:35 --> Input Class Initialized
INFO - 2016-05-16 17:41:35 --> Language Class Initialized
INFO - 2016-05-16 17:41:35 --> Loader Class Initialized
INFO - 2016-05-16 17:41:35 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:35 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:35 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:35 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:35 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:35 --> Controller Class Initialized
INFO - 2016-05-16 17:41:35 --> Model Class Initialized
INFO - 2016-05-16 17:41:35 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-16 17:41:35 --> Pagination Class Initialized
DEBUG - 2016-05-16 17:41:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-16 17:41:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-16 17:41:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:41:35 --> Final output sent to browser
DEBUG - 2016-05-16 17:41:35 --> Total execution time: 0.0835
INFO - 2016-05-16 17:41:45 --> Config Class Initialized
INFO - 2016-05-16 17:41:45 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:45 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:45 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:45 --> URI Class Initialized
INFO - 2016-05-16 17:41:45 --> Router Class Initialized
INFO - 2016-05-16 17:41:45 --> Output Class Initialized
INFO - 2016-05-16 17:41:45 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:45 --> Input Class Initialized
INFO - 2016-05-16 17:41:45 --> Language Class Initialized
INFO - 2016-05-16 17:41:45 --> Loader Class Initialized
INFO - 2016-05-16 17:41:45 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:45 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:45 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:45 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:45 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:45 --> Controller Class Initialized
INFO - 2016-05-16 17:41:45 --> Model Class Initialized
INFO - 2016-05-16 17:41:45 --> Database Driver Class Initialized
ERROR - 2016-05-16 17:41:45 --> Severity: Notice --> Undefined variable: cantidad C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 51
INFO - 2016-05-16 17:41:45 --> Config Class Initialized
INFO - 2016-05-16 17:41:45 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:45 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:45 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:45 --> URI Class Initialized
INFO - 2016-05-16 17:41:45 --> Router Class Initialized
INFO - 2016-05-16 17:41:45 --> Output Class Initialized
INFO - 2016-05-16 17:41:45 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:45 --> Input Class Initialized
INFO - 2016-05-16 17:41:45 --> Language Class Initialized
INFO - 2016-05-16 17:41:45 --> Loader Class Initialized
INFO - 2016-05-16 17:41:45 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:45 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:45 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:45 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:45 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:45 --> Controller Class Initialized
INFO - 2016-05-16 17:41:45 --> Model Class Initialized
INFO - 2016-05-16 17:41:45 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_carrito.php
INFO - 2016-05-16 17:41:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:41:45 --> Final output sent to browser
DEBUG - 2016-05-16 17:41:45 --> Total execution time: 0.0847
INFO - 2016-05-16 17:41:46 --> Config Class Initialized
INFO - 2016-05-16 17:41:46 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:46 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:46 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:46 --> URI Class Initialized
DEBUG - 2016-05-16 17:41:46 --> No URI present. Default controller set.
INFO - 2016-05-16 17:41:46 --> Router Class Initialized
INFO - 2016-05-16 17:41:46 --> Output Class Initialized
INFO - 2016-05-16 17:41:46 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:46 --> Input Class Initialized
INFO - 2016-05-16 17:41:46 --> Language Class Initialized
INFO - 2016-05-16 17:41:46 --> Loader Class Initialized
INFO - 2016-05-16 17:41:46 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:46 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:46 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:46 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:46 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:46 --> Controller Class Initialized
INFO - 2016-05-16 17:41:46 --> Model Class Initialized
INFO - 2016-05-16 17:41:46 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-16 17:41:46 --> Pagination Class Initialized
DEBUG - 2016-05-16 17:41:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-16 17:41:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-16 17:41:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:41:46 --> Final output sent to browser
DEBUG - 2016-05-16 17:41:46 --> Total execution time: 0.0846
INFO - 2016-05-16 17:41:47 --> Config Class Initialized
INFO - 2016-05-16 17:41:47 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:47 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:47 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:47 --> URI Class Initialized
INFO - 2016-05-16 17:41:47 --> Router Class Initialized
INFO - 2016-05-16 17:41:47 --> Output Class Initialized
INFO - 2016-05-16 17:41:47 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:47 --> Input Class Initialized
INFO - 2016-05-16 17:41:47 --> Language Class Initialized
INFO - 2016-05-16 17:41:47 --> Loader Class Initialized
INFO - 2016-05-16 17:41:47 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:47 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:47 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:47 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:47 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:47 --> Controller Class Initialized
INFO - 2016-05-16 17:41:47 --> Model Class Initialized
INFO - 2016-05-16 17:41:48 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-16 17:41:48 --> Pagination Class Initialized
DEBUG - 2016-05-16 17:41:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-16 17:41:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-16 17:41:48 --> Final output sent to browser
DEBUG - 2016-05-16 17:41:48 --> Total execution time: 0.0810
INFO - 2016-05-16 17:41:51 --> Config Class Initialized
INFO - 2016-05-16 17:41:51 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:51 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:51 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:51 --> URI Class Initialized
INFO - 2016-05-16 17:41:51 --> Router Class Initialized
INFO - 2016-05-16 17:41:51 --> Output Class Initialized
INFO - 2016-05-16 17:41:51 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:51 --> Input Class Initialized
INFO - 2016-05-16 17:41:51 --> Language Class Initialized
INFO - 2016-05-16 17:41:51 --> Loader Class Initialized
INFO - 2016-05-16 17:41:51 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:51 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:51 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:51 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:51 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:51 --> Controller Class Initialized
INFO - 2016-05-16 17:41:51 --> Model Class Initialized
INFO - 2016-05-16 17:41:51 --> Database Driver Class Initialized
ERROR - 2016-05-16 17:41:51 --> Severity: Notice --> Undefined variable: cantidad C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 51
INFO - 2016-05-16 17:41:51 --> Config Class Initialized
INFO - 2016-05-16 17:41:51 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:51 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:51 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:51 --> URI Class Initialized
INFO - 2016-05-16 17:41:51 --> Router Class Initialized
INFO - 2016-05-16 17:41:51 --> Output Class Initialized
INFO - 2016-05-16 17:41:51 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:51 --> Input Class Initialized
INFO - 2016-05-16 17:41:51 --> Language Class Initialized
INFO - 2016-05-16 17:41:51 --> Loader Class Initialized
INFO - 2016-05-16 17:41:51 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:51 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:51 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:51 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:51 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:51 --> Controller Class Initialized
INFO - 2016-05-16 17:41:51 --> Model Class Initialized
INFO - 2016-05-16 17:41:51 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_carrito.php
INFO - 2016-05-16 17:41:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:41:51 --> Final output sent to browser
DEBUG - 2016-05-16 17:41:51 --> Total execution time: 0.0826
INFO - 2016-05-16 17:41:53 --> Config Class Initialized
INFO - 2016-05-16 17:41:53 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:53 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:53 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:53 --> URI Class Initialized
INFO - 2016-05-16 17:41:53 --> Router Class Initialized
INFO - 2016-05-16 17:41:53 --> Output Class Initialized
INFO - 2016-05-16 17:41:53 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:53 --> Input Class Initialized
INFO - 2016-05-16 17:41:53 --> Language Class Initialized
INFO - 2016-05-16 17:41:53 --> Loader Class Initialized
INFO - 2016-05-16 17:41:53 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:53 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:53 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:53 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:53 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:53 --> Controller Class Initialized
INFO - 2016-05-16 17:41:53 --> Model Class Initialized
INFO - 2016-05-16 17:41:53 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:53 --> Config Class Initialized
INFO - 2016-05-16 17:41:53 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:53 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:53 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:53 --> URI Class Initialized
INFO - 2016-05-16 17:41:53 --> Router Class Initialized
INFO - 2016-05-16 17:41:53 --> Output Class Initialized
INFO - 2016-05-16 17:41:53 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:53 --> Input Class Initialized
INFO - 2016-05-16 17:41:53 --> Language Class Initialized
INFO - 2016-05-16 17:41:53 --> Loader Class Initialized
INFO - 2016-05-16 17:41:54 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:54 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:54 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:54 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:54 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:54 --> Controller Class Initialized
INFO - 2016-05-16 17:41:54 --> Model Class Initialized
INFO - 2016-05-16 17:41:54 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_carrito.php
INFO - 2016-05-16 17:41:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:41:54 --> Final output sent to browser
DEBUG - 2016-05-16 17:41:54 --> Total execution time: 0.0717
INFO - 2016-05-16 17:41:55 --> Config Class Initialized
INFO - 2016-05-16 17:41:55 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:55 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:55 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:55 --> URI Class Initialized
INFO - 2016-05-16 17:41:55 --> Router Class Initialized
INFO - 2016-05-16 17:41:55 --> Output Class Initialized
INFO - 2016-05-16 17:41:55 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:55 --> Input Class Initialized
INFO - 2016-05-16 17:41:55 --> Language Class Initialized
INFO - 2016-05-16 17:41:55 --> Loader Class Initialized
INFO - 2016-05-16 17:41:55 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:55 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:55 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:55 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:55 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:55 --> Controller Class Initialized
INFO - 2016-05-16 17:41:55 --> Model Class Initialized
INFO - 2016-05-16 17:41:55 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:55 --> Config Class Initialized
INFO - 2016-05-16 17:41:55 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:55 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:55 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:55 --> URI Class Initialized
INFO - 2016-05-16 17:41:55 --> Router Class Initialized
INFO - 2016-05-16 17:41:55 --> Output Class Initialized
INFO - 2016-05-16 17:41:55 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:55 --> Input Class Initialized
INFO - 2016-05-16 17:41:55 --> Language Class Initialized
INFO - 2016-05-16 17:41:55 --> Loader Class Initialized
INFO - 2016-05-16 17:41:55 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:55 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:55 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:55 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:55 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:55 --> Controller Class Initialized
INFO - 2016-05-16 17:41:55 --> Model Class Initialized
INFO - 2016-05-16 17:41:55 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_carrito.php
INFO - 2016-05-16 17:41:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:41:55 --> Final output sent to browser
DEBUG - 2016-05-16 17:41:55 --> Total execution time: 0.0964
INFO - 2016-05-16 17:41:59 --> Config Class Initialized
INFO - 2016-05-16 17:41:59 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:41:59 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:41:59 --> Utf8 Class Initialized
INFO - 2016-05-16 17:41:59 --> URI Class Initialized
INFO - 2016-05-16 17:41:59 --> Router Class Initialized
INFO - 2016-05-16 17:41:59 --> Output Class Initialized
INFO - 2016-05-16 17:41:59 --> Security Class Initialized
DEBUG - 2016-05-16 17:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:41:59 --> Input Class Initialized
INFO - 2016-05-16 17:41:59 --> Language Class Initialized
INFO - 2016-05-16 17:41:59 --> Loader Class Initialized
INFO - 2016-05-16 17:41:59 --> Helper loaded: url_helper
INFO - 2016-05-16 17:41:59 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:41:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:41:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:41:59 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:41:59 --> Helper loaded: form_helper
INFO - 2016-05-16 17:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:41:59 --> Form Validation Class Initialized
INFO - 2016-05-16 17:41:59 --> Controller Class Initialized
INFO - 2016-05-16 17:41:59 --> Model Class Initialized
INFO - 2016-05-16 17:41:59 --> Database Driver Class Initialized
INFO - 2016-05-16 17:41:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_venta1.php
INFO - 2016-05-16 17:41:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:41:59 --> Final output sent to browser
DEBUG - 2016-05-16 17:41:59 --> Total execution time: 0.1136
INFO - 2016-05-16 17:42:10 --> Config Class Initialized
INFO - 2016-05-16 17:42:10 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:42:11 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:42:11 --> Utf8 Class Initialized
INFO - 2016-05-16 17:42:11 --> URI Class Initialized
INFO - 2016-05-16 17:42:11 --> Router Class Initialized
INFO - 2016-05-16 17:42:11 --> Output Class Initialized
INFO - 2016-05-16 17:42:11 --> Security Class Initialized
DEBUG - 2016-05-16 17:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:42:11 --> Input Class Initialized
INFO - 2016-05-16 17:42:11 --> Language Class Initialized
INFO - 2016-05-16 17:42:11 --> Loader Class Initialized
INFO - 2016-05-16 17:42:11 --> Helper loaded: url_helper
INFO - 2016-05-16 17:42:11 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:42:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:42:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:42:11 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:42:11 --> Helper loaded: form_helper
INFO - 2016-05-16 17:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:42:11 --> Form Validation Class Initialized
INFO - 2016-05-16 17:42:11 --> Controller Class Initialized
INFO - 2016-05-16 17:42:11 --> Model Class Initialized
INFO - 2016-05-16 17:42:11 --> Database Driver Class Initialized
INFO - 2016-05-16 17:42:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_venta1.php
INFO - 2016-05-16 17:42:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:42:11 --> Final output sent to browser
DEBUG - 2016-05-16 17:42:11 --> Total execution time: 0.0862
INFO - 2016-05-16 17:42:14 --> Config Class Initialized
INFO - 2016-05-16 17:42:14 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:42:14 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:42:14 --> Utf8 Class Initialized
INFO - 2016-05-16 17:42:14 --> URI Class Initialized
INFO - 2016-05-16 17:42:14 --> Router Class Initialized
INFO - 2016-05-16 17:42:14 --> Output Class Initialized
INFO - 2016-05-16 17:42:14 --> Security Class Initialized
DEBUG - 2016-05-16 17:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:42:14 --> Input Class Initialized
INFO - 2016-05-16 17:42:14 --> Language Class Initialized
INFO - 2016-05-16 17:42:14 --> Loader Class Initialized
INFO - 2016-05-16 17:42:14 --> Helper loaded: url_helper
INFO - 2016-05-16 17:42:14 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:42:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:42:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:42:14 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:42:14 --> Helper loaded: form_helper
INFO - 2016-05-16 17:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:42:14 --> Form Validation Class Initialized
INFO - 2016-05-16 17:42:14 --> Controller Class Initialized
INFO - 2016-05-16 17:42:14 --> Model Class Initialized
INFO - 2016-05-16 17:42:14 --> Database Driver Class Initialized
INFO - 2016-05-16 17:42:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_venta2.php
INFO - 2016-05-16 17:42:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:42:14 --> Final output sent to browser
DEBUG - 2016-05-16 17:42:14 --> Total execution time: 0.0864
INFO - 2016-05-16 17:42:18 --> Config Class Initialized
INFO - 2016-05-16 17:42:18 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:42:18 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:42:18 --> Utf8 Class Initialized
INFO - 2016-05-16 17:42:18 --> URI Class Initialized
INFO - 2016-05-16 17:42:18 --> Router Class Initialized
INFO - 2016-05-16 17:42:18 --> Output Class Initialized
INFO - 2016-05-16 17:42:18 --> Security Class Initialized
DEBUG - 2016-05-16 17:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:42:18 --> Input Class Initialized
INFO - 2016-05-16 17:42:18 --> Language Class Initialized
INFO - 2016-05-16 17:42:18 --> Loader Class Initialized
INFO - 2016-05-16 17:42:18 --> Helper loaded: url_helper
INFO - 2016-05-16 17:42:18 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:42:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:42:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:42:18 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:42:18 --> Helper loaded: form_helper
INFO - 2016-05-16 17:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:42:18 --> Form Validation Class Initialized
INFO - 2016-05-16 17:42:18 --> Controller Class Initialized
INFO - 2016-05-16 17:42:18 --> Model Class Initialized
INFO - 2016-05-16 17:42:18 --> Database Driver Class Initialized
INFO - 2016-05-16 17:42:18 --> Config Class Initialized
INFO - 2016-05-16 17:42:18 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:42:18 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:42:18 --> Utf8 Class Initialized
INFO - 2016-05-16 17:42:18 --> URI Class Initialized
INFO - 2016-05-16 17:42:18 --> Router Class Initialized
INFO - 2016-05-16 17:42:18 --> Output Class Initialized
INFO - 2016-05-16 17:42:18 --> Security Class Initialized
DEBUG - 2016-05-16 17:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:42:18 --> Input Class Initialized
INFO - 2016-05-16 17:42:18 --> Language Class Initialized
INFO - 2016-05-16 17:42:18 --> Loader Class Initialized
INFO - 2016-05-16 17:42:18 --> Helper loaded: url_helper
INFO - 2016-05-16 17:42:18 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:42:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:42:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:42:18 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:42:18 --> Helper loaded: form_helper
INFO - 2016-05-16 17:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:42:18 --> Form Validation Class Initialized
INFO - 2016-05-16 17:42:18 --> Controller Class Initialized
INFO - 2016-05-16 17:42:18 --> Model Class Initialized
INFO - 2016-05-16 17:42:18 --> Database Driver Class Initialized
INFO - 2016-05-16 17:42:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_resumenventa.php
INFO - 2016-05-16 17:42:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:42:18 --> Final output sent to browser
DEBUG - 2016-05-16 17:42:18 --> Total execution time: 0.1168
INFO - 2016-05-16 17:42:20 --> Config Class Initialized
INFO - 2016-05-16 17:42:20 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:42:20 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:42:20 --> Utf8 Class Initialized
INFO - 2016-05-16 17:42:20 --> URI Class Initialized
INFO - 2016-05-16 17:42:20 --> Router Class Initialized
INFO - 2016-05-16 17:42:20 --> Output Class Initialized
INFO - 2016-05-16 17:42:20 --> Security Class Initialized
DEBUG - 2016-05-16 17:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:42:20 --> Input Class Initialized
INFO - 2016-05-16 17:42:20 --> Language Class Initialized
INFO - 2016-05-16 17:42:20 --> Loader Class Initialized
INFO - 2016-05-16 17:42:20 --> Helper loaded: url_helper
INFO - 2016-05-16 17:42:20 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:42:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:42:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:42:20 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:42:20 --> Helper loaded: form_helper
INFO - 2016-05-16 17:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:42:21 --> Form Validation Class Initialized
INFO - 2016-05-16 17:42:21 --> Controller Class Initialized
INFO - 2016-05-16 17:42:21 --> Model Class Initialized
INFO - 2016-05-16 17:42:21 --> Database Driver Class Initialized
INFO - 2016-05-16 17:42:21 --> Config Class Initialized
INFO - 2016-05-16 17:42:21 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:42:21 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:42:21 --> Utf8 Class Initialized
INFO - 2016-05-16 17:42:21 --> URI Class Initialized
INFO - 2016-05-16 17:42:21 --> Router Class Initialized
INFO - 2016-05-16 17:42:21 --> Output Class Initialized
INFO - 2016-05-16 17:42:21 --> Security Class Initialized
DEBUG - 2016-05-16 17:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:42:21 --> Input Class Initialized
INFO - 2016-05-16 17:42:21 --> Language Class Initialized
INFO - 2016-05-16 17:42:21 --> Loader Class Initialized
INFO - 2016-05-16 17:42:21 --> Helper loaded: url_helper
INFO - 2016-05-16 17:42:21 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:42:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:42:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:42:21 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:42:21 --> Helper loaded: form_helper
INFO - 2016-05-16 17:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:42:21 --> Form Validation Class Initialized
INFO - 2016-05-16 17:42:21 --> Controller Class Initialized
INFO - 2016-05-16 17:42:21 --> Model Class Initialized
INFO - 2016-05-16 17:42:21 --> Database Driver Class Initialized
INFO - 2016-05-16 17:42:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-16 17:42:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:42:21 --> Final output sent to browser
DEBUG - 2016-05-16 17:42:21 --> Total execution time: 0.1383
INFO - 2016-05-16 17:42:23 --> Config Class Initialized
INFO - 2016-05-16 17:42:23 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:42:23 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:42:23 --> Utf8 Class Initialized
INFO - 2016-05-16 17:42:23 --> URI Class Initialized
INFO - 2016-05-16 17:42:23 --> Router Class Initialized
INFO - 2016-05-16 17:42:23 --> Output Class Initialized
INFO - 2016-05-16 17:42:23 --> Security Class Initialized
DEBUG - 2016-05-16 17:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:42:23 --> Input Class Initialized
INFO - 2016-05-16 17:42:23 --> Language Class Initialized
INFO - 2016-05-16 17:42:23 --> Loader Class Initialized
INFO - 2016-05-16 17:42:23 --> Helper loaded: url_helper
INFO - 2016-05-16 17:42:23 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:42:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:42:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:42:23 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:42:23 --> Helper loaded: form_helper
INFO - 2016-05-16 17:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:42:23 --> Form Validation Class Initialized
INFO - 2016-05-16 17:42:23 --> Controller Class Initialized
INFO - 2016-05-16 17:42:23 --> Model Class Initialized
INFO - 2016-05-16 17:42:23 --> Database Driver Class Initialized
INFO - 2016-05-16 17:42:23 --> Final output sent to browser
DEBUG - 2016-05-16 17:42:23 --> Total execution time: 0.1458
INFO - 2016-05-16 17:42:34 --> Config Class Initialized
INFO - 2016-05-16 17:42:34 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:42:34 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:42:34 --> Utf8 Class Initialized
INFO - 2016-05-16 17:42:34 --> URI Class Initialized
INFO - 2016-05-16 17:42:34 --> Router Class Initialized
INFO - 2016-05-16 17:42:34 --> Output Class Initialized
INFO - 2016-05-16 17:42:34 --> Security Class Initialized
DEBUG - 2016-05-16 17:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:42:34 --> Input Class Initialized
INFO - 2016-05-16 17:42:34 --> Language Class Initialized
INFO - 2016-05-16 17:42:34 --> Loader Class Initialized
INFO - 2016-05-16 17:42:34 --> Helper loaded: url_helper
INFO - 2016-05-16 17:42:34 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:42:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:42:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:42:34 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:42:34 --> Helper loaded: form_helper
INFO - 2016-05-16 17:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:42:34 --> Form Validation Class Initialized
INFO - 2016-05-16 17:42:34 --> Controller Class Initialized
INFO - 2016-05-16 17:42:34 --> Model Class Initialized
INFO - 2016-05-16 17:42:34 --> Database Driver Class Initialized
INFO - 2016-05-16 17:42:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-16 17:42:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:42:34 --> Final output sent to browser
DEBUG - 2016-05-16 17:42:34 --> Total execution time: 0.0944
INFO - 2016-05-16 17:48:19 --> Config Class Initialized
INFO - 2016-05-16 17:48:19 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:48:19 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:48:19 --> Utf8 Class Initialized
INFO - 2016-05-16 17:48:19 --> URI Class Initialized
INFO - 2016-05-16 17:48:19 --> Router Class Initialized
INFO - 2016-05-16 17:48:19 --> Output Class Initialized
INFO - 2016-05-16 17:48:19 --> Security Class Initialized
DEBUG - 2016-05-16 17:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:48:19 --> Input Class Initialized
INFO - 2016-05-16 17:48:19 --> Language Class Initialized
INFO - 2016-05-16 17:48:19 --> Loader Class Initialized
INFO - 2016-05-16 17:48:19 --> Helper loaded: url_helper
INFO - 2016-05-16 17:48:19 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:48:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:48:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:48:19 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:48:19 --> Helper loaded: form_helper
INFO - 2016-05-16 17:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:48:19 --> Form Validation Class Initialized
INFO - 2016-05-16 17:48:19 --> Controller Class Initialized
INFO - 2016-05-16 17:48:19 --> Model Class Initialized
INFO - 2016-05-16 17:48:19 --> Database Driver Class Initialized
INFO - 2016-05-16 17:48:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-16 17:48:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:48:19 --> Final output sent to browser
DEBUG - 2016-05-16 17:48:19 --> Total execution time: 0.0798
INFO - 2016-05-16 17:48:21 --> Config Class Initialized
INFO - 2016-05-16 17:48:21 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:48:21 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:48:21 --> Utf8 Class Initialized
INFO - 2016-05-16 17:48:21 --> URI Class Initialized
INFO - 2016-05-16 17:48:21 --> Router Class Initialized
INFO - 2016-05-16 17:48:21 --> Output Class Initialized
INFO - 2016-05-16 17:48:21 --> Security Class Initialized
DEBUG - 2016-05-16 17:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:48:21 --> Input Class Initialized
INFO - 2016-05-16 17:48:21 --> Language Class Initialized
INFO - 2016-05-16 17:48:21 --> Loader Class Initialized
INFO - 2016-05-16 17:48:21 --> Helper loaded: url_helper
INFO - 2016-05-16 17:48:21 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:48:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:48:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:48:21 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:48:21 --> Helper loaded: form_helper
INFO - 2016-05-16 17:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:48:21 --> Form Validation Class Initialized
INFO - 2016-05-16 17:48:21 --> Controller Class Initialized
INFO - 2016-05-16 17:48:21 --> Model Class Initialized
INFO - 2016-05-16 17:48:21 --> Database Driver Class Initialized
ERROR - 2016-05-16 17:48:22 --> Severity: Notice --> Undefined variable: idAlbaran C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Mostrar.php 84
ERROR - 2016-05-16 17:48:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT a.idCliente, a.nombre_cliente 'nombre', a.nif, a.direccion, a.localidad, a.cp, p.nombre 'provincia' FROM albaran a INNER JOIN provincia p ON p.idProvincia=a.idProvincia WHERE a.idAlbaran =  
INFO - 2016-05-16 17:48:22 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-16 17:50:36 --> Config Class Initialized
INFO - 2016-05-16 17:50:36 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:50:36 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:50:36 --> Utf8 Class Initialized
INFO - 2016-05-16 17:50:36 --> URI Class Initialized
INFO - 2016-05-16 17:50:36 --> Router Class Initialized
INFO - 2016-05-16 17:50:36 --> Output Class Initialized
INFO - 2016-05-16 17:50:36 --> Security Class Initialized
DEBUG - 2016-05-16 17:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:50:36 --> Input Class Initialized
INFO - 2016-05-16 17:50:36 --> Language Class Initialized
INFO - 2016-05-16 17:50:36 --> Loader Class Initialized
INFO - 2016-05-16 17:50:36 --> Helper loaded: url_helper
INFO - 2016-05-16 17:50:36 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:50:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:50:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:50:36 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:50:36 --> Helper loaded: form_helper
INFO - 2016-05-16 17:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:50:36 --> Form Validation Class Initialized
INFO - 2016-05-16 17:50:36 --> Controller Class Initialized
INFO - 2016-05-16 17:50:36 --> Model Class Initialized
INFO - 2016-05-16 17:50:36 --> Database Driver Class Initialized
ERROR - 2016-05-16 17:50:36 --> Query error: Unknown column 'a.idProvincia' in 'on clause' - Invalid query: SELECT f.idCliente, f.nombre_cliente 'nombre', f.nif, f.direccion, f.localidad, f.cp, p.nombre 'provincia' FROM factura f INNER JOIN provincia p ON p.idProvincia=a.idProvincia WHERE f.idFactura = 10 
INFO - 2016-05-16 17:50:36 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-16 17:50:47 --> Config Class Initialized
INFO - 2016-05-16 17:50:47 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:50:47 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:50:47 --> Utf8 Class Initialized
INFO - 2016-05-16 17:50:47 --> URI Class Initialized
INFO - 2016-05-16 17:50:47 --> Router Class Initialized
INFO - 2016-05-16 17:50:47 --> Output Class Initialized
INFO - 2016-05-16 17:50:47 --> Security Class Initialized
DEBUG - 2016-05-16 17:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:50:47 --> Input Class Initialized
INFO - 2016-05-16 17:50:47 --> Language Class Initialized
INFO - 2016-05-16 17:50:47 --> Loader Class Initialized
INFO - 2016-05-16 17:50:47 --> Helper loaded: url_helper
INFO - 2016-05-16 17:50:47 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:50:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:50:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:50:47 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:50:48 --> Helper loaded: form_helper
INFO - 2016-05-16 17:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:50:48 --> Form Validation Class Initialized
INFO - 2016-05-16 17:50:48 --> Controller Class Initialized
INFO - 2016-05-16 17:50:48 --> Model Class Initialized
INFO - 2016-05-16 17:50:48 --> Database Driver Class Initialized
INFO - 2016-05-16 17:50:48 --> Final output sent to browser
DEBUG - 2016-05-16 17:50:48 --> Total execution time: 0.1276
INFO - 2016-05-16 17:56:27 --> Config Class Initialized
INFO - 2016-05-16 17:56:27 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:56:27 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:56:27 --> Utf8 Class Initialized
INFO - 2016-05-16 17:56:27 --> URI Class Initialized
DEBUG - 2016-05-16 17:56:27 --> No URI present. Default controller set.
INFO - 2016-05-16 17:56:27 --> Router Class Initialized
INFO - 2016-05-16 17:56:27 --> Output Class Initialized
INFO - 2016-05-16 17:56:27 --> Security Class Initialized
DEBUG - 2016-05-16 17:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:56:27 --> Input Class Initialized
INFO - 2016-05-16 17:56:27 --> Language Class Initialized
INFO - 2016-05-16 17:56:27 --> Loader Class Initialized
INFO - 2016-05-16 17:56:27 --> Helper loaded: url_helper
INFO - 2016-05-16 17:56:27 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:56:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:56:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:56:27 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:56:27 --> Helper loaded: form_helper
INFO - 2016-05-16 17:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:56:27 --> Form Validation Class Initialized
INFO - 2016-05-16 17:56:27 --> Controller Class Initialized
INFO - 2016-05-16 17:56:27 --> Model Class Initialized
INFO - 2016-05-16 17:56:27 --> Database Driver Class Initialized
INFO - 2016-05-16 17:56:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-16 17:56:27 --> Pagination Class Initialized
DEBUG - 2016-05-16 17:56:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-16 17:56:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-16 17:56:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:56:27 --> Final output sent to browser
DEBUG - 2016-05-16 17:56:27 --> Total execution time: 0.0904
INFO - 2016-05-16 17:56:29 --> Config Class Initialized
INFO - 2016-05-16 17:56:29 --> Hooks Class Initialized
DEBUG - 2016-05-16 17:56:29 --> UTF-8 Support Enabled
INFO - 2016-05-16 17:56:29 --> Utf8 Class Initialized
INFO - 2016-05-16 17:56:29 --> URI Class Initialized
INFO - 2016-05-16 17:56:29 --> Router Class Initialized
INFO - 2016-05-16 17:56:29 --> Output Class Initialized
INFO - 2016-05-16 17:56:29 --> Security Class Initialized
DEBUG - 2016-05-16 17:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 17:56:29 --> Input Class Initialized
INFO - 2016-05-16 17:56:29 --> Language Class Initialized
INFO - 2016-05-16 17:56:29 --> Loader Class Initialized
INFO - 2016-05-16 17:56:29 --> Helper loaded: url_helper
INFO - 2016-05-16 17:56:29 --> Helper loaded: sesion_helper
INFO - 2016-05-16 17:56:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 17:56:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 17:56:29 --> Helper loaded: redondear_helper
INFO - 2016-05-16 17:56:29 --> Helper loaded: form_helper
INFO - 2016-05-16 17:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 17:56:29 --> Form Validation Class Initialized
INFO - 2016-05-16 17:56:29 --> Controller Class Initialized
INFO - 2016-05-16 17:56:29 --> Model Class Initialized
INFO - 2016-05-16 17:56:29 --> Database Driver Class Initialized
INFO - 2016-05-16 17:56:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_carrito.php
INFO - 2016-05-16 17:56:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 17:56:29 --> Final output sent to browser
DEBUG - 2016-05-16 17:56:29 --> Total execution time: 0.1116
INFO - 2016-05-16 18:02:28 --> Config Class Initialized
INFO - 2016-05-16 18:02:28 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:02:28 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:02:28 --> Utf8 Class Initialized
INFO - 2016-05-16 18:02:28 --> URI Class Initialized
INFO - 2016-05-16 18:02:28 --> Router Class Initialized
INFO - 2016-05-16 18:02:28 --> Output Class Initialized
INFO - 2016-05-16 18:02:28 --> Security Class Initialized
DEBUG - 2016-05-16 18:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:02:28 --> Input Class Initialized
INFO - 2016-05-16 18:02:28 --> Language Class Initialized
INFO - 2016-05-16 18:02:28 --> Loader Class Initialized
INFO - 2016-05-16 18:02:28 --> Helper loaded: url_helper
INFO - 2016-05-16 18:02:28 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:02:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:02:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:02:28 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:02:28 --> Helper loaded: form_helper
INFO - 2016-05-16 18:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:02:28 --> Form Validation Class Initialized
INFO - 2016-05-16 18:02:28 --> Controller Class Initialized
INFO - 2016-05-16 18:02:28 --> Model Class Initialized
INFO - 2016-05-16 18:02:28 --> Database Driver Class Initialized
ERROR - 2016-05-16 18:02:28 --> Severity: Error --> Call to undefined method PDF::CreaFactura() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Mostrar.php 90
INFO - 2016-05-16 18:04:26 --> Config Class Initialized
INFO - 2016-05-16 18:04:26 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:04:26 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:04:26 --> Utf8 Class Initialized
INFO - 2016-05-16 18:04:26 --> URI Class Initialized
INFO - 2016-05-16 18:04:26 --> Router Class Initialized
INFO - 2016-05-16 18:04:26 --> Output Class Initialized
INFO - 2016-05-16 18:04:26 --> Security Class Initialized
DEBUG - 2016-05-16 18:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:04:26 --> Input Class Initialized
INFO - 2016-05-16 18:04:26 --> Language Class Initialized
INFO - 2016-05-16 18:04:26 --> Loader Class Initialized
INFO - 2016-05-16 18:04:26 --> Helper loaded: url_helper
INFO - 2016-05-16 18:04:26 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:04:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:04:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:04:26 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:04:26 --> Helper loaded: form_helper
INFO - 2016-05-16 18:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:04:26 --> Form Validation Class Initialized
INFO - 2016-05-16 18:04:26 --> Controller Class Initialized
INFO - 2016-05-16 18:04:26 --> Model Class Initialized
INFO - 2016-05-16 18:04:26 --> Database Driver Class Initialized
INFO - 2016-05-16 18:04:26 --> Final output sent to browser
DEBUG - 2016-05-16 18:04:26 --> Total execution time: 0.1234
INFO - 2016-05-16 18:08:43 --> Config Class Initialized
INFO - 2016-05-16 18:08:43 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:08:43 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:08:43 --> Utf8 Class Initialized
INFO - 2016-05-16 18:08:43 --> URI Class Initialized
INFO - 2016-05-16 18:08:43 --> Router Class Initialized
INFO - 2016-05-16 18:08:43 --> Output Class Initialized
INFO - 2016-05-16 18:08:43 --> Security Class Initialized
DEBUG - 2016-05-16 18:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:08:43 --> Input Class Initialized
INFO - 2016-05-16 18:08:43 --> Language Class Initialized
INFO - 2016-05-16 18:08:43 --> Loader Class Initialized
INFO - 2016-05-16 18:08:43 --> Helper loaded: url_helper
INFO - 2016-05-16 18:08:43 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:08:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:08:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:08:43 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:08:43 --> Helper loaded: form_helper
INFO - 2016-05-16 18:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:08:43 --> Form Validation Class Initialized
INFO - 2016-05-16 18:08:43 --> Controller Class Initialized
INFO - 2016-05-16 18:08:43 --> Model Class Initialized
INFO - 2016-05-16 18:08:43 --> Database Driver Class Initialized
INFO - 2016-05-16 18:08:43 --> Final output sent to browser
DEBUG - 2016-05-16 18:08:43 --> Total execution time: 0.1354
INFO - 2016-05-16 18:10:26 --> Config Class Initialized
INFO - 2016-05-16 18:10:26 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:10:26 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:10:26 --> Utf8 Class Initialized
INFO - 2016-05-16 18:10:26 --> URI Class Initialized
INFO - 2016-05-16 18:10:26 --> Router Class Initialized
INFO - 2016-05-16 18:10:26 --> Output Class Initialized
INFO - 2016-05-16 18:10:26 --> Security Class Initialized
DEBUG - 2016-05-16 18:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:10:26 --> Input Class Initialized
INFO - 2016-05-16 18:10:26 --> Language Class Initialized
INFO - 2016-05-16 18:10:26 --> Loader Class Initialized
INFO - 2016-05-16 18:10:26 --> Helper loaded: url_helper
INFO - 2016-05-16 18:10:26 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:10:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:10:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:10:26 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:10:26 --> Helper loaded: form_helper
INFO - 2016-05-16 18:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:10:26 --> Form Validation Class Initialized
INFO - 2016-05-16 18:10:26 --> Controller Class Initialized
INFO - 2016-05-16 18:10:26 --> Model Class Initialized
INFO - 2016-05-16 18:10:26 --> Database Driver Class Initialized
INFO - 2016-05-16 18:10:26 --> Final output sent to browser
DEBUG - 2016-05-16 18:10:26 --> Total execution time: 0.1606
INFO - 2016-05-16 18:10:41 --> Config Class Initialized
INFO - 2016-05-16 18:10:41 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:10:41 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:10:41 --> Utf8 Class Initialized
INFO - 2016-05-16 18:10:41 --> URI Class Initialized
INFO - 2016-05-16 18:10:41 --> Router Class Initialized
INFO - 2016-05-16 18:10:41 --> Output Class Initialized
INFO - 2016-05-16 18:10:41 --> Security Class Initialized
DEBUG - 2016-05-16 18:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:10:41 --> Input Class Initialized
INFO - 2016-05-16 18:10:41 --> Language Class Initialized
INFO - 2016-05-16 18:10:41 --> Loader Class Initialized
INFO - 2016-05-16 18:10:41 --> Helper loaded: url_helper
INFO - 2016-05-16 18:10:41 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:10:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:10:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:10:41 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:10:41 --> Helper loaded: form_helper
INFO - 2016-05-16 18:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:10:41 --> Form Validation Class Initialized
INFO - 2016-05-16 18:10:41 --> Controller Class Initialized
INFO - 2016-05-16 18:10:41 --> Model Class Initialized
INFO - 2016-05-16 18:10:41 --> Database Driver Class Initialized
INFO - 2016-05-16 18:10:41 --> Final output sent to browser
DEBUG - 2016-05-16 18:10:41 --> Total execution time: 0.1650
INFO - 2016-05-16 18:10:55 --> Config Class Initialized
INFO - 2016-05-16 18:10:55 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:10:55 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:10:55 --> Utf8 Class Initialized
INFO - 2016-05-16 18:10:55 --> URI Class Initialized
INFO - 2016-05-16 18:10:55 --> Router Class Initialized
INFO - 2016-05-16 18:10:55 --> Output Class Initialized
INFO - 2016-05-16 18:10:55 --> Security Class Initialized
DEBUG - 2016-05-16 18:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:10:55 --> Input Class Initialized
INFO - 2016-05-16 18:10:55 --> Language Class Initialized
INFO - 2016-05-16 18:10:55 --> Loader Class Initialized
INFO - 2016-05-16 18:10:55 --> Helper loaded: url_helper
INFO - 2016-05-16 18:10:55 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:10:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:10:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:10:55 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:10:55 --> Helper loaded: form_helper
INFO - 2016-05-16 18:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:10:55 --> Form Validation Class Initialized
INFO - 2016-05-16 18:10:55 --> Controller Class Initialized
INFO - 2016-05-16 18:10:55 --> Model Class Initialized
INFO - 2016-05-16 18:10:55 --> Database Driver Class Initialized
INFO - 2016-05-16 18:10:55 --> Final output sent to browser
DEBUG - 2016-05-16 18:10:55 --> Total execution time: 0.1465
INFO - 2016-05-16 18:11:00 --> Config Class Initialized
INFO - 2016-05-16 18:11:00 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:11:00 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:11:00 --> Utf8 Class Initialized
INFO - 2016-05-16 18:11:00 --> URI Class Initialized
INFO - 2016-05-16 18:11:00 --> Router Class Initialized
INFO - 2016-05-16 18:11:00 --> Output Class Initialized
INFO - 2016-05-16 18:11:00 --> Security Class Initialized
DEBUG - 2016-05-16 18:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:11:00 --> Input Class Initialized
INFO - 2016-05-16 18:11:00 --> Language Class Initialized
INFO - 2016-05-16 18:11:00 --> Loader Class Initialized
INFO - 2016-05-16 18:11:00 --> Helper loaded: url_helper
INFO - 2016-05-16 18:11:00 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:11:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:11:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:11:00 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:11:00 --> Helper loaded: form_helper
INFO - 2016-05-16 18:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:11:00 --> Form Validation Class Initialized
INFO - 2016-05-16 18:11:00 --> Controller Class Initialized
INFO - 2016-05-16 18:11:00 --> Model Class Initialized
INFO - 2016-05-16 18:11:00 --> Database Driver Class Initialized
INFO - 2016-05-16 18:11:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-16 18:11:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 18:11:00 --> Final output sent to browser
DEBUG - 2016-05-16 18:11:00 --> Total execution time: 0.0955
INFO - 2016-05-16 18:11:01 --> Config Class Initialized
INFO - 2016-05-16 18:11:01 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:11:01 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:11:01 --> Utf8 Class Initialized
INFO - 2016-05-16 18:11:01 --> URI Class Initialized
INFO - 2016-05-16 18:11:01 --> Router Class Initialized
INFO - 2016-05-16 18:11:01 --> Output Class Initialized
INFO - 2016-05-16 18:11:01 --> Security Class Initialized
DEBUG - 2016-05-16 18:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:11:01 --> Input Class Initialized
INFO - 2016-05-16 18:11:01 --> Language Class Initialized
INFO - 2016-05-16 18:11:01 --> Loader Class Initialized
INFO - 2016-05-16 18:11:01 --> Helper loaded: url_helper
INFO - 2016-05-16 18:11:01 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:11:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:11:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:11:01 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:11:01 --> Helper loaded: form_helper
INFO - 2016-05-16 18:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:11:01 --> Form Validation Class Initialized
INFO - 2016-05-16 18:11:01 --> Controller Class Initialized
INFO - 2016-05-16 18:11:01 --> Model Class Initialized
INFO - 2016-05-16 18:11:01 --> Database Driver Class Initialized
INFO - 2016-05-16 18:11:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-16 18:11:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 18:11:01 --> Final output sent to browser
DEBUG - 2016-05-16 18:11:01 --> Total execution time: 0.0917
INFO - 2016-05-16 18:11:04 --> Config Class Initialized
INFO - 2016-05-16 18:11:04 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:11:04 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:11:04 --> Utf8 Class Initialized
INFO - 2016-05-16 18:11:04 --> URI Class Initialized
INFO - 2016-05-16 18:11:04 --> Router Class Initialized
INFO - 2016-05-16 18:11:04 --> Output Class Initialized
INFO - 2016-05-16 18:11:04 --> Security Class Initialized
DEBUG - 2016-05-16 18:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:11:04 --> Input Class Initialized
INFO - 2016-05-16 18:11:04 --> Language Class Initialized
INFO - 2016-05-16 18:11:04 --> Loader Class Initialized
INFO - 2016-05-16 18:11:04 --> Helper loaded: url_helper
INFO - 2016-05-16 18:11:04 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:11:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:11:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:11:04 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:11:04 --> Helper loaded: form_helper
INFO - 2016-05-16 18:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:11:04 --> Form Validation Class Initialized
INFO - 2016-05-16 18:11:04 --> Controller Class Initialized
INFO - 2016-05-16 18:11:04 --> Model Class Initialized
INFO - 2016-05-16 18:11:04 --> Database Driver Class Initialized
INFO - 2016-05-16 18:11:04 --> Final output sent to browser
DEBUG - 2016-05-16 18:11:04 --> Total execution time: 0.1698
INFO - 2016-05-16 18:11:32 --> Config Class Initialized
INFO - 2016-05-16 18:11:32 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:11:32 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:11:32 --> Utf8 Class Initialized
INFO - 2016-05-16 18:11:32 --> URI Class Initialized
INFO - 2016-05-16 18:11:32 --> Router Class Initialized
INFO - 2016-05-16 18:11:32 --> Output Class Initialized
INFO - 2016-05-16 18:11:32 --> Security Class Initialized
DEBUG - 2016-05-16 18:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:11:32 --> Input Class Initialized
INFO - 2016-05-16 18:11:32 --> Language Class Initialized
INFO - 2016-05-16 18:11:32 --> Loader Class Initialized
INFO - 2016-05-16 18:11:32 --> Helper loaded: url_helper
INFO - 2016-05-16 18:11:32 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:11:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:11:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:11:32 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:11:32 --> Helper loaded: form_helper
INFO - 2016-05-16 18:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:11:32 --> Form Validation Class Initialized
INFO - 2016-05-16 18:11:32 --> Controller Class Initialized
INFO - 2016-05-16 18:11:32 --> Model Class Initialized
INFO - 2016-05-16 18:11:32 --> Database Driver Class Initialized
INFO - 2016-05-16 18:11:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-16 18:11:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 18:11:32 --> Final output sent to browser
DEBUG - 2016-05-16 18:11:32 --> Total execution time: 0.1019
INFO - 2016-05-16 18:11:33 --> Config Class Initialized
INFO - 2016-05-16 18:11:33 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:11:33 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:11:33 --> Utf8 Class Initialized
INFO - 2016-05-16 18:11:33 --> URI Class Initialized
INFO - 2016-05-16 18:11:33 --> Router Class Initialized
INFO - 2016-05-16 18:11:33 --> Output Class Initialized
INFO - 2016-05-16 18:11:33 --> Security Class Initialized
DEBUG - 2016-05-16 18:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:11:33 --> Input Class Initialized
INFO - 2016-05-16 18:11:33 --> Language Class Initialized
INFO - 2016-05-16 18:11:33 --> Loader Class Initialized
INFO - 2016-05-16 18:11:33 --> Helper loaded: url_helper
INFO - 2016-05-16 18:11:33 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:11:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:11:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:11:33 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:11:33 --> Helper loaded: form_helper
INFO - 2016-05-16 18:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:11:33 --> Form Validation Class Initialized
INFO - 2016-05-16 18:11:33 --> Controller Class Initialized
INFO - 2016-05-16 18:11:33 --> Model Class Initialized
INFO - 2016-05-16 18:11:34 --> Database Driver Class Initialized
INFO - 2016-05-16 18:11:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-16 18:11:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 18:11:34 --> Final output sent to browser
DEBUG - 2016-05-16 18:11:34 --> Total execution time: 0.0886
INFO - 2016-05-16 18:11:41 --> Config Class Initialized
INFO - 2016-05-16 18:11:41 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:11:41 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:11:41 --> Utf8 Class Initialized
INFO - 2016-05-16 18:11:41 --> URI Class Initialized
INFO - 2016-05-16 18:11:41 --> Router Class Initialized
INFO - 2016-05-16 18:11:41 --> Output Class Initialized
INFO - 2016-05-16 18:11:41 --> Security Class Initialized
DEBUG - 2016-05-16 18:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:11:41 --> Input Class Initialized
INFO - 2016-05-16 18:11:41 --> Language Class Initialized
INFO - 2016-05-16 18:11:41 --> Loader Class Initialized
INFO - 2016-05-16 18:11:41 --> Helper loaded: url_helper
INFO - 2016-05-16 18:11:41 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:11:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:11:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:11:41 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:11:41 --> Helper loaded: form_helper
INFO - 2016-05-16 18:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:11:41 --> Form Validation Class Initialized
INFO - 2016-05-16 18:11:41 --> Controller Class Initialized
INFO - 2016-05-16 18:11:41 --> Model Class Initialized
INFO - 2016-05-16 18:11:41 --> Database Driver Class Initialized
INFO - 2016-05-16 18:11:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-16 18:11:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 18:11:41 --> Final output sent to browser
DEBUG - 2016-05-16 18:11:41 --> Total execution time: 0.1235
INFO - 2016-05-16 18:11:47 --> Config Class Initialized
INFO - 2016-05-16 18:11:47 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:11:47 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:11:47 --> Utf8 Class Initialized
INFO - 2016-05-16 18:11:47 --> URI Class Initialized
INFO - 2016-05-16 18:11:47 --> Router Class Initialized
INFO - 2016-05-16 18:11:47 --> Output Class Initialized
INFO - 2016-05-16 18:11:47 --> Security Class Initialized
DEBUG - 2016-05-16 18:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:11:47 --> Input Class Initialized
INFO - 2016-05-16 18:11:47 --> Language Class Initialized
INFO - 2016-05-16 18:11:47 --> Loader Class Initialized
INFO - 2016-05-16 18:11:47 --> Helper loaded: url_helper
INFO - 2016-05-16 18:11:47 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:11:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:11:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:11:47 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:11:47 --> Helper loaded: form_helper
INFO - 2016-05-16 18:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:11:47 --> Form Validation Class Initialized
INFO - 2016-05-16 18:11:47 --> Controller Class Initialized
INFO - 2016-05-16 18:11:47 --> Model Class Initialized
INFO - 2016-05-16 18:11:47 --> Database Driver Class Initialized
INFO - 2016-05-16 18:11:47 --> Final output sent to browser
DEBUG - 2016-05-16 18:11:47 --> Total execution time: 0.1471
INFO - 2016-05-16 18:12:06 --> Config Class Initialized
INFO - 2016-05-16 18:12:06 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:12:06 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:12:06 --> Utf8 Class Initialized
INFO - 2016-05-16 18:12:06 --> URI Class Initialized
INFO - 2016-05-16 18:12:06 --> Router Class Initialized
INFO - 2016-05-16 18:12:06 --> Output Class Initialized
INFO - 2016-05-16 18:12:06 --> Security Class Initialized
DEBUG - 2016-05-16 18:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:12:06 --> Input Class Initialized
INFO - 2016-05-16 18:12:06 --> Language Class Initialized
INFO - 2016-05-16 18:12:06 --> Loader Class Initialized
INFO - 2016-05-16 18:12:06 --> Helper loaded: url_helper
INFO - 2016-05-16 18:12:06 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:12:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:12:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:12:06 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:12:06 --> Helper loaded: form_helper
INFO - 2016-05-16 18:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:12:06 --> Form Validation Class Initialized
INFO - 2016-05-16 18:12:06 --> Controller Class Initialized
INFO - 2016-05-16 18:12:06 --> Model Class Initialized
INFO - 2016-05-16 18:12:06 --> Database Driver Class Initialized
INFO - 2016-05-16 18:12:06 --> Final output sent to browser
DEBUG - 2016-05-16 18:12:06 --> Total execution time: 0.1527
INFO - 2016-05-16 18:12:28 --> Config Class Initialized
INFO - 2016-05-16 18:12:28 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:12:28 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:12:28 --> Utf8 Class Initialized
INFO - 2016-05-16 18:12:28 --> URI Class Initialized
INFO - 2016-05-16 18:12:28 --> Router Class Initialized
INFO - 2016-05-16 18:12:28 --> Output Class Initialized
INFO - 2016-05-16 18:12:28 --> Security Class Initialized
DEBUG - 2016-05-16 18:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:12:28 --> Input Class Initialized
INFO - 2016-05-16 18:12:28 --> Language Class Initialized
INFO - 2016-05-16 18:12:28 --> Loader Class Initialized
INFO - 2016-05-16 18:12:28 --> Helper loaded: url_helper
INFO - 2016-05-16 18:12:28 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:12:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:12:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:12:28 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:12:28 --> Helper loaded: form_helper
INFO - 2016-05-16 18:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:12:28 --> Form Validation Class Initialized
INFO - 2016-05-16 18:12:28 --> Controller Class Initialized
INFO - 2016-05-16 18:12:28 --> Model Class Initialized
INFO - 2016-05-16 18:12:28 --> Database Driver Class Initialized
INFO - 2016-05-16 18:12:28 --> Final output sent to browser
DEBUG - 2016-05-16 18:12:28 --> Total execution time: 0.1460
INFO - 2016-05-16 18:13:06 --> Config Class Initialized
INFO - 2016-05-16 18:13:06 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:13:06 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:13:06 --> Utf8 Class Initialized
INFO - 2016-05-16 18:13:06 --> URI Class Initialized
INFO - 2016-05-16 18:13:06 --> Router Class Initialized
INFO - 2016-05-16 18:13:06 --> Output Class Initialized
INFO - 2016-05-16 18:13:06 --> Security Class Initialized
DEBUG - 2016-05-16 18:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:13:06 --> Input Class Initialized
INFO - 2016-05-16 18:13:06 --> Language Class Initialized
INFO - 2016-05-16 18:13:06 --> Loader Class Initialized
INFO - 2016-05-16 18:13:06 --> Helper loaded: url_helper
INFO - 2016-05-16 18:13:06 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:13:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:13:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:13:06 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:13:06 --> Helper loaded: form_helper
INFO - 2016-05-16 18:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:13:06 --> Form Validation Class Initialized
INFO - 2016-05-16 18:13:06 --> Controller Class Initialized
INFO - 2016-05-16 18:13:06 --> Model Class Initialized
INFO - 2016-05-16 18:13:06 --> Database Driver Class Initialized
INFO - 2016-05-16 18:13:06 --> Final output sent to browser
DEBUG - 2016-05-16 18:13:06 --> Total execution time: 0.1497
INFO - 2016-05-16 18:13:29 --> Config Class Initialized
INFO - 2016-05-16 18:13:29 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:13:29 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:13:29 --> Utf8 Class Initialized
INFO - 2016-05-16 18:13:29 --> URI Class Initialized
INFO - 2016-05-16 18:13:29 --> Router Class Initialized
INFO - 2016-05-16 18:13:29 --> Output Class Initialized
INFO - 2016-05-16 18:13:29 --> Security Class Initialized
DEBUG - 2016-05-16 18:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:13:29 --> Input Class Initialized
INFO - 2016-05-16 18:13:29 --> Language Class Initialized
INFO - 2016-05-16 18:13:29 --> Loader Class Initialized
INFO - 2016-05-16 18:13:29 --> Helper loaded: url_helper
INFO - 2016-05-16 18:13:29 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:13:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:13:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:13:29 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:13:29 --> Helper loaded: form_helper
INFO - 2016-05-16 18:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:13:29 --> Form Validation Class Initialized
INFO - 2016-05-16 18:13:29 --> Controller Class Initialized
INFO - 2016-05-16 18:13:29 --> Model Class Initialized
INFO - 2016-05-16 18:13:29 --> Database Driver Class Initialized
INFO - 2016-05-16 18:13:30 --> Final output sent to browser
DEBUG - 2016-05-16 18:13:30 --> Total execution time: 0.1448
INFO - 2016-05-16 18:13:58 --> Config Class Initialized
INFO - 2016-05-16 18:13:58 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:13:58 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:13:58 --> Utf8 Class Initialized
INFO - 2016-05-16 18:13:58 --> URI Class Initialized
INFO - 2016-05-16 18:13:58 --> Router Class Initialized
INFO - 2016-05-16 18:13:58 --> Output Class Initialized
INFO - 2016-05-16 18:13:58 --> Security Class Initialized
DEBUG - 2016-05-16 18:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:13:58 --> Input Class Initialized
INFO - 2016-05-16 18:13:58 --> Language Class Initialized
INFO - 2016-05-16 18:13:58 --> Loader Class Initialized
INFO - 2016-05-16 18:13:58 --> Helper loaded: url_helper
INFO - 2016-05-16 18:13:58 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:13:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:13:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:13:58 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:13:58 --> Helper loaded: form_helper
INFO - 2016-05-16 18:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:13:58 --> Form Validation Class Initialized
INFO - 2016-05-16 18:13:58 --> Controller Class Initialized
INFO - 2016-05-16 18:13:58 --> Model Class Initialized
INFO - 2016-05-16 18:13:58 --> Database Driver Class Initialized
INFO - 2016-05-16 18:13:58 --> Final output sent to browser
DEBUG - 2016-05-16 18:13:58 --> Total execution time: 0.1657
INFO - 2016-05-16 18:14:55 --> Config Class Initialized
INFO - 2016-05-16 18:14:55 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:14:55 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:14:55 --> Utf8 Class Initialized
INFO - 2016-05-16 18:14:55 --> URI Class Initialized
INFO - 2016-05-16 18:14:55 --> Router Class Initialized
INFO - 2016-05-16 18:14:55 --> Output Class Initialized
INFO - 2016-05-16 18:14:55 --> Security Class Initialized
DEBUG - 2016-05-16 18:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:14:55 --> Input Class Initialized
INFO - 2016-05-16 18:14:55 --> Language Class Initialized
INFO - 2016-05-16 18:14:55 --> Loader Class Initialized
INFO - 2016-05-16 18:14:55 --> Helper loaded: url_helper
INFO - 2016-05-16 18:14:55 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:14:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:14:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:14:55 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:14:55 --> Helper loaded: form_helper
INFO - 2016-05-16 18:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:14:55 --> Form Validation Class Initialized
INFO - 2016-05-16 18:14:55 --> Controller Class Initialized
INFO - 2016-05-16 18:14:55 --> Model Class Initialized
INFO - 2016-05-16 18:14:55 --> Database Driver Class Initialized
INFO - 2016-05-16 18:14:55 --> Final output sent to browser
DEBUG - 2016-05-16 18:14:55 --> Total execution time: 0.1440
INFO - 2016-05-16 18:15:28 --> Config Class Initialized
INFO - 2016-05-16 18:15:28 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:15:28 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:15:28 --> Utf8 Class Initialized
INFO - 2016-05-16 18:15:28 --> URI Class Initialized
INFO - 2016-05-16 18:15:28 --> Router Class Initialized
INFO - 2016-05-16 18:15:28 --> Output Class Initialized
INFO - 2016-05-16 18:15:28 --> Security Class Initialized
DEBUG - 2016-05-16 18:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:15:28 --> Input Class Initialized
INFO - 2016-05-16 18:15:28 --> Language Class Initialized
INFO - 2016-05-16 18:15:28 --> Loader Class Initialized
INFO - 2016-05-16 18:15:28 --> Helper loaded: url_helper
INFO - 2016-05-16 18:15:28 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:15:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:15:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:15:28 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:15:28 --> Helper loaded: form_helper
INFO - 2016-05-16 18:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:15:28 --> Form Validation Class Initialized
INFO - 2016-05-16 18:15:28 --> Controller Class Initialized
INFO - 2016-05-16 18:15:28 --> Model Class Initialized
INFO - 2016-05-16 18:15:28 --> Database Driver Class Initialized
INFO - 2016-05-16 18:15:28 --> Final output sent to browser
DEBUG - 2016-05-16 18:15:28 --> Total execution time: 0.1419
INFO - 2016-05-16 18:15:43 --> Config Class Initialized
INFO - 2016-05-16 18:15:43 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:15:43 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:15:43 --> Utf8 Class Initialized
INFO - 2016-05-16 18:15:43 --> URI Class Initialized
INFO - 2016-05-16 18:15:43 --> Router Class Initialized
INFO - 2016-05-16 18:15:43 --> Output Class Initialized
INFO - 2016-05-16 18:15:43 --> Security Class Initialized
DEBUG - 2016-05-16 18:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:15:43 --> Input Class Initialized
INFO - 2016-05-16 18:15:43 --> Language Class Initialized
INFO - 2016-05-16 18:15:43 --> Loader Class Initialized
INFO - 2016-05-16 18:15:43 --> Helper loaded: url_helper
INFO - 2016-05-16 18:15:43 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:15:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:15:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:15:43 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:15:43 --> Helper loaded: form_helper
INFO - 2016-05-16 18:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:15:43 --> Form Validation Class Initialized
INFO - 2016-05-16 18:15:43 --> Controller Class Initialized
INFO - 2016-05-16 18:15:43 --> Model Class Initialized
INFO - 2016-05-16 18:15:43 --> Database Driver Class Initialized
INFO - 2016-05-16 18:15:43 --> Final output sent to browser
DEBUG - 2016-05-16 18:15:43 --> Total execution time: 0.1676
INFO - 2016-05-16 18:18:24 --> Config Class Initialized
INFO - 2016-05-16 18:18:24 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:18:24 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:18:24 --> Utf8 Class Initialized
INFO - 2016-05-16 18:18:24 --> URI Class Initialized
INFO - 2016-05-16 18:18:24 --> Router Class Initialized
INFO - 2016-05-16 18:18:24 --> Output Class Initialized
INFO - 2016-05-16 18:18:24 --> Security Class Initialized
DEBUG - 2016-05-16 18:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:18:24 --> Input Class Initialized
INFO - 2016-05-16 18:18:24 --> Language Class Initialized
INFO - 2016-05-16 18:18:24 --> Loader Class Initialized
INFO - 2016-05-16 18:18:24 --> Helper loaded: url_helper
INFO - 2016-05-16 18:18:24 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:18:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:18:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:18:24 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:18:24 --> Helper loaded: form_helper
INFO - 2016-05-16 18:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:18:24 --> Form Validation Class Initialized
INFO - 2016-05-16 18:18:24 --> Controller Class Initialized
INFO - 2016-05-16 18:18:24 --> Model Class Initialized
INFO - 2016-05-16 18:18:24 --> Database Driver Class Initialized
ERROR - 2016-05-16 18:18:25 --> Severity: Notice --> Undefined index: descuento C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\libraries\PDF.php 134
ERROR - 2016-05-16 18:18:25 --> Severity: error --> Exception: FPDF error: Some data has already been output, can't send PDF file C:\xampp\htdocs\Proyecto\Alumno\Fuentes\vendor\setasign\fpdf\fpdf.php 271
INFO - 2016-05-16 18:18:35 --> Config Class Initialized
INFO - 2016-05-16 18:18:35 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:18:35 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:18:35 --> Utf8 Class Initialized
INFO - 2016-05-16 18:18:35 --> URI Class Initialized
INFO - 2016-05-16 18:18:35 --> Router Class Initialized
INFO - 2016-05-16 18:18:35 --> Output Class Initialized
INFO - 2016-05-16 18:18:35 --> Security Class Initialized
DEBUG - 2016-05-16 18:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:18:35 --> Input Class Initialized
INFO - 2016-05-16 18:18:35 --> Language Class Initialized
INFO - 2016-05-16 18:18:35 --> Loader Class Initialized
INFO - 2016-05-16 18:18:35 --> Helper loaded: url_helper
INFO - 2016-05-16 18:18:35 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:18:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:18:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:18:35 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:18:35 --> Helper loaded: form_helper
INFO - 2016-05-16 18:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:18:35 --> Form Validation Class Initialized
INFO - 2016-05-16 18:18:35 --> Controller Class Initialized
INFO - 2016-05-16 18:18:35 --> Model Class Initialized
INFO - 2016-05-16 18:18:35 --> Database Driver Class Initialized
INFO - 2016-05-16 18:18:35 --> Final output sent to browser
DEBUG - 2016-05-16 18:18:35 --> Total execution time: 0.1232
INFO - 2016-05-16 18:19:07 --> Config Class Initialized
INFO - 2016-05-16 18:19:07 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:19:07 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:19:07 --> Utf8 Class Initialized
INFO - 2016-05-16 18:19:07 --> URI Class Initialized
INFO - 2016-05-16 18:19:07 --> Router Class Initialized
INFO - 2016-05-16 18:19:07 --> Output Class Initialized
INFO - 2016-05-16 18:19:07 --> Security Class Initialized
DEBUG - 2016-05-16 18:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:19:07 --> Input Class Initialized
INFO - 2016-05-16 18:19:07 --> Language Class Initialized
INFO - 2016-05-16 18:19:07 --> Loader Class Initialized
INFO - 2016-05-16 18:19:07 --> Helper loaded: url_helper
INFO - 2016-05-16 18:19:07 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:19:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:19:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:19:07 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:19:07 --> Helper loaded: form_helper
INFO - 2016-05-16 18:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:19:07 --> Form Validation Class Initialized
INFO - 2016-05-16 18:19:07 --> Controller Class Initialized
INFO - 2016-05-16 18:19:07 --> Model Class Initialized
INFO - 2016-05-16 18:19:07 --> Database Driver Class Initialized
INFO - 2016-05-16 18:19:07 --> Final output sent to browser
DEBUG - 2016-05-16 18:19:07 --> Total execution time: 0.2459
INFO - 2016-05-16 18:19:28 --> Config Class Initialized
INFO - 2016-05-16 18:19:28 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:19:28 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:19:28 --> Utf8 Class Initialized
INFO - 2016-05-16 18:19:28 --> URI Class Initialized
INFO - 2016-05-16 18:19:28 --> Router Class Initialized
INFO - 2016-05-16 18:19:28 --> Output Class Initialized
INFO - 2016-05-16 18:19:28 --> Security Class Initialized
DEBUG - 2016-05-16 18:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:19:28 --> Input Class Initialized
INFO - 2016-05-16 18:19:28 --> Language Class Initialized
INFO - 2016-05-16 18:19:28 --> Loader Class Initialized
INFO - 2016-05-16 18:19:28 --> Helper loaded: url_helper
INFO - 2016-05-16 18:19:28 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:19:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:19:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:19:28 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:19:28 --> Helper loaded: form_helper
INFO - 2016-05-16 18:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:19:28 --> Form Validation Class Initialized
INFO - 2016-05-16 18:19:28 --> Controller Class Initialized
INFO - 2016-05-16 18:19:28 --> Model Class Initialized
INFO - 2016-05-16 18:19:28 --> Database Driver Class Initialized
INFO - 2016-05-16 18:19:28 --> Final output sent to browser
DEBUG - 2016-05-16 18:19:28 --> Total execution time: 0.1259
INFO - 2016-05-16 18:20:12 --> Config Class Initialized
INFO - 2016-05-16 18:20:12 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:20:12 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:20:12 --> Utf8 Class Initialized
INFO - 2016-05-16 18:20:12 --> URI Class Initialized
INFO - 2016-05-16 18:20:12 --> Router Class Initialized
INFO - 2016-05-16 18:20:12 --> Output Class Initialized
INFO - 2016-05-16 18:20:12 --> Security Class Initialized
DEBUG - 2016-05-16 18:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:20:12 --> Input Class Initialized
INFO - 2016-05-16 18:20:12 --> Language Class Initialized
INFO - 2016-05-16 18:20:12 --> Loader Class Initialized
INFO - 2016-05-16 18:20:12 --> Helper loaded: url_helper
INFO - 2016-05-16 18:20:12 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:20:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:20:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:20:12 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:20:12 --> Helper loaded: form_helper
INFO - 2016-05-16 18:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:20:12 --> Form Validation Class Initialized
INFO - 2016-05-16 18:20:12 --> Controller Class Initialized
INFO - 2016-05-16 18:20:12 --> Model Class Initialized
INFO - 2016-05-16 18:20:12 --> Database Driver Class Initialized
INFO - 2016-05-16 18:20:12 --> Final output sent to browser
DEBUG - 2016-05-16 18:20:12 --> Total execution time: 0.1516
INFO - 2016-05-16 18:21:33 --> Config Class Initialized
INFO - 2016-05-16 18:21:33 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:21:33 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:21:33 --> Utf8 Class Initialized
INFO - 2016-05-16 18:21:33 --> URI Class Initialized
INFO - 2016-05-16 18:21:33 --> Router Class Initialized
INFO - 2016-05-16 18:21:33 --> Output Class Initialized
INFO - 2016-05-16 18:21:33 --> Security Class Initialized
DEBUG - 2016-05-16 18:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:21:33 --> Input Class Initialized
INFO - 2016-05-16 18:21:33 --> Language Class Initialized
INFO - 2016-05-16 18:21:33 --> Loader Class Initialized
INFO - 2016-05-16 18:21:33 --> Helper loaded: url_helper
INFO - 2016-05-16 18:21:33 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:21:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:21:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:21:33 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:21:33 --> Helper loaded: form_helper
INFO - 2016-05-16 18:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:21:33 --> Form Validation Class Initialized
INFO - 2016-05-16 18:21:33 --> Controller Class Initialized
INFO - 2016-05-16 18:21:33 --> Model Class Initialized
INFO - 2016-05-16 18:21:33 --> Database Driver Class Initialized
INFO - 2016-05-16 18:21:33 --> Final output sent to browser
DEBUG - 2016-05-16 18:21:33 --> Total execution time: 0.2025
INFO - 2016-05-16 18:23:26 --> Config Class Initialized
INFO - 2016-05-16 18:23:26 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:23:26 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:23:26 --> Utf8 Class Initialized
INFO - 2016-05-16 18:23:26 --> URI Class Initialized
INFO - 2016-05-16 18:23:26 --> Router Class Initialized
INFO - 2016-05-16 18:23:26 --> Output Class Initialized
INFO - 2016-05-16 18:23:26 --> Security Class Initialized
DEBUG - 2016-05-16 18:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:23:26 --> Input Class Initialized
INFO - 2016-05-16 18:23:26 --> Language Class Initialized
INFO - 2016-05-16 18:23:26 --> Loader Class Initialized
INFO - 2016-05-16 18:23:26 --> Helper loaded: url_helper
INFO - 2016-05-16 18:23:26 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:23:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:23:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:23:26 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:23:26 --> Helper loaded: form_helper
INFO - 2016-05-16 18:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:23:26 --> Form Validation Class Initialized
INFO - 2016-05-16 18:23:26 --> Controller Class Initialized
INFO - 2016-05-16 18:23:26 --> Model Class Initialized
INFO - 2016-05-16 18:23:26 --> Database Driver Class Initialized
INFO - 2016-05-16 18:23:26 --> Final output sent to browser
DEBUG - 2016-05-16 18:23:26 --> Total execution time: 0.1986
INFO - 2016-05-16 18:30:57 --> Config Class Initialized
INFO - 2016-05-16 18:30:57 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:30:57 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:30:57 --> Utf8 Class Initialized
INFO - 2016-05-16 18:30:57 --> URI Class Initialized
DEBUG - 2016-05-16 18:30:57 --> No URI present. Default controller set.
INFO - 2016-05-16 18:30:57 --> Router Class Initialized
INFO - 2016-05-16 18:30:57 --> Output Class Initialized
INFO - 2016-05-16 18:30:57 --> Security Class Initialized
DEBUG - 2016-05-16 18:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:30:57 --> Input Class Initialized
INFO - 2016-05-16 18:30:57 --> Language Class Initialized
INFO - 2016-05-16 18:30:57 --> Loader Class Initialized
INFO - 2016-05-16 18:30:57 --> Helper loaded: url_helper
INFO - 2016-05-16 18:30:57 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:30:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:30:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:30:57 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:30:57 --> Helper loaded: form_helper
INFO - 2016-05-16 18:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:30:57 --> Form Validation Class Initialized
INFO - 2016-05-16 18:30:57 --> Controller Class Initialized
INFO - 2016-05-16 18:30:57 --> Model Class Initialized
INFO - 2016-05-16 18:30:57 --> Database Driver Class Initialized
INFO - 2016-05-16 18:30:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-16 18:30:57 --> Pagination Class Initialized
DEBUG - 2016-05-16 18:30:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-16 18:30:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-16 18:30:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 18:30:57 --> Final output sent to browser
DEBUG - 2016-05-16 18:30:57 --> Total execution time: 0.0868
INFO - 2016-05-16 18:31:00 --> Config Class Initialized
INFO - 2016-05-16 18:31:00 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:31:00 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:31:00 --> Utf8 Class Initialized
INFO - 2016-05-16 18:31:00 --> URI Class Initialized
INFO - 2016-05-16 18:31:00 --> Router Class Initialized
INFO - 2016-05-16 18:31:00 --> Output Class Initialized
INFO - 2016-05-16 18:31:00 --> Security Class Initialized
DEBUG - 2016-05-16 18:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:31:00 --> Input Class Initialized
INFO - 2016-05-16 18:31:00 --> Language Class Initialized
INFO - 2016-05-16 18:31:00 --> Loader Class Initialized
INFO - 2016-05-16 18:31:00 --> Helper loaded: url_helper
INFO - 2016-05-16 18:31:00 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:31:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:31:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:31:00 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:31:00 --> Helper loaded: form_helper
INFO - 2016-05-16 18:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:31:00 --> Form Validation Class Initialized
INFO - 2016-05-16 18:31:00 --> Controller Class Initialized
INFO - 2016-05-16 18:31:00 --> Model Class Initialized
INFO - 2016-05-16 18:31:00 --> Database Driver Class Initialized
INFO - 2016-05-16 18:31:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_carrito.php
INFO - 2016-05-16 18:31:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 18:31:00 --> Final output sent to browser
DEBUG - 2016-05-16 18:31:00 --> Total execution time: 0.1167
INFO - 2016-05-16 18:31:01 --> Config Class Initialized
INFO - 2016-05-16 18:31:01 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:31:01 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:31:01 --> Utf8 Class Initialized
INFO - 2016-05-16 18:31:01 --> URI Class Initialized
INFO - 2016-05-16 18:31:01 --> Router Class Initialized
INFO - 2016-05-16 18:31:01 --> Output Class Initialized
INFO - 2016-05-16 18:31:01 --> Security Class Initialized
DEBUG - 2016-05-16 18:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:31:01 --> Input Class Initialized
INFO - 2016-05-16 18:31:01 --> Language Class Initialized
INFO - 2016-05-16 18:31:01 --> Loader Class Initialized
INFO - 2016-05-16 18:31:01 --> Helper loaded: url_helper
INFO - 2016-05-16 18:31:01 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:31:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:31:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:31:01 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:31:01 --> Helper loaded: form_helper
INFO - 2016-05-16 18:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:31:01 --> Form Validation Class Initialized
INFO - 2016-05-16 18:31:01 --> Controller Class Initialized
INFO - 2016-05-16 18:31:01 --> Model Class Initialized
INFO - 2016-05-16 18:31:01 --> Database Driver Class Initialized
INFO - 2016-05-16 18:31:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_venta1.php
INFO - 2016-05-16 18:31:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 18:31:01 --> Final output sent to browser
DEBUG - 2016-05-16 18:31:01 --> Total execution time: 0.1120
INFO - 2016-05-16 18:33:34 --> Config Class Initialized
INFO - 2016-05-16 18:33:34 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:33:34 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:33:34 --> Utf8 Class Initialized
INFO - 2016-05-16 18:33:34 --> URI Class Initialized
INFO - 2016-05-16 18:33:34 --> Router Class Initialized
INFO - 2016-05-16 18:33:34 --> Output Class Initialized
INFO - 2016-05-16 18:33:34 --> Security Class Initialized
DEBUG - 2016-05-16 18:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:33:34 --> Input Class Initialized
INFO - 2016-05-16 18:33:34 --> Language Class Initialized
INFO - 2016-05-16 18:33:34 --> Loader Class Initialized
INFO - 2016-05-16 18:33:34 --> Helper loaded: url_helper
INFO - 2016-05-16 18:33:34 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:33:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:33:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:33:34 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:33:34 --> Helper loaded: form_helper
INFO - 2016-05-16 18:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:33:34 --> Form Validation Class Initialized
INFO - 2016-05-16 18:33:34 --> Controller Class Initialized
INFO - 2016-05-16 18:33:34 --> Model Class Initialized
INFO - 2016-05-16 18:33:34 --> Database Driver Class Initialized
INFO - 2016-05-16 18:33:34 --> Config Class Initialized
INFO - 2016-05-16 18:33:34 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:33:34 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:33:34 --> Utf8 Class Initialized
INFO - 2016-05-16 18:33:34 --> URI Class Initialized
INFO - 2016-05-16 18:33:34 --> Router Class Initialized
INFO - 2016-05-16 18:33:34 --> Output Class Initialized
INFO - 2016-05-16 18:33:34 --> Security Class Initialized
DEBUG - 2016-05-16 18:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:33:34 --> Input Class Initialized
INFO - 2016-05-16 18:33:34 --> Language Class Initialized
INFO - 2016-05-16 18:33:34 --> Loader Class Initialized
INFO - 2016-05-16 18:33:34 --> Helper loaded: url_helper
INFO - 2016-05-16 18:33:34 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:33:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:33:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:33:34 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:33:34 --> Helper loaded: form_helper
INFO - 2016-05-16 18:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:33:34 --> Form Validation Class Initialized
INFO - 2016-05-16 18:33:34 --> Controller Class Initialized
INFO - 2016-05-16 18:33:34 --> Model Class Initialized
INFO - 2016-05-16 18:33:34 --> Database Driver Class Initialized
INFO - 2016-05-16 18:33:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_resumenventa.php
INFO - 2016-05-16 18:33:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 18:33:34 --> Final output sent to browser
DEBUG - 2016-05-16 18:33:34 --> Total execution time: 0.1280
INFO - 2016-05-16 18:33:38 --> Config Class Initialized
INFO - 2016-05-16 18:33:38 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:33:38 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:33:38 --> Utf8 Class Initialized
INFO - 2016-05-16 18:33:38 --> URI Class Initialized
INFO - 2016-05-16 18:33:38 --> Router Class Initialized
INFO - 2016-05-16 18:33:38 --> Output Class Initialized
INFO - 2016-05-16 18:33:38 --> Security Class Initialized
DEBUG - 2016-05-16 18:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:33:38 --> Input Class Initialized
INFO - 2016-05-16 18:33:38 --> Language Class Initialized
INFO - 2016-05-16 18:33:38 --> Loader Class Initialized
INFO - 2016-05-16 18:33:38 --> Helper loaded: url_helper
INFO - 2016-05-16 18:33:38 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:33:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:33:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:33:38 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:33:38 --> Helper loaded: form_helper
INFO - 2016-05-16 18:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:33:38 --> Form Validation Class Initialized
INFO - 2016-05-16 18:33:38 --> Controller Class Initialized
INFO - 2016-05-16 18:33:38 --> Model Class Initialized
INFO - 2016-05-16 18:33:38 --> Database Driver Class Initialized
INFO - 2016-05-16 18:33:38 --> Config Class Initialized
INFO - 2016-05-16 18:33:38 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:33:38 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:33:38 --> Utf8 Class Initialized
INFO - 2016-05-16 18:33:38 --> URI Class Initialized
INFO - 2016-05-16 18:33:38 --> Router Class Initialized
INFO - 2016-05-16 18:33:38 --> Output Class Initialized
INFO - 2016-05-16 18:33:38 --> Security Class Initialized
DEBUG - 2016-05-16 18:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:33:38 --> Input Class Initialized
INFO - 2016-05-16 18:33:38 --> Language Class Initialized
INFO - 2016-05-16 18:33:38 --> Loader Class Initialized
INFO - 2016-05-16 18:33:38 --> Helper loaded: url_helper
INFO - 2016-05-16 18:33:38 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:33:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:33:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:33:38 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:33:38 --> Helper loaded: form_helper
INFO - 2016-05-16 18:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:33:38 --> Form Validation Class Initialized
INFO - 2016-05-16 18:33:38 --> Controller Class Initialized
INFO - 2016-05-16 18:33:38 --> Model Class Initialized
INFO - 2016-05-16 18:33:38 --> Database Driver Class Initialized
INFO - 2016-05-16 18:33:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-16 18:33:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 18:33:38 --> Final output sent to browser
DEBUG - 2016-05-16 18:33:38 --> Total execution time: 0.0923
INFO - 2016-05-16 18:33:41 --> Config Class Initialized
INFO - 2016-05-16 18:33:41 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:33:41 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:33:41 --> Utf8 Class Initialized
INFO - 2016-05-16 18:33:41 --> URI Class Initialized
INFO - 2016-05-16 18:33:41 --> Router Class Initialized
INFO - 2016-05-16 18:33:41 --> Output Class Initialized
INFO - 2016-05-16 18:33:41 --> Security Class Initialized
DEBUG - 2016-05-16 18:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:33:41 --> Input Class Initialized
INFO - 2016-05-16 18:33:41 --> Language Class Initialized
INFO - 2016-05-16 18:33:41 --> Loader Class Initialized
INFO - 2016-05-16 18:33:41 --> Helper loaded: url_helper
INFO - 2016-05-16 18:33:41 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:33:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:33:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:33:41 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:33:41 --> Helper loaded: form_helper
INFO - 2016-05-16 18:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:33:41 --> Form Validation Class Initialized
INFO - 2016-05-16 18:33:41 --> Controller Class Initialized
INFO - 2016-05-16 18:33:41 --> Model Class Initialized
INFO - 2016-05-16 18:33:41 --> Database Driver Class Initialized
INFO - 2016-05-16 18:33:41 --> Final output sent to browser
DEBUG - 2016-05-16 18:33:41 --> Total execution time: 0.1490
INFO - 2016-05-16 18:44:46 --> Config Class Initialized
INFO - 2016-05-16 18:44:46 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:44:46 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:44:46 --> Utf8 Class Initialized
INFO - 2016-05-16 18:44:46 --> URI Class Initialized
INFO - 2016-05-16 18:44:46 --> Router Class Initialized
INFO - 2016-05-16 18:44:46 --> Output Class Initialized
INFO - 2016-05-16 18:44:46 --> Security Class Initialized
DEBUG - 2016-05-16 18:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:44:46 --> Input Class Initialized
INFO - 2016-05-16 18:44:46 --> Language Class Initialized
INFO - 2016-05-16 18:44:46 --> Loader Class Initialized
INFO - 2016-05-16 18:44:46 --> Helper loaded: url_helper
INFO - 2016-05-16 18:44:46 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:44:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:44:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:44:46 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:44:46 --> Helper loaded: form_helper
INFO - 2016-05-16 18:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:44:46 --> Form Validation Class Initialized
INFO - 2016-05-16 18:44:46 --> Controller Class Initialized
INFO - 2016-05-16 18:44:46 --> Model Class Initialized
INFO - 2016-05-16 18:44:46 --> Database Driver Class Initialized
INFO - 2016-05-16 18:44:46 --> Final output sent to browser
DEBUG - 2016-05-16 18:44:46 --> Total execution time: 0.1702
INFO - 2016-05-16 18:45:14 --> Config Class Initialized
INFO - 2016-05-16 18:45:14 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:45:14 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:45:14 --> Utf8 Class Initialized
INFO - 2016-05-16 18:45:14 --> URI Class Initialized
INFO - 2016-05-16 18:45:14 --> Router Class Initialized
INFO - 2016-05-16 18:45:14 --> Output Class Initialized
INFO - 2016-05-16 18:45:14 --> Security Class Initialized
DEBUG - 2016-05-16 18:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:45:14 --> Input Class Initialized
INFO - 2016-05-16 18:45:14 --> Language Class Initialized
INFO - 2016-05-16 18:45:14 --> Loader Class Initialized
INFO - 2016-05-16 18:45:14 --> Helper loaded: url_helper
INFO - 2016-05-16 18:45:14 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:45:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:45:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:45:14 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:45:14 --> Helper loaded: form_helper
INFO - 2016-05-16 18:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:45:14 --> Form Validation Class Initialized
INFO - 2016-05-16 18:45:14 --> Controller Class Initialized
INFO - 2016-05-16 18:45:14 --> Model Class Initialized
INFO - 2016-05-16 18:45:14 --> Database Driver Class Initialized
INFO - 2016-05-16 18:45:14 --> Final output sent to browser
DEBUG - 2016-05-16 18:45:14 --> Total execution time: 0.1945
INFO - 2016-05-16 18:45:46 --> Config Class Initialized
INFO - 2016-05-16 18:45:46 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:45:46 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:45:46 --> Utf8 Class Initialized
INFO - 2016-05-16 18:45:46 --> URI Class Initialized
INFO - 2016-05-16 18:45:46 --> Router Class Initialized
INFO - 2016-05-16 18:45:46 --> Output Class Initialized
INFO - 2016-05-16 18:45:46 --> Security Class Initialized
DEBUG - 2016-05-16 18:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:45:46 --> Input Class Initialized
INFO - 2016-05-16 18:45:46 --> Language Class Initialized
INFO - 2016-05-16 18:45:46 --> Loader Class Initialized
INFO - 2016-05-16 18:45:46 --> Helper loaded: url_helper
INFO - 2016-05-16 18:45:46 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:45:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:45:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:45:46 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:45:46 --> Helper loaded: form_helper
INFO - 2016-05-16 18:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:45:46 --> Form Validation Class Initialized
INFO - 2016-05-16 18:45:46 --> Controller Class Initialized
INFO - 2016-05-16 18:45:46 --> Model Class Initialized
INFO - 2016-05-16 18:45:46 --> Database Driver Class Initialized
INFO - 2016-05-16 18:45:47 --> Final output sent to browser
DEBUG - 2016-05-16 18:45:47 --> Total execution time: 0.1491
INFO - 2016-05-16 18:46:07 --> Config Class Initialized
INFO - 2016-05-16 18:46:07 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:46:07 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:46:07 --> Utf8 Class Initialized
INFO - 2016-05-16 18:46:07 --> URI Class Initialized
INFO - 2016-05-16 18:46:07 --> Router Class Initialized
INFO - 2016-05-16 18:46:07 --> Output Class Initialized
INFO - 2016-05-16 18:46:07 --> Security Class Initialized
DEBUG - 2016-05-16 18:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:46:07 --> Input Class Initialized
INFO - 2016-05-16 18:46:07 --> Language Class Initialized
INFO - 2016-05-16 18:46:07 --> Loader Class Initialized
INFO - 2016-05-16 18:46:07 --> Helper loaded: url_helper
INFO - 2016-05-16 18:46:07 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:46:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:46:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:46:07 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:46:07 --> Helper loaded: form_helper
INFO - 2016-05-16 18:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:46:07 --> Form Validation Class Initialized
INFO - 2016-05-16 18:46:07 --> Controller Class Initialized
INFO - 2016-05-16 18:46:07 --> Model Class Initialized
INFO - 2016-05-16 18:46:07 --> Database Driver Class Initialized
INFO - 2016-05-16 18:46:07 --> Final output sent to browser
DEBUG - 2016-05-16 18:46:07 --> Total execution time: 0.1499
INFO - 2016-05-16 18:47:14 --> Config Class Initialized
INFO - 2016-05-16 18:47:14 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:47:14 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:47:14 --> Utf8 Class Initialized
INFO - 2016-05-16 18:47:14 --> URI Class Initialized
INFO - 2016-05-16 18:47:14 --> Router Class Initialized
INFO - 2016-05-16 18:47:14 --> Output Class Initialized
INFO - 2016-05-16 18:47:14 --> Security Class Initialized
DEBUG - 2016-05-16 18:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:47:14 --> Input Class Initialized
INFO - 2016-05-16 18:47:14 --> Language Class Initialized
INFO - 2016-05-16 18:47:14 --> Loader Class Initialized
INFO - 2016-05-16 18:47:14 --> Helper loaded: url_helper
INFO - 2016-05-16 18:47:14 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:47:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:47:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:47:14 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:47:14 --> Helper loaded: form_helper
INFO - 2016-05-16 18:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:47:14 --> Form Validation Class Initialized
INFO - 2016-05-16 18:47:14 --> Controller Class Initialized
INFO - 2016-05-16 18:47:14 --> Model Class Initialized
INFO - 2016-05-16 18:47:14 --> Database Driver Class Initialized
INFO - 2016-05-16 18:47:14 --> Final output sent to browser
DEBUG - 2016-05-16 18:47:14 --> Total execution time: 0.1238
INFO - 2016-05-16 18:50:28 --> Config Class Initialized
INFO - 2016-05-16 18:50:28 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:50:28 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:50:28 --> Utf8 Class Initialized
INFO - 2016-05-16 18:50:28 --> URI Class Initialized
INFO - 2016-05-16 18:50:28 --> Router Class Initialized
INFO - 2016-05-16 18:50:28 --> Output Class Initialized
INFO - 2016-05-16 18:50:28 --> Security Class Initialized
DEBUG - 2016-05-16 18:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:50:28 --> Input Class Initialized
INFO - 2016-05-16 18:50:28 --> Language Class Initialized
INFO - 2016-05-16 18:50:28 --> Loader Class Initialized
INFO - 2016-05-16 18:50:28 --> Helper loaded: url_helper
INFO - 2016-05-16 18:50:28 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:50:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:50:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:50:28 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:50:28 --> Helper loaded: form_helper
INFO - 2016-05-16 18:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:50:28 --> Form Validation Class Initialized
INFO - 2016-05-16 18:50:28 --> Controller Class Initialized
INFO - 2016-05-16 18:50:28 --> Model Class Initialized
INFO - 2016-05-16 18:50:28 --> Database Driver Class Initialized
INFO - 2016-05-16 18:50:28 --> Final output sent to browser
DEBUG - 2016-05-16 18:50:28 --> Total execution time: 0.1623
INFO - 2016-05-16 18:50:52 --> Config Class Initialized
INFO - 2016-05-16 18:50:52 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:50:52 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:50:52 --> Utf8 Class Initialized
INFO - 2016-05-16 18:50:52 --> URI Class Initialized
INFO - 2016-05-16 18:50:52 --> Router Class Initialized
INFO - 2016-05-16 18:50:52 --> Output Class Initialized
INFO - 2016-05-16 18:50:52 --> Security Class Initialized
DEBUG - 2016-05-16 18:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:50:52 --> Input Class Initialized
INFO - 2016-05-16 18:50:52 --> Language Class Initialized
INFO - 2016-05-16 18:50:52 --> Loader Class Initialized
INFO - 2016-05-16 18:50:52 --> Helper loaded: url_helper
INFO - 2016-05-16 18:50:52 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:50:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:50:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:50:52 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:50:52 --> Helper loaded: form_helper
INFO - 2016-05-16 18:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:50:52 --> Form Validation Class Initialized
INFO - 2016-05-16 18:50:52 --> Controller Class Initialized
INFO - 2016-05-16 18:50:52 --> Model Class Initialized
INFO - 2016-05-16 18:50:52 --> Database Driver Class Initialized
INFO - 2016-05-16 18:50:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-16 18:50:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 18:50:52 --> Final output sent to browser
DEBUG - 2016-05-16 18:50:52 --> Total execution time: 0.0948
INFO - 2016-05-16 18:50:54 --> Config Class Initialized
INFO - 2016-05-16 18:50:54 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:50:54 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:50:54 --> Utf8 Class Initialized
INFO - 2016-05-16 18:50:54 --> URI Class Initialized
INFO - 2016-05-16 18:50:54 --> Router Class Initialized
INFO - 2016-05-16 18:50:54 --> Output Class Initialized
INFO - 2016-05-16 18:50:54 --> Security Class Initialized
DEBUG - 2016-05-16 18:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:50:54 --> Input Class Initialized
INFO - 2016-05-16 18:50:54 --> Language Class Initialized
INFO - 2016-05-16 18:50:54 --> Loader Class Initialized
INFO - 2016-05-16 18:50:54 --> Helper loaded: url_helper
INFO - 2016-05-16 18:50:54 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:50:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:50:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:50:55 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:50:55 --> Helper loaded: form_helper
INFO - 2016-05-16 18:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:50:55 --> Form Validation Class Initialized
INFO - 2016-05-16 18:50:55 --> Controller Class Initialized
INFO - 2016-05-16 18:50:55 --> Model Class Initialized
INFO - 2016-05-16 18:50:55 --> Database Driver Class Initialized
INFO - 2016-05-16 18:50:55 --> Final output sent to browser
DEBUG - 2016-05-16 18:50:55 --> Total execution time: 0.2392
INFO - 2016-05-16 18:51:14 --> Config Class Initialized
INFO - 2016-05-16 18:51:14 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:51:14 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:51:14 --> Utf8 Class Initialized
INFO - 2016-05-16 18:51:14 --> URI Class Initialized
INFO - 2016-05-16 18:51:14 --> Router Class Initialized
INFO - 2016-05-16 18:51:14 --> Output Class Initialized
INFO - 2016-05-16 18:51:14 --> Security Class Initialized
DEBUG - 2016-05-16 18:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:51:14 --> Input Class Initialized
INFO - 2016-05-16 18:51:14 --> Language Class Initialized
INFO - 2016-05-16 18:51:14 --> Loader Class Initialized
INFO - 2016-05-16 18:51:14 --> Helper loaded: url_helper
INFO - 2016-05-16 18:51:14 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:51:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:51:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:51:14 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:51:14 --> Helper loaded: form_helper
INFO - 2016-05-16 18:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:51:14 --> Form Validation Class Initialized
INFO - 2016-05-16 18:51:14 --> Controller Class Initialized
INFO - 2016-05-16 18:51:14 --> Model Class Initialized
INFO - 2016-05-16 18:51:14 --> Database Driver Class Initialized
INFO - 2016-05-16 18:51:15 --> Final output sent to browser
DEBUG - 2016-05-16 18:51:15 --> Total execution time: 0.1960
INFO - 2016-05-16 18:58:01 --> Config Class Initialized
INFO - 2016-05-16 18:58:01 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:58:01 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:58:01 --> Utf8 Class Initialized
INFO - 2016-05-16 18:58:01 --> URI Class Initialized
INFO - 2016-05-16 18:58:01 --> Router Class Initialized
INFO - 2016-05-16 18:58:01 --> Output Class Initialized
INFO - 2016-05-16 18:58:01 --> Security Class Initialized
DEBUG - 2016-05-16 18:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:58:01 --> Input Class Initialized
INFO - 2016-05-16 18:58:01 --> Language Class Initialized
INFO - 2016-05-16 18:58:01 --> Loader Class Initialized
INFO - 2016-05-16 18:58:01 --> Helper loaded: url_helper
INFO - 2016-05-16 18:58:01 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:58:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:58:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:58:01 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:58:01 --> Helper loaded: form_helper
INFO - 2016-05-16 18:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:58:01 --> Form Validation Class Initialized
INFO - 2016-05-16 18:58:01 --> Controller Class Initialized
INFO - 2016-05-16 18:58:01 --> Model Class Initialized
INFO - 2016-05-16 18:58:01 --> Database Driver Class Initialized
INFO - 2016-05-16 18:58:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizada.php
INFO - 2016-05-16 18:58:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-16 18:58:01 --> Final output sent to browser
DEBUG - 2016-05-16 18:58:01 --> Total execution time: 0.4749
INFO - 2016-05-16 18:58:04 --> Config Class Initialized
INFO - 2016-05-16 18:58:04 --> Hooks Class Initialized
DEBUG - 2016-05-16 18:58:04 --> UTF-8 Support Enabled
INFO - 2016-05-16 18:58:04 --> Utf8 Class Initialized
INFO - 2016-05-16 18:58:04 --> URI Class Initialized
INFO - 2016-05-16 18:58:04 --> Router Class Initialized
INFO - 2016-05-16 18:58:04 --> Output Class Initialized
INFO - 2016-05-16 18:58:04 --> Security Class Initialized
DEBUG - 2016-05-16 18:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-16 18:58:04 --> Input Class Initialized
INFO - 2016-05-16 18:58:04 --> Language Class Initialized
INFO - 2016-05-16 18:58:04 --> Loader Class Initialized
INFO - 2016-05-16 18:58:04 --> Helper loaded: url_helper
INFO - 2016-05-16 18:58:04 --> Helper loaded: sesion_helper
INFO - 2016-05-16 18:58:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-16 18:58:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-16 18:58:04 --> Helper loaded: redondear_helper
INFO - 2016-05-16 18:58:04 --> Helper loaded: form_helper
INFO - 2016-05-16 18:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-16 18:58:04 --> Form Validation Class Initialized
INFO - 2016-05-16 18:58:04 --> Controller Class Initialized
INFO - 2016-05-16 18:58:04 --> Model Class Initialized
INFO - 2016-05-16 18:58:04 --> Database Driver Class Initialized
INFO - 2016-05-16 18:58:04 --> Final output sent to browser
DEBUG - 2016-05-16 18:58:04 --> Total execution time: 0.3504
