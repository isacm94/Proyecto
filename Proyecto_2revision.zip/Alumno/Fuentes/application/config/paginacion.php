<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
 
//Configuración Paginación - Nº de elementos por página

//Módulo administracion
$config['per_page_proveedores'] = 5; //Lista de Proveedores

$config['per_page_categorias'] = 5; //Lista de Categorías

$config['per_page_productos'] = 5; //Lista de Productos

$config['per_page_clientes'] = 5; //Lista de Clientes

$config['per_page_usuarios'] = 5; //Lista de Usuarios

$config['per_page_facturas'] = 5; //Lista de Facturas

//Módulo venta

$config['per_page_home'] = 8;//Número de productos por página en home

$config['per_page_categorias_venta'] = 8;//Número de productos por página a mostrar en cada categoría