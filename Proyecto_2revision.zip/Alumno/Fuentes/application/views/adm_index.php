<?php
/*
 * VISTA DEL MÓDULO DE ADMINISTRACIÓN principaL
 */
?>
 <h1 class="text-center">BIENVENIDOS A SHOP'S ADMIN</h1>
<img class="img-responsive imagen-centrada" src="<?= base_url() . 'assets/images/favicon.png' ?>">
