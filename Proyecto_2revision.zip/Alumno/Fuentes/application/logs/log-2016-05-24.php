<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-24 08:02:17 --> Config Class Initialized
INFO - 2016-05-24 08:02:17 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:02:17 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:02:17 --> Utf8 Class Initialized
INFO - 2016-05-24 08:02:17 --> URI Class Initialized
DEBUG - 2016-05-24 08:02:17 --> No URI present. Default controller set.
INFO - 2016-05-24 08:02:17 --> Router Class Initialized
INFO - 2016-05-24 08:02:17 --> Output Class Initialized
INFO - 2016-05-24 08:02:17 --> Security Class Initialized
DEBUG - 2016-05-24 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:02:17 --> Input Class Initialized
INFO - 2016-05-24 08:02:17 --> Language Class Initialized
INFO - 2016-05-24 08:02:17 --> Loader Class Initialized
INFO - 2016-05-24 08:02:17 --> Helper loaded: url_helper
INFO - 2016-05-24 08:02:17 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:02:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:02:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:02:17 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:02:17 --> Helper loaded: form_helper
INFO - 2016-05-24 08:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:02:17 --> Form Validation Class Initialized
INFO - 2016-05-24 08:02:17 --> Controller Class Initialized
INFO - 2016-05-24 08:02:17 --> Model Class Initialized
INFO - 2016-05-24 08:02:17 --> Database Driver Class Initialized
ERROR - 2016-05-24 08:02:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '2daw1516_isabel'@'localhost' (using password: YES) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2016-05-24 08:02:17 --> Unable to connect to the database
INFO - 2016-05-24 08:02:17 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-24 08:02:37 --> Config Class Initialized
INFO - 2016-05-24 08:02:37 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:02:37 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:02:37 --> Utf8 Class Initialized
INFO - 2016-05-24 08:02:37 --> URI Class Initialized
DEBUG - 2016-05-24 08:02:37 --> No URI present. Default controller set.
INFO - 2016-05-24 08:02:37 --> Router Class Initialized
INFO - 2016-05-24 08:02:37 --> Output Class Initialized
INFO - 2016-05-24 08:02:37 --> Security Class Initialized
DEBUG - 2016-05-24 08:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:02:37 --> Input Class Initialized
INFO - 2016-05-24 08:02:37 --> Language Class Initialized
INFO - 2016-05-24 08:02:37 --> Loader Class Initialized
INFO - 2016-05-24 08:02:37 --> Helper loaded: url_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: form_helper
INFO - 2016-05-24 08:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:02:37 --> Form Validation Class Initialized
INFO - 2016-05-24 08:02:37 --> Controller Class Initialized
INFO - 2016-05-24 08:02:37 --> Model Class Initialized
INFO - 2016-05-24 08:02:37 --> Database Driver Class Initialized
INFO - 2016-05-24 08:02:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:02:37 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:02:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:02:37 --> Config Class Initialized
INFO - 2016-05-24 08:02:37 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:02:37 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:02:37 --> Utf8 Class Initialized
INFO - 2016-05-24 08:02:37 --> URI Class Initialized
INFO - 2016-05-24 08:02:37 --> Router Class Initialized
INFO - 2016-05-24 08:02:37 --> Output Class Initialized
INFO - 2016-05-24 08:02:37 --> Security Class Initialized
DEBUG - 2016-05-24 08:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:02:37 --> Input Class Initialized
INFO - 2016-05-24 08:02:37 --> Language Class Initialized
INFO - 2016-05-24 08:02:37 --> Loader Class Initialized
INFO - 2016-05-24 08:02:37 --> Helper loaded: url_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:02:37 --> Helper loaded: form_helper
INFO - 2016-05-24 08:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:02:37 --> Form Validation Class Initialized
INFO - 2016-05-24 08:02:37 --> Controller Class Initialized
INFO - 2016-05-24 08:02:37 --> Model Class Initialized
INFO - 2016-05-24 08:02:37 --> Database Driver Class Initialized
INFO - 2016-05-24 08:02:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-24 08:02:37 --> Final output sent to browser
DEBUG - 2016-05-24 08:02:37 --> Total execution time: 0.0983
INFO - 2016-05-24 08:02:46 --> Config Class Initialized
INFO - 2016-05-24 08:02:46 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:02:46 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:02:46 --> Utf8 Class Initialized
INFO - 2016-05-24 08:02:46 --> URI Class Initialized
INFO - 2016-05-24 08:02:46 --> Router Class Initialized
INFO - 2016-05-24 08:02:46 --> Output Class Initialized
INFO - 2016-05-24 08:02:46 --> Security Class Initialized
DEBUG - 2016-05-24 08:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:02:46 --> Input Class Initialized
INFO - 2016-05-24 08:02:46 --> Language Class Initialized
INFO - 2016-05-24 08:02:46 --> Loader Class Initialized
INFO - 2016-05-24 08:02:46 --> Helper loaded: url_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: form_helper
INFO - 2016-05-24 08:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:02:46 --> Form Validation Class Initialized
INFO - 2016-05-24 08:02:46 --> Controller Class Initialized
INFO - 2016-05-24 08:02:46 --> Model Class Initialized
INFO - 2016-05-24 08:02:46 --> Database Driver Class Initialized
INFO - 2016-05-24 08:02:46 --> Config Class Initialized
INFO - 2016-05-24 08:02:46 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:02:46 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:02:46 --> Utf8 Class Initialized
INFO - 2016-05-24 08:02:46 --> URI Class Initialized
DEBUG - 2016-05-24 08:02:46 --> No URI present. Default controller set.
INFO - 2016-05-24 08:02:46 --> Router Class Initialized
INFO - 2016-05-24 08:02:46 --> Output Class Initialized
INFO - 2016-05-24 08:02:46 --> Security Class Initialized
DEBUG - 2016-05-24 08:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:02:46 --> Input Class Initialized
INFO - 2016-05-24 08:02:46 --> Language Class Initialized
INFO - 2016-05-24 08:02:46 --> Loader Class Initialized
INFO - 2016-05-24 08:02:46 --> Helper loaded: url_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:02:46 --> Helper loaded: form_helper
INFO - 2016-05-24 08:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:02:46 --> Form Validation Class Initialized
INFO - 2016-05-24 08:02:46 --> Controller Class Initialized
INFO - 2016-05-24 08:02:46 --> Model Class Initialized
INFO - 2016-05-24 08:02:46 --> Database Driver Class Initialized
INFO - 2016-05-24 08:02:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:02:46 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:02:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:02:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-24 08:02:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template2.php
INFO - 2016-05-24 08:02:47 --> Final output sent to browser
DEBUG - 2016-05-24 08:02:47 --> Total execution time: 0.2074
INFO - 2016-05-24 08:02:51 --> Config Class Initialized
INFO - 2016-05-24 08:02:51 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:02:51 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:02:51 --> Utf8 Class Initialized
INFO - 2016-05-24 08:02:51 --> URI Class Initialized
INFO - 2016-05-24 08:02:51 --> Router Class Initialized
INFO - 2016-05-24 08:02:51 --> Output Class Initialized
INFO - 2016-05-24 08:02:51 --> Security Class Initialized
DEBUG - 2016-05-24 08:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:02:51 --> Input Class Initialized
INFO - 2016-05-24 08:02:51 --> Language Class Initialized
INFO - 2016-05-24 08:02:51 --> Loader Class Initialized
INFO - 2016-05-24 08:02:51 --> Helper loaded: url_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: form_helper
INFO - 2016-05-24 08:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:02:51 --> Form Validation Class Initialized
INFO - 2016-05-24 08:02:51 --> Controller Class Initialized
INFO - 2016-05-24 08:02:51 --> Config Class Initialized
INFO - 2016-05-24 08:02:51 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:02:51 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:02:51 --> Utf8 Class Initialized
INFO - 2016-05-24 08:02:51 --> URI Class Initialized
INFO - 2016-05-24 08:02:51 --> Router Class Initialized
INFO - 2016-05-24 08:02:51 --> Output Class Initialized
INFO - 2016-05-24 08:02:51 --> Security Class Initialized
DEBUG - 2016-05-24 08:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:02:51 --> Input Class Initialized
INFO - 2016-05-24 08:02:51 --> Language Class Initialized
INFO - 2016-05-24 08:02:51 --> Loader Class Initialized
INFO - 2016-05-24 08:02:51 --> Helper loaded: url_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:02:51 --> Helper loaded: form_helper
INFO - 2016-05-24 08:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:02:51 --> Form Validation Class Initialized
INFO - 2016-05-24 08:02:51 --> Controller Class Initialized
INFO - 2016-05-24 08:02:51 --> Model Class Initialized
INFO - 2016-05-24 08:02:51 --> Database Driver Class Initialized
INFO - 2016-05-24 08:02:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-24 08:02:51 --> Final output sent to browser
DEBUG - 2016-05-24 08:02:51 --> Total execution time: 0.0968
INFO - 2016-05-24 08:03:07 --> Config Class Initialized
INFO - 2016-05-24 08:03:07 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:07 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:07 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:07 --> URI Class Initialized
INFO - 2016-05-24 08:03:07 --> Router Class Initialized
INFO - 2016-05-24 08:03:07 --> Output Class Initialized
INFO - 2016-05-24 08:03:07 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:07 --> Input Class Initialized
INFO - 2016-05-24 08:03:07 --> Language Class Initialized
INFO - 2016-05-24 08:03:07 --> Loader Class Initialized
INFO - 2016-05-24 08:03:07 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:07 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:07 --> Controller Class Initialized
INFO - 2016-05-24 08:03:07 --> Model Class Initialized
INFO - 2016-05-24 08:03:07 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:07 --> Config Class Initialized
INFO - 2016-05-24 08:03:07 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:07 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:07 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:07 --> URI Class Initialized
INFO - 2016-05-24 08:03:07 --> Router Class Initialized
INFO - 2016-05-24 08:03:07 --> Output Class Initialized
INFO - 2016-05-24 08:03:07 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:07 --> Input Class Initialized
INFO - 2016-05-24 08:03:07 --> Language Class Initialized
INFO - 2016-05-24 08:03:07 --> Loader Class Initialized
INFO - 2016-05-24 08:03:07 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:07 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:07 --> Controller Class Initialized
INFO - 2016-05-24 08:03:07 --> Model Class Initialized
INFO - 2016-05-24 08:03:07 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:07 --> Config Class Initialized
INFO - 2016-05-24 08:03:07 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:07 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:07 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:07 --> URI Class Initialized
INFO - 2016-05-24 08:03:07 --> Router Class Initialized
INFO - 2016-05-24 08:03:07 --> Output Class Initialized
INFO - 2016-05-24 08:03:07 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:07 --> Input Class Initialized
INFO - 2016-05-24 08:03:07 --> Language Class Initialized
INFO - 2016-05-24 08:03:07 --> Loader Class Initialized
INFO - 2016-05-24 08:03:07 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:07 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:07 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:07 --> Controller Class Initialized
INFO - 2016-05-24 08:03:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-24 08:03:07 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:07 --> Total execution time: 0.0805
INFO - 2016-05-24 08:03:09 --> Config Class Initialized
INFO - 2016-05-24 08:03:09 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:09 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:09 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:09 --> URI Class Initialized
INFO - 2016-05-24 08:03:09 --> Router Class Initialized
INFO - 2016-05-24 08:03:09 --> Output Class Initialized
INFO - 2016-05-24 08:03:09 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:09 --> Input Class Initialized
INFO - 2016-05-24 08:03:09 --> Language Class Initialized
INFO - 2016-05-24 08:03:09 --> Loader Class Initialized
INFO - 2016-05-24 08:03:09 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:09 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:09 --> Controller Class Initialized
INFO - 2016-05-24 08:03:09 --> Model Class Initialized
INFO - 2016-05-24 08:03:09 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:09 --> Config Class Initialized
INFO - 2016-05-24 08:03:09 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:09 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:09 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:09 --> URI Class Initialized
INFO - 2016-05-24 08:03:09 --> Router Class Initialized
INFO - 2016-05-24 08:03:09 --> Output Class Initialized
INFO - 2016-05-24 08:03:09 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:09 --> Input Class Initialized
INFO - 2016-05-24 08:03:09 --> Language Class Initialized
INFO - 2016-05-24 08:03:09 --> Loader Class Initialized
INFO - 2016-05-24 08:03:09 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:09 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:09 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:09 --> Controller Class Initialized
INFO - 2016-05-24 08:03:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-24 08:03:09 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:09 --> Total execution time: 0.0687
INFO - 2016-05-24 08:03:14 --> Config Class Initialized
INFO - 2016-05-24 08:03:14 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:14 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:14 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:14 --> URI Class Initialized
INFO - 2016-05-24 08:03:14 --> Router Class Initialized
INFO - 2016-05-24 08:03:14 --> Output Class Initialized
INFO - 2016-05-24 08:03:14 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:14 --> Input Class Initialized
INFO - 2016-05-24 08:03:14 --> Language Class Initialized
INFO - 2016-05-24 08:03:14 --> Loader Class Initialized
INFO - 2016-05-24 08:03:14 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:14 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:14 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:14 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:14 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:14 --> Controller Class Initialized
INFO - 2016-05-24 08:03:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-24 08:03:14 --> Model Class Initialized
INFO - 2016-05-24 08:03:14 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 08:03:14 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:14 --> Total execution time: 0.0972
INFO - 2016-05-24 08:03:15 --> Config Class Initialized
INFO - 2016-05-24 08:03:15 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:15 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:15 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:15 --> URI Class Initialized
INFO - 2016-05-24 08:03:15 --> Router Class Initialized
INFO - 2016-05-24 08:03:15 --> Output Class Initialized
INFO - 2016-05-24 08:03:15 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:15 --> Input Class Initialized
INFO - 2016-05-24 08:03:15 --> Language Class Initialized
INFO - 2016-05-24 08:03:15 --> Loader Class Initialized
INFO - 2016-05-24 08:03:15 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:15 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:15 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:15 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:15 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:15 --> Controller Class Initialized
INFO - 2016-05-24 08:03:15 --> Model Class Initialized
INFO - 2016-05-24 08:03:15 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:03:15 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:03:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:03:15 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:15 --> Total execution time: 0.1097
INFO - 2016-05-24 08:03:27 --> Config Class Initialized
INFO - 2016-05-24 08:03:27 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:27 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:27 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:27 --> URI Class Initialized
INFO - 2016-05-24 08:03:27 --> Router Class Initialized
INFO - 2016-05-24 08:03:27 --> Output Class Initialized
INFO - 2016-05-24 08:03:27 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:27 --> Input Class Initialized
INFO - 2016-05-24 08:03:27 --> Language Class Initialized
INFO - 2016-05-24 08:03:27 --> Loader Class Initialized
INFO - 2016-05-24 08:03:27 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:27 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:27 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:27 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:27 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:27 --> Controller Class Initialized
DEBUG - 2016-05-24 08:03:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:03:27 --> Model Class Initialized
INFO - 2016-05-24 08:03:27 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-24 08:03:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 08:03:27 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:27 --> Total execution time: 0.0954
INFO - 2016-05-24 08:03:27 --> Config Class Initialized
INFO - 2016-05-24 08:03:27 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:27 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:27 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:27 --> URI Class Initialized
INFO - 2016-05-24 08:03:27 --> Router Class Initialized
INFO - 2016-05-24 08:03:27 --> Output Class Initialized
INFO - 2016-05-24 08:03:27 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:27 --> Input Class Initialized
INFO - 2016-05-24 08:03:27 --> Language Class Initialized
INFO - 2016-05-24 08:03:28 --> Loader Class Initialized
INFO - 2016-05-24 08:03:28 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:28 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:28 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:28 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:28 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:28 --> Controller Class Initialized
INFO - 2016-05-24 08:03:28 --> Model Class Initialized
INFO - 2016-05-24 08:03:28 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:03:28 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:03:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:03:28 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:28 --> Total execution time: 0.1303
INFO - 2016-05-24 08:03:32 --> Config Class Initialized
INFO - 2016-05-24 08:03:32 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:32 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:32 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:32 --> URI Class Initialized
INFO - 2016-05-24 08:03:32 --> Router Class Initialized
INFO - 2016-05-24 08:03:32 --> Output Class Initialized
INFO - 2016-05-24 08:03:32 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:32 --> Input Class Initialized
INFO - 2016-05-24 08:03:32 --> Language Class Initialized
INFO - 2016-05-24 08:03:32 --> Loader Class Initialized
INFO - 2016-05-24 08:03:32 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:32 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:32 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:32 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:32 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:32 --> Controller Class Initialized
DEBUG - 2016-05-24 08:03:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:03:32 --> Model Class Initialized
INFO - 2016-05-24 08:03:32 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:32 --> Config Class Initialized
INFO - 2016-05-24 08:03:32 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:32 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:32 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:32 --> URI Class Initialized
INFO - 2016-05-24 08:03:32 --> Router Class Initialized
INFO - 2016-05-24 08:03:32 --> Output Class Initialized
INFO - 2016-05-24 08:03:32 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:32 --> Input Class Initialized
INFO - 2016-05-24 08:03:32 --> Language Class Initialized
INFO - 2016-05-24 08:03:33 --> Loader Class Initialized
INFO - 2016-05-24 08:03:33 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:33 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:33 --> Controller Class Initialized
DEBUG - 2016-05-24 08:03:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:03:33 --> Model Class Initialized
INFO - 2016-05-24 08:03:33 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-24 08:03:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-24 08:03:33 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:33 --> Total execution time: 0.0872
INFO - 2016-05-24 08:03:33 --> Config Class Initialized
INFO - 2016-05-24 08:03:33 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:33 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:33 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:33 --> URI Class Initialized
INFO - 2016-05-24 08:03:33 --> Router Class Initialized
INFO - 2016-05-24 08:03:33 --> Output Class Initialized
INFO - 2016-05-24 08:03:33 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:33 --> Input Class Initialized
INFO - 2016-05-24 08:03:33 --> Language Class Initialized
INFO - 2016-05-24 08:03:33 --> Loader Class Initialized
INFO - 2016-05-24 08:03:33 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:33 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:33 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:33 --> Controller Class Initialized
INFO - 2016-05-24 08:03:33 --> Model Class Initialized
INFO - 2016-05-24 08:03:33 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:03:33 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:03:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:03:33 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:33 --> Total execution time: 0.1227
INFO - 2016-05-24 08:03:40 --> Config Class Initialized
INFO - 2016-05-24 08:03:40 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:40 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:40 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:40 --> URI Class Initialized
INFO - 2016-05-24 08:03:40 --> Router Class Initialized
INFO - 2016-05-24 08:03:40 --> Output Class Initialized
INFO - 2016-05-24 08:03:40 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:40 --> Input Class Initialized
INFO - 2016-05-24 08:03:40 --> Language Class Initialized
INFO - 2016-05-24 08:03:40 --> Loader Class Initialized
INFO - 2016-05-24 08:03:40 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:40 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:40 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:40 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:40 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:40 --> Controller Class Initialized
DEBUG - 2016-05-24 08:03:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:03:40 --> Model Class Initialized
INFO - 2016-05-24 08:03:40 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:40 --> Config Class Initialized
INFO - 2016-05-24 08:03:40 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:40 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:40 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:40 --> URI Class Initialized
INFO - 2016-05-24 08:03:40 --> Router Class Initialized
INFO - 2016-05-24 08:03:40 --> Output Class Initialized
INFO - 2016-05-24 08:03:40 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:40 --> Input Class Initialized
INFO - 2016-05-24 08:03:40 --> Language Class Initialized
INFO - 2016-05-24 08:03:41 --> Loader Class Initialized
INFO - 2016-05-24 08:03:41 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:41 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:41 --> Controller Class Initialized
DEBUG - 2016-05-24 08:03:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:03:41 --> Model Class Initialized
INFO - 2016-05-24 08:03:41 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-24 08:03:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 08:03:41 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:41 --> Total execution time: 0.0924
INFO - 2016-05-24 08:03:41 --> Config Class Initialized
INFO - 2016-05-24 08:03:41 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:41 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:41 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:41 --> URI Class Initialized
INFO - 2016-05-24 08:03:41 --> Router Class Initialized
INFO - 2016-05-24 08:03:41 --> Output Class Initialized
INFO - 2016-05-24 08:03:41 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:41 --> Input Class Initialized
INFO - 2016-05-24 08:03:41 --> Language Class Initialized
INFO - 2016-05-24 08:03:41 --> Loader Class Initialized
INFO - 2016-05-24 08:03:41 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:41 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:41 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:41 --> Controller Class Initialized
INFO - 2016-05-24 08:03:41 --> Model Class Initialized
INFO - 2016-05-24 08:03:41 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:03:41 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:03:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:03:41 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:41 --> Total execution time: 0.1239
INFO - 2016-05-24 08:03:44 --> Config Class Initialized
INFO - 2016-05-24 08:03:44 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:44 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:44 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:44 --> URI Class Initialized
INFO - 2016-05-24 08:03:44 --> Router Class Initialized
INFO - 2016-05-24 08:03:44 --> Output Class Initialized
INFO - 2016-05-24 08:03:44 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:44 --> Input Class Initialized
INFO - 2016-05-24 08:03:44 --> Language Class Initialized
INFO - 2016-05-24 08:03:44 --> Loader Class Initialized
INFO - 2016-05-24 08:03:44 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:44 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:44 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:44 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:45 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:45 --> Controller Class Initialized
DEBUG - 2016-05-24 08:03:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:03:45 --> Model Class Initialized
INFO - 2016-05-24 08:03:45 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:45 --> Config Class Initialized
INFO - 2016-05-24 08:03:45 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:45 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:45 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:45 --> URI Class Initialized
INFO - 2016-05-24 08:03:45 --> Router Class Initialized
INFO - 2016-05-24 08:03:45 --> Output Class Initialized
INFO - 2016-05-24 08:03:45 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:45 --> Input Class Initialized
INFO - 2016-05-24 08:03:45 --> Language Class Initialized
INFO - 2016-05-24 08:03:45 --> Loader Class Initialized
INFO - 2016-05-24 08:03:45 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:45 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:45 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:45 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:45 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:45 --> Controller Class Initialized
DEBUG - 2016-05-24 08:03:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:03:45 --> Model Class Initialized
INFO - 2016-05-24 08:03:45 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-24 08:03:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 08:03:45 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:45 --> Total execution time: 0.1193
INFO - 2016-05-24 08:03:46 --> Config Class Initialized
INFO - 2016-05-24 08:03:46 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:46 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:46 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:46 --> URI Class Initialized
DEBUG - 2016-05-24 08:03:46 --> No URI present. Default controller set.
INFO - 2016-05-24 08:03:46 --> Router Class Initialized
INFO - 2016-05-24 08:03:46 --> Output Class Initialized
INFO - 2016-05-24 08:03:46 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:46 --> Input Class Initialized
INFO - 2016-05-24 08:03:46 --> Language Class Initialized
INFO - 2016-05-24 08:03:46 --> Loader Class Initialized
INFO - 2016-05-24 08:03:46 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:46 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:46 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:46 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:46 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:46 --> Controller Class Initialized
INFO - 2016-05-24 08:03:46 --> Model Class Initialized
INFO - 2016-05-24 08:03:46 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:03:46 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:03:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:03:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-24 08:03:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-24 08:03:46 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:46 --> Total execution time: 0.1274
INFO - 2016-05-24 08:03:48 --> Config Class Initialized
INFO - 2016-05-24 08:03:48 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:03:48 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:03:48 --> Utf8 Class Initialized
INFO - 2016-05-24 08:03:48 --> URI Class Initialized
INFO - 2016-05-24 08:03:48 --> Router Class Initialized
INFO - 2016-05-24 08:03:48 --> Output Class Initialized
INFO - 2016-05-24 08:03:48 --> Security Class Initialized
DEBUG - 2016-05-24 08:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:03:48 --> Input Class Initialized
INFO - 2016-05-24 08:03:48 --> Language Class Initialized
INFO - 2016-05-24 08:03:48 --> Loader Class Initialized
INFO - 2016-05-24 08:03:48 --> Helper loaded: url_helper
INFO - 2016-05-24 08:03:48 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:03:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:03:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:03:48 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:03:48 --> Helper loaded: form_helper
INFO - 2016-05-24 08:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:03:49 --> Form Validation Class Initialized
INFO - 2016-05-24 08:03:49 --> Controller Class Initialized
INFO - 2016-05-24 08:03:49 --> Model Class Initialized
INFO - 2016-05-24 08:03:49 --> Database Driver Class Initialized
INFO - 2016-05-24 08:03:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:03:49 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:03:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:03:49 --> Final output sent to browser
DEBUG - 2016-05-24 08:03:49 --> Total execution time: 0.1398
INFO - 2016-05-24 08:04:11 --> Config Class Initialized
INFO - 2016-05-24 08:04:11 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:04:11 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:04:11 --> Utf8 Class Initialized
INFO - 2016-05-24 08:04:11 --> URI Class Initialized
INFO - 2016-05-24 08:04:11 --> Router Class Initialized
INFO - 2016-05-24 08:04:11 --> Output Class Initialized
INFO - 2016-05-24 08:04:11 --> Security Class Initialized
DEBUG - 2016-05-24 08:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:04:11 --> Input Class Initialized
INFO - 2016-05-24 08:04:11 --> Language Class Initialized
INFO - 2016-05-24 08:04:11 --> Loader Class Initialized
INFO - 2016-05-24 08:04:11 --> Helper loaded: url_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: form_helper
INFO - 2016-05-24 08:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:04:11 --> Form Validation Class Initialized
INFO - 2016-05-24 08:04:11 --> Controller Class Initialized
INFO - 2016-05-24 08:04:11 --> Model Class Initialized
INFO - 2016-05-24 08:04:11 --> Database Driver Class Initialized
INFO - 2016-05-24 08:04:11 --> Config Class Initialized
INFO - 2016-05-24 08:04:11 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:04:11 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:04:11 --> Utf8 Class Initialized
INFO - 2016-05-24 08:04:11 --> URI Class Initialized
INFO - 2016-05-24 08:04:11 --> Router Class Initialized
INFO - 2016-05-24 08:04:11 --> Output Class Initialized
INFO - 2016-05-24 08:04:11 --> Security Class Initialized
DEBUG - 2016-05-24 08:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:04:11 --> Input Class Initialized
INFO - 2016-05-24 08:04:11 --> Language Class Initialized
INFO - 2016-05-24 08:04:11 --> Loader Class Initialized
INFO - 2016-05-24 08:04:11 --> Helper loaded: url_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:04:11 --> Helper loaded: form_helper
INFO - 2016-05-24 08:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:04:11 --> Form Validation Class Initialized
INFO - 2016-05-24 08:04:11 --> Controller Class Initialized
INFO - 2016-05-24 08:04:11 --> Model Class Initialized
INFO - 2016-05-24 08:04:11 --> Database Driver Class Initialized
INFO - 2016-05-24 08:04:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-24 08:04:11 --> Final output sent to browser
DEBUG - 2016-05-24 08:04:11 --> Total execution time: 0.1492
INFO - 2016-05-24 08:04:14 --> Config Class Initialized
INFO - 2016-05-24 08:04:14 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:04:14 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:04:14 --> Utf8 Class Initialized
INFO - 2016-05-24 08:04:14 --> URI Class Initialized
INFO - 2016-05-24 08:04:14 --> Router Class Initialized
INFO - 2016-05-24 08:04:14 --> Output Class Initialized
INFO - 2016-05-24 08:04:14 --> Security Class Initialized
DEBUG - 2016-05-24 08:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:04:14 --> Input Class Initialized
INFO - 2016-05-24 08:04:14 --> Language Class Initialized
INFO - 2016-05-24 08:04:14 --> Loader Class Initialized
INFO - 2016-05-24 08:04:14 --> Helper loaded: url_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: form_helper
INFO - 2016-05-24 08:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:04:14 --> Form Validation Class Initialized
INFO - 2016-05-24 08:04:14 --> Controller Class Initialized
INFO - 2016-05-24 08:04:14 --> Model Class Initialized
INFO - 2016-05-24 08:04:14 --> Database Driver Class Initialized
INFO - 2016-05-24 08:04:14 --> Config Class Initialized
INFO - 2016-05-24 08:04:14 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:04:14 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:04:14 --> Utf8 Class Initialized
INFO - 2016-05-24 08:04:14 --> URI Class Initialized
INFO - 2016-05-24 08:04:14 --> Router Class Initialized
INFO - 2016-05-24 08:04:14 --> Output Class Initialized
INFO - 2016-05-24 08:04:14 --> Security Class Initialized
DEBUG - 2016-05-24 08:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:04:14 --> Input Class Initialized
INFO - 2016-05-24 08:04:14 --> Language Class Initialized
INFO - 2016-05-24 08:04:14 --> Loader Class Initialized
INFO - 2016-05-24 08:04:14 --> Helper loaded: url_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:04:14 --> Helper loaded: form_helper
INFO - 2016-05-24 08:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:04:14 --> Form Validation Class Initialized
INFO - 2016-05-24 08:04:14 --> Controller Class Initialized
INFO - 2016-05-24 08:04:14 --> Model Class Initialized
INFO - 2016-05-24 08:04:14 --> Database Driver Class Initialized
INFO - 2016-05-24 08:04:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-24 08:04:14 --> Final output sent to browser
DEBUG - 2016-05-24 08:04:14 --> Total execution time: 0.0947
INFO - 2016-05-24 08:04:19 --> Config Class Initialized
INFO - 2016-05-24 08:04:19 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:04:19 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:04:19 --> Utf8 Class Initialized
INFO - 2016-05-24 08:04:19 --> URI Class Initialized
INFO - 2016-05-24 08:04:19 --> Router Class Initialized
INFO - 2016-05-24 08:04:19 --> Output Class Initialized
INFO - 2016-05-24 08:04:19 --> Security Class Initialized
DEBUG - 2016-05-24 08:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:04:19 --> Input Class Initialized
INFO - 2016-05-24 08:04:19 --> Language Class Initialized
INFO - 2016-05-24 08:04:19 --> Loader Class Initialized
INFO - 2016-05-24 08:04:19 --> Helper loaded: url_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: form_helper
INFO - 2016-05-24 08:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:04:19 --> Form Validation Class Initialized
INFO - 2016-05-24 08:04:19 --> Controller Class Initialized
INFO - 2016-05-24 08:04:19 --> Model Class Initialized
INFO - 2016-05-24 08:04:19 --> Database Driver Class Initialized
INFO - 2016-05-24 08:04:19 --> Config Class Initialized
INFO - 2016-05-24 08:04:19 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:04:19 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:04:19 --> Utf8 Class Initialized
INFO - 2016-05-24 08:04:19 --> URI Class Initialized
INFO - 2016-05-24 08:04:19 --> Router Class Initialized
INFO - 2016-05-24 08:04:19 --> Output Class Initialized
INFO - 2016-05-24 08:04:19 --> Security Class Initialized
DEBUG - 2016-05-24 08:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:04:19 --> Input Class Initialized
INFO - 2016-05-24 08:04:19 --> Language Class Initialized
INFO - 2016-05-24 08:04:19 --> Loader Class Initialized
INFO - 2016-05-24 08:04:19 --> Helper loaded: url_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:04:19 --> Helper loaded: form_helper
INFO - 2016-05-24 08:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:04:19 --> Form Validation Class Initialized
INFO - 2016-05-24 08:04:19 --> Controller Class Initialized
DEBUG - 2016-05-24 08:04:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-24 08:04:19 --> Model Class Initialized
INFO - 2016-05-24 08:04:19 --> Database Driver Class Initialized
INFO - 2016-05-24 08:04:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-24 08:04:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 08:04:19 --> Final output sent to browser
DEBUG - 2016-05-24 08:04:19 --> Total execution time: 0.1710
INFO - 2016-05-24 08:04:20 --> Config Class Initialized
INFO - 2016-05-24 08:04:20 --> Hooks Class Initialized
DEBUG - 2016-05-24 08:04:20 --> UTF-8 Support Enabled
INFO - 2016-05-24 08:04:20 --> Utf8 Class Initialized
INFO - 2016-05-24 08:04:20 --> URI Class Initialized
INFO - 2016-05-24 08:04:20 --> Router Class Initialized
INFO - 2016-05-24 08:04:20 --> Output Class Initialized
INFO - 2016-05-24 08:04:20 --> Security Class Initialized
DEBUG - 2016-05-24 08:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 08:04:20 --> Input Class Initialized
INFO - 2016-05-24 08:04:20 --> Language Class Initialized
INFO - 2016-05-24 08:04:20 --> Loader Class Initialized
INFO - 2016-05-24 08:04:20 --> Helper loaded: url_helper
INFO - 2016-05-24 08:04:20 --> Helper loaded: sesion_helper
INFO - 2016-05-24 08:04:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 08:04:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 08:04:20 --> Helper loaded: redondear_helper
INFO - 2016-05-24 08:04:20 --> Helper loaded: form_helper
INFO - 2016-05-24 08:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 08:04:20 --> Form Validation Class Initialized
INFO - 2016-05-24 08:04:20 --> Controller Class Initialized
INFO - 2016-05-24 08:04:20 --> Model Class Initialized
INFO - 2016-05-24 08:04:20 --> Database Driver Class Initialized
INFO - 2016-05-24 08:04:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 08:04:20 --> Pagination Class Initialized
DEBUG - 2016-05-24 08:04:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 08:04:20 --> Final output sent to browser
DEBUG - 2016-05-24 08:04:20 --> Total execution time: 0.1129
INFO - 2016-05-24 18:32:00 --> Config Class Initialized
INFO - 2016-05-24 18:32:00 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:32:00 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:32:00 --> Utf8 Class Initialized
INFO - 2016-05-24 18:32:00 --> URI Class Initialized
DEBUG - 2016-05-24 18:32:00 --> No URI present. Default controller set.
INFO - 2016-05-24 18:32:00 --> Router Class Initialized
INFO - 2016-05-24 18:32:00 --> Output Class Initialized
INFO - 2016-05-24 18:32:00 --> Security Class Initialized
DEBUG - 2016-05-24 18:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:32:00 --> Input Class Initialized
INFO - 2016-05-24 18:32:00 --> Language Class Initialized
INFO - 2016-05-24 18:32:00 --> Loader Class Initialized
INFO - 2016-05-24 18:32:00 --> Helper loaded: url_helper
INFO - 2016-05-24 18:32:00 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:32:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:32:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:32:00 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:32:00 --> Helper loaded: form_helper
INFO - 2016-05-24 18:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:32:00 --> Form Validation Class Initialized
INFO - 2016-05-24 18:32:00 --> Controller Class Initialized
INFO - 2016-05-24 18:32:00 --> Model Class Initialized
INFO - 2016-05-24 18:32:00 --> Database Driver Class Initialized
INFO - 2016-05-24 18:32:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 18:32:01 --> Pagination Class Initialized
DEBUG - 2016-05-24 18:32:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 18:32:01 --> Config Class Initialized
INFO - 2016-05-24 18:32:01 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:32:01 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:32:01 --> Utf8 Class Initialized
INFO - 2016-05-24 18:32:01 --> URI Class Initialized
INFO - 2016-05-24 18:32:01 --> Router Class Initialized
INFO - 2016-05-24 18:32:01 --> Output Class Initialized
INFO - 2016-05-24 18:32:01 --> Security Class Initialized
DEBUG - 2016-05-24 18:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:32:01 --> Input Class Initialized
INFO - 2016-05-24 18:32:01 --> Language Class Initialized
INFO - 2016-05-24 18:32:01 --> Loader Class Initialized
INFO - 2016-05-24 18:32:01 --> Helper loaded: url_helper
INFO - 2016-05-24 18:32:01 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:32:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:32:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:32:01 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:32:01 --> Helper loaded: form_helper
INFO - 2016-05-24 18:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:32:01 --> Form Validation Class Initialized
INFO - 2016-05-24 18:32:01 --> Controller Class Initialized
INFO - 2016-05-24 18:32:01 --> Model Class Initialized
INFO - 2016-05-24 18:32:01 --> Database Driver Class Initialized
INFO - 2016-05-24 18:32:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-24 18:32:01 --> Final output sent to browser
DEBUG - 2016-05-24 18:32:01 --> Total execution time: 0.1253
INFO - 2016-05-24 18:32:05 --> Config Class Initialized
INFO - 2016-05-24 18:32:05 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:32:05 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:32:05 --> Utf8 Class Initialized
INFO - 2016-05-24 18:32:05 --> URI Class Initialized
INFO - 2016-05-24 18:32:05 --> Router Class Initialized
INFO - 2016-05-24 18:32:05 --> Output Class Initialized
INFO - 2016-05-24 18:32:05 --> Security Class Initialized
DEBUG - 2016-05-24 18:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:32:05 --> Input Class Initialized
INFO - 2016-05-24 18:32:05 --> Language Class Initialized
INFO - 2016-05-24 18:32:05 --> Loader Class Initialized
INFO - 2016-05-24 18:32:05 --> Helper loaded: url_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: form_helper
INFO - 2016-05-24 18:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:32:05 --> Form Validation Class Initialized
INFO - 2016-05-24 18:32:05 --> Controller Class Initialized
INFO - 2016-05-24 18:32:05 --> Config Class Initialized
INFO - 2016-05-24 18:32:05 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:32:05 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:32:05 --> Utf8 Class Initialized
INFO - 2016-05-24 18:32:05 --> URI Class Initialized
INFO - 2016-05-24 18:32:05 --> Router Class Initialized
INFO - 2016-05-24 18:32:05 --> Output Class Initialized
INFO - 2016-05-24 18:32:05 --> Security Class Initialized
DEBUG - 2016-05-24 18:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:32:05 --> Input Class Initialized
INFO - 2016-05-24 18:32:05 --> Language Class Initialized
INFO - 2016-05-24 18:32:05 --> Loader Class Initialized
INFO - 2016-05-24 18:32:05 --> Helper loaded: url_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:32:05 --> Helper loaded: form_helper
INFO - 2016-05-24 18:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:32:05 --> Form Validation Class Initialized
INFO - 2016-05-24 18:32:05 --> Controller Class Initialized
INFO - 2016-05-24 18:32:05 --> Model Class Initialized
INFO - 2016-05-24 18:32:06 --> Database Driver Class Initialized
INFO - 2016-05-24 18:32:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-24 18:32:06 --> Final output sent to browser
DEBUG - 2016-05-24 18:32:06 --> Total execution time: 0.0744
INFO - 2016-05-24 18:32:12 --> Config Class Initialized
INFO - 2016-05-24 18:32:12 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:32:12 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:32:12 --> Utf8 Class Initialized
INFO - 2016-05-24 18:32:12 --> URI Class Initialized
INFO - 2016-05-24 18:32:12 --> Router Class Initialized
INFO - 2016-05-24 18:32:12 --> Output Class Initialized
INFO - 2016-05-24 18:32:12 --> Security Class Initialized
DEBUG - 2016-05-24 18:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:32:12 --> Input Class Initialized
INFO - 2016-05-24 18:32:12 --> Language Class Initialized
INFO - 2016-05-24 18:32:12 --> Loader Class Initialized
INFO - 2016-05-24 18:32:12 --> Helper loaded: url_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: form_helper
INFO - 2016-05-24 18:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:32:12 --> Form Validation Class Initialized
INFO - 2016-05-24 18:32:12 --> Controller Class Initialized
INFO - 2016-05-24 18:32:12 --> Model Class Initialized
INFO - 2016-05-24 18:32:12 --> Database Driver Class Initialized
INFO - 2016-05-24 18:32:12 --> Config Class Initialized
INFO - 2016-05-24 18:32:12 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:32:12 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:32:12 --> Utf8 Class Initialized
INFO - 2016-05-24 18:32:12 --> URI Class Initialized
INFO - 2016-05-24 18:32:12 --> Router Class Initialized
INFO - 2016-05-24 18:32:12 --> Output Class Initialized
INFO - 2016-05-24 18:32:12 --> Security Class Initialized
DEBUG - 2016-05-24 18:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:32:12 --> Input Class Initialized
INFO - 2016-05-24 18:32:12 --> Language Class Initialized
INFO - 2016-05-24 18:32:12 --> Loader Class Initialized
INFO - 2016-05-24 18:32:12 --> Helper loaded: url_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:32:12 --> Helper loaded: form_helper
INFO - 2016-05-24 18:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:32:12 --> Form Validation Class Initialized
INFO - 2016-05-24 18:32:12 --> Controller Class Initialized
INFO - 2016-05-24 18:32:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-24 18:32:12 --> Model Class Initialized
INFO - 2016-05-24 18:32:12 --> Database Driver Class Initialized
INFO - 2016-05-24 18:32:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 18:32:12 --> Final output sent to browser
DEBUG - 2016-05-24 18:32:12 --> Total execution time: 0.0950
INFO - 2016-05-24 18:32:13 --> Config Class Initialized
INFO - 2016-05-24 18:32:13 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:32:13 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:32:13 --> Utf8 Class Initialized
INFO - 2016-05-24 18:32:13 --> URI Class Initialized
INFO - 2016-05-24 18:32:13 --> Router Class Initialized
INFO - 2016-05-24 18:32:13 --> Output Class Initialized
INFO - 2016-05-24 18:32:13 --> Security Class Initialized
DEBUG - 2016-05-24 18:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:32:13 --> Input Class Initialized
INFO - 2016-05-24 18:32:13 --> Language Class Initialized
INFO - 2016-05-24 18:32:13 --> Loader Class Initialized
INFO - 2016-05-24 18:32:13 --> Helper loaded: url_helper
INFO - 2016-05-24 18:32:13 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:32:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:32:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:32:13 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:32:13 --> Helper loaded: form_helper
INFO - 2016-05-24 18:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:32:13 --> Form Validation Class Initialized
INFO - 2016-05-24 18:32:13 --> Controller Class Initialized
INFO - 2016-05-24 18:32:13 --> Model Class Initialized
INFO - 2016-05-24 18:32:13 --> Database Driver Class Initialized
INFO - 2016-05-24 18:32:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 18:32:13 --> Pagination Class Initialized
DEBUG - 2016-05-24 18:32:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 18:32:13 --> Final output sent to browser
DEBUG - 2016-05-24 18:32:13 --> Total execution time: 0.1249
INFO - 2016-05-24 18:33:13 --> Config Class Initialized
INFO - 2016-05-24 18:33:13 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:33:13 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:33:13 --> Utf8 Class Initialized
INFO - 2016-05-24 18:33:13 --> URI Class Initialized
INFO - 2016-05-24 18:33:13 --> Router Class Initialized
INFO - 2016-05-24 18:33:13 --> Output Class Initialized
INFO - 2016-05-24 18:33:13 --> Security Class Initialized
DEBUG - 2016-05-24 18:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:33:13 --> Input Class Initialized
INFO - 2016-05-24 18:33:13 --> Language Class Initialized
INFO - 2016-05-24 18:33:13 --> Loader Class Initialized
INFO - 2016-05-24 18:33:13 --> Helper loaded: url_helper
INFO - 2016-05-24 18:33:13 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:33:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:33:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:33:13 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:33:13 --> Helper loaded: form_helper
INFO - 2016-05-24 18:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:33:13 --> Form Validation Class Initialized
INFO - 2016-05-24 18:33:13 --> Controller Class Initialized
INFO - 2016-05-24 18:33:13 --> Model Class Initialized
INFO - 2016-05-24 18:33:13 --> Database Driver Class Initialized
INFO - 2016-05-24 18:33:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 18:33:13 --> Pagination Class Initialized
DEBUG - 2016-05-24 18:33:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 18:33:13 --> Final output sent to browser
DEBUG - 2016-05-24 18:33:13 --> Total execution time: 0.0869
INFO - 2016-05-24 18:34:13 --> Config Class Initialized
INFO - 2016-05-24 18:34:13 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:34:13 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:34:13 --> Utf8 Class Initialized
INFO - 2016-05-24 18:34:13 --> URI Class Initialized
INFO - 2016-05-24 18:34:13 --> Router Class Initialized
INFO - 2016-05-24 18:34:13 --> Output Class Initialized
INFO - 2016-05-24 18:34:13 --> Security Class Initialized
DEBUG - 2016-05-24 18:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:34:13 --> Input Class Initialized
INFO - 2016-05-24 18:34:13 --> Language Class Initialized
INFO - 2016-05-24 18:34:13 --> Loader Class Initialized
INFO - 2016-05-24 18:34:13 --> Helper loaded: url_helper
INFO - 2016-05-24 18:34:13 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:34:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:34:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:34:13 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:34:13 --> Helper loaded: form_helper
INFO - 2016-05-24 18:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:34:13 --> Form Validation Class Initialized
INFO - 2016-05-24 18:34:13 --> Controller Class Initialized
INFO - 2016-05-24 18:34:13 --> Model Class Initialized
INFO - 2016-05-24 18:34:13 --> Database Driver Class Initialized
ERROR - 2016-05-24 18:34:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '2daw1516_isabel'@'localhost' (using password: YES) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2016-05-24 18:34:13 --> Unable to connect to the database
INFO - 2016-05-24 18:34:13 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-24 18:35:13 --> Config Class Initialized
INFO - 2016-05-24 18:35:13 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:35:13 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:35:13 --> Utf8 Class Initialized
INFO - 2016-05-24 18:35:13 --> URI Class Initialized
INFO - 2016-05-24 18:35:13 --> Router Class Initialized
INFO - 2016-05-24 18:35:13 --> Output Class Initialized
INFO - 2016-05-24 18:35:13 --> Security Class Initialized
DEBUG - 2016-05-24 18:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:35:13 --> Input Class Initialized
INFO - 2016-05-24 18:35:13 --> Language Class Initialized
INFO - 2016-05-24 18:35:13 --> Loader Class Initialized
INFO - 2016-05-24 18:35:13 --> Helper loaded: url_helper
INFO - 2016-05-24 18:35:13 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:35:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:35:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:35:13 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:35:13 --> Helper loaded: form_helper
INFO - 2016-05-24 18:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:35:13 --> Form Validation Class Initialized
INFO - 2016-05-24 18:35:13 --> Controller Class Initialized
INFO - 2016-05-24 18:35:13 --> Model Class Initialized
INFO - 2016-05-24 18:35:13 --> Database Driver Class Initialized
ERROR - 2016-05-24 18:35:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '2daw1516_isabel'@'localhost' (using password: YES) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2016-05-24 18:35:13 --> Unable to connect to the database
INFO - 2016-05-24 18:35:13 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-24 18:36:13 --> Config Class Initialized
INFO - 2016-05-24 18:36:13 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:36:13 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:36:13 --> Utf8 Class Initialized
INFO - 2016-05-24 18:36:13 --> URI Class Initialized
INFO - 2016-05-24 18:36:13 --> Router Class Initialized
INFO - 2016-05-24 18:36:13 --> Output Class Initialized
INFO - 2016-05-24 18:36:13 --> Security Class Initialized
DEBUG - 2016-05-24 18:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:36:13 --> Input Class Initialized
INFO - 2016-05-24 18:36:13 --> Language Class Initialized
INFO - 2016-05-24 18:36:13 --> Loader Class Initialized
INFO - 2016-05-24 18:36:13 --> Helper loaded: url_helper
INFO - 2016-05-24 18:36:13 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:36:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:36:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:36:13 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:36:13 --> Helper loaded: form_helper
INFO - 2016-05-24 18:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:36:13 --> Form Validation Class Initialized
INFO - 2016-05-24 18:36:13 --> Controller Class Initialized
INFO - 2016-05-24 18:36:13 --> Model Class Initialized
INFO - 2016-05-24 18:36:13 --> Database Driver Class Initialized
ERROR - 2016-05-24 18:36:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '2daw1516_isabel'@'localhost' (using password: YES) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2016-05-24 18:36:13 --> Unable to connect to the database
INFO - 2016-05-24 18:36:13 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-24 18:37:13 --> Config Class Initialized
INFO - 2016-05-24 18:37:13 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:37:13 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:37:13 --> Utf8 Class Initialized
INFO - 2016-05-24 18:37:13 --> URI Class Initialized
INFO - 2016-05-24 18:37:13 --> Router Class Initialized
INFO - 2016-05-24 18:37:13 --> Output Class Initialized
INFO - 2016-05-24 18:37:13 --> Security Class Initialized
DEBUG - 2016-05-24 18:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:37:13 --> Input Class Initialized
INFO - 2016-05-24 18:37:13 --> Language Class Initialized
INFO - 2016-05-24 18:37:13 --> Loader Class Initialized
INFO - 2016-05-24 18:37:13 --> Helper loaded: url_helper
INFO - 2016-05-24 18:37:13 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:37:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:37:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:37:13 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:37:13 --> Helper loaded: form_helper
INFO - 2016-05-24 18:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:37:13 --> Form Validation Class Initialized
INFO - 2016-05-24 18:37:13 --> Controller Class Initialized
INFO - 2016-05-24 18:37:13 --> Model Class Initialized
INFO - 2016-05-24 18:37:13 --> Database Driver Class Initialized
ERROR - 2016-05-24 18:37:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '2daw1516_isabel'@'localhost' (using password: YES) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2016-05-24 18:37:13 --> Unable to connect to the database
INFO - 2016-05-24 18:37:13 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-24 18:37:38 --> Config Class Initialized
INFO - 2016-05-24 18:37:38 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:37:38 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:37:38 --> Utf8 Class Initialized
INFO - 2016-05-24 18:37:38 --> URI Class Initialized
INFO - 2016-05-24 18:37:38 --> Router Class Initialized
INFO - 2016-05-24 18:37:38 --> Output Class Initialized
INFO - 2016-05-24 18:37:38 --> Security Class Initialized
DEBUG - 2016-05-24 18:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:37:38 --> Input Class Initialized
INFO - 2016-05-24 18:37:38 --> Language Class Initialized
INFO - 2016-05-24 18:37:38 --> Loader Class Initialized
INFO - 2016-05-24 18:37:38 --> Helper loaded: url_helper
INFO - 2016-05-24 18:37:38 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:37:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:37:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:37:38 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:37:38 --> Helper loaded: form_helper
INFO - 2016-05-24 18:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:37:39 --> Form Validation Class Initialized
INFO - 2016-05-24 18:37:39 --> Controller Class Initialized
INFO - 2016-05-24 18:37:39 --> Model Class Initialized
INFO - 2016-05-24 18:37:39 --> Database Driver Class Initialized
ERROR - 2016-05-24 18:37:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '2daw1516_isabel'@'localhost' (using password: YES) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2016-05-24 18:37:39 --> Unable to connect to the database
INFO - 2016-05-24 18:37:39 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-24 18:37:47 --> Config Class Initialized
INFO - 2016-05-24 18:37:47 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:37:47 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:37:47 --> Utf8 Class Initialized
INFO - 2016-05-24 18:37:47 --> URI Class Initialized
INFO - 2016-05-24 18:37:47 --> Router Class Initialized
INFO - 2016-05-24 18:37:47 --> Output Class Initialized
INFO - 2016-05-24 18:37:47 --> Security Class Initialized
DEBUG - 2016-05-24 18:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:37:47 --> Input Class Initialized
INFO - 2016-05-24 18:37:47 --> Language Class Initialized
INFO - 2016-05-24 18:37:47 --> Loader Class Initialized
INFO - 2016-05-24 18:37:47 --> Helper loaded: url_helper
INFO - 2016-05-24 18:37:47 --> Helper loaded: sesion_helper
INFO - 2016-05-24 18:37:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 18:37:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 18:37:47 --> Helper loaded: redondear_helper
INFO - 2016-05-24 18:37:47 --> Helper loaded: form_helper
INFO - 2016-05-24 18:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 18:37:47 --> Form Validation Class Initialized
INFO - 2016-05-24 18:37:47 --> Controller Class Initialized
INFO - 2016-05-24 18:37:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-24 18:37:47 --> Model Class Initialized
INFO - 2016-05-24 18:37:47 --> Database Driver Class Initialized
ERROR - 2016-05-24 18:37:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '2daw1516_isabel'@'localhost' (using password: YES) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2016-05-24 18:37:47 --> Unable to connect to the database
INFO - 2016-05-24 18:37:47 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-24 19:56:21 --> Config Class Initialized
INFO - 2016-05-24 19:56:21 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:56:21 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:56:21 --> Utf8 Class Initialized
INFO - 2016-05-24 19:56:21 --> URI Class Initialized
INFO - 2016-05-24 19:56:21 --> Router Class Initialized
INFO - 2016-05-24 19:56:21 --> Output Class Initialized
INFO - 2016-05-24 19:56:21 --> Security Class Initialized
DEBUG - 2016-05-24 19:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:56:21 --> Input Class Initialized
INFO - 2016-05-24 19:56:21 --> Language Class Initialized
INFO - 2016-05-24 19:56:21 --> Loader Class Initialized
INFO - 2016-05-24 19:56:21 --> Helper loaded: url_helper
INFO - 2016-05-24 19:56:21 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:56:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:56:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:56:21 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:56:21 --> Helper loaded: form_helper
INFO - 2016-05-24 19:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:56:21 --> Form Validation Class Initialized
INFO - 2016-05-24 19:56:21 --> Controller Class Initialized
INFO - 2016-05-24 19:56:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-24 19:56:21 --> Model Class Initialized
INFO - 2016-05-24 19:56:21 --> Database Driver Class Initialized
INFO - 2016-05-24 19:56:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:56:21 --> Final output sent to browser
DEBUG - 2016-05-24 19:56:21 --> Total execution time: 0.6086
INFO - 2016-05-24 19:56:22 --> Config Class Initialized
INFO - 2016-05-24 19:56:22 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:56:22 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:56:22 --> Utf8 Class Initialized
INFO - 2016-05-24 19:56:22 --> URI Class Initialized
INFO - 2016-05-24 19:56:22 --> Router Class Initialized
INFO - 2016-05-24 19:56:22 --> Output Class Initialized
INFO - 2016-05-24 19:56:22 --> Security Class Initialized
DEBUG - 2016-05-24 19:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:56:22 --> Input Class Initialized
INFO - 2016-05-24 19:56:22 --> Language Class Initialized
INFO - 2016-05-24 19:56:22 --> Loader Class Initialized
INFO - 2016-05-24 19:56:22 --> Helper loaded: url_helper
INFO - 2016-05-24 19:56:22 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:56:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:56:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:56:22 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:56:22 --> Helper loaded: form_helper
INFO - 2016-05-24 19:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:56:22 --> Form Validation Class Initialized
INFO - 2016-05-24 19:56:22 --> Controller Class Initialized
INFO - 2016-05-24 19:56:22 --> Model Class Initialized
INFO - 2016-05-24 19:56:22 --> Database Driver Class Initialized
INFO - 2016-05-24 19:56:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:56:22 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:56:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:56:22 --> Final output sent to browser
DEBUG - 2016-05-24 19:56:22 --> Total execution time: 0.1847
INFO - 2016-05-24 19:56:24 --> Config Class Initialized
INFO - 2016-05-24 19:56:24 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:56:24 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:56:24 --> Utf8 Class Initialized
INFO - 2016-05-24 19:56:24 --> URI Class Initialized
INFO - 2016-05-24 19:56:24 --> Router Class Initialized
INFO - 2016-05-24 19:56:24 --> Output Class Initialized
INFO - 2016-05-24 19:56:24 --> Security Class Initialized
DEBUG - 2016-05-24 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:56:24 --> Input Class Initialized
INFO - 2016-05-24 19:56:24 --> Language Class Initialized
INFO - 2016-05-24 19:56:24 --> Loader Class Initialized
INFO - 2016-05-24 19:56:24 --> Helper loaded: url_helper
INFO - 2016-05-24 19:56:24 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:56:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:56:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:56:24 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:56:24 --> Helper loaded: form_helper
INFO - 2016-05-24 19:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:56:24 --> Form Validation Class Initialized
INFO - 2016-05-24 19:56:24 --> Controller Class Initialized
INFO - 2016-05-24 19:56:24 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 19:56:24 --> Helper loaded: nif_validate_helper
INFO - 2016-05-24 19:56:24 --> Model Class Initialized
INFO - 2016-05-24 19:56:24 --> Database Driver Class Initialized
INFO - 2016-05-24 19:56:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-24 19:56:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 19:56:24 --> Final output sent to browser
DEBUG - 2016-05-24 19:56:24 --> Total execution time: 0.2179
INFO - 2016-05-24 19:56:25 --> Config Class Initialized
INFO - 2016-05-24 19:56:25 --> Hooks Class Initialized
DEBUG - 2016-05-24 19:56:25 --> UTF-8 Support Enabled
INFO - 2016-05-24 19:56:25 --> Utf8 Class Initialized
INFO - 2016-05-24 19:56:25 --> URI Class Initialized
INFO - 2016-05-24 19:56:25 --> Router Class Initialized
INFO - 2016-05-24 19:56:25 --> Output Class Initialized
INFO - 2016-05-24 19:56:25 --> Security Class Initialized
DEBUG - 2016-05-24 19:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 19:56:25 --> Input Class Initialized
INFO - 2016-05-24 19:56:25 --> Language Class Initialized
INFO - 2016-05-24 19:56:25 --> Loader Class Initialized
INFO - 2016-05-24 19:56:25 --> Helper loaded: url_helper
INFO - 2016-05-24 19:56:25 --> Helper loaded: sesion_helper
INFO - 2016-05-24 19:56:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 19:56:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 19:56:25 --> Helper loaded: redondear_helper
INFO - 2016-05-24 19:56:25 --> Helper loaded: form_helper
INFO - 2016-05-24 19:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 19:56:25 --> Form Validation Class Initialized
INFO - 2016-05-24 19:56:25 --> Controller Class Initialized
INFO - 2016-05-24 19:56:25 --> Model Class Initialized
INFO - 2016-05-24 19:56:25 --> Database Driver Class Initialized
INFO - 2016-05-24 19:56:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 19:56:25 --> Pagination Class Initialized
DEBUG - 2016-05-24 19:56:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 19:56:25 --> Final output sent to browser
DEBUG - 2016-05-24 19:56:25 --> Total execution time: 0.1180
INFO - 2016-05-24 20:33:04 --> Config Class Initialized
INFO - 2016-05-24 20:33:04 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:33:04 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:33:04 --> Utf8 Class Initialized
INFO - 2016-05-24 20:33:04 --> URI Class Initialized
DEBUG - 2016-05-24 20:33:04 --> No URI present. Default controller set.
INFO - 2016-05-24 20:33:04 --> Router Class Initialized
INFO - 2016-05-24 20:33:04 --> Output Class Initialized
INFO - 2016-05-24 20:33:04 --> Security Class Initialized
DEBUG - 2016-05-24 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:33:04 --> Input Class Initialized
INFO - 2016-05-24 20:33:04 --> Language Class Initialized
INFO - 2016-05-24 20:33:04 --> Loader Class Initialized
INFO - 2016-05-24 20:33:04 --> Helper loaded: url_helper
INFO - 2016-05-24 20:33:04 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:33:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:33:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:33:04 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:33:04 --> Helper loaded: form_helper
INFO - 2016-05-24 20:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:33:04 --> Form Validation Class Initialized
INFO - 2016-05-24 20:33:04 --> Controller Class Initialized
INFO - 2016-05-24 20:33:04 --> Model Class Initialized
INFO - 2016-05-24 20:33:04 --> Database Driver Class Initialized
INFO - 2016-05-24 20:33:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 20:33:04 --> Pagination Class Initialized
DEBUG - 2016-05-24 20:33:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 20:33:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-24 20:33:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template2.php
INFO - 2016-05-24 20:33:04 --> Final output sent to browser
DEBUG - 2016-05-24 20:33:04 --> Total execution time: 0.1235
INFO - 2016-05-24 20:33:14 --> Config Class Initialized
INFO - 2016-05-24 20:33:14 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:33:14 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:33:14 --> Utf8 Class Initialized
INFO - 2016-05-24 20:33:14 --> URI Class Initialized
DEBUG - 2016-05-24 20:33:14 --> No URI present. Default controller set.
INFO - 2016-05-24 20:33:14 --> Router Class Initialized
INFO - 2016-05-24 20:33:14 --> Output Class Initialized
INFO - 2016-05-24 20:33:14 --> Security Class Initialized
DEBUG - 2016-05-24 20:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:33:14 --> Input Class Initialized
INFO - 2016-05-24 20:33:14 --> Language Class Initialized
INFO - 2016-05-24 20:33:14 --> Loader Class Initialized
INFO - 2016-05-24 20:33:14 --> Helper loaded: url_helper
INFO - 2016-05-24 20:33:14 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:33:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:33:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:33:14 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:33:14 --> Helper loaded: form_helper
INFO - 2016-05-24 20:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:33:14 --> Form Validation Class Initialized
INFO - 2016-05-24 20:33:14 --> Controller Class Initialized
INFO - 2016-05-24 20:33:14 --> Model Class Initialized
INFO - 2016-05-24 20:33:14 --> Database Driver Class Initialized
INFO - 2016-05-24 20:33:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 20:33:14 --> Pagination Class Initialized
DEBUG - 2016-05-24 20:33:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 20:33:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-24 20:33:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template2.php
INFO - 2016-05-24 20:33:14 --> Final output sent to browser
DEBUG - 2016-05-24 20:33:14 --> Total execution time: 0.1030
INFO - 2016-05-24 20:33:16 --> Config Class Initialized
INFO - 2016-05-24 20:33:16 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:33:16 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:33:16 --> Utf8 Class Initialized
INFO - 2016-05-24 20:33:16 --> URI Class Initialized
INFO - 2016-05-24 20:33:16 --> Router Class Initialized
INFO - 2016-05-24 20:33:16 --> Output Class Initialized
INFO - 2016-05-24 20:33:16 --> Security Class Initialized
DEBUG - 2016-05-24 20:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:33:16 --> Input Class Initialized
INFO - 2016-05-24 20:33:16 --> Language Class Initialized
INFO - 2016-05-24 20:33:16 --> Loader Class Initialized
INFO - 2016-05-24 20:33:16 --> Helper loaded: url_helper
INFO - 2016-05-24 20:33:16 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:33:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:33:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:33:16 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:33:16 --> Helper loaded: form_helper
INFO - 2016-05-24 20:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:33:16 --> Form Validation Class Initialized
INFO - 2016-05-24 20:33:16 --> Controller Class Initialized
INFO - 2016-05-24 20:33:16 --> Model Class Initialized
INFO - 2016-05-24 20:33:16 --> Database Driver Class Initialized
INFO - 2016-05-24 20:33:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 20:33:16 --> Pagination Class Initialized
DEBUG - 2016-05-24 20:33:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 20:33:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_categoria.php
INFO - 2016-05-24 20:33:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template2.php
INFO - 2016-05-24 20:33:16 --> Final output sent to browser
DEBUG - 2016-05-24 20:33:16 --> Total execution time: 0.1086
INFO - 2016-05-24 20:33:27 --> Config Class Initialized
INFO - 2016-05-24 20:33:27 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:33:27 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:33:27 --> Utf8 Class Initialized
INFO - 2016-05-24 20:33:27 --> URI Class Initialized
INFO - 2016-05-24 20:33:27 --> Router Class Initialized
INFO - 2016-05-24 20:33:27 --> Output Class Initialized
INFO - 2016-05-24 20:33:27 --> Security Class Initialized
DEBUG - 2016-05-24 20:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:33:27 --> Input Class Initialized
INFO - 2016-05-24 20:33:27 --> Language Class Initialized
INFO - 2016-05-24 20:33:27 --> Loader Class Initialized
INFO - 2016-05-24 20:33:27 --> Helper loaded: url_helper
INFO - 2016-05-24 20:33:27 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:33:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:33:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:33:27 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:33:27 --> Helper loaded: form_helper
INFO - 2016-05-24 20:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:33:27 --> Form Validation Class Initialized
INFO - 2016-05-24 20:33:27 --> Controller Class Initialized
INFO - 2016-05-24 20:33:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-24 20:33:27 --> Model Class Initialized
INFO - 2016-05-24 20:33:27 --> Database Driver Class Initialized
INFO - 2016-05-24 20:33:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 20:33:27 --> Final output sent to browser
DEBUG - 2016-05-24 20:33:27 --> Total execution time: 0.0825
INFO - 2016-05-24 20:33:27 --> Config Class Initialized
INFO - 2016-05-24 20:33:27 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:33:27 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:33:27 --> Utf8 Class Initialized
INFO - 2016-05-24 20:33:27 --> URI Class Initialized
INFO - 2016-05-24 20:33:27 --> Router Class Initialized
INFO - 2016-05-24 20:33:27 --> Output Class Initialized
INFO - 2016-05-24 20:33:27 --> Security Class Initialized
DEBUG - 2016-05-24 20:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:33:27 --> Input Class Initialized
INFO - 2016-05-24 20:33:27 --> Language Class Initialized
INFO - 2016-05-24 20:33:27 --> Loader Class Initialized
INFO - 2016-05-24 20:33:27 --> Helper loaded: url_helper
INFO - 2016-05-24 20:33:27 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:33:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:33:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:33:27 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:33:27 --> Helper loaded: form_helper
INFO - 2016-05-24 20:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:33:27 --> Form Validation Class Initialized
INFO - 2016-05-24 20:33:27 --> Controller Class Initialized
INFO - 2016-05-24 20:33:27 --> Model Class Initialized
INFO - 2016-05-24 20:33:27 --> Database Driver Class Initialized
INFO - 2016-05-24 20:33:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 20:33:27 --> Pagination Class Initialized
DEBUG - 2016-05-24 20:33:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 20:33:27 --> Final output sent to browser
DEBUG - 2016-05-24 20:33:27 --> Total execution time: 0.0952
INFO - 2016-05-24 20:33:32 --> Config Class Initialized
INFO - 2016-05-24 20:33:32 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:33:32 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:33:32 --> Utf8 Class Initialized
INFO - 2016-05-24 20:33:32 --> URI Class Initialized
INFO - 2016-05-24 20:33:32 --> Router Class Initialized
INFO - 2016-05-24 20:33:32 --> Output Class Initialized
INFO - 2016-05-24 20:33:32 --> Security Class Initialized
DEBUG - 2016-05-24 20:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:33:32 --> Input Class Initialized
INFO - 2016-05-24 20:33:32 --> Language Class Initialized
INFO - 2016-05-24 20:33:32 --> Loader Class Initialized
INFO - 2016-05-24 20:33:32 --> Helper loaded: url_helper
INFO - 2016-05-24 20:33:32 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:33:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:33:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:33:32 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:33:32 --> Helper loaded: form_helper
INFO - 2016-05-24 20:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:33:32 --> Form Validation Class Initialized
INFO - 2016-05-24 20:33:32 --> Controller Class Initialized
INFO - 2016-05-24 20:33:32 --> Model Class Initialized
INFO - 2016-05-24 20:33:32 --> Database Driver Class Initialized
INFO - 2016-05-24 20:33:32 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 20:33:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 20:33:32 --> Pagination Class Initialized
DEBUG - 2016-05-24 20:33:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 20:33:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-24 20:33:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 20:33:32 --> Final output sent to browser
DEBUG - 2016-05-24 20:33:32 --> Total execution time: 0.1115
INFO - 2016-05-24 20:33:33 --> Config Class Initialized
INFO - 2016-05-24 20:33:33 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:33:33 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:33:33 --> Utf8 Class Initialized
INFO - 2016-05-24 20:33:33 --> URI Class Initialized
INFO - 2016-05-24 20:33:33 --> Router Class Initialized
INFO - 2016-05-24 20:33:33 --> Output Class Initialized
INFO - 2016-05-24 20:33:33 --> Security Class Initialized
DEBUG - 2016-05-24 20:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:33:33 --> Input Class Initialized
INFO - 2016-05-24 20:33:33 --> Language Class Initialized
INFO - 2016-05-24 20:33:33 --> Loader Class Initialized
INFO - 2016-05-24 20:33:33 --> Helper loaded: url_helper
INFO - 2016-05-24 20:33:33 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:33:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:33:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:33:33 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:33:33 --> Helper loaded: form_helper
INFO - 2016-05-24 20:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:33:33 --> Form Validation Class Initialized
INFO - 2016-05-24 20:33:33 --> Controller Class Initialized
INFO - 2016-05-24 20:33:33 --> Model Class Initialized
INFO - 2016-05-24 20:33:33 --> Database Driver Class Initialized
INFO - 2016-05-24 20:33:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 20:33:33 --> Pagination Class Initialized
DEBUG - 2016-05-24 20:33:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 20:33:33 --> Final output sent to browser
DEBUG - 2016-05-24 20:33:33 --> Total execution time: 0.1064
INFO - 2016-05-24 20:34:34 --> Config Class Initialized
INFO - 2016-05-24 20:34:34 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:34:34 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:34:34 --> Utf8 Class Initialized
INFO - 2016-05-24 20:34:34 --> URI Class Initialized
INFO - 2016-05-24 20:34:34 --> Router Class Initialized
INFO - 2016-05-24 20:34:34 --> Output Class Initialized
INFO - 2016-05-24 20:34:34 --> Security Class Initialized
DEBUG - 2016-05-24 20:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:34:34 --> Input Class Initialized
INFO - 2016-05-24 20:34:34 --> Language Class Initialized
INFO - 2016-05-24 20:34:34 --> Loader Class Initialized
INFO - 2016-05-24 20:34:34 --> Helper loaded: url_helper
INFO - 2016-05-24 20:34:34 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:34:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:34:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:34:34 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:34:34 --> Helper loaded: form_helper
INFO - 2016-05-24 20:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:34:34 --> Form Validation Class Initialized
INFO - 2016-05-24 20:34:34 --> Controller Class Initialized
INFO - 2016-05-24 20:34:34 --> Model Class Initialized
INFO - 2016-05-24 20:34:34 --> Database Driver Class Initialized
INFO - 2016-05-24 20:34:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 20:34:34 --> Pagination Class Initialized
DEBUG - 2016-05-24 20:34:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 20:34:34 --> Final output sent to browser
DEBUG - 2016-05-24 20:34:34 --> Total execution time: 0.0699
INFO - 2016-05-24 20:35:32 --> Config Class Initialized
INFO - 2016-05-24 20:35:32 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:35:32 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:35:32 --> Utf8 Class Initialized
INFO - 2016-05-24 20:35:32 --> URI Class Initialized
INFO - 2016-05-24 20:35:32 --> Router Class Initialized
INFO - 2016-05-24 20:35:32 --> Output Class Initialized
INFO - 2016-05-24 20:35:32 --> Security Class Initialized
DEBUG - 2016-05-24 20:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:35:32 --> Input Class Initialized
INFO - 2016-05-24 20:35:32 --> Language Class Initialized
INFO - 2016-05-24 20:35:32 --> Loader Class Initialized
INFO - 2016-05-24 20:35:32 --> Helper loaded: url_helper
INFO - 2016-05-24 20:35:32 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:35:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:35:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:35:32 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:35:32 --> Helper loaded: form_helper
INFO - 2016-05-24 20:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:35:32 --> Form Validation Class Initialized
INFO - 2016-05-24 20:35:32 --> Controller Class Initialized
INFO - 2016-05-24 20:35:32 --> Model Class Initialized
INFO - 2016-05-24 20:35:32 --> Database Driver Class Initialized
INFO - 2016-05-24 20:35:32 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 20:35:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 20:35:32 --> Pagination Class Initialized
DEBUG - 2016-05-24 20:35:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 20:35:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-24 20:35:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 20:35:32 --> Final output sent to browser
DEBUG - 2016-05-24 20:35:32 --> Total execution time: 0.0963
INFO - 2016-05-24 20:35:32 --> Config Class Initialized
INFO - 2016-05-24 20:35:32 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:35:32 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:35:32 --> Utf8 Class Initialized
INFO - 2016-05-24 20:35:32 --> URI Class Initialized
INFO - 2016-05-24 20:35:32 --> Router Class Initialized
INFO - 2016-05-24 20:35:32 --> Output Class Initialized
INFO - 2016-05-24 20:35:32 --> Security Class Initialized
DEBUG - 2016-05-24 20:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:35:32 --> Input Class Initialized
INFO - 2016-05-24 20:35:32 --> Language Class Initialized
INFO - 2016-05-24 20:35:32 --> Loader Class Initialized
INFO - 2016-05-24 20:35:32 --> Helper loaded: url_helper
INFO - 2016-05-24 20:35:32 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:35:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:35:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:35:32 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:35:32 --> Helper loaded: form_helper
INFO - 2016-05-24 20:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:35:32 --> Form Validation Class Initialized
INFO - 2016-05-24 20:35:32 --> Controller Class Initialized
INFO - 2016-05-24 20:35:32 --> Model Class Initialized
INFO - 2016-05-24 20:35:32 --> Database Driver Class Initialized
INFO - 2016-05-24 20:35:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 20:35:32 --> Pagination Class Initialized
DEBUG - 2016-05-24 20:35:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 20:35:32 --> Final output sent to browser
DEBUG - 2016-05-24 20:35:32 --> Total execution time: 0.1017
INFO - 2016-05-24 20:36:25 --> Config Class Initialized
INFO - 2016-05-24 20:36:25 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:36:25 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:36:25 --> Utf8 Class Initialized
INFO - 2016-05-24 20:36:25 --> URI Class Initialized
INFO - 2016-05-24 20:36:25 --> Router Class Initialized
INFO - 2016-05-24 20:36:25 --> Output Class Initialized
INFO - 2016-05-24 20:36:25 --> Security Class Initialized
DEBUG - 2016-05-24 20:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:36:25 --> Input Class Initialized
INFO - 2016-05-24 20:36:25 --> Language Class Initialized
INFO - 2016-05-24 20:36:25 --> Loader Class Initialized
INFO - 2016-05-24 20:36:25 --> Helper loaded: url_helper
INFO - 2016-05-24 20:36:25 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:36:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:36:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:36:25 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:36:25 --> Helper loaded: form_helper
INFO - 2016-05-24 20:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:36:25 --> Form Validation Class Initialized
INFO - 2016-05-24 20:36:25 --> Controller Class Initialized
INFO - 2016-05-24 20:36:25 --> Model Class Initialized
INFO - 2016-05-24 20:36:25 --> Database Driver Class Initialized
INFO - 2016-05-24 20:36:25 --> Helper loaded: creaselect_helper
INFO - 2016-05-24 20:36:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 20:36:25 --> Pagination Class Initialized
DEBUG - 2016-05-24 20:36:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 20:36:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-24 20:36:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-24 20:36:25 --> Final output sent to browser
DEBUG - 2016-05-24 20:36:25 --> Total execution time: 0.1003
INFO - 2016-05-24 20:36:25 --> Config Class Initialized
INFO - 2016-05-24 20:36:25 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:36:25 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:36:25 --> Utf8 Class Initialized
INFO - 2016-05-24 20:36:25 --> URI Class Initialized
INFO - 2016-05-24 20:36:25 --> Router Class Initialized
INFO - 2016-05-24 20:36:25 --> Output Class Initialized
INFO - 2016-05-24 20:36:25 --> Security Class Initialized
DEBUG - 2016-05-24 20:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:36:25 --> Input Class Initialized
INFO - 2016-05-24 20:36:25 --> Language Class Initialized
INFO - 2016-05-24 20:36:25 --> Loader Class Initialized
INFO - 2016-05-24 20:36:25 --> Helper loaded: url_helper
INFO - 2016-05-24 20:36:25 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:36:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:36:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:36:25 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:36:25 --> Helper loaded: form_helper
INFO - 2016-05-24 20:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:36:25 --> Form Validation Class Initialized
INFO - 2016-05-24 20:36:25 --> Controller Class Initialized
INFO - 2016-05-24 20:36:25 --> Model Class Initialized
INFO - 2016-05-24 20:36:25 --> Database Driver Class Initialized
INFO - 2016-05-24 20:36:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 20:36:25 --> Pagination Class Initialized
DEBUG - 2016-05-24 20:36:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 20:36:25 --> Final output sent to browser
DEBUG - 2016-05-24 20:36:25 --> Total execution time: 0.1040
INFO - 2016-05-24 20:37:26 --> Config Class Initialized
INFO - 2016-05-24 20:37:26 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:37:26 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:37:26 --> Utf8 Class Initialized
INFO - 2016-05-24 20:37:26 --> URI Class Initialized
INFO - 2016-05-24 20:37:26 --> Router Class Initialized
INFO - 2016-05-24 20:37:26 --> Output Class Initialized
INFO - 2016-05-24 20:37:26 --> Security Class Initialized
DEBUG - 2016-05-24 20:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:37:26 --> Input Class Initialized
INFO - 2016-05-24 20:37:26 --> Language Class Initialized
INFO - 2016-05-24 20:37:26 --> Loader Class Initialized
INFO - 2016-05-24 20:37:26 --> Helper loaded: url_helper
INFO - 2016-05-24 20:37:26 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:37:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:37:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:37:26 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:37:26 --> Helper loaded: form_helper
INFO - 2016-05-24 20:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:37:26 --> Form Validation Class Initialized
INFO - 2016-05-24 20:37:26 --> Controller Class Initialized
INFO - 2016-05-24 20:37:26 --> Model Class Initialized
INFO - 2016-05-24 20:37:26 --> Database Driver Class Initialized
INFO - 2016-05-24 20:37:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 20:37:26 --> Pagination Class Initialized
DEBUG - 2016-05-24 20:37:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 20:37:26 --> Final output sent to browser
DEBUG - 2016-05-24 20:37:26 --> Total execution time: 0.0748
INFO - 2016-05-24 20:37:33 --> Config Class Initialized
INFO - 2016-05-24 20:37:33 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:37:33 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:37:33 --> Utf8 Class Initialized
INFO - 2016-05-24 20:37:33 --> URI Class Initialized
DEBUG - 2016-05-24 20:37:33 --> No URI present. Default controller set.
INFO - 2016-05-24 20:37:33 --> Router Class Initialized
INFO - 2016-05-24 20:37:33 --> Output Class Initialized
INFO - 2016-05-24 20:37:33 --> Security Class Initialized
DEBUG - 2016-05-24 20:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:37:33 --> Input Class Initialized
INFO - 2016-05-24 20:37:33 --> Language Class Initialized
INFO - 2016-05-24 20:37:33 --> Loader Class Initialized
INFO - 2016-05-24 20:37:33 --> Helper loaded: url_helper
INFO - 2016-05-24 20:37:33 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:37:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:37:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:37:33 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:37:33 --> Helper loaded: form_helper
INFO - 2016-05-24 20:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:37:33 --> Form Validation Class Initialized
INFO - 2016-05-24 20:37:33 --> Controller Class Initialized
INFO - 2016-05-24 20:37:33 --> Model Class Initialized
INFO - 2016-05-24 20:37:33 --> Database Driver Class Initialized
INFO - 2016-05-24 20:37:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 20:37:33 --> Pagination Class Initialized
DEBUG - 2016-05-24 20:37:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 20:37:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-24 20:37:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template2.php
INFO - 2016-05-24 20:37:33 --> Final output sent to browser
DEBUG - 2016-05-24 20:37:33 --> Total execution time: 0.0882
INFO - 2016-05-24 20:37:36 --> Config Class Initialized
INFO - 2016-05-24 20:37:36 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:37:36 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:37:36 --> Utf8 Class Initialized
INFO - 2016-05-24 20:37:36 --> URI Class Initialized
INFO - 2016-05-24 20:37:36 --> Router Class Initialized
INFO - 2016-05-24 20:37:36 --> Output Class Initialized
INFO - 2016-05-24 20:37:36 --> Security Class Initialized
DEBUG - 2016-05-24 20:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:37:36 --> Input Class Initialized
INFO - 2016-05-24 20:37:36 --> Language Class Initialized
INFO - 2016-05-24 20:37:36 --> Loader Class Initialized
INFO - 2016-05-24 20:37:36 --> Helper loaded: url_helper
INFO - 2016-05-24 20:37:36 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:37:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:37:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:37:36 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:37:36 --> Helper loaded: form_helper
INFO - 2016-05-24 20:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:37:36 --> Form Validation Class Initialized
INFO - 2016-05-24 20:37:36 --> Controller Class Initialized
INFO - 2016-05-24 20:37:36 --> Model Class Initialized
INFO - 2016-05-24 20:37:36 --> Database Driver Class Initialized
INFO - 2016-05-24 20:37:36 --> Config Class Initialized
INFO - 2016-05-24 20:37:36 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:37:36 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:37:36 --> Utf8 Class Initialized
INFO - 2016-05-24 20:37:36 --> URI Class Initialized
INFO - 2016-05-24 20:37:36 --> Router Class Initialized
INFO - 2016-05-24 20:37:36 --> Output Class Initialized
INFO - 2016-05-24 20:37:36 --> Security Class Initialized
DEBUG - 2016-05-24 20:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:37:36 --> Input Class Initialized
INFO - 2016-05-24 20:37:36 --> Language Class Initialized
INFO - 2016-05-24 20:37:36 --> Loader Class Initialized
INFO - 2016-05-24 20:37:36 --> Helper loaded: url_helper
INFO - 2016-05-24 20:37:36 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:37:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:37:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:37:36 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:37:36 --> Helper loaded: form_helper
INFO - 2016-05-24 20:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:37:36 --> Form Validation Class Initialized
INFO - 2016-05-24 20:37:36 --> Controller Class Initialized
INFO - 2016-05-24 20:37:36 --> Model Class Initialized
INFO - 2016-05-24 20:37:36 --> Database Driver Class Initialized
INFO - 2016-05-24 20:37:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-24 20:37:36 --> Final output sent to browser
DEBUG - 2016-05-24 20:37:36 --> Total execution time: 0.0692
INFO - 2016-05-24 20:37:41 --> Config Class Initialized
INFO - 2016-05-24 20:37:41 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:37:41 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:37:41 --> Utf8 Class Initialized
INFO - 2016-05-24 20:37:41 --> URI Class Initialized
DEBUG - 2016-05-24 20:37:41 --> No URI present. Default controller set.
INFO - 2016-05-24 20:37:41 --> Router Class Initialized
INFO - 2016-05-24 20:37:41 --> Output Class Initialized
INFO - 2016-05-24 20:37:41 --> Security Class Initialized
DEBUG - 2016-05-24 20:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:37:41 --> Input Class Initialized
INFO - 2016-05-24 20:37:41 --> Language Class Initialized
INFO - 2016-05-24 20:37:41 --> Loader Class Initialized
INFO - 2016-05-24 20:37:41 --> Helper loaded: url_helper
INFO - 2016-05-24 20:37:41 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:37:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:37:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:37:41 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:37:41 --> Helper loaded: form_helper
INFO - 2016-05-24 20:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:37:41 --> Form Validation Class Initialized
INFO - 2016-05-24 20:37:41 --> Controller Class Initialized
INFO - 2016-05-24 20:37:41 --> Model Class Initialized
INFO - 2016-05-24 20:37:41 --> Database Driver Class Initialized
INFO - 2016-05-24 20:37:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-24 20:37:41 --> Pagination Class Initialized
DEBUG - 2016-05-24 20:37:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-24 20:37:41 --> Config Class Initialized
INFO - 2016-05-24 20:37:41 --> Hooks Class Initialized
DEBUG - 2016-05-24 20:37:41 --> UTF-8 Support Enabled
INFO - 2016-05-24 20:37:41 --> Utf8 Class Initialized
INFO - 2016-05-24 20:37:41 --> URI Class Initialized
INFO - 2016-05-24 20:37:41 --> Router Class Initialized
INFO - 2016-05-24 20:37:41 --> Output Class Initialized
INFO - 2016-05-24 20:37:41 --> Security Class Initialized
DEBUG - 2016-05-24 20:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 20:37:41 --> Input Class Initialized
INFO - 2016-05-24 20:37:41 --> Language Class Initialized
INFO - 2016-05-24 20:37:41 --> Loader Class Initialized
INFO - 2016-05-24 20:37:41 --> Helper loaded: url_helper
INFO - 2016-05-24 20:37:41 --> Helper loaded: sesion_helper
INFO - 2016-05-24 20:37:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-24 20:37:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-24 20:37:41 --> Helper loaded: redondear_helper
INFO - 2016-05-24 20:37:41 --> Helper loaded: form_helper
INFO - 2016-05-24 20:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-24 20:37:41 --> Form Validation Class Initialized
INFO - 2016-05-24 20:37:41 --> Controller Class Initialized
INFO - 2016-05-24 20:37:41 --> Model Class Initialized
INFO - 2016-05-24 20:37:41 --> Database Driver Class Initialized
INFO - 2016-05-24 20:37:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-24 20:37:41 --> Final output sent to browser
DEBUG - 2016-05-24 20:37:41 --> Total execution time: 0.0916
