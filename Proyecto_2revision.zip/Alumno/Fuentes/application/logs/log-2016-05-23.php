<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-23 08:45:52 --> Config Class Initialized
INFO - 2016-05-23 08:45:52 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:45:52 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:45:52 --> Utf8 Class Initialized
INFO - 2016-05-23 08:45:52 --> URI Class Initialized
DEBUG - 2016-05-23 08:45:52 --> No URI present. Default controller set.
INFO - 2016-05-23 08:45:52 --> Router Class Initialized
INFO - 2016-05-23 08:45:52 --> Output Class Initialized
INFO - 2016-05-23 08:45:52 --> Security Class Initialized
DEBUG - 2016-05-23 08:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:45:52 --> Input Class Initialized
INFO - 2016-05-23 08:45:52 --> Language Class Initialized
INFO - 2016-05-23 08:45:52 --> Loader Class Initialized
INFO - 2016-05-23 08:45:52 --> Helper loaded: url_helper
INFO - 2016-05-23 08:45:52 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:45:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:45:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:45:52 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:45:52 --> Helper loaded: form_helper
INFO - 2016-05-23 08:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:45:52 --> Form Validation Class Initialized
INFO - 2016-05-23 08:45:52 --> Controller Class Initialized
INFO - 2016-05-23 08:45:52 --> Model Class Initialized
INFO - 2016-05-23 08:45:52 --> Database Driver Class Initialized
INFO - 2016-05-23 08:45:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 08:45:52 --> Pagination Class Initialized
DEBUG - 2016-05-23 08:45:52 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 08:45:52 --> Config Class Initialized
INFO - 2016-05-23 08:45:52 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:45:52 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:45:52 --> Utf8 Class Initialized
INFO - 2016-05-23 08:45:52 --> URI Class Initialized
INFO - 2016-05-23 08:45:52 --> Router Class Initialized
INFO - 2016-05-23 08:45:52 --> Output Class Initialized
INFO - 2016-05-23 08:45:52 --> Security Class Initialized
DEBUG - 2016-05-23 08:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:45:52 --> Input Class Initialized
INFO - 2016-05-23 08:45:52 --> Language Class Initialized
INFO - 2016-05-23 08:45:52 --> Loader Class Initialized
INFO - 2016-05-23 08:45:52 --> Helper loaded: url_helper
INFO - 2016-05-23 08:45:52 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:45:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:45:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:45:52 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:45:52 --> Helper loaded: form_helper
INFO - 2016-05-23 08:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:45:52 --> Form Validation Class Initialized
INFO - 2016-05-23 08:45:52 --> Controller Class Initialized
INFO - 2016-05-23 08:45:52 --> Model Class Initialized
INFO - 2016-05-23 08:45:52 --> Database Driver Class Initialized
INFO - 2016-05-23 08:45:52 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_login.php
INFO - 2016-05-23 08:45:52 --> Final output sent to browser
DEBUG - 2016-05-23 08:45:52 --> Total execution time: 0.0616
INFO - 2016-05-23 08:55:23 --> Config Class Initialized
INFO - 2016-05-23 08:55:23 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:55:23 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:55:23 --> Utf8 Class Initialized
INFO - 2016-05-23 08:55:23 --> URI Class Initialized
DEBUG - 2016-05-23 08:55:23 --> No URI present. Default controller set.
INFO - 2016-05-23 08:55:23 --> Router Class Initialized
INFO - 2016-05-23 08:55:23 --> Output Class Initialized
INFO - 2016-05-23 08:55:23 --> Security Class Initialized
DEBUG - 2016-05-23 08:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:55:23 --> Input Class Initialized
INFO - 2016-05-23 08:55:23 --> Language Class Initialized
INFO - 2016-05-23 08:55:23 --> Loader Class Initialized
INFO - 2016-05-23 08:55:23 --> Helper loaded: url_helper
INFO - 2016-05-23 08:55:23 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:55:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:55:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:55:23 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:55:23 --> Helper loaded: form_helper
INFO - 2016-05-23 08:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:55:23 --> Form Validation Class Initialized
INFO - 2016-05-23 08:55:23 --> Controller Class Initialized
INFO - 2016-05-23 08:55:23 --> Model Class Initialized
INFO - 2016-05-23 08:55:23 --> Database Driver Class Initialized
INFO - 2016-05-23 08:55:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 08:55:23 --> Pagination Class Initialized
DEBUG - 2016-05-23 08:55:23 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 08:55:23 --> Config Class Initialized
INFO - 2016-05-23 08:55:23 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:55:23 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:55:23 --> Utf8 Class Initialized
INFO - 2016-05-23 08:55:23 --> URI Class Initialized
INFO - 2016-05-23 08:55:23 --> Router Class Initialized
INFO - 2016-05-23 08:55:23 --> Output Class Initialized
INFO - 2016-05-23 08:55:23 --> Security Class Initialized
DEBUG - 2016-05-23 08:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:55:23 --> Input Class Initialized
INFO - 2016-05-23 08:55:23 --> Language Class Initialized
INFO - 2016-05-23 08:55:23 --> Loader Class Initialized
INFO - 2016-05-23 08:55:23 --> Helper loaded: url_helper
INFO - 2016-05-23 08:55:23 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:55:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:55:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:55:23 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:55:23 --> Helper loaded: form_helper
INFO - 2016-05-23 08:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:55:23 --> Form Validation Class Initialized
INFO - 2016-05-23 08:55:23 --> Controller Class Initialized
INFO - 2016-05-23 08:55:23 --> Model Class Initialized
INFO - 2016-05-23 08:55:23 --> Database Driver Class Initialized
INFO - 2016-05-23 08:55:23 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_login.php
INFO - 2016-05-23 08:55:23 --> Final output sent to browser
DEBUG - 2016-05-23 08:55:23 --> Total execution time: 0.0456
INFO - 2016-05-23 08:55:25 --> Config Class Initialized
INFO - 2016-05-23 08:55:25 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:55:25 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:55:25 --> Utf8 Class Initialized
INFO - 2016-05-23 08:55:25 --> URI Class Initialized
INFO - 2016-05-23 08:55:25 --> Router Class Initialized
INFO - 2016-05-23 08:55:25 --> Output Class Initialized
INFO - 2016-05-23 08:55:25 --> Security Class Initialized
DEBUG - 2016-05-23 08:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:55:25 --> Input Class Initialized
INFO - 2016-05-23 08:55:25 --> Language Class Initialized
INFO - 2016-05-23 08:55:25 --> Loader Class Initialized
INFO - 2016-05-23 08:55:25 --> Helper loaded: url_helper
INFO - 2016-05-23 08:55:25 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:55:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:55:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:55:25 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:55:25 --> Helper loaded: form_helper
INFO - 2016-05-23 08:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:55:25 --> Form Validation Class Initialized
INFO - 2016-05-23 08:55:25 --> Controller Class Initialized
INFO - 2016-05-23 08:55:25 --> Model Class Initialized
INFO - 2016-05-23 08:55:25 --> Database Driver Class Initialized
INFO - 2016-05-23 08:55:25 --> Email Class Initialized
INFO - 2016-05-23 08:55:25 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_restablecerClave.php
INFO - 2016-05-23 08:55:25 --> Final output sent to browser
DEBUG - 2016-05-23 08:55:25 --> Total execution time: 0.1184
INFO - 2016-05-23 08:55:30 --> Config Class Initialized
INFO - 2016-05-23 08:55:30 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:55:30 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:55:30 --> Utf8 Class Initialized
INFO - 2016-05-23 08:55:30 --> URI Class Initialized
INFO - 2016-05-23 08:55:30 --> Router Class Initialized
INFO - 2016-05-23 08:55:30 --> Output Class Initialized
INFO - 2016-05-23 08:55:30 --> Security Class Initialized
DEBUG - 2016-05-23 08:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:55:30 --> Input Class Initialized
INFO - 2016-05-23 08:55:30 --> Language Class Initialized
INFO - 2016-05-23 08:55:30 --> Loader Class Initialized
INFO - 2016-05-23 08:55:30 --> Helper loaded: url_helper
INFO - 2016-05-23 08:55:30 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:55:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:55:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:55:30 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:55:30 --> Helper loaded: form_helper
INFO - 2016-05-23 08:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:55:30 --> Form Validation Class Initialized
INFO - 2016-05-23 08:55:30 --> Controller Class Initialized
INFO - 2016-05-23 08:55:30 --> Model Class Initialized
INFO - 2016-05-23 08:55:30 --> Database Driver Class Initialized
INFO - 2016-05-23 08:55:30 --> Email Class Initialized
INFO - 2016-05-23 08:55:30 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-23 08:55:30 --> Language file loaded: language/spanish/email_lang.php
INFO - 2016-05-23 08:55:30 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_mailIncorrecto.php
INFO - 2016-05-23 08:55:30 --> Final output sent to browser
DEBUG - 2016-05-23 08:55:30 --> Total execution time: 0.3819
INFO - 2016-05-23 08:55:35 --> Config Class Initialized
INFO - 2016-05-23 08:55:35 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:55:35 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:55:35 --> Utf8 Class Initialized
INFO - 2016-05-23 08:55:35 --> URI Class Initialized
INFO - 2016-05-23 08:55:35 --> Router Class Initialized
INFO - 2016-05-23 08:55:35 --> Output Class Initialized
INFO - 2016-05-23 08:55:35 --> Security Class Initialized
DEBUG - 2016-05-23 08:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:55:35 --> Input Class Initialized
INFO - 2016-05-23 08:55:35 --> Language Class Initialized
INFO - 2016-05-23 08:55:35 --> Loader Class Initialized
INFO - 2016-05-23 08:55:35 --> Helper loaded: url_helper
INFO - 2016-05-23 08:55:35 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:55:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:55:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:55:35 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:55:35 --> Helper loaded: form_helper
INFO - 2016-05-23 08:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:55:35 --> Form Validation Class Initialized
INFO - 2016-05-23 08:55:35 --> Controller Class Initialized
INFO - 2016-05-23 08:55:35 --> Model Class Initialized
INFO - 2016-05-23 08:55:35 --> Database Driver Class Initialized
INFO - 2016-05-23 08:55:35 --> Email Class Initialized
INFO - 2016-05-23 08:55:35 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_restablecerClave.php
INFO - 2016-05-23 08:55:35 --> Final output sent to browser
DEBUG - 2016-05-23 08:55:35 --> Total execution time: 0.0511
INFO - 2016-05-23 08:55:41 --> Config Class Initialized
INFO - 2016-05-23 08:55:41 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:55:41 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:55:41 --> Utf8 Class Initialized
INFO - 2016-05-23 08:55:41 --> URI Class Initialized
INFO - 2016-05-23 08:55:41 --> Router Class Initialized
INFO - 2016-05-23 08:55:41 --> Output Class Initialized
INFO - 2016-05-23 08:55:41 --> Security Class Initialized
DEBUG - 2016-05-23 08:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:55:41 --> Input Class Initialized
INFO - 2016-05-23 08:55:41 --> Language Class Initialized
INFO - 2016-05-23 08:55:41 --> Loader Class Initialized
INFO - 2016-05-23 08:55:41 --> Helper loaded: url_helper
INFO - 2016-05-23 08:55:41 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:55:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:55:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:55:41 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:55:41 --> Helper loaded: form_helper
INFO - 2016-05-23 08:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:55:41 --> Form Validation Class Initialized
INFO - 2016-05-23 08:55:41 --> Controller Class Initialized
INFO - 2016-05-23 08:55:41 --> Model Class Initialized
INFO - 2016-05-23 08:55:41 --> Database Driver Class Initialized
INFO - 2016-05-23 08:55:41 --> Email Class Initialized
INFO - 2016-05-23 08:55:41 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-23 08:55:42 --> Language file loaded: language/spanish/email_lang.php
INFO - 2016-05-23 08:55:42 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_mailCorrecto.php
INFO - 2016-05-23 08:55:42 --> Final output sent to browser
DEBUG - 2016-05-23 08:55:42 --> Total execution time: 0.1893
INFO - 2016-05-23 08:56:00 --> Config Class Initialized
INFO - 2016-05-23 08:56:00 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:56:00 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:56:00 --> Utf8 Class Initialized
INFO - 2016-05-23 08:56:00 --> URI Class Initialized
INFO - 2016-05-23 08:56:00 --> Router Class Initialized
INFO - 2016-05-23 08:56:00 --> Output Class Initialized
INFO - 2016-05-23 08:56:00 --> Security Class Initialized
DEBUG - 2016-05-23 08:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:56:00 --> Input Class Initialized
INFO - 2016-05-23 08:56:00 --> Language Class Initialized
INFO - 2016-05-23 08:56:00 --> Loader Class Initialized
INFO - 2016-05-23 08:56:00 --> Helper loaded: url_helper
INFO - 2016-05-23 08:56:00 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:56:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:56:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:56:00 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:56:00 --> Helper loaded: form_helper
INFO - 2016-05-23 08:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:56:00 --> Form Validation Class Initialized
INFO - 2016-05-23 08:56:00 --> Controller Class Initialized
INFO - 2016-05-23 08:56:00 --> Model Class Initialized
INFO - 2016-05-23 08:56:00 --> Database Driver Class Initialized
INFO - 2016-05-23 08:56:00 --> Email Class Initialized
INFO - 2016-05-23 08:56:00 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_pideClaveRestablecer.php
INFO - 2016-05-23 08:56:00 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_template1.php
INFO - 2016-05-23 08:56:00 --> Final output sent to browser
DEBUG - 2016-05-23 08:56:00 --> Total execution time: 0.1302
INFO - 2016-05-23 08:56:03 --> Config Class Initialized
INFO - 2016-05-23 08:56:03 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:56:03 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:56:03 --> Utf8 Class Initialized
INFO - 2016-05-23 08:56:03 --> URI Class Initialized
INFO - 2016-05-23 08:56:03 --> Router Class Initialized
INFO - 2016-05-23 08:56:03 --> Output Class Initialized
INFO - 2016-05-23 08:56:03 --> Security Class Initialized
DEBUG - 2016-05-23 08:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:56:03 --> Input Class Initialized
INFO - 2016-05-23 08:56:03 --> Language Class Initialized
INFO - 2016-05-23 08:56:03 --> Loader Class Initialized
INFO - 2016-05-23 08:56:03 --> Helper loaded: url_helper
INFO - 2016-05-23 08:56:03 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:56:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:56:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:56:03 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:56:03 --> Helper loaded: form_helper
INFO - 2016-05-23 08:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:56:03 --> Form Validation Class Initialized
INFO - 2016-05-23 08:56:03 --> Controller Class Initialized
INFO - 2016-05-23 08:56:03 --> Model Class Initialized
INFO - 2016-05-23 08:56:03 --> Database Driver Class Initialized
INFO - 2016-05-23 08:56:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 08:56:03 --> Pagination Class Initialized
DEBUG - 2016-05-23 08:56:03 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 08:56:04 --> Config Class Initialized
INFO - 2016-05-23 08:56:04 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:56:04 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:56:04 --> Utf8 Class Initialized
INFO - 2016-05-23 08:56:04 --> URI Class Initialized
INFO - 2016-05-23 08:56:04 --> Router Class Initialized
INFO - 2016-05-23 08:56:04 --> Output Class Initialized
INFO - 2016-05-23 08:56:04 --> Security Class Initialized
DEBUG - 2016-05-23 08:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:56:04 --> Input Class Initialized
INFO - 2016-05-23 08:56:04 --> Language Class Initialized
INFO - 2016-05-23 08:56:04 --> Loader Class Initialized
INFO - 2016-05-23 08:56:04 --> Helper loaded: url_helper
INFO - 2016-05-23 08:56:04 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:56:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:56:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:56:04 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:56:04 --> Helper loaded: form_helper
INFO - 2016-05-23 08:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:56:04 --> Form Validation Class Initialized
INFO - 2016-05-23 08:56:04 --> Controller Class Initialized
INFO - 2016-05-23 08:56:04 --> Model Class Initialized
INFO - 2016-05-23 08:56:04 --> Database Driver Class Initialized
INFO - 2016-05-23 08:56:04 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_login.php
INFO - 2016-05-23 08:56:04 --> Final output sent to browser
DEBUG - 2016-05-23 08:56:04 --> Total execution time: 0.0483
INFO - 2016-05-23 08:56:18 --> Config Class Initialized
INFO - 2016-05-23 08:56:18 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:56:18 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:56:18 --> Utf8 Class Initialized
INFO - 2016-05-23 08:56:18 --> URI Class Initialized
INFO - 2016-05-23 08:56:18 --> Router Class Initialized
INFO - 2016-05-23 08:56:18 --> Output Class Initialized
INFO - 2016-05-23 08:56:18 --> Security Class Initialized
DEBUG - 2016-05-23 08:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:56:18 --> Input Class Initialized
INFO - 2016-05-23 08:56:18 --> Language Class Initialized
INFO - 2016-05-23 08:56:18 --> Loader Class Initialized
INFO - 2016-05-23 08:56:18 --> Helper loaded: url_helper
INFO - 2016-05-23 08:56:18 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:56:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:56:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:56:18 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:56:18 --> Helper loaded: form_helper
INFO - 2016-05-23 08:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:56:18 --> Form Validation Class Initialized
INFO - 2016-05-23 08:56:18 --> Controller Class Initialized
INFO - 2016-05-23 08:56:18 --> Model Class Initialized
INFO - 2016-05-23 08:56:18 --> Database Driver Class Initialized
INFO - 2016-05-23 08:56:18 --> Email Class Initialized
INFO - 2016-05-23 08:56:18 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_restablecerClave.php
INFO - 2016-05-23 08:56:18 --> Final output sent to browser
DEBUG - 2016-05-23 08:56:18 --> Total execution time: 0.0649
INFO - 2016-05-23 08:56:21 --> Config Class Initialized
INFO - 2016-05-23 08:56:21 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:56:21 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:56:21 --> Utf8 Class Initialized
INFO - 2016-05-23 08:56:21 --> URI Class Initialized
INFO - 2016-05-23 08:56:21 --> Router Class Initialized
INFO - 2016-05-23 08:56:21 --> Output Class Initialized
INFO - 2016-05-23 08:56:21 --> Security Class Initialized
DEBUG - 2016-05-23 08:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:56:21 --> Input Class Initialized
INFO - 2016-05-23 08:56:21 --> Language Class Initialized
INFO - 2016-05-23 08:56:21 --> Loader Class Initialized
INFO - 2016-05-23 08:56:21 --> Helper loaded: url_helper
INFO - 2016-05-23 08:56:21 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:56:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:56:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:56:21 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:56:21 --> Helper loaded: form_helper
INFO - 2016-05-23 08:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:56:21 --> Form Validation Class Initialized
INFO - 2016-05-23 08:56:21 --> Controller Class Initialized
INFO - 2016-05-23 08:56:21 --> Model Class Initialized
INFO - 2016-05-23 08:56:21 --> Database Driver Class Initialized
INFO - 2016-05-23 08:56:21 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_login.php
INFO - 2016-05-23 08:56:21 --> Final output sent to browser
DEBUG - 2016-05-23 08:56:21 --> Total execution time: 0.0488
INFO - 2016-05-23 08:56:26 --> Config Class Initialized
INFO - 2016-05-23 08:56:26 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:56:26 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:56:26 --> Utf8 Class Initialized
INFO - 2016-05-23 08:56:26 --> URI Class Initialized
INFO - 2016-05-23 08:56:26 --> Router Class Initialized
INFO - 2016-05-23 08:56:26 --> Output Class Initialized
INFO - 2016-05-23 08:56:26 --> Security Class Initialized
DEBUG - 2016-05-23 08:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:56:26 --> Input Class Initialized
INFO - 2016-05-23 08:56:26 --> Language Class Initialized
INFO - 2016-05-23 08:56:26 --> Loader Class Initialized
INFO - 2016-05-23 08:56:26 --> Helper loaded: url_helper
INFO - 2016-05-23 08:56:26 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:56:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:56:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:56:26 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:56:26 --> Helper loaded: form_helper
INFO - 2016-05-23 08:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:56:26 --> Form Validation Class Initialized
INFO - 2016-05-23 08:56:26 --> Controller Class Initialized
INFO - 2016-05-23 08:56:26 --> Model Class Initialized
INFO - 2016-05-23 08:56:26 --> Database Driver Class Initialized
INFO - 2016-05-23 08:56:27 --> Config Class Initialized
INFO - 2016-05-23 08:56:27 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:56:27 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:56:27 --> Utf8 Class Initialized
INFO - 2016-05-23 08:56:27 --> URI Class Initialized
DEBUG - 2016-05-23 08:56:27 --> No URI present. Default controller set.
INFO - 2016-05-23 08:56:27 --> Router Class Initialized
INFO - 2016-05-23 08:56:27 --> Output Class Initialized
INFO - 2016-05-23 08:56:27 --> Security Class Initialized
DEBUG - 2016-05-23 08:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:56:27 --> Input Class Initialized
INFO - 2016-05-23 08:56:27 --> Language Class Initialized
INFO - 2016-05-23 08:56:27 --> Loader Class Initialized
INFO - 2016-05-23 08:56:27 --> Helper loaded: url_helper
INFO - 2016-05-23 08:56:27 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:56:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:56:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:56:27 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:56:27 --> Helper loaded: form_helper
INFO - 2016-05-23 08:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:56:27 --> Form Validation Class Initialized
INFO - 2016-05-23 08:56:27 --> Controller Class Initialized
INFO - 2016-05-23 08:56:27 --> Model Class Initialized
INFO - 2016-05-23 08:56:27 --> Database Driver Class Initialized
INFO - 2016-05-23 08:56:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 08:56:27 --> Pagination Class Initialized
DEBUG - 2016-05-23 08:56:27 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 08:56:27 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_index.php
INFO - 2016-05-23 08:56:27 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_template2.php
INFO - 2016-05-23 08:56:27 --> Final output sent to browser
DEBUG - 2016-05-23 08:56:27 --> Total execution time: 0.0672
INFO - 2016-05-23 08:56:34 --> Config Class Initialized
INFO - 2016-05-23 08:56:34 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:56:34 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:56:34 --> Utf8 Class Initialized
INFO - 2016-05-23 08:56:34 --> URI Class Initialized
INFO - 2016-05-23 08:56:34 --> Router Class Initialized
INFO - 2016-05-23 08:56:34 --> Output Class Initialized
INFO - 2016-05-23 08:56:34 --> Security Class Initialized
DEBUG - 2016-05-23 08:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:56:34 --> Input Class Initialized
INFO - 2016-05-23 08:56:34 --> Language Class Initialized
INFO - 2016-05-23 08:56:34 --> Loader Class Initialized
INFO - 2016-05-23 08:56:34 --> Helper loaded: url_helper
INFO - 2016-05-23 08:56:34 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:56:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:56:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:56:34 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:56:34 --> Helper loaded: form_helper
INFO - 2016-05-23 08:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:56:34 --> Form Validation Class Initialized
INFO - 2016-05-23 08:56:34 --> Controller Class Initialized
INFO - 2016-05-23 08:56:34 --> Model Class Initialized
INFO - 2016-05-23 08:56:34 --> Database Driver Class Initialized
INFO - 2016-05-23 08:56:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 08:56:34 --> Pagination Class Initialized
DEBUG - 2016-05-23 08:56:34 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 08:56:35 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_categoria.php
INFO - 2016-05-23 08:56:35 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_template2.php
INFO - 2016-05-23 08:56:35 --> Final output sent to browser
DEBUG - 2016-05-23 08:56:35 --> Total execution time: 0.2004
INFO - 2016-05-23 08:56:43 --> Config Class Initialized
INFO - 2016-05-23 08:56:43 --> Hooks Class Initialized
DEBUG - 2016-05-23 08:56:43 --> UTF-8 Support Enabled
INFO - 2016-05-23 08:56:43 --> Utf8 Class Initialized
INFO - 2016-05-23 08:56:43 --> URI Class Initialized
INFO - 2016-05-23 08:56:43 --> Router Class Initialized
INFO - 2016-05-23 08:56:43 --> Output Class Initialized
INFO - 2016-05-23 08:56:43 --> Security Class Initialized
DEBUG - 2016-05-23 08:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 08:56:43 --> Input Class Initialized
INFO - 2016-05-23 08:56:43 --> Language Class Initialized
INFO - 2016-05-23 08:56:43 --> Loader Class Initialized
INFO - 2016-05-23 08:56:43 --> Helper loaded: url_helper
INFO - 2016-05-23 08:56:43 --> Helper loaded: sesion_helper
INFO - 2016-05-23 08:56:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 08:56:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 08:56:43 --> Helper loaded: redondear_helper
INFO - 2016-05-23 08:56:43 --> Helper loaded: form_helper
INFO - 2016-05-23 08:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 08:56:43 --> Form Validation Class Initialized
INFO - 2016-05-23 08:56:43 --> Controller Class Initialized
INFO - 2016-05-23 08:56:43 --> Model Class Initialized
INFO - 2016-05-23 08:56:43 --> Database Driver Class Initialized
INFO - 2016-05-23 08:56:43 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_producto.php
INFO - 2016-05-23 08:56:43 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_template2.php
INFO - 2016-05-23 08:56:43 --> Final output sent to browser
DEBUG - 2016-05-23 08:56:43 --> Total execution time: 0.0837
INFO - 2016-05-23 10:39:30 --> Config Class Initialized
INFO - 2016-05-23 10:39:30 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:39:30 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:39:30 --> Utf8 Class Initialized
INFO - 2016-05-23 10:39:30 --> URI Class Initialized
DEBUG - 2016-05-23 10:39:30 --> No URI present. Default controller set.
INFO - 2016-05-23 10:39:30 --> Router Class Initialized
INFO - 2016-05-23 10:39:30 --> Output Class Initialized
INFO - 2016-05-23 10:39:30 --> Security Class Initialized
DEBUG - 2016-05-23 10:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:39:30 --> Input Class Initialized
INFO - 2016-05-23 10:39:30 --> Language Class Initialized
INFO - 2016-05-23 10:39:30 --> Loader Class Initialized
INFO - 2016-05-23 10:39:30 --> Helper loaded: url_helper
INFO - 2016-05-23 10:39:30 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:39:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:39:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:39:30 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:39:30 --> Helper loaded: form_helper
INFO - 2016-05-23 10:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:39:30 --> Form Validation Class Initialized
INFO - 2016-05-23 10:39:30 --> Controller Class Initialized
INFO - 2016-05-23 10:39:30 --> Model Class Initialized
INFO - 2016-05-23 10:39:31 --> Database Driver Class Initialized
INFO - 2016-05-23 10:39:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:39:31 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:39:31 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:39:31 --> Config Class Initialized
INFO - 2016-05-23 10:39:31 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:39:31 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:39:31 --> Utf8 Class Initialized
INFO - 2016-05-23 10:39:31 --> URI Class Initialized
INFO - 2016-05-23 10:39:31 --> Router Class Initialized
INFO - 2016-05-23 10:39:31 --> Output Class Initialized
INFO - 2016-05-23 10:39:31 --> Security Class Initialized
DEBUG - 2016-05-23 10:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:39:31 --> Input Class Initialized
INFO - 2016-05-23 10:39:31 --> Language Class Initialized
INFO - 2016-05-23 10:39:31 --> Loader Class Initialized
INFO - 2016-05-23 10:39:31 --> Helper loaded: url_helper
INFO - 2016-05-23 10:39:31 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:39:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:39:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:39:31 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:39:31 --> Helper loaded: form_helper
INFO - 2016-05-23 10:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:39:31 --> Form Validation Class Initialized
INFO - 2016-05-23 10:39:31 --> Controller Class Initialized
INFO - 2016-05-23 10:39:31 --> Model Class Initialized
INFO - 2016-05-23 10:39:31 --> Database Driver Class Initialized
INFO - 2016-05-23 10:39:31 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_login.php
INFO - 2016-05-23 10:39:31 --> Final output sent to browser
DEBUG - 2016-05-23 10:39:31 --> Total execution time: 0.0465
INFO - 2016-05-23 10:39:37 --> Config Class Initialized
INFO - 2016-05-23 10:39:37 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:39:37 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:39:37 --> Utf8 Class Initialized
INFO - 2016-05-23 10:39:37 --> URI Class Initialized
INFO - 2016-05-23 10:39:37 --> Router Class Initialized
INFO - 2016-05-23 10:39:37 --> Output Class Initialized
INFO - 2016-05-23 10:39:37 --> Security Class Initialized
DEBUG - 2016-05-23 10:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:39:37 --> Input Class Initialized
INFO - 2016-05-23 10:39:37 --> Language Class Initialized
INFO - 2016-05-23 10:39:37 --> Loader Class Initialized
INFO - 2016-05-23 10:39:37 --> Helper loaded: url_helper
INFO - 2016-05-23 10:39:37 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:39:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:39:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:39:37 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:39:37 --> Helper loaded: form_helper
INFO - 2016-05-23 10:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:39:37 --> Form Validation Class Initialized
INFO - 2016-05-23 10:39:37 --> Controller Class Initialized
INFO - 2016-05-23 10:39:37 --> Config Class Initialized
INFO - 2016-05-23 10:39:37 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:39:37 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:39:37 --> Utf8 Class Initialized
INFO - 2016-05-23 10:39:37 --> URI Class Initialized
INFO - 2016-05-23 10:39:37 --> Router Class Initialized
INFO - 2016-05-23 10:39:37 --> Output Class Initialized
INFO - 2016-05-23 10:39:37 --> Security Class Initialized
DEBUG - 2016-05-23 10:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:39:37 --> Input Class Initialized
INFO - 2016-05-23 10:39:37 --> Language Class Initialized
INFO - 2016-05-23 10:39:37 --> Loader Class Initialized
INFO - 2016-05-23 10:39:37 --> Helper loaded: url_helper
INFO - 2016-05-23 10:39:37 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:39:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:39:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:39:37 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:39:37 --> Helper loaded: form_helper
INFO - 2016-05-23 10:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:39:37 --> Form Validation Class Initialized
INFO - 2016-05-23 10:39:37 --> Controller Class Initialized
INFO - 2016-05-23 10:39:37 --> Model Class Initialized
INFO - 2016-05-23 10:39:37 --> Database Driver Class Initialized
INFO - 2016-05-23 10:39:37 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_login.php
INFO - 2016-05-23 10:39:37 --> Final output sent to browser
DEBUG - 2016-05-23 10:39:37 --> Total execution time: 0.0450
INFO - 2016-05-23 10:39:49 --> Config Class Initialized
INFO - 2016-05-23 10:39:49 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:39:49 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:39:49 --> Utf8 Class Initialized
INFO - 2016-05-23 10:39:49 --> URI Class Initialized
INFO - 2016-05-23 10:39:49 --> Router Class Initialized
INFO - 2016-05-23 10:39:49 --> Output Class Initialized
INFO - 2016-05-23 10:39:49 --> Security Class Initialized
DEBUG - 2016-05-23 10:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:39:49 --> Input Class Initialized
INFO - 2016-05-23 10:39:49 --> Language Class Initialized
INFO - 2016-05-23 10:39:49 --> Loader Class Initialized
INFO - 2016-05-23 10:39:49 --> Helper loaded: url_helper
INFO - 2016-05-23 10:39:49 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:39:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:39:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:39:49 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:39:49 --> Helper loaded: form_helper
INFO - 2016-05-23 10:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:39:49 --> Form Validation Class Initialized
INFO - 2016-05-23 10:39:49 --> Controller Class Initialized
INFO - 2016-05-23 10:39:49 --> Model Class Initialized
INFO - 2016-05-23 10:39:49 --> Database Driver Class Initialized
INFO - 2016-05-23 10:39:49 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_login.php
INFO - 2016-05-23 10:39:49 --> Final output sent to browser
DEBUG - 2016-05-23 10:39:49 --> Total execution time: 0.0518
INFO - 2016-05-23 10:39:50 --> Config Class Initialized
INFO - 2016-05-23 10:39:50 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:39:50 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:39:50 --> Utf8 Class Initialized
INFO - 2016-05-23 10:39:50 --> URI Class Initialized
INFO - 2016-05-23 10:39:50 --> Router Class Initialized
INFO - 2016-05-23 10:39:50 --> Output Class Initialized
INFO - 2016-05-23 10:39:50 --> Security Class Initialized
DEBUG - 2016-05-23 10:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:39:50 --> Input Class Initialized
INFO - 2016-05-23 10:39:50 --> Language Class Initialized
INFO - 2016-05-23 10:39:50 --> Loader Class Initialized
INFO - 2016-05-23 10:39:50 --> Helper loaded: url_helper
INFO - 2016-05-23 10:39:50 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:39:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:39:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:39:50 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:39:50 --> Helper loaded: form_helper
INFO - 2016-05-23 10:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:39:50 --> Form Validation Class Initialized
INFO - 2016-05-23 10:39:50 --> Controller Class Initialized
INFO - 2016-05-23 10:39:50 --> Model Class Initialized
INFO - 2016-05-23 10:39:50 --> Database Driver Class Initialized
INFO - 2016-05-23 10:39:50 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_login.php
INFO - 2016-05-23 10:39:50 --> Final output sent to browser
DEBUG - 2016-05-23 10:39:50 --> Total execution time: 0.0479
INFO - 2016-05-23 10:40:06 --> Config Class Initialized
INFO - 2016-05-23 10:40:06 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:06 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:06 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:06 --> URI Class Initialized
INFO - 2016-05-23 10:40:06 --> Router Class Initialized
INFO - 2016-05-23 10:40:06 --> Output Class Initialized
INFO - 2016-05-23 10:40:06 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:06 --> Input Class Initialized
INFO - 2016-05-23 10:40:06 --> Language Class Initialized
INFO - 2016-05-23 10:40:06 --> Loader Class Initialized
INFO - 2016-05-23 10:40:06 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:06 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:06 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:06 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:06 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:06 --> Controller Class Initialized
INFO - 2016-05-23 10:40:06 --> Model Class Initialized
INFO - 2016-05-23 10:40:06 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:06 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_login.php
INFO - 2016-05-23 10:40:06 --> Final output sent to browser
DEBUG - 2016-05-23 10:40:06 --> Total execution time: 0.0463
INFO - 2016-05-23 10:40:07 --> Config Class Initialized
INFO - 2016-05-23 10:40:07 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:07 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:07 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:07 --> URI Class Initialized
INFO - 2016-05-23 10:40:07 --> Router Class Initialized
INFO - 2016-05-23 10:40:07 --> Output Class Initialized
INFO - 2016-05-23 10:40:07 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:07 --> Input Class Initialized
INFO - 2016-05-23 10:40:07 --> Language Class Initialized
INFO - 2016-05-23 10:40:07 --> Loader Class Initialized
INFO - 2016-05-23 10:40:07 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:07 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:07 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:07 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:07 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:07 --> Controller Class Initialized
INFO - 2016-05-23 10:40:07 --> Model Class Initialized
INFO - 2016-05-23 10:40:07 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:07 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_login.php
INFO - 2016-05-23 10:40:07 --> Final output sent to browser
DEBUG - 2016-05-23 10:40:07 --> Total execution time: 0.0457
INFO - 2016-05-23 10:40:09 --> Config Class Initialized
INFO - 2016-05-23 10:40:09 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:09 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:09 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:09 --> URI Class Initialized
INFO - 2016-05-23 10:40:09 --> Router Class Initialized
INFO - 2016-05-23 10:40:09 --> Output Class Initialized
INFO - 2016-05-23 10:40:09 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:09 --> Input Class Initialized
INFO - 2016-05-23 10:40:09 --> Language Class Initialized
INFO - 2016-05-23 10:40:09 --> Loader Class Initialized
INFO - 2016-05-23 10:40:09 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:09 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:09 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:09 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:09 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:09 --> Controller Class Initialized
INFO - 2016-05-23 10:40:09 --> Model Class Initialized
INFO - 2016-05-23 10:40:09 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:09 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_login.php
INFO - 2016-05-23 10:40:09 --> Final output sent to browser
DEBUG - 2016-05-23 10:40:09 --> Total execution time: 0.0461
INFO - 2016-05-23 10:40:14 --> Config Class Initialized
INFO - 2016-05-23 10:40:14 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:14 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:14 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:14 --> URI Class Initialized
INFO - 2016-05-23 10:40:14 --> Router Class Initialized
INFO - 2016-05-23 10:40:14 --> Output Class Initialized
INFO - 2016-05-23 10:40:14 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:14 --> Input Class Initialized
INFO - 2016-05-23 10:40:14 --> Language Class Initialized
INFO - 2016-05-23 10:40:14 --> Loader Class Initialized
INFO - 2016-05-23 10:40:14 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:14 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:14 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:14 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:14 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:14 --> Controller Class Initialized
INFO - 2016-05-23 10:40:14 --> Model Class Initialized
INFO - 2016-05-23 10:40:14 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:14 --> Config Class Initialized
INFO - 2016-05-23 10:40:14 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:14 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:14 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:14 --> URI Class Initialized
DEBUG - 2016-05-23 10:40:14 --> No URI present. Default controller set.
INFO - 2016-05-23 10:40:14 --> Router Class Initialized
INFO - 2016-05-23 10:40:14 --> Output Class Initialized
INFO - 2016-05-23 10:40:14 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:14 --> Input Class Initialized
INFO - 2016-05-23 10:40:14 --> Language Class Initialized
INFO - 2016-05-23 10:40:14 --> Loader Class Initialized
INFO - 2016-05-23 10:40:14 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:14 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:14 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:14 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:14 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:14 --> Controller Class Initialized
INFO - 2016-05-23 10:40:14 --> Model Class Initialized
INFO - 2016-05-23 10:40:14 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:40:14 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:40:14 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:40:14 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_index.php
INFO - 2016-05-23 10:40:14 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_template2.php
INFO - 2016-05-23 10:40:14 --> Final output sent to browser
DEBUG - 2016-05-23 10:40:14 --> Total execution time: 0.0450
INFO - 2016-05-23 10:40:23 --> Config Class Initialized
INFO - 2016-05-23 10:40:23 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:23 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:23 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:23 --> URI Class Initialized
INFO - 2016-05-23 10:40:23 --> Router Class Initialized
INFO - 2016-05-23 10:40:23 --> Output Class Initialized
INFO - 2016-05-23 10:40:23 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:23 --> Input Class Initialized
INFO - 2016-05-23 10:40:23 --> Language Class Initialized
INFO - 2016-05-23 10:40:23 --> Loader Class Initialized
INFO - 2016-05-23 10:40:23 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:23 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:23 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:23 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:23 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:23 --> Controller Class Initialized
INFO - 2016-05-23 10:40:23 --> Model Class Initialized
INFO - 2016-05-23 10:40:23 --> Database Driver Class Initialized
ERROR - 2016-05-23 10:40:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/controllers/Carrito.php 43
ERROR - 2016-05-23 10:40:23 --> Severity: Notice --> Undefined variable: cantidad /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/controllers/Carrito.php 51
INFO - 2016-05-23 10:40:23 --> Config Class Initialized
INFO - 2016-05-23 10:40:23 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:23 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:23 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:23 --> URI Class Initialized
INFO - 2016-05-23 10:40:23 --> Router Class Initialized
INFO - 2016-05-23 10:40:23 --> Output Class Initialized
INFO - 2016-05-23 10:40:23 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:23 --> Input Class Initialized
INFO - 2016-05-23 10:40:23 --> Language Class Initialized
INFO - 2016-05-23 10:40:23 --> Loader Class Initialized
INFO - 2016-05-23 10:40:23 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:23 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:23 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:23 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:23 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:23 --> Controller Class Initialized
INFO - 2016-05-23 10:40:23 --> Model Class Initialized
INFO - 2016-05-23 10:40:23 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:23 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_carrito.php
INFO - 2016-05-23 10:40:23 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_template2.php
INFO - 2016-05-23 10:40:23 --> Final output sent to browser
DEBUG - 2016-05-23 10:40:23 --> Total execution time: 0.0510
INFO - 2016-05-23 10:40:25 --> Config Class Initialized
INFO - 2016-05-23 10:40:25 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:25 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:25 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:25 --> URI Class Initialized
INFO - 2016-05-23 10:40:25 --> Router Class Initialized
INFO - 2016-05-23 10:40:25 --> Output Class Initialized
INFO - 2016-05-23 10:40:25 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:25 --> Input Class Initialized
INFO - 2016-05-23 10:40:25 --> Language Class Initialized
INFO - 2016-05-23 10:40:25 --> Loader Class Initialized
INFO - 2016-05-23 10:40:25 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:25 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:25 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:25 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:25 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:25 --> Controller Class Initialized
INFO - 2016-05-23 10:40:25 --> Model Class Initialized
INFO - 2016-05-23 10:40:25 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:26 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_venta1.php
INFO - 2016-05-23 10:40:26 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_template2.php
INFO - 2016-05-23 10:40:26 --> Final output sent to browser
DEBUG - 2016-05-23 10:40:26 --> Total execution time: 0.1557
INFO - 2016-05-23 10:40:30 --> Config Class Initialized
INFO - 2016-05-23 10:40:30 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:30 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:30 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:30 --> URI Class Initialized
INFO - 2016-05-23 10:40:30 --> Router Class Initialized
INFO - 2016-05-23 10:40:30 --> Output Class Initialized
INFO - 2016-05-23 10:40:30 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:30 --> Input Class Initialized
INFO - 2016-05-23 10:40:30 --> Language Class Initialized
INFO - 2016-05-23 10:40:30 --> Loader Class Initialized
INFO - 2016-05-23 10:40:30 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:30 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:30 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:30 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:30 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:30 --> Controller Class Initialized
INFO - 2016-05-23 10:40:30 --> Model Class Initialized
INFO - 2016-05-23 10:40:30 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:30 --> Config Class Initialized
INFO - 2016-05-23 10:40:30 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:30 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:30 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:30 --> URI Class Initialized
INFO - 2016-05-23 10:40:30 --> Router Class Initialized
INFO - 2016-05-23 10:40:30 --> Output Class Initialized
INFO - 2016-05-23 10:40:30 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:30 --> Input Class Initialized
INFO - 2016-05-23 10:40:30 --> Language Class Initialized
INFO - 2016-05-23 10:40:30 --> Loader Class Initialized
INFO - 2016-05-23 10:40:30 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:30 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:30 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:30 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:30 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:30 --> Controller Class Initialized
INFO - 2016-05-23 10:40:30 --> Model Class Initialized
INFO - 2016-05-23 10:40:30 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:30 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_resumenventa.php
INFO - 2016-05-23 10:40:30 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_template2.php
INFO - 2016-05-23 10:40:30 --> Final output sent to browser
DEBUG - 2016-05-23 10:40:30 --> Total execution time: 0.0928
INFO - 2016-05-23 10:40:32 --> Config Class Initialized
INFO - 2016-05-23 10:40:32 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:32 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:32 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:32 --> URI Class Initialized
INFO - 2016-05-23 10:40:32 --> Router Class Initialized
INFO - 2016-05-23 10:40:32 --> Output Class Initialized
INFO - 2016-05-23 10:40:32 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:32 --> Input Class Initialized
INFO - 2016-05-23 10:40:32 --> Language Class Initialized
INFO - 2016-05-23 10:40:32 --> Loader Class Initialized
INFO - 2016-05-23 10:40:32 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:32 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:32 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:32 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:32 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:32 --> Controller Class Initialized
INFO - 2016-05-23 10:40:32 --> Model Class Initialized
INFO - 2016-05-23 10:40:32 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:32 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_venta1.php
INFO - 2016-05-23 10:40:32 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_template2.php
INFO - 2016-05-23 10:40:32 --> Final output sent to browser
DEBUG - 2016-05-23 10:40:32 --> Total execution time: 0.0519
INFO - 2016-05-23 10:40:36 --> Config Class Initialized
INFO - 2016-05-23 10:40:36 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:36 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:36 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:36 --> URI Class Initialized
INFO - 2016-05-23 10:40:36 --> Router Class Initialized
INFO - 2016-05-23 10:40:36 --> Output Class Initialized
INFO - 2016-05-23 10:40:36 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:36 --> Input Class Initialized
INFO - 2016-05-23 10:40:36 --> Language Class Initialized
INFO - 2016-05-23 10:40:36 --> Loader Class Initialized
INFO - 2016-05-23 10:40:36 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:36 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:36 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:36 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:36 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:36 --> Controller Class Initialized
INFO - 2016-05-23 10:40:36 --> Model Class Initialized
INFO - 2016-05-23 10:40:36 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:36 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_venta2.php
INFO - 2016-05-23 10:40:36 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_template2.php
INFO - 2016-05-23 10:40:36 --> Final output sent to browser
DEBUG - 2016-05-23 10:40:36 --> Total execution time: 0.0522
INFO - 2016-05-23 10:40:42 --> Config Class Initialized
INFO - 2016-05-23 10:40:42 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:42 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:42 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:42 --> URI Class Initialized
INFO - 2016-05-23 10:40:42 --> Router Class Initialized
INFO - 2016-05-23 10:40:42 --> Output Class Initialized
INFO - 2016-05-23 10:40:42 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:42 --> Input Class Initialized
INFO - 2016-05-23 10:40:42 --> Language Class Initialized
INFO - 2016-05-23 10:40:42 --> Loader Class Initialized
INFO - 2016-05-23 10:40:42 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:42 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:42 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:42 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:42 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:42 --> Controller Class Initialized
INFO - 2016-05-23 10:40:42 --> Model Class Initialized
INFO - 2016-05-23 10:40:42 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:42 --> Config Class Initialized
INFO - 2016-05-23 10:40:42 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:42 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:42 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:42 --> URI Class Initialized
INFO - 2016-05-23 10:40:42 --> Router Class Initialized
INFO - 2016-05-23 10:40:42 --> Output Class Initialized
INFO - 2016-05-23 10:40:42 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:42 --> Input Class Initialized
INFO - 2016-05-23 10:40:42 --> Language Class Initialized
INFO - 2016-05-23 10:40:42 --> Loader Class Initialized
INFO - 2016-05-23 10:40:42 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:42 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:42 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:42 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:42 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:42 --> Controller Class Initialized
INFO - 2016-05-23 10:40:42 --> Model Class Initialized
INFO - 2016-05-23 10:40:42 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:42 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_resumenventa.php
INFO - 2016-05-23 10:40:42 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_template2.php
INFO - 2016-05-23 10:40:42 --> Final output sent to browser
DEBUG - 2016-05-23 10:40:42 --> Total execution time: 0.0533
INFO - 2016-05-23 10:40:44 --> Config Class Initialized
INFO - 2016-05-23 10:40:44 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:44 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:44 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:44 --> URI Class Initialized
INFO - 2016-05-23 10:40:44 --> Router Class Initialized
INFO - 2016-05-23 10:40:44 --> Output Class Initialized
INFO - 2016-05-23 10:40:44 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:44 --> Input Class Initialized
INFO - 2016-05-23 10:40:44 --> Language Class Initialized
INFO - 2016-05-23 10:40:44 --> Loader Class Initialized
INFO - 2016-05-23 10:40:44 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:44 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:44 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:44 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:44 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:44 --> Controller Class Initialized
INFO - 2016-05-23 10:40:44 --> Model Class Initialized
INFO - 2016-05-23 10:40:44 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:45 --> Config Class Initialized
INFO - 2016-05-23 10:40:45 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:45 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:45 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:45 --> URI Class Initialized
INFO - 2016-05-23 10:40:45 --> Router Class Initialized
INFO - 2016-05-23 10:40:45 --> Output Class Initialized
INFO - 2016-05-23 10:40:45 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:45 --> Input Class Initialized
INFO - 2016-05-23 10:40:45 --> Language Class Initialized
INFO - 2016-05-23 10:40:45 --> Loader Class Initialized
INFO - 2016-05-23 10:40:45 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:45 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:45 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:45 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:45 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:45 --> Controller Class Initialized
INFO - 2016-05-23 10:40:45 --> Model Class Initialized
INFO - 2016-05-23 10:40:45 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:45 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_ventafinalizada.php
INFO - 2016-05-23 10:40:45 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_template2.php
INFO - 2016-05-23 10:40:45 --> Final output sent to browser
DEBUG - 2016-05-23 10:40:45 --> Total execution time: 0.1193
INFO - 2016-05-23 10:40:47 --> Config Class Initialized
INFO - 2016-05-23 10:40:47 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:47 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:47 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:47 --> URI Class Initialized
INFO - 2016-05-23 10:40:47 --> Router Class Initialized
INFO - 2016-05-23 10:40:47 --> Output Class Initialized
INFO - 2016-05-23 10:40:47 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:47 --> Input Class Initialized
INFO - 2016-05-23 10:40:47 --> Language Class Initialized
INFO - 2016-05-23 10:40:47 --> Loader Class Initialized
INFO - 2016-05-23 10:40:47 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:47 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:47 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:47 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:47 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:47 --> Controller Class Initialized
INFO - 2016-05-23 10:40:47 --> Model Class Initialized
INFO - 2016-05-23 10:40:47 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:47 --> Final output sent to browser
DEBUG - 2016-05-23 10:40:47 --> Total execution time: 0.1936
INFO - 2016-05-23 10:40:50 --> Config Class Initialized
INFO - 2016-05-23 10:40:50 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:50 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:50 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:50 --> URI Class Initialized
INFO - 2016-05-23 10:40:50 --> Router Class Initialized
INFO - 2016-05-23 10:40:50 --> Output Class Initialized
INFO - 2016-05-23 10:40:50 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:50 --> Input Class Initialized
INFO - 2016-05-23 10:40:50 --> Language Class Initialized
INFO - 2016-05-23 10:40:50 --> Loader Class Initialized
INFO - 2016-05-23 10:40:50 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:50 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:50 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:50 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:50 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:50 --> Controller Class Initialized
INFO - 2016-05-23 10:40:50 --> Model Class Initialized
INFO - 2016-05-23 10:40:50 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:50 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_ventafinalizada.php
INFO - 2016-05-23 10:40:50 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_template2.php
INFO - 2016-05-23 10:40:50 --> Final output sent to browser
DEBUG - 2016-05-23 10:40:50 --> Total execution time: 0.0818
INFO - 2016-05-23 10:40:52 --> Config Class Initialized
INFO - 2016-05-23 10:40:52 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:52 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:52 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:52 --> URI Class Initialized
INFO - 2016-05-23 10:40:52 --> Router Class Initialized
INFO - 2016-05-23 10:40:52 --> Output Class Initialized
INFO - 2016-05-23 10:40:52 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:52 --> Input Class Initialized
INFO - 2016-05-23 10:40:52 --> Language Class Initialized
INFO - 2016-05-23 10:40:52 --> Loader Class Initialized
INFO - 2016-05-23 10:40:52 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:52 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:52 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:52 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:52 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:52 --> Controller Class Initialized
INFO - 2016-05-23 10:40:52 --> Model Class Initialized
INFO - 2016-05-23 10:40:52 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:52 --> Final output sent to browser
DEBUG - 2016-05-23 10:40:52 --> Total execution time: 0.1272
INFO - 2016-05-23 10:40:58 --> Config Class Initialized
INFO - 2016-05-23 10:40:58 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:40:58 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:40:58 --> Utf8 Class Initialized
INFO - 2016-05-23 10:40:58 --> URI Class Initialized
INFO - 2016-05-23 10:40:58 --> Router Class Initialized
INFO - 2016-05-23 10:40:58 --> Output Class Initialized
INFO - 2016-05-23 10:40:58 --> Security Class Initialized
DEBUG - 2016-05-23 10:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:40:58 --> Input Class Initialized
INFO - 2016-05-23 10:40:58 --> Language Class Initialized
INFO - 2016-05-23 10:40:58 --> Loader Class Initialized
INFO - 2016-05-23 10:40:58 --> Helper loaded: url_helper
INFO - 2016-05-23 10:40:58 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:40:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:40:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:40:58 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:40:58 --> Helper loaded: form_helper
INFO - 2016-05-23 10:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:40:58 --> Form Validation Class Initialized
INFO - 2016-05-23 10:40:58 --> Controller Class Initialized
INFO - 2016-05-23 10:40:58 --> Model Class Initialized
INFO - 2016-05-23 10:40:58 --> Database Driver Class Initialized
INFO - 2016-05-23 10:40:58 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_ventafinalizada.php
INFO - 2016-05-23 10:40:58 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_template2.php
INFO - 2016-05-23 10:40:58 --> Final output sent to browser
DEBUG - 2016-05-23 10:40:58 --> Total execution time: 0.0603
INFO - 2016-05-23 10:41:25 --> Config Class Initialized
INFO - 2016-05-23 10:41:25 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:41:25 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:41:25 --> Utf8 Class Initialized
INFO - 2016-05-23 10:41:25 --> URI Class Initialized
INFO - 2016-05-23 10:41:25 --> Router Class Initialized
INFO - 2016-05-23 10:41:25 --> Output Class Initialized
INFO - 2016-05-23 10:41:25 --> Security Class Initialized
DEBUG - 2016-05-23 10:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:41:25 --> Input Class Initialized
INFO - 2016-05-23 10:41:25 --> Language Class Initialized
INFO - 2016-05-23 10:41:25 --> Loader Class Initialized
INFO - 2016-05-23 10:41:25 --> Helper loaded: url_helper
INFO - 2016-05-23 10:41:25 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:41:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:41:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:41:25 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:41:25 --> Helper loaded: form_helper
INFO - 2016-05-23 10:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:41:25 --> Form Validation Class Initialized
INFO - 2016-05-23 10:41:25 --> Controller Class Initialized
INFO - 2016-05-23 10:41:25 --> Config Class Initialized
INFO - 2016-05-23 10:41:25 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:41:25 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:41:25 --> Utf8 Class Initialized
INFO - 2016-05-23 10:41:25 --> URI Class Initialized
INFO - 2016-05-23 10:41:25 --> Router Class Initialized
INFO - 2016-05-23 10:41:25 --> Output Class Initialized
INFO - 2016-05-23 10:41:25 --> Security Class Initialized
DEBUG - 2016-05-23 10:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:41:25 --> Input Class Initialized
INFO - 2016-05-23 10:41:25 --> Language Class Initialized
INFO - 2016-05-23 10:41:25 --> Loader Class Initialized
INFO - 2016-05-23 10:41:25 --> Helper loaded: url_helper
INFO - 2016-05-23 10:41:25 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:41:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:41:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:41:25 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:41:25 --> Helper loaded: form_helper
INFO - 2016-05-23 10:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:41:25 --> Form Validation Class Initialized
INFO - 2016-05-23 10:41:25 --> Controller Class Initialized
INFO - 2016-05-23 10:41:25 --> Model Class Initialized
INFO - 2016-05-23 10:41:25 --> Database Driver Class Initialized
INFO - 2016-05-23 10:41:25 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_login.php
INFO - 2016-05-23 10:41:25 --> Final output sent to browser
DEBUG - 2016-05-23 10:41:25 --> Total execution time: 0.0449
INFO - 2016-05-23 10:41:33 --> Config Class Initialized
INFO - 2016-05-23 10:41:33 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:41:33 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:41:33 --> Utf8 Class Initialized
INFO - 2016-05-23 10:41:33 --> URI Class Initialized
INFO - 2016-05-23 10:41:33 --> Router Class Initialized
INFO - 2016-05-23 10:41:33 --> Output Class Initialized
INFO - 2016-05-23 10:41:33 --> Security Class Initialized
DEBUG - 2016-05-23 10:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:41:33 --> Input Class Initialized
INFO - 2016-05-23 10:41:33 --> Language Class Initialized
INFO - 2016-05-23 10:41:33 --> Loader Class Initialized
INFO - 2016-05-23 10:41:33 --> Helper loaded: url_helper
INFO - 2016-05-23 10:41:33 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:41:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:41:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:41:33 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:41:33 --> Helper loaded: form_helper
INFO - 2016-05-23 10:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:41:33 --> Form Validation Class Initialized
INFO - 2016-05-23 10:41:33 --> Controller Class Initialized
INFO - 2016-05-23 10:41:33 --> Model Class Initialized
INFO - 2016-05-23 10:41:33 --> Database Driver Class Initialized
INFO - 2016-05-23 10:41:34 --> Config Class Initialized
INFO - 2016-05-23 10:41:34 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:41:34 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:41:34 --> Utf8 Class Initialized
INFO - 2016-05-23 10:41:34 --> URI Class Initialized
INFO - 2016-05-23 10:41:34 --> Router Class Initialized
INFO - 2016-05-23 10:41:34 --> Output Class Initialized
INFO - 2016-05-23 10:41:34 --> Security Class Initialized
DEBUG - 2016-05-23 10:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:41:34 --> Input Class Initialized
INFO - 2016-05-23 10:41:34 --> Language Class Initialized
INFO - 2016-05-23 10:41:34 --> Loader Class Initialized
INFO - 2016-05-23 10:41:34 --> Helper loaded: url_helper
INFO - 2016-05-23 10:41:34 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:41:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:41:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:41:34 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:41:34 --> Helper loaded: form_helper
INFO - 2016-05-23 10:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:41:34 --> Form Validation Class Initialized
INFO - 2016-05-23 10:41:34 --> Controller Class Initialized
INFO - 2016-05-23 10:41:34 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_index.php
INFO - 2016-05-23 10:41:34 --> Model Class Initialized
INFO - 2016-05-23 10:41:34 --> Database Driver Class Initialized
INFO - 2016-05-23 10:41:34 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_template1.php
INFO - 2016-05-23 10:41:34 --> Final output sent to browser
DEBUG - 2016-05-23 10:41:34 --> Total execution time: 0.0482
INFO - 2016-05-23 10:41:34 --> Config Class Initialized
INFO - 2016-05-23 10:41:34 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:41:34 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:41:34 --> Utf8 Class Initialized
INFO - 2016-05-23 10:41:34 --> URI Class Initialized
INFO - 2016-05-23 10:41:34 --> Router Class Initialized
INFO - 2016-05-23 10:41:34 --> Output Class Initialized
INFO - 2016-05-23 10:41:34 --> Security Class Initialized
DEBUG - 2016-05-23 10:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:41:34 --> Input Class Initialized
INFO - 2016-05-23 10:41:34 --> Language Class Initialized
INFO - 2016-05-23 10:41:34 --> Loader Class Initialized
INFO - 2016-05-23 10:41:34 --> Helper loaded: url_helper
INFO - 2016-05-23 10:41:34 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:41:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:41:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:41:34 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:41:34 --> Helper loaded: form_helper
INFO - 2016-05-23 10:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:41:34 --> Form Validation Class Initialized
INFO - 2016-05-23 10:41:34 --> Controller Class Initialized
INFO - 2016-05-23 10:41:34 --> Model Class Initialized
INFO - 2016-05-23 10:41:34 --> Database Driver Class Initialized
INFO - 2016-05-23 10:41:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:41:34 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:41:34 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:41:34 --> Final output sent to browser
DEBUG - 2016-05-23 10:41:34 --> Total execution time: 0.0493
INFO - 2016-05-23 10:41:43 --> Config Class Initialized
INFO - 2016-05-23 10:41:43 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:41:43 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:41:43 --> Utf8 Class Initialized
INFO - 2016-05-23 10:41:43 --> URI Class Initialized
INFO - 2016-05-23 10:41:43 --> Router Class Initialized
INFO - 2016-05-23 10:41:43 --> Output Class Initialized
INFO - 2016-05-23 10:41:43 --> Security Class Initialized
DEBUG - 2016-05-23 10:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:41:43 --> Input Class Initialized
INFO - 2016-05-23 10:41:43 --> Language Class Initialized
INFO - 2016-05-23 10:41:43 --> Loader Class Initialized
INFO - 2016-05-23 10:41:43 --> Helper loaded: url_helper
INFO - 2016-05-23 10:41:43 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:41:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:41:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:41:43 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:41:43 --> Helper loaded: form_helper
INFO - 2016-05-23 10:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:41:43 --> Form Validation Class Initialized
INFO - 2016-05-23 10:41:43 --> Controller Class Initialized
INFO - 2016-05-23 10:41:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-23 10:41:43 --> Helper loaded: nif_validate_helper
INFO - 2016-05-23 10:41:43 --> Model Class Initialized
INFO - 2016-05-23 10:41:43 --> Database Driver Class Initialized
INFO - 2016-05-23 10:41:43 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_addProveedor.php
INFO - 2016-05-23 10:41:43 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_template1.php
INFO - 2016-05-23 10:41:43 --> Final output sent to browser
DEBUG - 2016-05-23 10:41:43 --> Total execution time: 0.0714
INFO - 2016-05-23 10:41:43 --> Config Class Initialized
INFO - 2016-05-23 10:41:43 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:41:43 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:41:43 --> Utf8 Class Initialized
INFO - 2016-05-23 10:41:43 --> URI Class Initialized
INFO - 2016-05-23 10:41:43 --> Router Class Initialized
INFO - 2016-05-23 10:41:43 --> Output Class Initialized
INFO - 2016-05-23 10:41:43 --> Security Class Initialized
DEBUG - 2016-05-23 10:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:41:43 --> Input Class Initialized
INFO - 2016-05-23 10:41:43 --> Language Class Initialized
INFO - 2016-05-23 10:41:43 --> Loader Class Initialized
INFO - 2016-05-23 10:41:43 --> Helper loaded: url_helper
INFO - 2016-05-23 10:41:43 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:41:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:41:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:41:43 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:41:43 --> Helper loaded: form_helper
INFO - 2016-05-23 10:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:41:43 --> Form Validation Class Initialized
INFO - 2016-05-23 10:41:43 --> Controller Class Initialized
INFO - 2016-05-23 10:41:43 --> Model Class Initialized
INFO - 2016-05-23 10:41:43 --> Database Driver Class Initialized
INFO - 2016-05-23 10:41:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:41:43 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:41:43 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:41:43 --> Final output sent to browser
DEBUG - 2016-05-23 10:41:43 --> Total execution time: 0.0495
INFO - 2016-05-23 10:41:47 --> Config Class Initialized
INFO - 2016-05-23 10:41:47 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:41:47 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:41:47 --> Utf8 Class Initialized
INFO - 2016-05-23 10:41:47 --> URI Class Initialized
INFO - 2016-05-23 10:41:47 --> Router Class Initialized
INFO - 2016-05-23 10:41:47 --> Output Class Initialized
INFO - 2016-05-23 10:41:47 --> Security Class Initialized
DEBUG - 2016-05-23 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:41:47 --> Input Class Initialized
INFO - 2016-05-23 10:41:47 --> Language Class Initialized
INFO - 2016-05-23 10:41:47 --> Loader Class Initialized
INFO - 2016-05-23 10:41:47 --> Helper loaded: url_helper
INFO - 2016-05-23 10:41:47 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:41:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:41:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:41:47 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:41:47 --> Helper loaded: form_helper
INFO - 2016-05-23 10:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:41:47 --> Form Validation Class Initialized
INFO - 2016-05-23 10:41:47 --> Controller Class Initialized
INFO - 2016-05-23 10:41:47 --> Model Class Initialized
INFO - 2016-05-23 10:41:47 --> Database Driver Class Initialized
INFO - 2016-05-23 10:41:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:41:47 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:41:47 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:41:47 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_listaFacturas.php
INFO - 2016-05-23 10:41:47 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_template1.php
INFO - 2016-05-23 10:41:47 --> Final output sent to browser
DEBUG - 2016-05-23 10:41:47 --> Total execution time: 0.1155
INFO - 2016-05-23 10:41:48 --> Config Class Initialized
INFO - 2016-05-23 10:41:48 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:41:48 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:41:48 --> Utf8 Class Initialized
INFO - 2016-05-23 10:41:48 --> URI Class Initialized
INFO - 2016-05-23 10:41:48 --> Router Class Initialized
INFO - 2016-05-23 10:41:48 --> Output Class Initialized
INFO - 2016-05-23 10:41:48 --> Security Class Initialized
DEBUG - 2016-05-23 10:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:41:48 --> Input Class Initialized
INFO - 2016-05-23 10:41:48 --> Language Class Initialized
INFO - 2016-05-23 10:41:48 --> Loader Class Initialized
INFO - 2016-05-23 10:41:48 --> Helper loaded: url_helper
INFO - 2016-05-23 10:41:48 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:41:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:41:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:41:48 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:41:48 --> Helper loaded: form_helper
INFO - 2016-05-23 10:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:41:48 --> Form Validation Class Initialized
INFO - 2016-05-23 10:41:48 --> Controller Class Initialized
INFO - 2016-05-23 10:41:48 --> Model Class Initialized
INFO - 2016-05-23 10:41:48 --> Database Driver Class Initialized
INFO - 2016-05-23 10:41:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:41:48 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:41:48 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:41:48 --> Final output sent to browser
DEBUG - 2016-05-23 10:41:48 --> Total execution time: 0.0490
INFO - 2016-05-23 10:41:52 --> Config Class Initialized
INFO - 2016-05-23 10:41:52 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:41:52 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:41:52 --> Utf8 Class Initialized
INFO - 2016-05-23 10:41:52 --> URI Class Initialized
INFO - 2016-05-23 10:41:52 --> Router Class Initialized
INFO - 2016-05-23 10:41:52 --> Output Class Initialized
INFO - 2016-05-23 10:41:52 --> Security Class Initialized
DEBUG - 2016-05-23 10:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:41:52 --> Input Class Initialized
INFO - 2016-05-23 10:41:52 --> Language Class Initialized
INFO - 2016-05-23 10:41:52 --> Loader Class Initialized
INFO - 2016-05-23 10:41:52 --> Helper loaded: url_helper
INFO - 2016-05-23 10:41:52 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:41:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:41:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:41:52 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:41:52 --> Helper loaded: form_helper
INFO - 2016-05-23 10:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:41:52 --> Form Validation Class Initialized
INFO - 2016-05-23 10:41:52 --> Controller Class Initialized
DEBUG - 2016-05-23 10:41:52 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/templates.php
INFO - 2016-05-23 10:41:52 --> Model Class Initialized
INFO - 2016-05-23 10:41:52 --> Database Driver Class Initialized
INFO - 2016-05-23 10:41:52 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/config_plantillas.php
INFO - 2016-05-23 10:41:52 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_template1.php
INFO - 2016-05-23 10:41:52 --> Final output sent to browser
DEBUG - 2016-05-23 10:41:52 --> Total execution time: 0.0519
INFO - 2016-05-23 10:41:52 --> Config Class Initialized
INFO - 2016-05-23 10:41:52 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:41:52 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:41:52 --> Utf8 Class Initialized
INFO - 2016-05-23 10:41:52 --> URI Class Initialized
INFO - 2016-05-23 10:41:52 --> Router Class Initialized
INFO - 2016-05-23 10:41:52 --> Output Class Initialized
INFO - 2016-05-23 10:41:52 --> Security Class Initialized
DEBUG - 2016-05-23 10:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:41:52 --> Input Class Initialized
INFO - 2016-05-23 10:41:52 --> Language Class Initialized
INFO - 2016-05-23 10:41:52 --> Loader Class Initialized
INFO - 2016-05-23 10:41:52 --> Helper loaded: url_helper
INFO - 2016-05-23 10:41:52 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:41:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:41:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:41:52 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:41:52 --> Helper loaded: form_helper
INFO - 2016-05-23 10:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:41:52 --> Form Validation Class Initialized
INFO - 2016-05-23 10:41:52 --> Controller Class Initialized
INFO - 2016-05-23 10:41:52 --> Model Class Initialized
INFO - 2016-05-23 10:41:52 --> Database Driver Class Initialized
INFO - 2016-05-23 10:41:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:41:52 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:41:52 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:41:52 --> Final output sent to browser
DEBUG - 2016-05-23 10:41:52 --> Total execution time: 0.0520
INFO - 2016-05-23 10:42:02 --> Config Class Initialized
INFO - 2016-05-23 10:42:02 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:42:02 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:42:02 --> Utf8 Class Initialized
INFO - 2016-05-23 10:42:02 --> URI Class Initialized
INFO - 2016-05-23 10:42:02 --> Router Class Initialized
INFO - 2016-05-23 10:42:02 --> Output Class Initialized
INFO - 2016-05-23 10:42:02 --> Security Class Initialized
DEBUG - 2016-05-23 10:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:42:02 --> Input Class Initialized
INFO - 2016-05-23 10:42:02 --> Language Class Initialized
INFO - 2016-05-23 10:42:02 --> Loader Class Initialized
INFO - 2016-05-23 10:42:02 --> Helper loaded: url_helper
INFO - 2016-05-23 10:42:02 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:42:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:42:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:42:02 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:42:02 --> Helper loaded: form_helper
INFO - 2016-05-23 10:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:42:02 --> Form Validation Class Initialized
INFO - 2016-05-23 10:42:02 --> Controller Class Initialized
DEBUG - 2016-05-23 10:42:02 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/templates.php
INFO - 2016-05-23 10:42:02 --> Model Class Initialized
INFO - 2016-05-23 10:42:02 --> Database Driver Class Initialized
INFO - 2016-05-23 10:42:02 --> Config Class Initialized
INFO - 2016-05-23 10:42:02 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:42:02 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:42:02 --> Utf8 Class Initialized
INFO - 2016-05-23 10:42:02 --> URI Class Initialized
INFO - 2016-05-23 10:42:02 --> Router Class Initialized
INFO - 2016-05-23 10:42:02 --> Output Class Initialized
INFO - 2016-05-23 10:42:02 --> Security Class Initialized
DEBUG - 2016-05-23 10:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:42:02 --> Input Class Initialized
INFO - 2016-05-23 10:42:02 --> Language Class Initialized
INFO - 2016-05-23 10:42:02 --> Loader Class Initialized
INFO - 2016-05-23 10:42:02 --> Helper loaded: url_helper
INFO - 2016-05-23 10:42:02 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:42:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:42:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:42:02 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:42:02 --> Helper loaded: form_helper
INFO - 2016-05-23 10:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:42:02 --> Form Validation Class Initialized
INFO - 2016-05-23 10:42:02 --> Controller Class Initialized
DEBUG - 2016-05-23 10:42:02 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/templates.php
INFO - 2016-05-23 10:42:02 --> Model Class Initialized
INFO - 2016-05-23 10:42:02 --> Database Driver Class Initialized
INFO - 2016-05-23 10:42:02 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/config_plantillas.php
INFO - 2016-05-23 10:42:02 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_template2.php
INFO - 2016-05-23 10:42:02 --> Final output sent to browser
DEBUG - 2016-05-23 10:42:02 --> Total execution time: 0.0510
INFO - 2016-05-23 10:42:03 --> Config Class Initialized
INFO - 2016-05-23 10:42:03 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:42:03 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:42:03 --> Utf8 Class Initialized
INFO - 2016-05-23 10:42:03 --> URI Class Initialized
INFO - 2016-05-23 10:42:03 --> Router Class Initialized
INFO - 2016-05-23 10:42:03 --> Output Class Initialized
INFO - 2016-05-23 10:42:03 --> Security Class Initialized
DEBUG - 2016-05-23 10:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:42:03 --> Input Class Initialized
INFO - 2016-05-23 10:42:03 --> Language Class Initialized
INFO - 2016-05-23 10:42:03 --> Loader Class Initialized
INFO - 2016-05-23 10:42:03 --> Helper loaded: url_helper
INFO - 2016-05-23 10:42:03 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:42:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:42:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:42:03 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:42:04 --> Helper loaded: form_helper
INFO - 2016-05-23 10:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:42:04 --> Form Validation Class Initialized
INFO - 2016-05-23 10:42:04 --> Controller Class Initialized
INFO - 2016-05-23 10:42:04 --> Model Class Initialized
INFO - 2016-05-23 10:42:04 --> Database Driver Class Initialized
INFO - 2016-05-23 10:42:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:42:04 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:42:04 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:42:04 --> Final output sent to browser
DEBUG - 2016-05-23 10:42:04 --> Total execution time: 0.0495
INFO - 2016-05-23 10:43:04 --> Config Class Initialized
INFO - 2016-05-23 10:43:04 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:43:04 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:43:04 --> Utf8 Class Initialized
INFO - 2016-05-23 10:43:04 --> URI Class Initialized
INFO - 2016-05-23 10:43:04 --> Router Class Initialized
INFO - 2016-05-23 10:43:04 --> Output Class Initialized
INFO - 2016-05-23 10:43:04 --> Security Class Initialized
DEBUG - 2016-05-23 10:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:43:04 --> Input Class Initialized
INFO - 2016-05-23 10:43:04 --> Language Class Initialized
INFO - 2016-05-23 10:43:04 --> Loader Class Initialized
INFO - 2016-05-23 10:43:04 --> Helper loaded: url_helper
INFO - 2016-05-23 10:43:04 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:43:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:43:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:43:04 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:43:04 --> Helper loaded: form_helper
INFO - 2016-05-23 10:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:43:04 --> Form Validation Class Initialized
INFO - 2016-05-23 10:43:04 --> Controller Class Initialized
INFO - 2016-05-23 10:43:04 --> Model Class Initialized
INFO - 2016-05-23 10:43:04 --> Database Driver Class Initialized
INFO - 2016-05-23 10:43:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:43:04 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:43:04 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:43:04 --> Final output sent to browser
DEBUG - 2016-05-23 10:43:04 --> Total execution time: 0.0496
INFO - 2016-05-23 10:44:04 --> Config Class Initialized
INFO - 2016-05-23 10:44:04 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:44:04 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:44:04 --> Utf8 Class Initialized
INFO - 2016-05-23 10:44:04 --> URI Class Initialized
INFO - 2016-05-23 10:44:04 --> Router Class Initialized
INFO - 2016-05-23 10:44:04 --> Output Class Initialized
INFO - 2016-05-23 10:44:04 --> Security Class Initialized
DEBUG - 2016-05-23 10:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:44:04 --> Input Class Initialized
INFO - 2016-05-23 10:44:04 --> Language Class Initialized
INFO - 2016-05-23 10:44:04 --> Loader Class Initialized
INFO - 2016-05-23 10:44:04 --> Helper loaded: url_helper
INFO - 2016-05-23 10:44:04 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:44:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:44:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:44:04 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:44:04 --> Helper loaded: form_helper
INFO - 2016-05-23 10:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:44:04 --> Form Validation Class Initialized
INFO - 2016-05-23 10:44:04 --> Controller Class Initialized
INFO - 2016-05-23 10:44:04 --> Model Class Initialized
INFO - 2016-05-23 10:44:04 --> Database Driver Class Initialized
INFO - 2016-05-23 10:44:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:44:04 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:44:04 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:44:04 --> Final output sent to browser
DEBUG - 2016-05-23 10:44:04 --> Total execution time: 0.0505
INFO - 2016-05-23 10:44:28 --> Config Class Initialized
INFO - 2016-05-23 10:44:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:44:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:44:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:44:28 --> URI Class Initialized
INFO - 2016-05-23 10:44:28 --> Router Class Initialized
INFO - 2016-05-23 10:44:28 --> Output Class Initialized
INFO - 2016-05-23 10:44:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:44:28 --> Input Class Initialized
INFO - 2016-05-23 10:44:28 --> Language Class Initialized
INFO - 2016-05-23 10:44:28 --> Loader Class Initialized
INFO - 2016-05-23 10:44:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:44:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:44:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:44:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:44:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:44:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:44:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:44:28 --> Controller Class Initialized
DEBUG - 2016-05-23 10:44:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/templates.php
INFO - 2016-05-23 10:44:28 --> Model Class Initialized
INFO - 2016-05-23 10:44:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:44:28 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/config_plantillas.php
INFO - 2016-05-23 10:44:28 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_template2.php
INFO - 2016-05-23 10:44:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:44:28 --> Total execution time: 0.0502
INFO - 2016-05-23 10:44:28 --> Config Class Initialized
INFO - 2016-05-23 10:44:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:44:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:44:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:44:28 --> URI Class Initialized
INFO - 2016-05-23 10:44:28 --> Router Class Initialized
INFO - 2016-05-23 10:44:28 --> Output Class Initialized
INFO - 2016-05-23 10:44:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:44:28 --> Input Class Initialized
INFO - 2016-05-23 10:44:28 --> Language Class Initialized
INFO - 2016-05-23 10:44:28 --> Loader Class Initialized
INFO - 2016-05-23 10:44:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:44:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:44:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:44:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:44:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:44:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:44:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:44:28 --> Controller Class Initialized
INFO - 2016-05-23 10:44:28 --> Model Class Initialized
INFO - 2016-05-23 10:44:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:44:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:44:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:44:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:44:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:44:28 --> Total execution time: 0.0490
INFO - 2016-05-23 10:45:28 --> Config Class Initialized
INFO - 2016-05-23 10:45:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:45:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:45:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:45:28 --> URI Class Initialized
INFO - 2016-05-23 10:45:28 --> Router Class Initialized
INFO - 2016-05-23 10:45:28 --> Output Class Initialized
INFO - 2016-05-23 10:45:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:45:28 --> Input Class Initialized
INFO - 2016-05-23 10:45:28 --> Language Class Initialized
INFO - 2016-05-23 10:45:28 --> Loader Class Initialized
INFO - 2016-05-23 10:45:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:45:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:45:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:45:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:45:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:45:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:45:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:45:28 --> Controller Class Initialized
INFO - 2016-05-23 10:45:28 --> Model Class Initialized
INFO - 2016-05-23 10:45:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:45:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:45:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:45:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:45:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:45:28 --> Total execution time: 0.0491
INFO - 2016-05-23 10:46:28 --> Config Class Initialized
INFO - 2016-05-23 10:46:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:46:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:46:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:46:28 --> URI Class Initialized
INFO - 2016-05-23 10:46:28 --> Router Class Initialized
INFO - 2016-05-23 10:46:28 --> Output Class Initialized
INFO - 2016-05-23 10:46:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:46:28 --> Input Class Initialized
INFO - 2016-05-23 10:46:28 --> Language Class Initialized
INFO - 2016-05-23 10:46:28 --> Loader Class Initialized
INFO - 2016-05-23 10:46:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:46:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:46:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:46:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:46:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:46:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:46:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:46:28 --> Controller Class Initialized
INFO - 2016-05-23 10:46:28 --> Model Class Initialized
INFO - 2016-05-23 10:46:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:46:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:46:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:46:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:46:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:46:28 --> Total execution time: 0.0495
INFO - 2016-05-23 10:47:28 --> Config Class Initialized
INFO - 2016-05-23 10:47:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:47:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:47:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:47:28 --> URI Class Initialized
INFO - 2016-05-23 10:47:28 --> Router Class Initialized
INFO - 2016-05-23 10:47:28 --> Output Class Initialized
INFO - 2016-05-23 10:47:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:47:28 --> Input Class Initialized
INFO - 2016-05-23 10:47:28 --> Language Class Initialized
INFO - 2016-05-23 10:47:28 --> Loader Class Initialized
INFO - 2016-05-23 10:47:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:47:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:47:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:47:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:47:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:47:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:47:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:47:28 --> Controller Class Initialized
INFO - 2016-05-23 10:47:28 --> Model Class Initialized
INFO - 2016-05-23 10:47:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:47:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:47:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:47:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:47:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:47:28 --> Total execution time: 0.0639
INFO - 2016-05-23 10:48:28 --> Config Class Initialized
INFO - 2016-05-23 10:48:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:48:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:48:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:48:28 --> URI Class Initialized
INFO - 2016-05-23 10:48:28 --> Router Class Initialized
INFO - 2016-05-23 10:48:28 --> Output Class Initialized
INFO - 2016-05-23 10:48:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:48:28 --> Input Class Initialized
INFO - 2016-05-23 10:48:28 --> Language Class Initialized
INFO - 2016-05-23 10:48:28 --> Loader Class Initialized
INFO - 2016-05-23 10:48:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:48:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:48:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:48:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:48:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:48:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:48:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:48:28 --> Controller Class Initialized
INFO - 2016-05-23 10:48:28 --> Model Class Initialized
INFO - 2016-05-23 10:48:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:48:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:48:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:48:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:48:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:48:28 --> Total execution time: 0.0623
INFO - 2016-05-23 10:49:28 --> Config Class Initialized
INFO - 2016-05-23 10:49:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:49:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:49:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:49:28 --> URI Class Initialized
INFO - 2016-05-23 10:49:28 --> Router Class Initialized
INFO - 2016-05-23 10:49:28 --> Output Class Initialized
INFO - 2016-05-23 10:49:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:49:28 --> Input Class Initialized
INFO - 2016-05-23 10:49:28 --> Language Class Initialized
INFO - 2016-05-23 10:49:28 --> Loader Class Initialized
INFO - 2016-05-23 10:49:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:49:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:49:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:49:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:49:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:49:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:49:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:49:28 --> Controller Class Initialized
INFO - 2016-05-23 10:49:28 --> Model Class Initialized
INFO - 2016-05-23 10:49:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:49:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:49:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:49:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:49:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:49:28 --> Total execution time: 0.0622
INFO - 2016-05-23 10:50:28 --> Config Class Initialized
INFO - 2016-05-23 10:50:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:50:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:50:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:50:28 --> URI Class Initialized
INFO - 2016-05-23 10:50:28 --> Router Class Initialized
INFO - 2016-05-23 10:50:28 --> Output Class Initialized
INFO - 2016-05-23 10:50:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:50:28 --> Input Class Initialized
INFO - 2016-05-23 10:50:28 --> Language Class Initialized
INFO - 2016-05-23 10:50:28 --> Loader Class Initialized
INFO - 2016-05-23 10:50:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:50:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:50:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:50:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:50:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:50:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:50:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:50:28 --> Controller Class Initialized
INFO - 2016-05-23 10:50:28 --> Model Class Initialized
INFO - 2016-05-23 10:50:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:50:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:50:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:50:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:50:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:50:28 --> Total execution time: 0.0564
INFO - 2016-05-23 10:51:28 --> Config Class Initialized
INFO - 2016-05-23 10:51:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:51:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:51:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:51:28 --> URI Class Initialized
INFO - 2016-05-23 10:51:28 --> Router Class Initialized
INFO - 2016-05-23 10:51:28 --> Output Class Initialized
INFO - 2016-05-23 10:51:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:51:28 --> Input Class Initialized
INFO - 2016-05-23 10:51:28 --> Language Class Initialized
INFO - 2016-05-23 10:51:28 --> Loader Class Initialized
INFO - 2016-05-23 10:51:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:51:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:51:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:51:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:51:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:51:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:51:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:51:28 --> Controller Class Initialized
INFO - 2016-05-23 10:51:28 --> Model Class Initialized
INFO - 2016-05-23 10:51:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:51:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:51:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:51:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:51:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:51:28 --> Total execution time: 0.0494
INFO - 2016-05-23 10:52:28 --> Config Class Initialized
INFO - 2016-05-23 10:52:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:52:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:52:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:52:28 --> URI Class Initialized
INFO - 2016-05-23 10:52:28 --> Router Class Initialized
INFO - 2016-05-23 10:52:28 --> Output Class Initialized
INFO - 2016-05-23 10:52:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:52:28 --> Input Class Initialized
INFO - 2016-05-23 10:52:28 --> Language Class Initialized
INFO - 2016-05-23 10:52:28 --> Loader Class Initialized
INFO - 2016-05-23 10:52:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:52:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:52:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:52:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:52:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:52:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:52:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:52:28 --> Controller Class Initialized
INFO - 2016-05-23 10:52:28 --> Model Class Initialized
INFO - 2016-05-23 10:52:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:52:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:52:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:52:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:52:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:52:28 --> Total execution time: 0.0494
INFO - 2016-05-23 10:53:28 --> Config Class Initialized
INFO - 2016-05-23 10:53:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:53:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:53:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:53:28 --> URI Class Initialized
INFO - 2016-05-23 10:53:28 --> Router Class Initialized
INFO - 2016-05-23 10:53:28 --> Output Class Initialized
INFO - 2016-05-23 10:53:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:53:28 --> Input Class Initialized
INFO - 2016-05-23 10:53:28 --> Language Class Initialized
INFO - 2016-05-23 10:53:28 --> Loader Class Initialized
INFO - 2016-05-23 10:53:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:53:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:53:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:53:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:53:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:53:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:53:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:53:28 --> Controller Class Initialized
INFO - 2016-05-23 10:53:28 --> Model Class Initialized
INFO - 2016-05-23 10:53:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:53:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:53:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:53:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:53:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:53:28 --> Total execution time: 0.0493
INFO - 2016-05-23 10:54:28 --> Config Class Initialized
INFO - 2016-05-23 10:54:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:54:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:54:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:54:28 --> URI Class Initialized
INFO - 2016-05-23 10:54:28 --> Router Class Initialized
INFO - 2016-05-23 10:54:28 --> Output Class Initialized
INFO - 2016-05-23 10:54:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:54:28 --> Input Class Initialized
INFO - 2016-05-23 10:54:28 --> Language Class Initialized
INFO - 2016-05-23 10:54:28 --> Loader Class Initialized
INFO - 2016-05-23 10:54:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:54:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:54:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:54:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:54:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:54:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:54:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:54:28 --> Controller Class Initialized
INFO - 2016-05-23 10:54:28 --> Model Class Initialized
INFO - 2016-05-23 10:54:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:54:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:54:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:54:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:54:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:54:28 --> Total execution time: 0.0519
INFO - 2016-05-23 10:55:28 --> Config Class Initialized
INFO - 2016-05-23 10:55:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:55:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:55:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:55:28 --> URI Class Initialized
INFO - 2016-05-23 10:55:28 --> Router Class Initialized
INFO - 2016-05-23 10:55:28 --> Output Class Initialized
INFO - 2016-05-23 10:55:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:55:28 --> Input Class Initialized
INFO - 2016-05-23 10:55:28 --> Language Class Initialized
INFO - 2016-05-23 10:55:28 --> Loader Class Initialized
INFO - 2016-05-23 10:55:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:55:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:55:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:55:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:55:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:55:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:55:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:55:28 --> Controller Class Initialized
INFO - 2016-05-23 10:55:28 --> Model Class Initialized
INFO - 2016-05-23 10:55:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:55:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:55:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:55:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:55:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:55:28 --> Total execution time: 0.0492
INFO - 2016-05-23 10:56:28 --> Config Class Initialized
INFO - 2016-05-23 10:56:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:56:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:56:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:56:28 --> URI Class Initialized
INFO - 2016-05-23 10:56:28 --> Router Class Initialized
INFO - 2016-05-23 10:56:28 --> Output Class Initialized
INFO - 2016-05-23 10:56:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:56:28 --> Input Class Initialized
INFO - 2016-05-23 10:56:28 --> Language Class Initialized
INFO - 2016-05-23 10:56:28 --> Loader Class Initialized
INFO - 2016-05-23 10:56:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:56:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:56:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:56:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:56:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:56:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:56:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:56:28 --> Controller Class Initialized
INFO - 2016-05-23 10:56:28 --> Model Class Initialized
INFO - 2016-05-23 10:56:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:56:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:56:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:56:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:56:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:56:28 --> Total execution time: 0.0624
INFO - 2016-05-23 10:57:28 --> Config Class Initialized
INFO - 2016-05-23 10:57:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:57:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:57:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:57:28 --> URI Class Initialized
INFO - 2016-05-23 10:57:28 --> Router Class Initialized
INFO - 2016-05-23 10:57:28 --> Output Class Initialized
INFO - 2016-05-23 10:57:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:57:28 --> Input Class Initialized
INFO - 2016-05-23 10:57:28 --> Language Class Initialized
INFO - 2016-05-23 10:57:28 --> Loader Class Initialized
INFO - 2016-05-23 10:57:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:57:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:57:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:57:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:57:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:57:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:57:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:57:28 --> Controller Class Initialized
INFO - 2016-05-23 10:57:28 --> Model Class Initialized
INFO - 2016-05-23 10:57:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:57:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:57:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:57:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:57:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:57:28 --> Total execution time: 0.0561
INFO - 2016-05-23 10:58:28 --> Config Class Initialized
INFO - 2016-05-23 10:58:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:58:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:58:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:58:28 --> URI Class Initialized
INFO - 2016-05-23 10:58:28 --> Router Class Initialized
INFO - 2016-05-23 10:58:28 --> Output Class Initialized
INFO - 2016-05-23 10:58:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:58:28 --> Input Class Initialized
INFO - 2016-05-23 10:58:28 --> Language Class Initialized
INFO - 2016-05-23 10:58:28 --> Loader Class Initialized
INFO - 2016-05-23 10:58:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:58:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:58:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:58:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:58:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:58:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:58:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:58:28 --> Controller Class Initialized
INFO - 2016-05-23 10:58:28 --> Model Class Initialized
INFO - 2016-05-23 10:58:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:58:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:58:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:58:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:58:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:58:28 --> Total execution time: 0.0489
INFO - 2016-05-23 10:59:28 --> Config Class Initialized
INFO - 2016-05-23 10:59:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:59:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:59:28 --> Utf8 Class Initialized
INFO - 2016-05-23 10:59:28 --> URI Class Initialized
INFO - 2016-05-23 10:59:28 --> Router Class Initialized
INFO - 2016-05-23 10:59:28 --> Output Class Initialized
INFO - 2016-05-23 10:59:28 --> Security Class Initialized
DEBUG - 2016-05-23 10:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:59:28 --> Input Class Initialized
INFO - 2016-05-23 10:59:28 --> Language Class Initialized
INFO - 2016-05-23 10:59:28 --> Loader Class Initialized
INFO - 2016-05-23 10:59:28 --> Helper loaded: url_helper
INFO - 2016-05-23 10:59:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 10:59:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 10:59:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 10:59:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 10:59:28 --> Helper loaded: form_helper
INFO - 2016-05-23 10:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 10:59:28 --> Form Validation Class Initialized
INFO - 2016-05-23 10:59:28 --> Controller Class Initialized
INFO - 2016-05-23 10:59:28 --> Model Class Initialized
INFO - 2016-05-23 10:59:28 --> Database Driver Class Initialized
INFO - 2016-05-23 10:59:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 10:59:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 10:59:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 10:59:28 --> Final output sent to browser
DEBUG - 2016-05-23 10:59:28 --> Total execution time: 0.0664
INFO - 2016-05-23 11:00:28 --> Config Class Initialized
INFO - 2016-05-23 11:00:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:00:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:00:28 --> Utf8 Class Initialized
INFO - 2016-05-23 11:00:28 --> URI Class Initialized
INFO - 2016-05-23 11:00:28 --> Router Class Initialized
INFO - 2016-05-23 11:00:28 --> Output Class Initialized
INFO - 2016-05-23 11:00:28 --> Security Class Initialized
DEBUG - 2016-05-23 11:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:00:28 --> Input Class Initialized
INFO - 2016-05-23 11:00:28 --> Language Class Initialized
INFO - 2016-05-23 11:00:28 --> Loader Class Initialized
INFO - 2016-05-23 11:00:28 --> Helper loaded: url_helper
INFO - 2016-05-23 11:00:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 11:00:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 11:00:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 11:00:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 11:00:28 --> Helper loaded: form_helper
INFO - 2016-05-23 11:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 11:00:28 --> Form Validation Class Initialized
INFO - 2016-05-23 11:00:28 --> Controller Class Initialized
INFO - 2016-05-23 11:00:28 --> Model Class Initialized
INFO - 2016-05-23 11:00:28 --> Database Driver Class Initialized
INFO - 2016-05-23 11:00:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 11:00:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 11:00:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 11:00:28 --> Final output sent to browser
DEBUG - 2016-05-23 11:00:28 --> Total execution time: 0.0618
INFO - 2016-05-23 11:01:28 --> Config Class Initialized
INFO - 2016-05-23 11:01:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:01:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:01:28 --> Utf8 Class Initialized
INFO - 2016-05-23 11:01:28 --> URI Class Initialized
INFO - 2016-05-23 11:01:28 --> Router Class Initialized
INFO - 2016-05-23 11:01:28 --> Output Class Initialized
INFO - 2016-05-23 11:01:28 --> Security Class Initialized
DEBUG - 2016-05-23 11:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:01:28 --> Input Class Initialized
INFO - 2016-05-23 11:01:28 --> Language Class Initialized
INFO - 2016-05-23 11:01:28 --> Loader Class Initialized
INFO - 2016-05-23 11:01:28 --> Helper loaded: url_helper
INFO - 2016-05-23 11:01:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 11:01:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 11:01:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 11:01:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 11:01:28 --> Helper loaded: form_helper
INFO - 2016-05-23 11:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 11:01:28 --> Form Validation Class Initialized
INFO - 2016-05-23 11:01:28 --> Controller Class Initialized
INFO - 2016-05-23 11:01:28 --> Model Class Initialized
INFO - 2016-05-23 11:01:28 --> Database Driver Class Initialized
INFO - 2016-05-23 11:01:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 11:01:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 11:01:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 11:01:28 --> Final output sent to browser
DEBUG - 2016-05-23 11:01:28 --> Total execution time: 0.0499
INFO - 2016-05-23 11:02:28 --> Config Class Initialized
INFO - 2016-05-23 11:02:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:02:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:02:28 --> Utf8 Class Initialized
INFO - 2016-05-23 11:02:28 --> URI Class Initialized
INFO - 2016-05-23 11:02:28 --> Router Class Initialized
INFO - 2016-05-23 11:02:28 --> Output Class Initialized
INFO - 2016-05-23 11:02:28 --> Security Class Initialized
DEBUG - 2016-05-23 11:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:02:28 --> Input Class Initialized
INFO - 2016-05-23 11:02:28 --> Language Class Initialized
INFO - 2016-05-23 11:02:28 --> Loader Class Initialized
INFO - 2016-05-23 11:02:28 --> Helper loaded: url_helper
INFO - 2016-05-23 11:02:28 --> Helper loaded: sesion_helper
INFO - 2016-05-23 11:02:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 11:02:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 11:02:28 --> Helper loaded: redondear_helper
INFO - 2016-05-23 11:02:28 --> Helper loaded: form_helper
INFO - 2016-05-23 11:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 11:02:28 --> Form Validation Class Initialized
INFO - 2016-05-23 11:02:28 --> Controller Class Initialized
INFO - 2016-05-23 11:02:28 --> Model Class Initialized
INFO - 2016-05-23 11:02:28 --> Database Driver Class Initialized
INFO - 2016-05-23 11:02:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 11:02:28 --> Pagination Class Initialized
DEBUG - 2016-05-23 11:02:28 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 11:02:28 --> Final output sent to browser
DEBUG - 2016-05-23 11:02:28 --> Total execution time: 0.0573
INFO - 2016-05-23 11:02:29 --> Config Class Initialized
INFO - 2016-05-23 11:02:29 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:02:29 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:02:29 --> Utf8 Class Initialized
INFO - 2016-05-23 11:02:29 --> URI Class Initialized
INFO - 2016-05-23 11:02:29 --> Router Class Initialized
INFO - 2016-05-23 11:02:29 --> Output Class Initialized
INFO - 2016-05-23 11:02:29 --> Security Class Initialized
DEBUG - 2016-05-23 11:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:02:29 --> Input Class Initialized
INFO - 2016-05-23 11:02:29 --> Language Class Initialized
INFO - 2016-05-23 11:02:29 --> Loader Class Initialized
INFO - 2016-05-23 11:02:29 --> Helper loaded: url_helper
INFO - 2016-05-23 11:02:29 --> Helper loaded: sesion_helper
INFO - 2016-05-23 11:02:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 11:02:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 11:02:29 --> Helper loaded: redondear_helper
INFO - 2016-05-23 11:02:29 --> Helper loaded: form_helper
INFO - 2016-05-23 11:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 11:02:29 --> Form Validation Class Initialized
INFO - 2016-05-23 11:02:29 --> Controller Class Initialized
DEBUG - 2016-05-23 11:02:29 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/templates.php
INFO - 2016-05-23 11:02:29 --> Model Class Initialized
INFO - 2016-05-23 11:02:29 --> Database Driver Class Initialized
INFO - 2016-05-23 11:02:29 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/config_plantillas.php
INFO - 2016-05-23 11:02:29 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_template2.php
INFO - 2016-05-23 11:02:29 --> Final output sent to browser
DEBUG - 2016-05-23 11:02:29 --> Total execution time: 0.0499
INFO - 2016-05-23 11:02:31 --> Config Class Initialized
INFO - 2016-05-23 11:02:31 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:02:31 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:02:31 --> Utf8 Class Initialized
INFO - 2016-05-23 11:02:31 --> URI Class Initialized
INFO - 2016-05-23 11:02:31 --> Router Class Initialized
INFO - 2016-05-23 11:02:31 --> Output Class Initialized
INFO - 2016-05-23 11:02:31 --> Security Class Initialized
DEBUG - 2016-05-23 11:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:02:31 --> Input Class Initialized
INFO - 2016-05-23 11:02:31 --> Language Class Initialized
INFO - 2016-05-23 11:02:31 --> Loader Class Initialized
INFO - 2016-05-23 11:02:31 --> Helper loaded: url_helper
INFO - 2016-05-23 11:02:31 --> Helper loaded: sesion_helper
INFO - 2016-05-23 11:02:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 11:02:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 11:02:31 --> Helper loaded: redondear_helper
INFO - 2016-05-23 11:02:31 --> Helper loaded: form_helper
INFO - 2016-05-23 11:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 11:02:31 --> Form Validation Class Initialized
INFO - 2016-05-23 11:02:31 --> Controller Class Initialized
INFO - 2016-05-23 11:02:31 --> Model Class Initialized
INFO - 2016-05-23 11:02:31 --> Database Driver Class Initialized
INFO - 2016-05-23 11:02:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 11:02:31 --> Pagination Class Initialized
DEBUG - 2016-05-23 11:02:31 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 11:02:31 --> Final output sent to browser
DEBUG - 2016-05-23 11:02:31 --> Total execution time: 0.0494
INFO - 2016-05-23 19:15:43 --> Config Class Initialized
INFO - 2016-05-23 19:15:43 --> Hooks Class Initialized
DEBUG - 2016-05-23 19:15:43 --> UTF-8 Support Enabled
INFO - 2016-05-23 19:15:43 --> Utf8 Class Initialized
INFO - 2016-05-23 19:15:43 --> URI Class Initialized
INFO - 2016-05-23 19:15:43 --> Router Class Initialized
INFO - 2016-05-23 19:15:43 --> Output Class Initialized
INFO - 2016-05-23 19:15:43 --> Security Class Initialized
DEBUG - 2016-05-23 19:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 19:15:43 --> Input Class Initialized
INFO - 2016-05-23 19:15:43 --> Language Class Initialized
INFO - 2016-05-23 19:15:43 --> Loader Class Initialized
INFO - 2016-05-23 19:15:43 --> Helper loaded: url_helper
INFO - 2016-05-23 19:15:43 --> Helper loaded: sesion_helper
INFO - 2016-05-23 19:15:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 19:15:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 19:15:43 --> Helper loaded: redondear_helper
INFO - 2016-05-23 19:15:43 --> Helper loaded: form_helper
INFO - 2016-05-23 19:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 19:15:43 --> Form Validation Class Initialized
INFO - 2016-05-23 19:15:43 --> Controller Class Initialized
INFO - 2016-05-23 19:15:43 --> Model Class Initialized
INFO - 2016-05-23 19:15:43 --> Database Driver Class Initialized
INFO - 2016-05-23 19:15:43 --> Email Class Initialized
INFO - 2016-05-23 19:15:43 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_pideClaveRestablecer.php
INFO - 2016-05-23 19:15:43 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_template2.php
INFO - 2016-05-23 19:15:43 --> Final output sent to browser
DEBUG - 2016-05-23 19:15:43 --> Total execution time: 0.3351
INFO - 2016-05-23 19:15:47 --> Config Class Initialized
INFO - 2016-05-23 19:15:47 --> Hooks Class Initialized
DEBUG - 2016-05-23 19:15:47 --> UTF-8 Support Enabled
INFO - 2016-05-23 19:15:47 --> Utf8 Class Initialized
INFO - 2016-05-23 19:15:47 --> URI Class Initialized
INFO - 2016-05-23 19:15:47 --> Router Class Initialized
INFO - 2016-05-23 19:15:47 --> Output Class Initialized
INFO - 2016-05-23 19:15:47 --> Security Class Initialized
DEBUG - 2016-05-23 19:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 19:15:47 --> Input Class Initialized
INFO - 2016-05-23 19:15:47 --> Language Class Initialized
INFO - 2016-05-23 19:15:47 --> Loader Class Initialized
INFO - 2016-05-23 19:15:47 --> Helper loaded: url_helper
INFO - 2016-05-23 19:15:47 --> Helper loaded: sesion_helper
INFO - 2016-05-23 19:15:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 19:15:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 19:15:47 --> Helper loaded: redondear_helper
INFO - 2016-05-23 19:15:47 --> Helper loaded: form_helper
INFO - 2016-05-23 19:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 19:15:47 --> Form Validation Class Initialized
INFO - 2016-05-23 19:15:47 --> Controller Class Initialized
INFO - 2016-05-23 19:15:47 --> Model Class Initialized
INFO - 2016-05-23 19:15:47 --> Database Driver Class Initialized
INFO - 2016-05-23 19:15:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 19:15:47 --> Pagination Class Initialized
DEBUG - 2016-05-23 19:15:47 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 19:15:47 --> Config Class Initialized
INFO - 2016-05-23 19:15:47 --> Hooks Class Initialized
DEBUG - 2016-05-23 19:15:47 --> UTF-8 Support Enabled
INFO - 2016-05-23 19:15:47 --> Utf8 Class Initialized
INFO - 2016-05-23 19:15:47 --> URI Class Initialized
INFO - 2016-05-23 19:15:47 --> Router Class Initialized
INFO - 2016-05-23 19:15:47 --> Output Class Initialized
INFO - 2016-05-23 19:15:47 --> Security Class Initialized
DEBUG - 2016-05-23 19:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 19:15:47 --> Input Class Initialized
INFO - 2016-05-23 19:15:47 --> Language Class Initialized
INFO - 2016-05-23 19:15:47 --> Loader Class Initialized
INFO - 2016-05-23 19:15:47 --> Helper loaded: url_helper
INFO - 2016-05-23 19:15:47 --> Helper loaded: sesion_helper
INFO - 2016-05-23 19:15:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 19:15:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 19:15:47 --> Helper loaded: redondear_helper
INFO - 2016-05-23 19:15:47 --> Helper loaded: form_helper
INFO - 2016-05-23 19:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 19:15:47 --> Form Validation Class Initialized
INFO - 2016-05-23 19:15:47 --> Controller Class Initialized
INFO - 2016-05-23 19:15:47 --> Model Class Initialized
INFO - 2016-05-23 19:15:47 --> Database Driver Class Initialized
INFO - 2016-05-23 19:15:47 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_login.php
INFO - 2016-05-23 19:15:47 --> Final output sent to browser
DEBUG - 2016-05-23 19:15:47 --> Total execution time: 0.0473
INFO - 2016-05-23 19:16:47 --> Config Class Initialized
INFO - 2016-05-23 19:16:47 --> Hooks Class Initialized
DEBUG - 2016-05-23 19:16:47 --> UTF-8 Support Enabled
INFO - 2016-05-23 19:16:47 --> Utf8 Class Initialized
INFO - 2016-05-23 19:16:47 --> URI Class Initialized
INFO - 2016-05-23 19:16:47 --> Router Class Initialized
INFO - 2016-05-23 19:16:47 --> Output Class Initialized
INFO - 2016-05-23 19:16:47 --> Security Class Initialized
DEBUG - 2016-05-23 19:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 19:16:47 --> Input Class Initialized
INFO - 2016-05-23 19:16:47 --> Language Class Initialized
INFO - 2016-05-23 19:16:47 --> Loader Class Initialized
INFO - 2016-05-23 19:16:47 --> Helper loaded: url_helper
INFO - 2016-05-23 19:16:47 --> Helper loaded: sesion_helper
INFO - 2016-05-23 19:16:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 19:16:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 19:16:47 --> Helper loaded: redondear_helper
INFO - 2016-05-23 19:16:47 --> Helper loaded: form_helper
INFO - 2016-05-23 19:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 19:16:47 --> Form Validation Class Initialized
INFO - 2016-05-23 19:16:47 --> Controller Class Initialized
INFO - 2016-05-23 19:16:47 --> Model Class Initialized
INFO - 2016-05-23 19:16:47 --> Database Driver Class Initialized
INFO - 2016-05-23 19:16:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 19:16:47 --> Pagination Class Initialized
DEBUG - 2016-05-23 19:16:47 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 19:16:47 --> Config Class Initialized
INFO - 2016-05-23 19:16:47 --> Hooks Class Initialized
DEBUG - 2016-05-23 19:16:47 --> UTF-8 Support Enabled
INFO - 2016-05-23 19:16:47 --> Utf8 Class Initialized
INFO - 2016-05-23 19:16:47 --> URI Class Initialized
INFO - 2016-05-23 19:16:47 --> Router Class Initialized
INFO - 2016-05-23 19:16:47 --> Output Class Initialized
INFO - 2016-05-23 19:16:47 --> Security Class Initialized
DEBUG - 2016-05-23 19:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 19:16:47 --> Input Class Initialized
INFO - 2016-05-23 19:16:47 --> Language Class Initialized
INFO - 2016-05-23 19:16:47 --> Loader Class Initialized
INFO - 2016-05-23 19:16:47 --> Helper loaded: url_helper
INFO - 2016-05-23 19:16:47 --> Helper loaded: sesion_helper
INFO - 2016-05-23 19:16:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 19:16:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 19:16:47 --> Helper loaded: redondear_helper
INFO - 2016-05-23 19:16:47 --> Helper loaded: form_helper
INFO - 2016-05-23 19:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 19:16:47 --> Form Validation Class Initialized
INFO - 2016-05-23 19:16:47 --> Controller Class Initialized
INFO - 2016-05-23 19:16:47 --> Model Class Initialized
INFO - 2016-05-23 19:16:47 --> Database Driver Class Initialized
INFO - 2016-05-23 19:16:47 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_login.php
INFO - 2016-05-23 19:16:47 --> Final output sent to browser
DEBUG - 2016-05-23 19:16:47 --> Total execution time: 0.0463
INFO - 2016-05-23 19:17:47 --> Config Class Initialized
INFO - 2016-05-23 19:17:47 --> Hooks Class Initialized
DEBUG - 2016-05-23 19:17:47 --> UTF-8 Support Enabled
INFO - 2016-05-23 19:17:47 --> Utf8 Class Initialized
INFO - 2016-05-23 19:17:47 --> URI Class Initialized
INFO - 2016-05-23 19:17:47 --> Router Class Initialized
INFO - 2016-05-23 19:17:47 --> Output Class Initialized
INFO - 2016-05-23 19:17:47 --> Security Class Initialized
DEBUG - 2016-05-23 19:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 19:17:47 --> Input Class Initialized
INFO - 2016-05-23 19:17:47 --> Language Class Initialized
INFO - 2016-05-23 19:17:47 --> Loader Class Initialized
INFO - 2016-05-23 19:17:47 --> Helper loaded: url_helper
INFO - 2016-05-23 19:17:47 --> Helper loaded: sesion_helper
INFO - 2016-05-23 19:17:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 19:17:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 19:17:47 --> Helper loaded: redondear_helper
INFO - 2016-05-23 19:17:47 --> Helper loaded: form_helper
INFO - 2016-05-23 19:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 19:17:47 --> Form Validation Class Initialized
INFO - 2016-05-23 19:17:47 --> Controller Class Initialized
INFO - 2016-05-23 19:17:47 --> Model Class Initialized
INFO - 2016-05-23 19:17:47 --> Database Driver Class Initialized
INFO - 2016-05-23 19:17:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 19:17:47 --> Pagination Class Initialized
DEBUG - 2016-05-23 19:17:47 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 19:17:47 --> Config Class Initialized
INFO - 2016-05-23 19:17:47 --> Hooks Class Initialized
DEBUG - 2016-05-23 19:17:47 --> UTF-8 Support Enabled
INFO - 2016-05-23 19:17:47 --> Utf8 Class Initialized
INFO - 2016-05-23 19:17:47 --> URI Class Initialized
INFO - 2016-05-23 19:17:47 --> Router Class Initialized
INFO - 2016-05-23 19:17:47 --> Output Class Initialized
INFO - 2016-05-23 19:17:47 --> Security Class Initialized
DEBUG - 2016-05-23 19:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 19:17:47 --> Input Class Initialized
INFO - 2016-05-23 19:17:47 --> Language Class Initialized
INFO - 2016-05-23 19:17:47 --> Loader Class Initialized
INFO - 2016-05-23 19:17:47 --> Helper loaded: url_helper
INFO - 2016-05-23 19:17:47 --> Helper loaded: sesion_helper
INFO - 2016-05-23 19:17:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 19:17:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 19:17:47 --> Helper loaded: redondear_helper
INFO - 2016-05-23 19:17:47 --> Helper loaded: form_helper
INFO - 2016-05-23 19:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 19:17:47 --> Form Validation Class Initialized
INFO - 2016-05-23 19:17:47 --> Controller Class Initialized
INFO - 2016-05-23 19:17:47 --> Model Class Initialized
INFO - 2016-05-23 19:17:47 --> Database Driver Class Initialized
INFO - 2016-05-23 19:17:47 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_login.php
INFO - 2016-05-23 19:17:47 --> Final output sent to browser
DEBUG - 2016-05-23 19:17:47 --> Total execution time: 0.0453
INFO - 2016-05-23 19:57:19 --> Config Class Initialized
INFO - 2016-05-23 19:57:19 --> Hooks Class Initialized
DEBUG - 2016-05-23 19:57:19 --> UTF-8 Support Enabled
INFO - 2016-05-23 19:57:19 --> Utf8 Class Initialized
INFO - 2016-05-23 19:57:19 --> URI Class Initialized
INFO - 2016-05-23 19:57:19 --> Router Class Initialized
INFO - 2016-05-23 19:57:19 --> Output Class Initialized
INFO - 2016-05-23 19:57:19 --> Security Class Initialized
DEBUG - 2016-05-23 19:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 19:57:19 --> Input Class Initialized
INFO - 2016-05-23 19:57:19 --> Language Class Initialized
INFO - 2016-05-23 19:57:19 --> Loader Class Initialized
INFO - 2016-05-23 19:57:19 --> Helper loaded: url_helper
INFO - 2016-05-23 19:57:19 --> Helper loaded: sesion_helper
INFO - 2016-05-23 19:57:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 19:57:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 19:57:19 --> Helper loaded: redondear_helper
INFO - 2016-05-23 19:57:19 --> Helper loaded: form_helper
INFO - 2016-05-23 19:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 19:57:19 --> Form Validation Class Initialized
INFO - 2016-05-23 19:57:19 --> Controller Class Initialized
INFO - 2016-05-23 19:57:19 --> Model Class Initialized
INFO - 2016-05-23 19:57:19 --> Database Driver Class Initialized
INFO - 2016-05-23 19:57:19 --> Email Class Initialized
INFO - 2016-05-23 19:57:19 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_pideClaveRestablecer.php
INFO - 2016-05-23 19:57:19 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_template2.php
INFO - 2016-05-23 19:57:19 --> Final output sent to browser
DEBUG - 2016-05-23 19:57:19 --> Total execution time: 0.0791
INFO - 2016-05-23 19:57:21 --> Config Class Initialized
INFO - 2016-05-23 19:57:21 --> Hooks Class Initialized
DEBUG - 2016-05-23 19:57:21 --> UTF-8 Support Enabled
INFO - 2016-05-23 19:57:21 --> Utf8 Class Initialized
INFO - 2016-05-23 19:57:21 --> URI Class Initialized
INFO - 2016-05-23 19:57:21 --> Router Class Initialized
INFO - 2016-05-23 19:57:21 --> Output Class Initialized
INFO - 2016-05-23 19:57:21 --> Security Class Initialized
DEBUG - 2016-05-23 19:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 19:57:21 --> Input Class Initialized
INFO - 2016-05-23 19:57:21 --> Language Class Initialized
INFO - 2016-05-23 19:57:21 --> Loader Class Initialized
INFO - 2016-05-23 19:57:21 --> Helper loaded: url_helper
INFO - 2016-05-23 19:57:21 --> Helper loaded: sesion_helper
INFO - 2016-05-23 19:57:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 19:57:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 19:57:21 --> Helper loaded: redondear_helper
INFO - 2016-05-23 19:57:21 --> Helper loaded: form_helper
INFO - 2016-05-23 19:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 19:57:21 --> Form Validation Class Initialized
INFO - 2016-05-23 19:57:21 --> Controller Class Initialized
INFO - 2016-05-23 19:57:21 --> Model Class Initialized
INFO - 2016-05-23 19:57:21 --> Database Driver Class Initialized
INFO - 2016-05-23 19:57:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 19:57:21 --> Pagination Class Initialized
DEBUG - 2016-05-23 19:57:21 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 19:57:21 --> Config Class Initialized
INFO - 2016-05-23 19:57:21 --> Hooks Class Initialized
DEBUG - 2016-05-23 19:57:21 --> UTF-8 Support Enabled
INFO - 2016-05-23 19:57:21 --> Utf8 Class Initialized
INFO - 2016-05-23 19:57:21 --> URI Class Initialized
INFO - 2016-05-23 19:57:21 --> Router Class Initialized
INFO - 2016-05-23 19:57:21 --> Output Class Initialized
INFO - 2016-05-23 19:57:21 --> Security Class Initialized
DEBUG - 2016-05-23 19:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 19:57:21 --> Input Class Initialized
INFO - 2016-05-23 19:57:21 --> Language Class Initialized
INFO - 2016-05-23 19:57:21 --> Loader Class Initialized
INFO - 2016-05-23 19:57:21 --> Helper loaded: url_helper
INFO - 2016-05-23 19:57:21 --> Helper loaded: sesion_helper
INFO - 2016-05-23 19:57:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 19:57:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 19:57:21 --> Helper loaded: redondear_helper
INFO - 2016-05-23 19:57:21 --> Helper loaded: form_helper
INFO - 2016-05-23 19:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 19:57:21 --> Form Validation Class Initialized
INFO - 2016-05-23 19:57:21 --> Controller Class Initialized
INFO - 2016-05-23 19:57:21 --> Model Class Initialized
INFO - 2016-05-23 19:57:22 --> Database Driver Class Initialized
INFO - 2016-05-23 19:57:22 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_login.php
INFO - 2016-05-23 19:57:22 --> Final output sent to browser
DEBUG - 2016-05-23 19:57:22 --> Total execution time: 0.0464
INFO - 2016-05-23 19:57:38 --> Config Class Initialized
INFO - 2016-05-23 19:57:38 --> Hooks Class Initialized
DEBUG - 2016-05-23 19:57:38 --> UTF-8 Support Enabled
INFO - 2016-05-23 19:57:38 --> Utf8 Class Initialized
INFO - 2016-05-23 19:57:38 --> URI Class Initialized
INFO - 2016-05-23 19:57:38 --> Router Class Initialized
INFO - 2016-05-23 19:57:38 --> Output Class Initialized
INFO - 2016-05-23 19:57:38 --> Security Class Initialized
DEBUG - 2016-05-23 19:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 19:57:38 --> Input Class Initialized
INFO - 2016-05-23 19:57:38 --> Language Class Initialized
INFO - 2016-05-23 19:57:38 --> Loader Class Initialized
INFO - 2016-05-23 19:57:38 --> Helper loaded: url_helper
INFO - 2016-05-23 19:57:38 --> Helper loaded: sesion_helper
INFO - 2016-05-23 19:57:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 19:57:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 19:57:38 --> Helper loaded: redondear_helper
INFO - 2016-05-23 19:57:38 --> Helper loaded: form_helper
INFO - 2016-05-23 19:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 19:57:38 --> Form Validation Class Initialized
INFO - 2016-05-23 19:57:38 --> Controller Class Initialized
INFO - 2016-05-23 19:57:38 --> Model Class Initialized
INFO - 2016-05-23 19:57:38 --> Database Driver Class Initialized
INFO - 2016-05-23 19:57:38 --> Email Class Initialized
INFO - 2016-05-23 19:57:38 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_pideClaveRestablecer.php
INFO - 2016-05-23 19:57:38 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_template2.php
INFO - 2016-05-23 19:57:38 --> Final output sent to browser
DEBUG - 2016-05-23 19:57:38 --> Total execution time: 0.0550
INFO - 2016-05-23 19:57:39 --> Config Class Initialized
INFO - 2016-05-23 19:57:39 --> Hooks Class Initialized
DEBUG - 2016-05-23 19:57:39 --> UTF-8 Support Enabled
INFO - 2016-05-23 19:57:39 --> Utf8 Class Initialized
INFO - 2016-05-23 19:57:39 --> URI Class Initialized
INFO - 2016-05-23 19:57:39 --> Router Class Initialized
INFO - 2016-05-23 19:57:39 --> Output Class Initialized
INFO - 2016-05-23 19:57:39 --> Security Class Initialized
DEBUG - 2016-05-23 19:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 19:57:39 --> Input Class Initialized
INFO - 2016-05-23 19:57:39 --> Language Class Initialized
INFO - 2016-05-23 19:57:39 --> Loader Class Initialized
INFO - 2016-05-23 19:57:39 --> Helper loaded: url_helper
INFO - 2016-05-23 19:57:39 --> Helper loaded: sesion_helper
INFO - 2016-05-23 19:57:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 19:57:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 19:57:39 --> Helper loaded: redondear_helper
INFO - 2016-05-23 19:57:39 --> Helper loaded: form_helper
INFO - 2016-05-23 19:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 19:57:39 --> Form Validation Class Initialized
INFO - 2016-05-23 19:57:39 --> Controller Class Initialized
INFO - 2016-05-23 19:57:39 --> Model Class Initialized
INFO - 2016-05-23 19:57:39 --> Database Driver Class Initialized
INFO - 2016-05-23 19:57:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 19:57:39 --> Pagination Class Initialized
DEBUG - 2016-05-23 19:57:39 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 19:57:39 --> Config Class Initialized
INFO - 2016-05-23 19:57:39 --> Hooks Class Initialized
DEBUG - 2016-05-23 19:57:39 --> UTF-8 Support Enabled
INFO - 2016-05-23 19:57:39 --> Utf8 Class Initialized
INFO - 2016-05-23 19:57:39 --> URI Class Initialized
INFO - 2016-05-23 19:57:39 --> Router Class Initialized
INFO - 2016-05-23 19:57:39 --> Output Class Initialized
INFO - 2016-05-23 19:57:39 --> Security Class Initialized
DEBUG - 2016-05-23 19:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 19:57:39 --> Input Class Initialized
INFO - 2016-05-23 19:57:39 --> Language Class Initialized
INFO - 2016-05-23 19:57:39 --> Loader Class Initialized
INFO - 2016-05-23 19:57:39 --> Helper loaded: url_helper
INFO - 2016-05-23 19:57:39 --> Helper loaded: sesion_helper
INFO - 2016-05-23 19:57:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 19:57:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 19:57:39 --> Helper loaded: redondear_helper
INFO - 2016-05-23 19:57:39 --> Helper loaded: form_helper
INFO - 2016-05-23 19:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 19:57:39 --> Form Validation Class Initialized
INFO - 2016-05-23 19:57:39 --> Controller Class Initialized
INFO - 2016-05-23 19:57:39 --> Model Class Initialized
INFO - 2016-05-23 19:57:39 --> Database Driver Class Initialized
INFO - 2016-05-23 19:57:39 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/adm_login.php
INFO - 2016-05-23 19:57:39 --> Final output sent to browser
DEBUG - 2016-05-23 19:57:39 --> Total execution time: 0.0455
INFO - 2016-05-23 20:00:48 --> Config Class Initialized
INFO - 2016-05-23 20:00:48 --> Hooks Class Initialized
DEBUG - 2016-05-23 20:00:48 --> UTF-8 Support Enabled
INFO - 2016-05-23 20:00:48 --> Utf8 Class Initialized
INFO - 2016-05-23 20:00:48 --> URI Class Initialized
DEBUG - 2016-05-23 20:00:48 --> No URI present. Default controller set.
INFO - 2016-05-23 20:00:48 --> Router Class Initialized
INFO - 2016-05-23 20:00:48 --> Output Class Initialized
INFO - 2016-05-23 20:00:48 --> Security Class Initialized
DEBUG - 2016-05-23 20:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 20:00:48 --> Input Class Initialized
INFO - 2016-05-23 20:00:48 --> Language Class Initialized
INFO - 2016-05-23 20:00:48 --> Loader Class Initialized
INFO - 2016-05-23 20:00:48 --> Helper loaded: url_helper
INFO - 2016-05-23 20:00:48 --> Helper loaded: sesion_helper
INFO - 2016-05-23 20:00:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 20:00:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 20:00:48 --> Helper loaded: redondear_helper
INFO - 2016-05-23 20:00:49 --> Helper loaded: form_helper
INFO - 2016-05-23 20:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 20:00:49 --> Form Validation Class Initialized
INFO - 2016-05-23 20:00:49 --> Controller Class Initialized
INFO - 2016-05-23 20:00:49 --> Model Class Initialized
INFO - 2016-05-23 20:00:49 --> Database Driver Class Initialized
INFO - 2016-05-23 20:00:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 20:00:49 --> Pagination Class Initialized
DEBUG - 2016-05-23 20:00:49 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 20:00:49 --> Config Class Initialized
INFO - 2016-05-23 20:00:49 --> Hooks Class Initialized
DEBUG - 2016-05-23 20:00:49 --> UTF-8 Support Enabled
INFO - 2016-05-23 20:00:49 --> Utf8 Class Initialized
INFO - 2016-05-23 20:00:49 --> URI Class Initialized
INFO - 2016-05-23 20:00:49 --> Router Class Initialized
INFO - 2016-05-23 20:00:49 --> Output Class Initialized
INFO - 2016-05-23 20:00:49 --> Security Class Initialized
DEBUG - 2016-05-23 20:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 20:00:49 --> Input Class Initialized
INFO - 2016-05-23 20:00:49 --> Language Class Initialized
INFO - 2016-05-23 20:00:49 --> Loader Class Initialized
INFO - 2016-05-23 20:00:49 --> Helper loaded: url_helper
INFO - 2016-05-23 20:00:49 --> Helper loaded: sesion_helper
INFO - 2016-05-23 20:00:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 20:00:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 20:00:49 --> Helper loaded: redondear_helper
INFO - 2016-05-23 20:00:49 --> Helper loaded: form_helper
INFO - 2016-05-23 20:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 20:00:49 --> Form Validation Class Initialized
INFO - 2016-05-23 20:00:49 --> Controller Class Initialized
INFO - 2016-05-23 20:00:49 --> Model Class Initialized
INFO - 2016-05-23 20:00:49 --> Database Driver Class Initialized
INFO - 2016-05-23 20:00:49 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_login.php
INFO - 2016-05-23 20:00:49 --> Final output sent to browser
DEBUG - 2016-05-23 20:00:49 --> Total execution time: 0.0580
INFO - 2016-05-23 20:01:02 --> Config Class Initialized
INFO - 2016-05-23 20:01:02 --> Hooks Class Initialized
DEBUG - 2016-05-23 20:01:02 --> UTF-8 Support Enabled
INFO - 2016-05-23 20:01:02 --> Utf8 Class Initialized
INFO - 2016-05-23 20:01:02 --> URI Class Initialized
DEBUG - 2016-05-23 20:01:02 --> No URI present. Default controller set.
INFO - 2016-05-23 20:01:02 --> Router Class Initialized
INFO - 2016-05-23 20:01:02 --> Output Class Initialized
INFO - 2016-05-23 20:01:02 --> Security Class Initialized
DEBUG - 2016-05-23 20:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 20:01:02 --> Input Class Initialized
INFO - 2016-05-23 20:01:02 --> Language Class Initialized
INFO - 2016-05-23 20:01:02 --> Loader Class Initialized
INFO - 2016-05-23 20:01:02 --> Helper loaded: url_helper
INFO - 2016-05-23 20:01:02 --> Helper loaded: sesion_helper
INFO - 2016-05-23 20:01:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 20:01:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 20:01:02 --> Helper loaded: redondear_helper
INFO - 2016-05-23 20:01:02 --> Helper loaded: form_helper
INFO - 2016-05-23 20:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 20:01:02 --> Form Validation Class Initialized
INFO - 2016-05-23 20:01:02 --> Controller Class Initialized
INFO - 2016-05-23 20:01:02 --> Model Class Initialized
INFO - 2016-05-23 20:01:02 --> Database Driver Class Initialized
INFO - 2016-05-23 20:01:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 20:01:02 --> Pagination Class Initialized
DEBUG - 2016-05-23 20:01:02 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 20:01:02 --> Config Class Initialized
INFO - 2016-05-23 20:01:02 --> Hooks Class Initialized
DEBUG - 2016-05-23 20:01:02 --> UTF-8 Support Enabled
INFO - 2016-05-23 20:01:02 --> Utf8 Class Initialized
INFO - 2016-05-23 20:01:02 --> URI Class Initialized
INFO - 2016-05-23 20:01:02 --> Router Class Initialized
INFO - 2016-05-23 20:01:02 --> Output Class Initialized
INFO - 2016-05-23 20:01:02 --> Security Class Initialized
DEBUG - 2016-05-23 20:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 20:01:02 --> Input Class Initialized
INFO - 2016-05-23 20:01:02 --> Language Class Initialized
INFO - 2016-05-23 20:01:02 --> Loader Class Initialized
INFO - 2016-05-23 20:01:02 --> Helper loaded: url_helper
INFO - 2016-05-23 20:01:02 --> Helper loaded: sesion_helper
INFO - 2016-05-23 20:01:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 20:01:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 20:01:02 --> Helper loaded: redondear_helper
INFO - 2016-05-23 20:01:02 --> Helper loaded: form_helper
INFO - 2016-05-23 20:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 20:01:02 --> Form Validation Class Initialized
INFO - 2016-05-23 20:01:02 --> Controller Class Initialized
INFO - 2016-05-23 20:01:02 --> Model Class Initialized
INFO - 2016-05-23 20:01:02 --> Database Driver Class Initialized
INFO - 2016-05-23 20:01:02 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_login.php
INFO - 2016-05-23 20:01:02 --> Final output sent to browser
DEBUG - 2016-05-23 20:01:02 --> Total execution time: 0.0455
INFO - 2016-05-23 23:25:26 --> Config Class Initialized
INFO - 2016-05-23 23:25:26 --> Hooks Class Initialized
DEBUG - 2016-05-23 23:25:26 --> UTF-8 Support Enabled
INFO - 2016-05-23 23:25:26 --> Utf8 Class Initialized
INFO - 2016-05-23 23:25:26 --> URI Class Initialized
DEBUG - 2016-05-23 23:25:26 --> No URI present. Default controller set.
INFO - 2016-05-23 23:25:26 --> Router Class Initialized
INFO - 2016-05-23 23:25:26 --> Output Class Initialized
INFO - 2016-05-23 23:25:26 --> Security Class Initialized
DEBUG - 2016-05-23 23:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 23:25:26 --> Input Class Initialized
INFO - 2016-05-23 23:25:26 --> Language Class Initialized
INFO - 2016-05-23 23:25:27 --> Loader Class Initialized
INFO - 2016-05-23 23:25:27 --> Helper loaded: url_helper
INFO - 2016-05-23 23:25:27 --> Helper loaded: sesion_helper
INFO - 2016-05-23 23:25:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 23:25:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 23:25:27 --> Helper loaded: redondear_helper
INFO - 2016-05-23 23:25:27 --> Helper loaded: form_helper
INFO - 2016-05-23 23:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 23:25:27 --> Form Validation Class Initialized
INFO - 2016-05-23 23:25:27 --> Controller Class Initialized
INFO - 2016-05-23 23:25:27 --> Model Class Initialized
INFO - 2016-05-23 23:25:27 --> Database Driver Class Initialized
INFO - 2016-05-23 23:25:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-23 23:25:27 --> Pagination Class Initialized
DEBUG - 2016-05-23 23:25:27 --> Config file loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/config/paginacion.php
INFO - 2016-05-23 23:25:27 --> Config Class Initialized
INFO - 2016-05-23 23:25:27 --> Hooks Class Initialized
DEBUG - 2016-05-23 23:25:27 --> UTF-8 Support Enabled
INFO - 2016-05-23 23:25:27 --> Utf8 Class Initialized
INFO - 2016-05-23 23:25:27 --> URI Class Initialized
INFO - 2016-05-23 23:25:27 --> Router Class Initialized
INFO - 2016-05-23 23:25:27 --> Output Class Initialized
INFO - 2016-05-23 23:25:27 --> Security Class Initialized
DEBUG - 2016-05-23 23:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 23:25:27 --> Input Class Initialized
INFO - 2016-05-23 23:25:27 --> Language Class Initialized
INFO - 2016-05-23 23:25:27 --> Loader Class Initialized
INFO - 2016-05-23 23:25:27 --> Helper loaded: url_helper
INFO - 2016-05-23 23:25:27 --> Helper loaded: sesion_helper
INFO - 2016-05-23 23:25:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-23 23:25:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-23 23:25:27 --> Helper loaded: redondear_helper
INFO - 2016-05-23 23:25:27 --> Helper loaded: form_helper
INFO - 2016-05-23 23:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-23 23:25:27 --> Form Validation Class Initialized
INFO - 2016-05-23 23:25:27 --> Controller Class Initialized
INFO - 2016-05-23 23:25:27 --> Model Class Initialized
INFO - 2016-05-23 23:25:27 --> Database Driver Class Initialized
INFO - 2016-05-23 23:25:27 --> File loaded: /var/www/ftp_users/2daw1516/c8cfe05582d0f20174c59e0bec21cf61af151648/web/application/views/ven_login.php
INFO - 2016-05-23 23:25:27 --> Final output sent to browser
DEBUG - 2016-05-23 23:25:27 --> Total execution time: 0.0614
