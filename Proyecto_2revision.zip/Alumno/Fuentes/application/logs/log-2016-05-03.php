<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-03 18:18:16 --> Config Class Initialized
INFO - 2016-05-03 18:18:16 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:18:16 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:18:16 --> Utf8 Class Initialized
INFO - 2016-05-03 18:18:16 --> URI Class Initialized
INFO - 2016-05-03 18:18:16 --> Router Class Initialized
INFO - 2016-05-03 18:18:16 --> Output Class Initialized
INFO - 2016-05-03 18:18:16 --> Security Class Initialized
DEBUG - 2016-05-03 18:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:18:16 --> Input Class Initialized
INFO - 2016-05-03 18:18:16 --> Language Class Initialized
INFO - 2016-05-03 18:18:16 --> Loader Class Initialized
INFO - 2016-05-03 18:18:16 --> Helper loaded: url_helper
INFO - 2016-05-03 18:18:16 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:18:16 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:18:16 --> Helper loaded: form_helper
INFO - 2016-05-03 18:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:18:16 --> Form Validation Class Initialized
INFO - 2016-05-03 18:18:16 --> Controller Class Initialized
INFO - 2016-05-03 18:18:17 --> Config Class Initialized
INFO - 2016-05-03 18:18:17 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:18:17 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:18:17 --> Utf8 Class Initialized
INFO - 2016-05-03 18:18:17 --> URI Class Initialized
INFO - 2016-05-03 18:18:17 --> Router Class Initialized
INFO - 2016-05-03 18:18:17 --> Output Class Initialized
INFO - 2016-05-03 18:18:17 --> Security Class Initialized
DEBUG - 2016-05-03 18:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:18:17 --> Input Class Initialized
INFO - 2016-05-03 18:18:17 --> Language Class Initialized
INFO - 2016-05-03 18:18:17 --> Loader Class Initialized
INFO - 2016-05-03 18:18:17 --> Helper loaded: url_helper
INFO - 2016-05-03 18:18:17 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:18:17 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:18:17 --> Helper loaded: form_helper
INFO - 2016-05-03 18:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:18:17 --> Form Validation Class Initialized
INFO - 2016-05-03 18:18:17 --> Controller Class Initialized
INFO - 2016-05-03 18:18:17 --> Model Class Initialized
INFO - 2016-05-03 18:18:17 --> Database Driver Class Initialized
INFO - 2016-05-03 18:18:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-03 18:18:17 --> Final output sent to browser
DEBUG - 2016-05-03 18:18:17 --> Total execution time: 0.1214
INFO - 2016-05-03 18:19:04 --> Config Class Initialized
INFO - 2016-05-03 18:19:04 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:19:04 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:19:04 --> Utf8 Class Initialized
INFO - 2016-05-03 18:19:04 --> URI Class Initialized
INFO - 2016-05-03 18:19:04 --> Router Class Initialized
INFO - 2016-05-03 18:19:04 --> Output Class Initialized
INFO - 2016-05-03 18:19:04 --> Security Class Initialized
DEBUG - 2016-05-03 18:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:19:04 --> Input Class Initialized
INFO - 2016-05-03 18:19:04 --> Language Class Initialized
INFO - 2016-05-03 18:19:04 --> Loader Class Initialized
INFO - 2016-05-03 18:19:04 --> Helper loaded: url_helper
INFO - 2016-05-03 18:19:04 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:19:04 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:19:04 --> Helper loaded: form_helper
INFO - 2016-05-03 18:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:19:04 --> Form Validation Class Initialized
INFO - 2016-05-03 18:19:04 --> Controller Class Initialized
INFO - 2016-05-03 18:19:04 --> Model Class Initialized
INFO - 2016-05-03 18:19:04 --> Database Driver Class Initialized
INFO - 2016-05-03 18:19:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-03 18:19:04 --> Final output sent to browser
DEBUG - 2016-05-03 18:19:04 --> Total execution time: 0.3016
INFO - 2016-05-03 18:19:09 --> Config Class Initialized
INFO - 2016-05-03 18:19:09 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:19:09 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:19:09 --> Utf8 Class Initialized
INFO - 2016-05-03 18:19:09 --> URI Class Initialized
INFO - 2016-05-03 18:19:09 --> Router Class Initialized
INFO - 2016-05-03 18:19:09 --> Output Class Initialized
INFO - 2016-05-03 18:19:09 --> Security Class Initialized
DEBUG - 2016-05-03 18:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:19:09 --> Input Class Initialized
INFO - 2016-05-03 18:19:09 --> Language Class Initialized
INFO - 2016-05-03 18:19:09 --> Loader Class Initialized
INFO - 2016-05-03 18:19:09 --> Helper loaded: url_helper
INFO - 2016-05-03 18:19:09 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:19:09 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:19:09 --> Helper loaded: form_helper
INFO - 2016-05-03 18:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:19:09 --> Form Validation Class Initialized
INFO - 2016-05-03 18:19:09 --> Controller Class Initialized
INFO - 2016-05-03 18:19:09 --> Model Class Initialized
INFO - 2016-05-03 18:19:09 --> Database Driver Class Initialized
INFO - 2016-05-03 18:19:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-03 18:19:09 --> Final output sent to browser
DEBUG - 2016-05-03 18:19:09 --> Total execution time: 0.0697
INFO - 2016-05-03 18:19:15 --> Config Class Initialized
INFO - 2016-05-03 18:19:15 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:19:15 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:19:15 --> Utf8 Class Initialized
INFO - 2016-05-03 18:19:15 --> URI Class Initialized
INFO - 2016-05-03 18:19:15 --> Router Class Initialized
INFO - 2016-05-03 18:19:15 --> Output Class Initialized
INFO - 2016-05-03 18:19:15 --> Security Class Initialized
DEBUG - 2016-05-03 18:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:19:15 --> Input Class Initialized
INFO - 2016-05-03 18:19:15 --> Language Class Initialized
INFO - 2016-05-03 18:19:15 --> Loader Class Initialized
INFO - 2016-05-03 18:19:15 --> Helper loaded: url_helper
INFO - 2016-05-03 18:19:15 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:19:15 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:19:15 --> Helper loaded: form_helper
INFO - 2016-05-03 18:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:19:15 --> Form Validation Class Initialized
INFO - 2016-05-03 18:19:15 --> Controller Class Initialized
INFO - 2016-05-03 18:19:15 --> Model Class Initialized
INFO - 2016-05-03 18:19:15 --> Database Driver Class Initialized
INFO - 2016-05-03 18:19:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-03 18:19:15 --> Final output sent to browser
DEBUG - 2016-05-03 18:19:15 --> Total execution time: 0.0859
INFO - 2016-05-03 18:19:20 --> Config Class Initialized
INFO - 2016-05-03 18:19:20 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:19:20 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:19:20 --> Utf8 Class Initialized
INFO - 2016-05-03 18:19:20 --> URI Class Initialized
INFO - 2016-05-03 18:19:20 --> Router Class Initialized
INFO - 2016-05-03 18:19:20 --> Output Class Initialized
INFO - 2016-05-03 18:19:20 --> Security Class Initialized
DEBUG - 2016-05-03 18:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:19:20 --> Input Class Initialized
INFO - 2016-05-03 18:19:20 --> Language Class Initialized
INFO - 2016-05-03 18:19:20 --> Loader Class Initialized
INFO - 2016-05-03 18:19:20 --> Helper loaded: url_helper
INFO - 2016-05-03 18:19:20 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:19:20 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:19:20 --> Helper loaded: form_helper
INFO - 2016-05-03 18:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:19:20 --> Form Validation Class Initialized
INFO - 2016-05-03 18:19:20 --> Controller Class Initialized
INFO - 2016-05-03 18:19:20 --> Model Class Initialized
INFO - 2016-05-03 18:19:20 --> Database Driver Class Initialized
INFO - 2016-05-03 18:19:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-03 18:19:20 --> Final output sent to browser
DEBUG - 2016-05-03 18:19:20 --> Total execution time: 0.0669
INFO - 2016-05-03 18:19:29 --> Config Class Initialized
INFO - 2016-05-03 18:19:29 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:19:29 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:19:29 --> Utf8 Class Initialized
INFO - 2016-05-03 18:19:29 --> URI Class Initialized
INFO - 2016-05-03 18:19:29 --> Router Class Initialized
INFO - 2016-05-03 18:19:29 --> Output Class Initialized
INFO - 2016-05-03 18:19:29 --> Security Class Initialized
DEBUG - 2016-05-03 18:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:19:29 --> Input Class Initialized
INFO - 2016-05-03 18:19:29 --> Language Class Initialized
INFO - 2016-05-03 18:19:29 --> Loader Class Initialized
INFO - 2016-05-03 18:19:29 --> Helper loaded: url_helper
INFO - 2016-05-03 18:19:29 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:19:29 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:19:29 --> Helper loaded: form_helper
INFO - 2016-05-03 18:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:19:29 --> Form Validation Class Initialized
INFO - 2016-05-03 18:19:29 --> Controller Class Initialized
INFO - 2016-05-03 18:19:29 --> Model Class Initialized
INFO - 2016-05-03 18:19:29 --> Database Driver Class Initialized
INFO - 2016-05-03 18:19:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-03 18:19:29 --> Final output sent to browser
DEBUG - 2016-05-03 18:19:29 --> Total execution time: 0.0659
INFO - 2016-05-03 18:19:31 --> Config Class Initialized
INFO - 2016-05-03 18:19:31 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:19:31 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:19:31 --> Utf8 Class Initialized
INFO - 2016-05-03 18:19:31 --> URI Class Initialized
INFO - 2016-05-03 18:19:31 --> Router Class Initialized
INFO - 2016-05-03 18:19:31 --> Output Class Initialized
INFO - 2016-05-03 18:19:31 --> Security Class Initialized
DEBUG - 2016-05-03 18:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:19:31 --> Input Class Initialized
INFO - 2016-05-03 18:19:31 --> Language Class Initialized
INFO - 2016-05-03 18:19:31 --> Loader Class Initialized
INFO - 2016-05-03 18:19:31 --> Helper loaded: url_helper
INFO - 2016-05-03 18:19:31 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:19:31 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:19:31 --> Helper loaded: form_helper
INFO - 2016-05-03 18:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:19:31 --> Form Validation Class Initialized
INFO - 2016-05-03 18:19:31 --> Controller Class Initialized
INFO - 2016-05-03 18:19:31 --> Config Class Initialized
INFO - 2016-05-03 18:19:31 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:19:31 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:19:31 --> Utf8 Class Initialized
INFO - 2016-05-03 18:19:31 --> URI Class Initialized
INFO - 2016-05-03 18:19:31 --> Router Class Initialized
INFO - 2016-05-03 18:19:31 --> Output Class Initialized
INFO - 2016-05-03 18:19:31 --> Security Class Initialized
DEBUG - 2016-05-03 18:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:19:31 --> Input Class Initialized
INFO - 2016-05-03 18:19:31 --> Language Class Initialized
INFO - 2016-05-03 18:19:31 --> Loader Class Initialized
INFO - 2016-05-03 18:19:31 --> Helper loaded: url_helper
INFO - 2016-05-03 18:19:31 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:19:31 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:19:31 --> Helper loaded: form_helper
INFO - 2016-05-03 18:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:19:31 --> Form Validation Class Initialized
INFO - 2016-05-03 18:19:31 --> Controller Class Initialized
INFO - 2016-05-03 18:19:31 --> Model Class Initialized
INFO - 2016-05-03 18:19:31 --> Database Driver Class Initialized
INFO - 2016-05-03 18:19:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-03 18:19:31 --> Final output sent to browser
DEBUG - 2016-05-03 18:19:31 --> Total execution time: 0.0657
INFO - 2016-05-03 18:20:31 --> Config Class Initialized
INFO - 2016-05-03 18:20:31 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:20:31 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:20:31 --> Utf8 Class Initialized
INFO - 2016-05-03 18:20:31 --> URI Class Initialized
INFO - 2016-05-03 18:20:31 --> Router Class Initialized
INFO - 2016-05-03 18:20:31 --> Output Class Initialized
INFO - 2016-05-03 18:20:31 --> Security Class Initialized
DEBUG - 2016-05-03 18:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:20:31 --> Input Class Initialized
INFO - 2016-05-03 18:20:31 --> Language Class Initialized
INFO - 2016-05-03 18:20:31 --> Loader Class Initialized
INFO - 2016-05-03 18:20:31 --> Helper loaded: url_helper
INFO - 2016-05-03 18:20:31 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:20:31 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:20:31 --> Helper loaded: form_helper
INFO - 2016-05-03 18:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:20:31 --> Form Validation Class Initialized
INFO - 2016-05-03 18:20:31 --> Controller Class Initialized
INFO - 2016-05-03 18:20:31 --> Model Class Initialized
INFO - 2016-05-03 18:20:31 --> Database Driver Class Initialized
INFO - 2016-05-03 18:20:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-03 18:20:31 --> Final output sent to browser
DEBUG - 2016-05-03 18:20:31 --> Total execution time: 0.0706
INFO - 2016-05-03 18:20:38 --> Config Class Initialized
INFO - 2016-05-03 18:20:38 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:20:38 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:20:38 --> Utf8 Class Initialized
INFO - 2016-05-03 18:20:38 --> URI Class Initialized
INFO - 2016-05-03 18:20:38 --> Router Class Initialized
INFO - 2016-05-03 18:20:38 --> Output Class Initialized
INFO - 2016-05-03 18:20:38 --> Security Class Initialized
DEBUG - 2016-05-03 18:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:20:38 --> Input Class Initialized
INFO - 2016-05-03 18:20:38 --> Language Class Initialized
INFO - 2016-05-03 18:20:38 --> Loader Class Initialized
INFO - 2016-05-03 18:20:38 --> Helper loaded: url_helper
INFO - 2016-05-03 18:20:38 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:20:38 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:20:38 --> Helper loaded: form_helper
INFO - 2016-05-03 18:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:20:38 --> Form Validation Class Initialized
INFO - 2016-05-03 18:20:38 --> Controller Class Initialized
INFO - 2016-05-03 18:20:38 --> Model Class Initialized
INFO - 2016-05-03 18:20:38 --> Database Driver Class Initialized
INFO - 2016-05-03 18:20:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-03 18:20:38 --> Final output sent to browser
DEBUG - 2016-05-03 18:20:38 --> Total execution time: 0.0662
INFO - 2016-05-03 18:20:52 --> Config Class Initialized
INFO - 2016-05-03 18:20:52 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:20:52 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:20:52 --> Utf8 Class Initialized
INFO - 2016-05-03 18:20:52 --> URI Class Initialized
INFO - 2016-05-03 18:20:52 --> Router Class Initialized
INFO - 2016-05-03 18:20:52 --> Output Class Initialized
INFO - 2016-05-03 18:20:52 --> Security Class Initialized
DEBUG - 2016-05-03 18:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:20:52 --> Input Class Initialized
INFO - 2016-05-03 18:20:52 --> Language Class Initialized
INFO - 2016-05-03 18:20:52 --> Loader Class Initialized
INFO - 2016-05-03 18:20:52 --> Helper loaded: url_helper
INFO - 2016-05-03 18:20:52 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:20:52 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:20:52 --> Helper loaded: form_helper
INFO - 2016-05-03 18:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:20:52 --> Form Validation Class Initialized
INFO - 2016-05-03 18:20:52 --> Controller Class Initialized
INFO - 2016-05-03 18:20:52 --> Model Class Initialized
INFO - 2016-05-03 18:20:52 --> Database Driver Class Initialized
INFO - 2016-05-03 18:20:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-03 18:20:52 --> Final output sent to browser
DEBUG - 2016-05-03 18:20:52 --> Total execution time: 0.0777
INFO - 2016-05-03 18:20:56 --> Config Class Initialized
INFO - 2016-05-03 18:20:56 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:20:56 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:20:56 --> Utf8 Class Initialized
INFO - 2016-05-03 18:20:56 --> URI Class Initialized
INFO - 2016-05-03 18:20:56 --> Router Class Initialized
INFO - 2016-05-03 18:20:56 --> Output Class Initialized
INFO - 2016-05-03 18:20:56 --> Security Class Initialized
DEBUG - 2016-05-03 18:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:20:56 --> Input Class Initialized
INFO - 2016-05-03 18:20:56 --> Language Class Initialized
INFO - 2016-05-03 18:20:56 --> Loader Class Initialized
INFO - 2016-05-03 18:20:56 --> Helper loaded: url_helper
INFO - 2016-05-03 18:20:56 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:20:56 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:20:56 --> Helper loaded: form_helper
INFO - 2016-05-03 18:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:20:56 --> Form Validation Class Initialized
INFO - 2016-05-03 18:20:56 --> Controller Class Initialized
INFO - 2016-05-03 18:20:56 --> Model Class Initialized
INFO - 2016-05-03 18:20:56 --> Database Driver Class Initialized
INFO - 2016-05-03 18:20:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-03 18:20:56 --> Final output sent to browser
DEBUG - 2016-05-03 18:20:56 --> Total execution time: 0.0745
INFO - 2016-05-03 18:21:13 --> Config Class Initialized
INFO - 2016-05-03 18:21:13 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:21:13 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:21:13 --> Utf8 Class Initialized
INFO - 2016-05-03 18:21:13 --> URI Class Initialized
INFO - 2016-05-03 18:21:13 --> Router Class Initialized
INFO - 2016-05-03 18:21:13 --> Output Class Initialized
INFO - 2016-05-03 18:21:13 --> Security Class Initialized
DEBUG - 2016-05-03 18:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:21:13 --> Input Class Initialized
INFO - 2016-05-03 18:21:13 --> Language Class Initialized
INFO - 2016-05-03 18:21:14 --> Loader Class Initialized
INFO - 2016-05-03 18:21:14 --> Helper loaded: url_helper
INFO - 2016-05-03 18:21:14 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:21:14 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:21:14 --> Helper loaded: form_helper
INFO - 2016-05-03 18:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:21:14 --> Form Validation Class Initialized
INFO - 2016-05-03 18:21:14 --> Controller Class Initialized
INFO - 2016-05-03 18:21:14 --> Model Class Initialized
INFO - 2016-05-03 18:21:14 --> Database Driver Class Initialized
INFO - 2016-05-03 18:21:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-03 18:21:14 --> Final output sent to browser
DEBUG - 2016-05-03 18:21:14 --> Total execution time: 0.0675
INFO - 2016-05-03 18:23:55 --> Config Class Initialized
INFO - 2016-05-03 18:23:55 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:23:55 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:23:55 --> Utf8 Class Initialized
INFO - 2016-05-03 18:23:55 --> URI Class Initialized
INFO - 2016-05-03 18:23:55 --> Router Class Initialized
INFO - 2016-05-03 18:23:55 --> Output Class Initialized
INFO - 2016-05-03 18:23:55 --> Security Class Initialized
DEBUG - 2016-05-03 18:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:23:55 --> Input Class Initialized
INFO - 2016-05-03 18:23:55 --> Language Class Initialized
INFO - 2016-05-03 18:23:55 --> Loader Class Initialized
INFO - 2016-05-03 18:23:55 --> Helper loaded: url_helper
INFO - 2016-05-03 18:23:55 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:23:55 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:23:55 --> Helper loaded: form_helper
INFO - 2016-05-03 18:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:23:55 --> Form Validation Class Initialized
INFO - 2016-05-03 18:23:55 --> Controller Class Initialized
INFO - 2016-05-03 18:23:55 --> Model Class Initialized
INFO - 2016-05-03 18:23:55 --> Database Driver Class Initialized
INFO - 2016-05-03 18:23:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-03 18:23:55 --> Final output sent to browser
DEBUG - 2016-05-03 18:23:55 --> Total execution time: 0.2215
INFO - 2016-05-03 18:24:06 --> Config Class Initialized
INFO - 2016-05-03 18:24:06 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:24:06 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:24:06 --> Utf8 Class Initialized
INFO - 2016-05-03 18:24:06 --> URI Class Initialized
INFO - 2016-05-03 18:24:06 --> Router Class Initialized
INFO - 2016-05-03 18:24:06 --> Output Class Initialized
INFO - 2016-05-03 18:24:06 --> Security Class Initialized
DEBUG - 2016-05-03 18:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:24:06 --> Input Class Initialized
INFO - 2016-05-03 18:24:06 --> Language Class Initialized
INFO - 2016-05-03 18:24:06 --> Loader Class Initialized
INFO - 2016-05-03 18:24:06 --> Helper loaded: url_helper
INFO - 2016-05-03 18:24:06 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:24:06 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:24:06 --> Helper loaded: form_helper
INFO - 2016-05-03 18:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:24:06 --> Form Validation Class Initialized
INFO - 2016-05-03 18:24:06 --> Controller Class Initialized
INFO - 2016-05-03 18:24:06 --> Model Class Initialized
INFO - 2016-05-03 18:24:06 --> Database Driver Class Initialized
INFO - 2016-05-03 18:24:06 --> Config Class Initialized
INFO - 2016-05-03 18:24:06 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:24:06 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:24:06 --> Utf8 Class Initialized
INFO - 2016-05-03 18:24:06 --> URI Class Initialized
INFO - 2016-05-03 18:24:06 --> Router Class Initialized
INFO - 2016-05-03 18:24:06 --> Output Class Initialized
INFO - 2016-05-03 18:24:06 --> Security Class Initialized
DEBUG - 2016-05-03 18:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:24:06 --> Input Class Initialized
INFO - 2016-05-03 18:24:06 --> Language Class Initialized
INFO - 2016-05-03 18:24:06 --> Loader Class Initialized
INFO - 2016-05-03 18:24:06 --> Helper loaded: url_helper
INFO - 2016-05-03 18:24:06 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:24:06 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:24:06 --> Helper loaded: form_helper
INFO - 2016-05-03 18:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:24:06 --> Form Validation Class Initialized
INFO - 2016-05-03 18:24:06 --> Controller Class Initialized
INFO - 2016-05-03 18:24:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-03 18:24:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:24:06 --> Final output sent to browser
DEBUG - 2016-05-03 18:24:06 --> Total execution time: 0.0471
INFO - 2016-05-03 18:25:13 --> Config Class Initialized
INFO - 2016-05-03 18:25:13 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:25:13 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:25:13 --> Utf8 Class Initialized
INFO - 2016-05-03 18:25:13 --> URI Class Initialized
INFO - 2016-05-03 18:25:13 --> Router Class Initialized
INFO - 2016-05-03 18:25:13 --> Output Class Initialized
INFO - 2016-05-03 18:25:13 --> Security Class Initialized
DEBUG - 2016-05-03 18:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:25:13 --> Input Class Initialized
INFO - 2016-05-03 18:25:13 --> Language Class Initialized
INFO - 2016-05-03 18:25:13 --> Loader Class Initialized
INFO - 2016-05-03 18:25:13 --> Helper loaded: url_helper
INFO - 2016-05-03 18:25:13 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:25:13 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:25:13 --> Helper loaded: form_helper
INFO - 2016-05-03 18:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:25:13 --> Form Validation Class Initialized
INFO - 2016-05-03 18:25:13 --> Controller Class Initialized
INFO - 2016-05-03 18:25:13 --> Model Class Initialized
INFO - 2016-05-03 18:25:13 --> Database Driver Class Initialized
INFO - 2016-05-03 18:25:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_perfil.php
INFO - 2016-05-03 18:25:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:25:13 --> Final output sent to browser
DEBUG - 2016-05-03 18:25:13 --> Total execution time: 0.0678
INFO - 2016-05-03 18:25:21 --> Config Class Initialized
INFO - 2016-05-03 18:25:21 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:25:21 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:25:21 --> Utf8 Class Initialized
INFO - 2016-05-03 18:25:21 --> URI Class Initialized
INFO - 2016-05-03 18:25:21 --> Router Class Initialized
INFO - 2016-05-03 18:25:21 --> Output Class Initialized
INFO - 2016-05-03 18:25:21 --> Security Class Initialized
DEBUG - 2016-05-03 18:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:25:21 --> Input Class Initialized
INFO - 2016-05-03 18:25:21 --> Language Class Initialized
INFO - 2016-05-03 18:25:21 --> Loader Class Initialized
INFO - 2016-05-03 18:25:21 --> Helper loaded: url_helper
INFO - 2016-05-03 18:25:21 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:25:21 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:25:21 --> Helper loaded: form_helper
INFO - 2016-05-03 18:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:25:21 --> Form Validation Class Initialized
INFO - 2016-05-03 18:25:21 --> Controller Class Initialized
INFO - 2016-05-03 18:25:21 --> Model Class Initialized
INFO - 2016-05-03 18:25:21 --> Database Driver Class Initialized
INFO - 2016-05-03 18:25:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modUser.php
INFO - 2016-05-03 18:25:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:25:21 --> Final output sent to browser
DEBUG - 2016-05-03 18:25:21 --> Total execution time: 0.0916
INFO - 2016-05-03 18:25:22 --> Config Class Initialized
INFO - 2016-05-03 18:25:22 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:25:22 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:25:22 --> Utf8 Class Initialized
INFO - 2016-05-03 18:25:22 --> URI Class Initialized
INFO - 2016-05-03 18:25:22 --> Router Class Initialized
INFO - 2016-05-03 18:25:22 --> Output Class Initialized
INFO - 2016-05-03 18:25:22 --> Security Class Initialized
DEBUG - 2016-05-03 18:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:25:22 --> Input Class Initialized
INFO - 2016-05-03 18:25:22 --> Language Class Initialized
INFO - 2016-05-03 18:25:22 --> Loader Class Initialized
INFO - 2016-05-03 18:25:22 --> Helper loaded: url_helper
INFO - 2016-05-03 18:25:22 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:25:22 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:25:22 --> Helper loaded: form_helper
INFO - 2016-05-03 18:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:25:22 --> Form Validation Class Initialized
INFO - 2016-05-03 18:25:22 --> Controller Class Initialized
INFO - 2016-05-03 18:25:22 --> Model Class Initialized
INFO - 2016-05-03 18:25:22 --> Database Driver Class Initialized
INFO - 2016-05-03 18:25:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_perfil.php
INFO - 2016-05-03 18:25:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:25:22 --> Final output sent to browser
DEBUG - 2016-05-03 18:25:22 --> Total execution time: 0.1496
INFO - 2016-05-03 18:25:24 --> Config Class Initialized
INFO - 2016-05-03 18:25:24 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:25:24 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:25:24 --> Utf8 Class Initialized
INFO - 2016-05-03 18:25:24 --> URI Class Initialized
INFO - 2016-05-03 18:25:24 --> Router Class Initialized
INFO - 2016-05-03 18:25:24 --> Output Class Initialized
INFO - 2016-05-03 18:25:24 --> Security Class Initialized
DEBUG - 2016-05-03 18:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:25:24 --> Input Class Initialized
INFO - 2016-05-03 18:25:24 --> Language Class Initialized
INFO - 2016-05-03 18:25:24 --> Loader Class Initialized
INFO - 2016-05-03 18:25:24 --> Helper loaded: url_helper
INFO - 2016-05-03 18:25:24 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:25:24 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:25:24 --> Helper loaded: form_helper
INFO - 2016-05-03 18:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:25:24 --> Form Validation Class Initialized
INFO - 2016-05-03 18:25:24 --> Controller Class Initialized
INFO - 2016-05-03 18:25:24 --> Model Class Initialized
INFO - 2016-05-03 18:25:24 --> Database Driver Class Initialized
INFO - 2016-05-03 18:25:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarClave.php
INFO - 2016-05-03 18:25:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:25:24 --> Final output sent to browser
DEBUG - 2016-05-03 18:25:24 --> Total execution time: 0.0862
INFO - 2016-05-03 18:25:37 --> Config Class Initialized
INFO - 2016-05-03 18:25:37 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:25:37 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:25:37 --> Utf8 Class Initialized
INFO - 2016-05-03 18:25:37 --> URI Class Initialized
INFO - 2016-05-03 18:25:37 --> Router Class Initialized
INFO - 2016-05-03 18:25:37 --> Output Class Initialized
INFO - 2016-05-03 18:25:37 --> Security Class Initialized
DEBUG - 2016-05-03 18:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:25:37 --> Input Class Initialized
INFO - 2016-05-03 18:25:37 --> Language Class Initialized
INFO - 2016-05-03 18:25:37 --> Loader Class Initialized
INFO - 2016-05-03 18:25:37 --> Helper loaded: url_helper
INFO - 2016-05-03 18:25:37 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:25:37 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:25:37 --> Helper loaded: form_helper
INFO - 2016-05-03 18:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:25:37 --> Form Validation Class Initialized
INFO - 2016-05-03 18:25:37 --> Controller Class Initialized
INFO - 2016-05-03 18:25:37 --> Model Class Initialized
INFO - 2016-05-03 18:25:37 --> Database Driver Class Initialized
INFO - 2016-05-03 18:25:37 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 18:25:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_cambiarClave.php
INFO - 2016-05-03 18:25:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:25:37 --> Final output sent to browser
DEBUG - 2016-05-03 18:25:37 --> Total execution time: 0.4931
INFO - 2016-05-03 18:26:17 --> Config Class Initialized
INFO - 2016-05-03 18:26:17 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:26:17 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:26:17 --> Utf8 Class Initialized
INFO - 2016-05-03 18:26:17 --> URI Class Initialized
INFO - 2016-05-03 18:26:17 --> Router Class Initialized
INFO - 2016-05-03 18:26:17 --> Output Class Initialized
INFO - 2016-05-03 18:26:17 --> Security Class Initialized
DEBUG - 2016-05-03 18:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:26:17 --> Input Class Initialized
INFO - 2016-05-03 18:26:17 --> Language Class Initialized
INFO - 2016-05-03 18:26:17 --> Loader Class Initialized
INFO - 2016-05-03 18:26:17 --> Helper loaded: url_helper
INFO - 2016-05-03 18:26:17 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:26:17 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:26:17 --> Helper loaded: form_helper
INFO - 2016-05-03 18:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:26:17 --> Form Validation Class Initialized
INFO - 2016-05-03 18:26:17 --> Controller Class Initialized
INFO - 2016-05-03 18:26:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:26:17 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:26:17 --> Model Class Initialized
INFO - 2016-05-03 18:26:17 --> Database Driver Class Initialized
INFO - 2016-05-03 18:26:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-03 18:26:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:26:17 --> Final output sent to browser
DEBUG - 2016-05-03 18:26:17 --> Total execution time: 0.1244
INFO - 2016-05-03 18:32:07 --> Config Class Initialized
INFO - 2016-05-03 18:32:07 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:32:07 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:32:07 --> Utf8 Class Initialized
INFO - 2016-05-03 18:32:07 --> URI Class Initialized
INFO - 2016-05-03 18:32:07 --> Router Class Initialized
INFO - 2016-05-03 18:32:07 --> Output Class Initialized
INFO - 2016-05-03 18:32:07 --> Security Class Initialized
DEBUG - 2016-05-03 18:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:32:07 --> Input Class Initialized
INFO - 2016-05-03 18:32:07 --> Language Class Initialized
INFO - 2016-05-03 18:32:07 --> Loader Class Initialized
INFO - 2016-05-03 18:32:07 --> Helper loaded: url_helper
INFO - 2016-05-03 18:32:07 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:32:07 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:32:07 --> Helper loaded: form_helper
INFO - 2016-05-03 18:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:32:07 --> Form Validation Class Initialized
INFO - 2016-05-03 18:32:07 --> Controller Class Initialized
INFO - 2016-05-03 18:32:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:32:07 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:32:07 --> Model Class Initialized
INFO - 2016-05-03 18:32:07 --> Database Driver Class Initialized
INFO - 2016-05-03 18:32:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-03 18:32:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:32:07 --> Final output sent to browser
DEBUG - 2016-05-03 18:32:07 --> Total execution time: 0.1817
INFO - 2016-05-03 18:33:21 --> Config Class Initialized
INFO - 2016-05-03 18:33:21 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:33:21 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:33:21 --> Utf8 Class Initialized
INFO - 2016-05-03 18:33:21 --> URI Class Initialized
INFO - 2016-05-03 18:33:21 --> Router Class Initialized
INFO - 2016-05-03 18:33:21 --> Output Class Initialized
INFO - 2016-05-03 18:33:21 --> Security Class Initialized
DEBUG - 2016-05-03 18:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:33:21 --> Input Class Initialized
INFO - 2016-05-03 18:33:21 --> Language Class Initialized
INFO - 2016-05-03 18:33:21 --> Loader Class Initialized
INFO - 2016-05-03 18:33:21 --> Helper loaded: url_helper
INFO - 2016-05-03 18:33:21 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:33:21 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:33:21 --> Helper loaded: form_helper
INFO - 2016-05-03 18:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:33:21 --> Form Validation Class Initialized
INFO - 2016-05-03 18:33:21 --> Controller Class Initialized
INFO - 2016-05-03 18:33:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:33:21 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:33:21 --> Model Class Initialized
INFO - 2016-05-03 18:33:21 --> Database Driver Class Initialized
INFO - 2016-05-03 18:33:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-03 18:33:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:33:21 --> Final output sent to browser
DEBUG - 2016-05-03 18:33:21 --> Total execution time: 0.1865
INFO - 2016-05-03 18:33:23 --> Config Class Initialized
INFO - 2016-05-03 18:33:23 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:33:23 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:33:23 --> Utf8 Class Initialized
INFO - 2016-05-03 18:33:23 --> URI Class Initialized
INFO - 2016-05-03 18:33:23 --> Router Class Initialized
INFO - 2016-05-03 18:33:23 --> Output Class Initialized
INFO - 2016-05-03 18:33:23 --> Security Class Initialized
DEBUG - 2016-05-03 18:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:33:23 --> Input Class Initialized
INFO - 2016-05-03 18:33:23 --> Language Class Initialized
INFO - 2016-05-03 18:33:23 --> Loader Class Initialized
INFO - 2016-05-03 18:33:23 --> Helper loaded: url_helper
INFO - 2016-05-03 18:33:23 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:33:23 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:33:23 --> Helper loaded: form_helper
INFO - 2016-05-03 18:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:33:23 --> Form Validation Class Initialized
INFO - 2016-05-03 18:33:23 --> Controller Class Initialized
INFO - 2016-05-03 18:33:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:33:23 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:33:23 --> Model Class Initialized
INFO - 2016-05-03 18:33:23 --> Database Driver Class Initialized
INFO - 2016-05-03 18:33:23 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 18:33:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-03 18:33:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:33:23 --> Final output sent to browser
DEBUG - 2016-05-03 18:33:23 --> Total execution time: 0.0971
INFO - 2016-05-03 18:33:39 --> Config Class Initialized
INFO - 2016-05-03 18:33:39 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:33:39 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:33:39 --> Utf8 Class Initialized
INFO - 2016-05-03 18:33:39 --> URI Class Initialized
INFO - 2016-05-03 18:33:39 --> Router Class Initialized
INFO - 2016-05-03 18:33:39 --> Output Class Initialized
INFO - 2016-05-03 18:33:39 --> Security Class Initialized
DEBUG - 2016-05-03 18:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:33:39 --> Input Class Initialized
INFO - 2016-05-03 18:33:39 --> Language Class Initialized
INFO - 2016-05-03 18:33:39 --> Loader Class Initialized
INFO - 2016-05-03 18:33:39 --> Helper loaded: url_helper
INFO - 2016-05-03 18:33:39 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:33:39 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:33:39 --> Helper loaded: form_helper
INFO - 2016-05-03 18:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:33:39 --> Form Validation Class Initialized
INFO - 2016-05-03 18:33:39 --> Controller Class Initialized
INFO - 2016-05-03 18:33:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:33:39 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:33:39 --> Model Class Initialized
INFO - 2016-05-03 18:33:39 --> Database Driver Class Initialized
INFO - 2016-05-03 18:33:39 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 18:33:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-03 18:33:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:33:39 --> Final output sent to browser
DEBUG - 2016-05-03 18:33:39 --> Total execution time: 0.0756
INFO - 2016-05-03 18:35:53 --> Config Class Initialized
INFO - 2016-05-03 18:35:53 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:35:53 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:35:53 --> Utf8 Class Initialized
INFO - 2016-05-03 18:35:53 --> URI Class Initialized
INFO - 2016-05-03 18:35:53 --> Router Class Initialized
INFO - 2016-05-03 18:35:53 --> Output Class Initialized
INFO - 2016-05-03 18:35:53 --> Security Class Initialized
DEBUG - 2016-05-03 18:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:35:53 --> Input Class Initialized
INFO - 2016-05-03 18:35:53 --> Language Class Initialized
INFO - 2016-05-03 18:35:53 --> Loader Class Initialized
INFO - 2016-05-03 18:35:53 --> Helper loaded: url_helper
INFO - 2016-05-03 18:35:53 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:35:53 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:35:53 --> Helper loaded: form_helper
INFO - 2016-05-03 18:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:35:53 --> Form Validation Class Initialized
INFO - 2016-05-03 18:35:53 --> Controller Class Initialized
INFO - 2016-05-03 18:35:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:35:53 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:35:53 --> Model Class Initialized
INFO - 2016-05-03 18:35:53 --> Database Driver Class Initialized
INFO - 2016-05-03 18:35:53 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 18:35:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-03 18:35:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:35:54 --> Final output sent to browser
DEBUG - 2016-05-03 18:35:54 --> Total execution time: 0.3708
INFO - 2016-05-03 18:41:19 --> Config Class Initialized
INFO - 2016-05-03 18:41:19 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:41:19 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:41:19 --> Utf8 Class Initialized
INFO - 2016-05-03 18:41:19 --> URI Class Initialized
INFO - 2016-05-03 18:41:19 --> Router Class Initialized
INFO - 2016-05-03 18:41:19 --> Output Class Initialized
INFO - 2016-05-03 18:41:19 --> Security Class Initialized
DEBUG - 2016-05-03 18:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:41:19 --> Input Class Initialized
INFO - 2016-05-03 18:41:19 --> Language Class Initialized
INFO - 2016-05-03 18:41:19 --> Loader Class Initialized
INFO - 2016-05-03 18:41:19 --> Helper loaded: url_helper
INFO - 2016-05-03 18:41:19 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:41:19 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:41:19 --> Helper loaded: form_helper
INFO - 2016-05-03 18:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:41:19 --> Form Validation Class Initialized
INFO - 2016-05-03 18:41:19 --> Controller Class Initialized
INFO - 2016-05-03 18:41:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:41:19 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:41:19 --> Model Class Initialized
INFO - 2016-05-03 18:41:19 --> Database Driver Class Initialized
INFO - 2016-05-03 18:41:19 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 18:41:20 --> Config Class Initialized
INFO - 2016-05-03 18:41:20 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:41:20 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:41:20 --> Utf8 Class Initialized
INFO - 2016-05-03 18:41:20 --> URI Class Initialized
INFO - 2016-05-03 18:41:20 --> Router Class Initialized
INFO - 2016-05-03 18:41:20 --> Output Class Initialized
INFO - 2016-05-03 18:41:20 --> Security Class Initialized
DEBUG - 2016-05-03 18:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:41:20 --> Input Class Initialized
INFO - 2016-05-03 18:41:20 --> Language Class Initialized
INFO - 2016-05-03 18:41:20 --> Loader Class Initialized
INFO - 2016-05-03 18:41:20 --> Helper loaded: url_helper
INFO - 2016-05-03 18:41:20 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:41:20 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:41:20 --> Helper loaded: form_helper
INFO - 2016-05-03 18:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:41:20 --> Form Validation Class Initialized
INFO - 2016-05-03 18:41:20 --> Controller Class Initialized
INFO - 2016-05-03 18:41:20 --> Model Class Initialized
INFO - 2016-05-03 18:41:20 --> Database Driver Class Initialized
INFO - 2016-05-03 18:41:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:41:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 18:41:20 --> Pagination Class Initialized
DEBUG - 2016-05-03 18:41:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 18:41:20 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:41:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 18:41:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:41:20 --> Final output sent to browser
DEBUG - 2016-05-03 18:41:20 --> Total execution time: 0.1226
INFO - 2016-05-03 18:41:29 --> Config Class Initialized
INFO - 2016-05-03 18:41:29 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:41:29 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:41:29 --> Utf8 Class Initialized
INFO - 2016-05-03 18:41:29 --> URI Class Initialized
INFO - 2016-05-03 18:41:29 --> Router Class Initialized
INFO - 2016-05-03 18:41:29 --> Output Class Initialized
INFO - 2016-05-03 18:41:29 --> Security Class Initialized
DEBUG - 2016-05-03 18:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:41:29 --> Input Class Initialized
INFO - 2016-05-03 18:41:29 --> Language Class Initialized
INFO - 2016-05-03 18:41:29 --> Loader Class Initialized
INFO - 2016-05-03 18:41:29 --> Helper loaded: url_helper
INFO - 2016-05-03 18:41:29 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:41:29 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:41:29 --> Helper loaded: form_helper
INFO - 2016-05-03 18:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:41:29 --> Form Validation Class Initialized
INFO - 2016-05-03 18:41:29 --> Controller Class Initialized
INFO - 2016-05-03 18:41:29 --> Model Class Initialized
INFO - 2016-05-03 18:41:29 --> Database Driver Class Initialized
INFO - 2016-05-03 18:41:29 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:41:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 18:41:29 --> Pagination Class Initialized
DEBUG - 2016-05-03 18:41:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 18:41:29 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:41:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 18:41:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:41:29 --> Final output sent to browser
DEBUG - 2016-05-03 18:41:29 --> Total execution time: 0.0775
INFO - 2016-05-03 18:41:55 --> Config Class Initialized
INFO - 2016-05-03 18:41:55 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:41:55 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:41:55 --> Utf8 Class Initialized
INFO - 2016-05-03 18:41:55 --> URI Class Initialized
INFO - 2016-05-03 18:41:55 --> Router Class Initialized
INFO - 2016-05-03 18:41:55 --> Output Class Initialized
INFO - 2016-05-03 18:41:55 --> Security Class Initialized
DEBUG - 2016-05-03 18:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:41:56 --> Input Class Initialized
INFO - 2016-05-03 18:41:56 --> Language Class Initialized
INFO - 2016-05-03 18:41:56 --> Loader Class Initialized
INFO - 2016-05-03 18:41:56 --> Helper loaded: url_helper
INFO - 2016-05-03 18:41:56 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:41:56 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:41:56 --> Helper loaded: form_helper
INFO - 2016-05-03 18:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:41:56 --> Form Validation Class Initialized
INFO - 2016-05-03 18:41:56 --> Controller Class Initialized
INFO - 2016-05-03 18:41:56 --> Model Class Initialized
INFO - 2016-05-03 18:41:56 --> Database Driver Class Initialized
INFO - 2016-05-03 18:41:56 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:41:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 18:41:56 --> Pagination Class Initialized
DEBUG - 2016-05-03 18:41:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 18:41:56 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:41:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProveedor.php
INFO - 2016-05-03 18:41:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:41:56 --> Final output sent to browser
DEBUG - 2016-05-03 18:41:56 --> Total execution time: 0.0790
INFO - 2016-05-03 18:42:00 --> Config Class Initialized
INFO - 2016-05-03 18:42:00 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:42:00 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:42:00 --> Utf8 Class Initialized
INFO - 2016-05-03 18:42:00 --> URI Class Initialized
INFO - 2016-05-03 18:42:00 --> Router Class Initialized
INFO - 2016-05-03 18:42:00 --> Output Class Initialized
INFO - 2016-05-03 18:42:00 --> Security Class Initialized
DEBUG - 2016-05-03 18:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:42:00 --> Input Class Initialized
INFO - 2016-05-03 18:42:00 --> Language Class Initialized
INFO - 2016-05-03 18:42:00 --> Loader Class Initialized
INFO - 2016-05-03 18:42:00 --> Helper loaded: url_helper
INFO - 2016-05-03 18:42:00 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:42:00 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:42:00 --> Helper loaded: form_helper
INFO - 2016-05-03 18:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:42:00 --> Form Validation Class Initialized
INFO - 2016-05-03 18:42:00 --> Controller Class Initialized
INFO - 2016-05-03 18:42:00 --> Model Class Initialized
INFO - 2016-05-03 18:42:00 --> Database Driver Class Initialized
INFO - 2016-05-03 18:42:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:42:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 18:42:00 --> Pagination Class Initialized
DEBUG - 2016-05-03 18:42:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 18:42:00 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:42:00 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 18:42:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProveedor.php
INFO - 2016-05-03 18:42:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:42:01 --> Final output sent to browser
DEBUG - 2016-05-03 18:42:01 --> Total execution time: 0.2147
INFO - 2016-05-03 18:42:04 --> Config Class Initialized
INFO - 2016-05-03 18:42:04 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:42:04 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:42:04 --> Utf8 Class Initialized
INFO - 2016-05-03 18:42:04 --> URI Class Initialized
INFO - 2016-05-03 18:42:04 --> Router Class Initialized
INFO - 2016-05-03 18:42:04 --> Output Class Initialized
INFO - 2016-05-03 18:42:04 --> Security Class Initialized
DEBUG - 2016-05-03 18:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:42:04 --> Input Class Initialized
INFO - 2016-05-03 18:42:04 --> Language Class Initialized
INFO - 2016-05-03 18:42:04 --> Loader Class Initialized
INFO - 2016-05-03 18:42:04 --> Helper loaded: url_helper
INFO - 2016-05-03 18:42:04 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:42:04 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:42:04 --> Helper loaded: form_helper
INFO - 2016-05-03 18:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:42:04 --> Form Validation Class Initialized
INFO - 2016-05-03 18:42:04 --> Controller Class Initialized
INFO - 2016-05-03 18:42:04 --> Model Class Initialized
INFO - 2016-05-03 18:42:04 --> Database Driver Class Initialized
INFO - 2016-05-03 18:42:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:42:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 18:42:04 --> Pagination Class Initialized
DEBUG - 2016-05-03 18:42:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 18:42:04 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:42:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 18:42:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:42:04 --> Final output sent to browser
DEBUG - 2016-05-03 18:42:04 --> Total execution time: 0.0956
INFO - 2016-05-03 18:43:58 --> Config Class Initialized
INFO - 2016-05-03 18:43:58 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:43:58 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:43:58 --> Utf8 Class Initialized
INFO - 2016-05-03 18:43:58 --> URI Class Initialized
INFO - 2016-05-03 18:43:58 --> Router Class Initialized
INFO - 2016-05-03 18:43:58 --> Output Class Initialized
INFO - 2016-05-03 18:43:58 --> Security Class Initialized
DEBUG - 2016-05-03 18:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:43:58 --> Input Class Initialized
INFO - 2016-05-03 18:43:58 --> Language Class Initialized
INFO - 2016-05-03 18:43:58 --> Loader Class Initialized
INFO - 2016-05-03 18:43:58 --> Helper loaded: url_helper
INFO - 2016-05-03 18:43:58 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:43:58 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:43:58 --> Helper loaded: form_helper
INFO - 2016-05-03 18:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:43:58 --> Form Validation Class Initialized
INFO - 2016-05-03 18:43:58 --> Controller Class Initialized
INFO - 2016-05-03 18:43:58 --> Model Class Initialized
INFO - 2016-05-03 18:43:58 --> Database Driver Class Initialized
INFO - 2016-05-03 18:43:58 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:43:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 18:43:58 --> Pagination Class Initialized
DEBUG - 2016-05-03 18:43:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 18:43:58 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:43:58 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 18:43:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProveedor.php
INFO - 2016-05-03 18:43:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:43:58 --> Final output sent to browser
DEBUG - 2016-05-03 18:43:58 --> Total execution time: 0.1672
INFO - 2016-05-03 18:44:02 --> Config Class Initialized
INFO - 2016-05-03 18:44:02 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:44:02 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:44:02 --> Utf8 Class Initialized
INFO - 2016-05-03 18:44:02 --> URI Class Initialized
INFO - 2016-05-03 18:44:02 --> Router Class Initialized
INFO - 2016-05-03 18:44:02 --> Output Class Initialized
INFO - 2016-05-03 18:44:02 --> Security Class Initialized
DEBUG - 2016-05-03 18:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:44:02 --> Input Class Initialized
INFO - 2016-05-03 18:44:02 --> Language Class Initialized
INFO - 2016-05-03 18:44:02 --> Loader Class Initialized
INFO - 2016-05-03 18:44:02 --> Helper loaded: url_helper
INFO - 2016-05-03 18:44:02 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:44:02 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:44:02 --> Helper loaded: form_helper
INFO - 2016-05-03 18:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:44:02 --> Form Validation Class Initialized
INFO - 2016-05-03 18:44:02 --> Controller Class Initialized
INFO - 2016-05-03 18:44:02 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:44:02 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:44:02 --> Model Class Initialized
INFO - 2016-05-03 18:44:02 --> Database Driver Class Initialized
INFO - 2016-05-03 18:44:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-03 18:44:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:44:02 --> Final output sent to browser
DEBUG - 2016-05-03 18:44:02 --> Total execution time: 0.0839
INFO - 2016-05-03 18:46:46 --> Config Class Initialized
INFO - 2016-05-03 18:46:46 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:46:46 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:46:46 --> Utf8 Class Initialized
INFO - 2016-05-03 18:46:46 --> URI Class Initialized
INFO - 2016-05-03 18:46:46 --> Router Class Initialized
INFO - 2016-05-03 18:46:46 --> Output Class Initialized
INFO - 2016-05-03 18:46:46 --> Security Class Initialized
DEBUG - 2016-05-03 18:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:46:46 --> Input Class Initialized
INFO - 2016-05-03 18:46:46 --> Language Class Initialized
INFO - 2016-05-03 18:46:46 --> Loader Class Initialized
INFO - 2016-05-03 18:46:46 --> Helper loaded: url_helper
INFO - 2016-05-03 18:46:46 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:46:46 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:46:46 --> Helper loaded: form_helper
INFO - 2016-05-03 18:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:46:46 --> Form Validation Class Initialized
INFO - 2016-05-03 18:46:46 --> Controller Class Initialized
INFO - 2016-05-03 18:46:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:46:46 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:46:46 --> Model Class Initialized
INFO - 2016-05-03 18:46:46 --> Database Driver Class Initialized
INFO - 2016-05-03 18:46:46 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 18:46:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-03 18:46:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:46:46 --> Final output sent to browser
DEBUG - 2016-05-03 18:46:46 --> Total execution time: 0.0882
INFO - 2016-05-03 18:46:49 --> Config Class Initialized
INFO - 2016-05-03 18:46:49 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:46:49 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:46:49 --> Utf8 Class Initialized
INFO - 2016-05-03 18:46:49 --> URI Class Initialized
INFO - 2016-05-03 18:46:49 --> Router Class Initialized
INFO - 2016-05-03 18:46:49 --> Output Class Initialized
INFO - 2016-05-03 18:46:49 --> Security Class Initialized
DEBUG - 2016-05-03 18:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:46:49 --> Input Class Initialized
INFO - 2016-05-03 18:46:49 --> Language Class Initialized
INFO - 2016-05-03 18:46:49 --> Loader Class Initialized
INFO - 2016-05-03 18:46:49 --> Helper loaded: url_helper
INFO - 2016-05-03 18:46:49 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:46:49 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:46:49 --> Helper loaded: form_helper
INFO - 2016-05-03 18:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:46:49 --> Form Validation Class Initialized
INFO - 2016-05-03 18:46:49 --> Controller Class Initialized
INFO - 2016-05-03 18:46:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:46:49 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:46:49 --> Model Class Initialized
INFO - 2016-05-03 18:46:49 --> Database Driver Class Initialized
INFO - 2016-05-03 18:46:49 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 18:46:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-03 18:46:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:46:49 --> Final output sent to browser
DEBUG - 2016-05-03 18:46:49 --> Total execution time: 0.1448
INFO - 2016-05-03 18:46:53 --> Config Class Initialized
INFO - 2016-05-03 18:46:53 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:46:53 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:46:53 --> Utf8 Class Initialized
INFO - 2016-05-03 18:46:53 --> URI Class Initialized
INFO - 2016-05-03 18:46:53 --> Router Class Initialized
INFO - 2016-05-03 18:46:53 --> Output Class Initialized
INFO - 2016-05-03 18:46:53 --> Security Class Initialized
DEBUG - 2016-05-03 18:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:46:53 --> Input Class Initialized
INFO - 2016-05-03 18:46:53 --> Language Class Initialized
INFO - 2016-05-03 18:46:53 --> Loader Class Initialized
INFO - 2016-05-03 18:46:53 --> Helper loaded: url_helper
INFO - 2016-05-03 18:46:53 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:46:53 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:46:53 --> Helper loaded: form_helper
INFO - 2016-05-03 18:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:46:53 --> Form Validation Class Initialized
INFO - 2016-05-03 18:46:53 --> Controller Class Initialized
INFO - 2016-05-03 18:46:53 --> Model Class Initialized
INFO - 2016-05-03 18:46:53 --> Database Driver Class Initialized
INFO - 2016-05-03 18:46:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:46:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 18:46:53 --> Pagination Class Initialized
DEBUG - 2016-05-03 18:46:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 18:46:53 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:46:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 18:46:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:46:53 --> Final output sent to browser
DEBUG - 2016-05-03 18:46:53 --> Total execution time: 0.0774
INFO - 2016-05-03 18:48:19 --> Config Class Initialized
INFO - 2016-05-03 18:48:19 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:48:19 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:48:19 --> Utf8 Class Initialized
INFO - 2016-05-03 18:48:19 --> URI Class Initialized
INFO - 2016-05-03 18:48:19 --> Router Class Initialized
INFO - 2016-05-03 18:48:19 --> Output Class Initialized
INFO - 2016-05-03 18:48:19 --> Security Class Initialized
DEBUG - 2016-05-03 18:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:48:19 --> Input Class Initialized
INFO - 2016-05-03 18:48:19 --> Language Class Initialized
INFO - 2016-05-03 18:48:19 --> Loader Class Initialized
INFO - 2016-05-03 18:48:19 --> Helper loaded: url_helper
INFO - 2016-05-03 18:48:19 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:48:19 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:48:19 --> Helper loaded: form_helper
INFO - 2016-05-03 18:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:48:19 --> Form Validation Class Initialized
INFO - 2016-05-03 18:48:19 --> Controller Class Initialized
INFO - 2016-05-03 18:48:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:48:19 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:48:19 --> Model Class Initialized
INFO - 2016-05-03 18:48:19 --> Database Driver Class Initialized
INFO - 2016-05-03 18:48:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-03 18:48:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:48:19 --> Final output sent to browser
DEBUG - 2016-05-03 18:48:19 --> Total execution time: 0.0693
INFO - 2016-05-03 18:52:10 --> Config Class Initialized
INFO - 2016-05-03 18:52:10 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:52:10 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:52:10 --> Utf8 Class Initialized
INFO - 2016-05-03 18:52:10 --> URI Class Initialized
INFO - 2016-05-03 18:52:10 --> Router Class Initialized
INFO - 2016-05-03 18:52:10 --> Output Class Initialized
INFO - 2016-05-03 18:52:10 --> Security Class Initialized
DEBUG - 2016-05-03 18:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:52:10 --> Input Class Initialized
INFO - 2016-05-03 18:52:10 --> Language Class Initialized
INFO - 2016-05-03 18:52:10 --> Loader Class Initialized
INFO - 2016-05-03 18:52:10 --> Helper loaded: url_helper
INFO - 2016-05-03 18:52:10 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:52:10 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:52:10 --> Helper loaded: form_helper
INFO - 2016-05-03 18:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:52:10 --> Form Validation Class Initialized
INFO - 2016-05-03 18:52:10 --> Controller Class Initialized
INFO - 2016-05-03 18:52:10 --> Model Class Initialized
INFO - 2016-05-03 18:52:10 --> Database Driver Class Initialized
INFO - 2016-05-03 18:52:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:52:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 18:52:10 --> Pagination Class Initialized
DEBUG - 2016-05-03 18:52:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 18:52:10 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:52:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 18:52:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:52:10 --> Final output sent to browser
DEBUG - 2016-05-03 18:52:10 --> Total execution time: 0.0877
INFO - 2016-05-03 18:53:14 --> Config Class Initialized
INFO - 2016-05-03 18:53:14 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:53:14 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:53:14 --> Utf8 Class Initialized
INFO - 2016-05-03 18:53:14 --> URI Class Initialized
INFO - 2016-05-03 18:53:14 --> Router Class Initialized
INFO - 2016-05-03 18:53:14 --> Output Class Initialized
INFO - 2016-05-03 18:53:14 --> Security Class Initialized
DEBUG - 2016-05-03 18:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:53:14 --> Input Class Initialized
INFO - 2016-05-03 18:53:14 --> Language Class Initialized
INFO - 2016-05-03 18:53:14 --> Loader Class Initialized
INFO - 2016-05-03 18:53:14 --> Helper loaded: url_helper
INFO - 2016-05-03 18:53:14 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:53:14 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:53:14 --> Helper loaded: form_helper
INFO - 2016-05-03 18:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:53:14 --> Form Validation Class Initialized
INFO - 2016-05-03 18:53:14 --> Controller Class Initialized
INFO - 2016-05-03 18:53:14 --> Model Class Initialized
INFO - 2016-05-03 18:53:14 --> Database Driver Class Initialized
INFO - 2016-05-03 18:53:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:53:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 18:53:14 --> Pagination Class Initialized
DEBUG - 2016-05-03 18:53:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 18:53:14 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:53:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 18:53:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:53:14 --> Final output sent to browser
DEBUG - 2016-05-03 18:53:14 --> Total execution time: 0.1085
INFO - 2016-05-03 18:53:37 --> Config Class Initialized
INFO - 2016-05-03 18:53:37 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:53:37 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:53:37 --> Utf8 Class Initialized
INFO - 2016-05-03 18:53:37 --> URI Class Initialized
INFO - 2016-05-03 18:53:37 --> Router Class Initialized
INFO - 2016-05-03 18:53:37 --> Output Class Initialized
INFO - 2016-05-03 18:53:37 --> Security Class Initialized
DEBUG - 2016-05-03 18:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:53:37 --> Input Class Initialized
INFO - 2016-05-03 18:53:37 --> Language Class Initialized
INFO - 2016-05-03 18:53:37 --> Loader Class Initialized
INFO - 2016-05-03 18:53:37 --> Helper loaded: url_helper
INFO - 2016-05-03 18:53:37 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:53:37 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:53:37 --> Helper loaded: form_helper
INFO - 2016-05-03 18:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:53:37 --> Form Validation Class Initialized
INFO - 2016-05-03 18:53:37 --> Controller Class Initialized
INFO - 2016-05-03 18:53:37 --> Model Class Initialized
INFO - 2016-05-03 18:53:37 --> Database Driver Class Initialized
INFO - 2016-05-03 18:53:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:53:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 18:53:37 --> Pagination Class Initialized
DEBUG - 2016-05-03 18:53:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 18:53:37 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:53:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 18:53:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:53:37 --> Final output sent to browser
DEBUG - 2016-05-03 18:53:37 --> Total execution time: 0.0815
INFO - 2016-05-03 18:53:50 --> Config Class Initialized
INFO - 2016-05-03 18:53:50 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:53:50 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:53:50 --> Utf8 Class Initialized
INFO - 2016-05-03 18:53:50 --> URI Class Initialized
INFO - 2016-05-03 18:53:50 --> Router Class Initialized
INFO - 2016-05-03 18:53:50 --> Output Class Initialized
INFO - 2016-05-03 18:53:50 --> Security Class Initialized
DEBUG - 2016-05-03 18:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:53:50 --> Input Class Initialized
INFO - 2016-05-03 18:53:50 --> Language Class Initialized
INFO - 2016-05-03 18:53:50 --> Loader Class Initialized
INFO - 2016-05-03 18:53:50 --> Helper loaded: url_helper
INFO - 2016-05-03 18:53:50 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:53:50 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:53:50 --> Helper loaded: form_helper
INFO - 2016-05-03 18:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:53:50 --> Form Validation Class Initialized
INFO - 2016-05-03 18:53:50 --> Controller Class Initialized
INFO - 2016-05-03 18:53:50 --> Model Class Initialized
INFO - 2016-05-03 18:53:50 --> Database Driver Class Initialized
INFO - 2016-05-03 18:53:50 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:53:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 18:53:50 --> Pagination Class Initialized
DEBUG - 2016-05-03 18:53:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 18:53:50 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:53:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProveedor.php
INFO - 2016-05-03 18:53:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:53:50 --> Final output sent to browser
DEBUG - 2016-05-03 18:53:50 --> Total execution time: 0.0783
INFO - 2016-05-03 18:53:54 --> Config Class Initialized
INFO - 2016-05-03 18:53:54 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:53:54 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:53:54 --> Utf8 Class Initialized
INFO - 2016-05-03 18:53:54 --> URI Class Initialized
INFO - 2016-05-03 18:53:54 --> Router Class Initialized
INFO - 2016-05-03 18:53:54 --> Output Class Initialized
INFO - 2016-05-03 18:53:54 --> Security Class Initialized
DEBUG - 2016-05-03 18:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:53:54 --> Input Class Initialized
INFO - 2016-05-03 18:53:54 --> Language Class Initialized
INFO - 2016-05-03 18:53:54 --> Loader Class Initialized
INFO - 2016-05-03 18:53:54 --> Helper loaded: url_helper
INFO - 2016-05-03 18:53:54 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:53:54 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:53:54 --> Helper loaded: form_helper
INFO - 2016-05-03 18:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:53:54 --> Form Validation Class Initialized
INFO - 2016-05-03 18:53:54 --> Controller Class Initialized
INFO - 2016-05-03 18:53:54 --> Model Class Initialized
INFO - 2016-05-03 18:53:54 --> Database Driver Class Initialized
INFO - 2016-05-03 18:53:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:53:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 18:53:54 --> Pagination Class Initialized
DEBUG - 2016-05-03 18:53:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 18:53:54 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:53:54 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 18:53:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProveedor.php
INFO - 2016-05-03 18:53:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:53:54 --> Final output sent to browser
DEBUG - 2016-05-03 18:53:54 --> Total execution time: 0.1497
INFO - 2016-05-03 18:53:55 --> Config Class Initialized
INFO - 2016-05-03 18:53:55 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:53:55 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:53:55 --> Utf8 Class Initialized
INFO - 2016-05-03 18:53:55 --> URI Class Initialized
INFO - 2016-05-03 18:53:55 --> Router Class Initialized
INFO - 2016-05-03 18:53:55 --> Output Class Initialized
INFO - 2016-05-03 18:53:55 --> Security Class Initialized
DEBUG - 2016-05-03 18:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:53:55 --> Input Class Initialized
INFO - 2016-05-03 18:53:55 --> Language Class Initialized
INFO - 2016-05-03 18:53:55 --> Loader Class Initialized
INFO - 2016-05-03 18:53:55 --> Helper loaded: url_helper
INFO - 2016-05-03 18:53:55 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:53:55 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:53:55 --> Helper loaded: form_helper
INFO - 2016-05-03 18:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:53:55 --> Form Validation Class Initialized
INFO - 2016-05-03 18:53:55 --> Controller Class Initialized
INFO - 2016-05-03 18:53:55 --> Model Class Initialized
INFO - 2016-05-03 18:53:55 --> Database Driver Class Initialized
INFO - 2016-05-03 18:53:55 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:53:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 18:53:55 --> Pagination Class Initialized
DEBUG - 2016-05-03 18:53:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 18:53:55 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:53:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 18:53:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:53:55 --> Final output sent to browser
DEBUG - 2016-05-03 18:53:55 --> Total execution time: 0.0940
INFO - 2016-05-03 18:59:57 --> Config Class Initialized
INFO - 2016-05-03 18:59:57 --> Hooks Class Initialized
DEBUG - 2016-05-03 18:59:57 --> UTF-8 Support Enabled
INFO - 2016-05-03 18:59:57 --> Utf8 Class Initialized
INFO - 2016-05-03 18:59:57 --> URI Class Initialized
INFO - 2016-05-03 18:59:57 --> Router Class Initialized
INFO - 2016-05-03 18:59:57 --> Output Class Initialized
INFO - 2016-05-03 18:59:57 --> Security Class Initialized
DEBUG - 2016-05-03 18:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 18:59:57 --> Input Class Initialized
INFO - 2016-05-03 18:59:57 --> Language Class Initialized
INFO - 2016-05-03 18:59:57 --> Loader Class Initialized
INFO - 2016-05-03 18:59:57 --> Helper loaded: url_helper
INFO - 2016-05-03 18:59:57 --> Helper loaded: sesion_helper
INFO - 2016-05-03 18:59:57 --> Helper loaded: templates_helper
INFO - 2016-05-03 18:59:57 --> Helper loaded: form_helper
INFO - 2016-05-03 18:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 18:59:57 --> Form Validation Class Initialized
INFO - 2016-05-03 18:59:57 --> Controller Class Initialized
INFO - 2016-05-03 18:59:57 --> Model Class Initialized
INFO - 2016-05-03 18:59:57 --> Database Driver Class Initialized
INFO - 2016-05-03 18:59:57 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 18:59:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 18:59:57 --> Pagination Class Initialized
DEBUG - 2016-05-03 18:59:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 18:59:57 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 18:59:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 18:59:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 18:59:57 --> Final output sent to browser
DEBUG - 2016-05-03 18:59:57 --> Total execution time: 0.0878
INFO - 2016-05-03 19:00:00 --> Config Class Initialized
INFO - 2016-05-03 19:00:00 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:00:00 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:00:00 --> Utf8 Class Initialized
INFO - 2016-05-03 19:00:00 --> URI Class Initialized
INFO - 2016-05-03 19:00:00 --> Router Class Initialized
INFO - 2016-05-03 19:00:00 --> Output Class Initialized
INFO - 2016-05-03 19:00:00 --> Security Class Initialized
DEBUG - 2016-05-03 19:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:00:00 --> Input Class Initialized
INFO - 2016-05-03 19:00:00 --> Language Class Initialized
INFO - 2016-05-03 19:00:00 --> Loader Class Initialized
INFO - 2016-05-03 19:00:00 --> Helper loaded: url_helper
INFO - 2016-05-03 19:00:00 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:00:00 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:00:00 --> Helper loaded: form_helper
INFO - 2016-05-03 19:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:00:00 --> Form Validation Class Initialized
INFO - 2016-05-03 19:00:00 --> Controller Class Initialized
INFO - 2016-05-03 19:00:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-03 19:00:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 19:00:00 --> Final output sent to browser
DEBUG - 2016-05-03 19:00:00 --> Total execution time: 0.0516
INFO - 2016-05-03 19:00:01 --> Config Class Initialized
INFO - 2016-05-03 19:00:01 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:00:01 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:00:01 --> Utf8 Class Initialized
INFO - 2016-05-03 19:00:01 --> URI Class Initialized
INFO - 2016-05-03 19:00:01 --> Router Class Initialized
INFO - 2016-05-03 19:00:01 --> Output Class Initialized
INFO - 2016-05-03 19:00:01 --> Security Class Initialized
DEBUG - 2016-05-03 19:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:00:01 --> Input Class Initialized
INFO - 2016-05-03 19:00:01 --> Language Class Initialized
INFO - 2016-05-03 19:00:01 --> Loader Class Initialized
INFO - 2016-05-03 19:00:01 --> Helper loaded: url_helper
INFO - 2016-05-03 19:00:01 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:00:01 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:00:01 --> Helper loaded: form_helper
INFO - 2016-05-03 19:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:00:01 --> Form Validation Class Initialized
INFO - 2016-05-03 19:00:01 --> Controller Class Initialized
INFO - 2016-05-03 19:00:01 --> Config Class Initialized
INFO - 2016-05-03 19:00:01 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:00:01 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:00:01 --> Utf8 Class Initialized
INFO - 2016-05-03 19:00:01 --> URI Class Initialized
INFO - 2016-05-03 19:00:01 --> Router Class Initialized
INFO - 2016-05-03 19:00:01 --> Output Class Initialized
INFO - 2016-05-03 19:00:01 --> Security Class Initialized
DEBUG - 2016-05-03 19:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:00:01 --> Input Class Initialized
INFO - 2016-05-03 19:00:01 --> Language Class Initialized
INFO - 2016-05-03 19:00:01 --> Loader Class Initialized
INFO - 2016-05-03 19:00:01 --> Helper loaded: url_helper
INFO - 2016-05-03 19:00:01 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:00:01 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:00:01 --> Helper loaded: form_helper
INFO - 2016-05-03 19:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:00:01 --> Form Validation Class Initialized
INFO - 2016-05-03 19:00:01 --> Controller Class Initialized
INFO - 2016-05-03 19:00:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-03 19:00:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:00:01 --> Final output sent to browser
DEBUG - 2016-05-03 19:00:01 --> Total execution time: 0.0485
INFO - 2016-05-03 19:00:04 --> Config Class Initialized
INFO - 2016-05-03 19:00:04 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:00:04 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:00:04 --> Utf8 Class Initialized
INFO - 2016-05-03 19:00:04 --> URI Class Initialized
INFO - 2016-05-03 19:00:04 --> Router Class Initialized
INFO - 2016-05-03 19:00:04 --> Output Class Initialized
INFO - 2016-05-03 19:00:04 --> Security Class Initialized
DEBUG - 2016-05-03 19:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:00:04 --> Input Class Initialized
INFO - 2016-05-03 19:00:04 --> Language Class Initialized
INFO - 2016-05-03 19:00:04 --> Loader Class Initialized
INFO - 2016-05-03 19:00:04 --> Helper loaded: url_helper
INFO - 2016-05-03 19:00:04 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:00:04 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:00:04 --> Helper loaded: form_helper
INFO - 2016-05-03 19:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:00:04 --> Form Validation Class Initialized
INFO - 2016-05-03 19:00:04 --> Controller Class Initialized
INFO - 2016-05-03 19:00:04 --> Model Class Initialized
INFO - 2016-05-03 19:00:04 --> Database Driver Class Initialized
INFO - 2016-05-03 19:00:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:00:04 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:00:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-03 19:00:04 --> Severity: Notice --> Undefined variable: proveedores C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 17
ERROR - 2016-05-03 19:00:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 17
INFO - 2016-05-03 19:00:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:00:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:00:04 --> Final output sent to browser
DEBUG - 2016-05-03 19:00:04 --> Total execution time: 0.0995
INFO - 2016-05-03 19:04:08 --> Config Class Initialized
INFO - 2016-05-03 19:04:08 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:04:08 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:04:08 --> Utf8 Class Initialized
INFO - 2016-05-03 19:04:08 --> URI Class Initialized
INFO - 2016-05-03 19:04:08 --> Router Class Initialized
INFO - 2016-05-03 19:04:08 --> Output Class Initialized
INFO - 2016-05-03 19:04:08 --> Security Class Initialized
DEBUG - 2016-05-03 19:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:04:08 --> Input Class Initialized
INFO - 2016-05-03 19:04:08 --> Language Class Initialized
INFO - 2016-05-03 19:04:08 --> Loader Class Initialized
INFO - 2016-05-03 19:04:08 --> Helper loaded: url_helper
INFO - 2016-05-03 19:04:08 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:04:08 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:04:08 --> Helper loaded: form_helper
INFO - 2016-05-03 19:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:04:08 --> Form Validation Class Initialized
INFO - 2016-05-03 19:04:08 --> Controller Class Initialized
INFO - 2016-05-03 19:04:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:04:08 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:04:08 --> Model Class Initialized
INFO - 2016-05-03 19:04:08 --> Database Driver Class Initialized
INFO - 2016-05-03 19:04:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-03 19:04:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:04:08 --> Final output sent to browser
DEBUG - 2016-05-03 19:04:08 --> Total execution time: 0.0865
INFO - 2016-05-03 19:04:10 --> Config Class Initialized
INFO - 2016-05-03 19:04:10 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:04:10 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:04:10 --> Utf8 Class Initialized
INFO - 2016-05-03 19:04:10 --> URI Class Initialized
INFO - 2016-05-03 19:04:10 --> Router Class Initialized
INFO - 2016-05-03 19:04:10 --> Output Class Initialized
INFO - 2016-05-03 19:04:10 --> Security Class Initialized
DEBUG - 2016-05-03 19:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:04:10 --> Input Class Initialized
INFO - 2016-05-03 19:04:10 --> Language Class Initialized
INFO - 2016-05-03 19:04:10 --> Loader Class Initialized
INFO - 2016-05-03 19:04:10 --> Helper loaded: url_helper
INFO - 2016-05-03 19:04:10 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:04:10 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:04:10 --> Helper loaded: form_helper
INFO - 2016-05-03 19:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:04:10 --> Form Validation Class Initialized
INFO - 2016-05-03 19:04:10 --> Controller Class Initialized
INFO - 2016-05-03 19:04:10 --> Model Class Initialized
INFO - 2016-05-03 19:04:10 --> Database Driver Class Initialized
INFO - 2016-05-03 19:04:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:04:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:04:10 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:04:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:04:10 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:04:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 19:04:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:04:10 --> Final output sent to browser
DEBUG - 2016-05-03 19:04:10 --> Total execution time: 0.1200
INFO - 2016-05-03 19:04:13 --> Config Class Initialized
INFO - 2016-05-03 19:04:13 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:04:13 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:04:13 --> Utf8 Class Initialized
INFO - 2016-05-03 19:04:13 --> URI Class Initialized
INFO - 2016-05-03 19:04:13 --> Router Class Initialized
INFO - 2016-05-03 19:04:13 --> Output Class Initialized
INFO - 2016-05-03 19:04:13 --> Security Class Initialized
DEBUG - 2016-05-03 19:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:04:13 --> Input Class Initialized
INFO - 2016-05-03 19:04:13 --> Language Class Initialized
INFO - 2016-05-03 19:04:13 --> Loader Class Initialized
INFO - 2016-05-03 19:04:13 --> Helper loaded: url_helper
INFO - 2016-05-03 19:04:13 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:04:13 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:04:13 --> Helper loaded: form_helper
INFO - 2016-05-03 19:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:04:13 --> Form Validation Class Initialized
INFO - 2016-05-03 19:04:13 --> Controller Class Initialized
INFO - 2016-05-03 19:04:13 --> Model Class Initialized
INFO - 2016-05-03 19:04:13 --> Database Driver Class Initialized
INFO - 2016-05-03 19:04:13 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:04:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:04:13 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:04:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:04:13 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:04:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProveedor.php
INFO - 2016-05-03 19:04:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:04:13 --> Final output sent to browser
DEBUG - 2016-05-03 19:04:13 --> Total execution time: 0.1162
INFO - 2016-05-03 19:04:15 --> Config Class Initialized
INFO - 2016-05-03 19:04:15 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:04:15 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:04:15 --> Utf8 Class Initialized
INFO - 2016-05-03 19:04:15 --> URI Class Initialized
INFO - 2016-05-03 19:04:15 --> Router Class Initialized
INFO - 2016-05-03 19:04:15 --> Output Class Initialized
INFO - 2016-05-03 19:04:15 --> Security Class Initialized
DEBUG - 2016-05-03 19:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:04:15 --> Input Class Initialized
INFO - 2016-05-03 19:04:15 --> Language Class Initialized
INFO - 2016-05-03 19:04:15 --> Loader Class Initialized
INFO - 2016-05-03 19:04:15 --> Helper loaded: url_helper
INFO - 2016-05-03 19:04:15 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:04:15 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:04:15 --> Helper loaded: form_helper
INFO - 2016-05-03 19:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:04:15 --> Form Validation Class Initialized
INFO - 2016-05-03 19:04:15 --> Controller Class Initialized
INFO - 2016-05-03 19:04:15 --> Model Class Initialized
INFO - 2016-05-03 19:04:15 --> Database Driver Class Initialized
INFO - 2016-05-03 19:04:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:04:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:04:15 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:04:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:04:15 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:04:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProveedor.php
INFO - 2016-05-03 19:04:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:04:15 --> Final output sent to browser
DEBUG - 2016-05-03 19:04:15 --> Total execution time: 0.1355
INFO - 2016-05-03 19:04:29 --> Config Class Initialized
INFO - 2016-05-03 19:04:29 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:04:29 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:04:29 --> Utf8 Class Initialized
INFO - 2016-05-03 19:04:29 --> URI Class Initialized
INFO - 2016-05-03 19:04:29 --> Router Class Initialized
INFO - 2016-05-03 19:04:29 --> Output Class Initialized
INFO - 2016-05-03 19:04:29 --> Security Class Initialized
DEBUG - 2016-05-03 19:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:04:29 --> Input Class Initialized
INFO - 2016-05-03 19:04:29 --> Language Class Initialized
INFO - 2016-05-03 19:04:29 --> Loader Class Initialized
INFO - 2016-05-03 19:04:29 --> Helper loaded: url_helper
INFO - 2016-05-03 19:04:29 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:04:29 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:04:29 --> Helper loaded: form_helper
INFO - 2016-05-03 19:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:04:29 --> Form Validation Class Initialized
INFO - 2016-05-03 19:04:29 --> Controller Class Initialized
INFO - 2016-05-03 19:04:29 --> Model Class Initialized
INFO - 2016-05-03 19:04:29 --> Database Driver Class Initialized
INFO - 2016-05-03 19:04:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:04:29 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:04:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-03 19:04:29 --> Severity: Notice --> Undefined variable: proveedores C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 17
ERROR - 2016-05-03 19:04:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 17
INFO - 2016-05-03 19:04:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:04:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:04:29 --> Final output sent to browser
DEBUG - 2016-05-03 19:04:29 --> Total execution time: 0.1160
INFO - 2016-05-03 19:05:38 --> Config Class Initialized
INFO - 2016-05-03 19:05:38 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:05:38 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:05:38 --> Utf8 Class Initialized
INFO - 2016-05-03 19:05:38 --> URI Class Initialized
INFO - 2016-05-03 19:05:38 --> Router Class Initialized
INFO - 2016-05-03 19:05:38 --> Output Class Initialized
INFO - 2016-05-03 19:05:38 --> Security Class Initialized
DEBUG - 2016-05-03 19:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:05:38 --> Input Class Initialized
INFO - 2016-05-03 19:05:38 --> Language Class Initialized
INFO - 2016-05-03 19:05:38 --> Loader Class Initialized
INFO - 2016-05-03 19:05:38 --> Helper loaded: url_helper
INFO - 2016-05-03 19:05:38 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:05:38 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:05:38 --> Helper loaded: form_helper
INFO - 2016-05-03 19:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:05:38 --> Form Validation Class Initialized
INFO - 2016-05-03 19:05:38 --> Controller Class Initialized
INFO - 2016-05-03 19:05:38 --> Model Class Initialized
INFO - 2016-05-03 19:05:38 --> Database Driver Class Initialized
INFO - 2016-05-03 19:05:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:05:38 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:05:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-03 19:05:38 --> Severity: Notice --> Undefined variable: proveedores C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 17
ERROR - 2016-05-03 19:05:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 17
INFO - 2016-05-03 19:05:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:05:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:05:38 --> Final output sent to browser
DEBUG - 2016-05-03 19:05:38 --> Total execution time: 0.0808
INFO - 2016-05-03 19:06:10 --> Config Class Initialized
INFO - 2016-05-03 19:06:10 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:06:10 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:06:10 --> Utf8 Class Initialized
INFO - 2016-05-03 19:06:10 --> URI Class Initialized
INFO - 2016-05-03 19:06:10 --> Router Class Initialized
INFO - 2016-05-03 19:06:10 --> Output Class Initialized
INFO - 2016-05-03 19:06:10 --> Security Class Initialized
DEBUG - 2016-05-03 19:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:06:10 --> Input Class Initialized
INFO - 2016-05-03 19:06:10 --> Language Class Initialized
INFO - 2016-05-03 19:06:10 --> Loader Class Initialized
INFO - 2016-05-03 19:06:10 --> Helper loaded: url_helper
INFO - 2016-05-03 19:06:10 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:06:10 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:06:10 --> Helper loaded: form_helper
INFO - 2016-05-03 19:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:06:10 --> Form Validation Class Initialized
INFO - 2016-05-03 19:06:10 --> Controller Class Initialized
INFO - 2016-05-03 19:06:10 --> Model Class Initialized
INFO - 2016-05-03 19:06:10 --> Database Driver Class Initialized
INFO - 2016-05-03 19:06:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:06:10 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:06:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-03 19:06:10 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 24
ERROR - 2016-05-03 19:06:10 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 25
ERROR - 2016-05-03 19:06:10 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 29
ERROR - 2016-05-03 19:06:10 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 32
ERROR - 2016-05-03 19:06:10 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 45
ERROR - 2016-05-03 19:06:10 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 24
ERROR - 2016-05-03 19:06:10 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 25
ERROR - 2016-05-03 19:06:10 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 29
ERROR - 2016-05-03 19:06:10 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 32
ERROR - 2016-05-03 19:06:10 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 45
INFO - 2016-05-03 19:06:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:06:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:06:10 --> Final output sent to browser
DEBUG - 2016-05-03 19:06:10 --> Total execution time: 0.1042
INFO - 2016-05-03 19:06:35 --> Config Class Initialized
INFO - 2016-05-03 19:06:35 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:06:35 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:06:35 --> Utf8 Class Initialized
INFO - 2016-05-03 19:06:35 --> URI Class Initialized
INFO - 2016-05-03 19:06:35 --> Router Class Initialized
INFO - 2016-05-03 19:06:35 --> Output Class Initialized
INFO - 2016-05-03 19:06:35 --> Security Class Initialized
DEBUG - 2016-05-03 19:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:06:35 --> Input Class Initialized
INFO - 2016-05-03 19:06:35 --> Language Class Initialized
INFO - 2016-05-03 19:06:35 --> Loader Class Initialized
INFO - 2016-05-03 19:06:35 --> Helper loaded: url_helper
INFO - 2016-05-03 19:06:35 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:06:35 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:06:35 --> Helper loaded: form_helper
INFO - 2016-05-03 19:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:06:35 --> Form Validation Class Initialized
INFO - 2016-05-03 19:06:35 --> Controller Class Initialized
INFO - 2016-05-03 19:06:35 --> Model Class Initialized
INFO - 2016-05-03 19:06:35 --> Database Driver Class Initialized
INFO - 2016-05-03 19:06:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:06:35 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:06:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-03 19:06:35 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 32
ERROR - 2016-05-03 19:06:35 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 32
INFO - 2016-05-03 19:06:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:06:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:06:35 --> Final output sent to browser
DEBUG - 2016-05-03 19:06:35 --> Total execution time: 0.1309
INFO - 2016-05-03 19:07:10 --> Config Class Initialized
INFO - 2016-05-03 19:07:10 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:07:10 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:07:10 --> Utf8 Class Initialized
INFO - 2016-05-03 19:07:10 --> URI Class Initialized
INFO - 2016-05-03 19:07:10 --> Router Class Initialized
INFO - 2016-05-03 19:07:10 --> Output Class Initialized
INFO - 2016-05-03 19:07:10 --> Security Class Initialized
DEBUG - 2016-05-03 19:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:07:10 --> Input Class Initialized
INFO - 2016-05-03 19:07:10 --> Language Class Initialized
INFO - 2016-05-03 19:07:10 --> Loader Class Initialized
INFO - 2016-05-03 19:07:10 --> Helper loaded: url_helper
INFO - 2016-05-03 19:07:10 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:07:10 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:07:10 --> Helper loaded: form_helper
INFO - 2016-05-03 19:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:07:10 --> Form Validation Class Initialized
INFO - 2016-05-03 19:07:10 --> Controller Class Initialized
INFO - 2016-05-03 19:07:10 --> Model Class Initialized
INFO - 2016-05-03 19:07:10 --> Database Driver Class Initialized
INFO - 2016-05-03 19:07:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:07:10 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:07:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-03 19:07:10 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 32
ERROR - 2016-05-03 19:07:10 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 32
INFO - 2016-05-03 19:07:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:07:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:07:10 --> Final output sent to browser
DEBUG - 2016-05-03 19:07:10 --> Total execution time: 0.1708
INFO - 2016-05-03 19:07:23 --> Config Class Initialized
INFO - 2016-05-03 19:07:23 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:07:23 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:07:23 --> Utf8 Class Initialized
INFO - 2016-05-03 19:07:23 --> URI Class Initialized
INFO - 2016-05-03 19:07:23 --> Router Class Initialized
INFO - 2016-05-03 19:07:23 --> Output Class Initialized
INFO - 2016-05-03 19:07:23 --> Security Class Initialized
DEBUG - 2016-05-03 19:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:07:23 --> Input Class Initialized
INFO - 2016-05-03 19:07:23 --> Language Class Initialized
INFO - 2016-05-03 19:07:23 --> Loader Class Initialized
INFO - 2016-05-03 19:07:23 --> Helper loaded: url_helper
INFO - 2016-05-03 19:07:23 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:07:23 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:07:23 --> Helper loaded: form_helper
INFO - 2016-05-03 19:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:07:23 --> Form Validation Class Initialized
INFO - 2016-05-03 19:07:23 --> Controller Class Initialized
INFO - 2016-05-03 19:07:23 --> Model Class Initialized
INFO - 2016-05-03 19:07:23 --> Database Driver Class Initialized
INFO - 2016-05-03 19:07:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:07:23 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:07:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:07:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:07:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:07:23 --> Final output sent to browser
DEBUG - 2016-05-03 19:07:23 --> Total execution time: 0.0765
INFO - 2016-05-03 19:08:37 --> Config Class Initialized
INFO - 2016-05-03 19:08:37 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:08:37 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:08:37 --> Utf8 Class Initialized
INFO - 2016-05-03 19:08:37 --> URI Class Initialized
INFO - 2016-05-03 19:08:37 --> Router Class Initialized
INFO - 2016-05-03 19:08:37 --> Output Class Initialized
INFO - 2016-05-03 19:08:37 --> Security Class Initialized
DEBUG - 2016-05-03 19:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:08:37 --> Input Class Initialized
INFO - 2016-05-03 19:08:37 --> Language Class Initialized
INFO - 2016-05-03 19:08:37 --> Loader Class Initialized
INFO - 2016-05-03 19:08:37 --> Helper loaded: url_helper
INFO - 2016-05-03 19:08:37 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:08:37 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:08:37 --> Helper loaded: form_helper
INFO - 2016-05-03 19:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:08:37 --> Form Validation Class Initialized
INFO - 2016-05-03 19:08:37 --> Controller Class Initialized
INFO - 2016-05-03 19:08:37 --> Model Class Initialized
INFO - 2016-05-03 19:08:37 --> Database Driver Class Initialized
INFO - 2016-05-03 19:08:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:08:37 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:08:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:08:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:08:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:08:37 --> Final output sent to browser
DEBUG - 2016-05-03 19:08:37 --> Total execution time: 0.0751
INFO - 2016-05-03 19:08:47 --> Config Class Initialized
INFO - 2016-05-03 19:08:47 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:08:47 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:08:47 --> Utf8 Class Initialized
INFO - 2016-05-03 19:08:47 --> URI Class Initialized
INFO - 2016-05-03 19:08:47 --> Router Class Initialized
INFO - 2016-05-03 19:08:47 --> Output Class Initialized
INFO - 2016-05-03 19:08:47 --> Security Class Initialized
DEBUG - 2016-05-03 19:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:08:47 --> Input Class Initialized
INFO - 2016-05-03 19:08:47 --> Language Class Initialized
INFO - 2016-05-03 19:08:47 --> Loader Class Initialized
INFO - 2016-05-03 19:08:47 --> Helper loaded: url_helper
INFO - 2016-05-03 19:08:47 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:08:47 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:08:47 --> Helper loaded: form_helper
INFO - 2016-05-03 19:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:08:47 --> Form Validation Class Initialized
INFO - 2016-05-03 19:08:47 --> Controller Class Initialized
INFO - 2016-05-03 19:08:47 --> Model Class Initialized
INFO - 2016-05-03 19:08:47 --> Database Driver Class Initialized
INFO - 2016-05-03 19:08:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:08:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:08:47 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:08:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:08:47 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:08:48 --> Config Class Initialized
INFO - 2016-05-03 19:08:48 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:08:48 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:08:48 --> Utf8 Class Initialized
INFO - 2016-05-03 19:08:48 --> URI Class Initialized
INFO - 2016-05-03 19:08:48 --> Router Class Initialized
INFO - 2016-05-03 19:08:48 --> Output Class Initialized
INFO - 2016-05-03 19:08:48 --> Security Class Initialized
DEBUG - 2016-05-03 19:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:08:48 --> Input Class Initialized
INFO - 2016-05-03 19:08:48 --> Language Class Initialized
INFO - 2016-05-03 19:08:48 --> Loader Class Initialized
INFO - 2016-05-03 19:08:48 --> Helper loaded: url_helper
INFO - 2016-05-03 19:08:48 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:08:48 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:08:48 --> Helper loaded: form_helper
INFO - 2016-05-03 19:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:08:48 --> Form Validation Class Initialized
INFO - 2016-05-03 19:08:48 --> Controller Class Initialized
INFO - 2016-05-03 19:08:48 --> Model Class Initialized
INFO - 2016-05-03 19:08:48 --> Database Driver Class Initialized
INFO - 2016-05-03 19:08:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:08:48 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:08:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:08:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:08:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:08:48 --> Final output sent to browser
DEBUG - 2016-05-03 19:08:48 --> Total execution time: 0.0783
INFO - 2016-05-03 19:08:51 --> Config Class Initialized
INFO - 2016-05-03 19:08:51 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:08:51 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:08:51 --> Utf8 Class Initialized
INFO - 2016-05-03 19:08:51 --> URI Class Initialized
INFO - 2016-05-03 19:08:51 --> Router Class Initialized
INFO - 2016-05-03 19:08:51 --> Output Class Initialized
INFO - 2016-05-03 19:08:51 --> Security Class Initialized
DEBUG - 2016-05-03 19:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:08:51 --> Input Class Initialized
INFO - 2016-05-03 19:08:51 --> Language Class Initialized
INFO - 2016-05-03 19:08:51 --> Loader Class Initialized
INFO - 2016-05-03 19:08:51 --> Helper loaded: url_helper
INFO - 2016-05-03 19:08:51 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:08:51 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:08:51 --> Helper loaded: form_helper
INFO - 2016-05-03 19:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:08:51 --> Form Validation Class Initialized
INFO - 2016-05-03 19:08:51 --> Controller Class Initialized
INFO - 2016-05-03 19:08:51 --> Model Class Initialized
INFO - 2016-05-03 19:08:51 --> Database Driver Class Initialized
INFO - 2016-05-03 19:08:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:08:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:08:51 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:08:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:08:51 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:08:51 --> Config Class Initialized
INFO - 2016-05-03 19:08:51 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:08:51 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:08:51 --> Utf8 Class Initialized
INFO - 2016-05-03 19:08:51 --> URI Class Initialized
INFO - 2016-05-03 19:08:51 --> Router Class Initialized
INFO - 2016-05-03 19:08:51 --> Output Class Initialized
INFO - 2016-05-03 19:08:51 --> Security Class Initialized
DEBUG - 2016-05-03 19:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:08:51 --> Input Class Initialized
INFO - 2016-05-03 19:08:51 --> Language Class Initialized
INFO - 2016-05-03 19:08:51 --> Loader Class Initialized
INFO - 2016-05-03 19:08:51 --> Helper loaded: url_helper
INFO - 2016-05-03 19:08:51 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:08:51 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:08:51 --> Helper loaded: form_helper
INFO - 2016-05-03 19:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:08:51 --> Form Validation Class Initialized
INFO - 2016-05-03 19:08:51 --> Controller Class Initialized
INFO - 2016-05-03 19:08:51 --> Model Class Initialized
INFO - 2016-05-03 19:08:51 --> Database Driver Class Initialized
INFO - 2016-05-03 19:08:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:08:51 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:08:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:08:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:08:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:08:51 --> Final output sent to browser
DEBUG - 2016-05-03 19:08:51 --> Total execution time: 0.0907
INFO - 2016-05-03 19:09:23 --> Config Class Initialized
INFO - 2016-05-03 19:09:23 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:09:23 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:09:23 --> Utf8 Class Initialized
INFO - 2016-05-03 19:09:23 --> URI Class Initialized
INFO - 2016-05-03 19:09:23 --> Router Class Initialized
INFO - 2016-05-03 19:09:23 --> Output Class Initialized
INFO - 2016-05-03 19:09:23 --> Security Class Initialized
DEBUG - 2016-05-03 19:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:09:23 --> Input Class Initialized
INFO - 2016-05-03 19:09:23 --> Language Class Initialized
INFO - 2016-05-03 19:09:23 --> Loader Class Initialized
INFO - 2016-05-03 19:09:23 --> Helper loaded: url_helper
INFO - 2016-05-03 19:09:23 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:09:23 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:09:23 --> Helper loaded: form_helper
INFO - 2016-05-03 19:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:09:23 --> Form Validation Class Initialized
INFO - 2016-05-03 19:09:23 --> Controller Class Initialized
INFO - 2016-05-03 19:09:23 --> Model Class Initialized
INFO - 2016-05-03 19:09:23 --> Database Driver Class Initialized
INFO - 2016-05-03 19:09:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:09:23 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:09:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:09:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:09:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:09:23 --> Final output sent to browser
DEBUG - 2016-05-03 19:09:23 --> Total execution time: 0.0804
INFO - 2016-05-03 19:09:34 --> Config Class Initialized
INFO - 2016-05-03 19:09:34 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:09:34 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:09:34 --> Utf8 Class Initialized
INFO - 2016-05-03 19:09:34 --> URI Class Initialized
INFO - 2016-05-03 19:09:34 --> Router Class Initialized
INFO - 2016-05-03 19:09:34 --> Output Class Initialized
INFO - 2016-05-03 19:09:34 --> Security Class Initialized
DEBUG - 2016-05-03 19:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:09:34 --> Input Class Initialized
INFO - 2016-05-03 19:09:34 --> Language Class Initialized
INFO - 2016-05-03 19:09:34 --> Loader Class Initialized
INFO - 2016-05-03 19:09:34 --> Helper loaded: url_helper
INFO - 2016-05-03 19:09:34 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:09:34 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:09:34 --> Helper loaded: form_helper
INFO - 2016-05-03 19:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:09:34 --> Form Validation Class Initialized
INFO - 2016-05-03 19:09:34 --> Controller Class Initialized
INFO - 2016-05-03 19:09:34 --> Model Class Initialized
INFO - 2016-05-03 19:09:34 --> Database Driver Class Initialized
INFO - 2016-05-03 19:09:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:09:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:09:34 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:09:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:09:34 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:09:34 --> Config Class Initialized
INFO - 2016-05-03 19:09:34 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:09:34 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:09:34 --> Utf8 Class Initialized
INFO - 2016-05-03 19:09:34 --> URI Class Initialized
INFO - 2016-05-03 19:09:34 --> Router Class Initialized
INFO - 2016-05-03 19:09:34 --> Output Class Initialized
INFO - 2016-05-03 19:09:34 --> Security Class Initialized
DEBUG - 2016-05-03 19:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:09:34 --> Input Class Initialized
INFO - 2016-05-03 19:09:34 --> Language Class Initialized
INFO - 2016-05-03 19:09:34 --> Loader Class Initialized
INFO - 2016-05-03 19:09:34 --> Helper loaded: url_helper
INFO - 2016-05-03 19:09:34 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:09:34 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:09:34 --> Helper loaded: form_helper
INFO - 2016-05-03 19:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:09:34 --> Form Validation Class Initialized
INFO - 2016-05-03 19:09:34 --> Controller Class Initialized
INFO - 2016-05-03 19:09:34 --> Model Class Initialized
INFO - 2016-05-03 19:09:34 --> Database Driver Class Initialized
INFO - 2016-05-03 19:09:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:09:34 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:09:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:09:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:09:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:09:34 --> Final output sent to browser
DEBUG - 2016-05-03 19:09:34 --> Total execution time: 0.0837
INFO - 2016-05-03 19:09:38 --> Config Class Initialized
INFO - 2016-05-03 19:09:38 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:09:38 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:09:38 --> Utf8 Class Initialized
INFO - 2016-05-03 19:09:38 --> URI Class Initialized
INFO - 2016-05-03 19:09:38 --> Router Class Initialized
INFO - 2016-05-03 19:09:38 --> Output Class Initialized
INFO - 2016-05-03 19:09:38 --> Security Class Initialized
DEBUG - 2016-05-03 19:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:09:38 --> Input Class Initialized
INFO - 2016-05-03 19:09:38 --> Language Class Initialized
INFO - 2016-05-03 19:09:38 --> Loader Class Initialized
INFO - 2016-05-03 19:09:38 --> Helper loaded: url_helper
INFO - 2016-05-03 19:09:38 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:09:38 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:09:38 --> Helper loaded: form_helper
INFO - 2016-05-03 19:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:09:38 --> Form Validation Class Initialized
INFO - 2016-05-03 19:09:38 --> Controller Class Initialized
INFO - 2016-05-03 19:09:38 --> Model Class Initialized
INFO - 2016-05-03 19:09:38 --> Database Driver Class Initialized
INFO - 2016-05-03 19:09:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:09:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:09:38 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:09:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:09:38 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:09:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 19:09:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:09:38 --> Final output sent to browser
DEBUG - 2016-05-03 19:09:38 --> Total execution time: 0.0971
INFO - 2016-05-03 19:09:40 --> Config Class Initialized
INFO - 2016-05-03 19:09:40 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:09:40 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:09:40 --> Utf8 Class Initialized
INFO - 2016-05-03 19:09:40 --> URI Class Initialized
INFO - 2016-05-03 19:09:40 --> Router Class Initialized
INFO - 2016-05-03 19:09:40 --> Output Class Initialized
INFO - 2016-05-03 19:09:40 --> Security Class Initialized
DEBUG - 2016-05-03 19:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:09:40 --> Input Class Initialized
INFO - 2016-05-03 19:09:40 --> Language Class Initialized
INFO - 2016-05-03 19:09:40 --> Loader Class Initialized
INFO - 2016-05-03 19:09:40 --> Helper loaded: url_helper
INFO - 2016-05-03 19:09:40 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:09:40 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:09:40 --> Helper loaded: form_helper
INFO - 2016-05-03 19:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:09:40 --> Form Validation Class Initialized
INFO - 2016-05-03 19:09:40 --> Controller Class Initialized
INFO - 2016-05-03 19:09:40 --> Model Class Initialized
INFO - 2016-05-03 19:09:40 --> Database Driver Class Initialized
INFO - 2016-05-03 19:09:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:09:40 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:09:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:09:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:09:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:09:40 --> Final output sent to browser
DEBUG - 2016-05-03 19:09:40 --> Total execution time: 0.0977
INFO - 2016-05-03 19:10:32 --> Config Class Initialized
INFO - 2016-05-03 19:10:32 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:10:32 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:10:32 --> Utf8 Class Initialized
INFO - 2016-05-03 19:10:32 --> URI Class Initialized
INFO - 2016-05-03 19:10:32 --> Router Class Initialized
INFO - 2016-05-03 19:10:32 --> Output Class Initialized
INFO - 2016-05-03 19:10:32 --> Security Class Initialized
DEBUG - 2016-05-03 19:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:10:32 --> Input Class Initialized
INFO - 2016-05-03 19:10:32 --> Language Class Initialized
INFO - 2016-05-03 19:10:32 --> Loader Class Initialized
INFO - 2016-05-03 19:10:32 --> Helper loaded: url_helper
INFO - 2016-05-03 19:10:32 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:10:32 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:10:32 --> Helper loaded: form_helper
INFO - 2016-05-03 19:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:10:32 --> Form Validation Class Initialized
INFO - 2016-05-03 19:10:32 --> Controller Class Initialized
INFO - 2016-05-03 19:10:32 --> Model Class Initialized
INFO - 2016-05-03 19:10:32 --> Database Driver Class Initialized
INFO - 2016-05-03 19:10:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:10:32 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:10:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:10:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:10:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:10:32 --> Final output sent to browser
DEBUG - 2016-05-03 19:10:32 --> Total execution time: 0.0846
INFO - 2016-05-03 19:10:40 --> Config Class Initialized
INFO - 2016-05-03 19:10:40 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:10:40 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:10:40 --> Utf8 Class Initialized
INFO - 2016-05-03 19:10:40 --> URI Class Initialized
INFO - 2016-05-03 19:10:40 --> Router Class Initialized
INFO - 2016-05-03 19:10:40 --> Output Class Initialized
INFO - 2016-05-03 19:10:40 --> Security Class Initialized
DEBUG - 2016-05-03 19:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:10:40 --> Input Class Initialized
INFO - 2016-05-03 19:10:40 --> Language Class Initialized
INFO - 2016-05-03 19:10:40 --> Loader Class Initialized
INFO - 2016-05-03 19:10:40 --> Helper loaded: url_helper
INFO - 2016-05-03 19:10:40 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:10:40 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:10:40 --> Helper loaded: form_helper
INFO - 2016-05-03 19:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:10:40 --> Form Validation Class Initialized
INFO - 2016-05-03 19:10:40 --> Controller Class Initialized
INFO - 2016-05-03 19:10:40 --> Model Class Initialized
INFO - 2016-05-03 19:10:40 --> Database Driver Class Initialized
INFO - 2016-05-03 19:10:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:10:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:10:40 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:10:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:10:40 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:10:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 19:10:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:10:40 --> Final output sent to browser
DEBUG - 2016-05-03 19:10:40 --> Total execution time: 0.0966
INFO - 2016-05-03 19:10:47 --> Config Class Initialized
INFO - 2016-05-03 19:10:47 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:10:47 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:10:47 --> Utf8 Class Initialized
INFO - 2016-05-03 19:10:47 --> URI Class Initialized
INFO - 2016-05-03 19:10:47 --> Router Class Initialized
INFO - 2016-05-03 19:10:47 --> Output Class Initialized
INFO - 2016-05-03 19:10:47 --> Security Class Initialized
DEBUG - 2016-05-03 19:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:10:47 --> Input Class Initialized
INFO - 2016-05-03 19:10:47 --> Language Class Initialized
INFO - 2016-05-03 19:10:47 --> Loader Class Initialized
INFO - 2016-05-03 19:10:47 --> Helper loaded: url_helper
INFO - 2016-05-03 19:10:47 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:10:47 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:10:47 --> Helper loaded: form_helper
INFO - 2016-05-03 19:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:10:47 --> Form Validation Class Initialized
INFO - 2016-05-03 19:10:47 --> Controller Class Initialized
INFO - 2016-05-03 19:10:47 --> Model Class Initialized
INFO - 2016-05-03 19:10:47 --> Database Driver Class Initialized
INFO - 2016-05-03 19:10:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:10:47 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:10:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:10:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:10:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:10:47 --> Final output sent to browser
DEBUG - 2016-05-03 19:10:47 --> Total execution time: 0.0920
INFO - 2016-05-03 19:13:20 --> Config Class Initialized
INFO - 2016-05-03 19:13:20 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:13:20 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:13:20 --> Utf8 Class Initialized
INFO - 2016-05-03 19:13:20 --> URI Class Initialized
INFO - 2016-05-03 19:13:20 --> Router Class Initialized
INFO - 2016-05-03 19:13:20 --> Output Class Initialized
INFO - 2016-05-03 19:13:20 --> Security Class Initialized
DEBUG - 2016-05-03 19:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:13:20 --> Input Class Initialized
INFO - 2016-05-03 19:13:20 --> Language Class Initialized
INFO - 2016-05-03 19:13:20 --> Loader Class Initialized
INFO - 2016-05-03 19:13:20 --> Helper loaded: url_helper
INFO - 2016-05-03 19:13:20 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:13:20 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:13:20 --> Helper loaded: form_helper
INFO - 2016-05-03 19:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:13:20 --> Form Validation Class Initialized
INFO - 2016-05-03 19:13:20 --> Controller Class Initialized
INFO - 2016-05-03 19:13:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:13:20 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:13:20 --> Model Class Initialized
INFO - 2016-05-03 19:13:20 --> Database Driver Class Initialized
INFO - 2016-05-03 19:13:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-03 19:13:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:13:20 --> Final output sent to browser
DEBUG - 2016-05-03 19:13:20 --> Total execution time: 0.0858
INFO - 2016-05-03 19:13:38 --> Config Class Initialized
INFO - 2016-05-03 19:13:38 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:13:38 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:13:39 --> Utf8 Class Initialized
INFO - 2016-05-03 19:13:39 --> URI Class Initialized
INFO - 2016-05-03 19:13:39 --> Router Class Initialized
INFO - 2016-05-03 19:13:39 --> Output Class Initialized
INFO - 2016-05-03 19:13:39 --> Security Class Initialized
DEBUG - 2016-05-03 19:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:13:39 --> Input Class Initialized
INFO - 2016-05-03 19:13:39 --> Language Class Initialized
INFO - 2016-05-03 19:13:39 --> Loader Class Initialized
INFO - 2016-05-03 19:13:39 --> Helper loaded: url_helper
INFO - 2016-05-03 19:13:39 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:13:39 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:13:39 --> Helper loaded: form_helper
INFO - 2016-05-03 19:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:13:39 --> Form Validation Class Initialized
INFO - 2016-05-03 19:13:39 --> Controller Class Initialized
INFO - 2016-05-03 19:13:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:13:39 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:13:39 --> Model Class Initialized
INFO - 2016-05-03 19:13:39 --> Database Driver Class Initialized
INFO - 2016-05-03 19:13:39 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:13:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-03 19:13:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:13:39 --> Final output sent to browser
DEBUG - 2016-05-03 19:13:39 --> Total execution time: 0.2119
INFO - 2016-05-03 19:13:41 --> Config Class Initialized
INFO - 2016-05-03 19:13:41 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:13:41 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:13:41 --> Utf8 Class Initialized
INFO - 2016-05-03 19:13:41 --> URI Class Initialized
INFO - 2016-05-03 19:13:41 --> Router Class Initialized
INFO - 2016-05-03 19:13:41 --> Output Class Initialized
INFO - 2016-05-03 19:13:41 --> Security Class Initialized
DEBUG - 2016-05-03 19:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:13:41 --> Input Class Initialized
INFO - 2016-05-03 19:13:41 --> Language Class Initialized
INFO - 2016-05-03 19:13:41 --> Loader Class Initialized
INFO - 2016-05-03 19:13:41 --> Helper loaded: url_helper
INFO - 2016-05-03 19:13:41 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:13:41 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:13:41 --> Helper loaded: form_helper
INFO - 2016-05-03 19:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:13:41 --> Form Validation Class Initialized
INFO - 2016-05-03 19:13:41 --> Controller Class Initialized
INFO - 2016-05-03 19:13:41 --> Model Class Initialized
INFO - 2016-05-03 19:13:41 --> Database Driver Class Initialized
INFO - 2016-05-03 19:13:41 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:13:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:13:41 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:13:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:13:41 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:13:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 19:13:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:13:41 --> Final output sent to browser
DEBUG - 2016-05-03 19:13:41 --> Total execution time: 0.1106
INFO - 2016-05-03 19:13:54 --> Config Class Initialized
INFO - 2016-05-03 19:13:54 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:13:54 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:13:54 --> Utf8 Class Initialized
INFO - 2016-05-03 19:13:54 --> URI Class Initialized
INFO - 2016-05-03 19:13:54 --> Router Class Initialized
INFO - 2016-05-03 19:13:54 --> Output Class Initialized
INFO - 2016-05-03 19:13:54 --> Security Class Initialized
DEBUG - 2016-05-03 19:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:13:54 --> Input Class Initialized
INFO - 2016-05-03 19:13:54 --> Language Class Initialized
INFO - 2016-05-03 19:13:54 --> Loader Class Initialized
INFO - 2016-05-03 19:13:54 --> Helper loaded: url_helper
INFO - 2016-05-03 19:13:54 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:13:54 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:13:54 --> Helper loaded: form_helper
INFO - 2016-05-03 19:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:13:54 --> Form Validation Class Initialized
INFO - 2016-05-03 19:13:54 --> Controller Class Initialized
INFO - 2016-05-03 19:13:54 --> Model Class Initialized
INFO - 2016-05-03 19:13:54 --> Database Driver Class Initialized
INFO - 2016-05-03 19:13:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:13:55 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:13:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:13:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:13:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:13:55 --> Final output sent to browser
DEBUG - 2016-05-03 19:13:55 --> Total execution time: 0.0948
INFO - 2016-05-03 19:15:42 --> Config Class Initialized
INFO - 2016-05-03 19:15:42 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:15:42 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:15:42 --> Utf8 Class Initialized
INFO - 2016-05-03 19:15:42 --> URI Class Initialized
INFO - 2016-05-03 19:15:42 --> Router Class Initialized
INFO - 2016-05-03 19:15:42 --> Output Class Initialized
INFO - 2016-05-03 19:15:42 --> Security Class Initialized
DEBUG - 2016-05-03 19:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:15:42 --> Input Class Initialized
INFO - 2016-05-03 19:15:42 --> Language Class Initialized
INFO - 2016-05-03 19:15:42 --> Loader Class Initialized
INFO - 2016-05-03 19:15:42 --> Helper loaded: url_helper
INFO - 2016-05-03 19:15:42 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:15:42 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:15:42 --> Helper loaded: form_helper
INFO - 2016-05-03 19:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:15:42 --> Form Validation Class Initialized
INFO - 2016-05-03 19:15:42 --> Controller Class Initialized
INFO - 2016-05-03 19:15:42 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:15:42 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:15:42 --> Model Class Initialized
INFO - 2016-05-03 19:15:42 --> Database Driver Class Initialized
INFO - 2016-05-03 19:15:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-03 19:15:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:15:42 --> Final output sent to browser
DEBUG - 2016-05-03 19:15:42 --> Total execution time: 0.0971
INFO - 2016-05-03 19:16:07 --> Config Class Initialized
INFO - 2016-05-03 19:16:07 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:16:07 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:16:07 --> Utf8 Class Initialized
INFO - 2016-05-03 19:16:07 --> URI Class Initialized
INFO - 2016-05-03 19:16:07 --> Router Class Initialized
INFO - 2016-05-03 19:16:07 --> Output Class Initialized
INFO - 2016-05-03 19:16:07 --> Security Class Initialized
DEBUG - 2016-05-03 19:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:16:07 --> Input Class Initialized
INFO - 2016-05-03 19:16:07 --> Language Class Initialized
INFO - 2016-05-03 19:16:07 --> Loader Class Initialized
INFO - 2016-05-03 19:16:07 --> Helper loaded: url_helper
INFO - 2016-05-03 19:16:07 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:16:07 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:16:07 --> Helper loaded: form_helper
INFO - 2016-05-03 19:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:16:07 --> Form Validation Class Initialized
INFO - 2016-05-03 19:16:07 --> Controller Class Initialized
INFO - 2016-05-03 19:16:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:16:07 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:16:07 --> Model Class Initialized
INFO - 2016-05-03 19:16:07 --> Database Driver Class Initialized
INFO - 2016-05-03 19:16:07 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:16:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-03 19:16:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:16:07 --> Final output sent to browser
DEBUG - 2016-05-03 19:16:07 --> Total execution time: 0.1992
INFO - 2016-05-03 19:16:09 --> Config Class Initialized
INFO - 2016-05-03 19:16:09 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:16:09 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:16:09 --> Utf8 Class Initialized
INFO - 2016-05-03 19:16:09 --> URI Class Initialized
INFO - 2016-05-03 19:16:09 --> Router Class Initialized
INFO - 2016-05-03 19:16:09 --> Output Class Initialized
INFO - 2016-05-03 19:16:09 --> Security Class Initialized
DEBUG - 2016-05-03 19:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:16:09 --> Input Class Initialized
INFO - 2016-05-03 19:16:09 --> Language Class Initialized
INFO - 2016-05-03 19:16:09 --> Loader Class Initialized
INFO - 2016-05-03 19:16:09 --> Helper loaded: url_helper
INFO - 2016-05-03 19:16:09 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:16:09 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:16:09 --> Helper loaded: form_helper
INFO - 2016-05-03 19:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:16:09 --> Form Validation Class Initialized
INFO - 2016-05-03 19:16:09 --> Controller Class Initialized
INFO - 2016-05-03 19:16:09 --> Model Class Initialized
INFO - 2016-05-03 19:16:09 --> Database Driver Class Initialized
INFO - 2016-05-03 19:16:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:16:09 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:16:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:16:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:16:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:16:09 --> Final output sent to browser
DEBUG - 2016-05-03 19:16:09 --> Total execution time: 0.1217
INFO - 2016-05-03 19:21:07 --> Config Class Initialized
INFO - 2016-05-03 19:21:07 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:21:07 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:21:07 --> Utf8 Class Initialized
INFO - 2016-05-03 19:21:07 --> URI Class Initialized
INFO - 2016-05-03 19:21:07 --> Router Class Initialized
INFO - 2016-05-03 19:21:07 --> Output Class Initialized
INFO - 2016-05-03 19:21:07 --> Security Class Initialized
DEBUG - 2016-05-03 19:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:21:07 --> Input Class Initialized
INFO - 2016-05-03 19:21:07 --> Language Class Initialized
INFO - 2016-05-03 19:21:07 --> Loader Class Initialized
INFO - 2016-05-03 19:21:07 --> Helper loaded: url_helper
INFO - 2016-05-03 19:21:07 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:21:07 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:21:07 --> Helper loaded: form_helper
INFO - 2016-05-03 19:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:21:07 --> Form Validation Class Initialized
INFO - 2016-05-03 19:21:07 --> Controller Class Initialized
INFO - 2016-05-03 19:21:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:21:07 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:21:07 --> Model Class Initialized
INFO - 2016-05-03 19:21:07 --> Database Driver Class Initialized
INFO - 2016-05-03 19:21:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-03 19:21:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:21:07 --> Final output sent to browser
DEBUG - 2016-05-03 19:21:07 --> Total execution time: 0.1054
INFO - 2016-05-03 19:21:13 --> Config Class Initialized
INFO - 2016-05-03 19:21:13 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:21:13 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:21:13 --> Utf8 Class Initialized
INFO - 2016-05-03 19:21:13 --> URI Class Initialized
INFO - 2016-05-03 19:21:13 --> Router Class Initialized
INFO - 2016-05-03 19:21:13 --> Output Class Initialized
INFO - 2016-05-03 19:21:13 --> Security Class Initialized
DEBUG - 2016-05-03 19:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:21:13 --> Input Class Initialized
INFO - 2016-05-03 19:21:13 --> Language Class Initialized
INFO - 2016-05-03 19:21:13 --> Loader Class Initialized
INFO - 2016-05-03 19:21:13 --> Helper loaded: url_helper
INFO - 2016-05-03 19:21:13 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:21:13 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:21:13 --> Helper loaded: form_helper
INFO - 2016-05-03 19:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:21:13 --> Form Validation Class Initialized
INFO - 2016-05-03 19:21:13 --> Controller Class Initialized
INFO - 2016-05-03 19:21:13 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:21:13 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:21:13 --> Model Class Initialized
INFO - 2016-05-03 19:21:13 --> Database Driver Class Initialized
INFO - 2016-05-03 19:21:13 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:21:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-03 19:21:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:21:13 --> Final output sent to browser
DEBUG - 2016-05-03 19:21:13 --> Total execution time: 0.1863
INFO - 2016-05-03 19:24:52 --> Config Class Initialized
INFO - 2016-05-03 19:24:52 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:24:52 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:24:52 --> Utf8 Class Initialized
INFO - 2016-05-03 19:24:52 --> URI Class Initialized
INFO - 2016-05-03 19:24:52 --> Router Class Initialized
INFO - 2016-05-03 19:24:52 --> Output Class Initialized
INFO - 2016-05-03 19:24:52 --> Security Class Initialized
DEBUG - 2016-05-03 19:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:24:52 --> Input Class Initialized
INFO - 2016-05-03 19:24:52 --> Language Class Initialized
INFO - 2016-05-03 19:24:52 --> Loader Class Initialized
INFO - 2016-05-03 19:24:52 --> Helper loaded: url_helper
INFO - 2016-05-03 19:24:52 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:24:52 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:24:52 --> Helper loaded: form_helper
INFO - 2016-05-03 19:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:24:52 --> Form Validation Class Initialized
INFO - 2016-05-03 19:24:52 --> Controller Class Initialized
INFO - 2016-05-03 19:24:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:24:52 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:24:52 --> Model Class Initialized
INFO - 2016-05-03 19:24:52 --> Database Driver Class Initialized
INFO - 2016-05-03 19:24:52 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:24:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-03 19:24:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:24:52 --> Final output sent to browser
DEBUG - 2016-05-03 19:24:52 --> Total execution time: 0.0891
INFO - 2016-05-03 19:24:55 --> Config Class Initialized
INFO - 2016-05-03 19:24:55 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:24:55 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:24:55 --> Utf8 Class Initialized
INFO - 2016-05-03 19:24:55 --> URI Class Initialized
INFO - 2016-05-03 19:24:55 --> Router Class Initialized
INFO - 2016-05-03 19:24:55 --> Output Class Initialized
INFO - 2016-05-03 19:24:55 --> Security Class Initialized
DEBUG - 2016-05-03 19:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:24:55 --> Input Class Initialized
INFO - 2016-05-03 19:24:56 --> Language Class Initialized
INFO - 2016-05-03 19:24:56 --> Loader Class Initialized
INFO - 2016-05-03 19:24:56 --> Helper loaded: url_helper
INFO - 2016-05-03 19:24:56 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:24:56 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:24:56 --> Helper loaded: form_helper
INFO - 2016-05-03 19:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:24:56 --> Form Validation Class Initialized
INFO - 2016-05-03 19:24:56 --> Controller Class Initialized
INFO - 2016-05-03 19:24:56 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:24:56 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:24:56 --> Model Class Initialized
INFO - 2016-05-03 19:24:56 --> Database Driver Class Initialized
INFO - 2016-05-03 19:24:56 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:24:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-03 19:24:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:24:56 --> Final output sent to browser
DEBUG - 2016-05-03 19:24:56 --> Total execution time: 0.1919
INFO - 2016-05-03 19:26:35 --> Config Class Initialized
INFO - 2016-05-03 19:26:35 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:26:35 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:26:35 --> Utf8 Class Initialized
INFO - 2016-05-03 19:26:36 --> URI Class Initialized
INFO - 2016-05-03 19:26:36 --> Router Class Initialized
INFO - 2016-05-03 19:26:36 --> Output Class Initialized
INFO - 2016-05-03 19:26:36 --> Security Class Initialized
DEBUG - 2016-05-03 19:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:26:36 --> Input Class Initialized
INFO - 2016-05-03 19:26:36 --> Language Class Initialized
INFO - 2016-05-03 19:26:36 --> Loader Class Initialized
INFO - 2016-05-03 19:26:36 --> Helper loaded: url_helper
INFO - 2016-05-03 19:26:36 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:26:36 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:26:36 --> Helper loaded: form_helper
INFO - 2016-05-03 19:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:26:36 --> Form Validation Class Initialized
INFO - 2016-05-03 19:26:36 --> Controller Class Initialized
INFO - 2016-05-03 19:26:36 --> Model Class Initialized
INFO - 2016-05-03 19:26:36 --> Database Driver Class Initialized
INFO - 2016-05-03 19:26:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:26:36 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:26:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:26:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:26:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:26:36 --> Final output sent to browser
DEBUG - 2016-05-03 19:26:36 --> Total execution time: 0.1036
INFO - 2016-05-03 19:27:09 --> Config Class Initialized
INFO - 2016-05-03 19:27:09 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:27:09 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:27:09 --> Utf8 Class Initialized
INFO - 2016-05-03 19:27:09 --> URI Class Initialized
INFO - 2016-05-03 19:27:09 --> Router Class Initialized
INFO - 2016-05-03 19:27:09 --> Output Class Initialized
INFO - 2016-05-03 19:27:09 --> Security Class Initialized
DEBUG - 2016-05-03 19:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:27:09 --> Input Class Initialized
INFO - 2016-05-03 19:27:09 --> Language Class Initialized
INFO - 2016-05-03 19:27:09 --> Loader Class Initialized
INFO - 2016-05-03 19:27:09 --> Helper loaded: url_helper
INFO - 2016-05-03 19:27:09 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:27:09 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:27:09 --> Helper loaded: form_helper
INFO - 2016-05-03 19:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:27:09 --> Form Validation Class Initialized
INFO - 2016-05-03 19:27:09 --> Controller Class Initialized
INFO - 2016-05-03 19:27:09 --> Model Class Initialized
INFO - 2016-05-03 19:27:09 --> Database Driver Class Initialized
INFO - 2016-05-03 19:27:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:27:09 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:27:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:27:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:27:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:27:09 --> Final output sent to browser
DEBUG - 2016-05-03 19:27:09 --> Total execution time: 0.0751
INFO - 2016-05-03 19:27:12 --> Config Class Initialized
INFO - 2016-05-03 19:27:12 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:27:12 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:27:12 --> Utf8 Class Initialized
INFO - 2016-05-03 19:27:12 --> URI Class Initialized
INFO - 2016-05-03 19:27:12 --> Router Class Initialized
INFO - 2016-05-03 19:27:12 --> Output Class Initialized
INFO - 2016-05-03 19:27:12 --> Security Class Initialized
DEBUG - 2016-05-03 19:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:27:12 --> Input Class Initialized
INFO - 2016-05-03 19:27:12 --> Language Class Initialized
INFO - 2016-05-03 19:27:12 --> Loader Class Initialized
INFO - 2016-05-03 19:27:13 --> Helper loaded: url_helper
INFO - 2016-05-03 19:27:13 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:27:13 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:27:13 --> Helper loaded: form_helper
INFO - 2016-05-03 19:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:27:13 --> Form Validation Class Initialized
INFO - 2016-05-03 19:27:13 --> Controller Class Initialized
INFO - 2016-05-03 19:27:13 --> Model Class Initialized
INFO - 2016-05-03 19:27:13 --> Database Driver Class Initialized
INFO - 2016-05-03 19:27:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:27:13 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:27:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:27:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:27:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:27:13 --> Final output sent to browser
DEBUG - 2016-05-03 19:27:13 --> Total execution time: 0.1006
INFO - 2016-05-03 19:27:15 --> Config Class Initialized
INFO - 2016-05-03 19:27:15 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:27:15 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:27:15 --> Utf8 Class Initialized
INFO - 2016-05-03 19:27:15 --> URI Class Initialized
INFO - 2016-05-03 19:27:15 --> Router Class Initialized
INFO - 2016-05-03 19:27:15 --> Output Class Initialized
INFO - 2016-05-03 19:27:15 --> Security Class Initialized
DEBUG - 2016-05-03 19:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:27:15 --> Input Class Initialized
INFO - 2016-05-03 19:27:15 --> Language Class Initialized
INFO - 2016-05-03 19:27:15 --> Loader Class Initialized
INFO - 2016-05-03 19:27:15 --> Helper loaded: url_helper
INFO - 2016-05-03 19:27:15 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:27:15 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:27:15 --> Helper loaded: form_helper
INFO - 2016-05-03 19:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:27:15 --> Form Validation Class Initialized
INFO - 2016-05-03 19:27:15 --> Controller Class Initialized
INFO - 2016-05-03 19:27:15 --> Model Class Initialized
INFO - 2016-05-03 19:27:15 --> Database Driver Class Initialized
INFO - 2016-05-03 19:27:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:27:15 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:27:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:27:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:27:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:27:15 --> Final output sent to browser
DEBUG - 2016-05-03 19:27:15 --> Total execution time: 0.0925
INFO - 2016-05-03 19:27:28 --> Config Class Initialized
INFO - 2016-05-03 19:27:28 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:27:28 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:27:28 --> Utf8 Class Initialized
INFO - 2016-05-03 19:27:28 --> URI Class Initialized
INFO - 2016-05-03 19:27:28 --> Router Class Initialized
INFO - 2016-05-03 19:27:28 --> Output Class Initialized
INFO - 2016-05-03 19:27:28 --> Security Class Initialized
DEBUG - 2016-05-03 19:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:27:28 --> Input Class Initialized
INFO - 2016-05-03 19:27:28 --> Language Class Initialized
INFO - 2016-05-03 19:27:28 --> Loader Class Initialized
INFO - 2016-05-03 19:27:28 --> Helper loaded: url_helper
INFO - 2016-05-03 19:27:28 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:27:28 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:27:28 --> Helper loaded: form_helper
INFO - 2016-05-03 19:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:27:28 --> Form Validation Class Initialized
INFO - 2016-05-03 19:27:28 --> Controller Class Initialized
INFO - 2016-05-03 19:27:28 --> Model Class Initialized
INFO - 2016-05-03 19:27:28 --> Database Driver Class Initialized
INFO - 2016-05-03 19:27:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:27:28 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:27:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:27:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:27:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:27:28 --> Final output sent to browser
DEBUG - 2016-05-03 19:27:28 --> Total execution time: 0.0891
INFO - 2016-05-03 19:27:32 --> Config Class Initialized
INFO - 2016-05-03 19:27:32 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:27:32 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:27:32 --> Utf8 Class Initialized
INFO - 2016-05-03 19:27:32 --> URI Class Initialized
INFO - 2016-05-03 19:27:32 --> Router Class Initialized
INFO - 2016-05-03 19:27:32 --> Output Class Initialized
INFO - 2016-05-03 19:27:32 --> Security Class Initialized
DEBUG - 2016-05-03 19:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:27:32 --> Input Class Initialized
INFO - 2016-05-03 19:27:32 --> Language Class Initialized
INFO - 2016-05-03 19:27:32 --> Loader Class Initialized
INFO - 2016-05-03 19:27:32 --> Helper loaded: url_helper
INFO - 2016-05-03 19:27:32 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:27:32 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:27:32 --> Helper loaded: form_helper
INFO - 2016-05-03 19:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:27:32 --> Form Validation Class Initialized
INFO - 2016-05-03 19:27:32 --> Controller Class Initialized
INFO - 2016-05-03 19:27:32 --> Model Class Initialized
INFO - 2016-05-03 19:27:32 --> Database Driver Class Initialized
INFO - 2016-05-03 19:27:32 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:27:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:27:32 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:27:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:27:32 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:27:32 --> Config Class Initialized
INFO - 2016-05-03 19:27:32 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:27:33 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:27:33 --> Utf8 Class Initialized
INFO - 2016-05-03 19:27:33 --> URI Class Initialized
INFO - 2016-05-03 19:27:33 --> Router Class Initialized
INFO - 2016-05-03 19:27:33 --> Output Class Initialized
INFO - 2016-05-03 19:27:33 --> Security Class Initialized
DEBUG - 2016-05-03 19:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:27:33 --> Input Class Initialized
INFO - 2016-05-03 19:27:33 --> Language Class Initialized
INFO - 2016-05-03 19:27:33 --> Loader Class Initialized
INFO - 2016-05-03 19:27:33 --> Helper loaded: url_helper
INFO - 2016-05-03 19:27:33 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:27:33 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:27:33 --> Helper loaded: form_helper
INFO - 2016-05-03 19:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:27:33 --> Form Validation Class Initialized
INFO - 2016-05-03 19:27:33 --> Controller Class Initialized
INFO - 2016-05-03 19:27:33 --> Model Class Initialized
INFO - 2016-05-03 19:27:33 --> Database Driver Class Initialized
INFO - 2016-05-03 19:27:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:27:33 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:27:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:27:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:27:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:27:33 --> Final output sent to browser
DEBUG - 2016-05-03 19:27:33 --> Total execution time: 0.0812
INFO - 2016-05-03 19:27:35 --> Config Class Initialized
INFO - 2016-05-03 19:27:35 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:27:35 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:27:35 --> Utf8 Class Initialized
INFO - 2016-05-03 19:27:35 --> URI Class Initialized
INFO - 2016-05-03 19:27:35 --> Router Class Initialized
INFO - 2016-05-03 19:27:35 --> Output Class Initialized
INFO - 2016-05-03 19:27:35 --> Security Class Initialized
DEBUG - 2016-05-03 19:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:27:35 --> Input Class Initialized
INFO - 2016-05-03 19:27:35 --> Language Class Initialized
INFO - 2016-05-03 19:27:35 --> Loader Class Initialized
INFO - 2016-05-03 19:27:35 --> Helper loaded: url_helper
INFO - 2016-05-03 19:27:35 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:27:35 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:27:35 --> Helper loaded: form_helper
INFO - 2016-05-03 19:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:27:35 --> Form Validation Class Initialized
INFO - 2016-05-03 19:27:35 --> Controller Class Initialized
INFO - 2016-05-03 19:27:35 --> Model Class Initialized
INFO - 2016-05-03 19:27:35 --> Database Driver Class Initialized
INFO - 2016-05-03 19:27:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:27:35 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:27:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:27:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:27:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:27:35 --> Final output sent to browser
DEBUG - 2016-05-03 19:27:35 --> Total execution time: 0.0758
INFO - 2016-05-03 19:28:22 --> Config Class Initialized
INFO - 2016-05-03 19:28:22 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:28:22 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:28:22 --> Utf8 Class Initialized
INFO - 2016-05-03 19:28:22 --> URI Class Initialized
INFO - 2016-05-03 19:28:22 --> Router Class Initialized
INFO - 2016-05-03 19:28:22 --> Output Class Initialized
INFO - 2016-05-03 19:28:22 --> Security Class Initialized
DEBUG - 2016-05-03 19:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:28:22 --> Input Class Initialized
INFO - 2016-05-03 19:28:22 --> Language Class Initialized
INFO - 2016-05-03 19:28:22 --> Loader Class Initialized
INFO - 2016-05-03 19:28:22 --> Helper loaded: url_helper
INFO - 2016-05-03 19:28:22 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:28:22 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:28:22 --> Helper loaded: form_helper
INFO - 2016-05-03 19:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:28:22 --> Form Validation Class Initialized
INFO - 2016-05-03 19:28:22 --> Controller Class Initialized
INFO - 2016-05-03 19:28:22 --> Model Class Initialized
INFO - 2016-05-03 19:28:22 --> Database Driver Class Initialized
INFO - 2016-05-03 19:28:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:28:22 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:28:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:28:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:28:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:28:22 --> Final output sent to browser
DEBUG - 2016-05-03 19:28:22 --> Total execution time: 0.1053
INFO - 2016-05-03 19:28:29 --> Config Class Initialized
INFO - 2016-05-03 19:28:29 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:28:29 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:28:29 --> Utf8 Class Initialized
INFO - 2016-05-03 19:28:29 --> URI Class Initialized
INFO - 2016-05-03 19:28:29 --> Router Class Initialized
INFO - 2016-05-03 19:28:29 --> Output Class Initialized
INFO - 2016-05-03 19:28:29 --> Security Class Initialized
DEBUG - 2016-05-03 19:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:28:29 --> Input Class Initialized
INFO - 2016-05-03 19:28:29 --> Language Class Initialized
INFO - 2016-05-03 19:28:29 --> Loader Class Initialized
INFO - 2016-05-03 19:28:29 --> Helper loaded: url_helper
INFO - 2016-05-03 19:28:29 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:28:29 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:28:29 --> Helper loaded: form_helper
INFO - 2016-05-03 19:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:28:29 --> Form Validation Class Initialized
INFO - 2016-05-03 19:28:29 --> Controller Class Initialized
INFO - 2016-05-03 19:28:29 --> Model Class Initialized
INFO - 2016-05-03 19:28:29 --> Database Driver Class Initialized
INFO - 2016-05-03 19:28:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:28:29 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:28:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:28:30 --> Config Class Initialized
INFO - 2016-05-03 19:28:30 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:28:30 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:28:30 --> Utf8 Class Initialized
INFO - 2016-05-03 19:28:30 --> URI Class Initialized
INFO - 2016-05-03 19:28:30 --> Router Class Initialized
INFO - 2016-05-03 19:28:30 --> Output Class Initialized
INFO - 2016-05-03 19:28:30 --> Security Class Initialized
DEBUG - 2016-05-03 19:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:28:30 --> Input Class Initialized
INFO - 2016-05-03 19:28:30 --> Language Class Initialized
INFO - 2016-05-03 19:28:30 --> Loader Class Initialized
INFO - 2016-05-03 19:28:30 --> Helper loaded: url_helper
INFO - 2016-05-03 19:28:30 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:28:30 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:28:30 --> Helper loaded: form_helper
INFO - 2016-05-03 19:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:28:30 --> Form Validation Class Initialized
INFO - 2016-05-03 19:28:30 --> Controller Class Initialized
INFO - 2016-05-03 19:28:30 --> Model Class Initialized
INFO - 2016-05-03 19:28:30 --> Database Driver Class Initialized
INFO - 2016-05-03 19:28:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:28:30 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:28:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-03 19:28:30 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 53
ERROR - 2016-05-03 19:28:30 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 69
INFO - 2016-05-03 19:28:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:28:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:28:30 --> Final output sent to browser
DEBUG - 2016-05-03 19:28:30 --> Total execution time: 0.1097
INFO - 2016-05-03 19:28:49 --> Config Class Initialized
INFO - 2016-05-03 19:28:49 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:28:49 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:28:49 --> Utf8 Class Initialized
INFO - 2016-05-03 19:28:49 --> URI Class Initialized
INFO - 2016-05-03 19:28:49 --> Router Class Initialized
INFO - 2016-05-03 19:28:49 --> Output Class Initialized
INFO - 2016-05-03 19:28:49 --> Security Class Initialized
DEBUG - 2016-05-03 19:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:28:49 --> Input Class Initialized
INFO - 2016-05-03 19:28:49 --> Language Class Initialized
INFO - 2016-05-03 19:28:49 --> Loader Class Initialized
INFO - 2016-05-03 19:28:49 --> Helper loaded: url_helper
INFO - 2016-05-03 19:28:49 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:28:49 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:28:49 --> Helper loaded: form_helper
INFO - 2016-05-03 19:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:28:49 --> Form Validation Class Initialized
INFO - 2016-05-03 19:28:49 --> Controller Class Initialized
INFO - 2016-05-03 19:28:49 --> Model Class Initialized
INFO - 2016-05-03 19:28:49 --> Database Driver Class Initialized
INFO - 2016-05-03 19:28:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:28:49 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:28:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-03 19:28:49 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 53
ERROR - 2016-05-03 19:28:49 --> Severity: Notice --> Undefined index: idCategorias C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 69
INFO - 2016-05-03 19:28:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:28:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:28:49 --> Final output sent to browser
DEBUG - 2016-05-03 19:28:49 --> Total execution time: 0.0895
INFO - 2016-05-03 19:28:58 --> Config Class Initialized
INFO - 2016-05-03 19:28:58 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:28:58 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:28:58 --> Utf8 Class Initialized
INFO - 2016-05-03 19:28:58 --> URI Class Initialized
INFO - 2016-05-03 19:28:58 --> Router Class Initialized
INFO - 2016-05-03 19:28:58 --> Output Class Initialized
INFO - 2016-05-03 19:28:58 --> Security Class Initialized
DEBUG - 2016-05-03 19:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:28:58 --> Input Class Initialized
INFO - 2016-05-03 19:28:58 --> Language Class Initialized
INFO - 2016-05-03 19:28:58 --> Loader Class Initialized
INFO - 2016-05-03 19:28:58 --> Helper loaded: url_helper
INFO - 2016-05-03 19:28:58 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:28:58 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:28:58 --> Helper loaded: form_helper
INFO - 2016-05-03 19:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:28:58 --> Form Validation Class Initialized
INFO - 2016-05-03 19:28:58 --> Controller Class Initialized
INFO - 2016-05-03 19:28:58 --> Model Class Initialized
INFO - 2016-05-03 19:28:58 --> Database Driver Class Initialized
INFO - 2016-05-03 19:28:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:28:58 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:28:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-03 19:28:58 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 53
ERROR - 2016-05-03 19:28:58 --> Severity: Notice --> Undefined index: idCategorias C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 69
INFO - 2016-05-03 19:28:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:28:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:28:58 --> Final output sent to browser
DEBUG - 2016-05-03 19:28:58 --> Total execution time: 0.1116
INFO - 2016-05-03 19:29:12 --> Config Class Initialized
INFO - 2016-05-03 19:29:12 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:29:12 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:29:12 --> Utf8 Class Initialized
INFO - 2016-05-03 19:29:12 --> URI Class Initialized
INFO - 2016-05-03 19:29:12 --> Router Class Initialized
INFO - 2016-05-03 19:29:12 --> Output Class Initialized
INFO - 2016-05-03 19:29:12 --> Security Class Initialized
DEBUG - 2016-05-03 19:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:29:12 --> Input Class Initialized
INFO - 2016-05-03 19:29:12 --> Language Class Initialized
INFO - 2016-05-03 19:29:13 --> Loader Class Initialized
INFO - 2016-05-03 19:29:13 --> Helper loaded: url_helper
INFO - 2016-05-03 19:29:13 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:29:13 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:29:13 --> Helper loaded: form_helper
INFO - 2016-05-03 19:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:29:13 --> Form Validation Class Initialized
INFO - 2016-05-03 19:29:13 --> Controller Class Initialized
INFO - 2016-05-03 19:29:13 --> Model Class Initialized
INFO - 2016-05-03 19:29:13 --> Database Driver Class Initialized
INFO - 2016-05-03 19:29:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:29:13 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:29:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-03 19:29:13 --> Severity: Notice --> Undefined index: idCategorias C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 53
ERROR - 2016-05-03 19:29:13 --> Severity: Notice --> Undefined index: idCategorias C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 69
INFO - 2016-05-03 19:29:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:29:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:29:13 --> Final output sent to browser
DEBUG - 2016-05-03 19:29:13 --> Total execution time: 0.1027
INFO - 2016-05-03 19:29:19 --> Config Class Initialized
INFO - 2016-05-03 19:29:19 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:29:19 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:29:19 --> Utf8 Class Initialized
INFO - 2016-05-03 19:29:19 --> URI Class Initialized
INFO - 2016-05-03 19:29:19 --> Router Class Initialized
INFO - 2016-05-03 19:29:19 --> Output Class Initialized
INFO - 2016-05-03 19:29:19 --> Security Class Initialized
DEBUG - 2016-05-03 19:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:29:19 --> Input Class Initialized
INFO - 2016-05-03 19:29:19 --> Language Class Initialized
INFO - 2016-05-03 19:29:19 --> Loader Class Initialized
INFO - 2016-05-03 19:29:19 --> Helper loaded: url_helper
INFO - 2016-05-03 19:29:19 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:29:19 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:29:19 --> Helper loaded: form_helper
INFO - 2016-05-03 19:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:29:19 --> Form Validation Class Initialized
INFO - 2016-05-03 19:29:19 --> Controller Class Initialized
INFO - 2016-05-03 19:29:19 --> Model Class Initialized
INFO - 2016-05-03 19:29:19 --> Database Driver Class Initialized
INFO - 2016-05-03 19:29:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:29:19 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:29:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-03 19:29:19 --> Severity: Notice --> Undefined index: idCategorias C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 69
INFO - 2016-05-03 19:29:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:29:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:29:19 --> Final output sent to browser
DEBUG - 2016-05-03 19:29:19 --> Total execution time: 0.1095
INFO - 2016-05-03 19:29:24 --> Config Class Initialized
INFO - 2016-05-03 19:29:24 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:29:24 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:29:24 --> Utf8 Class Initialized
INFO - 2016-05-03 19:29:24 --> URI Class Initialized
INFO - 2016-05-03 19:29:24 --> Router Class Initialized
INFO - 2016-05-03 19:29:24 --> Output Class Initialized
INFO - 2016-05-03 19:29:24 --> Security Class Initialized
DEBUG - 2016-05-03 19:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:29:24 --> Input Class Initialized
INFO - 2016-05-03 19:29:24 --> Language Class Initialized
INFO - 2016-05-03 19:29:24 --> Loader Class Initialized
INFO - 2016-05-03 19:29:24 --> Helper loaded: url_helper
INFO - 2016-05-03 19:29:24 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:29:24 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:29:24 --> Helper loaded: form_helper
INFO - 2016-05-03 19:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:29:24 --> Form Validation Class Initialized
INFO - 2016-05-03 19:29:24 --> Controller Class Initialized
INFO - 2016-05-03 19:29:24 --> Model Class Initialized
INFO - 2016-05-03 19:29:24 --> Database Driver Class Initialized
INFO - 2016-05-03 19:29:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:29:24 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:29:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:29:24 --> Config Class Initialized
INFO - 2016-05-03 19:29:24 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:29:24 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:29:24 --> Utf8 Class Initialized
INFO - 2016-05-03 19:29:24 --> URI Class Initialized
INFO - 2016-05-03 19:29:24 --> Router Class Initialized
INFO - 2016-05-03 19:29:24 --> Output Class Initialized
INFO - 2016-05-03 19:29:24 --> Security Class Initialized
DEBUG - 2016-05-03 19:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:29:24 --> Input Class Initialized
INFO - 2016-05-03 19:29:24 --> Language Class Initialized
INFO - 2016-05-03 19:29:24 --> Loader Class Initialized
INFO - 2016-05-03 19:29:24 --> Helper loaded: url_helper
INFO - 2016-05-03 19:29:24 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:29:24 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:29:24 --> Helper loaded: form_helper
INFO - 2016-05-03 19:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:29:24 --> Form Validation Class Initialized
INFO - 2016-05-03 19:29:24 --> Controller Class Initialized
INFO - 2016-05-03 19:29:24 --> Model Class Initialized
INFO - 2016-05-03 19:29:24 --> Database Driver Class Initialized
INFO - 2016-05-03 19:29:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:29:24 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:29:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-03 19:29:24 --> Severity: Notice --> Undefined index: idCategorias C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 69
ERROR - 2016-05-03 19:29:24 --> Severity: Notice --> Undefined index: idCategorias C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php 69
INFO - 2016-05-03 19:29:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:29:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:29:24 --> Final output sent to browser
DEBUG - 2016-05-03 19:29:24 --> Total execution time: 0.0934
INFO - 2016-05-03 19:29:47 --> Config Class Initialized
INFO - 2016-05-03 19:29:47 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:29:47 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:29:47 --> Utf8 Class Initialized
INFO - 2016-05-03 19:29:47 --> URI Class Initialized
INFO - 2016-05-03 19:29:47 --> Router Class Initialized
INFO - 2016-05-03 19:29:47 --> Output Class Initialized
INFO - 2016-05-03 19:29:47 --> Security Class Initialized
DEBUG - 2016-05-03 19:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:29:47 --> Input Class Initialized
INFO - 2016-05-03 19:29:47 --> Language Class Initialized
INFO - 2016-05-03 19:29:47 --> Loader Class Initialized
INFO - 2016-05-03 19:29:47 --> Helper loaded: url_helper
INFO - 2016-05-03 19:29:47 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:29:47 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:29:47 --> Helper loaded: form_helper
INFO - 2016-05-03 19:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:29:47 --> Form Validation Class Initialized
INFO - 2016-05-03 19:29:47 --> Controller Class Initialized
INFO - 2016-05-03 19:29:47 --> Model Class Initialized
INFO - 2016-05-03 19:29:47 --> Database Driver Class Initialized
INFO - 2016-05-03 19:29:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:29:47 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:29:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:29:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:29:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:29:47 --> Final output sent to browser
DEBUG - 2016-05-03 19:29:47 --> Total execution time: 0.0994
INFO - 2016-05-03 19:29:52 --> Config Class Initialized
INFO - 2016-05-03 19:29:52 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:29:52 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:29:52 --> Utf8 Class Initialized
INFO - 2016-05-03 19:29:52 --> URI Class Initialized
INFO - 2016-05-03 19:29:52 --> Router Class Initialized
INFO - 2016-05-03 19:29:52 --> Output Class Initialized
INFO - 2016-05-03 19:29:52 --> Security Class Initialized
DEBUG - 2016-05-03 19:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:29:52 --> Input Class Initialized
INFO - 2016-05-03 19:29:52 --> Language Class Initialized
INFO - 2016-05-03 19:29:52 --> Loader Class Initialized
INFO - 2016-05-03 19:29:52 --> Helper loaded: url_helper
INFO - 2016-05-03 19:29:52 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:29:52 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:29:52 --> Helper loaded: form_helper
INFO - 2016-05-03 19:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:29:52 --> Form Validation Class Initialized
INFO - 2016-05-03 19:29:52 --> Controller Class Initialized
INFO - 2016-05-03 19:29:52 --> Model Class Initialized
INFO - 2016-05-03 19:29:52 --> Database Driver Class Initialized
INFO - 2016-05-03 19:29:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:29:52 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:29:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:29:52 --> Config Class Initialized
INFO - 2016-05-03 19:29:52 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:29:52 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:29:52 --> Utf8 Class Initialized
INFO - 2016-05-03 19:29:52 --> URI Class Initialized
INFO - 2016-05-03 19:29:52 --> Router Class Initialized
INFO - 2016-05-03 19:29:52 --> Output Class Initialized
INFO - 2016-05-03 19:29:52 --> Security Class Initialized
DEBUG - 2016-05-03 19:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:29:52 --> Input Class Initialized
INFO - 2016-05-03 19:29:52 --> Language Class Initialized
INFO - 2016-05-03 19:29:52 --> Loader Class Initialized
INFO - 2016-05-03 19:29:52 --> Helper loaded: url_helper
INFO - 2016-05-03 19:29:52 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:29:52 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:29:52 --> Helper loaded: form_helper
INFO - 2016-05-03 19:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:29:52 --> Form Validation Class Initialized
INFO - 2016-05-03 19:29:52 --> Controller Class Initialized
INFO - 2016-05-03 19:29:52 --> Model Class Initialized
INFO - 2016-05-03 19:29:52 --> Database Driver Class Initialized
INFO - 2016-05-03 19:29:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:29:52 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:29:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:29:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:29:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:29:52 --> Final output sent to browser
DEBUG - 2016-05-03 19:29:52 --> Total execution time: 0.0764
INFO - 2016-05-03 19:37:53 --> Config Class Initialized
INFO - 2016-05-03 19:37:53 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:37:53 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:37:53 --> Utf8 Class Initialized
INFO - 2016-05-03 19:37:53 --> URI Class Initialized
INFO - 2016-05-03 19:37:53 --> Router Class Initialized
INFO - 2016-05-03 19:37:53 --> Output Class Initialized
INFO - 2016-05-03 19:37:53 --> Security Class Initialized
DEBUG - 2016-05-03 19:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:37:53 --> Input Class Initialized
INFO - 2016-05-03 19:37:53 --> Language Class Initialized
INFO - 2016-05-03 19:37:53 --> Loader Class Initialized
INFO - 2016-05-03 19:37:53 --> Helper loaded: url_helper
INFO - 2016-05-03 19:37:53 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:37:53 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:37:53 --> Helper loaded: form_helper
INFO - 2016-05-03 19:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:37:53 --> Form Validation Class Initialized
INFO - 2016-05-03 19:37:53 --> Controller Class Initialized
INFO - 2016-05-03 19:37:53 --> Model Class Initialized
INFO - 2016-05-03 19:37:53 --> Database Driver Class Initialized
INFO - 2016-05-03 19:37:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:37:53 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:37:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:37:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:37:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:37:53 --> Final output sent to browser
DEBUG - 2016-05-03 19:37:53 --> Total execution time: 0.0859
INFO - 2016-05-03 19:37:55 --> Config Class Initialized
INFO - 2016-05-03 19:37:55 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:37:55 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:37:55 --> Utf8 Class Initialized
INFO - 2016-05-03 19:37:55 --> URI Class Initialized
INFO - 2016-05-03 19:37:55 --> Router Class Initialized
INFO - 2016-05-03 19:37:55 --> Output Class Initialized
INFO - 2016-05-03 19:37:55 --> Security Class Initialized
DEBUG - 2016-05-03 19:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:37:55 --> Input Class Initialized
INFO - 2016-05-03 19:37:55 --> Language Class Initialized
INFO - 2016-05-03 19:37:55 --> Loader Class Initialized
INFO - 2016-05-03 19:37:55 --> Helper loaded: url_helper
INFO - 2016-05-03 19:37:55 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:37:55 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:37:55 --> Helper loaded: form_helper
INFO - 2016-05-03 19:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:37:55 --> Form Validation Class Initialized
INFO - 2016-05-03 19:37:55 --> Controller Class Initialized
INFO - 2016-05-03 19:37:55 --> Model Class Initialized
INFO - 2016-05-03 19:37:55 --> Database Driver Class Initialized
INFO - 2016-05-03 19:37:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:37:55 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:37:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-03 19:37:55 --> Severity: Error --> Call to undefined method Categorias::NombreCategoria_unico_check() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Categorias.php 90
INFO - 2016-05-03 19:39:29 --> Config Class Initialized
INFO - 2016-05-03 19:39:29 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:39:29 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:39:29 --> Utf8 Class Initialized
INFO - 2016-05-03 19:39:29 --> URI Class Initialized
INFO - 2016-05-03 19:39:29 --> Router Class Initialized
INFO - 2016-05-03 19:39:29 --> Output Class Initialized
INFO - 2016-05-03 19:39:29 --> Security Class Initialized
DEBUG - 2016-05-03 19:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:39:29 --> Input Class Initialized
INFO - 2016-05-03 19:39:29 --> Language Class Initialized
INFO - 2016-05-03 19:39:29 --> Loader Class Initialized
INFO - 2016-05-03 19:39:29 --> Helper loaded: url_helper
INFO - 2016-05-03 19:39:29 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:39:29 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:39:29 --> Helper loaded: form_helper
INFO - 2016-05-03 19:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:39:29 --> Form Validation Class Initialized
INFO - 2016-05-03 19:39:29 --> Controller Class Initialized
INFO - 2016-05-03 19:39:29 --> Model Class Initialized
INFO - 2016-05-03 19:39:29 --> Database Driver Class Initialized
INFO - 2016-05-03 19:39:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:39:29 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:39:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-03 19:39:29 --> Severity: Notice --> Undefined variable: selectProvincias C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProveedor.php 53
INFO - 2016-05-03 19:39:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProveedor.php
INFO - 2016-05-03 19:39:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:39:29 --> Final output sent to browser
DEBUG - 2016-05-03 19:39:29 --> Total execution time: 0.0809
INFO - 2016-05-03 19:39:50 --> Config Class Initialized
INFO - 2016-05-03 19:39:50 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:39:50 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:39:50 --> Utf8 Class Initialized
INFO - 2016-05-03 19:39:50 --> URI Class Initialized
INFO - 2016-05-03 19:39:50 --> Router Class Initialized
INFO - 2016-05-03 19:39:50 --> Output Class Initialized
INFO - 2016-05-03 19:39:50 --> Security Class Initialized
DEBUG - 2016-05-03 19:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:39:50 --> Input Class Initialized
INFO - 2016-05-03 19:39:50 --> Language Class Initialized
INFO - 2016-05-03 19:39:50 --> Loader Class Initialized
INFO - 2016-05-03 19:39:50 --> Helper loaded: url_helper
INFO - 2016-05-03 19:39:50 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:39:50 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:39:50 --> Helper loaded: form_helper
INFO - 2016-05-03 19:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:39:50 --> Form Validation Class Initialized
INFO - 2016-05-03 19:39:50 --> Controller Class Initialized
INFO - 2016-05-03 19:39:50 --> Model Class Initialized
INFO - 2016-05-03 19:39:50 --> Database Driver Class Initialized
INFO - 2016-05-03 19:39:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:39:50 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:39:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:39:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:39:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:39:50 --> Final output sent to browser
DEBUG - 2016-05-03 19:39:50 --> Total execution time: 0.0783
INFO - 2016-05-03 19:39:58 --> Config Class Initialized
INFO - 2016-05-03 19:39:58 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:39:58 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:39:58 --> Utf8 Class Initialized
INFO - 2016-05-03 19:39:58 --> URI Class Initialized
INFO - 2016-05-03 19:39:58 --> Router Class Initialized
INFO - 2016-05-03 19:39:58 --> Output Class Initialized
INFO - 2016-05-03 19:39:58 --> Security Class Initialized
DEBUG - 2016-05-03 19:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:39:58 --> Input Class Initialized
INFO - 2016-05-03 19:39:58 --> Language Class Initialized
INFO - 2016-05-03 19:39:58 --> Loader Class Initialized
INFO - 2016-05-03 19:39:58 --> Helper loaded: url_helper
INFO - 2016-05-03 19:39:58 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:39:58 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:39:59 --> Helper loaded: form_helper
INFO - 2016-05-03 19:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:39:59 --> Form Validation Class Initialized
INFO - 2016-05-03 19:39:59 --> Controller Class Initialized
INFO - 2016-05-03 19:39:59 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:39:59 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:39:59 --> Model Class Initialized
INFO - 2016-05-03 19:39:59 --> Database Driver Class Initialized
INFO - 2016-05-03 19:39:59 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:39:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-03 19:39:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:39:59 --> Final output sent to browser
DEBUG - 2016-05-03 19:39:59 --> Total execution time: 0.1205
INFO - 2016-05-03 19:41:08 --> Config Class Initialized
INFO - 2016-05-03 19:41:08 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:41:08 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:41:08 --> Utf8 Class Initialized
INFO - 2016-05-03 19:41:08 --> URI Class Initialized
INFO - 2016-05-03 19:41:08 --> Router Class Initialized
INFO - 2016-05-03 19:41:08 --> Output Class Initialized
INFO - 2016-05-03 19:41:08 --> Security Class Initialized
DEBUG - 2016-05-03 19:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:41:08 --> Input Class Initialized
INFO - 2016-05-03 19:41:08 --> Language Class Initialized
INFO - 2016-05-03 19:41:08 --> Loader Class Initialized
INFO - 2016-05-03 19:41:08 --> Helper loaded: url_helper
INFO - 2016-05-03 19:41:08 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:41:08 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:41:08 --> Helper loaded: form_helper
INFO - 2016-05-03 19:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:41:08 --> Form Validation Class Initialized
INFO - 2016-05-03 19:41:08 --> Controller Class Initialized
INFO - 2016-05-03 19:41:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:41:08 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:41:08 --> Model Class Initialized
INFO - 2016-05-03 19:41:08 --> Database Driver Class Initialized
INFO - 2016-05-03 19:41:08 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:41:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-03 19:41:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:41:08 --> Final output sent to browser
DEBUG - 2016-05-03 19:41:08 --> Total execution time: 0.0893
INFO - 2016-05-03 19:41:14 --> Config Class Initialized
INFO - 2016-05-03 19:41:14 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:41:14 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:41:14 --> Utf8 Class Initialized
INFO - 2016-05-03 19:41:14 --> URI Class Initialized
INFO - 2016-05-03 19:41:14 --> Router Class Initialized
INFO - 2016-05-03 19:41:14 --> Output Class Initialized
INFO - 2016-05-03 19:41:14 --> Security Class Initialized
DEBUG - 2016-05-03 19:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:41:14 --> Input Class Initialized
INFO - 2016-05-03 19:41:14 --> Language Class Initialized
INFO - 2016-05-03 19:41:14 --> Loader Class Initialized
INFO - 2016-05-03 19:41:14 --> Helper loaded: url_helper
INFO - 2016-05-03 19:41:14 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:41:14 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:41:14 --> Helper loaded: form_helper
INFO - 2016-05-03 19:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:41:14 --> Form Validation Class Initialized
INFO - 2016-05-03 19:41:14 --> Controller Class Initialized
INFO - 2016-05-03 19:41:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:41:14 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:41:14 --> Model Class Initialized
INFO - 2016-05-03 19:41:14 --> Database Driver Class Initialized
INFO - 2016-05-03 19:41:14 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:41:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-03 19:41:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:41:14 --> Final output sent to browser
DEBUG - 2016-05-03 19:41:14 --> Total execution time: 0.1234
INFO - 2016-05-03 19:41:19 --> Config Class Initialized
INFO - 2016-05-03 19:41:19 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:41:19 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:41:19 --> Utf8 Class Initialized
INFO - 2016-05-03 19:41:19 --> URI Class Initialized
INFO - 2016-05-03 19:41:19 --> Router Class Initialized
INFO - 2016-05-03 19:41:19 --> Output Class Initialized
INFO - 2016-05-03 19:41:19 --> Security Class Initialized
DEBUG - 2016-05-03 19:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:41:19 --> Input Class Initialized
INFO - 2016-05-03 19:41:19 --> Language Class Initialized
INFO - 2016-05-03 19:41:19 --> Loader Class Initialized
INFO - 2016-05-03 19:41:19 --> Helper loaded: url_helper
INFO - 2016-05-03 19:41:19 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:41:19 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:41:19 --> Helper loaded: form_helper
INFO - 2016-05-03 19:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:41:19 --> Form Validation Class Initialized
INFO - 2016-05-03 19:41:19 --> Controller Class Initialized
INFO - 2016-05-03 19:41:19 --> Model Class Initialized
INFO - 2016-05-03 19:41:19 --> Database Driver Class Initialized
INFO - 2016-05-03 19:41:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:41:19 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:41:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:41:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:41:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:41:19 --> Final output sent to browser
DEBUG - 2016-05-03 19:41:19 --> Total execution time: 0.0951
INFO - 2016-05-03 19:41:22 --> Config Class Initialized
INFO - 2016-05-03 19:41:22 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:41:22 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:41:22 --> Utf8 Class Initialized
INFO - 2016-05-03 19:41:22 --> URI Class Initialized
INFO - 2016-05-03 19:41:22 --> Router Class Initialized
INFO - 2016-05-03 19:41:22 --> Output Class Initialized
INFO - 2016-05-03 19:41:22 --> Security Class Initialized
DEBUG - 2016-05-03 19:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:41:22 --> Input Class Initialized
INFO - 2016-05-03 19:41:22 --> Language Class Initialized
INFO - 2016-05-03 19:41:22 --> Loader Class Initialized
INFO - 2016-05-03 19:41:22 --> Helper loaded: url_helper
INFO - 2016-05-03 19:41:22 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:41:22 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:41:22 --> Helper loaded: form_helper
INFO - 2016-05-03 19:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:41:22 --> Form Validation Class Initialized
INFO - 2016-05-03 19:41:22 --> Controller Class Initialized
INFO - 2016-05-03 19:41:22 --> Model Class Initialized
INFO - 2016-05-03 19:41:22 --> Database Driver Class Initialized
INFO - 2016-05-03 19:41:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:41:22 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:41:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:41:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:41:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:41:23 --> Final output sent to browser
DEBUG - 2016-05-03 19:41:23 --> Total execution time: 0.1570
INFO - 2016-05-03 19:41:34 --> Config Class Initialized
INFO - 2016-05-03 19:41:34 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:41:34 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:41:34 --> Utf8 Class Initialized
INFO - 2016-05-03 19:41:34 --> URI Class Initialized
INFO - 2016-05-03 19:41:34 --> Router Class Initialized
INFO - 2016-05-03 19:41:34 --> Output Class Initialized
INFO - 2016-05-03 19:41:34 --> Security Class Initialized
DEBUG - 2016-05-03 19:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:41:34 --> Input Class Initialized
INFO - 2016-05-03 19:41:34 --> Language Class Initialized
INFO - 2016-05-03 19:41:34 --> Loader Class Initialized
INFO - 2016-05-03 19:41:34 --> Helper loaded: url_helper
INFO - 2016-05-03 19:41:34 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:41:34 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:41:34 --> Helper loaded: form_helper
INFO - 2016-05-03 19:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:41:34 --> Form Validation Class Initialized
INFO - 2016-05-03 19:41:34 --> Controller Class Initialized
INFO - 2016-05-03 19:41:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:41:34 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:41:34 --> Model Class Initialized
INFO - 2016-05-03 19:41:34 --> Database Driver Class Initialized
INFO - 2016-05-03 19:41:34 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:41:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-03 19:41:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:41:34 --> Final output sent to browser
DEBUG - 2016-05-03 19:41:34 --> Total execution time: 0.1129
INFO - 2016-05-03 19:41:38 --> Config Class Initialized
INFO - 2016-05-03 19:41:38 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:41:38 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:41:38 --> Utf8 Class Initialized
INFO - 2016-05-03 19:41:38 --> URI Class Initialized
INFO - 2016-05-03 19:41:38 --> Router Class Initialized
INFO - 2016-05-03 19:41:38 --> Output Class Initialized
INFO - 2016-05-03 19:41:38 --> Security Class Initialized
DEBUG - 2016-05-03 19:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:41:38 --> Input Class Initialized
INFO - 2016-05-03 19:41:38 --> Language Class Initialized
INFO - 2016-05-03 19:41:38 --> Loader Class Initialized
INFO - 2016-05-03 19:41:38 --> Helper loaded: url_helper
INFO - 2016-05-03 19:41:38 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:41:38 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:41:38 --> Helper loaded: form_helper
INFO - 2016-05-03 19:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:41:38 --> Form Validation Class Initialized
INFO - 2016-05-03 19:41:38 --> Controller Class Initialized
INFO - 2016-05-03 19:41:38 --> Model Class Initialized
INFO - 2016-05-03 19:41:38 --> Database Driver Class Initialized
INFO - 2016-05-03 19:41:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:41:38 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:41:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:41:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:41:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:41:38 --> Final output sent to browser
DEBUG - 2016-05-03 19:41:38 --> Total execution time: 0.0736
INFO - 2016-05-03 19:42:02 --> Config Class Initialized
INFO - 2016-05-03 19:42:02 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:42:02 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:42:02 --> Utf8 Class Initialized
INFO - 2016-05-03 19:42:02 --> URI Class Initialized
INFO - 2016-05-03 19:42:02 --> Router Class Initialized
INFO - 2016-05-03 19:42:02 --> Output Class Initialized
INFO - 2016-05-03 19:42:02 --> Security Class Initialized
DEBUG - 2016-05-03 19:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:42:02 --> Input Class Initialized
INFO - 2016-05-03 19:42:02 --> Language Class Initialized
INFO - 2016-05-03 19:42:02 --> Loader Class Initialized
INFO - 2016-05-03 19:42:02 --> Helper loaded: url_helper
INFO - 2016-05-03 19:42:02 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:42:02 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:42:02 --> Helper loaded: form_helper
INFO - 2016-05-03 19:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:42:02 --> Form Validation Class Initialized
INFO - 2016-05-03 19:42:02 --> Controller Class Initialized
INFO - 2016-05-03 19:42:02 --> Model Class Initialized
INFO - 2016-05-03 19:42:02 --> Database Driver Class Initialized
INFO - 2016-05-03 19:42:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:42:02 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:42:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:42:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:42:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:42:02 --> Final output sent to browser
DEBUG - 2016-05-03 19:42:02 --> Total execution time: 0.0970
INFO - 2016-05-03 19:42:04 --> Config Class Initialized
INFO - 2016-05-03 19:42:04 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:42:04 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:42:04 --> Utf8 Class Initialized
INFO - 2016-05-03 19:42:04 --> URI Class Initialized
INFO - 2016-05-03 19:42:04 --> Router Class Initialized
INFO - 2016-05-03 19:42:04 --> Output Class Initialized
INFO - 2016-05-03 19:42:04 --> Security Class Initialized
DEBUG - 2016-05-03 19:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:42:04 --> Input Class Initialized
INFO - 2016-05-03 19:42:04 --> Language Class Initialized
INFO - 2016-05-03 19:42:04 --> Loader Class Initialized
INFO - 2016-05-03 19:42:04 --> Helper loaded: url_helper
INFO - 2016-05-03 19:42:04 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:42:04 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:42:04 --> Helper loaded: form_helper
INFO - 2016-05-03 19:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:42:04 --> Form Validation Class Initialized
INFO - 2016-05-03 19:42:04 --> Controller Class Initialized
INFO - 2016-05-03 19:42:04 --> Model Class Initialized
INFO - 2016-05-03 19:42:04 --> Database Driver Class Initialized
INFO - 2016-05-03 19:42:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:42:04 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:42:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:42:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:42:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:42:04 --> Final output sent to browser
DEBUG - 2016-05-03 19:42:04 --> Total execution time: 0.1347
INFO - 2016-05-03 19:42:06 --> Config Class Initialized
INFO - 2016-05-03 19:42:06 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:42:06 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:42:06 --> Utf8 Class Initialized
INFO - 2016-05-03 19:42:06 --> URI Class Initialized
INFO - 2016-05-03 19:42:06 --> Router Class Initialized
INFO - 2016-05-03 19:42:06 --> Output Class Initialized
INFO - 2016-05-03 19:42:06 --> Security Class Initialized
DEBUG - 2016-05-03 19:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:42:06 --> Input Class Initialized
INFO - 2016-05-03 19:42:06 --> Language Class Initialized
INFO - 2016-05-03 19:42:06 --> Loader Class Initialized
INFO - 2016-05-03 19:42:06 --> Helper loaded: url_helper
INFO - 2016-05-03 19:42:06 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:42:06 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:42:06 --> Helper loaded: form_helper
INFO - 2016-05-03 19:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:42:06 --> Form Validation Class Initialized
INFO - 2016-05-03 19:42:06 --> Controller Class Initialized
INFO - 2016-05-03 19:42:06 --> Model Class Initialized
INFO - 2016-05-03 19:42:06 --> Database Driver Class Initialized
INFO - 2016-05-03 19:42:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:42:06 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:42:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:42:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:42:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:42:06 --> Final output sent to browser
DEBUG - 2016-05-03 19:42:06 --> Total execution time: 0.0904
INFO - 2016-05-03 19:42:08 --> Config Class Initialized
INFO - 2016-05-03 19:42:08 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:42:08 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:42:08 --> Utf8 Class Initialized
INFO - 2016-05-03 19:42:08 --> URI Class Initialized
INFO - 2016-05-03 19:42:08 --> Router Class Initialized
INFO - 2016-05-03 19:42:08 --> Output Class Initialized
INFO - 2016-05-03 19:42:08 --> Security Class Initialized
DEBUG - 2016-05-03 19:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:42:08 --> Input Class Initialized
INFO - 2016-05-03 19:42:08 --> Language Class Initialized
INFO - 2016-05-03 19:42:08 --> Loader Class Initialized
INFO - 2016-05-03 19:42:08 --> Helper loaded: url_helper
INFO - 2016-05-03 19:42:08 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:42:08 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:42:08 --> Helper loaded: form_helper
INFO - 2016-05-03 19:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:42:08 --> Form Validation Class Initialized
INFO - 2016-05-03 19:42:08 --> Controller Class Initialized
INFO - 2016-05-03 19:42:08 --> Model Class Initialized
INFO - 2016-05-03 19:42:08 --> Database Driver Class Initialized
INFO - 2016-05-03 19:42:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:42:08 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:42:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:42:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:42:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:42:08 --> Final output sent to browser
DEBUG - 2016-05-03 19:42:08 --> Total execution time: 0.1415
INFO - 2016-05-03 19:42:10 --> Config Class Initialized
INFO - 2016-05-03 19:42:10 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:42:10 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:42:10 --> Utf8 Class Initialized
INFO - 2016-05-03 19:42:10 --> URI Class Initialized
INFO - 2016-05-03 19:42:10 --> Router Class Initialized
INFO - 2016-05-03 19:42:10 --> Output Class Initialized
INFO - 2016-05-03 19:42:10 --> Security Class Initialized
DEBUG - 2016-05-03 19:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:42:10 --> Input Class Initialized
INFO - 2016-05-03 19:42:10 --> Language Class Initialized
INFO - 2016-05-03 19:42:10 --> Loader Class Initialized
INFO - 2016-05-03 19:42:10 --> Helper loaded: url_helper
INFO - 2016-05-03 19:42:10 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:42:10 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:42:10 --> Helper loaded: form_helper
INFO - 2016-05-03 19:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:42:10 --> Form Validation Class Initialized
INFO - 2016-05-03 19:42:10 --> Controller Class Initialized
INFO - 2016-05-03 19:42:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:42:10 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:42:10 --> Model Class Initialized
INFO - 2016-05-03 19:42:10 --> Database Driver Class Initialized
INFO - 2016-05-03 19:42:10 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:42:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-03 19:42:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:42:10 --> Final output sent to browser
DEBUG - 2016-05-03 19:42:10 --> Total execution time: 0.1246
INFO - 2016-05-03 19:43:43 --> Config Class Initialized
INFO - 2016-05-03 19:43:43 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:43:43 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:43:43 --> Utf8 Class Initialized
INFO - 2016-05-03 19:43:43 --> URI Class Initialized
INFO - 2016-05-03 19:43:43 --> Router Class Initialized
INFO - 2016-05-03 19:43:43 --> Output Class Initialized
INFO - 2016-05-03 19:43:43 --> Security Class Initialized
DEBUG - 2016-05-03 19:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:43:43 --> Input Class Initialized
INFO - 2016-05-03 19:43:43 --> Language Class Initialized
INFO - 2016-05-03 19:43:43 --> Loader Class Initialized
INFO - 2016-05-03 19:43:43 --> Helper loaded: url_helper
INFO - 2016-05-03 19:43:43 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:43:43 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:43:43 --> Helper loaded: form_helper
INFO - 2016-05-03 19:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:43:43 --> Form Validation Class Initialized
INFO - 2016-05-03 19:43:43 --> Controller Class Initialized
INFO - 2016-05-03 19:43:43 --> Model Class Initialized
INFO - 2016-05-03 19:43:43 --> Database Driver Class Initialized
INFO - 2016-05-03 19:43:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:43:43 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:43:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:43:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:43:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:43:43 --> Final output sent to browser
DEBUG - 2016-05-03 19:43:43 --> Total execution time: 0.1014
INFO - 2016-05-03 19:43:45 --> Config Class Initialized
INFO - 2016-05-03 19:43:45 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:43:45 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:43:45 --> Utf8 Class Initialized
INFO - 2016-05-03 19:43:45 --> URI Class Initialized
INFO - 2016-05-03 19:43:45 --> Router Class Initialized
INFO - 2016-05-03 19:43:45 --> Output Class Initialized
INFO - 2016-05-03 19:43:45 --> Security Class Initialized
DEBUG - 2016-05-03 19:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:43:45 --> Input Class Initialized
INFO - 2016-05-03 19:43:45 --> Language Class Initialized
INFO - 2016-05-03 19:43:45 --> Loader Class Initialized
INFO - 2016-05-03 19:43:45 --> Helper loaded: url_helper
INFO - 2016-05-03 19:43:45 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:43:45 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:43:45 --> Helper loaded: form_helper
INFO - 2016-05-03 19:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:43:45 --> Form Validation Class Initialized
INFO - 2016-05-03 19:43:45 --> Controller Class Initialized
INFO - 2016-05-03 19:43:45 --> Model Class Initialized
INFO - 2016-05-03 19:43:45 --> Database Driver Class Initialized
INFO - 2016-05-03 19:43:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:43:45 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:43:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:43:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:43:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:43:45 --> Final output sent to browser
DEBUG - 2016-05-03 19:43:45 --> Total execution time: 0.1332
INFO - 2016-05-03 19:44:18 --> Config Class Initialized
INFO - 2016-05-03 19:44:18 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:44:18 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:44:18 --> Utf8 Class Initialized
INFO - 2016-05-03 19:44:18 --> URI Class Initialized
INFO - 2016-05-03 19:44:18 --> Router Class Initialized
INFO - 2016-05-03 19:44:18 --> Output Class Initialized
INFO - 2016-05-03 19:44:18 --> Security Class Initialized
DEBUG - 2016-05-03 19:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:44:18 --> Input Class Initialized
INFO - 2016-05-03 19:44:18 --> Language Class Initialized
INFO - 2016-05-03 19:44:18 --> Loader Class Initialized
INFO - 2016-05-03 19:44:18 --> Helper loaded: url_helper
INFO - 2016-05-03 19:44:18 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:44:18 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:44:18 --> Helper loaded: form_helper
INFO - 2016-05-03 19:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:44:18 --> Form Validation Class Initialized
INFO - 2016-05-03 19:44:18 --> Controller Class Initialized
INFO - 2016-05-03 19:44:18 --> Model Class Initialized
INFO - 2016-05-03 19:44:18 --> Database Driver Class Initialized
INFO - 2016-05-03 19:44:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:44:18 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:44:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:44:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:44:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:44:18 --> Final output sent to browser
DEBUG - 2016-05-03 19:44:18 --> Total execution time: 0.0801
INFO - 2016-05-03 19:44:21 --> Config Class Initialized
INFO - 2016-05-03 19:44:21 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:44:21 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:44:21 --> Utf8 Class Initialized
INFO - 2016-05-03 19:44:21 --> URI Class Initialized
INFO - 2016-05-03 19:44:21 --> Router Class Initialized
INFO - 2016-05-03 19:44:21 --> Output Class Initialized
INFO - 2016-05-03 19:44:21 --> Security Class Initialized
DEBUG - 2016-05-03 19:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:44:21 --> Input Class Initialized
INFO - 2016-05-03 19:44:21 --> Language Class Initialized
INFO - 2016-05-03 19:44:21 --> Loader Class Initialized
INFO - 2016-05-03 19:44:21 --> Helper loaded: url_helper
INFO - 2016-05-03 19:44:21 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:44:21 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:44:21 --> Helper loaded: form_helper
INFO - 2016-05-03 19:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:44:21 --> Form Validation Class Initialized
INFO - 2016-05-03 19:44:21 --> Controller Class Initialized
INFO - 2016-05-03 19:44:21 --> Model Class Initialized
INFO - 2016-05-03 19:44:21 --> Database Driver Class Initialized
INFO - 2016-05-03 19:44:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:44:21 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:44:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:44:21 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:44:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:44:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:44:21 --> Final output sent to browser
DEBUG - 2016-05-03 19:44:21 --> Total execution time: 0.1976
INFO - 2016-05-03 19:44:26 --> Config Class Initialized
INFO - 2016-05-03 19:44:26 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:44:26 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:44:26 --> Utf8 Class Initialized
INFO - 2016-05-03 19:44:26 --> URI Class Initialized
INFO - 2016-05-03 19:44:26 --> Router Class Initialized
INFO - 2016-05-03 19:44:26 --> Output Class Initialized
INFO - 2016-05-03 19:44:26 --> Security Class Initialized
DEBUG - 2016-05-03 19:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:44:26 --> Input Class Initialized
INFO - 2016-05-03 19:44:26 --> Language Class Initialized
INFO - 2016-05-03 19:44:26 --> Loader Class Initialized
INFO - 2016-05-03 19:44:26 --> Helper loaded: url_helper
INFO - 2016-05-03 19:44:26 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:44:26 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:44:26 --> Helper loaded: form_helper
INFO - 2016-05-03 19:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:44:26 --> Form Validation Class Initialized
INFO - 2016-05-03 19:44:26 --> Controller Class Initialized
INFO - 2016-05-03 19:44:26 --> Model Class Initialized
INFO - 2016-05-03 19:44:26 --> Database Driver Class Initialized
INFO - 2016-05-03 19:44:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:44:26 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:44:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:44:26 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:44:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:44:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:44:26 --> Final output sent to browser
DEBUG - 2016-05-03 19:44:26 --> Total execution time: 0.2656
INFO - 2016-05-03 19:44:27 --> Config Class Initialized
INFO - 2016-05-03 19:44:27 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:44:27 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:44:27 --> Utf8 Class Initialized
INFO - 2016-05-03 19:44:27 --> URI Class Initialized
INFO - 2016-05-03 19:44:27 --> Router Class Initialized
INFO - 2016-05-03 19:44:27 --> Output Class Initialized
INFO - 2016-05-03 19:44:27 --> Security Class Initialized
DEBUG - 2016-05-03 19:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:44:27 --> Input Class Initialized
INFO - 2016-05-03 19:44:27 --> Language Class Initialized
INFO - 2016-05-03 19:44:27 --> Loader Class Initialized
INFO - 2016-05-03 19:44:27 --> Helper loaded: url_helper
INFO - 2016-05-03 19:44:27 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:44:27 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:44:27 --> Helper loaded: form_helper
INFO - 2016-05-03 19:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:44:27 --> Form Validation Class Initialized
INFO - 2016-05-03 19:44:27 --> Controller Class Initialized
INFO - 2016-05-03 19:44:27 --> Model Class Initialized
INFO - 2016-05-03 19:44:27 --> Database Driver Class Initialized
INFO - 2016-05-03 19:44:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:44:27 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:44:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:44:27 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:44:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:44:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:44:27 --> Final output sent to browser
DEBUG - 2016-05-03 19:44:27 --> Total execution time: 0.1749
INFO - 2016-05-03 19:44:46 --> Config Class Initialized
INFO - 2016-05-03 19:44:46 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:44:46 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:44:46 --> Utf8 Class Initialized
INFO - 2016-05-03 19:44:46 --> URI Class Initialized
INFO - 2016-05-03 19:44:46 --> Router Class Initialized
INFO - 2016-05-03 19:44:46 --> Output Class Initialized
INFO - 2016-05-03 19:44:46 --> Security Class Initialized
DEBUG - 2016-05-03 19:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:44:46 --> Input Class Initialized
INFO - 2016-05-03 19:44:46 --> Language Class Initialized
INFO - 2016-05-03 19:44:46 --> Loader Class Initialized
INFO - 2016-05-03 19:44:46 --> Helper loaded: url_helper
INFO - 2016-05-03 19:44:46 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:44:46 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:44:46 --> Helper loaded: form_helper
INFO - 2016-05-03 19:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:44:46 --> Form Validation Class Initialized
INFO - 2016-05-03 19:44:46 --> Controller Class Initialized
INFO - 2016-05-03 19:44:46 --> Model Class Initialized
INFO - 2016-05-03 19:44:46 --> Database Driver Class Initialized
INFO - 2016-05-03 19:44:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:44:46 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:44:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:44:46 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:44:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:44:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:44:46 --> Final output sent to browser
DEBUG - 2016-05-03 19:44:46 --> Total execution time: 0.1376
INFO - 2016-05-03 19:45:14 --> Config Class Initialized
INFO - 2016-05-03 19:45:14 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:45:14 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:45:14 --> Utf8 Class Initialized
INFO - 2016-05-03 19:45:14 --> URI Class Initialized
INFO - 2016-05-03 19:45:14 --> Router Class Initialized
INFO - 2016-05-03 19:45:14 --> Output Class Initialized
INFO - 2016-05-03 19:45:14 --> Security Class Initialized
DEBUG - 2016-05-03 19:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:45:14 --> Input Class Initialized
INFO - 2016-05-03 19:45:14 --> Language Class Initialized
INFO - 2016-05-03 19:45:14 --> Loader Class Initialized
INFO - 2016-05-03 19:45:14 --> Helper loaded: url_helper
INFO - 2016-05-03 19:45:14 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:45:14 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:45:14 --> Helper loaded: form_helper
INFO - 2016-05-03 19:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:45:14 --> Form Validation Class Initialized
INFO - 2016-05-03 19:45:14 --> Controller Class Initialized
INFO - 2016-05-03 19:45:14 --> Model Class Initialized
INFO - 2016-05-03 19:45:14 --> Database Driver Class Initialized
INFO - 2016-05-03 19:45:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:45:14 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:45:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:45:14 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:45:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:45:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:45:14 --> Final output sent to browser
DEBUG - 2016-05-03 19:45:14 --> Total execution time: 0.0786
INFO - 2016-05-03 19:45:17 --> Config Class Initialized
INFO - 2016-05-03 19:45:17 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:45:18 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:45:18 --> Utf8 Class Initialized
INFO - 2016-05-03 19:45:18 --> URI Class Initialized
INFO - 2016-05-03 19:45:18 --> Router Class Initialized
INFO - 2016-05-03 19:45:18 --> Output Class Initialized
INFO - 2016-05-03 19:45:18 --> Security Class Initialized
DEBUG - 2016-05-03 19:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:45:18 --> Input Class Initialized
INFO - 2016-05-03 19:45:18 --> Language Class Initialized
INFO - 2016-05-03 19:45:18 --> Loader Class Initialized
INFO - 2016-05-03 19:45:18 --> Helper loaded: url_helper
INFO - 2016-05-03 19:45:18 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:45:18 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:45:18 --> Helper loaded: form_helper
INFO - 2016-05-03 19:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:45:18 --> Form Validation Class Initialized
INFO - 2016-05-03 19:45:18 --> Controller Class Initialized
INFO - 2016-05-03 19:45:18 --> Model Class Initialized
INFO - 2016-05-03 19:45:18 --> Database Driver Class Initialized
INFO - 2016-05-03 19:45:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:45:18 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:45:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:45:18 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:45:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:45:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:45:18 --> Final output sent to browser
DEBUG - 2016-05-03 19:45:18 --> Total execution time: 0.1182
INFO - 2016-05-03 19:45:19 --> Config Class Initialized
INFO - 2016-05-03 19:45:19 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:45:19 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:45:19 --> Utf8 Class Initialized
INFO - 2016-05-03 19:45:19 --> URI Class Initialized
INFO - 2016-05-03 19:45:19 --> Router Class Initialized
INFO - 2016-05-03 19:45:19 --> Output Class Initialized
INFO - 2016-05-03 19:45:19 --> Security Class Initialized
DEBUG - 2016-05-03 19:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:45:19 --> Input Class Initialized
INFO - 2016-05-03 19:45:19 --> Language Class Initialized
INFO - 2016-05-03 19:45:19 --> Loader Class Initialized
INFO - 2016-05-03 19:45:19 --> Helper loaded: url_helper
INFO - 2016-05-03 19:45:19 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:45:19 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:45:19 --> Helper loaded: form_helper
INFO - 2016-05-03 19:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:45:19 --> Form Validation Class Initialized
INFO - 2016-05-03 19:45:19 --> Controller Class Initialized
INFO - 2016-05-03 19:45:19 --> Model Class Initialized
INFO - 2016-05-03 19:45:19 --> Database Driver Class Initialized
INFO - 2016-05-03 19:45:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:45:19 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:45:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:45:19 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:45:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:45:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:45:19 --> Final output sent to browser
DEBUG - 2016-05-03 19:45:19 --> Total execution time: 0.1207
INFO - 2016-05-03 19:45:25 --> Config Class Initialized
INFO - 2016-05-03 19:45:25 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:45:25 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:45:25 --> Utf8 Class Initialized
INFO - 2016-05-03 19:45:25 --> URI Class Initialized
INFO - 2016-05-03 19:45:25 --> Router Class Initialized
INFO - 2016-05-03 19:45:25 --> Output Class Initialized
INFO - 2016-05-03 19:45:25 --> Security Class Initialized
DEBUG - 2016-05-03 19:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:45:25 --> Input Class Initialized
INFO - 2016-05-03 19:45:25 --> Language Class Initialized
INFO - 2016-05-03 19:45:25 --> Loader Class Initialized
INFO - 2016-05-03 19:45:25 --> Helper loaded: url_helper
INFO - 2016-05-03 19:45:25 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:45:25 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:45:25 --> Helper loaded: form_helper
INFO - 2016-05-03 19:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:45:25 --> Form Validation Class Initialized
INFO - 2016-05-03 19:45:25 --> Controller Class Initialized
INFO - 2016-05-03 19:45:25 --> Model Class Initialized
INFO - 2016-05-03 19:45:25 --> Database Driver Class Initialized
INFO - 2016-05-03 19:45:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:45:25 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:45:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:45:25 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:45:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:45:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:45:25 --> Final output sent to browser
DEBUG - 2016-05-03 19:45:25 --> Total execution time: 0.0777
INFO - 2016-05-03 19:45:35 --> Config Class Initialized
INFO - 2016-05-03 19:45:35 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:45:35 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:45:35 --> Utf8 Class Initialized
INFO - 2016-05-03 19:45:35 --> URI Class Initialized
INFO - 2016-05-03 19:45:35 --> Router Class Initialized
INFO - 2016-05-03 19:45:35 --> Output Class Initialized
INFO - 2016-05-03 19:45:35 --> Security Class Initialized
DEBUG - 2016-05-03 19:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:45:35 --> Input Class Initialized
INFO - 2016-05-03 19:45:35 --> Language Class Initialized
INFO - 2016-05-03 19:45:35 --> Loader Class Initialized
INFO - 2016-05-03 19:45:35 --> Helper loaded: url_helper
INFO - 2016-05-03 19:45:35 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:45:35 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:45:35 --> Helper loaded: form_helper
INFO - 2016-05-03 19:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:45:35 --> Form Validation Class Initialized
INFO - 2016-05-03 19:45:35 --> Controller Class Initialized
INFO - 2016-05-03 19:45:35 --> Model Class Initialized
INFO - 2016-05-03 19:45:35 --> Database Driver Class Initialized
INFO - 2016-05-03 19:45:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:45:35 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:45:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:45:35 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:45:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:45:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:45:35 --> Final output sent to browser
DEBUG - 2016-05-03 19:45:35 --> Total execution time: 0.1768
INFO - 2016-05-03 19:45:42 --> Config Class Initialized
INFO - 2016-05-03 19:45:42 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:45:42 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:45:42 --> Utf8 Class Initialized
INFO - 2016-05-03 19:45:42 --> URI Class Initialized
INFO - 2016-05-03 19:45:42 --> Router Class Initialized
INFO - 2016-05-03 19:45:42 --> Output Class Initialized
INFO - 2016-05-03 19:45:42 --> Security Class Initialized
DEBUG - 2016-05-03 19:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:45:42 --> Input Class Initialized
INFO - 2016-05-03 19:45:42 --> Language Class Initialized
INFO - 2016-05-03 19:45:42 --> Loader Class Initialized
INFO - 2016-05-03 19:45:42 --> Helper loaded: url_helper
INFO - 2016-05-03 19:45:42 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:45:42 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:45:42 --> Helper loaded: form_helper
INFO - 2016-05-03 19:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:45:42 --> Form Validation Class Initialized
INFO - 2016-05-03 19:45:42 --> Controller Class Initialized
INFO - 2016-05-03 19:45:42 --> Model Class Initialized
INFO - 2016-05-03 19:45:42 --> Database Driver Class Initialized
INFO - 2016-05-03 19:45:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:45:42 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:45:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:45:42 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-03 19:45:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-03 19:45:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:45:42 --> Final output sent to browser
DEBUG - 2016-05-03 19:45:42 --> Total execution time: 0.1956
INFO - 2016-05-03 19:45:46 --> Config Class Initialized
INFO - 2016-05-03 19:45:46 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:45:46 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:45:46 --> Utf8 Class Initialized
INFO - 2016-05-03 19:45:46 --> URI Class Initialized
INFO - 2016-05-03 19:45:46 --> Router Class Initialized
INFO - 2016-05-03 19:45:46 --> Output Class Initialized
INFO - 2016-05-03 19:45:46 --> Security Class Initialized
DEBUG - 2016-05-03 19:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:45:46 --> Input Class Initialized
INFO - 2016-05-03 19:45:46 --> Language Class Initialized
INFO - 2016-05-03 19:45:46 --> Loader Class Initialized
INFO - 2016-05-03 19:45:46 --> Helper loaded: url_helper
INFO - 2016-05-03 19:45:46 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:45:46 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:45:46 --> Helper loaded: form_helper
INFO - 2016-05-03 19:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:45:46 --> Form Validation Class Initialized
INFO - 2016-05-03 19:45:46 --> Controller Class Initialized
INFO - 2016-05-03 19:45:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:45:46 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:45:46 --> Model Class Initialized
INFO - 2016-05-03 19:45:46 --> Database Driver Class Initialized
INFO - 2016-05-03 19:45:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-03 19:45:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:45:46 --> Final output sent to browser
DEBUG - 2016-05-03 19:45:46 --> Total execution time: 0.0890
INFO - 2016-05-03 19:45:54 --> Config Class Initialized
INFO - 2016-05-03 19:45:54 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:45:54 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:45:54 --> Utf8 Class Initialized
INFO - 2016-05-03 19:45:54 --> URI Class Initialized
INFO - 2016-05-03 19:45:54 --> Router Class Initialized
INFO - 2016-05-03 19:45:54 --> Output Class Initialized
INFO - 2016-05-03 19:45:54 --> Security Class Initialized
DEBUG - 2016-05-03 19:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:45:54 --> Input Class Initialized
INFO - 2016-05-03 19:45:54 --> Language Class Initialized
INFO - 2016-05-03 19:45:54 --> Loader Class Initialized
INFO - 2016-05-03 19:45:54 --> Helper loaded: url_helper
INFO - 2016-05-03 19:45:54 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:45:54 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:45:54 --> Helper loaded: form_helper
INFO - 2016-05-03 19:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:45:54 --> Form Validation Class Initialized
INFO - 2016-05-03 19:45:54 --> Controller Class Initialized
INFO - 2016-05-03 19:45:54 --> Model Class Initialized
INFO - 2016-05-03 19:45:54 --> Database Driver Class Initialized
INFO - 2016-05-03 19:45:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:45:54 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:45:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:45:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:45:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:45:54 --> Final output sent to browser
DEBUG - 2016-05-03 19:45:54 --> Total execution time: 0.0935
INFO - 2016-05-03 19:46:25 --> Config Class Initialized
INFO - 2016-05-03 19:46:25 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:46:25 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:46:25 --> Utf8 Class Initialized
INFO - 2016-05-03 19:46:25 --> URI Class Initialized
INFO - 2016-05-03 19:46:25 --> Router Class Initialized
INFO - 2016-05-03 19:46:25 --> Output Class Initialized
INFO - 2016-05-03 19:46:25 --> Security Class Initialized
DEBUG - 2016-05-03 19:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:46:25 --> Input Class Initialized
INFO - 2016-05-03 19:46:25 --> Language Class Initialized
INFO - 2016-05-03 19:46:25 --> Loader Class Initialized
INFO - 2016-05-03 19:46:25 --> Helper loaded: url_helper
INFO - 2016-05-03 19:46:25 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:46:25 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:46:25 --> Helper loaded: form_helper
INFO - 2016-05-03 19:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:46:25 --> Form Validation Class Initialized
INFO - 2016-05-03 19:46:25 --> Controller Class Initialized
INFO - 2016-05-03 19:46:25 --> Model Class Initialized
INFO - 2016-05-03 19:46:25 --> Database Driver Class Initialized
INFO - 2016-05-03 19:46:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:46:25 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:46:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:46:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-03 19:46:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:46:25 --> Final output sent to browser
DEBUG - 2016-05-03 19:46:25 --> Total execution time: 0.0976
INFO - 2016-05-03 19:46:27 --> Config Class Initialized
INFO - 2016-05-03 19:46:27 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:46:27 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:46:27 --> Utf8 Class Initialized
INFO - 2016-05-03 19:46:27 --> URI Class Initialized
INFO - 2016-05-03 19:46:27 --> Router Class Initialized
INFO - 2016-05-03 19:46:27 --> Output Class Initialized
INFO - 2016-05-03 19:46:27 --> Security Class Initialized
DEBUG - 2016-05-03 19:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:46:27 --> Input Class Initialized
INFO - 2016-05-03 19:46:27 --> Language Class Initialized
INFO - 2016-05-03 19:46:27 --> Loader Class Initialized
INFO - 2016-05-03 19:46:27 --> Helper loaded: url_helper
INFO - 2016-05-03 19:46:27 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:46:27 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:46:27 --> Helper loaded: form_helper
INFO - 2016-05-03 19:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:46:27 --> Form Validation Class Initialized
INFO - 2016-05-03 19:46:27 --> Controller Class Initialized
INFO - 2016-05-03 19:46:27 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:46:27 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:46:27 --> Model Class Initialized
INFO - 2016-05-03 19:46:27 --> Database Driver Class Initialized
INFO - 2016-05-03 19:46:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-03 19:46:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:46:27 --> Final output sent to browser
DEBUG - 2016-05-03 19:46:27 --> Total execution time: 0.0924
INFO - 2016-05-03 19:46:30 --> Config Class Initialized
INFO - 2016-05-03 19:46:30 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:46:30 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:46:30 --> Utf8 Class Initialized
INFO - 2016-05-03 19:46:30 --> URI Class Initialized
INFO - 2016-05-03 19:46:30 --> Router Class Initialized
INFO - 2016-05-03 19:46:30 --> Output Class Initialized
INFO - 2016-05-03 19:46:30 --> Security Class Initialized
DEBUG - 2016-05-03 19:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:46:30 --> Input Class Initialized
INFO - 2016-05-03 19:46:30 --> Language Class Initialized
INFO - 2016-05-03 19:46:30 --> Loader Class Initialized
INFO - 2016-05-03 19:46:30 --> Helper loaded: url_helper
INFO - 2016-05-03 19:46:30 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:46:30 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:46:30 --> Helper loaded: form_helper
INFO - 2016-05-03 19:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:46:30 --> Form Validation Class Initialized
INFO - 2016-05-03 19:46:30 --> Controller Class Initialized
INFO - 2016-05-03 19:46:30 --> Model Class Initialized
INFO - 2016-05-03 19:46:30 --> Database Driver Class Initialized
INFO - 2016-05-03 19:46:30 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:46:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:46:30 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:46:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:46:30 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:46:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 19:46:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:46:30 --> Final output sent to browser
DEBUG - 2016-05-03 19:46:30 --> Total execution time: 0.1217
INFO - 2016-05-03 19:59:11 --> Config Class Initialized
INFO - 2016-05-03 19:59:11 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:59:11 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:59:11 --> Utf8 Class Initialized
INFO - 2016-05-03 19:59:11 --> URI Class Initialized
INFO - 2016-05-03 19:59:11 --> Router Class Initialized
INFO - 2016-05-03 19:59:11 --> Output Class Initialized
INFO - 2016-05-03 19:59:11 --> Security Class Initialized
DEBUG - 2016-05-03 19:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:59:11 --> Input Class Initialized
INFO - 2016-05-03 19:59:11 --> Language Class Initialized
INFO - 2016-05-03 19:59:11 --> Loader Class Initialized
INFO - 2016-05-03 19:59:11 --> Helper loaded: url_helper
INFO - 2016-05-03 19:59:11 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:59:11 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:59:11 --> Helper loaded: form_helper
INFO - 2016-05-03 19:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:59:11 --> Form Validation Class Initialized
INFO - 2016-05-03 19:59:11 --> Controller Class Initialized
INFO - 2016-05-03 19:59:11 --> Model Class Initialized
INFO - 2016-05-03 19:59:11 --> Database Driver Class Initialized
INFO - 2016-05-03 19:59:11 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:59:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:59:11 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:59:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:59:11 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:59:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 19:59:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:59:11 --> Final output sent to browser
DEBUG - 2016-05-03 19:59:11 --> Total execution time: 0.6372
INFO - 2016-05-03 19:59:13 --> Config Class Initialized
INFO - 2016-05-03 19:59:13 --> Hooks Class Initialized
DEBUG - 2016-05-03 19:59:13 --> UTF-8 Support Enabled
INFO - 2016-05-03 19:59:13 --> Utf8 Class Initialized
INFO - 2016-05-03 19:59:13 --> URI Class Initialized
INFO - 2016-05-03 19:59:13 --> Router Class Initialized
INFO - 2016-05-03 19:59:13 --> Output Class Initialized
INFO - 2016-05-03 19:59:13 --> Security Class Initialized
DEBUG - 2016-05-03 19:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 19:59:13 --> Input Class Initialized
INFO - 2016-05-03 19:59:13 --> Language Class Initialized
INFO - 2016-05-03 19:59:13 --> Loader Class Initialized
INFO - 2016-05-03 19:59:13 --> Helper loaded: url_helper
INFO - 2016-05-03 19:59:13 --> Helper loaded: sesion_helper
INFO - 2016-05-03 19:59:13 --> Helper loaded: templates_helper
INFO - 2016-05-03 19:59:13 --> Helper loaded: form_helper
INFO - 2016-05-03 19:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 19:59:13 --> Form Validation Class Initialized
INFO - 2016-05-03 19:59:13 --> Controller Class Initialized
INFO - 2016-05-03 19:59:13 --> Model Class Initialized
INFO - 2016-05-03 19:59:13 --> Database Driver Class Initialized
INFO - 2016-05-03 19:59:13 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 19:59:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 19:59:13 --> Pagination Class Initialized
DEBUG - 2016-05-03 19:59:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 19:59:13 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 19:59:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 19:59:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 19:59:13 --> Final output sent to browser
DEBUG - 2016-05-03 19:59:13 --> Total execution time: 0.1270
INFO - 2016-05-03 20:03:06 --> Config Class Initialized
INFO - 2016-05-03 20:03:06 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:03:06 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:03:06 --> Utf8 Class Initialized
INFO - 2016-05-03 20:03:06 --> URI Class Initialized
INFO - 2016-05-03 20:03:06 --> Router Class Initialized
INFO - 2016-05-03 20:03:06 --> Output Class Initialized
INFO - 2016-05-03 20:03:06 --> Security Class Initialized
DEBUG - 2016-05-03 20:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:03:06 --> Input Class Initialized
INFO - 2016-05-03 20:03:06 --> Language Class Initialized
INFO - 2016-05-03 20:03:06 --> Loader Class Initialized
INFO - 2016-05-03 20:03:06 --> Helper loaded: url_helper
INFO - 2016-05-03 20:03:06 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:03:06 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:03:06 --> Helper loaded: form_helper
INFO - 2016-05-03 20:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:03:06 --> Form Validation Class Initialized
INFO - 2016-05-03 20:03:06 --> Controller Class Initialized
INFO - 2016-05-03 20:03:06 --> Model Class Initialized
INFO - 2016-05-03 20:03:06 --> Database Driver Class Initialized
INFO - 2016-05-03 20:03:06 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:03:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:03:06 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:03:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:03:06 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:03:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:03:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:03:06 --> Final output sent to browser
DEBUG - 2016-05-03 20:03:06 --> Total execution time: 0.0938
INFO - 2016-05-03 20:04:48 --> Config Class Initialized
INFO - 2016-05-03 20:04:48 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:04:48 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:04:48 --> Utf8 Class Initialized
INFO - 2016-05-03 20:04:48 --> URI Class Initialized
INFO - 2016-05-03 20:04:48 --> Router Class Initialized
INFO - 2016-05-03 20:04:48 --> Output Class Initialized
INFO - 2016-05-03 20:04:48 --> Security Class Initialized
DEBUG - 2016-05-03 20:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:04:48 --> Input Class Initialized
INFO - 2016-05-03 20:04:48 --> Language Class Initialized
INFO - 2016-05-03 20:04:48 --> Loader Class Initialized
INFO - 2016-05-03 20:04:48 --> Helper loaded: url_helper
INFO - 2016-05-03 20:04:48 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:04:48 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:04:48 --> Helper loaded: form_helper
INFO - 2016-05-03 20:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:04:48 --> Form Validation Class Initialized
INFO - 2016-05-03 20:04:48 --> Controller Class Initialized
INFO - 2016-05-03 20:04:48 --> Model Class Initialized
INFO - 2016-05-03 20:04:48 --> Database Driver Class Initialized
INFO - 2016-05-03 20:04:48 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:04:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:04:48 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:04:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:04:48 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:04:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:04:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:04:48 --> Final output sent to browser
DEBUG - 2016-05-03 20:04:48 --> Total execution time: 0.1255
INFO - 2016-05-03 20:05:05 --> Config Class Initialized
INFO - 2016-05-03 20:05:05 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:05:05 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:05:05 --> Utf8 Class Initialized
INFO - 2016-05-03 20:05:05 --> URI Class Initialized
INFO - 2016-05-03 20:05:05 --> Router Class Initialized
INFO - 2016-05-03 20:05:05 --> Output Class Initialized
INFO - 2016-05-03 20:05:05 --> Security Class Initialized
DEBUG - 2016-05-03 20:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:05:05 --> Input Class Initialized
INFO - 2016-05-03 20:05:05 --> Language Class Initialized
INFO - 2016-05-03 20:05:05 --> Loader Class Initialized
INFO - 2016-05-03 20:05:05 --> Helper loaded: url_helper
INFO - 2016-05-03 20:05:05 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:05:05 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:05:05 --> Helper loaded: form_helper
INFO - 2016-05-03 20:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:05:05 --> Form Validation Class Initialized
INFO - 2016-05-03 20:05:05 --> Controller Class Initialized
INFO - 2016-05-03 20:05:05 --> Model Class Initialized
INFO - 2016-05-03 20:05:05 --> Database Driver Class Initialized
INFO - 2016-05-03 20:05:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:05:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:05:05 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:05:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:05:05 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:05:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:05:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:05:05 --> Final output sent to browser
DEBUG - 2016-05-03 20:05:05 --> Total execution time: 0.1027
INFO - 2016-05-03 20:05:17 --> Config Class Initialized
INFO - 2016-05-03 20:05:17 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:05:17 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:05:17 --> Utf8 Class Initialized
INFO - 2016-05-03 20:05:17 --> URI Class Initialized
INFO - 2016-05-03 20:05:17 --> Router Class Initialized
INFO - 2016-05-03 20:05:17 --> Output Class Initialized
INFO - 2016-05-03 20:05:17 --> Security Class Initialized
DEBUG - 2016-05-03 20:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:05:17 --> Input Class Initialized
INFO - 2016-05-03 20:05:17 --> Language Class Initialized
INFO - 2016-05-03 20:05:17 --> Loader Class Initialized
INFO - 2016-05-03 20:05:17 --> Helper loaded: url_helper
INFO - 2016-05-03 20:05:17 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:05:17 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:05:17 --> Helper loaded: form_helper
INFO - 2016-05-03 20:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:05:17 --> Form Validation Class Initialized
INFO - 2016-05-03 20:05:17 --> Controller Class Initialized
INFO - 2016-05-03 20:05:17 --> Model Class Initialized
INFO - 2016-05-03 20:05:17 --> Database Driver Class Initialized
INFO - 2016-05-03 20:05:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:05:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:05:17 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:05:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:05:17 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:05:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:05:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:05:17 --> Final output sent to browser
DEBUG - 2016-05-03 20:05:17 --> Total execution time: 0.0896
INFO - 2016-05-03 20:05:19 --> Config Class Initialized
INFO - 2016-05-03 20:05:19 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:05:19 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:05:19 --> Utf8 Class Initialized
INFO - 2016-05-03 20:05:19 --> URI Class Initialized
INFO - 2016-05-03 20:05:19 --> Router Class Initialized
INFO - 2016-05-03 20:05:19 --> Output Class Initialized
INFO - 2016-05-03 20:05:19 --> Security Class Initialized
DEBUG - 2016-05-03 20:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:05:19 --> Input Class Initialized
INFO - 2016-05-03 20:05:19 --> Language Class Initialized
INFO - 2016-05-03 20:05:19 --> Loader Class Initialized
INFO - 2016-05-03 20:05:19 --> Helper loaded: url_helper
INFO - 2016-05-03 20:05:19 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:05:19 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:05:19 --> Helper loaded: form_helper
INFO - 2016-05-03 20:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:05:19 --> Form Validation Class Initialized
INFO - 2016-05-03 20:05:19 --> Controller Class Initialized
INFO - 2016-05-03 20:05:19 --> Model Class Initialized
INFO - 2016-05-03 20:05:19 --> Database Driver Class Initialized
INFO - 2016-05-03 20:05:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:05:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:05:19 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:05:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:05:19 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:05:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:05:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:05:19 --> Final output sent to browser
DEBUG - 2016-05-03 20:05:19 --> Total execution time: 0.0795
INFO - 2016-05-03 20:05:44 --> Config Class Initialized
INFO - 2016-05-03 20:05:44 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:05:44 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:05:44 --> Utf8 Class Initialized
INFO - 2016-05-03 20:05:44 --> URI Class Initialized
INFO - 2016-05-03 20:05:44 --> Router Class Initialized
INFO - 2016-05-03 20:05:44 --> Output Class Initialized
INFO - 2016-05-03 20:05:44 --> Security Class Initialized
DEBUG - 2016-05-03 20:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:05:44 --> Input Class Initialized
INFO - 2016-05-03 20:05:44 --> Language Class Initialized
INFO - 2016-05-03 20:05:44 --> Loader Class Initialized
INFO - 2016-05-03 20:05:44 --> Helper loaded: url_helper
INFO - 2016-05-03 20:05:44 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:05:44 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:05:44 --> Helper loaded: form_helper
INFO - 2016-05-03 20:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:05:44 --> Form Validation Class Initialized
INFO - 2016-05-03 20:05:44 --> Controller Class Initialized
INFO - 2016-05-03 20:05:44 --> Model Class Initialized
INFO - 2016-05-03 20:05:44 --> Database Driver Class Initialized
INFO - 2016-05-03 20:05:44 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:05:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:05:44 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:05:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:05:44 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:05:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:05:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:05:44 --> Final output sent to browser
DEBUG - 2016-05-03 20:05:44 --> Total execution time: 0.0839
INFO - 2016-05-03 20:07:45 --> Config Class Initialized
INFO - 2016-05-03 20:07:45 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:07:45 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:07:45 --> Utf8 Class Initialized
INFO - 2016-05-03 20:07:45 --> URI Class Initialized
INFO - 2016-05-03 20:07:45 --> Router Class Initialized
INFO - 2016-05-03 20:07:45 --> Output Class Initialized
INFO - 2016-05-03 20:07:45 --> Security Class Initialized
DEBUG - 2016-05-03 20:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:07:45 --> Input Class Initialized
INFO - 2016-05-03 20:07:45 --> Language Class Initialized
INFO - 2016-05-03 20:07:45 --> Loader Class Initialized
INFO - 2016-05-03 20:07:45 --> Helper loaded: url_helper
INFO - 2016-05-03 20:07:45 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:07:45 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:07:45 --> Helper loaded: form_helper
INFO - 2016-05-03 20:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:07:45 --> Form Validation Class Initialized
INFO - 2016-05-03 20:07:45 --> Controller Class Initialized
INFO - 2016-05-03 20:07:45 --> Model Class Initialized
INFO - 2016-05-03 20:07:45 --> Database Driver Class Initialized
INFO - 2016-05-03 20:07:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:07:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:07:45 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:07:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:07:45 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:07:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:07:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:07:45 --> Final output sent to browser
DEBUG - 2016-05-03 20:07:45 --> Total execution time: 0.0899
INFO - 2016-05-03 20:08:03 --> Config Class Initialized
INFO - 2016-05-03 20:08:03 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:08:03 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:08:03 --> Utf8 Class Initialized
INFO - 2016-05-03 20:08:03 --> URI Class Initialized
INFO - 2016-05-03 20:08:03 --> Router Class Initialized
INFO - 2016-05-03 20:08:03 --> Output Class Initialized
INFO - 2016-05-03 20:08:03 --> Security Class Initialized
DEBUG - 2016-05-03 20:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:08:03 --> Input Class Initialized
INFO - 2016-05-03 20:08:03 --> Language Class Initialized
INFO - 2016-05-03 20:08:03 --> Loader Class Initialized
INFO - 2016-05-03 20:08:03 --> Helper loaded: url_helper
INFO - 2016-05-03 20:08:03 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:08:03 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:08:03 --> Helper loaded: form_helper
INFO - 2016-05-03 20:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:08:03 --> Form Validation Class Initialized
INFO - 2016-05-03 20:08:03 --> Controller Class Initialized
INFO - 2016-05-03 20:08:03 --> Model Class Initialized
INFO - 2016-05-03 20:08:03 --> Database Driver Class Initialized
INFO - 2016-05-03 20:08:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:08:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:08:03 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:08:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:08:03 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:08:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:08:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:08:03 --> Final output sent to browser
DEBUG - 2016-05-03 20:08:03 --> Total execution time: 0.0812
INFO - 2016-05-03 20:08:51 --> Config Class Initialized
INFO - 2016-05-03 20:08:51 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:08:51 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:08:51 --> Utf8 Class Initialized
INFO - 2016-05-03 20:08:51 --> URI Class Initialized
INFO - 2016-05-03 20:08:51 --> Router Class Initialized
INFO - 2016-05-03 20:08:51 --> Output Class Initialized
INFO - 2016-05-03 20:08:51 --> Security Class Initialized
DEBUG - 2016-05-03 20:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:08:51 --> Input Class Initialized
INFO - 2016-05-03 20:08:51 --> Language Class Initialized
INFO - 2016-05-03 20:08:51 --> Loader Class Initialized
INFO - 2016-05-03 20:08:51 --> Helper loaded: url_helper
INFO - 2016-05-03 20:08:51 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:08:51 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:08:51 --> Helper loaded: form_helper
INFO - 2016-05-03 20:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:08:51 --> Form Validation Class Initialized
INFO - 2016-05-03 20:08:51 --> Controller Class Initialized
INFO - 2016-05-03 20:08:51 --> Model Class Initialized
INFO - 2016-05-03 20:08:51 --> Database Driver Class Initialized
INFO - 2016-05-03 20:08:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:08:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:08:51 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:08:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:08:51 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:08:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:08:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:08:51 --> Final output sent to browser
DEBUG - 2016-05-03 20:08:51 --> Total execution time: 0.0815
INFO - 2016-05-03 20:08:56 --> Config Class Initialized
INFO - 2016-05-03 20:08:56 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:08:56 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:08:56 --> Utf8 Class Initialized
INFO - 2016-05-03 20:08:56 --> URI Class Initialized
INFO - 2016-05-03 20:08:56 --> Router Class Initialized
INFO - 2016-05-03 20:08:56 --> Output Class Initialized
INFO - 2016-05-03 20:08:56 --> Security Class Initialized
DEBUG - 2016-05-03 20:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:08:56 --> Input Class Initialized
INFO - 2016-05-03 20:08:56 --> Language Class Initialized
INFO - 2016-05-03 20:08:56 --> Loader Class Initialized
INFO - 2016-05-03 20:08:56 --> Helper loaded: url_helper
INFO - 2016-05-03 20:08:56 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:08:56 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:08:56 --> Helper loaded: form_helper
INFO - 2016-05-03 20:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:08:56 --> Form Validation Class Initialized
INFO - 2016-05-03 20:08:56 --> Controller Class Initialized
INFO - 2016-05-03 20:08:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-03 20:08:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:08:56 --> Final output sent to browser
DEBUG - 2016-05-03 20:08:56 --> Total execution time: 0.1383
INFO - 2016-05-03 20:08:58 --> Config Class Initialized
INFO - 2016-05-03 20:08:58 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:08:58 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:08:58 --> Utf8 Class Initialized
INFO - 2016-05-03 20:08:58 --> URI Class Initialized
INFO - 2016-05-03 20:08:58 --> Router Class Initialized
INFO - 2016-05-03 20:08:58 --> Output Class Initialized
INFO - 2016-05-03 20:08:58 --> Security Class Initialized
DEBUG - 2016-05-03 20:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:08:58 --> Input Class Initialized
INFO - 2016-05-03 20:08:58 --> Language Class Initialized
INFO - 2016-05-03 20:08:58 --> Loader Class Initialized
INFO - 2016-05-03 20:08:58 --> Helper loaded: url_helper
INFO - 2016-05-03 20:08:58 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:08:58 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:08:58 --> Helper loaded: form_helper
INFO - 2016-05-03 20:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:08:58 --> Form Validation Class Initialized
INFO - 2016-05-03 20:08:58 --> Controller Class Initialized
INFO - 2016-05-03 20:08:58 --> Config Class Initialized
INFO - 2016-05-03 20:08:58 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:08:58 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:08:58 --> Utf8 Class Initialized
INFO - 2016-05-03 20:08:58 --> URI Class Initialized
INFO - 2016-05-03 20:08:58 --> Router Class Initialized
INFO - 2016-05-03 20:08:58 --> Output Class Initialized
INFO - 2016-05-03 20:08:58 --> Security Class Initialized
DEBUG - 2016-05-03 20:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:08:58 --> Input Class Initialized
INFO - 2016-05-03 20:08:58 --> Language Class Initialized
INFO - 2016-05-03 20:08:58 --> Loader Class Initialized
INFO - 2016-05-03 20:08:58 --> Helper loaded: url_helper
INFO - 2016-05-03 20:08:58 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:08:58 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:08:58 --> Helper loaded: form_helper
INFO - 2016-05-03 20:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:08:58 --> Form Validation Class Initialized
INFO - 2016-05-03 20:08:58 --> Controller Class Initialized
INFO - 2016-05-03 20:08:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-03 20:08:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:08:58 --> Final output sent to browser
DEBUG - 2016-05-03 20:08:58 --> Total execution time: 0.1144
INFO - 2016-05-03 20:09:01 --> Config Class Initialized
INFO - 2016-05-03 20:09:01 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:09:01 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:09:01 --> Utf8 Class Initialized
INFO - 2016-05-03 20:09:01 --> URI Class Initialized
INFO - 2016-05-03 20:09:01 --> Router Class Initialized
INFO - 2016-05-03 20:09:01 --> Output Class Initialized
INFO - 2016-05-03 20:09:01 --> Security Class Initialized
DEBUG - 2016-05-03 20:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:09:01 --> Input Class Initialized
INFO - 2016-05-03 20:09:01 --> Language Class Initialized
INFO - 2016-05-03 20:09:01 --> Loader Class Initialized
INFO - 2016-05-03 20:09:01 --> Helper loaded: url_helper
INFO - 2016-05-03 20:09:01 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:09:01 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:09:01 --> Helper loaded: form_helper
INFO - 2016-05-03 20:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:09:01 --> Form Validation Class Initialized
INFO - 2016-05-03 20:09:01 --> Controller Class Initialized
INFO - 2016-05-03 20:09:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-03 20:09:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:09:01 --> Final output sent to browser
DEBUG - 2016-05-03 20:09:01 --> Total execution time: 0.0525
INFO - 2016-05-03 20:09:04 --> Config Class Initialized
INFO - 2016-05-03 20:09:04 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:09:04 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:09:04 --> Utf8 Class Initialized
INFO - 2016-05-03 20:09:04 --> URI Class Initialized
INFO - 2016-05-03 20:09:04 --> Router Class Initialized
INFO - 2016-05-03 20:09:04 --> Output Class Initialized
INFO - 2016-05-03 20:09:04 --> Security Class Initialized
DEBUG - 2016-05-03 20:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:09:04 --> Input Class Initialized
INFO - 2016-05-03 20:09:04 --> Language Class Initialized
INFO - 2016-05-03 20:09:04 --> Loader Class Initialized
INFO - 2016-05-03 20:09:04 --> Helper loaded: url_helper
INFO - 2016-05-03 20:09:04 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:09:04 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:09:04 --> Helper loaded: form_helper
INFO - 2016-05-03 20:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:09:04 --> Form Validation Class Initialized
INFO - 2016-05-03 20:09:04 --> Controller Class Initialized
INFO - 2016-05-03 20:09:04 --> Model Class Initialized
INFO - 2016-05-03 20:09:04 --> Database Driver Class Initialized
INFO - 2016-05-03 20:09:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:09:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:09:04 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:09:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:09:04 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:09:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:09:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:09:04 --> Final output sent to browser
DEBUG - 2016-05-03 20:09:04 --> Total execution time: 0.1045
INFO - 2016-05-03 20:09:38 --> Config Class Initialized
INFO - 2016-05-03 20:09:38 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:09:38 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:09:38 --> Utf8 Class Initialized
INFO - 2016-05-03 20:09:38 --> URI Class Initialized
INFO - 2016-05-03 20:09:38 --> Router Class Initialized
INFO - 2016-05-03 20:09:38 --> Output Class Initialized
INFO - 2016-05-03 20:09:38 --> Security Class Initialized
DEBUG - 2016-05-03 20:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:09:38 --> Input Class Initialized
INFO - 2016-05-03 20:09:38 --> Language Class Initialized
INFO - 2016-05-03 20:09:38 --> Loader Class Initialized
INFO - 2016-05-03 20:09:38 --> Helper loaded: url_helper
INFO - 2016-05-03 20:09:38 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:09:38 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:09:38 --> Helper loaded: form_helper
INFO - 2016-05-03 20:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:09:38 --> Form Validation Class Initialized
INFO - 2016-05-03 20:09:38 --> Controller Class Initialized
INFO - 2016-05-03 20:09:38 --> Model Class Initialized
INFO - 2016-05-03 20:09:38 --> Database Driver Class Initialized
INFO - 2016-05-03 20:09:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:09:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:09:38 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:09:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:09:38 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:09:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:09:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:09:38 --> Final output sent to browser
DEBUG - 2016-05-03 20:09:38 --> Total execution time: 0.0907
INFO - 2016-05-03 20:09:59 --> Config Class Initialized
INFO - 2016-05-03 20:09:59 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:09:59 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:09:59 --> Utf8 Class Initialized
INFO - 2016-05-03 20:09:59 --> URI Class Initialized
INFO - 2016-05-03 20:09:59 --> Router Class Initialized
INFO - 2016-05-03 20:09:59 --> Output Class Initialized
INFO - 2016-05-03 20:09:59 --> Security Class Initialized
DEBUG - 2016-05-03 20:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:09:59 --> Input Class Initialized
INFO - 2016-05-03 20:09:59 --> Language Class Initialized
INFO - 2016-05-03 20:10:00 --> Loader Class Initialized
INFO - 2016-05-03 20:10:00 --> Helper loaded: url_helper
INFO - 2016-05-03 20:10:00 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:10:00 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:10:00 --> Helper loaded: form_helper
INFO - 2016-05-03 20:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:10:00 --> Form Validation Class Initialized
INFO - 2016-05-03 20:10:00 --> Controller Class Initialized
INFO - 2016-05-03 20:10:00 --> Model Class Initialized
INFO - 2016-05-03 20:10:00 --> Database Driver Class Initialized
INFO - 2016-05-03 20:10:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:10:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:10:00 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:10:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:10:00 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:10:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:10:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:10:00 --> Final output sent to browser
DEBUG - 2016-05-03 20:10:00 --> Total execution time: 0.0860
INFO - 2016-05-03 20:10:04 --> Config Class Initialized
INFO - 2016-05-03 20:10:04 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:10:04 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:10:04 --> Utf8 Class Initialized
INFO - 2016-05-03 20:10:04 --> URI Class Initialized
INFO - 2016-05-03 20:10:04 --> Router Class Initialized
INFO - 2016-05-03 20:10:04 --> Output Class Initialized
INFO - 2016-05-03 20:10:04 --> Security Class Initialized
DEBUG - 2016-05-03 20:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:10:04 --> Input Class Initialized
INFO - 2016-05-03 20:10:04 --> Language Class Initialized
INFO - 2016-05-03 20:10:04 --> Loader Class Initialized
INFO - 2016-05-03 20:10:04 --> Helper loaded: url_helper
INFO - 2016-05-03 20:10:04 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:10:04 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:10:04 --> Helper loaded: form_helper
INFO - 2016-05-03 20:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:10:04 --> Form Validation Class Initialized
INFO - 2016-05-03 20:10:04 --> Controller Class Initialized
INFO - 2016-05-03 20:10:04 --> Model Class Initialized
INFO - 2016-05-03 20:10:04 --> Database Driver Class Initialized
INFO - 2016-05-03 20:10:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:10:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:10:04 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:10:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:10:04 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:10:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:10:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:10:04 --> Final output sent to browser
DEBUG - 2016-05-03 20:10:04 --> Total execution time: 0.0839
INFO - 2016-05-03 20:10:42 --> Config Class Initialized
INFO - 2016-05-03 20:10:42 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:10:42 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:10:42 --> Utf8 Class Initialized
INFO - 2016-05-03 20:10:42 --> URI Class Initialized
INFO - 2016-05-03 20:10:42 --> Router Class Initialized
INFO - 2016-05-03 20:10:42 --> Output Class Initialized
INFO - 2016-05-03 20:10:42 --> Security Class Initialized
DEBUG - 2016-05-03 20:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:10:42 --> Input Class Initialized
INFO - 2016-05-03 20:10:42 --> Language Class Initialized
INFO - 2016-05-03 20:10:42 --> Loader Class Initialized
INFO - 2016-05-03 20:10:42 --> Helper loaded: url_helper
INFO - 2016-05-03 20:10:42 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:10:42 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:10:42 --> Helper loaded: form_helper
INFO - 2016-05-03 20:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:10:42 --> Form Validation Class Initialized
INFO - 2016-05-03 20:10:42 --> Controller Class Initialized
INFO - 2016-05-03 20:10:42 --> Model Class Initialized
INFO - 2016-05-03 20:10:42 --> Database Driver Class Initialized
INFO - 2016-05-03 20:10:42 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:10:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:10:42 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:10:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:10:42 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:10:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:10:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:10:42 --> Final output sent to browser
DEBUG - 2016-05-03 20:10:42 --> Total execution time: 0.0867
INFO - 2016-05-03 20:12:13 --> Config Class Initialized
INFO - 2016-05-03 20:12:13 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:12:13 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:12:13 --> Utf8 Class Initialized
INFO - 2016-05-03 20:12:13 --> URI Class Initialized
INFO - 2016-05-03 20:12:13 --> Router Class Initialized
INFO - 2016-05-03 20:12:13 --> Output Class Initialized
INFO - 2016-05-03 20:12:13 --> Security Class Initialized
DEBUG - 2016-05-03 20:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:12:13 --> Input Class Initialized
INFO - 2016-05-03 20:12:13 --> Language Class Initialized
INFO - 2016-05-03 20:12:13 --> Loader Class Initialized
INFO - 2016-05-03 20:12:13 --> Helper loaded: url_helper
INFO - 2016-05-03 20:12:13 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:12:13 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:12:13 --> Helper loaded: form_helper
INFO - 2016-05-03 20:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:12:13 --> Form Validation Class Initialized
INFO - 2016-05-03 20:12:13 --> Controller Class Initialized
INFO - 2016-05-03 20:12:13 --> Model Class Initialized
INFO - 2016-05-03 20:12:13 --> Database Driver Class Initialized
INFO - 2016-05-03 20:12:13 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:12:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:12:13 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:12:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:12:13 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:12:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:12:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:12:13 --> Final output sent to browser
DEBUG - 2016-05-03 20:12:13 --> Total execution time: 0.0911
INFO - 2016-05-03 20:13:03 --> Config Class Initialized
INFO - 2016-05-03 20:13:03 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:13:03 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:13:03 --> Utf8 Class Initialized
INFO - 2016-05-03 20:13:03 --> URI Class Initialized
INFO - 2016-05-03 20:13:03 --> Router Class Initialized
INFO - 2016-05-03 20:13:03 --> Output Class Initialized
INFO - 2016-05-03 20:13:03 --> Security Class Initialized
DEBUG - 2016-05-03 20:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:13:03 --> Input Class Initialized
INFO - 2016-05-03 20:13:03 --> Language Class Initialized
INFO - 2016-05-03 20:13:03 --> Loader Class Initialized
INFO - 2016-05-03 20:13:03 --> Helper loaded: url_helper
INFO - 2016-05-03 20:13:03 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:13:03 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:13:03 --> Helper loaded: form_helper
INFO - 2016-05-03 20:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:13:03 --> Form Validation Class Initialized
INFO - 2016-05-03 20:13:03 --> Controller Class Initialized
INFO - 2016-05-03 20:13:03 --> Model Class Initialized
INFO - 2016-05-03 20:13:03 --> Database Driver Class Initialized
INFO - 2016-05-03 20:13:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:13:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:13:03 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:13:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:13:03 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:13:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:13:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:13:03 --> Final output sent to browser
DEBUG - 2016-05-03 20:13:03 --> Total execution time: 0.0806
INFO - 2016-05-03 20:16:17 --> Config Class Initialized
INFO - 2016-05-03 20:16:17 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:16:17 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:16:17 --> Utf8 Class Initialized
INFO - 2016-05-03 20:16:17 --> URI Class Initialized
INFO - 2016-05-03 20:16:17 --> Router Class Initialized
INFO - 2016-05-03 20:16:17 --> Output Class Initialized
INFO - 2016-05-03 20:16:17 --> Security Class Initialized
DEBUG - 2016-05-03 20:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:16:17 --> Input Class Initialized
INFO - 2016-05-03 20:16:17 --> Language Class Initialized
INFO - 2016-05-03 20:16:17 --> Loader Class Initialized
INFO - 2016-05-03 20:16:17 --> Helper loaded: url_helper
INFO - 2016-05-03 20:16:17 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:16:17 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:16:17 --> Helper loaded: form_helper
INFO - 2016-05-03 20:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:16:17 --> Form Validation Class Initialized
INFO - 2016-05-03 20:16:17 --> Controller Class Initialized
INFO - 2016-05-03 20:16:17 --> Model Class Initialized
INFO - 2016-05-03 20:16:17 --> Database Driver Class Initialized
INFO - 2016-05-03 20:16:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:16:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:16:17 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:16:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:16:17 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:16:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:16:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:16:17 --> Final output sent to browser
DEBUG - 2016-05-03 20:16:17 --> Total execution time: 0.1086
INFO - 2016-05-03 20:16:21 --> Config Class Initialized
INFO - 2016-05-03 20:16:21 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:16:21 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:16:21 --> Utf8 Class Initialized
INFO - 2016-05-03 20:16:21 --> URI Class Initialized
INFO - 2016-05-03 20:16:21 --> Router Class Initialized
INFO - 2016-05-03 20:16:21 --> Output Class Initialized
INFO - 2016-05-03 20:16:21 --> Security Class Initialized
DEBUG - 2016-05-03 20:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:16:21 --> Input Class Initialized
INFO - 2016-05-03 20:16:21 --> Language Class Initialized
INFO - 2016-05-03 20:16:21 --> Loader Class Initialized
INFO - 2016-05-03 20:16:21 --> Helper loaded: url_helper
INFO - 2016-05-03 20:16:21 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:16:21 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:16:21 --> Helper loaded: form_helper
INFO - 2016-05-03 20:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:16:21 --> Form Validation Class Initialized
INFO - 2016-05-03 20:16:21 --> Controller Class Initialized
INFO - 2016-05-03 20:16:21 --> Model Class Initialized
INFO - 2016-05-03 20:16:21 --> Database Driver Class Initialized
INFO - 2016-05-03 20:16:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:16:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:16:21 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:16:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:16:21 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 20:16:21 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProveedor.php 15
INFO - 2016-05-03 20:16:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProveedor.php
INFO - 2016-05-03 20:16:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:16:21 --> Final output sent to browser
DEBUG - 2016-05-03 20:16:21 --> Total execution time: 0.1591
INFO - 2016-05-03 20:16:22 --> Config Class Initialized
INFO - 2016-05-03 20:16:22 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:16:22 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:16:22 --> Utf8 Class Initialized
INFO - 2016-05-03 20:16:22 --> URI Class Initialized
INFO - 2016-05-03 20:16:22 --> Router Class Initialized
INFO - 2016-05-03 20:16:22 --> Output Class Initialized
INFO - 2016-05-03 20:16:22 --> Security Class Initialized
DEBUG - 2016-05-03 20:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:16:22 --> Input Class Initialized
INFO - 2016-05-03 20:16:22 --> Language Class Initialized
INFO - 2016-05-03 20:16:22 --> Loader Class Initialized
INFO - 2016-05-03 20:16:22 --> Helper loaded: url_helper
INFO - 2016-05-03 20:16:22 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:16:22 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:16:22 --> Helper loaded: form_helper
INFO - 2016-05-03 20:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:16:22 --> Form Validation Class Initialized
INFO - 2016-05-03 20:16:22 --> Controller Class Initialized
INFO - 2016-05-03 20:16:22 --> Model Class Initialized
INFO - 2016-05-03 20:16:22 --> Database Driver Class Initialized
INFO - 2016-05-03 20:16:22 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:16:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:16:22 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:16:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:16:22 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:16:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:16:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:16:22 --> Final output sent to browser
DEBUG - 2016-05-03 20:16:22 --> Total execution time: 0.1008
INFO - 2016-05-03 20:16:43 --> Config Class Initialized
INFO - 2016-05-03 20:16:43 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:16:43 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:16:43 --> Utf8 Class Initialized
INFO - 2016-05-03 20:16:43 --> URI Class Initialized
INFO - 2016-05-03 20:16:43 --> Router Class Initialized
INFO - 2016-05-03 20:16:43 --> Output Class Initialized
INFO - 2016-05-03 20:16:43 --> Security Class Initialized
DEBUG - 2016-05-03 20:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:16:43 --> Input Class Initialized
INFO - 2016-05-03 20:16:43 --> Language Class Initialized
INFO - 2016-05-03 20:16:43 --> Loader Class Initialized
INFO - 2016-05-03 20:16:43 --> Helper loaded: url_helper
INFO - 2016-05-03 20:16:43 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:16:43 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:16:43 --> Helper loaded: form_helper
INFO - 2016-05-03 20:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:16:43 --> Form Validation Class Initialized
INFO - 2016-05-03 20:16:43 --> Controller Class Initialized
INFO - 2016-05-03 20:16:43 --> Model Class Initialized
INFO - 2016-05-03 20:16:43 --> Database Driver Class Initialized
INFO - 2016-05-03 20:16:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:16:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:16:43 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:16:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:16:43 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 39
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 69
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 72
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 85
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 39
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 44
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 47
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 60
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 39
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 69
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 72
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 85
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 39
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 44
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 47
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 60
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 39
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 44
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 47
ERROR - 2016-05-03 20:16:43 --> Severity: Notice --> Undefined index: idCategoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 60
INFO - 2016-05-03 20:16:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:16:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:16:43 --> Final output sent to browser
DEBUG - 2016-05-03 20:16:43 --> Total execution time: 0.1395
INFO - 2016-05-03 20:17:15 --> Config Class Initialized
INFO - 2016-05-03 20:17:15 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:17:15 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:17:15 --> Utf8 Class Initialized
INFO - 2016-05-03 20:17:15 --> URI Class Initialized
INFO - 2016-05-03 20:17:15 --> Router Class Initialized
INFO - 2016-05-03 20:17:15 --> Output Class Initialized
INFO - 2016-05-03 20:17:15 --> Security Class Initialized
DEBUG - 2016-05-03 20:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:17:15 --> Input Class Initialized
INFO - 2016-05-03 20:17:15 --> Language Class Initialized
INFO - 2016-05-03 20:17:15 --> Loader Class Initialized
INFO - 2016-05-03 20:17:15 --> Helper loaded: url_helper
INFO - 2016-05-03 20:17:15 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:17:15 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:17:15 --> Helper loaded: form_helper
INFO - 2016-05-03 20:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:17:15 --> Form Validation Class Initialized
INFO - 2016-05-03 20:17:15 --> Controller Class Initialized
INFO - 2016-05-03 20:17:15 --> Model Class Initialized
INFO - 2016-05-03 20:17:15 --> Database Driver Class Initialized
INFO - 2016-05-03 20:17:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:17:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:17:15 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:17:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:17:15 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 39
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 69
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 72
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 85
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 39
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 44
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 47
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 60
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 39
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 69
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 72
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 85
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 39
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 44
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 47
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 60
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 39
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 44
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 47
ERROR - 2016-05-03 20:17:15 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 60
INFO - 2016-05-03 20:17:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:17:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:17:15 --> Final output sent to browser
DEBUG - 2016-05-03 20:17:15 --> Total execution time: 0.1471
INFO - 2016-05-03 20:17:16 --> Config Class Initialized
INFO - 2016-05-03 20:17:16 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:17:16 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:17:16 --> Utf8 Class Initialized
INFO - 2016-05-03 20:17:16 --> URI Class Initialized
INFO - 2016-05-03 20:17:16 --> Router Class Initialized
INFO - 2016-05-03 20:17:16 --> Output Class Initialized
INFO - 2016-05-03 20:17:16 --> Security Class Initialized
DEBUG - 2016-05-03 20:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:17:16 --> Input Class Initialized
INFO - 2016-05-03 20:17:16 --> Language Class Initialized
INFO - 2016-05-03 20:17:17 --> Loader Class Initialized
INFO - 2016-05-03 20:17:17 --> Helper loaded: url_helper
INFO - 2016-05-03 20:17:17 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:17:17 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:17:17 --> Helper loaded: form_helper
INFO - 2016-05-03 20:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:17:17 --> Form Validation Class Initialized
INFO - 2016-05-03 20:17:17 --> Controller Class Initialized
INFO - 2016-05-03 20:17:17 --> Model Class Initialized
INFO - 2016-05-03 20:17:17 --> Database Driver Class Initialized
INFO - 2016-05-03 20:17:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:17:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:17:17 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:17:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:17:17 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 39
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 69
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 72
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 85
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 39
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 44
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 47
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 60
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 39
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 69
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 72
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 85
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 39
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 44
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 47
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 60
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 39
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 44
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 47
ERROR - 2016-05-03 20:17:17 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 60
INFO - 2016-05-03 20:17:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:17:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:17:17 --> Final output sent to browser
DEBUG - 2016-05-03 20:17:17 --> Total execution time: 0.1480
INFO - 2016-05-03 20:17:40 --> Config Class Initialized
INFO - 2016-05-03 20:17:40 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:17:40 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:17:40 --> Utf8 Class Initialized
INFO - 2016-05-03 20:17:40 --> URI Class Initialized
INFO - 2016-05-03 20:17:40 --> Router Class Initialized
INFO - 2016-05-03 20:17:40 --> Output Class Initialized
INFO - 2016-05-03 20:17:40 --> Security Class Initialized
DEBUG - 2016-05-03 20:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:17:40 --> Input Class Initialized
INFO - 2016-05-03 20:17:40 --> Language Class Initialized
INFO - 2016-05-03 20:17:40 --> Loader Class Initialized
INFO - 2016-05-03 20:17:40 --> Helper loaded: url_helper
INFO - 2016-05-03 20:17:40 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:17:40 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:17:40 --> Helper loaded: form_helper
INFO - 2016-05-03 20:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:17:40 --> Form Validation Class Initialized
INFO - 2016-05-03 20:17:40 --> Controller Class Initialized
INFO - 2016-05-03 20:17:40 --> Model Class Initialized
INFO - 2016-05-03 20:17:40 --> Database Driver Class Initialized
INFO - 2016-05-03 20:17:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:17:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:17:40 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:17:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:17:40 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 5
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 41
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 70
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 73
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 86
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 41
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 45
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 48
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 61
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 41
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 70
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 73
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 86
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 41
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 45
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 48
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 61
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 41
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 45
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 48
ERROR - 2016-05-03 20:17:40 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 61
INFO - 2016-05-03 20:17:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:17:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:17:40 --> Final output sent to browser
DEBUG - 2016-05-03 20:17:40 --> Total execution time: 0.1247
INFO - 2016-05-03 20:17:47 --> Config Class Initialized
INFO - 2016-05-03 20:17:47 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:17:47 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:17:47 --> Utf8 Class Initialized
INFO - 2016-05-03 20:17:47 --> URI Class Initialized
INFO - 2016-05-03 20:17:47 --> Router Class Initialized
INFO - 2016-05-03 20:17:47 --> Output Class Initialized
INFO - 2016-05-03 20:17:47 --> Security Class Initialized
DEBUG - 2016-05-03 20:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:17:47 --> Input Class Initialized
INFO - 2016-05-03 20:17:47 --> Language Class Initialized
INFO - 2016-05-03 20:17:47 --> Loader Class Initialized
INFO - 2016-05-03 20:17:47 --> Helper loaded: url_helper
INFO - 2016-05-03 20:17:47 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:17:47 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:17:47 --> Helper loaded: form_helper
INFO - 2016-05-03 20:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:17:47 --> Form Validation Class Initialized
INFO - 2016-05-03 20:17:47 --> Controller Class Initialized
INFO - 2016-05-03 20:17:47 --> Model Class Initialized
INFO - 2016-05-03 20:17:47 --> Database Driver Class Initialized
INFO - 2016-05-03 20:17:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:17:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:17:47 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:17:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:17:47 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 41
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 70
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 73
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 86
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 41
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 45
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 48
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 61
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 41
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 70
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 73
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 86
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 41
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 45
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 48
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 61
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 40
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 41
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 45
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 48
ERROR - 2016-05-03 20:17:47 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 61
INFO - 2016-05-03 20:17:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:17:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:17:47 --> Final output sent to browser
DEBUG - 2016-05-03 20:17:47 --> Total execution time: 0.1836
INFO - 2016-05-03 20:18:15 --> Config Class Initialized
INFO - 2016-05-03 20:18:15 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:18:15 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:18:15 --> Utf8 Class Initialized
INFO - 2016-05-03 20:18:15 --> URI Class Initialized
INFO - 2016-05-03 20:18:15 --> Router Class Initialized
INFO - 2016-05-03 20:18:15 --> Output Class Initialized
INFO - 2016-05-03 20:18:15 --> Security Class Initialized
DEBUG - 2016-05-03 20:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:18:15 --> Input Class Initialized
INFO - 2016-05-03 20:18:15 --> Language Class Initialized
INFO - 2016-05-03 20:18:15 --> Loader Class Initialized
INFO - 2016-05-03 20:18:15 --> Helper loaded: url_helper
INFO - 2016-05-03 20:18:15 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:18:15 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:18:15 --> Helper loaded: form_helper
INFO - 2016-05-03 20:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:18:15 --> Form Validation Class Initialized
INFO - 2016-05-03 20:18:15 --> Controller Class Initialized
INFO - 2016-05-03 20:18:15 --> Model Class Initialized
INFO - 2016-05-03 20:18:15 --> Database Driver Class Initialized
INFO - 2016-05-03 20:18:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:18:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:18:15 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:18:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:18:15 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:18:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:18:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:18:15 --> Final output sent to browser
DEBUG - 2016-05-03 20:18:15 --> Total execution time: 0.0854
INFO - 2016-05-03 20:18:29 --> Config Class Initialized
INFO - 2016-05-03 20:18:29 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:18:29 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:18:29 --> Utf8 Class Initialized
INFO - 2016-05-03 20:18:29 --> URI Class Initialized
INFO - 2016-05-03 20:18:29 --> Router Class Initialized
INFO - 2016-05-03 20:18:29 --> Output Class Initialized
INFO - 2016-05-03 20:18:29 --> Security Class Initialized
DEBUG - 2016-05-03 20:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:18:29 --> Input Class Initialized
INFO - 2016-05-03 20:18:29 --> Language Class Initialized
INFO - 2016-05-03 20:18:29 --> Loader Class Initialized
INFO - 2016-05-03 20:18:29 --> Helper loaded: url_helper
INFO - 2016-05-03 20:18:29 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:18:29 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:18:29 --> Helper loaded: form_helper
INFO - 2016-05-03 20:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:18:29 --> Form Validation Class Initialized
INFO - 2016-05-03 20:18:29 --> Controller Class Initialized
INFO - 2016-05-03 20:18:29 --> Model Class Initialized
INFO - 2016-05-03 20:18:29 --> Database Driver Class Initialized
INFO - 2016-05-03 20:18:29 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:18:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:18:29 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:18:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:18:29 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:18:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:18:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:18:29 --> Final output sent to browser
DEBUG - 2016-05-03 20:18:29 --> Total execution time: 0.0895
INFO - 2016-05-03 20:19:02 --> Config Class Initialized
INFO - 2016-05-03 20:19:02 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:19:02 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:19:02 --> Utf8 Class Initialized
INFO - 2016-05-03 20:19:02 --> URI Class Initialized
INFO - 2016-05-03 20:19:02 --> Router Class Initialized
INFO - 2016-05-03 20:19:02 --> Output Class Initialized
INFO - 2016-05-03 20:19:02 --> Security Class Initialized
DEBUG - 2016-05-03 20:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:19:02 --> Input Class Initialized
INFO - 2016-05-03 20:19:02 --> Language Class Initialized
INFO - 2016-05-03 20:19:02 --> Loader Class Initialized
INFO - 2016-05-03 20:19:02 --> Helper loaded: url_helper
INFO - 2016-05-03 20:19:02 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:19:02 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:19:02 --> Helper loaded: form_helper
INFO - 2016-05-03 20:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:19:02 --> Form Validation Class Initialized
INFO - 2016-05-03 20:19:02 --> Controller Class Initialized
INFO - 2016-05-03 20:19:02 --> Model Class Initialized
INFO - 2016-05-03 20:19:02 --> Database Driver Class Initialized
INFO - 2016-05-03 20:19:02 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:19:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:19:02 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:19:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:19:02 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 20:19:02 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProveedor.php 15
INFO - 2016-05-03 20:19:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProveedor.php
INFO - 2016-05-03 20:19:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:19:02 --> Final output sent to browser
DEBUG - 2016-05-03 20:19:02 --> Total execution time: 0.0854
INFO - 2016-05-03 20:19:29 --> Config Class Initialized
INFO - 2016-05-03 20:19:29 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:19:29 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:19:29 --> Utf8 Class Initialized
INFO - 2016-05-03 20:19:29 --> URI Class Initialized
INFO - 2016-05-03 20:19:29 --> Router Class Initialized
INFO - 2016-05-03 20:19:29 --> Output Class Initialized
INFO - 2016-05-03 20:19:29 --> Security Class Initialized
DEBUG - 2016-05-03 20:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:19:29 --> Input Class Initialized
INFO - 2016-05-03 20:19:29 --> Language Class Initialized
INFO - 2016-05-03 20:19:29 --> Loader Class Initialized
INFO - 2016-05-03 20:19:29 --> Helper loaded: url_helper
INFO - 2016-05-03 20:19:29 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:19:29 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:19:29 --> Helper loaded: form_helper
INFO - 2016-05-03 20:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:19:29 --> Form Validation Class Initialized
INFO - 2016-05-03 20:19:29 --> Controller Class Initialized
INFO - 2016-05-03 20:19:29 --> Model Class Initialized
INFO - 2016-05-03 20:19:29 --> Database Driver Class Initialized
INFO - 2016-05-03 20:19:29 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:19:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:19:29 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:19:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:19:29 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:19:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProveedor.php
INFO - 2016-05-03 20:19:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:19:29 --> Final output sent to browser
DEBUG - 2016-05-03 20:19:29 --> Total execution time: 0.0987
INFO - 2016-05-03 20:19:32 --> Config Class Initialized
INFO - 2016-05-03 20:19:32 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:19:32 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:19:32 --> Utf8 Class Initialized
INFO - 2016-05-03 20:19:32 --> URI Class Initialized
INFO - 2016-05-03 20:19:32 --> Router Class Initialized
INFO - 2016-05-03 20:19:32 --> Output Class Initialized
INFO - 2016-05-03 20:19:32 --> Security Class Initialized
DEBUG - 2016-05-03 20:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:19:32 --> Input Class Initialized
INFO - 2016-05-03 20:19:32 --> Language Class Initialized
INFO - 2016-05-03 20:19:32 --> Loader Class Initialized
INFO - 2016-05-03 20:19:32 --> Helper loaded: url_helper
INFO - 2016-05-03 20:19:32 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:19:32 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:19:32 --> Helper loaded: form_helper
INFO - 2016-05-03 20:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:19:32 --> Form Validation Class Initialized
INFO - 2016-05-03 20:19:32 --> Controller Class Initialized
INFO - 2016-05-03 20:19:32 --> Model Class Initialized
INFO - 2016-05-03 20:19:32 --> Database Driver Class Initialized
INFO - 2016-05-03 20:19:32 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:19:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:19:32 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:19:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:19:32 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:19:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProveedor.php
INFO - 2016-05-03 20:19:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:19:32 --> Final output sent to browser
DEBUG - 2016-05-03 20:19:32 --> Total execution time: 0.1266
INFO - 2016-05-03 20:19:33 --> Config Class Initialized
INFO - 2016-05-03 20:19:33 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:19:33 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:19:33 --> Utf8 Class Initialized
INFO - 2016-05-03 20:19:33 --> URI Class Initialized
INFO - 2016-05-03 20:19:33 --> Router Class Initialized
INFO - 2016-05-03 20:19:33 --> Output Class Initialized
INFO - 2016-05-03 20:19:33 --> Security Class Initialized
DEBUG - 2016-05-03 20:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:19:33 --> Input Class Initialized
INFO - 2016-05-03 20:19:33 --> Language Class Initialized
INFO - 2016-05-03 20:19:33 --> Loader Class Initialized
INFO - 2016-05-03 20:19:33 --> Helper loaded: url_helper
INFO - 2016-05-03 20:19:33 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:19:33 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:19:33 --> Helper loaded: form_helper
INFO - 2016-05-03 20:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:19:33 --> Form Validation Class Initialized
INFO - 2016-05-03 20:19:33 --> Controller Class Initialized
INFO - 2016-05-03 20:19:33 --> Model Class Initialized
INFO - 2016-05-03 20:19:33 --> Database Driver Class Initialized
INFO - 2016-05-03 20:19:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:19:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:19:33 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:19:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:19:33 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:19:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProveedor.php
INFO - 2016-05-03 20:19:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:19:33 --> Final output sent to browser
DEBUG - 2016-05-03 20:19:33 --> Total execution time: 0.0808
INFO - 2016-05-03 20:19:36 --> Config Class Initialized
INFO - 2016-05-03 20:19:36 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:19:36 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:19:36 --> Utf8 Class Initialized
INFO - 2016-05-03 20:19:36 --> URI Class Initialized
INFO - 2016-05-03 20:19:36 --> Router Class Initialized
INFO - 2016-05-03 20:19:36 --> Output Class Initialized
INFO - 2016-05-03 20:19:36 --> Security Class Initialized
DEBUG - 2016-05-03 20:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:19:36 --> Input Class Initialized
INFO - 2016-05-03 20:19:36 --> Language Class Initialized
INFO - 2016-05-03 20:19:36 --> Loader Class Initialized
INFO - 2016-05-03 20:19:36 --> Helper loaded: url_helper
INFO - 2016-05-03 20:19:36 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:19:36 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:19:36 --> Helper loaded: form_helper
INFO - 2016-05-03 20:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:19:36 --> Form Validation Class Initialized
INFO - 2016-05-03 20:19:36 --> Controller Class Initialized
INFO - 2016-05-03 20:19:36 --> Model Class Initialized
INFO - 2016-05-03 20:19:36 --> Database Driver Class Initialized
INFO - 2016-05-03 20:19:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:19:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:19:36 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:19:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:19:36 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:19:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:19:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:19:36 --> Final output sent to browser
DEBUG - 2016-05-03 20:19:36 --> Total execution time: 0.0829
INFO - 2016-05-03 20:22:48 --> Config Class Initialized
INFO - 2016-05-03 20:22:48 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:22:48 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:22:48 --> Utf8 Class Initialized
INFO - 2016-05-03 20:22:48 --> URI Class Initialized
INFO - 2016-05-03 20:22:48 --> Router Class Initialized
INFO - 2016-05-03 20:22:48 --> Output Class Initialized
INFO - 2016-05-03 20:22:48 --> Security Class Initialized
DEBUG - 2016-05-03 20:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:22:48 --> Input Class Initialized
INFO - 2016-05-03 20:22:48 --> Language Class Initialized
INFO - 2016-05-03 20:22:48 --> Loader Class Initialized
INFO - 2016-05-03 20:22:48 --> Helper loaded: url_helper
INFO - 2016-05-03 20:22:48 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:22:48 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:22:48 --> Helper loaded: form_helper
INFO - 2016-05-03 20:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:22:48 --> Form Validation Class Initialized
INFO - 2016-05-03 20:22:48 --> Controller Class Initialized
INFO - 2016-05-03 20:22:48 --> Model Class Initialized
INFO - 2016-05-03 20:22:48 --> Database Driver Class Initialized
INFO - 2016-05-03 20:22:48 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:22:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:22:48 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:22:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:22:48 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:22:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:22:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:22:48 --> Final output sent to browser
DEBUG - 2016-05-03 20:22:48 --> Total execution time: 0.1091
INFO - 2016-05-03 20:22:54 --> Config Class Initialized
INFO - 2016-05-03 20:22:54 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:22:54 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:22:54 --> Utf8 Class Initialized
INFO - 2016-05-03 20:22:54 --> URI Class Initialized
INFO - 2016-05-03 20:22:54 --> Router Class Initialized
INFO - 2016-05-03 20:22:54 --> Output Class Initialized
INFO - 2016-05-03 20:22:54 --> Security Class Initialized
DEBUG - 2016-05-03 20:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:22:54 --> Input Class Initialized
INFO - 2016-05-03 20:22:54 --> Language Class Initialized
INFO - 2016-05-03 20:22:54 --> Loader Class Initialized
INFO - 2016-05-03 20:22:54 --> Helper loaded: url_helper
INFO - 2016-05-03 20:22:54 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:22:54 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:22:54 --> Helper loaded: form_helper
INFO - 2016-05-03 20:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:22:54 --> Form Validation Class Initialized
INFO - 2016-05-03 20:22:54 --> Controller Class Initialized
INFO - 2016-05-03 20:22:54 --> Model Class Initialized
INFO - 2016-05-03 20:22:54 --> Database Driver Class Initialized
INFO - 2016-05-03 20:22:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:22:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:22:54 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:22:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:22:54 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 20:22:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 137
ERROR - 2016-05-03 20:22:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 138
ERROR - 2016-05-03 20:22:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 139
ERROR - 2016-05-03 20:22:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 140
ERROR - 2016-05-03 20:22:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 141
ERROR - 2016-05-03 20:22:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 142
ERROR - 2016-05-03 20:22:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 143
ERROR - 2016-05-03 20:22:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 144
INFO - 2016-05-03 20:22:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:22:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:22:54 --> Final output sent to browser
DEBUG - 2016-05-03 20:22:54 --> Total execution time: 0.1001
INFO - 2016-05-03 20:22:58 --> Config Class Initialized
INFO - 2016-05-03 20:22:58 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:22:58 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:22:58 --> Utf8 Class Initialized
INFO - 2016-05-03 20:22:58 --> URI Class Initialized
INFO - 2016-05-03 20:22:58 --> Router Class Initialized
INFO - 2016-05-03 20:22:58 --> Output Class Initialized
INFO - 2016-05-03 20:22:58 --> Security Class Initialized
DEBUG - 2016-05-03 20:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:22:58 --> Input Class Initialized
INFO - 2016-05-03 20:22:58 --> Language Class Initialized
INFO - 2016-05-03 20:22:58 --> Loader Class Initialized
INFO - 2016-05-03 20:22:58 --> Helper loaded: url_helper
INFO - 2016-05-03 20:22:58 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:22:58 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:22:58 --> Helper loaded: form_helper
INFO - 2016-05-03 20:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:22:58 --> Form Validation Class Initialized
INFO - 2016-05-03 20:22:58 --> Controller Class Initialized
INFO - 2016-05-03 20:22:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-03 20:22:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:22:58 --> Final output sent to browser
DEBUG - 2016-05-03 20:22:58 --> Total execution time: 0.0606
INFO - 2016-05-03 20:23:01 --> Config Class Initialized
INFO - 2016-05-03 20:23:01 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:23:01 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:23:01 --> Utf8 Class Initialized
INFO - 2016-05-03 20:23:01 --> URI Class Initialized
INFO - 2016-05-03 20:23:01 --> Router Class Initialized
INFO - 2016-05-03 20:23:01 --> Output Class Initialized
INFO - 2016-05-03 20:23:01 --> Security Class Initialized
DEBUG - 2016-05-03 20:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:23:01 --> Input Class Initialized
INFO - 2016-05-03 20:23:01 --> Language Class Initialized
INFO - 2016-05-03 20:23:01 --> Loader Class Initialized
INFO - 2016-05-03 20:23:01 --> Helper loaded: url_helper
INFO - 2016-05-03 20:23:01 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:23:01 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:23:01 --> Helper loaded: form_helper
INFO - 2016-05-03 20:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:23:01 --> Form Validation Class Initialized
INFO - 2016-05-03 20:23:01 --> Controller Class Initialized
INFO - 2016-05-03 20:23:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-03 20:23:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-03 20:23:01 --> Final output sent to browser
DEBUG - 2016-05-03 20:23:01 --> Total execution time: 0.0522
INFO - 2016-05-03 20:23:03 --> Config Class Initialized
INFO - 2016-05-03 20:23:03 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:23:03 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:23:03 --> Utf8 Class Initialized
INFO - 2016-05-03 20:23:03 --> URI Class Initialized
INFO - 2016-05-03 20:23:03 --> Router Class Initialized
INFO - 2016-05-03 20:23:03 --> Output Class Initialized
INFO - 2016-05-03 20:23:03 --> Security Class Initialized
DEBUG - 2016-05-03 20:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:23:03 --> Input Class Initialized
INFO - 2016-05-03 20:23:03 --> Language Class Initialized
INFO - 2016-05-03 20:23:03 --> Loader Class Initialized
INFO - 2016-05-03 20:23:03 --> Helper loaded: url_helper
INFO - 2016-05-03 20:23:03 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:23:03 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:23:03 --> Helper loaded: form_helper
INFO - 2016-05-03 20:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:23:03 --> Form Validation Class Initialized
INFO - 2016-05-03 20:23:03 --> Controller Class Initialized
INFO - 2016-05-03 20:23:03 --> Config Class Initialized
INFO - 2016-05-03 20:23:03 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:23:03 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:23:03 --> Utf8 Class Initialized
INFO - 2016-05-03 20:23:03 --> URI Class Initialized
INFO - 2016-05-03 20:23:03 --> Router Class Initialized
INFO - 2016-05-03 20:23:03 --> Output Class Initialized
INFO - 2016-05-03 20:23:03 --> Security Class Initialized
DEBUG - 2016-05-03 20:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:23:03 --> Input Class Initialized
INFO - 2016-05-03 20:23:03 --> Language Class Initialized
INFO - 2016-05-03 20:23:03 --> Loader Class Initialized
INFO - 2016-05-03 20:23:03 --> Helper loaded: url_helper
INFO - 2016-05-03 20:23:04 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:23:04 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:23:04 --> Helper loaded: form_helper
INFO - 2016-05-03 20:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:23:04 --> Form Validation Class Initialized
INFO - 2016-05-03 20:23:04 --> Controller Class Initialized
INFO - 2016-05-03 20:23:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-03 20:23:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:23:04 --> Final output sent to browser
DEBUG - 2016-05-03 20:23:04 --> Total execution time: 0.0771
INFO - 2016-05-03 20:23:06 --> Config Class Initialized
INFO - 2016-05-03 20:23:06 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:23:06 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:23:06 --> Utf8 Class Initialized
INFO - 2016-05-03 20:23:06 --> URI Class Initialized
INFO - 2016-05-03 20:23:06 --> Router Class Initialized
INFO - 2016-05-03 20:23:06 --> Output Class Initialized
INFO - 2016-05-03 20:23:06 --> Security Class Initialized
DEBUG - 2016-05-03 20:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:23:06 --> Input Class Initialized
INFO - 2016-05-03 20:23:06 --> Language Class Initialized
INFO - 2016-05-03 20:23:06 --> Loader Class Initialized
INFO - 2016-05-03 20:23:06 --> Helper loaded: url_helper
INFO - 2016-05-03 20:23:06 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:23:06 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:23:06 --> Helper loaded: form_helper
INFO - 2016-05-03 20:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:23:06 --> Form Validation Class Initialized
INFO - 2016-05-03 20:23:06 --> Controller Class Initialized
INFO - 2016-05-03 20:23:06 --> Model Class Initialized
INFO - 2016-05-03 20:23:06 --> Database Driver Class Initialized
INFO - 2016-05-03 20:23:06 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:23:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:23:06 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:23:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:23:06 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:23:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:23:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:23:06 --> Final output sent to browser
DEBUG - 2016-05-03 20:23:06 --> Total execution time: 0.0951
INFO - 2016-05-03 20:23:10 --> Config Class Initialized
INFO - 2016-05-03 20:23:10 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:23:10 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:23:10 --> Utf8 Class Initialized
INFO - 2016-05-03 20:23:10 --> URI Class Initialized
INFO - 2016-05-03 20:23:10 --> Router Class Initialized
INFO - 2016-05-03 20:23:10 --> Output Class Initialized
INFO - 2016-05-03 20:23:10 --> Security Class Initialized
DEBUG - 2016-05-03 20:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:23:10 --> Input Class Initialized
INFO - 2016-05-03 20:23:10 --> Language Class Initialized
INFO - 2016-05-03 20:23:10 --> Loader Class Initialized
INFO - 2016-05-03 20:23:10 --> Helper loaded: url_helper
INFO - 2016-05-03 20:23:10 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:23:10 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:23:10 --> Helper loaded: form_helper
INFO - 2016-05-03 20:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:23:10 --> Form Validation Class Initialized
INFO - 2016-05-03 20:23:10 --> Controller Class Initialized
INFO - 2016-05-03 20:23:10 --> Model Class Initialized
INFO - 2016-05-03 20:23:10 --> Database Driver Class Initialized
INFO - 2016-05-03 20:23:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:23:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:23:10 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:23:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:23:10 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 20:23:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 137
ERROR - 2016-05-03 20:23:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 138
ERROR - 2016-05-03 20:23:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 139
ERROR - 2016-05-03 20:23:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 140
ERROR - 2016-05-03 20:23:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 141
ERROR - 2016-05-03 20:23:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 142
ERROR - 2016-05-03 20:23:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 143
ERROR - 2016-05-03 20:23:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 144
INFO - 2016-05-03 20:23:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:23:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:23:10 --> Final output sent to browser
DEBUG - 2016-05-03 20:23:10 --> Total execution time: 0.1413
INFO - 2016-05-03 20:23:30 --> Config Class Initialized
INFO - 2016-05-03 20:23:30 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:23:30 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:23:30 --> Utf8 Class Initialized
INFO - 2016-05-03 20:23:30 --> URI Class Initialized
INFO - 2016-05-03 20:23:30 --> Router Class Initialized
INFO - 2016-05-03 20:23:30 --> Output Class Initialized
INFO - 2016-05-03 20:23:30 --> Security Class Initialized
DEBUG - 2016-05-03 20:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:23:30 --> Input Class Initialized
INFO - 2016-05-03 20:23:30 --> Language Class Initialized
INFO - 2016-05-03 20:23:30 --> Loader Class Initialized
INFO - 2016-05-03 20:23:30 --> Helper loaded: url_helper
INFO - 2016-05-03 20:23:30 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:23:30 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:23:30 --> Helper loaded: form_helper
INFO - 2016-05-03 20:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:23:30 --> Form Validation Class Initialized
INFO - 2016-05-03 20:23:30 --> Controller Class Initialized
INFO - 2016-05-03 20:23:30 --> Model Class Initialized
INFO - 2016-05-03 20:23:30 --> Database Driver Class Initialized
INFO - 2016-05-03 20:23:30 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:23:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:23:30 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:23:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:23:30 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:23:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:23:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:23:30 --> Final output sent to browser
DEBUG - 2016-05-03 20:23:30 --> Total execution time: 0.0909
INFO - 2016-05-03 20:23:36 --> Config Class Initialized
INFO - 2016-05-03 20:23:36 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:23:36 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:23:36 --> Utf8 Class Initialized
INFO - 2016-05-03 20:23:36 --> URI Class Initialized
INFO - 2016-05-03 20:23:36 --> Router Class Initialized
INFO - 2016-05-03 20:23:36 --> Output Class Initialized
INFO - 2016-05-03 20:23:36 --> Security Class Initialized
DEBUG - 2016-05-03 20:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:23:36 --> Input Class Initialized
INFO - 2016-05-03 20:23:36 --> Language Class Initialized
INFO - 2016-05-03 20:23:36 --> Loader Class Initialized
INFO - 2016-05-03 20:23:36 --> Helper loaded: url_helper
INFO - 2016-05-03 20:23:36 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:23:36 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:23:36 --> Helper loaded: form_helper
INFO - 2016-05-03 20:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:23:36 --> Form Validation Class Initialized
INFO - 2016-05-03 20:23:36 --> Controller Class Initialized
INFO - 2016-05-03 20:23:36 --> Model Class Initialized
INFO - 2016-05-03 20:23:36 --> Database Driver Class Initialized
INFO - 2016-05-03 20:23:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:23:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:23:36 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:23:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:23:36 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:23:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:23:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:23:36 --> Final output sent to browser
DEBUG - 2016-05-03 20:23:36 --> Total execution time: 0.1228
INFO - 2016-05-03 20:23:40 --> Config Class Initialized
INFO - 2016-05-03 20:23:40 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:23:40 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:23:40 --> Utf8 Class Initialized
INFO - 2016-05-03 20:23:40 --> URI Class Initialized
INFO - 2016-05-03 20:23:40 --> Router Class Initialized
INFO - 2016-05-03 20:23:40 --> Output Class Initialized
INFO - 2016-05-03 20:23:40 --> Security Class Initialized
DEBUG - 2016-05-03 20:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:23:40 --> Input Class Initialized
INFO - 2016-05-03 20:23:40 --> Language Class Initialized
INFO - 2016-05-03 20:23:40 --> Loader Class Initialized
INFO - 2016-05-03 20:23:40 --> Helper loaded: url_helper
INFO - 2016-05-03 20:23:40 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:23:40 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:23:40 --> Helper loaded: form_helper
INFO - 2016-05-03 20:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:23:40 --> Form Validation Class Initialized
INFO - 2016-05-03 20:23:40 --> Controller Class Initialized
INFO - 2016-05-03 20:23:40 --> Model Class Initialized
INFO - 2016-05-03 20:23:40 --> Database Driver Class Initialized
INFO - 2016-05-03 20:23:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:23:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:23:40 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:23:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:23:40 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:23:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:23:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:23:40 --> Final output sent to browser
DEBUG - 2016-05-03 20:23:40 --> Total execution time: 0.1208
INFO - 2016-05-03 20:25:25 --> Config Class Initialized
INFO - 2016-05-03 20:25:25 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:25:25 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:25:25 --> Utf8 Class Initialized
INFO - 2016-05-03 20:25:25 --> URI Class Initialized
INFO - 2016-05-03 20:25:25 --> Router Class Initialized
INFO - 2016-05-03 20:25:25 --> Output Class Initialized
INFO - 2016-05-03 20:25:25 --> Security Class Initialized
DEBUG - 2016-05-03 20:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:25:25 --> Input Class Initialized
INFO - 2016-05-03 20:25:25 --> Language Class Initialized
INFO - 2016-05-03 20:25:25 --> Loader Class Initialized
INFO - 2016-05-03 20:25:25 --> Helper loaded: url_helper
INFO - 2016-05-03 20:25:25 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:25:25 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:25:25 --> Helper loaded: form_helper
INFO - 2016-05-03 20:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:25:25 --> Form Validation Class Initialized
INFO - 2016-05-03 20:25:25 --> Controller Class Initialized
INFO - 2016-05-03 20:25:25 --> Model Class Initialized
INFO - 2016-05-03 20:25:25 --> Database Driver Class Initialized
INFO - 2016-05-03 20:25:25 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:25:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:25:25 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:25:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:25:25 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:25:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:25:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:25:25 --> Final output sent to browser
DEBUG - 2016-05-03 20:25:25 --> Total execution time: 0.0852
INFO - 2016-05-03 20:25:28 --> Config Class Initialized
INFO - 2016-05-03 20:25:28 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:25:28 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:25:28 --> Utf8 Class Initialized
INFO - 2016-05-03 20:25:28 --> URI Class Initialized
INFO - 2016-05-03 20:25:28 --> Router Class Initialized
INFO - 2016-05-03 20:25:28 --> Output Class Initialized
INFO - 2016-05-03 20:25:28 --> Security Class Initialized
DEBUG - 2016-05-03 20:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:25:28 --> Input Class Initialized
INFO - 2016-05-03 20:25:28 --> Language Class Initialized
INFO - 2016-05-03 20:25:28 --> Loader Class Initialized
INFO - 2016-05-03 20:25:28 --> Helper loaded: url_helper
INFO - 2016-05-03 20:25:28 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:25:28 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:25:28 --> Helper loaded: form_helper
INFO - 2016-05-03 20:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:25:28 --> Form Validation Class Initialized
INFO - 2016-05-03 20:25:28 --> Controller Class Initialized
INFO - 2016-05-03 20:25:28 --> Model Class Initialized
INFO - 2016-05-03 20:25:28 --> Database Driver Class Initialized
INFO - 2016-05-03 20:25:28 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:25:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:25:28 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:25:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:25:28 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:25:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:25:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:25:28 --> Final output sent to browser
DEBUG - 2016-05-03 20:25:28 --> Total execution time: 0.0784
INFO - 2016-05-03 20:26:00 --> Config Class Initialized
INFO - 2016-05-03 20:26:00 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:26:00 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:26:00 --> Utf8 Class Initialized
INFO - 2016-05-03 20:26:00 --> URI Class Initialized
INFO - 2016-05-03 20:26:00 --> Router Class Initialized
INFO - 2016-05-03 20:26:00 --> Output Class Initialized
INFO - 2016-05-03 20:26:00 --> Security Class Initialized
DEBUG - 2016-05-03 20:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:26:00 --> Input Class Initialized
INFO - 2016-05-03 20:26:00 --> Language Class Initialized
INFO - 2016-05-03 20:26:00 --> Loader Class Initialized
INFO - 2016-05-03 20:26:00 --> Helper loaded: url_helper
INFO - 2016-05-03 20:26:00 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:26:00 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:26:00 --> Helper loaded: form_helper
INFO - 2016-05-03 20:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:26:00 --> Form Validation Class Initialized
INFO - 2016-05-03 20:26:00 --> Controller Class Initialized
INFO - 2016-05-03 20:26:00 --> Model Class Initialized
INFO - 2016-05-03 20:26:00 --> Database Driver Class Initialized
INFO - 2016-05-03 20:26:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:26:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:26:00 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:26:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:26:00 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:26:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:26:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:26:00 --> Final output sent to browser
DEBUG - 2016-05-03 20:26:00 --> Total execution time: 0.1333
INFO - 2016-05-03 20:26:15 --> Config Class Initialized
INFO - 2016-05-03 20:26:15 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:26:15 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:26:15 --> Utf8 Class Initialized
INFO - 2016-05-03 20:26:15 --> URI Class Initialized
INFO - 2016-05-03 20:26:15 --> Router Class Initialized
INFO - 2016-05-03 20:26:15 --> Output Class Initialized
INFO - 2016-05-03 20:26:15 --> Security Class Initialized
DEBUG - 2016-05-03 20:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:26:15 --> Input Class Initialized
INFO - 2016-05-03 20:26:15 --> Language Class Initialized
INFO - 2016-05-03 20:26:15 --> Loader Class Initialized
INFO - 2016-05-03 20:26:15 --> Helper loaded: url_helper
INFO - 2016-05-03 20:26:15 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:26:15 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:26:15 --> Helper loaded: form_helper
INFO - 2016-05-03 20:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:26:15 --> Form Validation Class Initialized
INFO - 2016-05-03 20:26:15 --> Controller Class Initialized
INFO - 2016-05-03 20:26:15 --> Model Class Initialized
INFO - 2016-05-03 20:26:15 --> Database Driver Class Initialized
INFO - 2016-05-03 20:26:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:26:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:26:15 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:26:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:26:15 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:26:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:26:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:26:15 --> Final output sent to browser
DEBUG - 2016-05-03 20:26:15 --> Total execution time: 0.1124
INFO - 2016-05-03 20:27:09 --> Config Class Initialized
INFO - 2016-05-03 20:27:09 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:27:09 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:27:09 --> Utf8 Class Initialized
INFO - 2016-05-03 20:27:09 --> URI Class Initialized
INFO - 2016-05-03 20:27:09 --> Router Class Initialized
INFO - 2016-05-03 20:27:09 --> Output Class Initialized
INFO - 2016-05-03 20:27:09 --> Security Class Initialized
DEBUG - 2016-05-03 20:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:27:09 --> Input Class Initialized
INFO - 2016-05-03 20:27:09 --> Language Class Initialized
INFO - 2016-05-03 20:27:09 --> Loader Class Initialized
INFO - 2016-05-03 20:27:09 --> Helper loaded: url_helper
INFO - 2016-05-03 20:27:09 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:27:09 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:27:09 --> Helper loaded: form_helper
INFO - 2016-05-03 20:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:27:09 --> Form Validation Class Initialized
INFO - 2016-05-03 20:27:09 --> Controller Class Initialized
INFO - 2016-05-03 20:27:09 --> Model Class Initialized
INFO - 2016-05-03 20:27:09 --> Database Driver Class Initialized
INFO - 2016-05-03 20:27:09 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:27:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:27:09 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:27:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:27:09 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:27:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:27:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:27:09 --> Final output sent to browser
DEBUG - 2016-05-03 20:27:09 --> Total execution time: 0.1034
INFO - 2016-05-03 20:32:02 --> Config Class Initialized
INFO - 2016-05-03 20:32:02 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:32:02 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:32:02 --> Utf8 Class Initialized
INFO - 2016-05-03 20:32:02 --> URI Class Initialized
INFO - 2016-05-03 20:32:02 --> Router Class Initialized
INFO - 2016-05-03 20:32:02 --> Output Class Initialized
INFO - 2016-05-03 20:32:02 --> Security Class Initialized
DEBUG - 2016-05-03 20:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:32:02 --> Input Class Initialized
INFO - 2016-05-03 20:32:02 --> Language Class Initialized
INFO - 2016-05-03 20:32:02 --> Loader Class Initialized
INFO - 2016-05-03 20:32:02 --> Helper loaded: url_helper
INFO - 2016-05-03 20:32:02 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:32:02 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:32:02 --> Helper loaded: form_helper
INFO - 2016-05-03 20:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:32:02 --> Form Validation Class Initialized
INFO - 2016-05-03 20:32:02 --> Controller Class Initialized
INFO - 2016-05-03 20:32:02 --> Model Class Initialized
INFO - 2016-05-03 20:32:02 --> Database Driver Class Initialized
INFO - 2016-05-03 20:32:02 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:32:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:32:02 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:32:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:32:02 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:32:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:32:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:32:02 --> Final output sent to browser
DEBUG - 2016-05-03 20:32:02 --> Total execution time: 0.0990
INFO - 2016-05-03 20:32:19 --> Config Class Initialized
INFO - 2016-05-03 20:32:19 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:32:19 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:32:19 --> Utf8 Class Initialized
INFO - 2016-05-03 20:32:19 --> URI Class Initialized
INFO - 2016-05-03 20:32:19 --> Router Class Initialized
INFO - 2016-05-03 20:32:19 --> Output Class Initialized
INFO - 2016-05-03 20:32:19 --> Security Class Initialized
DEBUG - 2016-05-03 20:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:32:19 --> Input Class Initialized
INFO - 2016-05-03 20:32:19 --> Language Class Initialized
INFO - 2016-05-03 20:32:19 --> Loader Class Initialized
INFO - 2016-05-03 20:32:19 --> Helper loaded: url_helper
INFO - 2016-05-03 20:32:19 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:32:19 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:32:19 --> Helper loaded: form_helper
INFO - 2016-05-03 20:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:32:19 --> Form Validation Class Initialized
INFO - 2016-05-03 20:32:19 --> Controller Class Initialized
INFO - 2016-05-03 20:32:19 --> Model Class Initialized
INFO - 2016-05-03 20:32:19 --> Database Driver Class Initialized
INFO - 2016-05-03 20:32:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:32:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:32:19 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:32:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:32:19 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:32:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:32:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:32:19 --> Final output sent to browser
DEBUG - 2016-05-03 20:32:19 --> Total execution time: 0.0842
INFO - 2016-05-03 20:32:55 --> Config Class Initialized
INFO - 2016-05-03 20:32:55 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:32:55 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:32:55 --> Utf8 Class Initialized
INFO - 2016-05-03 20:32:55 --> URI Class Initialized
INFO - 2016-05-03 20:32:55 --> Router Class Initialized
INFO - 2016-05-03 20:32:55 --> Output Class Initialized
INFO - 2016-05-03 20:32:55 --> Security Class Initialized
DEBUG - 2016-05-03 20:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:32:55 --> Input Class Initialized
INFO - 2016-05-03 20:32:55 --> Language Class Initialized
INFO - 2016-05-03 20:32:55 --> Loader Class Initialized
INFO - 2016-05-03 20:32:55 --> Helper loaded: url_helper
INFO - 2016-05-03 20:32:55 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:32:55 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:32:55 --> Helper loaded: form_helper
INFO - 2016-05-03 20:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:32:55 --> Form Validation Class Initialized
INFO - 2016-05-03 20:32:55 --> Controller Class Initialized
INFO - 2016-05-03 20:32:55 --> Model Class Initialized
INFO - 2016-05-03 20:32:55 --> Database Driver Class Initialized
INFO - 2016-05-03 20:32:55 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:32:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:32:55 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:32:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:32:55 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 20:32:55 --> Severity: Warning --> Missing argument 3 for Proveedores::index() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Proveedores.php 20
INFO - 2016-05-03 20:32:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:32:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:32:55 --> Final output sent to browser
DEBUG - 2016-05-03 20:32:55 --> Total execution time: 0.1205
INFO - 2016-05-03 20:33:00 --> Config Class Initialized
INFO - 2016-05-03 20:33:00 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:33:00 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:33:00 --> Utf8 Class Initialized
INFO - 2016-05-03 20:33:00 --> URI Class Initialized
INFO - 2016-05-03 20:33:00 --> Router Class Initialized
INFO - 2016-05-03 20:33:00 --> Output Class Initialized
INFO - 2016-05-03 20:33:00 --> Security Class Initialized
DEBUG - 2016-05-03 20:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:33:00 --> Input Class Initialized
INFO - 2016-05-03 20:33:00 --> Language Class Initialized
INFO - 2016-05-03 20:33:00 --> Loader Class Initialized
INFO - 2016-05-03 20:33:00 --> Helper loaded: url_helper
INFO - 2016-05-03 20:33:00 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:33:00 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:33:00 --> Helper loaded: form_helper
INFO - 2016-05-03 20:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:33:00 --> Form Validation Class Initialized
INFO - 2016-05-03 20:33:00 --> Controller Class Initialized
INFO - 2016-05-03 20:33:00 --> Model Class Initialized
INFO - 2016-05-03 20:33:00 --> Database Driver Class Initialized
INFO - 2016-05-03 20:33:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:33:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:33:00 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:33:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:33:00 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:33:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:33:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:33:00 --> Final output sent to browser
DEBUG - 2016-05-03 20:33:00 --> Total execution time: 0.0965
INFO - 2016-05-03 20:35:53 --> Config Class Initialized
INFO - 2016-05-03 20:35:53 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:35:53 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:35:53 --> Utf8 Class Initialized
INFO - 2016-05-03 20:35:53 --> URI Class Initialized
INFO - 2016-05-03 20:35:53 --> Router Class Initialized
INFO - 2016-05-03 20:35:53 --> Output Class Initialized
INFO - 2016-05-03 20:35:53 --> Security Class Initialized
DEBUG - 2016-05-03 20:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:35:53 --> Input Class Initialized
INFO - 2016-05-03 20:35:53 --> Language Class Initialized
INFO - 2016-05-03 20:35:53 --> Loader Class Initialized
INFO - 2016-05-03 20:35:53 --> Helper loaded: url_helper
INFO - 2016-05-03 20:35:53 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:35:53 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:35:53 --> Helper loaded: form_helper
INFO - 2016-05-03 20:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:35:53 --> Form Validation Class Initialized
INFO - 2016-05-03 20:35:53 --> Controller Class Initialized
INFO - 2016-05-03 20:35:53 --> Model Class Initialized
INFO - 2016-05-03 20:35:53 --> Database Driver Class Initialized
INFO - 2016-05-03 20:35:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:35:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:35:53 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:35:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:35:53 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:35:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:35:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:35:53 --> Final output sent to browser
DEBUG - 2016-05-03 20:35:53 --> Total execution time: 0.0867
INFO - 2016-05-03 20:35:59 --> Config Class Initialized
INFO - 2016-05-03 20:35:59 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:35:59 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:35:59 --> Utf8 Class Initialized
INFO - 2016-05-03 20:35:59 --> URI Class Initialized
INFO - 2016-05-03 20:35:59 --> Router Class Initialized
INFO - 2016-05-03 20:35:59 --> Output Class Initialized
INFO - 2016-05-03 20:35:59 --> Security Class Initialized
DEBUG - 2016-05-03 20:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:35:59 --> Input Class Initialized
INFO - 2016-05-03 20:35:59 --> Language Class Initialized
INFO - 2016-05-03 20:35:59 --> Loader Class Initialized
INFO - 2016-05-03 20:35:59 --> Helper loaded: url_helper
INFO - 2016-05-03 20:35:59 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:35:59 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:35:59 --> Helper loaded: form_helper
INFO - 2016-05-03 20:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:35:59 --> Form Validation Class Initialized
INFO - 2016-05-03 20:35:59 --> Controller Class Initialized
INFO - 2016-05-03 20:35:59 --> Model Class Initialized
INFO - 2016-05-03 20:35:59 --> Database Driver Class Initialized
INFO - 2016-05-03 20:35:59 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:35:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:35:59 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:35:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:35:59 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:35:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:35:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:35:59 --> Final output sent to browser
DEBUG - 2016-05-03 20:35:59 --> Total execution time: 0.0819
INFO - 2016-05-03 20:36:03 --> Config Class Initialized
INFO - 2016-05-03 20:36:03 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:36:03 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:36:03 --> Utf8 Class Initialized
INFO - 2016-05-03 20:36:03 --> URI Class Initialized
INFO - 2016-05-03 20:36:03 --> Router Class Initialized
INFO - 2016-05-03 20:36:03 --> Output Class Initialized
INFO - 2016-05-03 20:36:03 --> Security Class Initialized
DEBUG - 2016-05-03 20:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:36:03 --> Input Class Initialized
INFO - 2016-05-03 20:36:03 --> Language Class Initialized
INFO - 2016-05-03 20:36:03 --> Loader Class Initialized
INFO - 2016-05-03 20:36:03 --> Helper loaded: url_helper
INFO - 2016-05-03 20:36:03 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:36:03 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:36:03 --> Helper loaded: form_helper
INFO - 2016-05-03 20:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:36:03 --> Form Validation Class Initialized
INFO - 2016-05-03 20:36:03 --> Controller Class Initialized
INFO - 2016-05-03 20:36:03 --> Model Class Initialized
INFO - 2016-05-03 20:36:03 --> Database Driver Class Initialized
INFO - 2016-05-03 20:36:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:36:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:36:03 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:36:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:36:03 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 20:36:03 --> Severity: Warning --> Missing argument 3 for Proveedores::index() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Proveedores.php 20
ERROR - 2016-05-03 20:36:03 --> Severity: Notice --> Undefined variable: proveedores C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Proveedores.php 36
ERROR - 2016-05-03 20:36:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 31
INFO - 2016-05-03 20:36:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:36:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:36:03 --> Final output sent to browser
DEBUG - 2016-05-03 20:36:03 --> Total execution time: 0.1200
INFO - 2016-05-03 20:36:19 --> Config Class Initialized
INFO - 2016-05-03 20:36:19 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:36:19 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:36:19 --> Utf8 Class Initialized
INFO - 2016-05-03 20:36:19 --> URI Class Initialized
INFO - 2016-05-03 20:36:19 --> Router Class Initialized
INFO - 2016-05-03 20:36:19 --> Output Class Initialized
INFO - 2016-05-03 20:36:19 --> Security Class Initialized
DEBUG - 2016-05-03 20:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:36:19 --> Input Class Initialized
INFO - 2016-05-03 20:36:19 --> Language Class Initialized
INFO - 2016-05-03 20:36:19 --> Loader Class Initialized
INFO - 2016-05-03 20:36:19 --> Helper loaded: url_helper
INFO - 2016-05-03 20:36:19 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:36:19 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:36:19 --> Helper loaded: form_helper
INFO - 2016-05-03 20:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:36:19 --> Form Validation Class Initialized
INFO - 2016-05-03 20:36:19 --> Controller Class Initialized
INFO - 2016-05-03 20:36:19 --> Model Class Initialized
INFO - 2016-05-03 20:36:19 --> Database Driver Class Initialized
INFO - 2016-05-03 20:36:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:36:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:36:19 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:36:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:36:19 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:36:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:36:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:36:19 --> Final output sent to browser
DEBUG - 2016-05-03 20:36:19 --> Total execution time: 0.0815
INFO - 2016-05-03 20:36:21 --> Config Class Initialized
INFO - 2016-05-03 20:36:21 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:36:21 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:36:21 --> Utf8 Class Initialized
INFO - 2016-05-03 20:36:21 --> URI Class Initialized
INFO - 2016-05-03 20:36:21 --> Router Class Initialized
INFO - 2016-05-03 20:36:21 --> Output Class Initialized
INFO - 2016-05-03 20:36:21 --> Security Class Initialized
DEBUG - 2016-05-03 20:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:36:21 --> Input Class Initialized
INFO - 2016-05-03 20:36:21 --> Language Class Initialized
INFO - 2016-05-03 20:36:21 --> Loader Class Initialized
INFO - 2016-05-03 20:36:21 --> Helper loaded: url_helper
INFO - 2016-05-03 20:36:21 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:36:21 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:36:21 --> Helper loaded: form_helper
INFO - 2016-05-03 20:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:36:21 --> Form Validation Class Initialized
INFO - 2016-05-03 20:36:21 --> Controller Class Initialized
INFO - 2016-05-03 20:36:21 --> Model Class Initialized
INFO - 2016-05-03 20:36:21 --> Database Driver Class Initialized
INFO - 2016-05-03 20:36:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:36:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:36:21 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:36:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:36:21 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:36:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:36:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:36:21 --> Final output sent to browser
DEBUG - 2016-05-03 20:36:21 --> Total execution time: 0.1043
INFO - 2016-05-03 20:36:25 --> Config Class Initialized
INFO - 2016-05-03 20:36:25 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:36:25 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:36:25 --> Utf8 Class Initialized
INFO - 2016-05-03 20:36:25 --> URI Class Initialized
INFO - 2016-05-03 20:36:25 --> Router Class Initialized
INFO - 2016-05-03 20:36:25 --> Output Class Initialized
INFO - 2016-05-03 20:36:25 --> Security Class Initialized
DEBUG - 2016-05-03 20:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:36:25 --> Input Class Initialized
INFO - 2016-05-03 20:36:25 --> Language Class Initialized
INFO - 2016-05-03 20:36:25 --> Loader Class Initialized
INFO - 2016-05-03 20:36:25 --> Helper loaded: url_helper
INFO - 2016-05-03 20:36:25 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:36:25 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:36:25 --> Helper loaded: form_helper
INFO - 2016-05-03 20:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:36:25 --> Form Validation Class Initialized
INFO - 2016-05-03 20:36:25 --> Controller Class Initialized
INFO - 2016-05-03 20:36:25 --> Model Class Initialized
INFO - 2016-05-03 20:36:25 --> Database Driver Class Initialized
INFO - 2016-05-03 20:36:25 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:36:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:36:25 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:36:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:36:25 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:36:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:36:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:36:25 --> Final output sent to browser
DEBUG - 2016-05-03 20:36:25 --> Total execution time: 0.1213
INFO - 2016-05-03 20:36:39 --> Config Class Initialized
INFO - 2016-05-03 20:36:39 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:36:39 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:36:39 --> Utf8 Class Initialized
INFO - 2016-05-03 20:36:39 --> URI Class Initialized
INFO - 2016-05-03 20:36:39 --> Router Class Initialized
INFO - 2016-05-03 20:36:39 --> Output Class Initialized
INFO - 2016-05-03 20:36:39 --> Security Class Initialized
DEBUG - 2016-05-03 20:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:36:39 --> Input Class Initialized
INFO - 2016-05-03 20:36:39 --> Language Class Initialized
INFO - 2016-05-03 20:36:39 --> Loader Class Initialized
INFO - 2016-05-03 20:36:39 --> Helper loaded: url_helper
INFO - 2016-05-03 20:36:39 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:36:39 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:36:39 --> Helper loaded: form_helper
INFO - 2016-05-03 20:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:36:39 --> Form Validation Class Initialized
INFO - 2016-05-03 20:36:39 --> Controller Class Initialized
INFO - 2016-05-03 20:36:39 --> Model Class Initialized
INFO - 2016-05-03 20:36:39 --> Database Driver Class Initialized
INFO - 2016-05-03 20:36:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:36:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:36:39 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:36:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:36:39 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:36:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:36:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:36:39 --> Final output sent to browser
DEBUG - 2016-05-03 20:36:39 --> Total execution time: 0.0889
INFO - 2016-05-03 20:40:03 --> Config Class Initialized
INFO - 2016-05-03 20:40:03 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:40:03 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:40:03 --> Utf8 Class Initialized
INFO - 2016-05-03 20:40:03 --> URI Class Initialized
INFO - 2016-05-03 20:40:03 --> Router Class Initialized
INFO - 2016-05-03 20:40:03 --> Output Class Initialized
INFO - 2016-05-03 20:40:03 --> Security Class Initialized
DEBUG - 2016-05-03 20:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:40:03 --> Input Class Initialized
INFO - 2016-05-03 20:40:03 --> Language Class Initialized
INFO - 2016-05-03 20:40:03 --> Loader Class Initialized
INFO - 2016-05-03 20:40:03 --> Helper loaded: url_helper
INFO - 2016-05-03 20:40:03 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:40:03 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:40:03 --> Helper loaded: form_helper
INFO - 2016-05-03 20:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:40:03 --> Form Validation Class Initialized
INFO - 2016-05-03 20:40:03 --> Controller Class Initialized
INFO - 2016-05-03 20:40:03 --> Model Class Initialized
INFO - 2016-05-03 20:40:03 --> Database Driver Class Initialized
INFO - 2016-05-03 20:40:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:40:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:40:03 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:40:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:40:03 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:40:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:40:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:40:03 --> Final output sent to browser
DEBUG - 2016-05-03 20:40:03 --> Total execution time: 0.1376
INFO - 2016-05-03 20:41:01 --> Config Class Initialized
INFO - 2016-05-03 20:41:01 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:41:01 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:41:01 --> Utf8 Class Initialized
INFO - 2016-05-03 20:41:01 --> URI Class Initialized
INFO - 2016-05-03 20:41:01 --> Router Class Initialized
INFO - 2016-05-03 20:41:01 --> Output Class Initialized
INFO - 2016-05-03 20:41:01 --> Security Class Initialized
DEBUG - 2016-05-03 20:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:41:01 --> Input Class Initialized
INFO - 2016-05-03 20:41:01 --> Language Class Initialized
INFO - 2016-05-03 20:41:01 --> Loader Class Initialized
INFO - 2016-05-03 20:41:01 --> Helper loaded: url_helper
INFO - 2016-05-03 20:41:01 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:41:01 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:41:01 --> Helper loaded: form_helper
INFO - 2016-05-03 20:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:41:01 --> Form Validation Class Initialized
INFO - 2016-05-03 20:41:01 --> Controller Class Initialized
INFO - 2016-05-03 20:41:01 --> Model Class Initialized
INFO - 2016-05-03 20:41:01 --> Database Driver Class Initialized
INFO - 2016-05-03 20:41:01 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:41:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:41:01 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:41:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:41:01 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:41:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:41:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:41:01 --> Final output sent to browser
DEBUG - 2016-05-03 20:41:01 --> Total execution time: 0.1264
INFO - 2016-05-03 20:41:07 --> Config Class Initialized
INFO - 2016-05-03 20:41:07 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:41:07 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:41:07 --> Utf8 Class Initialized
INFO - 2016-05-03 20:41:07 --> URI Class Initialized
INFO - 2016-05-03 20:41:07 --> Router Class Initialized
INFO - 2016-05-03 20:41:07 --> Output Class Initialized
INFO - 2016-05-03 20:41:07 --> Security Class Initialized
DEBUG - 2016-05-03 20:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:41:07 --> Input Class Initialized
INFO - 2016-05-03 20:41:07 --> Language Class Initialized
INFO - 2016-05-03 20:41:07 --> Loader Class Initialized
INFO - 2016-05-03 20:41:07 --> Helper loaded: url_helper
INFO - 2016-05-03 20:41:07 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:41:07 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:41:07 --> Helper loaded: form_helper
INFO - 2016-05-03 20:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:41:07 --> Form Validation Class Initialized
INFO - 2016-05-03 20:41:07 --> Controller Class Initialized
INFO - 2016-05-03 20:41:07 --> Model Class Initialized
INFO - 2016-05-03 20:41:07 --> Database Driver Class Initialized
INFO - 2016-05-03 20:41:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:41:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:41:07 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:41:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:41:07 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:41:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:41:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:41:07 --> Final output sent to browser
DEBUG - 2016-05-03 20:41:07 --> Total execution time: 0.0877
INFO - 2016-05-03 20:41:12 --> Config Class Initialized
INFO - 2016-05-03 20:41:12 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:41:12 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:41:12 --> Utf8 Class Initialized
INFO - 2016-05-03 20:41:12 --> URI Class Initialized
INFO - 2016-05-03 20:41:12 --> Router Class Initialized
INFO - 2016-05-03 20:41:12 --> Output Class Initialized
INFO - 2016-05-03 20:41:12 --> Security Class Initialized
DEBUG - 2016-05-03 20:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:41:12 --> Input Class Initialized
INFO - 2016-05-03 20:41:12 --> Language Class Initialized
INFO - 2016-05-03 20:41:12 --> Loader Class Initialized
INFO - 2016-05-03 20:41:12 --> Helper loaded: url_helper
INFO - 2016-05-03 20:41:12 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:41:12 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:41:12 --> Helper loaded: form_helper
INFO - 2016-05-03 20:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:41:12 --> Form Validation Class Initialized
INFO - 2016-05-03 20:41:12 --> Controller Class Initialized
INFO - 2016-05-03 20:41:12 --> Model Class Initialized
INFO - 2016-05-03 20:41:12 --> Database Driver Class Initialized
INFO - 2016-05-03 20:41:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:41:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:41:12 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:41:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:41:12 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:41:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:41:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:41:12 --> Final output sent to browser
DEBUG - 2016-05-03 20:41:12 --> Total execution time: 0.0774
INFO - 2016-05-03 20:41:35 --> Config Class Initialized
INFO - 2016-05-03 20:41:35 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:41:35 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:41:35 --> Utf8 Class Initialized
INFO - 2016-05-03 20:41:35 --> URI Class Initialized
INFO - 2016-05-03 20:41:35 --> Router Class Initialized
INFO - 2016-05-03 20:41:35 --> Output Class Initialized
INFO - 2016-05-03 20:41:35 --> Security Class Initialized
DEBUG - 2016-05-03 20:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:41:35 --> Input Class Initialized
INFO - 2016-05-03 20:41:35 --> Language Class Initialized
INFO - 2016-05-03 20:41:35 --> Loader Class Initialized
INFO - 2016-05-03 20:41:35 --> Helper loaded: url_helper
INFO - 2016-05-03 20:41:35 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:41:35 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:41:35 --> Helper loaded: form_helper
INFO - 2016-05-03 20:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:41:35 --> Form Validation Class Initialized
INFO - 2016-05-03 20:41:35 --> Controller Class Initialized
INFO - 2016-05-03 20:41:35 --> Model Class Initialized
INFO - 2016-05-03 20:41:35 --> Database Driver Class Initialized
INFO - 2016-05-03 20:41:35 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:41:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:41:35 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:41:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:41:35 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:41:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:41:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:41:35 --> Final output sent to browser
DEBUG - 2016-05-03 20:41:35 --> Total execution time: 0.0808
INFO - 2016-05-03 20:41:40 --> Config Class Initialized
INFO - 2016-05-03 20:41:40 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:41:40 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:41:40 --> Utf8 Class Initialized
INFO - 2016-05-03 20:41:40 --> URI Class Initialized
INFO - 2016-05-03 20:41:40 --> Router Class Initialized
INFO - 2016-05-03 20:41:40 --> Output Class Initialized
INFO - 2016-05-03 20:41:40 --> Security Class Initialized
DEBUG - 2016-05-03 20:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:41:40 --> Input Class Initialized
INFO - 2016-05-03 20:41:40 --> Language Class Initialized
INFO - 2016-05-03 20:41:40 --> Loader Class Initialized
INFO - 2016-05-03 20:41:40 --> Helper loaded: url_helper
INFO - 2016-05-03 20:41:40 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:41:40 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:41:40 --> Helper loaded: form_helper
INFO - 2016-05-03 20:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:41:40 --> Form Validation Class Initialized
INFO - 2016-05-03 20:41:40 --> Controller Class Initialized
INFO - 2016-05-03 20:41:40 --> Model Class Initialized
INFO - 2016-05-03 20:41:40 --> Database Driver Class Initialized
INFO - 2016-05-03 20:41:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:41:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:41:40 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:41:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:41:40 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:41:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:41:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:41:40 --> Final output sent to browser
DEBUG - 2016-05-03 20:41:40 --> Total execution time: 0.1437
INFO - 2016-05-03 20:41:49 --> Config Class Initialized
INFO - 2016-05-03 20:41:49 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:41:49 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:41:49 --> Utf8 Class Initialized
INFO - 2016-05-03 20:41:49 --> URI Class Initialized
INFO - 2016-05-03 20:41:49 --> Router Class Initialized
INFO - 2016-05-03 20:41:49 --> Output Class Initialized
INFO - 2016-05-03 20:41:49 --> Security Class Initialized
DEBUG - 2016-05-03 20:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:41:49 --> Input Class Initialized
INFO - 2016-05-03 20:41:49 --> Language Class Initialized
INFO - 2016-05-03 20:41:49 --> Loader Class Initialized
INFO - 2016-05-03 20:41:49 --> Helper loaded: url_helper
INFO - 2016-05-03 20:41:49 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:41:49 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:41:49 --> Helper loaded: form_helper
INFO - 2016-05-03 20:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:41:49 --> Form Validation Class Initialized
INFO - 2016-05-03 20:41:49 --> Controller Class Initialized
INFO - 2016-05-03 20:41:49 --> Model Class Initialized
INFO - 2016-05-03 20:41:49 --> Database Driver Class Initialized
INFO - 2016-05-03 20:41:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:41:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:41:49 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:41:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:41:50 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:41:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:41:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:41:50 --> Final output sent to browser
DEBUG - 2016-05-03 20:41:50 --> Total execution time: 0.1193
INFO - 2016-05-03 20:42:29 --> Config Class Initialized
INFO - 2016-05-03 20:42:29 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:42:29 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:42:29 --> Utf8 Class Initialized
INFO - 2016-05-03 20:42:29 --> URI Class Initialized
INFO - 2016-05-03 20:42:29 --> Router Class Initialized
INFO - 2016-05-03 20:42:29 --> Output Class Initialized
INFO - 2016-05-03 20:42:29 --> Security Class Initialized
DEBUG - 2016-05-03 20:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:42:29 --> Input Class Initialized
INFO - 2016-05-03 20:42:29 --> Language Class Initialized
INFO - 2016-05-03 20:42:29 --> Loader Class Initialized
INFO - 2016-05-03 20:42:29 --> Helper loaded: url_helper
INFO - 2016-05-03 20:42:29 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:42:29 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:42:29 --> Helper loaded: form_helper
INFO - 2016-05-03 20:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:42:29 --> Form Validation Class Initialized
INFO - 2016-05-03 20:42:29 --> Controller Class Initialized
INFO - 2016-05-03 20:42:29 --> Model Class Initialized
INFO - 2016-05-03 20:42:29 --> Database Driver Class Initialized
INFO - 2016-05-03 20:42:29 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:42:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:42:29 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:42:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:42:29 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:42:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:42:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:42:29 --> Final output sent to browser
DEBUG - 2016-05-03 20:42:29 --> Total execution time: 0.0811
INFO - 2016-05-03 20:42:50 --> Config Class Initialized
INFO - 2016-05-03 20:42:50 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:42:50 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:42:50 --> Utf8 Class Initialized
INFO - 2016-05-03 20:42:50 --> URI Class Initialized
INFO - 2016-05-03 20:42:50 --> Router Class Initialized
INFO - 2016-05-03 20:42:50 --> Output Class Initialized
INFO - 2016-05-03 20:42:50 --> Security Class Initialized
DEBUG - 2016-05-03 20:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:42:50 --> Input Class Initialized
INFO - 2016-05-03 20:42:50 --> Language Class Initialized
INFO - 2016-05-03 20:42:50 --> Loader Class Initialized
INFO - 2016-05-03 20:42:50 --> Helper loaded: url_helper
INFO - 2016-05-03 20:42:50 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:42:50 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:42:50 --> Helper loaded: form_helper
INFO - 2016-05-03 20:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:42:50 --> Form Validation Class Initialized
INFO - 2016-05-03 20:42:50 --> Controller Class Initialized
INFO - 2016-05-03 20:42:50 --> Model Class Initialized
INFO - 2016-05-03 20:42:50 --> Database Driver Class Initialized
INFO - 2016-05-03 20:42:50 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:42:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:42:50 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:42:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:42:50 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:42:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:42:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:42:50 --> Final output sent to browser
DEBUG - 2016-05-03 20:42:50 --> Total execution time: 0.0810
INFO - 2016-05-03 20:43:33 --> Config Class Initialized
INFO - 2016-05-03 20:43:33 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:43:33 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:43:33 --> Utf8 Class Initialized
INFO - 2016-05-03 20:43:33 --> URI Class Initialized
INFO - 2016-05-03 20:43:33 --> Router Class Initialized
INFO - 2016-05-03 20:43:33 --> Output Class Initialized
INFO - 2016-05-03 20:43:33 --> Security Class Initialized
DEBUG - 2016-05-03 20:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:43:33 --> Input Class Initialized
INFO - 2016-05-03 20:43:33 --> Language Class Initialized
INFO - 2016-05-03 20:43:33 --> Loader Class Initialized
INFO - 2016-05-03 20:43:33 --> Helper loaded: url_helper
INFO - 2016-05-03 20:43:33 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:43:33 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:43:33 --> Helper loaded: form_helper
INFO - 2016-05-03 20:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:43:33 --> Form Validation Class Initialized
INFO - 2016-05-03 20:43:33 --> Controller Class Initialized
INFO - 2016-05-03 20:43:33 --> Model Class Initialized
INFO - 2016-05-03 20:43:33 --> Database Driver Class Initialized
INFO - 2016-05-03 20:43:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:43:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:43:33 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:43:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:43:33 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:43:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:43:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:43:33 --> Final output sent to browser
DEBUG - 2016-05-03 20:43:33 --> Total execution time: 0.0816
INFO - 2016-05-03 20:44:15 --> Config Class Initialized
INFO - 2016-05-03 20:44:15 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:44:15 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:44:15 --> Utf8 Class Initialized
INFO - 2016-05-03 20:44:15 --> URI Class Initialized
INFO - 2016-05-03 20:44:15 --> Router Class Initialized
INFO - 2016-05-03 20:44:15 --> Output Class Initialized
INFO - 2016-05-03 20:44:15 --> Security Class Initialized
DEBUG - 2016-05-03 20:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:44:15 --> Input Class Initialized
INFO - 2016-05-03 20:44:15 --> Language Class Initialized
INFO - 2016-05-03 20:44:15 --> Loader Class Initialized
INFO - 2016-05-03 20:44:16 --> Helper loaded: url_helper
INFO - 2016-05-03 20:44:16 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:44:16 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:44:16 --> Helper loaded: form_helper
INFO - 2016-05-03 20:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:44:16 --> Form Validation Class Initialized
INFO - 2016-05-03 20:44:16 --> Controller Class Initialized
INFO - 2016-05-03 20:44:16 --> Model Class Initialized
INFO - 2016-05-03 20:44:16 --> Database Driver Class Initialized
INFO - 2016-05-03 20:44:16 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:44:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:44:16 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:44:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:44:16 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:44:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:44:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:44:16 --> Final output sent to browser
DEBUG - 2016-05-03 20:44:16 --> Total execution time: 0.0829
INFO - 2016-05-03 20:44:46 --> Config Class Initialized
INFO - 2016-05-03 20:44:46 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:44:46 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:44:46 --> Utf8 Class Initialized
INFO - 2016-05-03 20:44:46 --> URI Class Initialized
INFO - 2016-05-03 20:44:46 --> Router Class Initialized
INFO - 2016-05-03 20:44:46 --> Output Class Initialized
INFO - 2016-05-03 20:44:46 --> Security Class Initialized
DEBUG - 2016-05-03 20:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:44:46 --> Input Class Initialized
INFO - 2016-05-03 20:44:46 --> Language Class Initialized
INFO - 2016-05-03 20:44:46 --> Loader Class Initialized
INFO - 2016-05-03 20:44:46 --> Helper loaded: url_helper
INFO - 2016-05-03 20:44:46 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:44:46 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:44:46 --> Helper loaded: form_helper
INFO - 2016-05-03 20:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:44:46 --> Form Validation Class Initialized
INFO - 2016-05-03 20:44:46 --> Controller Class Initialized
INFO - 2016-05-03 20:44:46 --> Model Class Initialized
INFO - 2016-05-03 20:44:46 --> Database Driver Class Initialized
INFO - 2016-05-03 20:44:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:44:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:44:46 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:44:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:44:46 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:44:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:44:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:44:46 --> Final output sent to browser
DEBUG - 2016-05-03 20:44:46 --> Total execution time: 0.0821
INFO - 2016-05-03 20:45:20 --> Config Class Initialized
INFO - 2016-05-03 20:45:20 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:45:20 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:45:20 --> Utf8 Class Initialized
INFO - 2016-05-03 20:45:20 --> URI Class Initialized
INFO - 2016-05-03 20:45:20 --> Router Class Initialized
INFO - 2016-05-03 20:45:20 --> Output Class Initialized
INFO - 2016-05-03 20:45:20 --> Security Class Initialized
DEBUG - 2016-05-03 20:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:45:20 --> Input Class Initialized
INFO - 2016-05-03 20:45:20 --> Language Class Initialized
INFO - 2016-05-03 20:45:20 --> Loader Class Initialized
INFO - 2016-05-03 20:45:20 --> Helper loaded: url_helper
INFO - 2016-05-03 20:45:20 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:45:20 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:45:20 --> Helper loaded: form_helper
INFO - 2016-05-03 20:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:45:20 --> Form Validation Class Initialized
INFO - 2016-05-03 20:45:20 --> Controller Class Initialized
INFO - 2016-05-03 20:45:20 --> Model Class Initialized
INFO - 2016-05-03 20:45:20 --> Database Driver Class Initialized
INFO - 2016-05-03 20:45:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:45:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:45:20 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:45:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:45:20 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:45:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:45:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:45:20 --> Final output sent to browser
DEBUG - 2016-05-03 20:45:20 --> Total execution time: 0.0788
INFO - 2016-05-03 20:45:37 --> Config Class Initialized
INFO - 2016-05-03 20:45:37 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:45:37 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:45:37 --> Utf8 Class Initialized
INFO - 2016-05-03 20:45:37 --> URI Class Initialized
INFO - 2016-05-03 20:45:37 --> Router Class Initialized
INFO - 2016-05-03 20:45:37 --> Output Class Initialized
INFO - 2016-05-03 20:45:37 --> Security Class Initialized
DEBUG - 2016-05-03 20:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:45:37 --> Input Class Initialized
INFO - 2016-05-03 20:45:37 --> Language Class Initialized
INFO - 2016-05-03 20:45:37 --> Loader Class Initialized
INFO - 2016-05-03 20:45:37 --> Helper loaded: url_helper
INFO - 2016-05-03 20:45:37 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:45:37 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:45:37 --> Helper loaded: form_helper
INFO - 2016-05-03 20:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:45:37 --> Form Validation Class Initialized
INFO - 2016-05-03 20:45:37 --> Controller Class Initialized
INFO - 2016-05-03 20:45:37 --> Model Class Initialized
INFO - 2016-05-03 20:45:37 --> Database Driver Class Initialized
INFO - 2016-05-03 20:45:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:45:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:45:37 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:45:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:45:37 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:45:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:45:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:45:37 --> Final output sent to browser
DEBUG - 2016-05-03 20:45:37 --> Total execution time: 0.0817
INFO - 2016-05-03 20:45:42 --> Config Class Initialized
INFO - 2016-05-03 20:45:42 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:45:42 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:45:42 --> Utf8 Class Initialized
INFO - 2016-05-03 20:45:42 --> URI Class Initialized
INFO - 2016-05-03 20:45:42 --> Router Class Initialized
INFO - 2016-05-03 20:45:42 --> Output Class Initialized
INFO - 2016-05-03 20:45:42 --> Security Class Initialized
DEBUG - 2016-05-03 20:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:45:42 --> Input Class Initialized
INFO - 2016-05-03 20:45:42 --> Language Class Initialized
INFO - 2016-05-03 20:45:42 --> Loader Class Initialized
INFO - 2016-05-03 20:45:42 --> Helper loaded: url_helper
INFO - 2016-05-03 20:45:42 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:45:42 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:45:42 --> Helper loaded: form_helper
INFO - 2016-05-03 20:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:45:42 --> Form Validation Class Initialized
INFO - 2016-05-03 20:45:42 --> Controller Class Initialized
INFO - 2016-05-03 20:45:42 --> Model Class Initialized
INFO - 2016-05-03 20:45:42 --> Database Driver Class Initialized
INFO - 2016-05-03 20:45:42 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:45:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:45:42 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:45:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:45:42 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:45:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:45:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:45:42 --> Final output sent to browser
DEBUG - 2016-05-03 20:45:42 --> Total execution time: 0.1480
INFO - 2016-05-03 20:46:05 --> Config Class Initialized
INFO - 2016-05-03 20:46:05 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:46:05 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:46:05 --> Utf8 Class Initialized
INFO - 2016-05-03 20:46:05 --> URI Class Initialized
INFO - 2016-05-03 20:46:05 --> Router Class Initialized
INFO - 2016-05-03 20:46:05 --> Output Class Initialized
INFO - 2016-05-03 20:46:05 --> Security Class Initialized
DEBUG - 2016-05-03 20:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:46:05 --> Input Class Initialized
INFO - 2016-05-03 20:46:05 --> Language Class Initialized
INFO - 2016-05-03 20:46:05 --> Loader Class Initialized
INFO - 2016-05-03 20:46:05 --> Helper loaded: url_helper
INFO - 2016-05-03 20:46:05 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:46:05 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:46:05 --> Helper loaded: form_helper
INFO - 2016-05-03 20:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:46:05 --> Form Validation Class Initialized
INFO - 2016-05-03 20:46:05 --> Controller Class Initialized
INFO - 2016-05-03 20:46:05 --> Model Class Initialized
INFO - 2016-05-03 20:46:05 --> Database Driver Class Initialized
INFO - 2016-05-03 20:46:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:46:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:46:05 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:46:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:46:05 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:46:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:46:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:46:05 --> Final output sent to browser
DEBUG - 2016-05-03 20:46:05 --> Total execution time: 0.0839
INFO - 2016-05-03 20:46:32 --> Config Class Initialized
INFO - 2016-05-03 20:46:32 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:46:32 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:46:32 --> Utf8 Class Initialized
INFO - 2016-05-03 20:46:32 --> URI Class Initialized
INFO - 2016-05-03 20:46:32 --> Router Class Initialized
INFO - 2016-05-03 20:46:32 --> Output Class Initialized
INFO - 2016-05-03 20:46:32 --> Security Class Initialized
DEBUG - 2016-05-03 20:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:46:32 --> Input Class Initialized
INFO - 2016-05-03 20:46:32 --> Language Class Initialized
INFO - 2016-05-03 20:46:32 --> Loader Class Initialized
INFO - 2016-05-03 20:46:32 --> Helper loaded: url_helper
INFO - 2016-05-03 20:46:32 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:46:32 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:46:32 --> Helper loaded: form_helper
INFO - 2016-05-03 20:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:46:32 --> Form Validation Class Initialized
INFO - 2016-05-03 20:46:32 --> Controller Class Initialized
INFO - 2016-05-03 20:46:32 --> Model Class Initialized
INFO - 2016-05-03 20:46:32 --> Database Driver Class Initialized
INFO - 2016-05-03 20:46:32 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:46:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:46:32 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:46:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:46:32 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:46:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:46:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:46:32 --> Final output sent to browser
DEBUG - 2016-05-03 20:46:32 --> Total execution time: 0.0798
INFO - 2016-05-03 20:46:43 --> Config Class Initialized
INFO - 2016-05-03 20:46:43 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:46:43 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:46:43 --> Utf8 Class Initialized
INFO - 2016-05-03 20:46:43 --> URI Class Initialized
INFO - 2016-05-03 20:46:43 --> Router Class Initialized
INFO - 2016-05-03 20:46:43 --> Output Class Initialized
INFO - 2016-05-03 20:46:43 --> Security Class Initialized
DEBUG - 2016-05-03 20:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:46:43 --> Input Class Initialized
INFO - 2016-05-03 20:46:43 --> Language Class Initialized
INFO - 2016-05-03 20:46:43 --> Loader Class Initialized
INFO - 2016-05-03 20:46:43 --> Helper loaded: url_helper
INFO - 2016-05-03 20:46:43 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:46:43 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:46:43 --> Helper loaded: form_helper
INFO - 2016-05-03 20:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:46:43 --> Form Validation Class Initialized
INFO - 2016-05-03 20:46:43 --> Controller Class Initialized
INFO - 2016-05-03 20:46:43 --> Model Class Initialized
INFO - 2016-05-03 20:46:43 --> Database Driver Class Initialized
INFO - 2016-05-03 20:46:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:46:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:46:43 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:46:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:46:43 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:46:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:46:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:46:43 --> Final output sent to browser
DEBUG - 2016-05-03 20:46:43 --> Total execution time: 0.0805
INFO - 2016-05-03 20:47:11 --> Config Class Initialized
INFO - 2016-05-03 20:47:11 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:47:11 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:47:11 --> Utf8 Class Initialized
INFO - 2016-05-03 20:47:11 --> URI Class Initialized
INFO - 2016-05-03 20:47:11 --> Router Class Initialized
INFO - 2016-05-03 20:47:11 --> Output Class Initialized
INFO - 2016-05-03 20:47:11 --> Security Class Initialized
DEBUG - 2016-05-03 20:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:47:11 --> Input Class Initialized
INFO - 2016-05-03 20:47:11 --> Language Class Initialized
INFO - 2016-05-03 20:47:11 --> Loader Class Initialized
INFO - 2016-05-03 20:47:11 --> Helper loaded: url_helper
INFO - 2016-05-03 20:47:11 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:47:11 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:47:11 --> Helper loaded: form_helper
INFO - 2016-05-03 20:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:47:11 --> Form Validation Class Initialized
INFO - 2016-05-03 20:47:11 --> Controller Class Initialized
INFO - 2016-05-03 20:47:11 --> Model Class Initialized
INFO - 2016-05-03 20:47:11 --> Database Driver Class Initialized
INFO - 2016-05-03 20:47:11 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:47:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:47:11 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:47:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:47:11 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:47:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:47:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:47:11 --> Final output sent to browser
DEBUG - 2016-05-03 20:47:11 --> Total execution time: 0.0905
INFO - 2016-05-03 20:47:17 --> Config Class Initialized
INFO - 2016-05-03 20:47:17 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:47:17 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:47:17 --> Utf8 Class Initialized
INFO - 2016-05-03 20:47:17 --> URI Class Initialized
INFO - 2016-05-03 20:47:17 --> Router Class Initialized
INFO - 2016-05-03 20:47:17 --> Output Class Initialized
INFO - 2016-05-03 20:47:17 --> Security Class Initialized
DEBUG - 2016-05-03 20:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:47:17 --> Input Class Initialized
INFO - 2016-05-03 20:47:17 --> Language Class Initialized
INFO - 2016-05-03 20:47:17 --> Loader Class Initialized
INFO - 2016-05-03 20:47:17 --> Helper loaded: url_helper
INFO - 2016-05-03 20:47:17 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:47:17 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:47:17 --> Helper loaded: form_helper
INFO - 2016-05-03 20:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:47:17 --> Form Validation Class Initialized
INFO - 2016-05-03 20:47:17 --> Controller Class Initialized
INFO - 2016-05-03 20:47:17 --> Model Class Initialized
INFO - 2016-05-03 20:47:17 --> Database Driver Class Initialized
INFO - 2016-05-03 20:47:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:47:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:47:17 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:47:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:47:17 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:47:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:47:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:47:17 --> Final output sent to browser
DEBUG - 2016-05-03 20:47:17 --> Total execution time: 0.0757
INFO - 2016-05-03 20:47:21 --> Config Class Initialized
INFO - 2016-05-03 20:47:21 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:47:21 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:47:21 --> Utf8 Class Initialized
INFO - 2016-05-03 20:47:21 --> URI Class Initialized
INFO - 2016-05-03 20:47:21 --> Router Class Initialized
INFO - 2016-05-03 20:47:21 --> Output Class Initialized
INFO - 2016-05-03 20:47:21 --> Security Class Initialized
DEBUG - 2016-05-03 20:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:47:21 --> Input Class Initialized
INFO - 2016-05-03 20:47:21 --> Language Class Initialized
INFO - 2016-05-03 20:47:21 --> Loader Class Initialized
INFO - 2016-05-03 20:47:21 --> Helper loaded: url_helper
INFO - 2016-05-03 20:47:21 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:47:21 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:47:21 --> Helper loaded: form_helper
INFO - 2016-05-03 20:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:47:21 --> Form Validation Class Initialized
INFO - 2016-05-03 20:47:21 --> Controller Class Initialized
INFO - 2016-05-03 20:47:21 --> Model Class Initialized
INFO - 2016-05-03 20:47:21 --> Database Driver Class Initialized
INFO - 2016-05-03 20:47:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:47:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:47:21 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:47:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:47:21 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:47:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:47:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:47:21 --> Final output sent to browser
DEBUG - 2016-05-03 20:47:21 --> Total execution time: 0.0758
INFO - 2016-05-03 20:47:23 --> Config Class Initialized
INFO - 2016-05-03 20:47:23 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:47:23 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:47:23 --> Utf8 Class Initialized
INFO - 2016-05-03 20:47:23 --> URI Class Initialized
INFO - 2016-05-03 20:47:23 --> Router Class Initialized
INFO - 2016-05-03 20:47:23 --> Output Class Initialized
INFO - 2016-05-03 20:47:23 --> Security Class Initialized
DEBUG - 2016-05-03 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:47:23 --> Input Class Initialized
INFO - 2016-05-03 20:47:23 --> Language Class Initialized
INFO - 2016-05-03 20:47:23 --> Loader Class Initialized
INFO - 2016-05-03 20:47:23 --> Helper loaded: url_helper
INFO - 2016-05-03 20:47:23 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:47:23 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:47:23 --> Helper loaded: form_helper
INFO - 2016-05-03 20:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:47:23 --> Form Validation Class Initialized
INFO - 2016-05-03 20:47:23 --> Controller Class Initialized
INFO - 2016-05-03 20:47:23 --> Model Class Initialized
INFO - 2016-05-03 20:47:23 --> Database Driver Class Initialized
INFO - 2016-05-03 20:47:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:47:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:47:23 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:47:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:47:23 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:47:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:47:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:47:23 --> Final output sent to browser
DEBUG - 2016-05-03 20:47:23 --> Total execution time: 0.1012
INFO - 2016-05-03 20:48:07 --> Config Class Initialized
INFO - 2016-05-03 20:48:07 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:48:07 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:48:07 --> Utf8 Class Initialized
INFO - 2016-05-03 20:48:07 --> URI Class Initialized
INFO - 2016-05-03 20:48:07 --> Router Class Initialized
INFO - 2016-05-03 20:48:07 --> Output Class Initialized
INFO - 2016-05-03 20:48:07 --> Security Class Initialized
DEBUG - 2016-05-03 20:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:48:07 --> Input Class Initialized
INFO - 2016-05-03 20:48:07 --> Language Class Initialized
INFO - 2016-05-03 20:48:07 --> Loader Class Initialized
INFO - 2016-05-03 20:48:07 --> Helper loaded: url_helper
INFO - 2016-05-03 20:48:07 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:48:07 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:48:07 --> Helper loaded: form_helper
INFO - 2016-05-03 20:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:48:07 --> Form Validation Class Initialized
INFO - 2016-05-03 20:48:07 --> Controller Class Initialized
INFO - 2016-05-03 20:48:07 --> Model Class Initialized
INFO - 2016-05-03 20:48:07 --> Database Driver Class Initialized
INFO - 2016-05-03 20:48:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:48:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:48:07 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:48:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:48:07 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:48:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:48:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:48:07 --> Final output sent to browser
DEBUG - 2016-05-03 20:48:07 --> Total execution time: 0.1030
INFO - 2016-05-03 20:48:12 --> Config Class Initialized
INFO - 2016-05-03 20:48:12 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:48:12 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:48:12 --> Utf8 Class Initialized
INFO - 2016-05-03 20:48:12 --> URI Class Initialized
INFO - 2016-05-03 20:48:12 --> Router Class Initialized
INFO - 2016-05-03 20:48:12 --> Output Class Initialized
INFO - 2016-05-03 20:48:12 --> Security Class Initialized
DEBUG - 2016-05-03 20:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:48:12 --> Input Class Initialized
INFO - 2016-05-03 20:48:12 --> Language Class Initialized
INFO - 2016-05-03 20:48:12 --> Loader Class Initialized
INFO - 2016-05-03 20:48:12 --> Helper loaded: url_helper
INFO - 2016-05-03 20:48:12 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:48:12 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:48:12 --> Helper loaded: form_helper
INFO - 2016-05-03 20:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:48:12 --> Form Validation Class Initialized
INFO - 2016-05-03 20:48:12 --> Controller Class Initialized
INFO - 2016-05-03 20:48:12 --> Model Class Initialized
INFO - 2016-05-03 20:48:12 --> Database Driver Class Initialized
INFO - 2016-05-03 20:48:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:48:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:48:12 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:48:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:48:12 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:48:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:48:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:48:12 --> Final output sent to browser
DEBUG - 2016-05-03 20:48:12 --> Total execution time: 0.1041
INFO - 2016-05-03 20:48:16 --> Config Class Initialized
INFO - 2016-05-03 20:48:16 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:48:16 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:48:16 --> Utf8 Class Initialized
INFO - 2016-05-03 20:48:16 --> URI Class Initialized
INFO - 2016-05-03 20:48:16 --> Router Class Initialized
INFO - 2016-05-03 20:48:16 --> Output Class Initialized
INFO - 2016-05-03 20:48:16 --> Security Class Initialized
DEBUG - 2016-05-03 20:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:48:16 --> Input Class Initialized
INFO - 2016-05-03 20:48:16 --> Language Class Initialized
INFO - 2016-05-03 20:48:16 --> Loader Class Initialized
INFO - 2016-05-03 20:48:16 --> Helper loaded: url_helper
INFO - 2016-05-03 20:48:16 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:48:16 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:48:16 --> Helper loaded: form_helper
INFO - 2016-05-03 20:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:48:16 --> Form Validation Class Initialized
INFO - 2016-05-03 20:48:16 --> Controller Class Initialized
INFO - 2016-05-03 20:48:16 --> Model Class Initialized
INFO - 2016-05-03 20:48:16 --> Database Driver Class Initialized
INFO - 2016-05-03 20:48:16 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:48:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:48:16 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:48:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:48:16 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:48:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:48:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:48:16 --> Final output sent to browser
DEBUG - 2016-05-03 20:48:16 --> Total execution time: 0.0970
INFO - 2016-05-03 20:48:22 --> Config Class Initialized
INFO - 2016-05-03 20:48:22 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:48:22 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:48:22 --> Utf8 Class Initialized
INFO - 2016-05-03 20:48:22 --> URI Class Initialized
INFO - 2016-05-03 20:48:22 --> Router Class Initialized
INFO - 2016-05-03 20:48:22 --> Output Class Initialized
INFO - 2016-05-03 20:48:22 --> Security Class Initialized
DEBUG - 2016-05-03 20:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:48:22 --> Input Class Initialized
INFO - 2016-05-03 20:48:22 --> Language Class Initialized
INFO - 2016-05-03 20:48:22 --> Loader Class Initialized
INFO - 2016-05-03 20:48:22 --> Helper loaded: url_helper
INFO - 2016-05-03 20:48:22 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:48:22 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:48:22 --> Helper loaded: form_helper
INFO - 2016-05-03 20:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:48:22 --> Form Validation Class Initialized
INFO - 2016-05-03 20:48:22 --> Controller Class Initialized
INFO - 2016-05-03 20:48:22 --> Model Class Initialized
INFO - 2016-05-03 20:48:22 --> Database Driver Class Initialized
INFO - 2016-05-03 20:48:22 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:48:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:48:22 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:48:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:48:22 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:48:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:48:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:48:22 --> Final output sent to browser
DEBUG - 2016-05-03 20:48:22 --> Total execution time: 0.1199
INFO - 2016-05-03 20:50:55 --> Config Class Initialized
INFO - 2016-05-03 20:50:55 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:50:55 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:50:55 --> Utf8 Class Initialized
INFO - 2016-05-03 20:50:55 --> URI Class Initialized
INFO - 2016-05-03 20:50:55 --> Router Class Initialized
INFO - 2016-05-03 20:50:55 --> Output Class Initialized
INFO - 2016-05-03 20:50:55 --> Security Class Initialized
DEBUG - 2016-05-03 20:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:50:55 --> Input Class Initialized
INFO - 2016-05-03 20:50:55 --> Language Class Initialized
INFO - 2016-05-03 20:50:55 --> Loader Class Initialized
INFO - 2016-05-03 20:50:55 --> Helper loaded: url_helper
INFO - 2016-05-03 20:50:55 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:50:55 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:50:55 --> Helper loaded: form_helper
INFO - 2016-05-03 20:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:50:55 --> Form Validation Class Initialized
INFO - 2016-05-03 20:50:55 --> Controller Class Initialized
INFO - 2016-05-03 20:50:55 --> Model Class Initialized
INFO - 2016-05-03 20:50:55 --> Database Driver Class Initialized
INFO - 2016-05-03 20:50:55 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:50:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:50:55 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:50:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:50:56 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 20:50:56 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Proveedores.php 36
ERROR - 2016-05-03 20:50:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM proveedor WHERE nombre LIKE '%baja%' OR nif LIKE '%baja%' OR correo LIKE '%baja%' OR telefono LIKE '%baja%' OR direccion LIKE '%baja%' OR localidad LIKE '%baja%' OR anotaciones LIKE '%baja%' OR estado LIKE '%baja%' LIMIT 0, ; 
INFO - 2016-05-03 20:50:56 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-03 20:51:15 --> Config Class Initialized
INFO - 2016-05-03 20:51:15 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:51:15 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:51:15 --> Utf8 Class Initialized
INFO - 2016-05-03 20:51:15 --> URI Class Initialized
INFO - 2016-05-03 20:51:15 --> Router Class Initialized
INFO - 2016-05-03 20:51:15 --> Output Class Initialized
INFO - 2016-05-03 20:51:15 --> Security Class Initialized
DEBUG - 2016-05-03 20:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:51:15 --> Input Class Initialized
INFO - 2016-05-03 20:51:15 --> Language Class Initialized
INFO - 2016-05-03 20:51:15 --> Loader Class Initialized
INFO - 2016-05-03 20:51:15 --> Helper loaded: url_helper
INFO - 2016-05-03 20:51:15 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:51:15 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:51:15 --> Helper loaded: form_helper
INFO - 2016-05-03 20:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:51:15 --> Form Validation Class Initialized
INFO - 2016-05-03 20:51:15 --> Controller Class Initialized
INFO - 2016-05-03 20:51:15 --> Model Class Initialized
INFO - 2016-05-03 20:51:15 --> Database Driver Class Initialized
INFO - 2016-05-03 20:51:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:51:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:51:15 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:51:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:51:15 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 20:51:15 --> Severity: Notice --> Undefined index: per_page C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Proveedores.php 36
ERROR - 2016-05-03 20:51:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM proveedor WHERE nombre LIKE '%baja%' OR nif LIKE '%baja%' OR correo LIKE '%baja%' OR telefono LIKE '%baja%' OR direccion LIKE '%baja%' OR localidad LIKE '%baja%' OR anotaciones LIKE '%baja%' OR estado LIKE '%baja%' LIMIT 0, ; 
INFO - 2016-05-03 20:51:15 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-03 20:51:37 --> Config Class Initialized
INFO - 2016-05-03 20:51:37 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:51:37 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:51:37 --> Utf8 Class Initialized
INFO - 2016-05-03 20:51:37 --> URI Class Initialized
INFO - 2016-05-03 20:51:37 --> Router Class Initialized
INFO - 2016-05-03 20:51:37 --> Output Class Initialized
INFO - 2016-05-03 20:51:37 --> Security Class Initialized
DEBUG - 2016-05-03 20:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:51:37 --> Input Class Initialized
INFO - 2016-05-03 20:51:37 --> Language Class Initialized
INFO - 2016-05-03 20:51:37 --> Loader Class Initialized
INFO - 2016-05-03 20:51:37 --> Helper loaded: url_helper
INFO - 2016-05-03 20:51:37 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:51:37 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:51:37 --> Helper loaded: form_helper
INFO - 2016-05-03 20:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:51:37 --> Form Validation Class Initialized
INFO - 2016-05-03 20:51:37 --> Controller Class Initialized
INFO - 2016-05-03 20:51:37 --> Model Class Initialized
INFO - 2016-05-03 20:51:37 --> Database Driver Class Initialized
INFO - 2016-05-03 20:51:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:51:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:51:37 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:51:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:51:37 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 20:51:37 --> Severity: Error --> Unsupported operand types C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\libraries\Pagination.php 409
INFO - 2016-05-03 20:52:04 --> Config Class Initialized
INFO - 2016-05-03 20:52:04 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:52:04 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:52:04 --> Utf8 Class Initialized
INFO - 2016-05-03 20:52:04 --> URI Class Initialized
INFO - 2016-05-03 20:52:04 --> Router Class Initialized
INFO - 2016-05-03 20:52:04 --> Output Class Initialized
INFO - 2016-05-03 20:52:04 --> Security Class Initialized
DEBUG - 2016-05-03 20:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:52:04 --> Input Class Initialized
INFO - 2016-05-03 20:52:04 --> Language Class Initialized
INFO - 2016-05-03 20:52:04 --> Loader Class Initialized
INFO - 2016-05-03 20:52:04 --> Helper loaded: url_helper
INFO - 2016-05-03 20:52:04 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:52:04 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:52:04 --> Helper loaded: form_helper
INFO - 2016-05-03 20:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:52:04 --> Form Validation Class Initialized
INFO - 2016-05-03 20:52:04 --> Controller Class Initialized
INFO - 2016-05-03 20:52:04 --> Model Class Initialized
INFO - 2016-05-03 20:52:04 --> Database Driver Class Initialized
INFO - 2016-05-03 20:52:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:52:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:52:04 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:52:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:52:04 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:52:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:52:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:52:04 --> Final output sent to browser
DEBUG - 2016-05-03 20:52:04 --> Total execution time: 0.0918
INFO - 2016-05-03 20:52:16 --> Config Class Initialized
INFO - 2016-05-03 20:52:16 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:52:16 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:52:16 --> Utf8 Class Initialized
INFO - 2016-05-03 20:52:16 --> URI Class Initialized
INFO - 2016-05-03 20:52:16 --> Router Class Initialized
INFO - 2016-05-03 20:52:16 --> Output Class Initialized
INFO - 2016-05-03 20:52:16 --> Security Class Initialized
DEBUG - 2016-05-03 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:52:16 --> Input Class Initialized
INFO - 2016-05-03 20:52:16 --> Language Class Initialized
INFO - 2016-05-03 20:52:16 --> Loader Class Initialized
INFO - 2016-05-03 20:52:16 --> Helper loaded: url_helper
INFO - 2016-05-03 20:52:16 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:52:16 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:52:16 --> Helper loaded: form_helper
INFO - 2016-05-03 20:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:52:16 --> Form Validation Class Initialized
INFO - 2016-05-03 20:52:16 --> Controller Class Initialized
INFO - 2016-05-03 20:52:16 --> Model Class Initialized
INFO - 2016-05-03 20:52:17 --> Database Driver Class Initialized
INFO - 2016-05-03 20:52:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:52:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:52:17 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:52:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:52:17 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:52:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:52:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:52:17 --> Final output sent to browser
DEBUG - 2016-05-03 20:52:17 --> Total execution time: 0.0759
INFO - 2016-05-03 20:52:30 --> Config Class Initialized
INFO - 2016-05-03 20:52:30 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:52:30 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:52:30 --> Utf8 Class Initialized
INFO - 2016-05-03 20:52:30 --> URI Class Initialized
INFO - 2016-05-03 20:52:30 --> Router Class Initialized
INFO - 2016-05-03 20:52:30 --> Output Class Initialized
INFO - 2016-05-03 20:52:30 --> Security Class Initialized
DEBUG - 2016-05-03 20:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:52:30 --> Input Class Initialized
INFO - 2016-05-03 20:52:30 --> Language Class Initialized
INFO - 2016-05-03 20:52:30 --> Loader Class Initialized
INFO - 2016-05-03 20:52:30 --> Helper loaded: url_helper
INFO - 2016-05-03 20:52:30 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:52:30 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:52:30 --> Helper loaded: form_helper
INFO - 2016-05-03 20:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:52:30 --> Form Validation Class Initialized
INFO - 2016-05-03 20:52:30 --> Controller Class Initialized
INFO - 2016-05-03 20:52:30 --> Model Class Initialized
INFO - 2016-05-03 20:52:30 --> Database Driver Class Initialized
INFO - 2016-05-03 20:52:30 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:52:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:52:30 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:52:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:52:30 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:52:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:52:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:52:30 --> Final output sent to browser
DEBUG - 2016-05-03 20:52:30 --> Total execution time: 0.0958
INFO - 2016-05-03 20:52:33 --> Config Class Initialized
INFO - 2016-05-03 20:52:33 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:52:33 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:52:33 --> Utf8 Class Initialized
INFO - 2016-05-03 20:52:33 --> URI Class Initialized
INFO - 2016-05-03 20:52:33 --> Router Class Initialized
INFO - 2016-05-03 20:52:33 --> Output Class Initialized
INFO - 2016-05-03 20:52:33 --> Security Class Initialized
DEBUG - 2016-05-03 20:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:52:33 --> Input Class Initialized
INFO - 2016-05-03 20:52:33 --> Language Class Initialized
INFO - 2016-05-03 20:52:33 --> Loader Class Initialized
INFO - 2016-05-03 20:52:33 --> Helper loaded: url_helper
INFO - 2016-05-03 20:52:33 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:52:33 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:52:33 --> Helper loaded: form_helper
INFO - 2016-05-03 20:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:52:33 --> Form Validation Class Initialized
INFO - 2016-05-03 20:52:33 --> Controller Class Initialized
INFO - 2016-05-03 20:52:33 --> Model Class Initialized
INFO - 2016-05-03 20:52:33 --> Database Driver Class Initialized
INFO - 2016-05-03 20:52:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:52:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:52:33 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:52:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:52:33 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:52:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:52:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:52:33 --> Final output sent to browser
DEBUG - 2016-05-03 20:52:33 --> Total execution time: 0.1110
INFO - 2016-05-03 20:53:56 --> Config Class Initialized
INFO - 2016-05-03 20:53:56 --> Hooks Class Initialized
DEBUG - 2016-05-03 20:53:56 --> UTF-8 Support Enabled
INFO - 2016-05-03 20:53:56 --> Utf8 Class Initialized
INFO - 2016-05-03 20:53:56 --> URI Class Initialized
INFO - 2016-05-03 20:53:56 --> Router Class Initialized
INFO - 2016-05-03 20:53:56 --> Output Class Initialized
INFO - 2016-05-03 20:53:56 --> Security Class Initialized
DEBUG - 2016-05-03 20:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 20:53:56 --> Input Class Initialized
INFO - 2016-05-03 20:53:56 --> Language Class Initialized
INFO - 2016-05-03 20:53:56 --> Loader Class Initialized
INFO - 2016-05-03 20:53:56 --> Helper loaded: url_helper
INFO - 2016-05-03 20:53:56 --> Helper loaded: sesion_helper
INFO - 2016-05-03 20:53:56 --> Helper loaded: templates_helper
INFO - 2016-05-03 20:53:56 --> Helper loaded: form_helper
INFO - 2016-05-03 20:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 20:53:56 --> Form Validation Class Initialized
INFO - 2016-05-03 20:53:56 --> Controller Class Initialized
INFO - 2016-05-03 20:53:56 --> Model Class Initialized
INFO - 2016-05-03 20:53:56 --> Database Driver Class Initialized
INFO - 2016-05-03 20:53:56 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 20:53:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 20:53:56 --> Pagination Class Initialized
DEBUG - 2016-05-03 20:53:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 20:53:56 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 20:53:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 20:53:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 20:53:56 --> Final output sent to browser
DEBUG - 2016-05-03 20:53:56 --> Total execution time: 0.0992
INFO - 2016-05-03 21:00:12 --> Config Class Initialized
INFO - 2016-05-03 21:00:12 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:00:12 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:00:12 --> Utf8 Class Initialized
INFO - 2016-05-03 21:00:12 --> URI Class Initialized
INFO - 2016-05-03 21:00:12 --> Router Class Initialized
INFO - 2016-05-03 21:00:12 --> Output Class Initialized
INFO - 2016-05-03 21:00:12 --> Security Class Initialized
DEBUG - 2016-05-03 21:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:00:12 --> Input Class Initialized
INFO - 2016-05-03 21:00:12 --> Language Class Initialized
INFO - 2016-05-03 21:00:12 --> Loader Class Initialized
INFO - 2016-05-03 21:00:12 --> Helper loaded: url_helper
INFO - 2016-05-03 21:00:12 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:00:12 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:00:12 --> Helper loaded: form_helper
INFO - 2016-05-03 21:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:00:12 --> Form Validation Class Initialized
INFO - 2016-05-03 21:00:12 --> Controller Class Initialized
INFO - 2016-05-03 21:00:12 --> Model Class Initialized
INFO - 2016-05-03 21:00:12 --> Database Driver Class Initialized
INFO - 2016-05-03 21:00:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:00:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:00:12 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:00:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:00:12 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:00:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:00:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:00:12 --> Final output sent to browser
DEBUG - 2016-05-03 21:00:12 --> Total execution time: 0.1096
INFO - 2016-05-03 21:00:18 --> Config Class Initialized
INFO - 2016-05-03 21:00:18 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:00:18 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:00:18 --> Utf8 Class Initialized
INFO - 2016-05-03 21:00:18 --> URI Class Initialized
INFO - 2016-05-03 21:00:18 --> Router Class Initialized
INFO - 2016-05-03 21:00:18 --> Output Class Initialized
INFO - 2016-05-03 21:00:18 --> Security Class Initialized
DEBUG - 2016-05-03 21:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:00:18 --> Input Class Initialized
INFO - 2016-05-03 21:00:18 --> Language Class Initialized
INFO - 2016-05-03 21:00:18 --> Loader Class Initialized
INFO - 2016-05-03 21:00:18 --> Helper loaded: url_helper
INFO - 2016-05-03 21:00:18 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:00:18 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:00:18 --> Helper loaded: form_helper
INFO - 2016-05-03 21:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:00:18 --> Form Validation Class Initialized
INFO - 2016-05-03 21:00:18 --> Controller Class Initialized
INFO - 2016-05-03 21:00:18 --> Model Class Initialized
INFO - 2016-05-03 21:00:18 --> Database Driver Class Initialized
INFO - 2016-05-03 21:00:18 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:00:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:00:18 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:00:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:00:18 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:00:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:00:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:00:18 --> Final output sent to browser
DEBUG - 2016-05-03 21:00:18 --> Total execution time: 0.1147
INFO - 2016-05-03 21:01:30 --> Config Class Initialized
INFO - 2016-05-03 21:01:30 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:01:30 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:01:30 --> Utf8 Class Initialized
INFO - 2016-05-03 21:01:30 --> URI Class Initialized
INFO - 2016-05-03 21:01:30 --> Router Class Initialized
INFO - 2016-05-03 21:01:30 --> Output Class Initialized
INFO - 2016-05-03 21:01:30 --> Security Class Initialized
DEBUG - 2016-05-03 21:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:01:30 --> Input Class Initialized
INFO - 2016-05-03 21:01:30 --> Language Class Initialized
INFO - 2016-05-03 21:01:30 --> Loader Class Initialized
INFO - 2016-05-03 21:01:30 --> Helper loaded: url_helper
INFO - 2016-05-03 21:01:30 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:01:30 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:01:30 --> Helper loaded: form_helper
INFO - 2016-05-03 21:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:01:30 --> Form Validation Class Initialized
INFO - 2016-05-03 21:01:30 --> Controller Class Initialized
INFO - 2016-05-03 21:01:30 --> Model Class Initialized
INFO - 2016-05-03 21:01:30 --> Database Driver Class Initialized
INFO - 2016-05-03 21:01:30 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:01:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:01:30 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:01:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:01:30 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:01:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:01:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:01:30 --> Final output sent to browser
DEBUG - 2016-05-03 21:01:30 --> Total execution time: 0.0803
INFO - 2016-05-03 21:01:35 --> Config Class Initialized
INFO - 2016-05-03 21:01:35 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:01:35 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:01:35 --> Utf8 Class Initialized
INFO - 2016-05-03 21:01:35 --> URI Class Initialized
INFO - 2016-05-03 21:01:35 --> Router Class Initialized
INFO - 2016-05-03 21:01:35 --> Output Class Initialized
INFO - 2016-05-03 21:01:35 --> Security Class Initialized
DEBUG - 2016-05-03 21:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:01:35 --> Input Class Initialized
INFO - 2016-05-03 21:01:35 --> Language Class Initialized
INFO - 2016-05-03 21:01:35 --> Loader Class Initialized
INFO - 2016-05-03 21:01:35 --> Helper loaded: url_helper
INFO - 2016-05-03 21:01:35 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:01:35 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:01:35 --> Helper loaded: form_helper
INFO - 2016-05-03 21:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:01:35 --> Form Validation Class Initialized
INFO - 2016-05-03 21:01:35 --> Controller Class Initialized
INFO - 2016-05-03 21:01:35 --> Model Class Initialized
INFO - 2016-05-03 21:01:35 --> Database Driver Class Initialized
INFO - 2016-05-03 21:01:35 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:01:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:01:35 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:01:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:01:35 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:01:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:01:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:01:35 --> Final output sent to browser
DEBUG - 2016-05-03 21:01:35 --> Total execution time: 0.1218
INFO - 2016-05-03 21:01:37 --> Config Class Initialized
INFO - 2016-05-03 21:01:37 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:01:37 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:01:37 --> Utf8 Class Initialized
INFO - 2016-05-03 21:01:37 --> URI Class Initialized
INFO - 2016-05-03 21:01:37 --> Router Class Initialized
INFO - 2016-05-03 21:01:37 --> Output Class Initialized
INFO - 2016-05-03 21:01:37 --> Security Class Initialized
DEBUG - 2016-05-03 21:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:01:37 --> Input Class Initialized
INFO - 2016-05-03 21:01:37 --> Language Class Initialized
INFO - 2016-05-03 21:01:37 --> Loader Class Initialized
INFO - 2016-05-03 21:01:37 --> Helper loaded: url_helper
INFO - 2016-05-03 21:01:37 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:01:37 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:01:37 --> Helper loaded: form_helper
INFO - 2016-05-03 21:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:01:37 --> Form Validation Class Initialized
INFO - 2016-05-03 21:01:37 --> Controller Class Initialized
INFO - 2016-05-03 21:01:37 --> Model Class Initialized
INFO - 2016-05-03 21:01:37 --> Database Driver Class Initialized
INFO - 2016-05-03 21:01:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:01:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:01:37 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:01:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:01:37 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:01:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:01:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:01:37 --> Final output sent to browser
DEBUG - 2016-05-03 21:01:37 --> Total execution time: 0.1412
INFO - 2016-05-03 21:01:45 --> Config Class Initialized
INFO - 2016-05-03 21:01:45 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:01:45 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:01:45 --> Utf8 Class Initialized
INFO - 2016-05-03 21:01:45 --> URI Class Initialized
INFO - 2016-05-03 21:01:45 --> Router Class Initialized
INFO - 2016-05-03 21:01:45 --> Output Class Initialized
INFO - 2016-05-03 21:01:45 --> Security Class Initialized
DEBUG - 2016-05-03 21:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:01:45 --> Input Class Initialized
INFO - 2016-05-03 21:01:45 --> Language Class Initialized
INFO - 2016-05-03 21:01:45 --> Loader Class Initialized
INFO - 2016-05-03 21:01:45 --> Helper loaded: url_helper
INFO - 2016-05-03 21:01:45 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:01:45 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:01:45 --> Helper loaded: form_helper
INFO - 2016-05-03 21:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:01:45 --> Form Validation Class Initialized
INFO - 2016-05-03 21:01:45 --> Controller Class Initialized
INFO - 2016-05-03 21:01:45 --> Model Class Initialized
INFO - 2016-05-03 21:01:45 --> Database Driver Class Initialized
INFO - 2016-05-03 21:01:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:01:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:01:45 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:01:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:01:45 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:01:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:01:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:01:45 --> Final output sent to browser
DEBUG - 2016-05-03 21:01:45 --> Total execution time: 0.0827
INFO - 2016-05-03 21:01:52 --> Config Class Initialized
INFO - 2016-05-03 21:01:52 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:01:52 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:01:52 --> Utf8 Class Initialized
INFO - 2016-05-03 21:01:52 --> URI Class Initialized
INFO - 2016-05-03 21:01:52 --> Router Class Initialized
INFO - 2016-05-03 21:01:52 --> Output Class Initialized
INFO - 2016-05-03 21:01:52 --> Security Class Initialized
DEBUG - 2016-05-03 21:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:01:52 --> Input Class Initialized
INFO - 2016-05-03 21:01:52 --> Language Class Initialized
INFO - 2016-05-03 21:01:52 --> Loader Class Initialized
INFO - 2016-05-03 21:01:52 --> Helper loaded: url_helper
INFO - 2016-05-03 21:01:52 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:01:52 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:01:52 --> Helper loaded: form_helper
INFO - 2016-05-03 21:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:01:52 --> Form Validation Class Initialized
INFO - 2016-05-03 21:01:52 --> Controller Class Initialized
INFO - 2016-05-03 21:01:52 --> Model Class Initialized
INFO - 2016-05-03 21:01:52 --> Database Driver Class Initialized
INFO - 2016-05-03 21:01:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:01:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:01:52 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:01:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:01:52 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:01:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:01:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:01:52 --> Final output sent to browser
DEBUG - 2016-05-03 21:01:52 --> Total execution time: 0.0754
INFO - 2016-05-03 21:02:02 --> Config Class Initialized
INFO - 2016-05-03 21:02:02 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:02:02 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:02:02 --> Utf8 Class Initialized
INFO - 2016-05-03 21:02:02 --> URI Class Initialized
INFO - 2016-05-03 21:02:02 --> Router Class Initialized
INFO - 2016-05-03 21:02:02 --> Output Class Initialized
INFO - 2016-05-03 21:02:02 --> Security Class Initialized
DEBUG - 2016-05-03 21:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:02:02 --> Input Class Initialized
INFO - 2016-05-03 21:02:02 --> Language Class Initialized
INFO - 2016-05-03 21:02:02 --> Loader Class Initialized
INFO - 2016-05-03 21:02:02 --> Helper loaded: url_helper
INFO - 2016-05-03 21:02:02 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:02:02 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:02:02 --> Helper loaded: form_helper
INFO - 2016-05-03 21:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:02:02 --> Form Validation Class Initialized
INFO - 2016-05-03 21:02:02 --> Controller Class Initialized
INFO - 2016-05-03 21:02:02 --> Model Class Initialized
INFO - 2016-05-03 21:02:03 --> Database Driver Class Initialized
INFO - 2016-05-03 21:02:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:02:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:02:03 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:02:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:02:03 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:02:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:02:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:02:03 --> Final output sent to browser
DEBUG - 2016-05-03 21:02:03 --> Total execution time: 0.0776
INFO - 2016-05-03 21:02:07 --> Config Class Initialized
INFO - 2016-05-03 21:02:07 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:02:07 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:02:07 --> Utf8 Class Initialized
INFO - 2016-05-03 21:02:07 --> URI Class Initialized
INFO - 2016-05-03 21:02:07 --> Router Class Initialized
INFO - 2016-05-03 21:02:07 --> Output Class Initialized
INFO - 2016-05-03 21:02:07 --> Security Class Initialized
DEBUG - 2016-05-03 21:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:02:07 --> Input Class Initialized
INFO - 2016-05-03 21:02:07 --> Language Class Initialized
INFO - 2016-05-03 21:02:07 --> Loader Class Initialized
INFO - 2016-05-03 21:02:07 --> Helper loaded: url_helper
INFO - 2016-05-03 21:02:07 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:02:07 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:02:07 --> Helper loaded: form_helper
INFO - 2016-05-03 21:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:02:07 --> Form Validation Class Initialized
INFO - 2016-05-03 21:02:07 --> Controller Class Initialized
INFO - 2016-05-03 21:02:07 --> Model Class Initialized
INFO - 2016-05-03 21:02:07 --> Database Driver Class Initialized
INFO - 2016-05-03 21:02:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:02:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:02:07 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:02:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:02:07 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:02:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:02:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:02:07 --> Final output sent to browser
DEBUG - 2016-05-03 21:02:07 --> Total execution time: 0.0767
INFO - 2016-05-03 21:02:10 --> Config Class Initialized
INFO - 2016-05-03 21:02:10 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:02:10 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:02:10 --> Utf8 Class Initialized
INFO - 2016-05-03 21:02:10 --> URI Class Initialized
INFO - 2016-05-03 21:02:10 --> Router Class Initialized
INFO - 2016-05-03 21:02:10 --> Output Class Initialized
INFO - 2016-05-03 21:02:10 --> Security Class Initialized
DEBUG - 2016-05-03 21:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:02:10 --> Input Class Initialized
INFO - 2016-05-03 21:02:10 --> Language Class Initialized
INFO - 2016-05-03 21:02:10 --> Loader Class Initialized
INFO - 2016-05-03 21:02:10 --> Helper loaded: url_helper
INFO - 2016-05-03 21:02:10 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:02:10 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:02:10 --> Helper loaded: form_helper
INFO - 2016-05-03 21:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:02:10 --> Form Validation Class Initialized
INFO - 2016-05-03 21:02:10 --> Controller Class Initialized
INFO - 2016-05-03 21:02:10 --> Model Class Initialized
INFO - 2016-05-03 21:02:10 --> Database Driver Class Initialized
INFO - 2016-05-03 21:02:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:02:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:02:10 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:02:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:02:10 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:02:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:02:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:02:10 --> Final output sent to browser
DEBUG - 2016-05-03 21:02:10 --> Total execution time: 0.1015
INFO - 2016-05-03 21:02:14 --> Config Class Initialized
INFO - 2016-05-03 21:02:14 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:02:14 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:02:14 --> Utf8 Class Initialized
INFO - 2016-05-03 21:02:14 --> URI Class Initialized
INFO - 2016-05-03 21:02:14 --> Router Class Initialized
INFO - 2016-05-03 21:02:14 --> Output Class Initialized
INFO - 2016-05-03 21:02:14 --> Security Class Initialized
DEBUG - 2016-05-03 21:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:02:14 --> Input Class Initialized
INFO - 2016-05-03 21:02:14 --> Language Class Initialized
INFO - 2016-05-03 21:02:14 --> Loader Class Initialized
INFO - 2016-05-03 21:02:14 --> Helper loaded: url_helper
INFO - 2016-05-03 21:02:14 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:02:14 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:02:14 --> Helper loaded: form_helper
INFO - 2016-05-03 21:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:02:14 --> Form Validation Class Initialized
INFO - 2016-05-03 21:02:14 --> Controller Class Initialized
INFO - 2016-05-03 21:02:14 --> Model Class Initialized
INFO - 2016-05-03 21:02:14 --> Database Driver Class Initialized
INFO - 2016-05-03 21:02:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:02:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:02:14 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:02:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:02:14 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:02:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:02:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:02:14 --> Final output sent to browser
DEBUG - 2016-05-03 21:02:14 --> Total execution time: 0.0964
INFO - 2016-05-03 21:03:26 --> Config Class Initialized
INFO - 2016-05-03 21:03:26 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:03:26 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:03:26 --> Utf8 Class Initialized
INFO - 2016-05-03 21:03:26 --> URI Class Initialized
INFO - 2016-05-03 21:03:26 --> Router Class Initialized
INFO - 2016-05-03 21:03:26 --> Output Class Initialized
INFO - 2016-05-03 21:03:26 --> Security Class Initialized
DEBUG - 2016-05-03 21:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:03:26 --> Input Class Initialized
INFO - 2016-05-03 21:03:26 --> Language Class Initialized
INFO - 2016-05-03 21:03:26 --> Loader Class Initialized
INFO - 2016-05-03 21:03:26 --> Helper loaded: url_helper
INFO - 2016-05-03 21:03:26 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:03:26 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:03:26 --> Helper loaded: form_helper
INFO - 2016-05-03 21:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:03:26 --> Form Validation Class Initialized
INFO - 2016-05-03 21:03:26 --> Controller Class Initialized
INFO - 2016-05-03 21:03:26 --> Model Class Initialized
INFO - 2016-05-03 21:03:26 --> Database Driver Class Initialized
INFO - 2016-05-03 21:03:26 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:03:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:03:26 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:03:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:03:26 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:03:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:03:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:03:26 --> Final output sent to browser
DEBUG - 2016-05-03 21:03:26 --> Total execution time: 0.1238
INFO - 2016-05-03 21:10:43 --> Config Class Initialized
INFO - 2016-05-03 21:10:43 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:10:43 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:10:43 --> Utf8 Class Initialized
INFO - 2016-05-03 21:10:43 --> URI Class Initialized
INFO - 2016-05-03 21:10:43 --> Router Class Initialized
INFO - 2016-05-03 21:10:43 --> Output Class Initialized
INFO - 2016-05-03 21:10:43 --> Security Class Initialized
DEBUG - 2016-05-03 21:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:10:43 --> Input Class Initialized
INFO - 2016-05-03 21:10:43 --> Language Class Initialized
INFO - 2016-05-03 21:10:43 --> Loader Class Initialized
INFO - 2016-05-03 21:10:43 --> Helper loaded: url_helper
INFO - 2016-05-03 21:10:43 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:10:43 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:10:43 --> Helper loaded: form_helper
INFO - 2016-05-03 21:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:10:43 --> Form Validation Class Initialized
INFO - 2016-05-03 21:10:43 --> Controller Class Initialized
INFO - 2016-05-03 21:10:43 --> Model Class Initialized
INFO - 2016-05-03 21:10:43 --> Database Driver Class Initialized
INFO - 2016-05-03 21:10:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:10:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:10:43 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:10:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:10:43 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:10:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:10:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:10:43 --> Final output sent to browser
DEBUG - 2016-05-03 21:10:43 --> Total execution time: 0.2380
INFO - 2016-05-03 21:10:49 --> Config Class Initialized
INFO - 2016-05-03 21:10:49 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:10:49 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:10:49 --> Utf8 Class Initialized
INFO - 2016-05-03 21:10:49 --> URI Class Initialized
INFO - 2016-05-03 21:10:49 --> Router Class Initialized
INFO - 2016-05-03 21:10:49 --> Output Class Initialized
INFO - 2016-05-03 21:10:49 --> Security Class Initialized
DEBUG - 2016-05-03 21:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:10:49 --> Input Class Initialized
INFO - 2016-05-03 21:10:49 --> Language Class Initialized
INFO - 2016-05-03 21:10:49 --> Loader Class Initialized
INFO - 2016-05-03 21:10:49 --> Helper loaded: url_helper
INFO - 2016-05-03 21:10:49 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:10:49 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:10:49 --> Helper loaded: form_helper
INFO - 2016-05-03 21:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:10:49 --> Form Validation Class Initialized
INFO - 2016-05-03 21:10:49 --> Controller Class Initialized
INFO - 2016-05-03 21:10:49 --> Model Class Initialized
INFO - 2016-05-03 21:10:49 --> Database Driver Class Initialized
INFO - 2016-05-03 21:10:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:10:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:10:49 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:10:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:10:49 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 21:10:49 --> Query error: Undeclared variable: buscar - Invalid query: SELECT idProveedor, nombre, nif, correo, estado, telefono FROM proveedor LIMIT buscar, 5; 
INFO - 2016-05-03 21:10:49 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-03 21:11:52 --> Config Class Initialized
INFO - 2016-05-03 21:11:52 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:11:52 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:11:52 --> Utf8 Class Initialized
INFO - 2016-05-03 21:11:52 --> URI Class Initialized
INFO - 2016-05-03 21:11:52 --> Router Class Initialized
INFO - 2016-05-03 21:11:52 --> Output Class Initialized
INFO - 2016-05-03 21:11:52 --> Security Class Initialized
DEBUG - 2016-05-03 21:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:11:53 --> Input Class Initialized
INFO - 2016-05-03 21:11:53 --> Language Class Initialized
INFO - 2016-05-03 21:11:53 --> Loader Class Initialized
INFO - 2016-05-03 21:11:53 --> Helper loaded: url_helper
INFO - 2016-05-03 21:11:53 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:11:53 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:11:53 --> Helper loaded: form_helper
INFO - 2016-05-03 21:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:11:53 --> Form Validation Class Initialized
INFO - 2016-05-03 21:11:53 --> Controller Class Initialized
INFO - 2016-05-03 21:11:53 --> Model Class Initialized
INFO - 2016-05-03 21:11:53 --> Database Driver Class Initialized
INFO - 2016-05-03 21:11:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:11:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:11:53 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:11:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:11:53 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 21:11:53 --> Query error: Undeclared variable: buscar - Invalid query: SELECT idProveedor, nombre, nif, correo, estado, telefono FROM proveedor LIMIT buscar, 5; 
INFO - 2016-05-03 21:11:53 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-03 21:11:53 --> Config Class Initialized
INFO - 2016-05-03 21:11:53 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:11:53 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:11:53 --> Utf8 Class Initialized
INFO - 2016-05-03 21:11:53 --> URI Class Initialized
INFO - 2016-05-03 21:11:53 --> Router Class Initialized
INFO - 2016-05-03 21:11:53 --> Output Class Initialized
INFO - 2016-05-03 21:11:53 --> Security Class Initialized
DEBUG - 2016-05-03 21:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:11:53 --> Input Class Initialized
INFO - 2016-05-03 21:11:53 --> Language Class Initialized
INFO - 2016-05-03 21:11:53 --> Loader Class Initialized
INFO - 2016-05-03 21:11:53 --> Helper loaded: url_helper
INFO - 2016-05-03 21:11:53 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:11:53 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:11:53 --> Helper loaded: form_helper
INFO - 2016-05-03 21:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:11:53 --> Form Validation Class Initialized
INFO - 2016-05-03 21:11:53 --> Controller Class Initialized
INFO - 2016-05-03 21:11:53 --> Model Class Initialized
INFO - 2016-05-03 21:11:53 --> Database Driver Class Initialized
INFO - 2016-05-03 21:11:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:11:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:11:53 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:11:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:11:53 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:11:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:11:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:11:53 --> Final output sent to browser
DEBUG - 2016-05-03 21:11:53 --> Total execution time: 0.1399
INFO - 2016-05-03 21:11:54 --> Config Class Initialized
INFO - 2016-05-03 21:11:54 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:11:54 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:11:54 --> Utf8 Class Initialized
INFO - 2016-05-03 21:11:54 --> URI Class Initialized
INFO - 2016-05-03 21:11:54 --> Router Class Initialized
INFO - 2016-05-03 21:11:54 --> Output Class Initialized
INFO - 2016-05-03 21:11:54 --> Security Class Initialized
DEBUG - 2016-05-03 21:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:11:54 --> Input Class Initialized
INFO - 2016-05-03 21:11:54 --> Language Class Initialized
INFO - 2016-05-03 21:11:54 --> Loader Class Initialized
INFO - 2016-05-03 21:11:54 --> Helper loaded: url_helper
INFO - 2016-05-03 21:11:54 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:11:54 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:11:54 --> Helper loaded: form_helper
INFO - 2016-05-03 21:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:11:54 --> Form Validation Class Initialized
INFO - 2016-05-03 21:11:54 --> Controller Class Initialized
INFO - 2016-05-03 21:11:54 --> Model Class Initialized
INFO - 2016-05-03 21:11:54 --> Database Driver Class Initialized
INFO - 2016-05-03 21:11:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:11:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:11:54 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:11:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:11:54 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:11:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:11:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:11:54 --> Final output sent to browser
DEBUG - 2016-05-03 21:11:54 --> Total execution time: 0.1243
INFO - 2016-05-03 21:11:58 --> Config Class Initialized
INFO - 2016-05-03 21:11:58 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:11:58 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:11:58 --> Utf8 Class Initialized
INFO - 2016-05-03 21:11:58 --> URI Class Initialized
INFO - 2016-05-03 21:11:58 --> Router Class Initialized
INFO - 2016-05-03 21:11:58 --> Output Class Initialized
INFO - 2016-05-03 21:11:58 --> Security Class Initialized
DEBUG - 2016-05-03 21:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:11:58 --> Input Class Initialized
INFO - 2016-05-03 21:11:58 --> Language Class Initialized
INFO - 2016-05-03 21:11:58 --> Loader Class Initialized
INFO - 2016-05-03 21:11:58 --> Helper loaded: url_helper
INFO - 2016-05-03 21:11:58 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:11:58 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:11:58 --> Helper loaded: form_helper
INFO - 2016-05-03 21:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:11:58 --> Form Validation Class Initialized
INFO - 2016-05-03 21:11:58 --> Controller Class Initialized
INFO - 2016-05-03 21:11:58 --> Model Class Initialized
INFO - 2016-05-03 21:11:58 --> Database Driver Class Initialized
INFO - 2016-05-03 21:11:58 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:11:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:11:58 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:11:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:11:58 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:11:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:11:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:11:58 --> Final output sent to browser
DEBUG - 2016-05-03 21:11:58 --> Total execution time: 0.0999
INFO - 2016-05-03 21:12:01 --> Config Class Initialized
INFO - 2016-05-03 21:12:01 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:12:01 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:12:01 --> Utf8 Class Initialized
INFO - 2016-05-03 21:12:01 --> URI Class Initialized
INFO - 2016-05-03 21:12:01 --> Router Class Initialized
INFO - 2016-05-03 21:12:01 --> Output Class Initialized
INFO - 2016-05-03 21:12:01 --> Security Class Initialized
DEBUG - 2016-05-03 21:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:12:01 --> Input Class Initialized
INFO - 2016-05-03 21:12:01 --> Language Class Initialized
INFO - 2016-05-03 21:12:01 --> Loader Class Initialized
INFO - 2016-05-03 21:12:01 --> Helper loaded: url_helper
INFO - 2016-05-03 21:12:01 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:12:01 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:12:01 --> Helper loaded: form_helper
INFO - 2016-05-03 21:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:12:01 --> Form Validation Class Initialized
INFO - 2016-05-03 21:12:01 --> Controller Class Initialized
INFO - 2016-05-03 21:12:01 --> Model Class Initialized
INFO - 2016-05-03 21:12:01 --> Database Driver Class Initialized
INFO - 2016-05-03 21:12:01 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:12:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:12:01 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:12:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:12:01 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:12:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:12:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:12:01 --> Final output sent to browser
DEBUG - 2016-05-03 21:12:01 --> Total execution time: 0.1287
INFO - 2016-05-03 21:12:43 --> Config Class Initialized
INFO - 2016-05-03 21:12:43 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:12:43 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:12:43 --> Utf8 Class Initialized
INFO - 2016-05-03 21:12:43 --> URI Class Initialized
INFO - 2016-05-03 21:12:43 --> Router Class Initialized
INFO - 2016-05-03 21:12:43 --> Output Class Initialized
INFO - 2016-05-03 21:12:43 --> Security Class Initialized
DEBUG - 2016-05-03 21:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:12:43 --> Input Class Initialized
INFO - 2016-05-03 21:12:43 --> Language Class Initialized
INFO - 2016-05-03 21:12:43 --> Loader Class Initialized
INFO - 2016-05-03 21:12:43 --> Helper loaded: url_helper
INFO - 2016-05-03 21:12:43 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:12:43 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:12:43 --> Helper loaded: form_helper
INFO - 2016-05-03 21:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:12:43 --> Form Validation Class Initialized
INFO - 2016-05-03 21:12:43 --> Controller Class Initialized
INFO - 2016-05-03 21:12:43 --> Model Class Initialized
INFO - 2016-05-03 21:12:43 --> Database Driver Class Initialized
INFO - 2016-05-03 21:12:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:12:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:12:43 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:12:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:12:43 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:12:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:12:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:12:43 --> Final output sent to browser
DEBUG - 2016-05-03 21:12:43 --> Total execution time: 0.1077
INFO - 2016-05-03 21:12:51 --> Config Class Initialized
INFO - 2016-05-03 21:12:51 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:12:51 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:12:51 --> Utf8 Class Initialized
INFO - 2016-05-03 21:12:51 --> URI Class Initialized
INFO - 2016-05-03 21:12:51 --> Router Class Initialized
INFO - 2016-05-03 21:12:51 --> Output Class Initialized
INFO - 2016-05-03 21:12:51 --> Security Class Initialized
DEBUG - 2016-05-03 21:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:12:51 --> Input Class Initialized
INFO - 2016-05-03 21:12:51 --> Language Class Initialized
INFO - 2016-05-03 21:12:51 --> Loader Class Initialized
INFO - 2016-05-03 21:12:51 --> Helper loaded: url_helper
INFO - 2016-05-03 21:12:51 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:12:51 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:12:51 --> Helper loaded: form_helper
INFO - 2016-05-03 21:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:12:51 --> Form Validation Class Initialized
INFO - 2016-05-03 21:12:51 --> Controller Class Initialized
INFO - 2016-05-03 21:12:51 --> Model Class Initialized
INFO - 2016-05-03 21:12:51 --> Database Driver Class Initialized
INFO - 2016-05-03 21:12:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:12:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:12:51 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:12:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:12:51 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:12:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:12:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:12:51 --> Final output sent to browser
DEBUG - 2016-05-03 21:12:51 --> Total execution time: 0.1072
INFO - 2016-05-03 21:12:54 --> Config Class Initialized
INFO - 2016-05-03 21:12:54 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:12:54 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:12:54 --> Utf8 Class Initialized
INFO - 2016-05-03 21:12:54 --> URI Class Initialized
INFO - 2016-05-03 21:12:54 --> Router Class Initialized
INFO - 2016-05-03 21:12:54 --> Output Class Initialized
INFO - 2016-05-03 21:12:54 --> Security Class Initialized
DEBUG - 2016-05-03 21:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:12:54 --> Input Class Initialized
INFO - 2016-05-03 21:12:54 --> Language Class Initialized
INFO - 2016-05-03 21:12:54 --> Loader Class Initialized
INFO - 2016-05-03 21:12:54 --> Helper loaded: url_helper
INFO - 2016-05-03 21:12:54 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:12:54 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:12:54 --> Helper loaded: form_helper
INFO - 2016-05-03 21:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:12:54 --> Form Validation Class Initialized
INFO - 2016-05-03 21:12:54 --> Controller Class Initialized
INFO - 2016-05-03 21:12:54 --> Model Class Initialized
INFO - 2016-05-03 21:12:54 --> Database Driver Class Initialized
INFO - 2016-05-03 21:12:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:12:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:12:54 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:12:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:12:54 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:12:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:12:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:12:54 --> Final output sent to browser
DEBUG - 2016-05-03 21:12:54 --> Total execution time: 0.0980
INFO - 2016-05-03 21:17:08 --> Config Class Initialized
INFO - 2016-05-03 21:17:08 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:17:08 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:17:08 --> Utf8 Class Initialized
INFO - 2016-05-03 21:17:08 --> URI Class Initialized
INFO - 2016-05-03 21:17:08 --> Router Class Initialized
INFO - 2016-05-03 21:17:08 --> Output Class Initialized
INFO - 2016-05-03 21:17:08 --> Security Class Initialized
DEBUG - 2016-05-03 21:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:17:08 --> Input Class Initialized
INFO - 2016-05-03 21:17:08 --> Language Class Initialized
INFO - 2016-05-03 21:17:08 --> Loader Class Initialized
INFO - 2016-05-03 21:17:08 --> Helper loaded: url_helper
INFO - 2016-05-03 21:17:08 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:17:08 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:17:08 --> Helper loaded: form_helper
INFO - 2016-05-03 21:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:17:08 --> Form Validation Class Initialized
INFO - 2016-05-03 21:17:08 --> Controller Class Initialized
INFO - 2016-05-03 21:17:08 --> Model Class Initialized
INFO - 2016-05-03 21:17:08 --> Database Driver Class Initialized
INFO - 2016-05-03 21:17:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:17:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:17:08 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:17:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:17:08 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:17:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:17:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:17:08 --> Final output sent to browser
DEBUG - 2016-05-03 21:17:08 --> Total execution time: 0.1669
INFO - 2016-05-03 21:17:12 --> Config Class Initialized
INFO - 2016-05-03 21:17:12 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:17:12 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:17:12 --> Utf8 Class Initialized
INFO - 2016-05-03 21:17:12 --> URI Class Initialized
INFO - 2016-05-03 21:17:13 --> Router Class Initialized
INFO - 2016-05-03 21:17:13 --> Output Class Initialized
INFO - 2016-05-03 21:17:13 --> Security Class Initialized
DEBUG - 2016-05-03 21:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:17:13 --> Input Class Initialized
INFO - 2016-05-03 21:17:13 --> Language Class Initialized
INFO - 2016-05-03 21:17:13 --> Loader Class Initialized
INFO - 2016-05-03 21:17:13 --> Helper loaded: url_helper
INFO - 2016-05-03 21:17:13 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:17:13 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:17:13 --> Helper loaded: form_helper
INFO - 2016-05-03 21:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:17:13 --> Form Validation Class Initialized
INFO - 2016-05-03 21:17:13 --> Controller Class Initialized
INFO - 2016-05-03 21:17:13 --> Model Class Initialized
INFO - 2016-05-03 21:17:13 --> Database Driver Class Initialized
INFO - 2016-05-03 21:17:13 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:17:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:17:13 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:17:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:17:13 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:17:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:17:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:17:13 --> Final output sent to browser
DEBUG - 2016-05-03 21:17:13 --> Total execution time: 0.0830
INFO - 2016-05-03 21:17:42 --> Config Class Initialized
INFO - 2016-05-03 21:17:42 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:17:42 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:17:42 --> Utf8 Class Initialized
INFO - 2016-05-03 21:17:42 --> URI Class Initialized
INFO - 2016-05-03 21:17:42 --> Router Class Initialized
INFO - 2016-05-03 21:17:42 --> Output Class Initialized
INFO - 2016-05-03 21:17:42 --> Security Class Initialized
DEBUG - 2016-05-03 21:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:17:42 --> Input Class Initialized
INFO - 2016-05-03 21:17:42 --> Language Class Initialized
INFO - 2016-05-03 21:17:42 --> Loader Class Initialized
INFO - 2016-05-03 21:17:42 --> Helper loaded: url_helper
INFO - 2016-05-03 21:17:42 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:17:42 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:17:42 --> Helper loaded: form_helper
INFO - 2016-05-03 21:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:17:42 --> Form Validation Class Initialized
INFO - 2016-05-03 21:17:42 --> Controller Class Initialized
INFO - 2016-05-03 21:17:42 --> Model Class Initialized
INFO - 2016-05-03 21:17:42 --> Database Driver Class Initialized
INFO - 2016-05-03 21:17:42 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:17:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:17:42 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:17:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:17:42 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:17:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:17:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:17:42 --> Final output sent to browser
DEBUG - 2016-05-03 21:17:42 --> Total execution time: 0.0778
INFO - 2016-05-03 21:17:45 --> Config Class Initialized
INFO - 2016-05-03 21:17:46 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:17:46 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:17:46 --> Utf8 Class Initialized
INFO - 2016-05-03 21:17:46 --> URI Class Initialized
INFO - 2016-05-03 21:17:46 --> Router Class Initialized
INFO - 2016-05-03 21:17:46 --> Output Class Initialized
INFO - 2016-05-03 21:17:46 --> Security Class Initialized
DEBUG - 2016-05-03 21:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:17:46 --> Input Class Initialized
INFO - 2016-05-03 21:17:46 --> Language Class Initialized
INFO - 2016-05-03 21:17:46 --> Loader Class Initialized
INFO - 2016-05-03 21:17:46 --> Helper loaded: url_helper
INFO - 2016-05-03 21:17:46 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:17:46 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:17:46 --> Helper loaded: form_helper
INFO - 2016-05-03 21:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:17:46 --> Form Validation Class Initialized
INFO - 2016-05-03 21:17:46 --> Controller Class Initialized
INFO - 2016-05-03 21:17:46 --> Model Class Initialized
INFO - 2016-05-03 21:17:46 --> Database Driver Class Initialized
INFO - 2016-05-03 21:17:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:17:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:17:46 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:17:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:17:46 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:17:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:17:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:17:46 --> Final output sent to browser
DEBUG - 2016-05-03 21:17:46 --> Total execution time: 0.0967
INFO - 2016-05-03 21:17:47 --> Config Class Initialized
INFO - 2016-05-03 21:17:47 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:17:47 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:17:47 --> Utf8 Class Initialized
INFO - 2016-05-03 21:17:47 --> URI Class Initialized
INFO - 2016-05-03 21:17:47 --> Router Class Initialized
INFO - 2016-05-03 21:17:47 --> Output Class Initialized
INFO - 2016-05-03 21:17:47 --> Security Class Initialized
DEBUG - 2016-05-03 21:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:17:47 --> Input Class Initialized
INFO - 2016-05-03 21:17:47 --> Language Class Initialized
INFO - 2016-05-03 21:17:47 --> Loader Class Initialized
INFO - 2016-05-03 21:17:47 --> Helper loaded: url_helper
INFO - 2016-05-03 21:17:47 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:17:47 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:17:47 --> Helper loaded: form_helper
INFO - 2016-05-03 21:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:17:47 --> Form Validation Class Initialized
INFO - 2016-05-03 21:17:47 --> Controller Class Initialized
INFO - 2016-05-03 21:17:47 --> Model Class Initialized
INFO - 2016-05-03 21:17:47 --> Database Driver Class Initialized
INFO - 2016-05-03 21:17:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:17:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:17:47 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:17:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:17:47 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:17:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:17:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:17:47 --> Final output sent to browser
DEBUG - 2016-05-03 21:17:47 --> Total execution time: 0.1095
INFO - 2016-05-03 21:19:35 --> Config Class Initialized
INFO - 2016-05-03 21:19:35 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:19:35 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:19:35 --> Utf8 Class Initialized
INFO - 2016-05-03 21:19:35 --> URI Class Initialized
INFO - 2016-05-03 21:19:35 --> Router Class Initialized
INFO - 2016-05-03 21:19:35 --> Output Class Initialized
INFO - 2016-05-03 21:19:35 --> Security Class Initialized
DEBUG - 2016-05-03 21:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:19:35 --> Input Class Initialized
INFO - 2016-05-03 21:19:35 --> Language Class Initialized
INFO - 2016-05-03 21:19:35 --> Loader Class Initialized
INFO - 2016-05-03 21:19:35 --> Helper loaded: url_helper
INFO - 2016-05-03 21:19:35 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:19:35 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:19:35 --> Helper loaded: form_helper
INFO - 2016-05-03 21:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:19:35 --> Form Validation Class Initialized
INFO - 2016-05-03 21:19:35 --> Controller Class Initialized
INFO - 2016-05-03 21:19:35 --> Model Class Initialized
INFO - 2016-05-03 21:19:35 --> Database Driver Class Initialized
INFO - 2016-05-03 21:19:35 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:19:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:19:35 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:19:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:19:35 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 21:19:35 --> Severity: Warning --> Missing argument 1 for Proveedores::getConfigPagBuscar(), called in C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Proveedores.php on line 46 and defined C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Proveedores.php 59
ERROR - 2016-05-03 21:19:35 --> Severity: Notice --> Undefined variable: campo C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Proveedores.php 61
INFO - 2016-05-03 21:19:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:19:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:19:35 --> Final output sent to browser
DEBUG - 2016-05-03 21:19:35 --> Total execution time: 0.1255
INFO - 2016-05-03 21:19:45 --> Config Class Initialized
INFO - 2016-05-03 21:19:45 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:19:45 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:19:45 --> Utf8 Class Initialized
INFO - 2016-05-03 21:19:45 --> URI Class Initialized
INFO - 2016-05-03 21:19:45 --> Router Class Initialized
INFO - 2016-05-03 21:19:45 --> Output Class Initialized
INFO - 2016-05-03 21:19:45 --> Security Class Initialized
DEBUG - 2016-05-03 21:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:19:45 --> Input Class Initialized
INFO - 2016-05-03 21:19:45 --> Language Class Initialized
INFO - 2016-05-03 21:19:45 --> Loader Class Initialized
INFO - 2016-05-03 21:19:45 --> Helper loaded: url_helper
INFO - 2016-05-03 21:19:45 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:19:45 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:19:45 --> Helper loaded: form_helper
INFO - 2016-05-03 21:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:19:45 --> Form Validation Class Initialized
INFO - 2016-05-03 21:19:45 --> Controller Class Initialized
INFO - 2016-05-03 21:19:45 --> Model Class Initialized
INFO - 2016-05-03 21:19:45 --> Database Driver Class Initialized
INFO - 2016-05-03 21:19:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:19:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:19:45 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:19:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:19:45 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:19:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:19:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:19:45 --> Final output sent to browser
DEBUG - 2016-05-03 21:19:45 --> Total execution time: 0.1455
INFO - 2016-05-03 21:20:20 --> Config Class Initialized
INFO - 2016-05-03 21:20:20 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:20:20 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:20:20 --> Utf8 Class Initialized
INFO - 2016-05-03 21:20:20 --> URI Class Initialized
INFO - 2016-05-03 21:20:20 --> Router Class Initialized
INFO - 2016-05-03 21:20:20 --> Output Class Initialized
INFO - 2016-05-03 21:20:20 --> Security Class Initialized
DEBUG - 2016-05-03 21:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:20:20 --> Input Class Initialized
INFO - 2016-05-03 21:20:20 --> Language Class Initialized
INFO - 2016-05-03 21:20:20 --> Loader Class Initialized
INFO - 2016-05-03 21:20:20 --> Helper loaded: url_helper
INFO - 2016-05-03 21:20:20 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:20:20 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:20:20 --> Helper loaded: form_helper
INFO - 2016-05-03 21:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:20:20 --> Form Validation Class Initialized
INFO - 2016-05-03 21:20:20 --> Controller Class Initialized
INFO - 2016-05-03 21:20:20 --> Model Class Initialized
INFO - 2016-05-03 21:20:20 --> Database Driver Class Initialized
INFO - 2016-05-03 21:20:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:20:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:20:20 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:20:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:20:20 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:20:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:20:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:20:20 --> Final output sent to browser
DEBUG - 2016-05-03 21:20:20 --> Total execution time: 0.0933
INFO - 2016-05-03 21:20:21 --> Config Class Initialized
INFO - 2016-05-03 21:20:21 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:20:21 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:20:21 --> Utf8 Class Initialized
INFO - 2016-05-03 21:20:21 --> URI Class Initialized
INFO - 2016-05-03 21:20:21 --> Router Class Initialized
INFO - 2016-05-03 21:20:21 --> Output Class Initialized
INFO - 2016-05-03 21:20:21 --> Security Class Initialized
DEBUG - 2016-05-03 21:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:20:21 --> Input Class Initialized
INFO - 2016-05-03 21:20:21 --> Language Class Initialized
INFO - 2016-05-03 21:20:21 --> Loader Class Initialized
INFO - 2016-05-03 21:20:21 --> Helper loaded: url_helper
INFO - 2016-05-03 21:20:21 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:20:21 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:20:21 --> Helper loaded: form_helper
INFO - 2016-05-03 21:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:20:21 --> Form Validation Class Initialized
INFO - 2016-05-03 21:20:21 --> Controller Class Initialized
INFO - 2016-05-03 21:20:21 --> Model Class Initialized
INFO - 2016-05-03 21:20:21 --> Database Driver Class Initialized
INFO - 2016-05-03 21:20:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:20:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:20:21 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:20:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:20:21 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:20:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:20:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:20:21 --> Final output sent to browser
DEBUG - 2016-05-03 21:20:21 --> Total execution time: 0.1329
INFO - 2016-05-03 21:20:23 --> Config Class Initialized
INFO - 2016-05-03 21:20:23 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:20:23 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:20:23 --> Utf8 Class Initialized
INFO - 2016-05-03 21:20:23 --> URI Class Initialized
INFO - 2016-05-03 21:20:23 --> Router Class Initialized
INFO - 2016-05-03 21:20:23 --> Output Class Initialized
INFO - 2016-05-03 21:20:23 --> Security Class Initialized
DEBUG - 2016-05-03 21:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:20:23 --> Input Class Initialized
INFO - 2016-05-03 21:20:23 --> Language Class Initialized
INFO - 2016-05-03 21:20:23 --> Loader Class Initialized
INFO - 2016-05-03 21:20:23 --> Helper loaded: url_helper
INFO - 2016-05-03 21:20:23 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:20:23 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:20:23 --> Helper loaded: form_helper
INFO - 2016-05-03 21:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:20:23 --> Form Validation Class Initialized
INFO - 2016-05-03 21:20:23 --> Controller Class Initialized
INFO - 2016-05-03 21:20:23 --> Model Class Initialized
INFO - 2016-05-03 21:20:23 --> Database Driver Class Initialized
INFO - 2016-05-03 21:20:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:20:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:20:23 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:20:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:20:23 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:20:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:20:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:20:23 --> Final output sent to browser
DEBUG - 2016-05-03 21:20:23 --> Total execution time: 0.0970
INFO - 2016-05-03 21:20:31 --> Config Class Initialized
INFO - 2016-05-03 21:20:31 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:20:31 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:20:31 --> Utf8 Class Initialized
INFO - 2016-05-03 21:20:31 --> URI Class Initialized
INFO - 2016-05-03 21:20:31 --> Router Class Initialized
INFO - 2016-05-03 21:20:31 --> Output Class Initialized
INFO - 2016-05-03 21:20:31 --> Security Class Initialized
DEBUG - 2016-05-03 21:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:20:31 --> Input Class Initialized
INFO - 2016-05-03 21:20:31 --> Language Class Initialized
INFO - 2016-05-03 21:20:31 --> Loader Class Initialized
INFO - 2016-05-03 21:20:31 --> Helper loaded: url_helper
INFO - 2016-05-03 21:20:31 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:20:31 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:20:31 --> Helper loaded: form_helper
INFO - 2016-05-03 21:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:20:31 --> Form Validation Class Initialized
INFO - 2016-05-03 21:20:31 --> Controller Class Initialized
INFO - 2016-05-03 21:20:31 --> Model Class Initialized
INFO - 2016-05-03 21:20:31 --> Database Driver Class Initialized
INFO - 2016-05-03 21:20:31 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:20:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:20:31 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:20:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:20:31 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:20:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:20:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:20:31 --> Final output sent to browser
DEBUG - 2016-05-03 21:20:31 --> Total execution time: 0.0757
INFO - 2016-05-03 21:20:36 --> Config Class Initialized
INFO - 2016-05-03 21:20:36 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:20:36 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:20:36 --> Utf8 Class Initialized
INFO - 2016-05-03 21:20:36 --> URI Class Initialized
INFO - 2016-05-03 21:20:36 --> Router Class Initialized
INFO - 2016-05-03 21:20:36 --> Output Class Initialized
INFO - 2016-05-03 21:20:36 --> Security Class Initialized
DEBUG - 2016-05-03 21:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:20:36 --> Input Class Initialized
INFO - 2016-05-03 21:20:36 --> Language Class Initialized
INFO - 2016-05-03 21:20:36 --> Loader Class Initialized
INFO - 2016-05-03 21:20:36 --> Helper loaded: url_helper
INFO - 2016-05-03 21:20:36 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:20:36 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:20:36 --> Helper loaded: form_helper
INFO - 2016-05-03 21:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:20:36 --> Form Validation Class Initialized
INFO - 2016-05-03 21:20:36 --> Controller Class Initialized
INFO - 2016-05-03 21:20:36 --> Model Class Initialized
INFO - 2016-05-03 21:20:36 --> Database Driver Class Initialized
INFO - 2016-05-03 21:20:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:20:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:20:36 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:20:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:20:36 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:20:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:20:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:20:36 --> Final output sent to browser
DEBUG - 2016-05-03 21:20:36 --> Total execution time: 0.0848
INFO - 2016-05-03 21:20:40 --> Config Class Initialized
INFO - 2016-05-03 21:20:40 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:20:40 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:20:40 --> Utf8 Class Initialized
INFO - 2016-05-03 21:20:40 --> URI Class Initialized
INFO - 2016-05-03 21:20:40 --> Router Class Initialized
INFO - 2016-05-03 21:20:40 --> Output Class Initialized
INFO - 2016-05-03 21:20:40 --> Security Class Initialized
DEBUG - 2016-05-03 21:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:20:40 --> Input Class Initialized
INFO - 2016-05-03 21:20:40 --> Language Class Initialized
INFO - 2016-05-03 21:20:40 --> Loader Class Initialized
INFO - 2016-05-03 21:20:40 --> Helper loaded: url_helper
INFO - 2016-05-03 21:20:40 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:20:40 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:20:40 --> Helper loaded: form_helper
INFO - 2016-05-03 21:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:20:40 --> Form Validation Class Initialized
INFO - 2016-05-03 21:20:40 --> Controller Class Initialized
INFO - 2016-05-03 21:20:40 --> Model Class Initialized
INFO - 2016-05-03 21:20:40 --> Database Driver Class Initialized
INFO - 2016-05-03 21:20:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:20:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:20:40 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:20:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:20:40 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:20:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:20:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:20:40 --> Final output sent to browser
DEBUG - 2016-05-03 21:20:40 --> Total execution time: 0.0911
INFO - 2016-05-03 21:21:53 --> Config Class Initialized
INFO - 2016-05-03 21:21:53 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:21:53 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:21:53 --> Utf8 Class Initialized
INFO - 2016-05-03 21:21:53 --> URI Class Initialized
INFO - 2016-05-03 21:21:53 --> Router Class Initialized
INFO - 2016-05-03 21:21:53 --> Output Class Initialized
INFO - 2016-05-03 21:21:53 --> Security Class Initialized
DEBUG - 2016-05-03 21:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:21:53 --> Input Class Initialized
INFO - 2016-05-03 21:21:53 --> Language Class Initialized
INFO - 2016-05-03 21:21:53 --> Loader Class Initialized
INFO - 2016-05-03 21:21:53 --> Helper loaded: url_helper
INFO - 2016-05-03 21:21:53 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:21:53 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:21:53 --> Helper loaded: form_helper
INFO - 2016-05-03 21:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:21:53 --> Form Validation Class Initialized
INFO - 2016-05-03 21:21:53 --> Controller Class Initialized
INFO - 2016-05-03 21:21:53 --> Model Class Initialized
INFO - 2016-05-03 21:21:53 --> Database Driver Class Initialized
INFO - 2016-05-03 21:21:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:21:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:21:53 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:21:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:21:54 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:21:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:21:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:21:54 --> Final output sent to browser
DEBUG - 2016-05-03 21:21:54 --> Total execution time: 0.1726
INFO - 2016-05-03 21:21:55 --> Config Class Initialized
INFO - 2016-05-03 21:21:55 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:21:55 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:21:55 --> Utf8 Class Initialized
INFO - 2016-05-03 21:21:55 --> URI Class Initialized
INFO - 2016-05-03 21:21:55 --> Router Class Initialized
INFO - 2016-05-03 21:21:55 --> Output Class Initialized
INFO - 2016-05-03 21:21:55 --> Security Class Initialized
DEBUG - 2016-05-03 21:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:21:55 --> Input Class Initialized
INFO - 2016-05-03 21:21:55 --> Language Class Initialized
INFO - 2016-05-03 21:21:55 --> Loader Class Initialized
INFO - 2016-05-03 21:21:55 --> Helper loaded: url_helper
INFO - 2016-05-03 21:21:55 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:21:55 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:21:55 --> Helper loaded: form_helper
INFO - 2016-05-03 21:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:21:55 --> Form Validation Class Initialized
INFO - 2016-05-03 21:21:55 --> Controller Class Initialized
INFO - 2016-05-03 21:21:55 --> Model Class Initialized
INFO - 2016-05-03 21:21:55 --> Database Driver Class Initialized
INFO - 2016-05-03 21:21:55 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:21:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:21:55 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:21:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:21:55 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:21:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:21:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:21:55 --> Final output sent to browser
DEBUG - 2016-05-03 21:21:55 --> Total execution time: 0.1022
INFO - 2016-05-03 21:22:00 --> Config Class Initialized
INFO - 2016-05-03 21:22:00 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:22:00 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:22:00 --> Utf8 Class Initialized
INFO - 2016-05-03 21:22:00 --> URI Class Initialized
INFO - 2016-05-03 21:22:00 --> Router Class Initialized
INFO - 2016-05-03 21:22:00 --> Output Class Initialized
INFO - 2016-05-03 21:22:00 --> Security Class Initialized
DEBUG - 2016-05-03 21:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:22:00 --> Input Class Initialized
INFO - 2016-05-03 21:22:00 --> Language Class Initialized
INFO - 2016-05-03 21:22:00 --> Loader Class Initialized
INFO - 2016-05-03 21:22:00 --> Helper loaded: url_helper
INFO - 2016-05-03 21:22:00 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:22:00 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:22:00 --> Helper loaded: form_helper
INFO - 2016-05-03 21:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:22:00 --> Form Validation Class Initialized
INFO - 2016-05-03 21:22:00 --> Controller Class Initialized
INFO - 2016-05-03 21:22:00 --> Model Class Initialized
INFO - 2016-05-03 21:22:00 --> Database Driver Class Initialized
INFO - 2016-05-03 21:22:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:22:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:22:00 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:22:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:22:00 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:22:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:22:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:22:00 --> Final output sent to browser
DEBUG - 2016-05-03 21:22:00 --> Total execution time: 0.0751
INFO - 2016-05-03 21:22:05 --> Config Class Initialized
INFO - 2016-05-03 21:22:05 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:22:05 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:22:05 --> Utf8 Class Initialized
INFO - 2016-05-03 21:22:05 --> URI Class Initialized
INFO - 2016-05-03 21:22:05 --> Router Class Initialized
INFO - 2016-05-03 21:22:05 --> Output Class Initialized
INFO - 2016-05-03 21:22:05 --> Security Class Initialized
DEBUG - 2016-05-03 21:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:22:05 --> Input Class Initialized
INFO - 2016-05-03 21:22:05 --> Language Class Initialized
INFO - 2016-05-03 21:22:05 --> Loader Class Initialized
INFO - 2016-05-03 21:22:05 --> Helper loaded: url_helper
INFO - 2016-05-03 21:22:05 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:22:05 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:22:05 --> Helper loaded: form_helper
INFO - 2016-05-03 21:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:22:05 --> Form Validation Class Initialized
INFO - 2016-05-03 21:22:05 --> Controller Class Initialized
INFO - 2016-05-03 21:22:05 --> Model Class Initialized
INFO - 2016-05-03 21:22:05 --> Database Driver Class Initialized
INFO - 2016-05-03 21:22:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:22:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:22:05 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:22:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:22:05 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:22:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:22:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:22:05 --> Final output sent to browser
DEBUG - 2016-05-03 21:22:05 --> Total execution time: 0.0964
INFO - 2016-05-03 21:22:59 --> Config Class Initialized
INFO - 2016-05-03 21:22:59 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:22:59 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:22:59 --> Utf8 Class Initialized
INFO - 2016-05-03 21:22:59 --> URI Class Initialized
INFO - 2016-05-03 21:22:59 --> Router Class Initialized
INFO - 2016-05-03 21:22:59 --> Output Class Initialized
INFO - 2016-05-03 21:22:59 --> Security Class Initialized
DEBUG - 2016-05-03 21:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:22:59 --> Input Class Initialized
INFO - 2016-05-03 21:22:59 --> Language Class Initialized
INFO - 2016-05-03 21:22:59 --> Loader Class Initialized
INFO - 2016-05-03 21:22:59 --> Helper loaded: url_helper
INFO - 2016-05-03 21:22:59 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:22:59 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:22:59 --> Helper loaded: form_helper
INFO - 2016-05-03 21:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:22:59 --> Form Validation Class Initialized
INFO - 2016-05-03 21:22:59 --> Controller Class Initialized
INFO - 2016-05-03 21:22:59 --> Model Class Initialized
INFO - 2016-05-03 21:22:59 --> Database Driver Class Initialized
INFO - 2016-05-03 21:22:59 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:22:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:22:59 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:22:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:22:59 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:22:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:22:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:22:59 --> Final output sent to browser
DEBUG - 2016-05-03 21:22:59 --> Total execution time: 0.0789
INFO - 2016-05-03 21:23:49 --> Config Class Initialized
INFO - 2016-05-03 21:23:49 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:23:49 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:23:49 --> Utf8 Class Initialized
INFO - 2016-05-03 21:23:49 --> URI Class Initialized
INFO - 2016-05-03 21:23:49 --> Router Class Initialized
INFO - 2016-05-03 21:23:49 --> Output Class Initialized
INFO - 2016-05-03 21:23:49 --> Security Class Initialized
DEBUG - 2016-05-03 21:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:23:49 --> Input Class Initialized
INFO - 2016-05-03 21:23:49 --> Language Class Initialized
INFO - 2016-05-03 21:23:49 --> Loader Class Initialized
INFO - 2016-05-03 21:23:49 --> Helper loaded: url_helper
INFO - 2016-05-03 21:23:49 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:23:49 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:23:49 --> Helper loaded: form_helper
INFO - 2016-05-03 21:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:23:49 --> Form Validation Class Initialized
INFO - 2016-05-03 21:23:49 --> Controller Class Initialized
INFO - 2016-05-03 21:23:49 --> Model Class Initialized
INFO - 2016-05-03 21:23:49 --> Database Driver Class Initialized
INFO - 2016-05-03 21:23:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:23:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:23:49 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:23:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:23:49 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:23:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:23:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:23:49 --> Final output sent to browser
DEBUG - 2016-05-03 21:23:49 --> Total execution time: 0.0857
INFO - 2016-05-03 21:24:55 --> Config Class Initialized
INFO - 2016-05-03 21:24:55 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:24:55 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:24:55 --> Utf8 Class Initialized
INFO - 2016-05-03 21:24:55 --> URI Class Initialized
INFO - 2016-05-03 21:24:55 --> Router Class Initialized
INFO - 2016-05-03 21:24:55 --> Output Class Initialized
INFO - 2016-05-03 21:24:55 --> Security Class Initialized
DEBUG - 2016-05-03 21:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:24:55 --> Input Class Initialized
INFO - 2016-05-03 21:24:55 --> Language Class Initialized
INFO - 2016-05-03 21:24:55 --> Loader Class Initialized
INFO - 2016-05-03 21:24:55 --> Helper loaded: url_helper
INFO - 2016-05-03 21:24:55 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:24:55 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:24:55 --> Helper loaded: form_helper
INFO - 2016-05-03 21:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:24:55 --> Form Validation Class Initialized
INFO - 2016-05-03 21:24:55 --> Controller Class Initialized
INFO - 2016-05-03 21:24:55 --> Model Class Initialized
INFO - 2016-05-03 21:24:55 --> Database Driver Class Initialized
INFO - 2016-05-03 21:24:55 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:24:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:24:55 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:24:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:24:55 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:24:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:24:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:24:55 --> Final output sent to browser
DEBUG - 2016-05-03 21:24:55 --> Total execution time: 0.0837
INFO - 2016-05-03 21:25:10 --> Config Class Initialized
INFO - 2016-05-03 21:25:10 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:25:10 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:25:10 --> Utf8 Class Initialized
INFO - 2016-05-03 21:25:10 --> URI Class Initialized
INFO - 2016-05-03 21:25:10 --> Router Class Initialized
INFO - 2016-05-03 21:25:10 --> Output Class Initialized
INFO - 2016-05-03 21:25:10 --> Security Class Initialized
DEBUG - 2016-05-03 21:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:25:10 --> Input Class Initialized
INFO - 2016-05-03 21:25:10 --> Language Class Initialized
INFO - 2016-05-03 21:25:10 --> Loader Class Initialized
INFO - 2016-05-03 21:25:10 --> Helper loaded: url_helper
INFO - 2016-05-03 21:25:10 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:25:10 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:25:10 --> Helper loaded: form_helper
INFO - 2016-05-03 21:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:25:10 --> Form Validation Class Initialized
INFO - 2016-05-03 21:25:10 --> Controller Class Initialized
INFO - 2016-05-03 21:25:10 --> Model Class Initialized
INFO - 2016-05-03 21:25:10 --> Database Driver Class Initialized
INFO - 2016-05-03 21:25:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:25:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:25:10 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:25:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:25:10 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:25:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:25:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:25:10 --> Final output sent to browser
DEBUG - 2016-05-03 21:25:10 --> Total execution time: 0.0886
INFO - 2016-05-03 21:25:22 --> Config Class Initialized
INFO - 2016-05-03 21:25:22 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:25:22 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:25:22 --> Utf8 Class Initialized
INFO - 2016-05-03 21:25:22 --> URI Class Initialized
INFO - 2016-05-03 21:25:22 --> Router Class Initialized
INFO - 2016-05-03 21:25:22 --> Output Class Initialized
INFO - 2016-05-03 21:25:22 --> Security Class Initialized
DEBUG - 2016-05-03 21:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:25:22 --> Input Class Initialized
INFO - 2016-05-03 21:25:22 --> Language Class Initialized
INFO - 2016-05-03 21:25:22 --> Loader Class Initialized
INFO - 2016-05-03 21:25:22 --> Helper loaded: url_helper
INFO - 2016-05-03 21:25:22 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:25:22 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:25:22 --> Helper loaded: form_helper
INFO - 2016-05-03 21:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:25:22 --> Form Validation Class Initialized
INFO - 2016-05-03 21:25:22 --> Controller Class Initialized
INFO - 2016-05-03 21:25:22 --> Model Class Initialized
INFO - 2016-05-03 21:25:22 --> Database Driver Class Initialized
INFO - 2016-05-03 21:25:22 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:25:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:25:22 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:25:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:25:22 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:25:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:25:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:25:22 --> Final output sent to browser
DEBUG - 2016-05-03 21:25:22 --> Total execution time: 0.1135
INFO - 2016-05-03 21:25:26 --> Config Class Initialized
INFO - 2016-05-03 21:25:26 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:25:26 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:25:26 --> Utf8 Class Initialized
INFO - 2016-05-03 21:25:26 --> URI Class Initialized
INFO - 2016-05-03 21:25:26 --> Router Class Initialized
INFO - 2016-05-03 21:25:26 --> Output Class Initialized
INFO - 2016-05-03 21:25:26 --> Security Class Initialized
DEBUG - 2016-05-03 21:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:25:26 --> Input Class Initialized
INFO - 2016-05-03 21:25:26 --> Language Class Initialized
INFO - 2016-05-03 21:25:26 --> Loader Class Initialized
INFO - 2016-05-03 21:25:26 --> Helper loaded: url_helper
INFO - 2016-05-03 21:25:26 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:25:26 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:25:26 --> Helper loaded: form_helper
INFO - 2016-05-03 21:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:25:26 --> Form Validation Class Initialized
INFO - 2016-05-03 21:25:26 --> Controller Class Initialized
INFO - 2016-05-03 21:25:26 --> Model Class Initialized
INFO - 2016-05-03 21:25:26 --> Database Driver Class Initialized
INFO - 2016-05-03 21:25:26 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:25:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:25:26 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:25:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:25:26 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:25:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:25:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:25:26 --> Final output sent to browser
DEBUG - 2016-05-03 21:25:26 --> Total execution time: 0.0853
INFO - 2016-05-03 21:25:31 --> Config Class Initialized
INFO - 2016-05-03 21:25:31 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:25:31 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:25:31 --> Utf8 Class Initialized
INFO - 2016-05-03 21:25:31 --> URI Class Initialized
INFO - 2016-05-03 21:25:31 --> Router Class Initialized
INFO - 2016-05-03 21:25:31 --> Output Class Initialized
INFO - 2016-05-03 21:25:31 --> Security Class Initialized
DEBUG - 2016-05-03 21:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:25:31 --> Input Class Initialized
INFO - 2016-05-03 21:25:31 --> Language Class Initialized
INFO - 2016-05-03 21:25:31 --> Loader Class Initialized
INFO - 2016-05-03 21:25:31 --> Helper loaded: url_helper
INFO - 2016-05-03 21:25:31 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:25:31 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:25:31 --> Helper loaded: form_helper
INFO - 2016-05-03 21:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:25:31 --> Form Validation Class Initialized
INFO - 2016-05-03 21:25:31 --> Controller Class Initialized
INFO - 2016-05-03 21:25:31 --> Model Class Initialized
INFO - 2016-05-03 21:25:32 --> Database Driver Class Initialized
INFO - 2016-05-03 21:25:32 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:25:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:25:32 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:25:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:25:32 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:25:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:25:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:25:32 --> Final output sent to browser
DEBUG - 2016-05-03 21:25:32 --> Total execution time: 0.1021
INFO - 2016-05-03 21:26:02 --> Config Class Initialized
INFO - 2016-05-03 21:26:02 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:26:02 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:26:02 --> Utf8 Class Initialized
INFO - 2016-05-03 21:26:02 --> URI Class Initialized
INFO - 2016-05-03 21:26:02 --> Router Class Initialized
INFO - 2016-05-03 21:26:02 --> Output Class Initialized
INFO - 2016-05-03 21:26:02 --> Security Class Initialized
DEBUG - 2016-05-03 21:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:26:02 --> Input Class Initialized
INFO - 2016-05-03 21:26:02 --> Language Class Initialized
INFO - 2016-05-03 21:26:02 --> Loader Class Initialized
INFO - 2016-05-03 21:26:02 --> Helper loaded: url_helper
INFO - 2016-05-03 21:26:02 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:26:02 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:26:02 --> Helper loaded: form_helper
INFO - 2016-05-03 21:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:26:02 --> Form Validation Class Initialized
INFO - 2016-05-03 21:26:02 --> Controller Class Initialized
INFO - 2016-05-03 21:26:02 --> Model Class Initialized
INFO - 2016-05-03 21:26:03 --> Database Driver Class Initialized
INFO - 2016-05-03 21:26:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:26:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:26:03 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:26:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:26:03 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:26:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:26:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:26:03 --> Final output sent to browser
DEBUG - 2016-05-03 21:26:03 --> Total execution time: 0.1204
INFO - 2016-05-03 21:26:05 --> Config Class Initialized
INFO - 2016-05-03 21:26:05 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:26:05 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:26:05 --> Utf8 Class Initialized
INFO - 2016-05-03 21:26:05 --> URI Class Initialized
INFO - 2016-05-03 21:26:05 --> Router Class Initialized
INFO - 2016-05-03 21:26:05 --> Output Class Initialized
INFO - 2016-05-03 21:26:05 --> Security Class Initialized
DEBUG - 2016-05-03 21:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:26:05 --> Input Class Initialized
INFO - 2016-05-03 21:26:05 --> Language Class Initialized
INFO - 2016-05-03 21:26:05 --> Loader Class Initialized
INFO - 2016-05-03 21:26:05 --> Helper loaded: url_helper
INFO - 2016-05-03 21:26:05 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:26:05 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:26:05 --> Helper loaded: form_helper
INFO - 2016-05-03 21:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:26:05 --> Form Validation Class Initialized
INFO - 2016-05-03 21:26:05 --> Controller Class Initialized
INFO - 2016-05-03 21:26:05 --> Model Class Initialized
INFO - 2016-05-03 21:26:05 --> Database Driver Class Initialized
INFO - 2016-05-03 21:26:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:26:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:26:05 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:26:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:26:05 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:26:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:26:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:26:05 --> Final output sent to browser
DEBUG - 2016-05-03 21:26:05 --> Total execution time: 0.0827
INFO - 2016-05-03 21:26:12 --> Config Class Initialized
INFO - 2016-05-03 21:26:12 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:26:12 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:26:12 --> Utf8 Class Initialized
INFO - 2016-05-03 21:26:12 --> URI Class Initialized
INFO - 2016-05-03 21:26:12 --> Router Class Initialized
INFO - 2016-05-03 21:26:12 --> Output Class Initialized
INFO - 2016-05-03 21:26:12 --> Security Class Initialized
DEBUG - 2016-05-03 21:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:26:12 --> Input Class Initialized
INFO - 2016-05-03 21:26:12 --> Language Class Initialized
INFO - 2016-05-03 21:26:12 --> Loader Class Initialized
INFO - 2016-05-03 21:26:12 --> Helper loaded: url_helper
INFO - 2016-05-03 21:26:12 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:26:12 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:26:12 --> Helper loaded: form_helper
INFO - 2016-05-03 21:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:26:12 --> Form Validation Class Initialized
INFO - 2016-05-03 21:26:12 --> Controller Class Initialized
INFO - 2016-05-03 21:26:12 --> Model Class Initialized
INFO - 2016-05-03 21:26:12 --> Database Driver Class Initialized
INFO - 2016-05-03 21:26:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:26:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:26:12 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:26:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:26:12 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:26:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:26:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:26:12 --> Final output sent to browser
DEBUG - 2016-05-03 21:26:12 --> Total execution time: 0.1052
INFO - 2016-05-03 21:26:34 --> Config Class Initialized
INFO - 2016-05-03 21:26:34 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:26:34 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:26:34 --> Utf8 Class Initialized
INFO - 2016-05-03 21:26:34 --> URI Class Initialized
INFO - 2016-05-03 21:26:34 --> Router Class Initialized
INFO - 2016-05-03 21:26:34 --> Output Class Initialized
INFO - 2016-05-03 21:26:34 --> Security Class Initialized
DEBUG - 2016-05-03 21:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:26:34 --> Input Class Initialized
INFO - 2016-05-03 21:26:34 --> Language Class Initialized
INFO - 2016-05-03 21:26:34 --> Loader Class Initialized
INFO - 2016-05-03 21:26:34 --> Helper loaded: url_helper
INFO - 2016-05-03 21:26:34 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:26:34 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:26:34 --> Helper loaded: form_helper
INFO - 2016-05-03 21:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:26:34 --> Form Validation Class Initialized
INFO - 2016-05-03 21:26:34 --> Controller Class Initialized
INFO - 2016-05-03 21:26:34 --> Model Class Initialized
INFO - 2016-05-03 21:26:34 --> Database Driver Class Initialized
INFO - 2016-05-03 21:26:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:26:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:26:34 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:26:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:26:34 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:26:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:26:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:26:34 --> Final output sent to browser
DEBUG - 2016-05-03 21:26:34 --> Total execution time: 0.1164
INFO - 2016-05-03 21:26:37 --> Config Class Initialized
INFO - 2016-05-03 21:26:37 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:26:37 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:26:37 --> Utf8 Class Initialized
INFO - 2016-05-03 21:26:37 --> URI Class Initialized
INFO - 2016-05-03 21:26:37 --> Router Class Initialized
INFO - 2016-05-03 21:26:37 --> Output Class Initialized
INFO - 2016-05-03 21:26:37 --> Security Class Initialized
DEBUG - 2016-05-03 21:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:26:37 --> Input Class Initialized
INFO - 2016-05-03 21:26:37 --> Language Class Initialized
INFO - 2016-05-03 21:26:37 --> Loader Class Initialized
INFO - 2016-05-03 21:26:37 --> Helper loaded: url_helper
INFO - 2016-05-03 21:26:37 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:26:37 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:26:37 --> Helper loaded: form_helper
INFO - 2016-05-03 21:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:26:37 --> Form Validation Class Initialized
INFO - 2016-05-03 21:26:37 --> Controller Class Initialized
INFO - 2016-05-03 21:26:37 --> Model Class Initialized
INFO - 2016-05-03 21:26:37 --> Database Driver Class Initialized
INFO - 2016-05-03 21:26:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:26:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:26:37 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:26:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:26:37 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:26:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:26:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:26:37 --> Final output sent to browser
DEBUG - 2016-05-03 21:26:37 --> Total execution time: 0.1234
INFO - 2016-05-03 21:29:04 --> Config Class Initialized
INFO - 2016-05-03 21:29:04 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:29:04 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:29:04 --> Utf8 Class Initialized
INFO - 2016-05-03 21:29:04 --> URI Class Initialized
INFO - 2016-05-03 21:29:04 --> Router Class Initialized
INFO - 2016-05-03 21:29:04 --> Output Class Initialized
INFO - 2016-05-03 21:29:04 --> Security Class Initialized
DEBUG - 2016-05-03 21:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:29:04 --> Input Class Initialized
INFO - 2016-05-03 21:29:04 --> Language Class Initialized
INFO - 2016-05-03 21:29:04 --> Loader Class Initialized
INFO - 2016-05-03 21:29:04 --> Helper loaded: url_helper
INFO - 2016-05-03 21:29:04 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:29:04 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:29:04 --> Helper loaded: form_helper
INFO - 2016-05-03 21:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:29:04 --> Form Validation Class Initialized
INFO - 2016-05-03 21:29:04 --> Controller Class Initialized
INFO - 2016-05-03 21:29:04 --> Model Class Initialized
INFO - 2016-05-03 21:29:04 --> Database Driver Class Initialized
INFO - 2016-05-03 21:29:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:29:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:29:04 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:29:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:29:04 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:29:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:29:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:29:04 --> Final output sent to browser
DEBUG - 2016-05-03 21:29:04 --> Total execution time: 0.1858
INFO - 2016-05-03 21:30:17 --> Config Class Initialized
INFO - 2016-05-03 21:30:17 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:30:17 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:30:17 --> Utf8 Class Initialized
INFO - 2016-05-03 21:30:17 --> URI Class Initialized
INFO - 2016-05-03 21:30:17 --> Router Class Initialized
INFO - 2016-05-03 21:30:17 --> Output Class Initialized
INFO - 2016-05-03 21:30:17 --> Security Class Initialized
DEBUG - 2016-05-03 21:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:30:17 --> Input Class Initialized
INFO - 2016-05-03 21:30:17 --> Language Class Initialized
INFO - 2016-05-03 21:30:17 --> Loader Class Initialized
INFO - 2016-05-03 21:30:17 --> Helper loaded: url_helper
INFO - 2016-05-03 21:30:17 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:30:17 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:30:17 --> Helper loaded: form_helper
INFO - 2016-05-03 21:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:30:17 --> Form Validation Class Initialized
INFO - 2016-05-03 21:30:17 --> Controller Class Initialized
INFO - 2016-05-03 21:30:17 --> Model Class Initialized
INFO - 2016-05-03 21:30:17 --> Database Driver Class Initialized
INFO - 2016-05-03 21:30:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:30:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:30:17 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:30:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:30:17 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:30:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:30:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:30:17 --> Final output sent to browser
DEBUG - 2016-05-03 21:30:17 --> Total execution time: 0.1554
INFO - 2016-05-03 21:30:35 --> Config Class Initialized
INFO - 2016-05-03 21:30:35 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:30:35 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:30:35 --> Utf8 Class Initialized
INFO - 2016-05-03 21:30:35 --> URI Class Initialized
INFO - 2016-05-03 21:30:35 --> Router Class Initialized
INFO - 2016-05-03 21:30:35 --> Output Class Initialized
INFO - 2016-05-03 21:30:35 --> Security Class Initialized
DEBUG - 2016-05-03 21:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:30:35 --> Input Class Initialized
INFO - 2016-05-03 21:30:35 --> Language Class Initialized
INFO - 2016-05-03 21:30:35 --> Loader Class Initialized
INFO - 2016-05-03 21:30:35 --> Helper loaded: url_helper
INFO - 2016-05-03 21:30:35 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:30:35 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:30:35 --> Helper loaded: form_helper
INFO - 2016-05-03 21:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:30:35 --> Form Validation Class Initialized
INFO - 2016-05-03 21:30:35 --> Controller Class Initialized
INFO - 2016-05-03 21:30:35 --> Model Class Initialized
INFO - 2016-05-03 21:30:35 --> Database Driver Class Initialized
INFO - 2016-05-03 21:30:35 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:30:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:30:35 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:30:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:30:35 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:30:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:30:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:30:36 --> Final output sent to browser
DEBUG - 2016-05-03 21:30:36 --> Total execution time: 0.0893
INFO - 2016-05-03 21:32:03 --> Config Class Initialized
INFO - 2016-05-03 21:32:03 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:32:03 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:32:03 --> Utf8 Class Initialized
INFO - 2016-05-03 21:32:03 --> URI Class Initialized
INFO - 2016-05-03 21:32:03 --> Router Class Initialized
INFO - 2016-05-03 21:32:03 --> Output Class Initialized
INFO - 2016-05-03 21:32:03 --> Security Class Initialized
DEBUG - 2016-05-03 21:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:32:03 --> Input Class Initialized
INFO - 2016-05-03 21:32:03 --> Language Class Initialized
INFO - 2016-05-03 21:32:03 --> Loader Class Initialized
INFO - 2016-05-03 21:32:03 --> Helper loaded: url_helper
INFO - 2016-05-03 21:32:03 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:32:03 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:32:03 --> Helper loaded: form_helper
INFO - 2016-05-03 21:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:32:03 --> Form Validation Class Initialized
INFO - 2016-05-03 21:32:03 --> Controller Class Initialized
INFO - 2016-05-03 21:32:03 --> Model Class Initialized
INFO - 2016-05-03 21:32:03 --> Database Driver Class Initialized
INFO - 2016-05-03 21:32:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:32:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:32:03 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:32:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:32:03 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:32:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:32:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:32:03 --> Final output sent to browser
DEBUG - 2016-05-03 21:32:03 --> Total execution time: 0.0767
INFO - 2016-05-03 21:32:28 --> Config Class Initialized
INFO - 2016-05-03 21:32:28 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:32:28 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:32:28 --> Utf8 Class Initialized
INFO - 2016-05-03 21:32:28 --> URI Class Initialized
INFO - 2016-05-03 21:32:28 --> Router Class Initialized
INFO - 2016-05-03 21:32:28 --> Output Class Initialized
INFO - 2016-05-03 21:32:28 --> Security Class Initialized
DEBUG - 2016-05-03 21:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:32:28 --> Input Class Initialized
INFO - 2016-05-03 21:32:28 --> Language Class Initialized
INFO - 2016-05-03 21:32:28 --> Loader Class Initialized
INFO - 2016-05-03 21:32:28 --> Helper loaded: url_helper
INFO - 2016-05-03 21:32:28 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:32:28 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:32:28 --> Helper loaded: form_helper
INFO - 2016-05-03 21:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:32:29 --> Form Validation Class Initialized
INFO - 2016-05-03 21:32:29 --> Controller Class Initialized
INFO - 2016-05-03 21:32:29 --> Model Class Initialized
INFO - 2016-05-03 21:32:29 --> Database Driver Class Initialized
INFO - 2016-05-03 21:32:29 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:32:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:32:29 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:32:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:32:29 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:32:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:32:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:32:29 --> Final output sent to browser
DEBUG - 2016-05-03 21:32:29 --> Total execution time: 0.9185
INFO - 2016-05-03 21:33:14 --> Config Class Initialized
INFO - 2016-05-03 21:33:14 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:33:14 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:33:14 --> Utf8 Class Initialized
INFO - 2016-05-03 21:33:14 --> URI Class Initialized
INFO - 2016-05-03 21:33:14 --> Router Class Initialized
INFO - 2016-05-03 21:33:14 --> Output Class Initialized
INFO - 2016-05-03 21:33:14 --> Security Class Initialized
DEBUG - 2016-05-03 21:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:33:14 --> Input Class Initialized
INFO - 2016-05-03 21:33:14 --> Language Class Initialized
INFO - 2016-05-03 21:33:14 --> Loader Class Initialized
INFO - 2016-05-03 21:33:14 --> Helper loaded: url_helper
INFO - 2016-05-03 21:33:14 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:33:14 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:33:14 --> Helper loaded: form_helper
INFO - 2016-05-03 21:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:33:14 --> Form Validation Class Initialized
INFO - 2016-05-03 21:33:14 --> Controller Class Initialized
INFO - 2016-05-03 21:33:14 --> Model Class Initialized
INFO - 2016-05-03 21:33:14 --> Database Driver Class Initialized
INFO - 2016-05-03 21:33:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:33:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:33:14 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:33:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:33:14 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:33:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:33:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:33:14 --> Final output sent to browser
DEBUG - 2016-05-03 21:33:14 --> Total execution time: 0.0781
INFO - 2016-05-03 21:33:18 --> Config Class Initialized
INFO - 2016-05-03 21:33:18 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:33:18 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:33:18 --> Utf8 Class Initialized
INFO - 2016-05-03 21:33:18 --> URI Class Initialized
INFO - 2016-05-03 21:33:18 --> Router Class Initialized
INFO - 2016-05-03 21:33:18 --> Output Class Initialized
INFO - 2016-05-03 21:33:18 --> Security Class Initialized
DEBUG - 2016-05-03 21:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:33:18 --> Input Class Initialized
INFO - 2016-05-03 21:33:18 --> Language Class Initialized
INFO - 2016-05-03 21:33:18 --> Loader Class Initialized
INFO - 2016-05-03 21:33:18 --> Helper loaded: url_helper
INFO - 2016-05-03 21:33:18 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:33:18 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:33:18 --> Helper loaded: form_helper
INFO - 2016-05-03 21:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:33:18 --> Form Validation Class Initialized
INFO - 2016-05-03 21:33:18 --> Controller Class Initialized
INFO - 2016-05-03 21:33:18 --> Model Class Initialized
INFO - 2016-05-03 21:33:18 --> Database Driver Class Initialized
INFO - 2016-05-03 21:33:18 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:33:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:33:18 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:33:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:33:18 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:33:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:33:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:33:18 --> Final output sent to browser
DEBUG - 2016-05-03 21:33:18 --> Total execution time: 0.0982
INFO - 2016-05-03 21:33:45 --> Config Class Initialized
INFO - 2016-05-03 21:33:45 --> Hooks Class Initialized
DEBUG - 2016-05-03 21:33:45 --> UTF-8 Support Enabled
INFO - 2016-05-03 21:33:45 --> Utf8 Class Initialized
INFO - 2016-05-03 21:33:45 --> URI Class Initialized
INFO - 2016-05-03 21:33:45 --> Router Class Initialized
INFO - 2016-05-03 21:33:45 --> Output Class Initialized
INFO - 2016-05-03 21:33:45 --> Security Class Initialized
DEBUG - 2016-05-03 21:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 21:33:45 --> Input Class Initialized
INFO - 2016-05-03 21:33:45 --> Language Class Initialized
INFO - 2016-05-03 21:33:45 --> Loader Class Initialized
INFO - 2016-05-03 21:33:45 --> Helper loaded: url_helper
INFO - 2016-05-03 21:33:45 --> Helper loaded: sesion_helper
INFO - 2016-05-03 21:33:45 --> Helper loaded: templates_helper
INFO - 2016-05-03 21:33:45 --> Helper loaded: form_helper
INFO - 2016-05-03 21:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 21:33:45 --> Form Validation Class Initialized
INFO - 2016-05-03 21:33:45 --> Controller Class Initialized
INFO - 2016-05-03 21:33:45 --> Model Class Initialized
INFO - 2016-05-03 21:33:45 --> Database Driver Class Initialized
INFO - 2016-05-03 21:33:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 21:33:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 21:33:45 --> Pagination Class Initialized
DEBUG - 2016-05-03 21:33:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 21:33:45 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 21:33:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 21:33:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 21:33:45 --> Final output sent to browser
DEBUG - 2016-05-03 21:33:45 --> Total execution time: 0.1000
INFO - 2016-05-03 22:05:12 --> Config Class Initialized
INFO - 2016-05-03 22:05:12 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:05:12 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:05:12 --> Utf8 Class Initialized
INFO - 2016-05-03 22:05:12 --> URI Class Initialized
INFO - 2016-05-03 22:05:12 --> Router Class Initialized
INFO - 2016-05-03 22:05:12 --> Output Class Initialized
INFO - 2016-05-03 22:05:12 --> Security Class Initialized
DEBUG - 2016-05-03 22:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:05:12 --> Input Class Initialized
INFO - 2016-05-03 22:05:12 --> Language Class Initialized
INFO - 2016-05-03 22:05:12 --> Loader Class Initialized
INFO - 2016-05-03 22:05:12 --> Helper loaded: url_helper
INFO - 2016-05-03 22:05:12 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:05:12 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:05:12 --> Helper loaded: form_helper
INFO - 2016-05-03 22:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:05:12 --> Form Validation Class Initialized
INFO - 2016-05-03 22:05:12 --> Controller Class Initialized
INFO - 2016-05-03 22:05:12 --> Model Class Initialized
INFO - 2016-05-03 22:05:12 --> Database Driver Class Initialized
INFO - 2016-05-03 22:05:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:05:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:05:12 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:05:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:05:12 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 22:05:12 --> Severity: Notice --> Undefined variable: mensajebuscar C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Proveedores.php 56
ERROR - 2016-05-03 22:05:12 --> Severity: Notice --> Undefined variable: sinrdo C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 27
INFO - 2016-05-03 22:05:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:05:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:05:12 --> Final output sent to browser
DEBUG - 2016-05-03 22:05:12 --> Total execution time: 0.0967
INFO - 2016-05-03 22:05:25 --> Config Class Initialized
INFO - 2016-05-03 22:05:25 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:05:25 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:05:25 --> Utf8 Class Initialized
INFO - 2016-05-03 22:05:25 --> URI Class Initialized
INFO - 2016-05-03 22:05:25 --> Router Class Initialized
INFO - 2016-05-03 22:05:25 --> Output Class Initialized
INFO - 2016-05-03 22:05:25 --> Security Class Initialized
DEBUG - 2016-05-03 22:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:05:25 --> Input Class Initialized
INFO - 2016-05-03 22:05:25 --> Language Class Initialized
INFO - 2016-05-03 22:05:25 --> Loader Class Initialized
INFO - 2016-05-03 22:05:25 --> Helper loaded: url_helper
INFO - 2016-05-03 22:05:25 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:05:25 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:05:25 --> Helper loaded: form_helper
INFO - 2016-05-03 22:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:05:25 --> Form Validation Class Initialized
INFO - 2016-05-03 22:05:25 --> Controller Class Initialized
INFO - 2016-05-03 22:05:25 --> Model Class Initialized
INFO - 2016-05-03 22:05:25 --> Database Driver Class Initialized
INFO - 2016-05-03 22:05:25 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:05:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:05:25 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:05:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:05:25 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 22:05:25 --> Severity: Notice --> Undefined variable: mensajebuscar C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Proveedores.php 56
INFO - 2016-05-03 22:05:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:05:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:05:25 --> Final output sent to browser
DEBUG - 2016-05-03 22:05:25 --> Total execution time: 0.0867
INFO - 2016-05-03 22:05:56 --> Config Class Initialized
INFO - 2016-05-03 22:05:56 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:05:56 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:05:56 --> Utf8 Class Initialized
INFO - 2016-05-03 22:05:56 --> URI Class Initialized
INFO - 2016-05-03 22:05:56 --> Router Class Initialized
INFO - 2016-05-03 22:05:56 --> Output Class Initialized
INFO - 2016-05-03 22:05:56 --> Security Class Initialized
DEBUG - 2016-05-03 22:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:05:56 --> Input Class Initialized
INFO - 2016-05-03 22:05:56 --> Language Class Initialized
INFO - 2016-05-03 22:05:56 --> Loader Class Initialized
INFO - 2016-05-03 22:05:56 --> Helper loaded: url_helper
INFO - 2016-05-03 22:05:56 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:05:56 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:05:56 --> Helper loaded: form_helper
INFO - 2016-05-03 22:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:05:56 --> Form Validation Class Initialized
INFO - 2016-05-03 22:05:56 --> Controller Class Initialized
INFO - 2016-05-03 22:05:56 --> Model Class Initialized
INFO - 2016-05-03 22:05:56 --> Database Driver Class Initialized
INFO - 2016-05-03 22:05:56 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:05:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:05:56 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:05:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:05:56 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:05:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:05:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:05:56 --> Final output sent to browser
DEBUG - 2016-05-03 22:05:56 --> Total execution time: 0.0824
INFO - 2016-05-03 22:06:43 --> Config Class Initialized
INFO - 2016-05-03 22:06:43 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:06:43 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:06:43 --> Utf8 Class Initialized
INFO - 2016-05-03 22:06:43 --> URI Class Initialized
INFO - 2016-05-03 22:06:43 --> Router Class Initialized
INFO - 2016-05-03 22:06:43 --> Output Class Initialized
INFO - 2016-05-03 22:06:43 --> Security Class Initialized
DEBUG - 2016-05-03 22:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:06:43 --> Input Class Initialized
INFO - 2016-05-03 22:06:43 --> Language Class Initialized
INFO - 2016-05-03 22:06:43 --> Loader Class Initialized
INFO - 2016-05-03 22:06:43 --> Helper loaded: url_helper
INFO - 2016-05-03 22:06:43 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:06:43 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:06:43 --> Helper loaded: form_helper
INFO - 2016-05-03 22:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:06:43 --> Form Validation Class Initialized
INFO - 2016-05-03 22:06:43 --> Controller Class Initialized
INFO - 2016-05-03 22:06:43 --> Model Class Initialized
INFO - 2016-05-03 22:06:43 --> Database Driver Class Initialized
INFO - 2016-05-03 22:06:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:06:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:06:43 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:06:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:06:43 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:06:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:06:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:06:43 --> Final output sent to browser
DEBUG - 2016-05-03 22:06:43 --> Total execution time: 0.0909
INFO - 2016-05-03 22:07:15 --> Config Class Initialized
INFO - 2016-05-03 22:07:15 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:07:15 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:07:15 --> Utf8 Class Initialized
INFO - 2016-05-03 22:07:15 --> URI Class Initialized
INFO - 2016-05-03 22:07:15 --> Router Class Initialized
INFO - 2016-05-03 22:07:15 --> Output Class Initialized
INFO - 2016-05-03 22:07:15 --> Security Class Initialized
DEBUG - 2016-05-03 22:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:07:15 --> Input Class Initialized
INFO - 2016-05-03 22:07:15 --> Language Class Initialized
INFO - 2016-05-03 22:07:15 --> Loader Class Initialized
INFO - 2016-05-03 22:07:15 --> Helper loaded: url_helper
INFO - 2016-05-03 22:07:15 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:07:15 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:07:15 --> Helper loaded: form_helper
INFO - 2016-05-03 22:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:07:15 --> Form Validation Class Initialized
INFO - 2016-05-03 22:07:15 --> Controller Class Initialized
INFO - 2016-05-03 22:07:15 --> Model Class Initialized
INFO - 2016-05-03 22:07:15 --> Database Driver Class Initialized
INFO - 2016-05-03 22:07:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:07:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:07:15 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:07:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:07:15 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:07:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:07:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:07:15 --> Final output sent to browser
DEBUG - 2016-05-03 22:07:15 --> Total execution time: 0.1090
INFO - 2016-05-03 22:07:36 --> Config Class Initialized
INFO - 2016-05-03 22:07:36 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:07:36 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:07:36 --> Utf8 Class Initialized
INFO - 2016-05-03 22:07:36 --> URI Class Initialized
INFO - 2016-05-03 22:07:37 --> Router Class Initialized
INFO - 2016-05-03 22:07:37 --> Output Class Initialized
INFO - 2016-05-03 22:07:37 --> Security Class Initialized
DEBUG - 2016-05-03 22:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:07:37 --> Input Class Initialized
INFO - 2016-05-03 22:07:37 --> Language Class Initialized
INFO - 2016-05-03 22:07:37 --> Loader Class Initialized
INFO - 2016-05-03 22:07:37 --> Helper loaded: url_helper
INFO - 2016-05-03 22:07:37 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:07:37 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:07:37 --> Helper loaded: form_helper
INFO - 2016-05-03 22:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:07:37 --> Form Validation Class Initialized
INFO - 2016-05-03 22:07:37 --> Controller Class Initialized
INFO - 2016-05-03 22:07:37 --> Model Class Initialized
INFO - 2016-05-03 22:07:37 --> Database Driver Class Initialized
INFO - 2016-05-03 22:07:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:07:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:07:37 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:07:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:07:37 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:07:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:07:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:07:37 --> Final output sent to browser
DEBUG - 2016-05-03 22:07:37 --> Total execution time: 0.0844
INFO - 2016-05-03 22:07:42 --> Config Class Initialized
INFO - 2016-05-03 22:07:42 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:07:42 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:07:42 --> Utf8 Class Initialized
INFO - 2016-05-03 22:07:42 --> URI Class Initialized
INFO - 2016-05-03 22:07:42 --> Router Class Initialized
INFO - 2016-05-03 22:07:42 --> Output Class Initialized
INFO - 2016-05-03 22:07:42 --> Security Class Initialized
DEBUG - 2016-05-03 22:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:07:42 --> Input Class Initialized
INFO - 2016-05-03 22:07:42 --> Language Class Initialized
INFO - 2016-05-03 22:07:42 --> Loader Class Initialized
INFO - 2016-05-03 22:07:42 --> Helper loaded: url_helper
INFO - 2016-05-03 22:07:42 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:07:42 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:07:42 --> Helper loaded: form_helper
INFO - 2016-05-03 22:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:07:42 --> Form Validation Class Initialized
INFO - 2016-05-03 22:07:42 --> Controller Class Initialized
INFO - 2016-05-03 22:07:42 --> Model Class Initialized
INFO - 2016-05-03 22:07:42 --> Database Driver Class Initialized
INFO - 2016-05-03 22:07:42 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:07:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:07:42 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:07:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:07:42 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:07:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:07:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:07:42 --> Final output sent to browser
DEBUG - 2016-05-03 22:07:42 --> Total execution time: 0.0989
INFO - 2016-05-03 22:08:43 --> Config Class Initialized
INFO - 2016-05-03 22:08:43 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:08:43 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:08:43 --> Utf8 Class Initialized
INFO - 2016-05-03 22:08:43 --> URI Class Initialized
INFO - 2016-05-03 22:08:43 --> Router Class Initialized
INFO - 2016-05-03 22:08:43 --> Output Class Initialized
INFO - 2016-05-03 22:08:43 --> Security Class Initialized
DEBUG - 2016-05-03 22:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:08:43 --> Input Class Initialized
INFO - 2016-05-03 22:08:43 --> Language Class Initialized
INFO - 2016-05-03 22:08:43 --> Loader Class Initialized
INFO - 2016-05-03 22:08:43 --> Helper loaded: url_helper
INFO - 2016-05-03 22:08:43 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:08:43 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:08:43 --> Helper loaded: form_helper
INFO - 2016-05-03 22:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:08:43 --> Form Validation Class Initialized
INFO - 2016-05-03 22:08:43 --> Controller Class Initialized
INFO - 2016-05-03 22:08:43 --> Model Class Initialized
INFO - 2016-05-03 22:08:43 --> Database Driver Class Initialized
INFO - 2016-05-03 22:08:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:08:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:08:43 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:08:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:08:43 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:08:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:08:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:08:43 --> Final output sent to browser
DEBUG - 2016-05-03 22:08:43 --> Total execution time: 0.0816
INFO - 2016-05-03 22:08:51 --> Config Class Initialized
INFO - 2016-05-03 22:08:51 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:08:51 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:08:51 --> Utf8 Class Initialized
INFO - 2016-05-03 22:08:51 --> URI Class Initialized
INFO - 2016-05-03 22:08:51 --> Router Class Initialized
INFO - 2016-05-03 22:08:51 --> Output Class Initialized
INFO - 2016-05-03 22:08:51 --> Security Class Initialized
DEBUG - 2016-05-03 22:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:08:51 --> Input Class Initialized
INFO - 2016-05-03 22:08:51 --> Language Class Initialized
INFO - 2016-05-03 22:08:51 --> Loader Class Initialized
INFO - 2016-05-03 22:08:51 --> Helper loaded: url_helper
INFO - 2016-05-03 22:08:51 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:08:51 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:08:51 --> Helper loaded: form_helper
INFO - 2016-05-03 22:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:08:51 --> Form Validation Class Initialized
INFO - 2016-05-03 22:08:51 --> Controller Class Initialized
INFO - 2016-05-03 22:08:51 --> Model Class Initialized
INFO - 2016-05-03 22:08:51 --> Database Driver Class Initialized
INFO - 2016-05-03 22:08:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:08:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:08:51 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:08:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:08:51 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:08:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:08:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:08:51 --> Final output sent to browser
DEBUG - 2016-05-03 22:08:51 --> Total execution time: 0.1002
INFO - 2016-05-03 22:09:13 --> Config Class Initialized
INFO - 2016-05-03 22:09:13 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:09:13 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:09:13 --> Utf8 Class Initialized
INFO - 2016-05-03 22:09:13 --> URI Class Initialized
INFO - 2016-05-03 22:09:13 --> Router Class Initialized
INFO - 2016-05-03 22:09:13 --> Output Class Initialized
INFO - 2016-05-03 22:09:13 --> Security Class Initialized
DEBUG - 2016-05-03 22:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:09:13 --> Input Class Initialized
INFO - 2016-05-03 22:09:13 --> Language Class Initialized
INFO - 2016-05-03 22:09:13 --> Loader Class Initialized
INFO - 2016-05-03 22:09:13 --> Helper loaded: url_helper
INFO - 2016-05-03 22:09:13 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:09:13 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:09:13 --> Helper loaded: form_helper
INFO - 2016-05-03 22:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:09:13 --> Form Validation Class Initialized
INFO - 2016-05-03 22:09:13 --> Controller Class Initialized
INFO - 2016-05-03 22:09:13 --> Model Class Initialized
INFO - 2016-05-03 22:09:13 --> Database Driver Class Initialized
INFO - 2016-05-03 22:09:13 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:09:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:09:13 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:09:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:09:13 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:09:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:09:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:09:13 --> Final output sent to browser
DEBUG - 2016-05-03 22:09:13 --> Total execution time: 0.0840
INFO - 2016-05-03 22:09:45 --> Config Class Initialized
INFO - 2016-05-03 22:09:45 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:09:45 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:09:45 --> Utf8 Class Initialized
INFO - 2016-05-03 22:09:45 --> URI Class Initialized
INFO - 2016-05-03 22:09:45 --> Router Class Initialized
INFO - 2016-05-03 22:09:45 --> Output Class Initialized
INFO - 2016-05-03 22:09:45 --> Security Class Initialized
DEBUG - 2016-05-03 22:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:09:45 --> Input Class Initialized
INFO - 2016-05-03 22:09:45 --> Language Class Initialized
INFO - 2016-05-03 22:09:45 --> Loader Class Initialized
INFO - 2016-05-03 22:09:45 --> Helper loaded: url_helper
INFO - 2016-05-03 22:09:45 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:09:45 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:09:45 --> Helper loaded: form_helper
INFO - 2016-05-03 22:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:09:45 --> Form Validation Class Initialized
INFO - 2016-05-03 22:09:45 --> Controller Class Initialized
INFO - 2016-05-03 22:09:45 --> Model Class Initialized
INFO - 2016-05-03 22:09:45 --> Database Driver Class Initialized
INFO - 2016-05-03 22:09:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:09:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:09:45 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:09:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:09:45 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:09:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:09:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:09:45 --> Final output sent to browser
DEBUG - 2016-05-03 22:09:45 --> Total execution time: 0.1047
INFO - 2016-05-03 22:10:17 --> Config Class Initialized
INFO - 2016-05-03 22:10:17 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:10:17 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:10:17 --> Utf8 Class Initialized
INFO - 2016-05-03 22:10:17 --> URI Class Initialized
INFO - 2016-05-03 22:10:17 --> Router Class Initialized
INFO - 2016-05-03 22:10:17 --> Output Class Initialized
INFO - 2016-05-03 22:10:17 --> Security Class Initialized
DEBUG - 2016-05-03 22:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:10:17 --> Input Class Initialized
INFO - 2016-05-03 22:10:17 --> Language Class Initialized
INFO - 2016-05-03 22:10:17 --> Loader Class Initialized
INFO - 2016-05-03 22:10:17 --> Helper loaded: url_helper
INFO - 2016-05-03 22:10:17 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:10:17 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:10:17 --> Helper loaded: form_helper
INFO - 2016-05-03 22:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:10:17 --> Form Validation Class Initialized
INFO - 2016-05-03 22:10:17 --> Controller Class Initialized
INFO - 2016-05-03 22:10:17 --> Model Class Initialized
INFO - 2016-05-03 22:10:17 --> Database Driver Class Initialized
INFO - 2016-05-03 22:10:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:10:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:10:17 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:10:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:10:17 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:10:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:10:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:10:17 --> Final output sent to browser
DEBUG - 2016-05-03 22:10:17 --> Total execution time: 0.0901
INFO - 2016-05-03 22:10:39 --> Config Class Initialized
INFO - 2016-05-03 22:10:39 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:10:39 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:10:39 --> Utf8 Class Initialized
INFO - 2016-05-03 22:10:39 --> URI Class Initialized
INFO - 2016-05-03 22:10:39 --> Router Class Initialized
INFO - 2016-05-03 22:10:39 --> Output Class Initialized
INFO - 2016-05-03 22:10:39 --> Security Class Initialized
DEBUG - 2016-05-03 22:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:10:39 --> Input Class Initialized
INFO - 2016-05-03 22:10:39 --> Language Class Initialized
INFO - 2016-05-03 22:10:39 --> Loader Class Initialized
INFO - 2016-05-03 22:10:39 --> Helper loaded: url_helper
INFO - 2016-05-03 22:10:39 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:10:39 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:10:39 --> Helper loaded: form_helper
INFO - 2016-05-03 22:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:10:39 --> Form Validation Class Initialized
INFO - 2016-05-03 22:10:39 --> Controller Class Initialized
INFO - 2016-05-03 22:10:39 --> Model Class Initialized
INFO - 2016-05-03 22:10:39 --> Database Driver Class Initialized
INFO - 2016-05-03 22:10:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:10:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:10:39 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:10:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:10:39 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:10:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:10:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:10:39 --> Final output sent to browser
DEBUG - 2016-05-03 22:10:39 --> Total execution time: 0.0827
INFO - 2016-05-03 22:10:53 --> Config Class Initialized
INFO - 2016-05-03 22:10:53 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:10:53 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:10:53 --> Utf8 Class Initialized
INFO - 2016-05-03 22:10:53 --> URI Class Initialized
INFO - 2016-05-03 22:10:53 --> Router Class Initialized
INFO - 2016-05-03 22:10:53 --> Output Class Initialized
INFO - 2016-05-03 22:10:53 --> Security Class Initialized
DEBUG - 2016-05-03 22:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:10:53 --> Input Class Initialized
INFO - 2016-05-03 22:10:53 --> Language Class Initialized
INFO - 2016-05-03 22:10:53 --> Loader Class Initialized
INFO - 2016-05-03 22:10:53 --> Helper loaded: url_helper
INFO - 2016-05-03 22:10:53 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:10:53 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:10:53 --> Helper loaded: form_helper
INFO - 2016-05-03 22:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:10:53 --> Form Validation Class Initialized
INFO - 2016-05-03 22:10:53 --> Controller Class Initialized
INFO - 2016-05-03 22:10:53 --> Model Class Initialized
INFO - 2016-05-03 22:10:53 --> Database Driver Class Initialized
INFO - 2016-05-03 22:10:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:10:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:10:53 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:10:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:10:53 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:10:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:10:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:10:53 --> Final output sent to browser
DEBUG - 2016-05-03 22:10:53 --> Total execution time: 0.0815
INFO - 2016-05-03 22:10:57 --> Config Class Initialized
INFO - 2016-05-03 22:10:57 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:10:57 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:10:57 --> Utf8 Class Initialized
INFO - 2016-05-03 22:10:57 --> URI Class Initialized
INFO - 2016-05-03 22:10:57 --> Router Class Initialized
INFO - 2016-05-03 22:10:57 --> Output Class Initialized
INFO - 2016-05-03 22:10:57 --> Security Class Initialized
DEBUG - 2016-05-03 22:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:10:57 --> Input Class Initialized
INFO - 2016-05-03 22:10:57 --> Language Class Initialized
INFO - 2016-05-03 22:10:57 --> Loader Class Initialized
INFO - 2016-05-03 22:10:57 --> Helper loaded: url_helper
INFO - 2016-05-03 22:10:57 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:10:57 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:10:57 --> Helper loaded: form_helper
INFO - 2016-05-03 22:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:10:57 --> Form Validation Class Initialized
INFO - 2016-05-03 22:10:57 --> Controller Class Initialized
INFO - 2016-05-03 22:10:57 --> Model Class Initialized
INFO - 2016-05-03 22:10:57 --> Database Driver Class Initialized
INFO - 2016-05-03 22:10:57 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:10:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:10:57 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:10:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:10:57 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:10:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:10:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:10:57 --> Final output sent to browser
DEBUG - 2016-05-03 22:10:57 --> Total execution time: 0.0899
INFO - 2016-05-03 22:11:02 --> Config Class Initialized
INFO - 2016-05-03 22:11:02 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:11:02 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:11:02 --> Utf8 Class Initialized
INFO - 2016-05-03 22:11:02 --> URI Class Initialized
INFO - 2016-05-03 22:11:02 --> Router Class Initialized
INFO - 2016-05-03 22:11:02 --> Output Class Initialized
INFO - 2016-05-03 22:11:02 --> Security Class Initialized
DEBUG - 2016-05-03 22:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:11:02 --> Input Class Initialized
INFO - 2016-05-03 22:11:02 --> Language Class Initialized
INFO - 2016-05-03 22:11:02 --> Loader Class Initialized
INFO - 2016-05-03 22:11:02 --> Helper loaded: url_helper
INFO - 2016-05-03 22:11:02 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:11:02 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:11:02 --> Helper loaded: form_helper
INFO - 2016-05-03 22:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:11:02 --> Form Validation Class Initialized
INFO - 2016-05-03 22:11:02 --> Controller Class Initialized
INFO - 2016-05-03 22:11:02 --> Model Class Initialized
INFO - 2016-05-03 22:11:02 --> Database Driver Class Initialized
INFO - 2016-05-03 22:11:02 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:11:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:11:02 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:11:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:11:02 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:11:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:11:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:11:02 --> Final output sent to browser
DEBUG - 2016-05-03 22:11:02 --> Total execution time: 0.1131
INFO - 2016-05-03 22:12:40 --> Config Class Initialized
INFO - 2016-05-03 22:12:40 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:12:40 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:12:40 --> Utf8 Class Initialized
INFO - 2016-05-03 22:12:40 --> URI Class Initialized
INFO - 2016-05-03 22:12:40 --> Router Class Initialized
INFO - 2016-05-03 22:12:40 --> Output Class Initialized
INFO - 2016-05-03 22:12:40 --> Security Class Initialized
DEBUG - 2016-05-03 22:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:12:40 --> Input Class Initialized
INFO - 2016-05-03 22:12:40 --> Language Class Initialized
INFO - 2016-05-03 22:12:40 --> Loader Class Initialized
INFO - 2016-05-03 22:12:40 --> Helper loaded: url_helper
INFO - 2016-05-03 22:12:40 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:12:40 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:12:40 --> Helper loaded: form_helper
INFO - 2016-05-03 22:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:12:40 --> Form Validation Class Initialized
INFO - 2016-05-03 22:12:40 --> Controller Class Initialized
INFO - 2016-05-03 22:12:40 --> Model Class Initialized
INFO - 2016-05-03 22:12:40 --> Database Driver Class Initialized
INFO - 2016-05-03 22:12:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:12:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:12:40 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:12:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:12:40 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:12:40 --> Config Class Initialized
INFO - 2016-05-03 22:12:40 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:12:40 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:12:40 --> Utf8 Class Initialized
INFO - 2016-05-03 22:12:40 --> URI Class Initialized
INFO - 2016-05-03 22:12:40 --> Router Class Initialized
INFO - 2016-05-03 22:12:40 --> Output Class Initialized
INFO - 2016-05-03 22:12:40 --> Security Class Initialized
DEBUG - 2016-05-03 22:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:12:40 --> Input Class Initialized
INFO - 2016-05-03 22:12:40 --> Language Class Initialized
INFO - 2016-05-03 22:12:40 --> Loader Class Initialized
INFO - 2016-05-03 22:12:40 --> Helper loaded: url_helper
INFO - 2016-05-03 22:12:40 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:12:40 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:12:40 --> Helper loaded: form_helper
INFO - 2016-05-03 22:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:12:40 --> Form Validation Class Initialized
INFO - 2016-05-03 22:12:40 --> Controller Class Initialized
INFO - 2016-05-03 22:12:40 --> Model Class Initialized
INFO - 2016-05-03 22:12:40 --> Database Driver Class Initialized
INFO - 2016-05-03 22:12:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:12:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:12:40 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:12:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:12:40 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:12:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:12:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:12:40 --> Final output sent to browser
DEBUG - 2016-05-03 22:12:40 --> Total execution time: 0.0795
INFO - 2016-05-03 22:12:43 --> Config Class Initialized
INFO - 2016-05-03 22:12:43 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:12:43 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:12:43 --> Utf8 Class Initialized
INFO - 2016-05-03 22:12:43 --> URI Class Initialized
INFO - 2016-05-03 22:12:43 --> Router Class Initialized
INFO - 2016-05-03 22:12:43 --> Output Class Initialized
INFO - 2016-05-03 22:12:43 --> Security Class Initialized
DEBUG - 2016-05-03 22:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:12:43 --> Input Class Initialized
INFO - 2016-05-03 22:12:43 --> Language Class Initialized
INFO - 2016-05-03 22:12:43 --> Loader Class Initialized
INFO - 2016-05-03 22:12:43 --> Helper loaded: url_helper
INFO - 2016-05-03 22:12:43 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:12:43 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:12:43 --> Helper loaded: form_helper
INFO - 2016-05-03 22:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:12:43 --> Form Validation Class Initialized
INFO - 2016-05-03 22:12:43 --> Controller Class Initialized
INFO - 2016-05-03 22:12:43 --> Model Class Initialized
INFO - 2016-05-03 22:12:43 --> Database Driver Class Initialized
INFO - 2016-05-03 22:12:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:12:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:12:43 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:12:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:12:43 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:12:43 --> Config Class Initialized
INFO - 2016-05-03 22:12:43 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:12:43 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:12:43 --> Utf8 Class Initialized
INFO - 2016-05-03 22:12:43 --> URI Class Initialized
INFO - 2016-05-03 22:12:43 --> Router Class Initialized
INFO - 2016-05-03 22:12:43 --> Output Class Initialized
INFO - 2016-05-03 22:12:43 --> Security Class Initialized
DEBUG - 2016-05-03 22:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:12:43 --> Input Class Initialized
INFO - 2016-05-03 22:12:43 --> Language Class Initialized
INFO - 2016-05-03 22:12:43 --> Loader Class Initialized
INFO - 2016-05-03 22:12:43 --> Helper loaded: url_helper
INFO - 2016-05-03 22:12:43 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:12:43 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:12:43 --> Helper loaded: form_helper
INFO - 2016-05-03 22:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:12:43 --> Form Validation Class Initialized
INFO - 2016-05-03 22:12:43 --> Controller Class Initialized
INFO - 2016-05-03 22:12:43 --> Model Class Initialized
INFO - 2016-05-03 22:12:43 --> Database Driver Class Initialized
INFO - 2016-05-03 22:12:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:12:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:12:43 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:12:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:12:43 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:12:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:12:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:12:43 --> Final output sent to browser
DEBUG - 2016-05-03 22:12:43 --> Total execution time: 0.1020
INFO - 2016-05-03 22:12:53 --> Config Class Initialized
INFO - 2016-05-03 22:12:53 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:12:53 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:12:53 --> Utf8 Class Initialized
INFO - 2016-05-03 22:12:53 --> URI Class Initialized
INFO - 2016-05-03 22:12:53 --> Router Class Initialized
INFO - 2016-05-03 22:12:53 --> Output Class Initialized
INFO - 2016-05-03 22:12:53 --> Security Class Initialized
DEBUG - 2016-05-03 22:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:12:53 --> Input Class Initialized
INFO - 2016-05-03 22:12:53 --> Language Class Initialized
INFO - 2016-05-03 22:12:53 --> Loader Class Initialized
INFO - 2016-05-03 22:12:53 --> Helper loaded: url_helper
INFO - 2016-05-03 22:12:53 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:12:53 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:12:53 --> Helper loaded: form_helper
INFO - 2016-05-03 22:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:12:53 --> Form Validation Class Initialized
INFO - 2016-05-03 22:12:53 --> Controller Class Initialized
INFO - 2016-05-03 22:12:53 --> Model Class Initialized
INFO - 2016-05-03 22:12:53 --> Database Driver Class Initialized
INFO - 2016-05-03 22:12:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:12:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:12:53 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:12:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:12:53 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:12:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:12:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:12:53 --> Final output sent to browser
DEBUG - 2016-05-03 22:12:53 --> Total execution time: 0.1247
INFO - 2016-05-03 22:14:21 --> Config Class Initialized
INFO - 2016-05-03 22:14:21 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:14:21 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:14:21 --> Utf8 Class Initialized
INFO - 2016-05-03 22:14:21 --> URI Class Initialized
INFO - 2016-05-03 22:14:21 --> Router Class Initialized
INFO - 2016-05-03 22:14:21 --> Output Class Initialized
INFO - 2016-05-03 22:14:21 --> Security Class Initialized
DEBUG - 2016-05-03 22:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:14:21 --> Input Class Initialized
INFO - 2016-05-03 22:14:21 --> Language Class Initialized
INFO - 2016-05-03 22:14:21 --> Loader Class Initialized
INFO - 2016-05-03 22:14:21 --> Helper loaded: url_helper
INFO - 2016-05-03 22:14:21 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:14:21 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:14:21 --> Helper loaded: form_helper
INFO - 2016-05-03 22:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:14:21 --> Form Validation Class Initialized
INFO - 2016-05-03 22:14:21 --> Controller Class Initialized
INFO - 2016-05-03 22:14:21 --> Model Class Initialized
INFO - 2016-05-03 22:14:21 --> Database Driver Class Initialized
INFO - 2016-05-03 22:14:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:14:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:14:21 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:14:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:14:21 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:14:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:14:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:14:21 --> Final output sent to browser
DEBUG - 2016-05-03 22:14:21 --> Total execution time: 0.0782
INFO - 2016-05-03 22:14:23 --> Config Class Initialized
INFO - 2016-05-03 22:14:23 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:14:23 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:14:23 --> Utf8 Class Initialized
INFO - 2016-05-03 22:14:23 --> URI Class Initialized
INFO - 2016-05-03 22:14:23 --> Router Class Initialized
INFO - 2016-05-03 22:14:23 --> Output Class Initialized
INFO - 2016-05-03 22:14:23 --> Security Class Initialized
DEBUG - 2016-05-03 22:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:14:23 --> Input Class Initialized
INFO - 2016-05-03 22:14:23 --> Language Class Initialized
INFO - 2016-05-03 22:14:23 --> Loader Class Initialized
INFO - 2016-05-03 22:14:23 --> Helper loaded: url_helper
INFO - 2016-05-03 22:14:23 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:14:23 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:14:23 --> Helper loaded: form_helper
INFO - 2016-05-03 22:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:14:23 --> Form Validation Class Initialized
INFO - 2016-05-03 22:14:23 --> Controller Class Initialized
INFO - 2016-05-03 22:14:23 --> Model Class Initialized
INFO - 2016-05-03 22:14:23 --> Database Driver Class Initialized
INFO - 2016-05-03 22:14:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:14:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:14:23 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:14:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:14:23 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:14:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:14:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:14:23 --> Final output sent to browser
DEBUG - 2016-05-03 22:14:23 --> Total execution time: 0.0897
INFO - 2016-05-03 22:14:27 --> Config Class Initialized
INFO - 2016-05-03 22:14:27 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:14:27 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:14:27 --> Utf8 Class Initialized
INFO - 2016-05-03 22:14:27 --> URI Class Initialized
INFO - 2016-05-03 22:14:27 --> Router Class Initialized
INFO - 2016-05-03 22:14:27 --> Output Class Initialized
INFO - 2016-05-03 22:14:27 --> Security Class Initialized
DEBUG - 2016-05-03 22:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:14:27 --> Input Class Initialized
INFO - 2016-05-03 22:14:27 --> Language Class Initialized
INFO - 2016-05-03 22:14:27 --> Loader Class Initialized
INFO - 2016-05-03 22:14:27 --> Helper loaded: url_helper
INFO - 2016-05-03 22:14:27 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:14:27 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:14:27 --> Helper loaded: form_helper
INFO - 2016-05-03 22:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:14:27 --> Form Validation Class Initialized
INFO - 2016-05-03 22:14:27 --> Controller Class Initialized
INFO - 2016-05-03 22:14:27 --> Model Class Initialized
INFO - 2016-05-03 22:14:27 --> Database Driver Class Initialized
INFO - 2016-05-03 22:14:27 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:14:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:14:27 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:14:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:14:27 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:14:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:14:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:14:27 --> Final output sent to browser
DEBUG - 2016-05-03 22:14:27 --> Total execution time: 0.0765
INFO - 2016-05-03 22:14:34 --> Config Class Initialized
INFO - 2016-05-03 22:14:34 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:14:34 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:14:34 --> Utf8 Class Initialized
INFO - 2016-05-03 22:14:34 --> URI Class Initialized
INFO - 2016-05-03 22:14:34 --> Router Class Initialized
INFO - 2016-05-03 22:14:34 --> Output Class Initialized
INFO - 2016-05-03 22:14:34 --> Security Class Initialized
DEBUG - 2016-05-03 22:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:14:34 --> Input Class Initialized
INFO - 2016-05-03 22:14:34 --> Language Class Initialized
INFO - 2016-05-03 22:14:34 --> Loader Class Initialized
INFO - 2016-05-03 22:14:34 --> Helper loaded: url_helper
INFO - 2016-05-03 22:14:34 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:14:34 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:14:34 --> Helper loaded: form_helper
INFO - 2016-05-03 22:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:14:34 --> Form Validation Class Initialized
INFO - 2016-05-03 22:14:34 --> Controller Class Initialized
INFO - 2016-05-03 22:14:34 --> Model Class Initialized
INFO - 2016-05-03 22:14:34 --> Database Driver Class Initialized
INFO - 2016-05-03 22:14:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:14:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:14:34 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:14:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:14:34 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:14:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:14:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:14:34 --> Final output sent to browser
DEBUG - 2016-05-03 22:14:34 --> Total execution time: 0.0967
INFO - 2016-05-03 22:15:06 --> Config Class Initialized
INFO - 2016-05-03 22:15:06 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:15:06 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:15:06 --> Utf8 Class Initialized
INFO - 2016-05-03 22:15:06 --> URI Class Initialized
INFO - 2016-05-03 22:15:06 --> Router Class Initialized
INFO - 2016-05-03 22:15:06 --> Output Class Initialized
INFO - 2016-05-03 22:15:06 --> Security Class Initialized
DEBUG - 2016-05-03 22:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:15:06 --> Input Class Initialized
INFO - 2016-05-03 22:15:06 --> Language Class Initialized
INFO - 2016-05-03 22:15:06 --> Loader Class Initialized
INFO - 2016-05-03 22:15:06 --> Helper loaded: url_helper
INFO - 2016-05-03 22:15:06 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:15:06 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:15:06 --> Helper loaded: form_helper
INFO - 2016-05-03 22:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:15:06 --> Form Validation Class Initialized
INFO - 2016-05-03 22:15:06 --> Controller Class Initialized
INFO - 2016-05-03 22:15:06 --> Model Class Initialized
INFO - 2016-05-03 22:15:06 --> Database Driver Class Initialized
INFO - 2016-05-03 22:15:06 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:15:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:15:06 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:15:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:15:06 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:15:06 --> Config Class Initialized
INFO - 2016-05-03 22:15:06 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:15:06 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:15:06 --> Utf8 Class Initialized
INFO - 2016-05-03 22:15:06 --> URI Class Initialized
INFO - 2016-05-03 22:15:06 --> Router Class Initialized
INFO - 2016-05-03 22:15:06 --> Output Class Initialized
INFO - 2016-05-03 22:15:06 --> Security Class Initialized
DEBUG - 2016-05-03 22:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:15:06 --> Input Class Initialized
INFO - 2016-05-03 22:15:06 --> Language Class Initialized
INFO - 2016-05-03 22:15:06 --> Loader Class Initialized
INFO - 2016-05-03 22:15:06 --> Helper loaded: url_helper
INFO - 2016-05-03 22:15:06 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:15:06 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:15:06 --> Helper loaded: form_helper
INFO - 2016-05-03 22:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:15:06 --> Form Validation Class Initialized
INFO - 2016-05-03 22:15:06 --> Controller Class Initialized
INFO - 2016-05-03 22:15:06 --> Model Class Initialized
INFO - 2016-05-03 22:15:06 --> Database Driver Class Initialized
INFO - 2016-05-03 22:15:06 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:15:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:15:06 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:15:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:15:06 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:15:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:15:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:15:06 --> Final output sent to browser
DEBUG - 2016-05-03 22:15:06 --> Total execution time: 0.0965
INFO - 2016-05-03 22:15:35 --> Config Class Initialized
INFO - 2016-05-03 22:15:35 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:15:35 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:15:35 --> Utf8 Class Initialized
INFO - 2016-05-03 22:15:35 --> URI Class Initialized
INFO - 2016-05-03 22:15:35 --> Router Class Initialized
INFO - 2016-05-03 22:15:35 --> Output Class Initialized
INFO - 2016-05-03 22:15:35 --> Security Class Initialized
DEBUG - 2016-05-03 22:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:15:35 --> Input Class Initialized
INFO - 2016-05-03 22:15:35 --> Language Class Initialized
INFO - 2016-05-03 22:15:35 --> Loader Class Initialized
INFO - 2016-05-03 22:15:35 --> Helper loaded: url_helper
INFO - 2016-05-03 22:15:35 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:15:35 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:15:35 --> Helper loaded: form_helper
INFO - 2016-05-03 22:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:15:35 --> Form Validation Class Initialized
INFO - 2016-05-03 22:15:35 --> Controller Class Initialized
INFO - 2016-05-03 22:15:35 --> Model Class Initialized
INFO - 2016-05-03 22:15:35 --> Database Driver Class Initialized
INFO - 2016-05-03 22:15:35 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:15:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:15:35 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:15:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:15:35 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:15:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:15:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:15:35 --> Final output sent to browser
DEBUG - 2016-05-03 22:15:35 --> Total execution time: 0.0854
INFO - 2016-05-03 22:15:45 --> Config Class Initialized
INFO - 2016-05-03 22:15:45 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:15:45 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:15:45 --> Utf8 Class Initialized
INFO - 2016-05-03 22:15:45 --> URI Class Initialized
INFO - 2016-05-03 22:15:45 --> Router Class Initialized
INFO - 2016-05-03 22:15:45 --> Output Class Initialized
INFO - 2016-05-03 22:15:45 --> Security Class Initialized
DEBUG - 2016-05-03 22:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:15:45 --> Input Class Initialized
INFO - 2016-05-03 22:15:45 --> Language Class Initialized
INFO - 2016-05-03 22:15:45 --> Loader Class Initialized
INFO - 2016-05-03 22:15:45 --> Helper loaded: url_helper
INFO - 2016-05-03 22:15:45 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:15:45 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:15:45 --> Helper loaded: form_helper
INFO - 2016-05-03 22:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:15:45 --> Form Validation Class Initialized
INFO - 2016-05-03 22:15:45 --> Controller Class Initialized
INFO - 2016-05-03 22:15:45 --> Model Class Initialized
INFO - 2016-05-03 22:15:45 --> Database Driver Class Initialized
INFO - 2016-05-03 22:15:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:15:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:15:45 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:15:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:15:45 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:15:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:15:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:15:45 --> Final output sent to browser
DEBUG - 2016-05-03 22:15:45 --> Total execution time: 0.0870
INFO - 2016-05-03 22:16:20 --> Config Class Initialized
INFO - 2016-05-03 22:16:20 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:16:20 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:16:20 --> Utf8 Class Initialized
INFO - 2016-05-03 22:16:20 --> URI Class Initialized
INFO - 2016-05-03 22:16:20 --> Router Class Initialized
INFO - 2016-05-03 22:16:20 --> Output Class Initialized
INFO - 2016-05-03 22:16:20 --> Security Class Initialized
DEBUG - 2016-05-03 22:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:16:20 --> Input Class Initialized
INFO - 2016-05-03 22:16:20 --> Language Class Initialized
INFO - 2016-05-03 22:16:20 --> Loader Class Initialized
INFO - 2016-05-03 22:16:20 --> Helper loaded: url_helper
INFO - 2016-05-03 22:16:20 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:16:20 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:16:20 --> Helper loaded: form_helper
INFO - 2016-05-03 22:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:16:20 --> Form Validation Class Initialized
INFO - 2016-05-03 22:16:20 --> Controller Class Initialized
INFO - 2016-05-03 22:16:20 --> Model Class Initialized
INFO - 2016-05-03 22:16:20 --> Database Driver Class Initialized
INFO - 2016-05-03 22:16:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:16:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:16:20 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:16:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:16:20 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:16:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:16:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:16:20 --> Final output sent to browser
DEBUG - 2016-05-03 22:16:20 --> Total execution time: 0.0843
INFO - 2016-05-03 22:17:06 --> Config Class Initialized
INFO - 2016-05-03 22:17:06 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:17:06 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:17:06 --> Utf8 Class Initialized
INFO - 2016-05-03 22:17:06 --> URI Class Initialized
INFO - 2016-05-03 22:17:06 --> Router Class Initialized
INFO - 2016-05-03 22:17:06 --> Output Class Initialized
INFO - 2016-05-03 22:17:06 --> Security Class Initialized
DEBUG - 2016-05-03 22:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:17:06 --> Input Class Initialized
INFO - 2016-05-03 22:17:06 --> Language Class Initialized
INFO - 2016-05-03 22:17:06 --> Loader Class Initialized
INFO - 2016-05-03 22:17:06 --> Helper loaded: url_helper
INFO - 2016-05-03 22:17:06 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:17:06 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:17:06 --> Helper loaded: form_helper
INFO - 2016-05-03 22:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:17:06 --> Form Validation Class Initialized
INFO - 2016-05-03 22:17:06 --> Controller Class Initialized
INFO - 2016-05-03 22:17:06 --> Model Class Initialized
INFO - 2016-05-03 22:17:06 --> Database Driver Class Initialized
INFO - 2016-05-03 22:17:06 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:17:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:17:06 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:17:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:17:06 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:17:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:17:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:17:06 --> Final output sent to browser
DEBUG - 2016-05-03 22:17:06 --> Total execution time: 0.0779
INFO - 2016-05-03 22:17:55 --> Config Class Initialized
INFO - 2016-05-03 22:17:55 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:17:55 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:17:55 --> Utf8 Class Initialized
INFO - 2016-05-03 22:17:55 --> URI Class Initialized
INFO - 2016-05-03 22:17:55 --> Router Class Initialized
INFO - 2016-05-03 22:17:55 --> Output Class Initialized
INFO - 2016-05-03 22:17:55 --> Security Class Initialized
DEBUG - 2016-05-03 22:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:17:55 --> Input Class Initialized
INFO - 2016-05-03 22:17:55 --> Language Class Initialized
INFO - 2016-05-03 22:17:55 --> Loader Class Initialized
INFO - 2016-05-03 22:17:55 --> Helper loaded: url_helper
INFO - 2016-05-03 22:17:55 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:17:55 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:17:55 --> Helper loaded: form_helper
INFO - 2016-05-03 22:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:17:55 --> Form Validation Class Initialized
INFO - 2016-05-03 22:17:55 --> Controller Class Initialized
INFO - 2016-05-03 22:17:55 --> Model Class Initialized
INFO - 2016-05-03 22:17:55 --> Database Driver Class Initialized
INFO - 2016-05-03 22:17:55 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:17:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:17:55 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:17:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:17:55 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:17:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:17:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:17:55 --> Final output sent to browser
DEBUG - 2016-05-03 22:17:55 --> Total execution time: 0.0823
INFO - 2016-05-03 22:17:59 --> Config Class Initialized
INFO - 2016-05-03 22:17:59 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:17:59 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:17:59 --> Utf8 Class Initialized
INFO - 2016-05-03 22:17:59 --> URI Class Initialized
INFO - 2016-05-03 22:17:59 --> Router Class Initialized
INFO - 2016-05-03 22:17:59 --> Output Class Initialized
INFO - 2016-05-03 22:17:59 --> Security Class Initialized
DEBUG - 2016-05-03 22:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:17:59 --> Input Class Initialized
INFO - 2016-05-03 22:17:59 --> Language Class Initialized
INFO - 2016-05-03 22:17:59 --> Loader Class Initialized
INFO - 2016-05-03 22:17:59 --> Helper loaded: url_helper
INFO - 2016-05-03 22:17:59 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:17:59 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:17:59 --> Helper loaded: form_helper
INFO - 2016-05-03 22:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:17:59 --> Form Validation Class Initialized
INFO - 2016-05-03 22:17:59 --> Controller Class Initialized
INFO - 2016-05-03 22:17:59 --> Model Class Initialized
INFO - 2016-05-03 22:17:59 --> Database Driver Class Initialized
INFO - 2016-05-03 22:17:59 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:17:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:17:59 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:17:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:17:59 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:17:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:17:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:17:59 --> Final output sent to browser
DEBUG - 2016-05-03 22:17:59 --> Total execution time: 0.1401
INFO - 2016-05-03 22:18:02 --> Config Class Initialized
INFO - 2016-05-03 22:18:02 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:18:02 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:18:02 --> Utf8 Class Initialized
INFO - 2016-05-03 22:18:02 --> URI Class Initialized
INFO - 2016-05-03 22:18:02 --> Router Class Initialized
INFO - 2016-05-03 22:18:02 --> Output Class Initialized
INFO - 2016-05-03 22:18:02 --> Security Class Initialized
DEBUG - 2016-05-03 22:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:18:02 --> Input Class Initialized
INFO - 2016-05-03 22:18:02 --> Language Class Initialized
INFO - 2016-05-03 22:18:02 --> Loader Class Initialized
INFO - 2016-05-03 22:18:02 --> Helper loaded: url_helper
INFO - 2016-05-03 22:18:02 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:18:02 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:18:02 --> Helper loaded: form_helper
INFO - 2016-05-03 22:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:18:02 --> Form Validation Class Initialized
INFO - 2016-05-03 22:18:02 --> Controller Class Initialized
INFO - 2016-05-03 22:18:02 --> Model Class Initialized
INFO - 2016-05-03 22:18:02 --> Database Driver Class Initialized
INFO - 2016-05-03 22:18:02 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:18:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:18:02 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:18:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:18:02 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 22:18:02 --> Severity: Notice --> Undefined variable: sinrdo C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 29
INFO - 2016-05-03 22:18:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:18:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:18:02 --> Final output sent to browser
DEBUG - 2016-05-03 22:18:02 --> Total execution time: 0.1260
INFO - 2016-05-03 22:18:14 --> Config Class Initialized
INFO - 2016-05-03 22:18:14 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:18:14 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:18:14 --> Utf8 Class Initialized
INFO - 2016-05-03 22:18:14 --> URI Class Initialized
INFO - 2016-05-03 22:18:14 --> Router Class Initialized
INFO - 2016-05-03 22:18:14 --> Output Class Initialized
INFO - 2016-05-03 22:18:14 --> Security Class Initialized
DEBUG - 2016-05-03 22:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:18:14 --> Input Class Initialized
INFO - 2016-05-03 22:18:14 --> Language Class Initialized
INFO - 2016-05-03 22:18:14 --> Loader Class Initialized
INFO - 2016-05-03 22:18:14 --> Helper loaded: url_helper
INFO - 2016-05-03 22:18:14 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:18:14 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:18:14 --> Helper loaded: form_helper
INFO - 2016-05-03 22:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:18:14 --> Form Validation Class Initialized
INFO - 2016-05-03 22:18:14 --> Controller Class Initialized
INFO - 2016-05-03 22:18:14 --> Model Class Initialized
INFO - 2016-05-03 22:18:14 --> Database Driver Class Initialized
INFO - 2016-05-03 22:18:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:18:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:18:14 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:18:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:18:14 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:18:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:18:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:18:14 --> Final output sent to browser
DEBUG - 2016-05-03 22:18:14 --> Total execution time: 0.0822
INFO - 2016-05-03 22:18:38 --> Config Class Initialized
INFO - 2016-05-03 22:18:38 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:18:38 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:18:38 --> Utf8 Class Initialized
INFO - 2016-05-03 22:18:38 --> URI Class Initialized
INFO - 2016-05-03 22:18:38 --> Router Class Initialized
INFO - 2016-05-03 22:18:38 --> Output Class Initialized
INFO - 2016-05-03 22:18:38 --> Security Class Initialized
DEBUG - 2016-05-03 22:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:18:38 --> Input Class Initialized
INFO - 2016-05-03 22:18:38 --> Language Class Initialized
INFO - 2016-05-03 22:18:38 --> Loader Class Initialized
INFO - 2016-05-03 22:18:38 --> Helper loaded: url_helper
INFO - 2016-05-03 22:18:38 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:18:38 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:18:38 --> Helper loaded: form_helper
INFO - 2016-05-03 22:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:18:38 --> Form Validation Class Initialized
INFO - 2016-05-03 22:18:38 --> Controller Class Initialized
INFO - 2016-05-03 22:18:38 --> Model Class Initialized
INFO - 2016-05-03 22:18:38 --> Database Driver Class Initialized
INFO - 2016-05-03 22:18:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:18:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:18:38 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:18:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:18:38 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 22:18:38 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 29
INFO - 2016-05-03 22:18:51 --> Config Class Initialized
INFO - 2016-05-03 22:18:51 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:18:51 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:18:51 --> Utf8 Class Initialized
INFO - 2016-05-03 22:18:51 --> URI Class Initialized
INFO - 2016-05-03 22:18:51 --> Router Class Initialized
INFO - 2016-05-03 22:18:51 --> Output Class Initialized
INFO - 2016-05-03 22:18:51 --> Security Class Initialized
DEBUG - 2016-05-03 22:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:18:51 --> Input Class Initialized
INFO - 2016-05-03 22:18:51 --> Language Class Initialized
INFO - 2016-05-03 22:18:51 --> Loader Class Initialized
INFO - 2016-05-03 22:18:51 --> Helper loaded: url_helper
INFO - 2016-05-03 22:18:51 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:18:51 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:18:51 --> Helper loaded: form_helper
INFO - 2016-05-03 22:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:18:51 --> Form Validation Class Initialized
INFO - 2016-05-03 22:18:51 --> Controller Class Initialized
INFO - 2016-05-03 22:18:51 --> Model Class Initialized
INFO - 2016-05-03 22:18:51 --> Database Driver Class Initialized
INFO - 2016-05-03 22:18:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:18:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:18:51 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:18:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:18:51 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 22:18:51 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 29
INFO - 2016-05-03 22:18:52 --> Config Class Initialized
INFO - 2016-05-03 22:18:52 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:18:52 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:18:52 --> Utf8 Class Initialized
INFO - 2016-05-03 22:18:52 --> URI Class Initialized
INFO - 2016-05-03 22:18:52 --> Router Class Initialized
INFO - 2016-05-03 22:18:52 --> Output Class Initialized
INFO - 2016-05-03 22:18:52 --> Security Class Initialized
DEBUG - 2016-05-03 22:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:18:52 --> Input Class Initialized
INFO - 2016-05-03 22:18:52 --> Language Class Initialized
INFO - 2016-05-03 22:18:52 --> Loader Class Initialized
INFO - 2016-05-03 22:18:52 --> Helper loaded: url_helper
INFO - 2016-05-03 22:18:52 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:18:52 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:18:52 --> Helper loaded: form_helper
INFO - 2016-05-03 22:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:18:52 --> Form Validation Class Initialized
INFO - 2016-05-03 22:18:52 --> Controller Class Initialized
INFO - 2016-05-03 22:18:52 --> Model Class Initialized
INFO - 2016-05-03 22:18:52 --> Database Driver Class Initialized
INFO - 2016-05-03 22:18:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:18:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:18:52 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:18:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:18:52 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 22:18:52 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 29
INFO - 2016-05-03 22:19:03 --> Config Class Initialized
INFO - 2016-05-03 22:19:03 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:19:03 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:19:03 --> Utf8 Class Initialized
INFO - 2016-05-03 22:19:03 --> URI Class Initialized
INFO - 2016-05-03 22:19:03 --> Router Class Initialized
INFO - 2016-05-03 22:19:03 --> Output Class Initialized
INFO - 2016-05-03 22:19:03 --> Security Class Initialized
DEBUG - 2016-05-03 22:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:19:03 --> Input Class Initialized
INFO - 2016-05-03 22:19:03 --> Language Class Initialized
INFO - 2016-05-03 22:19:03 --> Loader Class Initialized
INFO - 2016-05-03 22:19:03 --> Helper loaded: url_helper
INFO - 2016-05-03 22:19:03 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:19:03 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:19:03 --> Helper loaded: form_helper
INFO - 2016-05-03 22:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:19:03 --> Form Validation Class Initialized
INFO - 2016-05-03 22:19:03 --> Controller Class Initialized
INFO - 2016-05-03 22:19:03 --> Model Class Initialized
INFO - 2016-05-03 22:19:03 --> Database Driver Class Initialized
INFO - 2016-05-03 22:19:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:19:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:19:03 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:19:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:19:03 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:19:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:19:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:19:03 --> Final output sent to browser
DEBUG - 2016-05-03 22:19:03 --> Total execution time: 0.1926
INFO - 2016-05-03 22:19:10 --> Config Class Initialized
INFO - 2016-05-03 22:19:10 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:19:10 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:19:10 --> Utf8 Class Initialized
INFO - 2016-05-03 22:19:10 --> URI Class Initialized
INFO - 2016-05-03 22:19:11 --> Router Class Initialized
INFO - 2016-05-03 22:19:11 --> Output Class Initialized
INFO - 2016-05-03 22:19:11 --> Security Class Initialized
DEBUG - 2016-05-03 22:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:19:11 --> Input Class Initialized
INFO - 2016-05-03 22:19:11 --> Language Class Initialized
INFO - 2016-05-03 22:19:11 --> Loader Class Initialized
INFO - 2016-05-03 22:19:11 --> Helper loaded: url_helper
INFO - 2016-05-03 22:19:11 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:19:11 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:19:11 --> Helper loaded: form_helper
INFO - 2016-05-03 22:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:19:11 --> Form Validation Class Initialized
INFO - 2016-05-03 22:19:11 --> Controller Class Initialized
INFO - 2016-05-03 22:19:11 --> Model Class Initialized
INFO - 2016-05-03 22:19:11 --> Database Driver Class Initialized
INFO - 2016-05-03 22:19:11 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:19:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:19:11 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:19:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:19:11 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:19:11 --> Config Class Initialized
INFO - 2016-05-03 22:19:11 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:19:11 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:19:11 --> Utf8 Class Initialized
INFO - 2016-05-03 22:19:11 --> URI Class Initialized
INFO - 2016-05-03 22:19:11 --> Router Class Initialized
INFO - 2016-05-03 22:19:11 --> Output Class Initialized
INFO - 2016-05-03 22:19:11 --> Security Class Initialized
DEBUG - 2016-05-03 22:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:19:11 --> Input Class Initialized
INFO - 2016-05-03 22:19:11 --> Language Class Initialized
INFO - 2016-05-03 22:19:11 --> Loader Class Initialized
INFO - 2016-05-03 22:19:11 --> Helper loaded: url_helper
INFO - 2016-05-03 22:19:11 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:19:11 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:19:11 --> Helper loaded: form_helper
INFO - 2016-05-03 22:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:19:11 --> Form Validation Class Initialized
INFO - 2016-05-03 22:19:11 --> Controller Class Initialized
INFO - 2016-05-03 22:19:11 --> Model Class Initialized
INFO - 2016-05-03 22:19:11 --> Database Driver Class Initialized
INFO - 2016-05-03 22:19:11 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:19:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:19:11 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:19:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:19:11 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:19:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:19:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:19:11 --> Final output sent to browser
DEBUG - 2016-05-03 22:19:11 --> Total execution time: 0.1002
INFO - 2016-05-03 22:19:12 --> Config Class Initialized
INFO - 2016-05-03 22:19:12 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:19:12 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:19:12 --> Utf8 Class Initialized
INFO - 2016-05-03 22:19:12 --> URI Class Initialized
INFO - 2016-05-03 22:19:12 --> Router Class Initialized
INFO - 2016-05-03 22:19:12 --> Output Class Initialized
INFO - 2016-05-03 22:19:12 --> Security Class Initialized
DEBUG - 2016-05-03 22:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:19:12 --> Input Class Initialized
INFO - 2016-05-03 22:19:12 --> Language Class Initialized
INFO - 2016-05-03 22:19:12 --> Loader Class Initialized
INFO - 2016-05-03 22:19:12 --> Helper loaded: url_helper
INFO - 2016-05-03 22:19:12 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:19:12 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:19:12 --> Helper loaded: form_helper
INFO - 2016-05-03 22:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:19:12 --> Form Validation Class Initialized
INFO - 2016-05-03 22:19:12 --> Controller Class Initialized
INFO - 2016-05-03 22:19:12 --> Model Class Initialized
INFO - 2016-05-03 22:19:12 --> Database Driver Class Initialized
INFO - 2016-05-03 22:19:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:19:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:19:12 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:19:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:19:12 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:19:12 --> Config Class Initialized
INFO - 2016-05-03 22:19:12 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:19:12 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:19:12 --> Utf8 Class Initialized
INFO - 2016-05-03 22:19:12 --> URI Class Initialized
INFO - 2016-05-03 22:19:12 --> Router Class Initialized
INFO - 2016-05-03 22:19:12 --> Output Class Initialized
INFO - 2016-05-03 22:19:12 --> Security Class Initialized
DEBUG - 2016-05-03 22:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:19:12 --> Input Class Initialized
INFO - 2016-05-03 22:19:12 --> Language Class Initialized
INFO - 2016-05-03 22:19:12 --> Loader Class Initialized
INFO - 2016-05-03 22:19:12 --> Helper loaded: url_helper
INFO - 2016-05-03 22:19:12 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:19:12 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:19:12 --> Helper loaded: form_helper
INFO - 2016-05-03 22:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:19:12 --> Form Validation Class Initialized
INFO - 2016-05-03 22:19:12 --> Controller Class Initialized
INFO - 2016-05-03 22:19:12 --> Model Class Initialized
INFO - 2016-05-03 22:19:12 --> Database Driver Class Initialized
INFO - 2016-05-03 22:19:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:19:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:19:12 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:19:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:19:12 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:19:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:19:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:19:12 --> Final output sent to browser
DEBUG - 2016-05-03 22:19:12 --> Total execution time: 0.1026
INFO - 2016-05-03 22:19:20 --> Config Class Initialized
INFO - 2016-05-03 22:19:20 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:19:20 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:19:20 --> Utf8 Class Initialized
INFO - 2016-05-03 22:19:20 --> URI Class Initialized
INFO - 2016-05-03 22:19:21 --> Router Class Initialized
INFO - 2016-05-03 22:19:21 --> Output Class Initialized
INFO - 2016-05-03 22:19:21 --> Security Class Initialized
DEBUG - 2016-05-03 22:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:19:21 --> Input Class Initialized
INFO - 2016-05-03 22:19:21 --> Language Class Initialized
INFO - 2016-05-03 22:19:21 --> Loader Class Initialized
INFO - 2016-05-03 22:19:21 --> Helper loaded: url_helper
INFO - 2016-05-03 22:19:21 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:19:21 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:19:21 --> Helper loaded: form_helper
INFO - 2016-05-03 22:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:19:21 --> Form Validation Class Initialized
INFO - 2016-05-03 22:19:21 --> Controller Class Initialized
INFO - 2016-05-03 22:19:21 --> Model Class Initialized
INFO - 2016-05-03 22:19:21 --> Database Driver Class Initialized
INFO - 2016-05-03 22:19:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:19:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:19:21 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:19:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:19:21 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:19:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:19:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:19:21 --> Final output sent to browser
DEBUG - 2016-05-03 22:19:21 --> Total execution time: 0.1237
INFO - 2016-05-03 22:19:48 --> Config Class Initialized
INFO - 2016-05-03 22:19:48 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:19:48 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:19:48 --> Utf8 Class Initialized
INFO - 2016-05-03 22:19:48 --> URI Class Initialized
INFO - 2016-05-03 22:19:48 --> Router Class Initialized
INFO - 2016-05-03 22:19:48 --> Output Class Initialized
INFO - 2016-05-03 22:19:48 --> Security Class Initialized
DEBUG - 2016-05-03 22:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:19:48 --> Input Class Initialized
INFO - 2016-05-03 22:19:48 --> Language Class Initialized
INFO - 2016-05-03 22:19:48 --> Loader Class Initialized
INFO - 2016-05-03 22:19:48 --> Helper loaded: url_helper
INFO - 2016-05-03 22:19:48 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:19:48 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:19:48 --> Helper loaded: form_helper
INFO - 2016-05-03 22:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:19:48 --> Form Validation Class Initialized
INFO - 2016-05-03 22:19:48 --> Controller Class Initialized
INFO - 2016-05-03 22:19:48 --> Model Class Initialized
INFO - 2016-05-03 22:19:48 --> Database Driver Class Initialized
INFO - 2016-05-03 22:19:48 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:19:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:19:48 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:19:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:19:48 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:19:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:19:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:19:48 --> Final output sent to browser
DEBUG - 2016-05-03 22:19:48 --> Total execution time: 0.0780
INFO - 2016-05-03 22:21:39 --> Config Class Initialized
INFO - 2016-05-03 22:21:39 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:21:39 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:21:39 --> Utf8 Class Initialized
INFO - 2016-05-03 22:21:39 --> URI Class Initialized
INFO - 2016-05-03 22:21:39 --> Router Class Initialized
INFO - 2016-05-03 22:21:39 --> Output Class Initialized
INFO - 2016-05-03 22:21:39 --> Security Class Initialized
DEBUG - 2016-05-03 22:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:21:39 --> Input Class Initialized
INFO - 2016-05-03 22:21:39 --> Language Class Initialized
INFO - 2016-05-03 22:21:39 --> Loader Class Initialized
INFO - 2016-05-03 22:21:39 --> Helper loaded: url_helper
INFO - 2016-05-03 22:21:39 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:21:39 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:21:39 --> Helper loaded: form_helper
INFO - 2016-05-03 22:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:21:39 --> Form Validation Class Initialized
INFO - 2016-05-03 22:21:39 --> Controller Class Initialized
INFO - 2016-05-03 22:21:39 --> Model Class Initialized
INFO - 2016-05-03 22:21:39 --> Database Driver Class Initialized
INFO - 2016-05-03 22:21:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:21:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:21:39 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:21:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:21:39 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:21:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:21:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:21:39 --> Final output sent to browser
DEBUG - 2016-05-03 22:21:39 --> Total execution time: 0.0825
INFO - 2016-05-03 22:21:50 --> Config Class Initialized
INFO - 2016-05-03 22:21:50 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:21:50 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:21:50 --> Utf8 Class Initialized
INFO - 2016-05-03 22:21:50 --> URI Class Initialized
INFO - 2016-05-03 22:21:50 --> Router Class Initialized
INFO - 2016-05-03 22:21:50 --> Output Class Initialized
INFO - 2016-05-03 22:21:50 --> Security Class Initialized
DEBUG - 2016-05-03 22:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:21:50 --> Input Class Initialized
INFO - 2016-05-03 22:21:50 --> Language Class Initialized
INFO - 2016-05-03 22:21:50 --> Loader Class Initialized
INFO - 2016-05-03 22:21:50 --> Helper loaded: url_helper
INFO - 2016-05-03 22:21:50 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:21:50 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:21:50 --> Helper loaded: form_helper
INFO - 2016-05-03 22:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:21:50 --> Form Validation Class Initialized
INFO - 2016-05-03 22:21:50 --> Controller Class Initialized
INFO - 2016-05-03 22:21:50 --> Model Class Initialized
INFO - 2016-05-03 22:21:50 --> Database Driver Class Initialized
INFO - 2016-05-03 22:21:50 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:21:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:21:50 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:21:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:21:50 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:21:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:21:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:21:50 --> Final output sent to browser
DEBUG - 2016-05-03 22:21:50 --> Total execution time: 0.1016
INFO - 2016-05-03 22:21:54 --> Config Class Initialized
INFO - 2016-05-03 22:21:54 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:21:54 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:21:54 --> Utf8 Class Initialized
INFO - 2016-05-03 22:21:54 --> URI Class Initialized
INFO - 2016-05-03 22:21:54 --> Router Class Initialized
INFO - 2016-05-03 22:21:54 --> Output Class Initialized
INFO - 2016-05-03 22:21:54 --> Security Class Initialized
DEBUG - 2016-05-03 22:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:21:54 --> Input Class Initialized
INFO - 2016-05-03 22:21:54 --> Language Class Initialized
INFO - 2016-05-03 22:21:54 --> Loader Class Initialized
INFO - 2016-05-03 22:21:54 --> Helper loaded: url_helper
INFO - 2016-05-03 22:21:54 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:21:54 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:21:54 --> Helper loaded: form_helper
INFO - 2016-05-03 22:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:21:54 --> Form Validation Class Initialized
INFO - 2016-05-03 22:21:54 --> Controller Class Initialized
INFO - 2016-05-03 22:21:54 --> Model Class Initialized
INFO - 2016-05-03 22:21:54 --> Database Driver Class Initialized
INFO - 2016-05-03 22:21:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:21:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:21:54 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:21:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:21:54 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:21:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:21:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:21:54 --> Final output sent to browser
DEBUG - 2016-05-03 22:21:54 --> Total execution time: 0.0906
INFO - 2016-05-03 22:22:08 --> Config Class Initialized
INFO - 2016-05-03 22:22:08 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:22:08 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:22:08 --> Utf8 Class Initialized
INFO - 2016-05-03 22:22:08 --> URI Class Initialized
INFO - 2016-05-03 22:22:08 --> Router Class Initialized
INFO - 2016-05-03 22:22:08 --> Output Class Initialized
INFO - 2016-05-03 22:22:08 --> Security Class Initialized
DEBUG - 2016-05-03 22:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:22:08 --> Input Class Initialized
INFO - 2016-05-03 22:22:08 --> Language Class Initialized
INFO - 2016-05-03 22:22:08 --> Loader Class Initialized
INFO - 2016-05-03 22:22:08 --> Helper loaded: url_helper
INFO - 2016-05-03 22:22:08 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:22:08 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:22:08 --> Helper loaded: form_helper
INFO - 2016-05-03 22:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:22:08 --> Form Validation Class Initialized
INFO - 2016-05-03 22:22:08 --> Controller Class Initialized
INFO - 2016-05-03 22:22:08 --> Model Class Initialized
INFO - 2016-05-03 22:22:08 --> Database Driver Class Initialized
INFO - 2016-05-03 22:22:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:22:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:22:08 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:22:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:22:08 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:22:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:22:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:22:08 --> Final output sent to browser
DEBUG - 2016-05-03 22:22:08 --> Total execution time: 0.0780
INFO - 2016-05-03 22:23:34 --> Config Class Initialized
INFO - 2016-05-03 22:23:34 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:23:34 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:23:34 --> Utf8 Class Initialized
INFO - 2016-05-03 22:23:34 --> URI Class Initialized
INFO - 2016-05-03 22:23:34 --> Router Class Initialized
INFO - 2016-05-03 22:23:34 --> Output Class Initialized
INFO - 2016-05-03 22:23:34 --> Security Class Initialized
DEBUG - 2016-05-03 22:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:23:34 --> Input Class Initialized
INFO - 2016-05-03 22:23:34 --> Language Class Initialized
INFO - 2016-05-03 22:23:34 --> Loader Class Initialized
INFO - 2016-05-03 22:23:34 --> Helper loaded: url_helper
INFO - 2016-05-03 22:23:34 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:23:34 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:23:34 --> Helper loaded: form_helper
INFO - 2016-05-03 22:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:23:34 --> Form Validation Class Initialized
INFO - 2016-05-03 22:23:34 --> Controller Class Initialized
INFO - 2016-05-03 22:23:34 --> Model Class Initialized
INFO - 2016-05-03 22:23:34 --> Database Driver Class Initialized
INFO - 2016-05-03 22:23:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:23:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:23:34 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:23:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:23:34 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:23:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:23:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:23:34 --> Final output sent to browser
DEBUG - 2016-05-03 22:23:34 --> Total execution time: 0.0841
INFO - 2016-05-03 22:35:00 --> Config Class Initialized
INFO - 2016-05-03 22:35:00 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:35:00 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:35:00 --> Utf8 Class Initialized
INFO - 2016-05-03 22:35:00 --> URI Class Initialized
INFO - 2016-05-03 22:35:00 --> Router Class Initialized
INFO - 2016-05-03 22:35:00 --> Output Class Initialized
INFO - 2016-05-03 22:35:00 --> Security Class Initialized
DEBUG - 2016-05-03 22:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:35:00 --> Input Class Initialized
INFO - 2016-05-03 22:35:00 --> Language Class Initialized
INFO - 2016-05-03 22:35:00 --> Loader Class Initialized
INFO - 2016-05-03 22:35:00 --> Helper loaded: url_helper
INFO - 2016-05-03 22:35:00 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:35:00 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:35:00 --> Helper loaded: form_helper
INFO - 2016-05-03 22:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:35:00 --> Form Validation Class Initialized
INFO - 2016-05-03 22:35:00 --> Controller Class Initialized
INFO - 2016-05-03 22:35:00 --> Model Class Initialized
INFO - 2016-05-03 22:35:00 --> Database Driver Class Initialized
INFO - 2016-05-03 22:35:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:35:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:35:00 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:35:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:35:00 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 22:35:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'idProvincia = (select idProvincia from provincia where nombre LIKE 'madrid')' at line 1 - Invalid query: SELECT count(*) 'cont' FROM proveedor WHERE nombre LIKE '%madrid%' OR nif LIKE '%madrid%' OR correo LIKE '%madrid%' OR telefono LIKE '%madrid%' OR direccion LIKE '%madrid%' OR localidad LIKE '%madrid%' OR cp LIKE '%madrid%' OR anotaciones LIKE '%madrid%' OR estado LIKE '%madrid%' idProvincia = (select idProvincia from provincia where nombre LIKE 'madrid')
INFO - 2016-05-03 22:35:00 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-03 22:35:20 --> Config Class Initialized
INFO - 2016-05-03 22:35:20 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:35:20 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:35:20 --> Utf8 Class Initialized
INFO - 2016-05-03 22:35:20 --> URI Class Initialized
INFO - 2016-05-03 22:35:20 --> Router Class Initialized
INFO - 2016-05-03 22:35:20 --> Output Class Initialized
INFO - 2016-05-03 22:35:20 --> Security Class Initialized
DEBUG - 2016-05-03 22:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:35:20 --> Input Class Initialized
INFO - 2016-05-03 22:35:20 --> Language Class Initialized
INFO - 2016-05-03 22:35:20 --> Loader Class Initialized
INFO - 2016-05-03 22:35:20 --> Helper loaded: url_helper
INFO - 2016-05-03 22:35:20 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:35:20 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:35:20 --> Helper loaded: form_helper
INFO - 2016-05-03 22:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:35:20 --> Form Validation Class Initialized
INFO - 2016-05-03 22:35:20 --> Controller Class Initialized
INFO - 2016-05-03 22:35:20 --> Model Class Initialized
INFO - 2016-05-03 22:35:20 --> Database Driver Class Initialized
INFO - 2016-05-03 22:35:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:35:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:35:20 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:35:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:35:20 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:35:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:35:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:35:20 --> Final output sent to browser
DEBUG - 2016-05-03 22:35:20 --> Total execution time: 0.1062
INFO - 2016-05-03 22:37:51 --> Config Class Initialized
INFO - 2016-05-03 22:37:51 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:37:51 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:37:51 --> Utf8 Class Initialized
INFO - 2016-05-03 22:37:51 --> URI Class Initialized
INFO - 2016-05-03 22:37:51 --> Router Class Initialized
INFO - 2016-05-03 22:37:51 --> Output Class Initialized
INFO - 2016-05-03 22:37:51 --> Security Class Initialized
DEBUG - 2016-05-03 22:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:37:51 --> Input Class Initialized
INFO - 2016-05-03 22:37:51 --> Language Class Initialized
INFO - 2016-05-03 22:37:51 --> Loader Class Initialized
INFO - 2016-05-03 22:37:51 --> Helper loaded: url_helper
INFO - 2016-05-03 22:37:51 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:37:51 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:37:51 --> Helper loaded: form_helper
INFO - 2016-05-03 22:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:37:51 --> Form Validation Class Initialized
INFO - 2016-05-03 22:37:51 --> Controller Class Initialized
INFO - 2016-05-03 22:37:51 --> Model Class Initialized
INFO - 2016-05-03 22:37:51 --> Database Driver Class Initialized
INFO - 2016-05-03 22:37:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:37:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:37:51 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:37:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:37:51 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:37:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:37:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:37:51 --> Final output sent to browser
DEBUG - 2016-05-03 22:37:51 --> Total execution time: 0.0958
INFO - 2016-05-03 22:38:03 --> Config Class Initialized
INFO - 2016-05-03 22:38:03 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:38:03 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:38:03 --> Utf8 Class Initialized
INFO - 2016-05-03 22:38:03 --> URI Class Initialized
INFO - 2016-05-03 22:38:03 --> Router Class Initialized
INFO - 2016-05-03 22:38:03 --> Output Class Initialized
INFO - 2016-05-03 22:38:03 --> Security Class Initialized
DEBUG - 2016-05-03 22:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:38:03 --> Input Class Initialized
INFO - 2016-05-03 22:38:03 --> Language Class Initialized
INFO - 2016-05-03 22:38:03 --> Loader Class Initialized
INFO - 2016-05-03 22:38:03 --> Helper loaded: url_helper
INFO - 2016-05-03 22:38:03 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:38:03 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:38:03 --> Helper loaded: form_helper
INFO - 2016-05-03 22:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:38:03 --> Form Validation Class Initialized
INFO - 2016-05-03 22:38:03 --> Controller Class Initialized
INFO - 2016-05-03 22:38:03 --> Model Class Initialized
INFO - 2016-05-03 22:38:03 --> Database Driver Class Initialized
INFO - 2016-05-03 22:38:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:38:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:38:03 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:38:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:38:03 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:38:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:38:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:38:03 --> Final output sent to browser
DEBUG - 2016-05-03 22:38:03 --> Total execution time: 0.1105
INFO - 2016-05-03 22:39:13 --> Config Class Initialized
INFO - 2016-05-03 22:39:13 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:39:13 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:39:13 --> Utf8 Class Initialized
INFO - 2016-05-03 22:39:13 --> URI Class Initialized
INFO - 2016-05-03 22:39:14 --> Router Class Initialized
INFO - 2016-05-03 22:39:14 --> Output Class Initialized
INFO - 2016-05-03 22:39:14 --> Security Class Initialized
DEBUG - 2016-05-03 22:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:39:14 --> Input Class Initialized
INFO - 2016-05-03 22:39:14 --> Language Class Initialized
INFO - 2016-05-03 22:39:14 --> Loader Class Initialized
INFO - 2016-05-03 22:39:14 --> Helper loaded: url_helper
INFO - 2016-05-03 22:39:14 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:39:14 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:39:14 --> Helper loaded: form_helper
INFO - 2016-05-03 22:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:39:14 --> Form Validation Class Initialized
INFO - 2016-05-03 22:39:14 --> Controller Class Initialized
INFO - 2016-05-03 22:39:14 --> Model Class Initialized
INFO - 2016-05-03 22:39:14 --> Database Driver Class Initialized
INFO - 2016-05-03 22:39:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:39:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:39:14 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:39:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:39:14 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-03 22:39:14 --> Severity: Notice --> Undefined variable: select C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 150
INFO - 2016-05-03 22:39:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:39:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:39:14 --> Final output sent to browser
DEBUG - 2016-05-03 22:39:14 --> Total execution time: 0.2161
INFO - 2016-05-03 22:39:21 --> Config Class Initialized
INFO - 2016-05-03 22:39:21 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:39:21 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:39:21 --> Utf8 Class Initialized
INFO - 2016-05-03 22:39:21 --> URI Class Initialized
INFO - 2016-05-03 22:39:21 --> Router Class Initialized
INFO - 2016-05-03 22:39:21 --> Output Class Initialized
INFO - 2016-05-03 22:39:21 --> Security Class Initialized
DEBUG - 2016-05-03 22:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:39:21 --> Input Class Initialized
INFO - 2016-05-03 22:39:21 --> Language Class Initialized
INFO - 2016-05-03 22:39:21 --> Loader Class Initialized
INFO - 2016-05-03 22:39:21 --> Helper loaded: url_helper
INFO - 2016-05-03 22:39:21 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:39:21 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:39:21 --> Helper loaded: form_helper
INFO - 2016-05-03 22:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:39:21 --> Form Validation Class Initialized
INFO - 2016-05-03 22:39:21 --> Controller Class Initialized
INFO - 2016-05-03 22:39:21 --> Model Class Initialized
INFO - 2016-05-03 22:39:21 --> Database Driver Class Initialized
INFO - 2016-05-03 22:39:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:39:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:39:21 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:39:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:39:21 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:39:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:39:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:39:21 --> Final output sent to browser
DEBUG - 2016-05-03 22:39:21 --> Total execution time: 0.0918
INFO - 2016-05-03 22:39:25 --> Config Class Initialized
INFO - 2016-05-03 22:39:25 --> Hooks Class Initialized
DEBUG - 2016-05-03 22:39:25 --> UTF-8 Support Enabled
INFO - 2016-05-03 22:39:25 --> Utf8 Class Initialized
INFO - 2016-05-03 22:39:25 --> URI Class Initialized
INFO - 2016-05-03 22:39:25 --> Router Class Initialized
INFO - 2016-05-03 22:39:25 --> Output Class Initialized
INFO - 2016-05-03 22:39:25 --> Security Class Initialized
DEBUG - 2016-05-03 22:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-03 22:39:25 --> Input Class Initialized
INFO - 2016-05-03 22:39:25 --> Language Class Initialized
INFO - 2016-05-03 22:39:25 --> Loader Class Initialized
INFO - 2016-05-03 22:39:25 --> Helper loaded: url_helper
INFO - 2016-05-03 22:39:25 --> Helper loaded: sesion_helper
INFO - 2016-05-03 22:39:25 --> Helper loaded: templates_helper
INFO - 2016-05-03 22:39:25 --> Helper loaded: form_helper
INFO - 2016-05-03 22:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-03 22:39:25 --> Form Validation Class Initialized
INFO - 2016-05-03 22:39:25 --> Controller Class Initialized
INFO - 2016-05-03 22:39:25 --> Model Class Initialized
INFO - 2016-05-03 22:39:25 --> Database Driver Class Initialized
INFO - 2016-05-03 22:39:25 --> Helper loaded: creaselect_helper
INFO - 2016-05-03 22:39:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-03 22:39:25 --> Pagination Class Initialized
DEBUG - 2016-05-03 22:39:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-03 22:39:25 --> Helper loaded: nif_validate_helper
INFO - 2016-05-03 22:39:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-03 22:39:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-03 22:39:25 --> Final output sent to browser
DEBUG - 2016-05-03 22:39:25 --> Total execution time: 0.0996
