<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

//CSS propio 
$config['css'] = '<h1>PROBANDO</h1>';

$config['main_menu']['agregar_proveedor'] = "";
