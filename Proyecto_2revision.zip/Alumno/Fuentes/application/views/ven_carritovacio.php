<div class="row text-center">

    <img class="img-responsive imagen-centrada" src="<?= base_url() . 'assets/images/carrito.jpg' ?>">
    <h1 class="text-center" style="color: red;">¡El carrito está vacío!</h1>                

</div>