<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-20 19:05:42 --> Config Class Initialized
INFO - 2016-05-20 19:05:42 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:05:42 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:05:42 --> Utf8 Class Initialized
INFO - 2016-05-20 19:05:42 --> URI Class Initialized
INFO - 2016-05-20 19:05:42 --> Router Class Initialized
INFO - 2016-05-20 19:05:42 --> Output Class Initialized
INFO - 2016-05-20 19:05:42 --> Security Class Initialized
DEBUG - 2016-05-20 19:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:05:42 --> Input Class Initialized
INFO - 2016-05-20 19:05:42 --> Language Class Initialized
INFO - 2016-05-20 19:05:42 --> Loader Class Initialized
INFO - 2016-05-20 19:05:42 --> Helper loaded: url_helper
INFO - 2016-05-20 19:05:42 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:05:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:05:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:05:42 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:05:42 --> Helper loaded: form_helper
INFO - 2016-05-20 19:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:05:42 --> Form Validation Class Initialized
INFO - 2016-05-20 19:05:42 --> Controller Class Initialized
INFO - 2016-05-20 19:05:42 --> Config Class Initialized
INFO - 2016-05-20 19:05:42 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:05:42 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:05:42 --> Utf8 Class Initialized
INFO - 2016-05-20 19:05:42 --> URI Class Initialized
INFO - 2016-05-20 19:05:42 --> Router Class Initialized
INFO - 2016-05-20 19:05:42 --> Output Class Initialized
INFO - 2016-05-20 19:05:42 --> Security Class Initialized
DEBUG - 2016-05-20 19:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:05:42 --> Input Class Initialized
INFO - 2016-05-20 19:05:42 --> Language Class Initialized
INFO - 2016-05-20 19:05:42 --> Loader Class Initialized
INFO - 2016-05-20 19:05:42 --> Helper loaded: url_helper
INFO - 2016-05-20 19:05:42 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:05:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:05:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:05:42 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:05:42 --> Helper loaded: form_helper
INFO - 2016-05-20 19:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:05:42 --> Form Validation Class Initialized
INFO - 2016-05-20 19:05:42 --> Controller Class Initialized
INFO - 2016-05-20 19:05:42 --> Model Class Initialized
INFO - 2016-05-20 19:05:42 --> Database Driver Class Initialized
INFO - 2016-05-20 19:05:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-20 19:05:42 --> Final output sent to browser
DEBUG - 2016-05-20 19:05:42 --> Total execution time: 0.0984
INFO - 2016-05-20 19:05:51 --> Config Class Initialized
INFO - 2016-05-20 19:05:51 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:05:51 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:05:51 --> Utf8 Class Initialized
INFO - 2016-05-20 19:05:51 --> URI Class Initialized
INFO - 2016-05-20 19:05:51 --> Router Class Initialized
INFO - 2016-05-20 19:05:51 --> Output Class Initialized
INFO - 2016-05-20 19:05:51 --> Security Class Initialized
DEBUG - 2016-05-20 19:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:05:51 --> Input Class Initialized
INFO - 2016-05-20 19:05:51 --> Language Class Initialized
INFO - 2016-05-20 19:05:51 --> Loader Class Initialized
INFO - 2016-05-20 19:05:51 --> Helper loaded: url_helper
INFO - 2016-05-20 19:05:51 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:05:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:05:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:05:51 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:05:51 --> Helper loaded: form_helper
INFO - 2016-05-20 19:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:05:51 --> Form Validation Class Initialized
INFO - 2016-05-20 19:05:51 --> Controller Class Initialized
INFO - 2016-05-20 19:05:51 --> Model Class Initialized
INFO - 2016-05-20 19:05:51 --> Database Driver Class Initialized
INFO - 2016-05-20 19:05:52 --> Config Class Initialized
INFO - 2016-05-20 19:05:52 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:05:52 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:05:52 --> Utf8 Class Initialized
INFO - 2016-05-20 19:05:52 --> URI Class Initialized
INFO - 2016-05-20 19:05:52 --> Router Class Initialized
INFO - 2016-05-20 19:05:52 --> Output Class Initialized
INFO - 2016-05-20 19:05:52 --> Security Class Initialized
DEBUG - 2016-05-20 19:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:05:52 --> Input Class Initialized
INFO - 2016-05-20 19:05:52 --> Language Class Initialized
INFO - 2016-05-20 19:05:52 --> Loader Class Initialized
INFO - 2016-05-20 19:05:52 --> Helper loaded: url_helper
INFO - 2016-05-20 19:05:52 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:05:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:05:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:05:52 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:05:52 --> Helper loaded: form_helper
INFO - 2016-05-20 19:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:05:52 --> Form Validation Class Initialized
INFO - 2016-05-20 19:05:52 --> Controller Class Initialized
INFO - 2016-05-20 19:05:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:05:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:05:52 --> Final output sent to browser
DEBUG - 2016-05-20 19:05:52 --> Total execution time: 0.0515
INFO - 2016-05-20 19:05:53 --> Config Class Initialized
INFO - 2016-05-20 19:05:53 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:05:53 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:05:53 --> Utf8 Class Initialized
INFO - 2016-05-20 19:05:53 --> URI Class Initialized
INFO - 2016-05-20 19:05:53 --> Router Class Initialized
INFO - 2016-05-20 19:05:53 --> Output Class Initialized
INFO - 2016-05-20 19:05:53 --> Security Class Initialized
DEBUG - 2016-05-20 19:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:05:53 --> Input Class Initialized
INFO - 2016-05-20 19:05:53 --> Language Class Initialized
INFO - 2016-05-20 19:05:53 --> Loader Class Initialized
INFO - 2016-05-20 19:05:53 --> Helper loaded: url_helper
INFO - 2016-05-20 19:05:53 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:05:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:05:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:05:53 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:05:53 --> Helper loaded: form_helper
INFO - 2016-05-20 19:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:05:53 --> Form Validation Class Initialized
INFO - 2016-05-20 19:05:53 --> Controller Class Initialized
INFO - 2016-05-20 19:05:53 --> Model Class Initialized
INFO - 2016-05-20 19:05:53 --> Database Driver Class Initialized
INFO - 2016-05-20 19:05:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:05:53 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:05:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:05:53 --> Final output sent to browser
DEBUG - 2016-05-20 19:05:53 --> Total execution time: 0.1324
INFO - 2016-05-20 19:08:07 --> Config Class Initialized
INFO - 2016-05-20 19:08:07 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:08:07 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:08:07 --> Utf8 Class Initialized
INFO - 2016-05-20 19:08:07 --> URI Class Initialized
INFO - 2016-05-20 19:08:07 --> Router Class Initialized
INFO - 2016-05-20 19:08:07 --> Output Class Initialized
INFO - 2016-05-20 19:08:07 --> Security Class Initialized
DEBUG - 2016-05-20 19:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:08:07 --> Input Class Initialized
INFO - 2016-05-20 19:08:07 --> Language Class Initialized
INFO - 2016-05-20 19:08:07 --> Loader Class Initialized
INFO - 2016-05-20 19:08:07 --> Helper loaded: url_helper
INFO - 2016-05-20 19:08:07 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:08:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:08:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:08:07 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:08:07 --> Helper loaded: form_helper
INFO - 2016-05-20 19:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:08:07 --> Form Validation Class Initialized
INFO - 2016-05-20 19:08:07 --> Controller Class Initialized
INFO - 2016-05-20 19:08:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:08:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:08:07 --> Final output sent to browser
DEBUG - 2016-05-20 19:08:07 --> Total execution time: 0.0552
INFO - 2016-05-20 19:08:07 --> Config Class Initialized
INFO - 2016-05-20 19:08:07 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:08:07 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:08:07 --> Utf8 Class Initialized
INFO - 2016-05-20 19:08:07 --> URI Class Initialized
INFO - 2016-05-20 19:08:07 --> Router Class Initialized
INFO - 2016-05-20 19:08:07 --> Output Class Initialized
INFO - 2016-05-20 19:08:07 --> Security Class Initialized
DEBUG - 2016-05-20 19:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:08:07 --> Input Class Initialized
INFO - 2016-05-20 19:08:07 --> Language Class Initialized
INFO - 2016-05-20 19:08:07 --> Loader Class Initialized
INFO - 2016-05-20 19:08:07 --> Helper loaded: url_helper
INFO - 2016-05-20 19:08:07 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:08:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:08:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:08:07 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:08:07 --> Helper loaded: form_helper
INFO - 2016-05-20 19:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:08:07 --> Form Validation Class Initialized
INFO - 2016-05-20 19:08:07 --> Controller Class Initialized
INFO - 2016-05-20 19:08:07 --> Model Class Initialized
INFO - 2016-05-20 19:08:07 --> Database Driver Class Initialized
INFO - 2016-05-20 19:08:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:08:07 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:08:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:08:07 --> Final output sent to browser
DEBUG - 2016-05-20 19:08:07 --> Total execution time: 0.0950
INFO - 2016-05-20 19:08:20 --> Config Class Initialized
INFO - 2016-05-20 19:08:20 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:08:20 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:08:20 --> Utf8 Class Initialized
INFO - 2016-05-20 19:08:20 --> URI Class Initialized
INFO - 2016-05-20 19:08:20 --> Router Class Initialized
INFO - 2016-05-20 19:08:20 --> Output Class Initialized
INFO - 2016-05-20 19:08:20 --> Security Class Initialized
DEBUG - 2016-05-20 19:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:08:20 --> Input Class Initialized
INFO - 2016-05-20 19:08:20 --> Language Class Initialized
INFO - 2016-05-20 19:08:20 --> Loader Class Initialized
INFO - 2016-05-20 19:08:20 --> Helper loaded: url_helper
INFO - 2016-05-20 19:08:20 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:08:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:08:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:08:20 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:08:20 --> Helper loaded: form_helper
INFO - 2016-05-20 19:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:08:20 --> Form Validation Class Initialized
INFO - 2016-05-20 19:08:20 --> Controller Class Initialized
INFO - 2016-05-20 19:08:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:08:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:08:20 --> Final output sent to browser
DEBUG - 2016-05-20 19:08:20 --> Total execution time: 0.0618
INFO - 2016-05-20 19:08:21 --> Config Class Initialized
INFO - 2016-05-20 19:08:21 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:08:21 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:08:21 --> Utf8 Class Initialized
INFO - 2016-05-20 19:08:21 --> URI Class Initialized
INFO - 2016-05-20 19:08:21 --> Router Class Initialized
INFO - 2016-05-20 19:08:21 --> Output Class Initialized
INFO - 2016-05-20 19:08:21 --> Security Class Initialized
DEBUG - 2016-05-20 19:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:08:21 --> Input Class Initialized
INFO - 2016-05-20 19:08:21 --> Language Class Initialized
INFO - 2016-05-20 19:08:21 --> Loader Class Initialized
INFO - 2016-05-20 19:08:21 --> Helper loaded: url_helper
INFO - 2016-05-20 19:08:21 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:08:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:08:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:08:21 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:08:21 --> Helper loaded: form_helper
INFO - 2016-05-20 19:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:08:21 --> Form Validation Class Initialized
INFO - 2016-05-20 19:08:21 --> Controller Class Initialized
INFO - 2016-05-20 19:08:21 --> Model Class Initialized
INFO - 2016-05-20 19:08:21 --> Database Driver Class Initialized
INFO - 2016-05-20 19:08:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:08:21 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:08:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:08:21 --> Final output sent to browser
DEBUG - 2016-05-20 19:08:21 --> Total execution time: 0.0982
INFO - 2016-05-20 19:08:22 --> Config Class Initialized
INFO - 2016-05-20 19:08:22 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:08:22 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:08:22 --> Utf8 Class Initialized
INFO - 2016-05-20 19:08:22 --> URI Class Initialized
INFO - 2016-05-20 19:08:22 --> Router Class Initialized
INFO - 2016-05-20 19:08:22 --> Output Class Initialized
INFO - 2016-05-20 19:08:22 --> Security Class Initialized
DEBUG - 2016-05-20 19:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:08:22 --> Input Class Initialized
INFO - 2016-05-20 19:08:22 --> Language Class Initialized
INFO - 2016-05-20 19:08:22 --> Loader Class Initialized
INFO - 2016-05-20 19:08:22 --> Helper loaded: url_helper
INFO - 2016-05-20 19:08:22 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:08:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:08:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:08:22 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:08:22 --> Helper loaded: form_helper
INFO - 2016-05-20 19:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:08:22 --> Form Validation Class Initialized
INFO - 2016-05-20 19:08:22 --> Controller Class Initialized
INFO - 2016-05-20 19:08:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:08:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:08:22 --> Final output sent to browser
DEBUG - 2016-05-20 19:08:22 --> Total execution time: 0.0557
INFO - 2016-05-20 19:08:23 --> Config Class Initialized
INFO - 2016-05-20 19:08:23 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:08:23 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:08:23 --> Utf8 Class Initialized
INFO - 2016-05-20 19:08:23 --> URI Class Initialized
INFO - 2016-05-20 19:08:23 --> Router Class Initialized
INFO - 2016-05-20 19:08:23 --> Output Class Initialized
INFO - 2016-05-20 19:08:23 --> Security Class Initialized
DEBUG - 2016-05-20 19:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:08:23 --> Input Class Initialized
INFO - 2016-05-20 19:08:23 --> Language Class Initialized
INFO - 2016-05-20 19:08:23 --> Loader Class Initialized
INFO - 2016-05-20 19:08:23 --> Helper loaded: url_helper
INFO - 2016-05-20 19:08:23 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:08:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:08:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:08:23 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:08:23 --> Helper loaded: form_helper
INFO - 2016-05-20 19:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:08:23 --> Form Validation Class Initialized
INFO - 2016-05-20 19:08:23 --> Controller Class Initialized
INFO - 2016-05-20 19:08:23 --> Model Class Initialized
INFO - 2016-05-20 19:08:23 --> Database Driver Class Initialized
INFO - 2016-05-20 19:08:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:08:23 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:08:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:08:23 --> Final output sent to browser
DEBUG - 2016-05-20 19:08:23 --> Total execution time: 0.1060
INFO - 2016-05-20 19:08:31 --> Config Class Initialized
INFO - 2016-05-20 19:08:31 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:08:31 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:08:31 --> Utf8 Class Initialized
INFO - 2016-05-20 19:08:31 --> URI Class Initialized
INFO - 2016-05-20 19:08:31 --> Router Class Initialized
INFO - 2016-05-20 19:08:31 --> Output Class Initialized
INFO - 2016-05-20 19:08:31 --> Security Class Initialized
DEBUG - 2016-05-20 19:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:08:31 --> Input Class Initialized
INFO - 2016-05-20 19:08:31 --> Language Class Initialized
INFO - 2016-05-20 19:08:31 --> Loader Class Initialized
INFO - 2016-05-20 19:08:31 --> Helper loaded: url_helper
INFO - 2016-05-20 19:08:31 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:08:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:08:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:08:31 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:08:31 --> Helper loaded: form_helper
INFO - 2016-05-20 19:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:08:31 --> Form Validation Class Initialized
INFO - 2016-05-20 19:08:31 --> Controller Class Initialized
INFO - 2016-05-20 19:08:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:08:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:08:31 --> Final output sent to browser
DEBUG - 2016-05-20 19:08:31 --> Total execution time: 0.0627
INFO - 2016-05-20 19:08:31 --> Config Class Initialized
INFO - 2016-05-20 19:08:31 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:08:31 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:08:31 --> Utf8 Class Initialized
INFO - 2016-05-20 19:08:31 --> URI Class Initialized
INFO - 2016-05-20 19:08:31 --> Router Class Initialized
INFO - 2016-05-20 19:08:31 --> Output Class Initialized
INFO - 2016-05-20 19:08:31 --> Security Class Initialized
DEBUG - 2016-05-20 19:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:08:31 --> Input Class Initialized
INFO - 2016-05-20 19:08:31 --> Language Class Initialized
INFO - 2016-05-20 19:08:31 --> Loader Class Initialized
INFO - 2016-05-20 19:08:31 --> Helper loaded: url_helper
INFO - 2016-05-20 19:08:31 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:08:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:08:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:08:31 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:08:31 --> Helper loaded: form_helper
INFO - 2016-05-20 19:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:08:31 --> Form Validation Class Initialized
INFO - 2016-05-20 19:08:31 --> Controller Class Initialized
INFO - 2016-05-20 19:08:31 --> Model Class Initialized
INFO - 2016-05-20 19:08:31 --> Database Driver Class Initialized
INFO - 2016-05-20 19:08:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:08:31 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:08:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:08:31 --> Final output sent to browser
DEBUG - 2016-05-20 19:08:31 --> Total execution time: 0.1199
INFO - 2016-05-20 19:09:31 --> Config Class Initialized
INFO - 2016-05-20 19:09:31 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:09:31 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:09:31 --> Utf8 Class Initialized
INFO - 2016-05-20 19:09:31 --> URI Class Initialized
INFO - 2016-05-20 19:09:31 --> Router Class Initialized
INFO - 2016-05-20 19:09:31 --> Output Class Initialized
INFO - 2016-05-20 19:09:31 --> Security Class Initialized
DEBUG - 2016-05-20 19:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:09:31 --> Input Class Initialized
INFO - 2016-05-20 19:09:31 --> Language Class Initialized
INFO - 2016-05-20 19:09:31 --> Loader Class Initialized
INFO - 2016-05-20 19:09:31 --> Helper loaded: url_helper
INFO - 2016-05-20 19:09:31 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:09:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:09:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:09:31 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:09:31 --> Helper loaded: form_helper
INFO - 2016-05-20 19:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:09:31 --> Form Validation Class Initialized
INFO - 2016-05-20 19:09:31 --> Controller Class Initialized
INFO - 2016-05-20 19:09:31 --> Model Class Initialized
INFO - 2016-05-20 19:09:31 --> Database Driver Class Initialized
INFO - 2016-05-20 19:09:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:09:31 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:09:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:09:31 --> Final output sent to browser
DEBUG - 2016-05-20 19:09:31 --> Total execution time: 0.0787
INFO - 2016-05-20 19:10:31 --> Config Class Initialized
INFO - 2016-05-20 19:10:31 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:10:31 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:10:31 --> Utf8 Class Initialized
INFO - 2016-05-20 19:10:31 --> URI Class Initialized
INFO - 2016-05-20 19:10:31 --> Router Class Initialized
INFO - 2016-05-20 19:10:31 --> Output Class Initialized
INFO - 2016-05-20 19:10:31 --> Security Class Initialized
DEBUG - 2016-05-20 19:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:10:31 --> Input Class Initialized
INFO - 2016-05-20 19:10:31 --> Language Class Initialized
INFO - 2016-05-20 19:10:31 --> Loader Class Initialized
INFO - 2016-05-20 19:10:31 --> Helper loaded: url_helper
INFO - 2016-05-20 19:10:31 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:10:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:10:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:10:31 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:10:31 --> Helper loaded: form_helper
INFO - 2016-05-20 19:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:10:31 --> Form Validation Class Initialized
INFO - 2016-05-20 19:10:31 --> Controller Class Initialized
INFO - 2016-05-20 19:10:31 --> Model Class Initialized
INFO - 2016-05-20 19:10:31 --> Database Driver Class Initialized
INFO - 2016-05-20 19:10:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:10:31 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:10:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:10:31 --> Final output sent to browser
DEBUG - 2016-05-20 19:10:31 --> Total execution time: 0.0787
INFO - 2016-05-20 19:11:31 --> Config Class Initialized
INFO - 2016-05-20 19:11:31 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:11:31 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:11:31 --> Utf8 Class Initialized
INFO - 2016-05-20 19:11:31 --> URI Class Initialized
INFO - 2016-05-20 19:11:31 --> Router Class Initialized
INFO - 2016-05-20 19:11:31 --> Output Class Initialized
INFO - 2016-05-20 19:11:31 --> Security Class Initialized
DEBUG - 2016-05-20 19:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:11:31 --> Input Class Initialized
INFO - 2016-05-20 19:11:31 --> Language Class Initialized
INFO - 2016-05-20 19:11:31 --> Loader Class Initialized
INFO - 2016-05-20 19:11:31 --> Helper loaded: url_helper
INFO - 2016-05-20 19:11:31 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:11:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:11:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:11:31 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:11:31 --> Helper loaded: form_helper
INFO - 2016-05-20 19:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:11:31 --> Form Validation Class Initialized
INFO - 2016-05-20 19:11:31 --> Controller Class Initialized
INFO - 2016-05-20 19:11:31 --> Model Class Initialized
INFO - 2016-05-20 19:11:31 --> Database Driver Class Initialized
INFO - 2016-05-20 19:11:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:11:31 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:11:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:11:31 --> Final output sent to browser
DEBUG - 2016-05-20 19:11:31 --> Total execution time: 0.1045
INFO - 2016-05-20 19:12:31 --> Config Class Initialized
INFO - 2016-05-20 19:12:31 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:12:31 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:12:31 --> Utf8 Class Initialized
INFO - 2016-05-20 19:12:31 --> URI Class Initialized
INFO - 2016-05-20 19:12:31 --> Router Class Initialized
INFO - 2016-05-20 19:12:31 --> Output Class Initialized
INFO - 2016-05-20 19:12:31 --> Security Class Initialized
DEBUG - 2016-05-20 19:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:12:31 --> Input Class Initialized
INFO - 2016-05-20 19:12:31 --> Language Class Initialized
INFO - 2016-05-20 19:12:31 --> Loader Class Initialized
INFO - 2016-05-20 19:12:31 --> Helper loaded: url_helper
INFO - 2016-05-20 19:12:31 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:12:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:12:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:12:31 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:12:31 --> Helper loaded: form_helper
INFO - 2016-05-20 19:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:12:31 --> Form Validation Class Initialized
INFO - 2016-05-20 19:12:31 --> Controller Class Initialized
INFO - 2016-05-20 19:12:31 --> Model Class Initialized
INFO - 2016-05-20 19:12:31 --> Database Driver Class Initialized
INFO - 2016-05-20 19:12:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:12:31 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:12:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:12:31 --> Final output sent to browser
DEBUG - 2016-05-20 19:12:31 --> Total execution time: 0.1223
INFO - 2016-05-20 19:13:31 --> Config Class Initialized
INFO - 2016-05-20 19:13:31 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:13:31 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:13:31 --> Utf8 Class Initialized
INFO - 2016-05-20 19:13:31 --> URI Class Initialized
INFO - 2016-05-20 19:13:31 --> Router Class Initialized
INFO - 2016-05-20 19:13:31 --> Output Class Initialized
INFO - 2016-05-20 19:13:31 --> Security Class Initialized
DEBUG - 2016-05-20 19:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:13:31 --> Input Class Initialized
INFO - 2016-05-20 19:13:31 --> Language Class Initialized
INFO - 2016-05-20 19:13:31 --> Loader Class Initialized
INFO - 2016-05-20 19:13:31 --> Helper loaded: url_helper
INFO - 2016-05-20 19:13:31 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:13:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:13:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:13:31 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:13:31 --> Helper loaded: form_helper
INFO - 2016-05-20 19:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:13:31 --> Form Validation Class Initialized
INFO - 2016-05-20 19:13:31 --> Controller Class Initialized
INFO - 2016-05-20 19:13:31 --> Model Class Initialized
INFO - 2016-05-20 19:13:31 --> Database Driver Class Initialized
INFO - 2016-05-20 19:13:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:13:31 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:13:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:13:31 --> Final output sent to browser
DEBUG - 2016-05-20 19:13:31 --> Total execution time: 0.1591
INFO - 2016-05-20 19:13:56 --> Config Class Initialized
INFO - 2016-05-20 19:13:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:13:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:13:56 --> Utf8 Class Initialized
INFO - 2016-05-20 19:13:56 --> URI Class Initialized
INFO - 2016-05-20 19:13:56 --> Router Class Initialized
INFO - 2016-05-20 19:13:56 --> Output Class Initialized
INFO - 2016-05-20 19:13:56 --> Security Class Initialized
DEBUG - 2016-05-20 19:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:13:56 --> Input Class Initialized
INFO - 2016-05-20 19:13:56 --> Language Class Initialized
INFO - 2016-05-20 19:13:56 --> Loader Class Initialized
INFO - 2016-05-20 19:13:56 --> Helper loaded: url_helper
INFO - 2016-05-20 19:13:56 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:13:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:13:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:13:56 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:13:56 --> Helper loaded: form_helper
INFO - 2016-05-20 19:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:13:56 --> Form Validation Class Initialized
INFO - 2016-05-20 19:13:56 --> Controller Class Initialized
INFO - 2016-05-20 19:13:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:13:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:13:56 --> Final output sent to browser
DEBUG - 2016-05-20 19:13:56 --> Total execution time: 0.0615
INFO - 2016-05-20 19:13:57 --> Config Class Initialized
INFO - 2016-05-20 19:13:57 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:13:57 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:13:57 --> Utf8 Class Initialized
INFO - 2016-05-20 19:13:57 --> URI Class Initialized
INFO - 2016-05-20 19:13:57 --> Router Class Initialized
INFO - 2016-05-20 19:13:57 --> Output Class Initialized
INFO - 2016-05-20 19:13:57 --> Security Class Initialized
DEBUG - 2016-05-20 19:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:13:57 --> Input Class Initialized
INFO - 2016-05-20 19:13:57 --> Language Class Initialized
INFO - 2016-05-20 19:13:57 --> Loader Class Initialized
INFO - 2016-05-20 19:13:57 --> Helper loaded: url_helper
INFO - 2016-05-20 19:13:57 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:13:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:13:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:13:57 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:13:57 --> Helper loaded: form_helper
INFO - 2016-05-20 19:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:13:57 --> Form Validation Class Initialized
INFO - 2016-05-20 19:13:57 --> Controller Class Initialized
INFO - 2016-05-20 19:13:57 --> Model Class Initialized
INFO - 2016-05-20 19:13:57 --> Database Driver Class Initialized
INFO - 2016-05-20 19:13:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:13:57 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:13:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:13:57 --> Final output sent to browser
DEBUG - 2016-05-20 19:13:57 --> Total execution time: 0.1001
INFO - 2016-05-20 19:13:58 --> Config Class Initialized
INFO - 2016-05-20 19:13:58 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:13:58 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:13:58 --> Utf8 Class Initialized
INFO - 2016-05-20 19:13:58 --> URI Class Initialized
INFO - 2016-05-20 19:13:58 --> Router Class Initialized
INFO - 2016-05-20 19:13:58 --> Output Class Initialized
INFO - 2016-05-20 19:13:58 --> Security Class Initialized
DEBUG - 2016-05-20 19:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:13:58 --> Input Class Initialized
INFO - 2016-05-20 19:13:58 --> Language Class Initialized
INFO - 2016-05-20 19:13:58 --> Loader Class Initialized
INFO - 2016-05-20 19:13:58 --> Helper loaded: url_helper
INFO - 2016-05-20 19:13:58 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:13:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:13:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:13:58 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:13:58 --> Helper loaded: form_helper
INFO - 2016-05-20 19:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:13:58 --> Form Validation Class Initialized
INFO - 2016-05-20 19:13:58 --> Controller Class Initialized
INFO - 2016-05-20 19:13:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:13:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:13:58 --> Final output sent to browser
DEBUG - 2016-05-20 19:13:58 --> Total execution time: 0.1037
INFO - 2016-05-20 19:13:58 --> Config Class Initialized
INFO - 2016-05-20 19:13:58 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:13:58 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:13:58 --> Utf8 Class Initialized
INFO - 2016-05-20 19:13:58 --> URI Class Initialized
INFO - 2016-05-20 19:13:58 --> Router Class Initialized
INFO - 2016-05-20 19:13:58 --> Output Class Initialized
INFO - 2016-05-20 19:13:58 --> Security Class Initialized
DEBUG - 2016-05-20 19:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:13:58 --> Input Class Initialized
INFO - 2016-05-20 19:13:58 --> Language Class Initialized
INFO - 2016-05-20 19:13:58 --> Loader Class Initialized
INFO - 2016-05-20 19:13:58 --> Helper loaded: url_helper
INFO - 2016-05-20 19:13:58 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:13:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:13:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:13:58 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:13:58 --> Helper loaded: form_helper
INFO - 2016-05-20 19:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:13:58 --> Form Validation Class Initialized
INFO - 2016-05-20 19:13:58 --> Controller Class Initialized
INFO - 2016-05-20 19:13:58 --> Model Class Initialized
INFO - 2016-05-20 19:13:58 --> Database Driver Class Initialized
INFO - 2016-05-20 19:13:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:13:58 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:13:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:13:58 --> Final output sent to browser
DEBUG - 2016-05-20 19:13:58 --> Total execution time: 0.1000
INFO - 2016-05-20 19:13:59 --> Config Class Initialized
INFO - 2016-05-20 19:13:59 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:13:59 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:13:59 --> Utf8 Class Initialized
INFO - 2016-05-20 19:13:59 --> URI Class Initialized
INFO - 2016-05-20 19:13:59 --> Router Class Initialized
INFO - 2016-05-20 19:13:59 --> Output Class Initialized
INFO - 2016-05-20 19:13:59 --> Security Class Initialized
DEBUG - 2016-05-20 19:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:13:59 --> Input Class Initialized
INFO - 2016-05-20 19:13:59 --> Language Class Initialized
INFO - 2016-05-20 19:13:59 --> Loader Class Initialized
INFO - 2016-05-20 19:13:59 --> Helper loaded: url_helper
INFO - 2016-05-20 19:13:59 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:13:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:13:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:13:59 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:13:59 --> Helper loaded: form_helper
INFO - 2016-05-20 19:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:13:59 --> Form Validation Class Initialized
INFO - 2016-05-20 19:13:59 --> Controller Class Initialized
INFO - 2016-05-20 19:13:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:13:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:13:59 --> Final output sent to browser
DEBUG - 2016-05-20 19:13:59 --> Total execution time: 0.0802
INFO - 2016-05-20 19:13:59 --> Config Class Initialized
INFO - 2016-05-20 19:13:59 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:14:00 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:14:00 --> Utf8 Class Initialized
INFO - 2016-05-20 19:14:00 --> URI Class Initialized
INFO - 2016-05-20 19:14:00 --> Router Class Initialized
INFO - 2016-05-20 19:14:00 --> Output Class Initialized
INFO - 2016-05-20 19:14:00 --> Security Class Initialized
DEBUG - 2016-05-20 19:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:14:00 --> Input Class Initialized
INFO - 2016-05-20 19:14:00 --> Language Class Initialized
INFO - 2016-05-20 19:14:00 --> Loader Class Initialized
INFO - 2016-05-20 19:14:00 --> Helper loaded: url_helper
INFO - 2016-05-20 19:14:00 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:14:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:14:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:14:00 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:14:00 --> Helper loaded: form_helper
INFO - 2016-05-20 19:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:14:00 --> Form Validation Class Initialized
INFO - 2016-05-20 19:14:00 --> Controller Class Initialized
INFO - 2016-05-20 19:14:00 --> Model Class Initialized
INFO - 2016-05-20 19:14:00 --> Database Driver Class Initialized
INFO - 2016-05-20 19:14:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:14:00 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:14:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:14:00 --> Final output sent to browser
DEBUG - 2016-05-20 19:14:00 --> Total execution time: 0.1191
INFO - 2016-05-20 19:14:00 --> Config Class Initialized
INFO - 2016-05-20 19:14:00 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:14:00 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:14:00 --> Utf8 Class Initialized
INFO - 2016-05-20 19:14:00 --> URI Class Initialized
INFO - 2016-05-20 19:14:00 --> Router Class Initialized
INFO - 2016-05-20 19:14:00 --> Output Class Initialized
INFO - 2016-05-20 19:14:00 --> Security Class Initialized
DEBUG - 2016-05-20 19:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:14:00 --> Input Class Initialized
INFO - 2016-05-20 19:14:00 --> Language Class Initialized
INFO - 2016-05-20 19:14:00 --> Loader Class Initialized
INFO - 2016-05-20 19:14:00 --> Helper loaded: url_helper
INFO - 2016-05-20 19:14:00 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:14:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:14:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:14:01 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:14:01 --> Helper loaded: form_helper
INFO - 2016-05-20 19:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:14:01 --> Form Validation Class Initialized
INFO - 2016-05-20 19:14:01 --> Controller Class Initialized
INFO - 2016-05-20 19:14:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:14:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:14:01 --> Final output sent to browser
DEBUG - 2016-05-20 19:14:01 --> Total execution time: 0.1282
INFO - 2016-05-20 19:14:01 --> Config Class Initialized
INFO - 2016-05-20 19:14:01 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:14:01 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:14:01 --> Utf8 Class Initialized
INFO - 2016-05-20 19:14:01 --> URI Class Initialized
INFO - 2016-05-20 19:14:01 --> Router Class Initialized
INFO - 2016-05-20 19:14:01 --> Output Class Initialized
INFO - 2016-05-20 19:14:01 --> Security Class Initialized
DEBUG - 2016-05-20 19:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:14:01 --> Input Class Initialized
INFO - 2016-05-20 19:14:01 --> Language Class Initialized
INFO - 2016-05-20 19:14:01 --> Loader Class Initialized
INFO - 2016-05-20 19:14:01 --> Helper loaded: url_helper
INFO - 2016-05-20 19:14:01 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:14:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:14:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:14:01 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:14:01 --> Helper loaded: form_helper
INFO - 2016-05-20 19:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:14:01 --> Form Validation Class Initialized
INFO - 2016-05-20 19:14:01 --> Controller Class Initialized
INFO - 2016-05-20 19:14:01 --> Model Class Initialized
INFO - 2016-05-20 19:14:01 --> Database Driver Class Initialized
INFO - 2016-05-20 19:14:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:14:01 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:14:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:14:01 --> Final output sent to browser
DEBUG - 2016-05-20 19:14:01 --> Total execution time: 0.1686
INFO - 2016-05-20 19:14:29 --> Config Class Initialized
INFO - 2016-05-20 19:14:29 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:14:29 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:14:29 --> Utf8 Class Initialized
INFO - 2016-05-20 19:14:29 --> URI Class Initialized
INFO - 2016-05-20 19:14:29 --> Router Class Initialized
INFO - 2016-05-20 19:14:29 --> Output Class Initialized
INFO - 2016-05-20 19:14:29 --> Security Class Initialized
DEBUG - 2016-05-20 19:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:14:29 --> Input Class Initialized
INFO - 2016-05-20 19:14:29 --> Language Class Initialized
INFO - 2016-05-20 19:14:29 --> Loader Class Initialized
INFO - 2016-05-20 19:14:29 --> Helper loaded: url_helper
INFO - 2016-05-20 19:14:29 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:14:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:14:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:14:29 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:14:29 --> Helper loaded: form_helper
INFO - 2016-05-20 19:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:14:29 --> Form Validation Class Initialized
INFO - 2016-05-20 19:14:29 --> Controller Class Initialized
INFO - 2016-05-20 19:14:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:14:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:14:29 --> Final output sent to browser
DEBUG - 2016-05-20 19:14:29 --> Total execution time: 0.0931
INFO - 2016-05-20 19:14:30 --> Config Class Initialized
INFO - 2016-05-20 19:14:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:14:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:14:30 --> Utf8 Class Initialized
INFO - 2016-05-20 19:14:30 --> URI Class Initialized
INFO - 2016-05-20 19:14:30 --> Router Class Initialized
INFO - 2016-05-20 19:14:30 --> Output Class Initialized
INFO - 2016-05-20 19:14:30 --> Security Class Initialized
DEBUG - 2016-05-20 19:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:14:30 --> Input Class Initialized
INFO - 2016-05-20 19:14:30 --> Language Class Initialized
INFO - 2016-05-20 19:14:30 --> Loader Class Initialized
INFO - 2016-05-20 19:14:30 --> Helper loaded: url_helper
INFO - 2016-05-20 19:14:30 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:14:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:14:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:14:30 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:14:30 --> Helper loaded: form_helper
INFO - 2016-05-20 19:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:14:30 --> Form Validation Class Initialized
INFO - 2016-05-20 19:14:30 --> Controller Class Initialized
INFO - 2016-05-20 19:14:30 --> Model Class Initialized
INFO - 2016-05-20 19:14:30 --> Database Driver Class Initialized
INFO - 2016-05-20 19:14:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:14:30 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:14:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:14:30 --> Final output sent to browser
DEBUG - 2016-05-20 19:14:30 --> Total execution time: 0.0968
INFO - 2016-05-20 19:15:11 --> Config Class Initialized
INFO - 2016-05-20 19:15:11 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:15:11 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:15:11 --> Utf8 Class Initialized
INFO - 2016-05-20 19:15:11 --> URI Class Initialized
INFO - 2016-05-20 19:15:11 --> Router Class Initialized
INFO - 2016-05-20 19:15:11 --> Output Class Initialized
INFO - 2016-05-20 19:15:11 --> Security Class Initialized
DEBUG - 2016-05-20 19:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:15:11 --> Input Class Initialized
INFO - 2016-05-20 19:15:11 --> Language Class Initialized
INFO - 2016-05-20 19:15:11 --> Loader Class Initialized
INFO - 2016-05-20 19:15:11 --> Helper loaded: url_helper
INFO - 2016-05-20 19:15:11 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:15:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:15:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:15:11 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:15:11 --> Helper loaded: form_helper
INFO - 2016-05-20 19:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:15:11 --> Form Validation Class Initialized
INFO - 2016-05-20 19:15:11 --> Controller Class Initialized
INFO - 2016-05-20 19:15:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:15:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:15:11 --> Final output sent to browser
DEBUG - 2016-05-20 19:15:11 --> Total execution time: 0.0993
INFO - 2016-05-20 19:15:48 --> Config Class Initialized
INFO - 2016-05-20 19:15:48 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:15:48 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:15:48 --> Utf8 Class Initialized
INFO - 2016-05-20 19:15:48 --> URI Class Initialized
INFO - 2016-05-20 19:15:48 --> Router Class Initialized
INFO - 2016-05-20 19:15:48 --> Output Class Initialized
INFO - 2016-05-20 19:15:48 --> Security Class Initialized
DEBUG - 2016-05-20 19:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:15:48 --> Input Class Initialized
INFO - 2016-05-20 19:15:48 --> Language Class Initialized
INFO - 2016-05-20 19:15:48 --> Loader Class Initialized
INFO - 2016-05-20 19:15:48 --> Helper loaded: url_helper
INFO - 2016-05-20 19:15:48 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:15:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:15:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:15:48 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:15:48 --> Helper loaded: form_helper
INFO - 2016-05-20 19:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:15:48 --> Form Validation Class Initialized
INFO - 2016-05-20 19:15:48 --> Controller Class Initialized
INFO - 2016-05-20 19:15:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:15:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:15:48 --> Final output sent to browser
DEBUG - 2016-05-20 19:15:48 --> Total execution time: 0.1590
INFO - 2016-05-20 19:15:49 --> Config Class Initialized
INFO - 2016-05-20 19:15:49 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:15:49 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:15:49 --> Utf8 Class Initialized
INFO - 2016-05-20 19:15:49 --> URI Class Initialized
INFO - 2016-05-20 19:15:49 --> Router Class Initialized
INFO - 2016-05-20 19:15:49 --> Output Class Initialized
INFO - 2016-05-20 19:15:49 --> Security Class Initialized
DEBUG - 2016-05-20 19:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:15:49 --> Input Class Initialized
INFO - 2016-05-20 19:15:49 --> Language Class Initialized
INFO - 2016-05-20 19:15:49 --> Loader Class Initialized
INFO - 2016-05-20 19:15:49 --> Helper loaded: url_helper
INFO - 2016-05-20 19:15:49 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:15:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:15:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:15:49 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:15:49 --> Helper loaded: form_helper
INFO - 2016-05-20 19:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:15:49 --> Form Validation Class Initialized
INFO - 2016-05-20 19:15:49 --> Controller Class Initialized
INFO - 2016-05-20 19:15:49 --> Model Class Initialized
INFO - 2016-05-20 19:15:49 --> Database Driver Class Initialized
INFO - 2016-05-20 19:15:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:15:49 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:15:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:15:49 --> Final output sent to browser
DEBUG - 2016-05-20 19:15:49 --> Total execution time: 0.1057
INFO - 2016-05-20 19:16:01 --> Config Class Initialized
INFO - 2016-05-20 19:16:01 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:01 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:01 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:01 --> URI Class Initialized
INFO - 2016-05-20 19:16:01 --> Router Class Initialized
INFO - 2016-05-20 19:16:01 --> Output Class Initialized
INFO - 2016-05-20 19:16:01 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:01 --> Input Class Initialized
INFO - 2016-05-20 19:16:01 --> Language Class Initialized
INFO - 2016-05-20 19:16:01 --> Loader Class Initialized
INFO - 2016-05-20 19:16:01 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:01 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:01 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:01 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:01 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:01 --> Controller Class Initialized
INFO - 2016-05-20 19:16:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:16:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:16:01 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:01 --> Total execution time: 0.0991
INFO - 2016-05-20 19:16:02 --> Config Class Initialized
INFO - 2016-05-20 19:16:02 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:02 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:02 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:02 --> URI Class Initialized
INFO - 2016-05-20 19:16:02 --> Router Class Initialized
INFO - 2016-05-20 19:16:02 --> Output Class Initialized
INFO - 2016-05-20 19:16:02 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:02 --> Input Class Initialized
INFO - 2016-05-20 19:16:02 --> Language Class Initialized
INFO - 2016-05-20 19:16:02 --> Loader Class Initialized
INFO - 2016-05-20 19:16:02 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:02 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:02 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:02 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:02 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:02 --> Controller Class Initialized
INFO - 2016-05-20 19:16:02 --> Model Class Initialized
INFO - 2016-05-20 19:16:02 --> Database Driver Class Initialized
INFO - 2016-05-20 19:16:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:16:02 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:16:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:16:02 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:02 --> Total execution time: 0.0840
INFO - 2016-05-20 19:16:03 --> Config Class Initialized
INFO - 2016-05-20 19:16:03 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:03 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:03 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:03 --> URI Class Initialized
INFO - 2016-05-20 19:16:03 --> Router Class Initialized
INFO - 2016-05-20 19:16:03 --> Output Class Initialized
INFO - 2016-05-20 19:16:03 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:03 --> Input Class Initialized
INFO - 2016-05-20 19:16:03 --> Language Class Initialized
INFO - 2016-05-20 19:16:03 --> Loader Class Initialized
INFO - 2016-05-20 19:16:03 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:03 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:03 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:03 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:03 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:03 --> Controller Class Initialized
INFO - 2016-05-20 19:16:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:16:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:16:03 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:03 --> Total execution time: 0.0559
INFO - 2016-05-20 19:16:03 --> Config Class Initialized
INFO - 2016-05-20 19:16:03 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:03 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:03 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:03 --> URI Class Initialized
INFO - 2016-05-20 19:16:03 --> Router Class Initialized
INFO - 2016-05-20 19:16:03 --> Output Class Initialized
INFO - 2016-05-20 19:16:03 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:03 --> Input Class Initialized
INFO - 2016-05-20 19:16:03 --> Language Class Initialized
INFO - 2016-05-20 19:16:03 --> Loader Class Initialized
INFO - 2016-05-20 19:16:03 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:03 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:03 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:03 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:03 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:03 --> Controller Class Initialized
INFO - 2016-05-20 19:16:03 --> Model Class Initialized
INFO - 2016-05-20 19:16:03 --> Database Driver Class Initialized
INFO - 2016-05-20 19:16:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:16:03 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:16:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:16:03 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:03 --> Total execution time: 0.0872
INFO - 2016-05-20 19:16:04 --> Config Class Initialized
INFO - 2016-05-20 19:16:04 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:04 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:04 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:04 --> URI Class Initialized
INFO - 2016-05-20 19:16:04 --> Router Class Initialized
INFO - 2016-05-20 19:16:04 --> Output Class Initialized
INFO - 2016-05-20 19:16:04 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:05 --> Input Class Initialized
INFO - 2016-05-20 19:16:05 --> Language Class Initialized
INFO - 2016-05-20 19:16:05 --> Loader Class Initialized
INFO - 2016-05-20 19:16:05 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:05 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:05 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:05 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:05 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:05 --> Controller Class Initialized
INFO - 2016-05-20 19:16:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:16:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:16:05 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:05 --> Total execution time: 0.1154
INFO - 2016-05-20 19:16:05 --> Config Class Initialized
INFO - 2016-05-20 19:16:05 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:05 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:05 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:05 --> URI Class Initialized
INFO - 2016-05-20 19:16:05 --> Router Class Initialized
INFO - 2016-05-20 19:16:05 --> Output Class Initialized
INFO - 2016-05-20 19:16:05 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:05 --> Input Class Initialized
INFO - 2016-05-20 19:16:05 --> Language Class Initialized
INFO - 2016-05-20 19:16:05 --> Loader Class Initialized
INFO - 2016-05-20 19:16:05 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:05 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:05 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:05 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:05 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:05 --> Controller Class Initialized
INFO - 2016-05-20 19:16:05 --> Model Class Initialized
INFO - 2016-05-20 19:16:05 --> Database Driver Class Initialized
INFO - 2016-05-20 19:16:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:16:05 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:16:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:16:05 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:05 --> Total execution time: 0.1395
INFO - 2016-05-20 19:16:06 --> Config Class Initialized
INFO - 2016-05-20 19:16:06 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:06 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:06 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:06 --> URI Class Initialized
INFO - 2016-05-20 19:16:06 --> Router Class Initialized
INFO - 2016-05-20 19:16:06 --> Output Class Initialized
INFO - 2016-05-20 19:16:06 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:06 --> Input Class Initialized
INFO - 2016-05-20 19:16:06 --> Language Class Initialized
INFO - 2016-05-20 19:16:06 --> Loader Class Initialized
INFO - 2016-05-20 19:16:06 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:06 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:06 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:06 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:06 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:06 --> Controller Class Initialized
INFO - 2016-05-20 19:16:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:16:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:16:06 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:06 --> Total execution time: 0.0889
INFO - 2016-05-20 19:16:07 --> Config Class Initialized
INFO - 2016-05-20 19:16:07 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:07 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:07 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:07 --> URI Class Initialized
INFO - 2016-05-20 19:16:07 --> Router Class Initialized
INFO - 2016-05-20 19:16:07 --> Output Class Initialized
INFO - 2016-05-20 19:16:07 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:07 --> Input Class Initialized
INFO - 2016-05-20 19:16:07 --> Language Class Initialized
INFO - 2016-05-20 19:16:07 --> Loader Class Initialized
INFO - 2016-05-20 19:16:07 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:07 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:07 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:07 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:07 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:07 --> Controller Class Initialized
INFO - 2016-05-20 19:16:07 --> Model Class Initialized
INFO - 2016-05-20 19:16:07 --> Database Driver Class Initialized
INFO - 2016-05-20 19:16:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:16:07 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:16:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:16:07 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:07 --> Total execution time: 0.1079
INFO - 2016-05-20 19:16:08 --> Config Class Initialized
INFO - 2016-05-20 19:16:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:08 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:08 --> URI Class Initialized
INFO - 2016-05-20 19:16:08 --> Router Class Initialized
INFO - 2016-05-20 19:16:08 --> Output Class Initialized
INFO - 2016-05-20 19:16:08 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:08 --> Input Class Initialized
INFO - 2016-05-20 19:16:08 --> Language Class Initialized
INFO - 2016-05-20 19:16:08 --> Loader Class Initialized
INFO - 2016-05-20 19:16:08 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:08 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:08 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:08 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:08 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:08 --> Controller Class Initialized
INFO - 2016-05-20 19:16:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:16:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:16:08 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:08 --> Total execution time: 0.0945
INFO - 2016-05-20 19:16:08 --> Config Class Initialized
INFO - 2016-05-20 19:16:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:08 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:08 --> URI Class Initialized
INFO - 2016-05-20 19:16:08 --> Router Class Initialized
INFO - 2016-05-20 19:16:08 --> Output Class Initialized
INFO - 2016-05-20 19:16:08 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:08 --> Input Class Initialized
INFO - 2016-05-20 19:16:08 --> Language Class Initialized
INFO - 2016-05-20 19:16:08 --> Loader Class Initialized
INFO - 2016-05-20 19:16:08 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:08 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:08 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:08 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:08 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:08 --> Controller Class Initialized
INFO - 2016-05-20 19:16:08 --> Model Class Initialized
INFO - 2016-05-20 19:16:08 --> Database Driver Class Initialized
INFO - 2016-05-20 19:16:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:16:08 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:16:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:16:08 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:08 --> Total execution time: 0.0998
INFO - 2016-05-20 19:16:11 --> Config Class Initialized
INFO - 2016-05-20 19:16:11 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:11 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:11 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:11 --> URI Class Initialized
INFO - 2016-05-20 19:16:11 --> Router Class Initialized
INFO - 2016-05-20 19:16:11 --> Output Class Initialized
INFO - 2016-05-20 19:16:11 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:11 --> Input Class Initialized
INFO - 2016-05-20 19:16:11 --> Language Class Initialized
INFO - 2016-05-20 19:16:11 --> Loader Class Initialized
INFO - 2016-05-20 19:16:11 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:11 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:11 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:11 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:11 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:11 --> Controller Class Initialized
INFO - 2016-05-20 19:16:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:16:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:16:11 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:11 --> Total execution time: 0.1024
INFO - 2016-05-20 19:16:11 --> Config Class Initialized
INFO - 2016-05-20 19:16:11 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:11 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:11 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:11 --> URI Class Initialized
INFO - 2016-05-20 19:16:11 --> Router Class Initialized
INFO - 2016-05-20 19:16:11 --> Output Class Initialized
INFO - 2016-05-20 19:16:11 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:11 --> Input Class Initialized
INFO - 2016-05-20 19:16:11 --> Language Class Initialized
INFO - 2016-05-20 19:16:11 --> Loader Class Initialized
INFO - 2016-05-20 19:16:11 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:11 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:11 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:11 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:11 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:11 --> Controller Class Initialized
INFO - 2016-05-20 19:16:11 --> Model Class Initialized
INFO - 2016-05-20 19:16:11 --> Database Driver Class Initialized
INFO - 2016-05-20 19:16:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:16:11 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:16:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:16:11 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:11 --> Total execution time: 0.1017
INFO - 2016-05-20 19:16:12 --> Config Class Initialized
INFO - 2016-05-20 19:16:12 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:12 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:12 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:12 --> URI Class Initialized
INFO - 2016-05-20 19:16:12 --> Router Class Initialized
INFO - 2016-05-20 19:16:12 --> Output Class Initialized
INFO - 2016-05-20 19:16:12 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:12 --> Input Class Initialized
INFO - 2016-05-20 19:16:12 --> Language Class Initialized
INFO - 2016-05-20 19:16:12 --> Loader Class Initialized
INFO - 2016-05-20 19:16:12 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:12 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:12 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:12 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:12 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:12 --> Controller Class Initialized
INFO - 2016-05-20 19:16:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:16:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:16:12 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:12 --> Total execution time: 0.1410
INFO - 2016-05-20 19:16:13 --> Config Class Initialized
INFO - 2016-05-20 19:16:13 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:13 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:13 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:13 --> URI Class Initialized
INFO - 2016-05-20 19:16:13 --> Router Class Initialized
INFO - 2016-05-20 19:16:13 --> Output Class Initialized
INFO - 2016-05-20 19:16:13 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:13 --> Input Class Initialized
INFO - 2016-05-20 19:16:13 --> Language Class Initialized
INFO - 2016-05-20 19:16:13 --> Loader Class Initialized
INFO - 2016-05-20 19:16:13 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:13 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:13 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:13 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:13 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:13 --> Controller Class Initialized
INFO - 2016-05-20 19:16:13 --> Model Class Initialized
INFO - 2016-05-20 19:16:13 --> Database Driver Class Initialized
INFO - 2016-05-20 19:16:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:16:13 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:16:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:16:13 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:13 --> Total execution time: 0.0973
INFO - 2016-05-20 19:16:15 --> Config Class Initialized
INFO - 2016-05-20 19:16:15 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:15 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:15 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:15 --> URI Class Initialized
INFO - 2016-05-20 19:16:15 --> Router Class Initialized
INFO - 2016-05-20 19:16:15 --> Output Class Initialized
INFO - 2016-05-20 19:16:15 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:15 --> Input Class Initialized
INFO - 2016-05-20 19:16:15 --> Language Class Initialized
INFO - 2016-05-20 19:16:15 --> Loader Class Initialized
INFO - 2016-05-20 19:16:15 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:15 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:15 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:15 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:15 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:15 --> Controller Class Initialized
INFO - 2016-05-20 19:16:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:16:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:16:15 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:15 --> Total execution time: 0.1359
INFO - 2016-05-20 19:16:16 --> Config Class Initialized
INFO - 2016-05-20 19:16:16 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:16 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:16 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:16 --> URI Class Initialized
INFO - 2016-05-20 19:16:16 --> Router Class Initialized
INFO - 2016-05-20 19:16:16 --> Output Class Initialized
INFO - 2016-05-20 19:16:16 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:16 --> Input Class Initialized
INFO - 2016-05-20 19:16:16 --> Language Class Initialized
INFO - 2016-05-20 19:16:16 --> Loader Class Initialized
INFO - 2016-05-20 19:16:16 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:16 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:16 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:16 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:16 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:16 --> Controller Class Initialized
INFO - 2016-05-20 19:16:16 --> Model Class Initialized
INFO - 2016-05-20 19:16:16 --> Database Driver Class Initialized
INFO - 2016-05-20 19:16:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:16:16 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:16:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:16:16 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:16 --> Total execution time: 0.1054
INFO - 2016-05-20 19:16:23 --> Config Class Initialized
INFO - 2016-05-20 19:16:23 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:23 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:23 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:23 --> URI Class Initialized
DEBUG - 2016-05-20 19:16:23 --> No URI present. Default controller set.
INFO - 2016-05-20 19:16:23 --> Router Class Initialized
INFO - 2016-05-20 19:16:23 --> Output Class Initialized
INFO - 2016-05-20 19:16:23 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:23 --> Input Class Initialized
INFO - 2016-05-20 19:16:23 --> Language Class Initialized
INFO - 2016-05-20 19:16:23 --> Loader Class Initialized
INFO - 2016-05-20 19:16:23 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:23 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:23 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:23 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:23 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:23 --> Controller Class Initialized
INFO - 2016-05-20 19:16:23 --> Model Class Initialized
INFO - 2016-05-20 19:16:23 --> Database Driver Class Initialized
INFO - 2016-05-20 19:16:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:16:24 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:16:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:16:24 --> Config Class Initialized
INFO - 2016-05-20 19:16:24 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:24 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:24 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:24 --> URI Class Initialized
INFO - 2016-05-20 19:16:24 --> Router Class Initialized
INFO - 2016-05-20 19:16:24 --> Output Class Initialized
INFO - 2016-05-20 19:16:24 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:24 --> Input Class Initialized
INFO - 2016-05-20 19:16:24 --> Language Class Initialized
INFO - 2016-05-20 19:16:24 --> Loader Class Initialized
INFO - 2016-05-20 19:16:24 --> Helper loaded: url_helper
INFO - 2016-05-20 19:16:24 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:16:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:16:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:16:24 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:16:24 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:16:24 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:24 --> Controller Class Initialized
INFO - 2016-05-20 19:16:24 --> Model Class Initialized
INFO - 2016-05-20 19:16:24 --> Database Driver Class Initialized
INFO - 2016-05-20 19:16:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-20 19:16:24 --> Final output sent to browser
DEBUG - 2016-05-20 19:16:24 --> Total execution time: 0.0822
INFO - 2016-05-20 19:17:16 --> Config Class Initialized
INFO - 2016-05-20 19:17:16 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:17:16 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:17:16 --> Utf8 Class Initialized
INFO - 2016-05-20 19:17:16 --> URI Class Initialized
INFO - 2016-05-20 19:17:16 --> Router Class Initialized
INFO - 2016-05-20 19:17:16 --> Output Class Initialized
INFO - 2016-05-20 19:17:16 --> Security Class Initialized
DEBUG - 2016-05-20 19:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:17:16 --> Input Class Initialized
INFO - 2016-05-20 19:17:16 --> Language Class Initialized
INFO - 2016-05-20 19:17:16 --> Loader Class Initialized
INFO - 2016-05-20 19:17:16 --> Helper loaded: url_helper
INFO - 2016-05-20 19:17:16 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:17:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:17:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:17:16 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:17:16 --> Helper loaded: form_helper
INFO - 2016-05-20 19:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:17:16 --> Form Validation Class Initialized
INFO - 2016-05-20 19:17:16 --> Controller Class Initialized
INFO - 2016-05-20 19:17:16 --> Model Class Initialized
INFO - 2016-05-20 19:17:16 --> Database Driver Class Initialized
INFO - 2016-05-20 19:17:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:17:16 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:17:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:17:16 --> Final output sent to browser
DEBUG - 2016-05-20 19:17:16 --> Total execution time: 0.1120
INFO - 2016-05-20 19:18:16 --> Config Class Initialized
INFO - 2016-05-20 19:18:16 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:18:16 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:18:16 --> Utf8 Class Initialized
INFO - 2016-05-20 19:18:16 --> URI Class Initialized
INFO - 2016-05-20 19:18:16 --> Router Class Initialized
INFO - 2016-05-20 19:18:16 --> Output Class Initialized
INFO - 2016-05-20 19:18:16 --> Security Class Initialized
DEBUG - 2016-05-20 19:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:18:16 --> Input Class Initialized
INFO - 2016-05-20 19:18:16 --> Language Class Initialized
INFO - 2016-05-20 19:18:16 --> Loader Class Initialized
INFO - 2016-05-20 19:18:16 --> Helper loaded: url_helper
INFO - 2016-05-20 19:18:16 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:18:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:18:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:18:16 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:18:16 --> Helper loaded: form_helper
INFO - 2016-05-20 19:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:18:16 --> Form Validation Class Initialized
INFO - 2016-05-20 19:18:16 --> Controller Class Initialized
INFO - 2016-05-20 19:18:16 --> Model Class Initialized
INFO - 2016-05-20 19:18:16 --> Database Driver Class Initialized
INFO - 2016-05-20 19:18:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:18:16 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:18:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:18:16 --> Final output sent to browser
DEBUG - 2016-05-20 19:18:16 --> Total execution time: 0.0877
INFO - 2016-05-20 19:19:16 --> Config Class Initialized
INFO - 2016-05-20 19:19:16 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:19:16 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:19:16 --> Utf8 Class Initialized
INFO - 2016-05-20 19:19:16 --> URI Class Initialized
INFO - 2016-05-20 19:19:16 --> Router Class Initialized
INFO - 2016-05-20 19:19:16 --> Output Class Initialized
INFO - 2016-05-20 19:19:16 --> Security Class Initialized
DEBUG - 2016-05-20 19:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:19:16 --> Input Class Initialized
INFO - 2016-05-20 19:19:16 --> Language Class Initialized
INFO - 2016-05-20 19:19:16 --> Loader Class Initialized
INFO - 2016-05-20 19:19:16 --> Helper loaded: url_helper
INFO - 2016-05-20 19:19:16 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:19:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:19:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:19:16 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:19:16 --> Helper loaded: form_helper
INFO - 2016-05-20 19:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:19:16 --> Form Validation Class Initialized
INFO - 2016-05-20 19:19:16 --> Controller Class Initialized
INFO - 2016-05-20 19:19:16 --> Model Class Initialized
INFO - 2016-05-20 19:19:16 --> Database Driver Class Initialized
INFO - 2016-05-20 19:19:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:19:16 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:19:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:19:16 --> Final output sent to browser
DEBUG - 2016-05-20 19:19:16 --> Total execution time: 0.0758
INFO - 2016-05-20 19:20:01 --> Config Class Initialized
INFO - 2016-05-20 19:20:01 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:20:01 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:20:01 --> Utf8 Class Initialized
INFO - 2016-05-20 19:20:01 --> URI Class Initialized
INFO - 2016-05-20 19:20:01 --> Router Class Initialized
INFO - 2016-05-20 19:20:01 --> Output Class Initialized
INFO - 2016-05-20 19:20:01 --> Security Class Initialized
DEBUG - 2016-05-20 19:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:20:01 --> Input Class Initialized
INFO - 2016-05-20 19:20:01 --> Language Class Initialized
INFO - 2016-05-20 19:20:01 --> Loader Class Initialized
INFO - 2016-05-20 19:20:01 --> Helper loaded: url_helper
INFO - 2016-05-20 19:20:01 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:20:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:20:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:20:01 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:20:01 --> Helper loaded: form_helper
INFO - 2016-05-20 19:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:20:01 --> Form Validation Class Initialized
INFO - 2016-05-20 19:20:01 --> Controller Class Initialized
INFO - 2016-05-20 19:20:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:20:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:20:01 --> Final output sent to browser
DEBUG - 2016-05-20 19:20:01 --> Total execution time: 0.0641
INFO - 2016-05-20 19:20:02 --> Config Class Initialized
INFO - 2016-05-20 19:20:02 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:20:02 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:20:02 --> Utf8 Class Initialized
INFO - 2016-05-20 19:20:02 --> URI Class Initialized
INFO - 2016-05-20 19:20:02 --> Router Class Initialized
INFO - 2016-05-20 19:20:02 --> Output Class Initialized
INFO - 2016-05-20 19:20:02 --> Security Class Initialized
DEBUG - 2016-05-20 19:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:20:02 --> Input Class Initialized
INFO - 2016-05-20 19:20:02 --> Language Class Initialized
INFO - 2016-05-20 19:20:02 --> Loader Class Initialized
INFO - 2016-05-20 19:20:02 --> Helper loaded: url_helper
INFO - 2016-05-20 19:20:02 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:20:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:20:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:20:02 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:20:02 --> Helper loaded: form_helper
INFO - 2016-05-20 19:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:20:02 --> Form Validation Class Initialized
INFO - 2016-05-20 19:20:02 --> Controller Class Initialized
INFO - 2016-05-20 19:20:02 --> Model Class Initialized
INFO - 2016-05-20 19:20:02 --> Database Driver Class Initialized
INFO - 2016-05-20 19:20:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:20:02 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:20:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:20:02 --> Final output sent to browser
DEBUG - 2016-05-20 19:20:02 --> Total execution time: 0.0898
INFO - 2016-05-20 19:20:09 --> Config Class Initialized
INFO - 2016-05-20 19:20:09 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:20:09 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:20:09 --> Utf8 Class Initialized
INFO - 2016-05-20 19:20:09 --> URI Class Initialized
INFO - 2016-05-20 19:20:09 --> Router Class Initialized
INFO - 2016-05-20 19:20:09 --> Output Class Initialized
INFO - 2016-05-20 19:20:09 --> Security Class Initialized
DEBUG - 2016-05-20 19:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:20:09 --> Input Class Initialized
INFO - 2016-05-20 19:20:09 --> Language Class Initialized
INFO - 2016-05-20 19:20:09 --> Loader Class Initialized
INFO - 2016-05-20 19:20:09 --> Helper loaded: url_helper
INFO - 2016-05-20 19:20:09 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:20:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:20:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:20:09 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:20:09 --> Helper loaded: form_helper
INFO - 2016-05-20 19:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:20:09 --> Form Validation Class Initialized
INFO - 2016-05-20 19:20:09 --> Controller Class Initialized
INFO - 2016-05-20 19:20:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:20:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:20:09 --> Final output sent to browser
DEBUG - 2016-05-20 19:20:09 --> Total execution time: 0.0609
INFO - 2016-05-20 19:20:10 --> Config Class Initialized
INFO - 2016-05-20 19:20:10 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:20:10 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:20:10 --> Utf8 Class Initialized
INFO - 2016-05-20 19:20:10 --> URI Class Initialized
INFO - 2016-05-20 19:20:10 --> Router Class Initialized
INFO - 2016-05-20 19:20:10 --> Output Class Initialized
INFO - 2016-05-20 19:20:10 --> Security Class Initialized
DEBUG - 2016-05-20 19:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:20:10 --> Input Class Initialized
INFO - 2016-05-20 19:20:10 --> Language Class Initialized
INFO - 2016-05-20 19:20:10 --> Loader Class Initialized
INFO - 2016-05-20 19:20:10 --> Helper loaded: url_helper
INFO - 2016-05-20 19:20:10 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:20:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:20:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:20:10 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:20:10 --> Helper loaded: form_helper
INFO - 2016-05-20 19:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:20:10 --> Form Validation Class Initialized
INFO - 2016-05-20 19:20:10 --> Controller Class Initialized
INFO - 2016-05-20 19:20:10 --> Model Class Initialized
INFO - 2016-05-20 19:20:10 --> Database Driver Class Initialized
INFO - 2016-05-20 19:20:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:20:10 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:20:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:20:10 --> Final output sent to browser
DEBUG - 2016-05-20 19:20:10 --> Total execution time: 0.0910
INFO - 2016-05-20 19:20:11 --> Config Class Initialized
INFO - 2016-05-20 19:20:11 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:20:11 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:20:11 --> Utf8 Class Initialized
INFO - 2016-05-20 19:20:11 --> URI Class Initialized
INFO - 2016-05-20 19:20:11 --> Router Class Initialized
INFO - 2016-05-20 19:20:11 --> Output Class Initialized
INFO - 2016-05-20 19:20:11 --> Security Class Initialized
DEBUG - 2016-05-20 19:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:20:11 --> Input Class Initialized
INFO - 2016-05-20 19:20:11 --> Language Class Initialized
INFO - 2016-05-20 19:20:11 --> Loader Class Initialized
INFO - 2016-05-20 19:20:11 --> Helper loaded: url_helper
INFO - 2016-05-20 19:20:11 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:20:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:20:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:20:11 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:20:11 --> Helper loaded: form_helper
INFO - 2016-05-20 19:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:20:11 --> Form Validation Class Initialized
INFO - 2016-05-20 19:20:11 --> Controller Class Initialized
INFO - 2016-05-20 19:20:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:20:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:20:11 --> Final output sent to browser
DEBUG - 2016-05-20 19:20:11 --> Total execution time: 0.0548
INFO - 2016-05-20 19:20:11 --> Config Class Initialized
INFO - 2016-05-20 19:20:11 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:20:11 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:20:11 --> Utf8 Class Initialized
INFO - 2016-05-20 19:20:11 --> URI Class Initialized
INFO - 2016-05-20 19:20:11 --> Router Class Initialized
INFO - 2016-05-20 19:20:11 --> Output Class Initialized
INFO - 2016-05-20 19:20:11 --> Security Class Initialized
DEBUG - 2016-05-20 19:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:20:11 --> Input Class Initialized
INFO - 2016-05-20 19:20:11 --> Language Class Initialized
INFO - 2016-05-20 19:20:11 --> Loader Class Initialized
INFO - 2016-05-20 19:20:11 --> Helper loaded: url_helper
INFO - 2016-05-20 19:20:11 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:20:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:20:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:20:11 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:20:11 --> Helper loaded: form_helper
INFO - 2016-05-20 19:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:20:12 --> Form Validation Class Initialized
INFO - 2016-05-20 19:20:12 --> Controller Class Initialized
INFO - 2016-05-20 19:20:12 --> Model Class Initialized
INFO - 2016-05-20 19:20:12 --> Database Driver Class Initialized
INFO - 2016-05-20 19:20:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:20:12 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:20:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:20:12 --> Final output sent to browser
DEBUG - 2016-05-20 19:20:12 --> Total execution time: 0.0870
INFO - 2016-05-20 19:20:12 --> Config Class Initialized
INFO - 2016-05-20 19:20:12 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:20:12 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:20:12 --> Utf8 Class Initialized
INFO - 2016-05-20 19:20:12 --> URI Class Initialized
INFO - 2016-05-20 19:20:12 --> Router Class Initialized
INFO - 2016-05-20 19:20:12 --> Output Class Initialized
INFO - 2016-05-20 19:20:12 --> Security Class Initialized
DEBUG - 2016-05-20 19:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:20:12 --> Input Class Initialized
INFO - 2016-05-20 19:20:12 --> Language Class Initialized
INFO - 2016-05-20 19:20:12 --> Loader Class Initialized
INFO - 2016-05-20 19:20:12 --> Helper loaded: url_helper
INFO - 2016-05-20 19:20:12 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:20:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:20:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:20:12 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:20:12 --> Helper loaded: form_helper
INFO - 2016-05-20 19:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:20:12 --> Form Validation Class Initialized
INFO - 2016-05-20 19:20:12 --> Controller Class Initialized
INFO - 2016-05-20 19:20:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:20:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:20:13 --> Final output sent to browser
DEBUG - 2016-05-20 19:20:13 --> Total execution time: 0.0629
INFO - 2016-05-20 19:20:13 --> Config Class Initialized
INFO - 2016-05-20 19:20:13 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:20:13 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:20:13 --> Utf8 Class Initialized
INFO - 2016-05-20 19:20:13 --> URI Class Initialized
INFO - 2016-05-20 19:20:13 --> Router Class Initialized
INFO - 2016-05-20 19:20:13 --> Output Class Initialized
INFO - 2016-05-20 19:20:13 --> Security Class Initialized
DEBUG - 2016-05-20 19:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:20:13 --> Input Class Initialized
INFO - 2016-05-20 19:20:13 --> Language Class Initialized
INFO - 2016-05-20 19:20:13 --> Loader Class Initialized
INFO - 2016-05-20 19:20:13 --> Helper loaded: url_helper
INFO - 2016-05-20 19:20:13 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:20:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:20:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:20:13 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:20:13 --> Helper loaded: form_helper
INFO - 2016-05-20 19:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:20:13 --> Form Validation Class Initialized
INFO - 2016-05-20 19:20:13 --> Controller Class Initialized
INFO - 2016-05-20 19:20:13 --> Model Class Initialized
INFO - 2016-05-20 19:20:13 --> Database Driver Class Initialized
INFO - 2016-05-20 19:20:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:20:13 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:20:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:20:13 --> Final output sent to browser
DEBUG - 2016-05-20 19:20:13 --> Total execution time: 0.1169
INFO - 2016-05-20 19:20:14 --> Config Class Initialized
INFO - 2016-05-20 19:20:14 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:20:14 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:20:14 --> Utf8 Class Initialized
INFO - 2016-05-20 19:20:14 --> URI Class Initialized
INFO - 2016-05-20 19:20:14 --> Router Class Initialized
INFO - 2016-05-20 19:20:14 --> Output Class Initialized
INFO - 2016-05-20 19:20:14 --> Security Class Initialized
DEBUG - 2016-05-20 19:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:20:14 --> Input Class Initialized
INFO - 2016-05-20 19:20:14 --> Language Class Initialized
INFO - 2016-05-20 19:20:14 --> Loader Class Initialized
INFO - 2016-05-20 19:20:14 --> Helper loaded: url_helper
INFO - 2016-05-20 19:20:14 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:20:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:20:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:20:14 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:20:14 --> Helper loaded: form_helper
INFO - 2016-05-20 19:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:20:14 --> Form Validation Class Initialized
INFO - 2016-05-20 19:20:14 --> Controller Class Initialized
INFO - 2016-05-20 19:20:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:20:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:20:14 --> Final output sent to browser
DEBUG - 2016-05-20 19:20:14 --> Total execution time: 0.0616
INFO - 2016-05-20 19:20:14 --> Config Class Initialized
INFO - 2016-05-20 19:20:14 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:20:14 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:20:14 --> Utf8 Class Initialized
INFO - 2016-05-20 19:20:14 --> URI Class Initialized
INFO - 2016-05-20 19:20:14 --> Router Class Initialized
INFO - 2016-05-20 19:20:14 --> Output Class Initialized
INFO - 2016-05-20 19:20:14 --> Security Class Initialized
DEBUG - 2016-05-20 19:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:20:14 --> Input Class Initialized
INFO - 2016-05-20 19:20:14 --> Language Class Initialized
INFO - 2016-05-20 19:20:14 --> Loader Class Initialized
INFO - 2016-05-20 19:20:14 --> Helper loaded: url_helper
INFO - 2016-05-20 19:20:14 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:20:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:20:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:20:14 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:20:14 --> Helper loaded: form_helper
INFO - 2016-05-20 19:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:20:14 --> Form Validation Class Initialized
INFO - 2016-05-20 19:20:14 --> Controller Class Initialized
INFO - 2016-05-20 19:20:14 --> Model Class Initialized
INFO - 2016-05-20 19:20:14 --> Database Driver Class Initialized
INFO - 2016-05-20 19:20:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:20:14 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:20:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:20:14 --> Final output sent to browser
DEBUG - 2016-05-20 19:20:14 --> Total execution time: 0.1374
INFO - 2016-05-20 19:21:15 --> Config Class Initialized
INFO - 2016-05-20 19:21:15 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:21:15 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:21:15 --> Utf8 Class Initialized
INFO - 2016-05-20 19:21:15 --> URI Class Initialized
INFO - 2016-05-20 19:21:15 --> Router Class Initialized
INFO - 2016-05-20 19:21:15 --> Output Class Initialized
INFO - 2016-05-20 19:21:15 --> Security Class Initialized
DEBUG - 2016-05-20 19:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:21:15 --> Input Class Initialized
INFO - 2016-05-20 19:21:15 --> Language Class Initialized
INFO - 2016-05-20 19:21:15 --> Loader Class Initialized
INFO - 2016-05-20 19:21:15 --> Helper loaded: url_helper
INFO - 2016-05-20 19:21:15 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:21:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:21:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:21:15 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:21:15 --> Helper loaded: form_helper
INFO - 2016-05-20 19:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:21:15 --> Form Validation Class Initialized
INFO - 2016-05-20 19:21:15 --> Controller Class Initialized
INFO - 2016-05-20 19:21:15 --> Model Class Initialized
INFO - 2016-05-20 19:21:15 --> Database Driver Class Initialized
INFO - 2016-05-20 19:21:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:21:15 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:21:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:21:15 --> Final output sent to browser
DEBUG - 2016-05-20 19:21:15 --> Total execution time: 0.0660
INFO - 2016-05-20 19:22:05 --> Config Class Initialized
INFO - 2016-05-20 19:22:05 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:22:05 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:22:05 --> Utf8 Class Initialized
INFO - 2016-05-20 19:22:05 --> URI Class Initialized
INFO - 2016-05-20 19:22:05 --> Router Class Initialized
INFO - 2016-05-20 19:22:05 --> Output Class Initialized
INFO - 2016-05-20 19:22:05 --> Security Class Initialized
DEBUG - 2016-05-20 19:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:22:05 --> Input Class Initialized
INFO - 2016-05-20 19:22:05 --> Language Class Initialized
INFO - 2016-05-20 19:22:05 --> Loader Class Initialized
INFO - 2016-05-20 19:22:05 --> Helper loaded: url_helper
INFO - 2016-05-20 19:22:05 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:22:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:22:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:22:05 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:22:05 --> Helper loaded: form_helper
INFO - 2016-05-20 19:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:22:05 --> Form Validation Class Initialized
INFO - 2016-05-20 19:22:05 --> Controller Class Initialized
INFO - 2016-05-20 19:22:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:22:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:22:05 --> Final output sent to browser
DEBUG - 2016-05-20 19:22:05 --> Total execution time: 0.0598
INFO - 2016-05-20 19:22:06 --> Config Class Initialized
INFO - 2016-05-20 19:22:06 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:22:06 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:22:06 --> Utf8 Class Initialized
INFO - 2016-05-20 19:22:06 --> URI Class Initialized
INFO - 2016-05-20 19:22:06 --> Router Class Initialized
INFO - 2016-05-20 19:22:06 --> Output Class Initialized
INFO - 2016-05-20 19:22:06 --> Security Class Initialized
DEBUG - 2016-05-20 19:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:22:06 --> Input Class Initialized
INFO - 2016-05-20 19:22:06 --> Language Class Initialized
INFO - 2016-05-20 19:22:06 --> Loader Class Initialized
INFO - 2016-05-20 19:22:06 --> Helper loaded: url_helper
INFO - 2016-05-20 19:22:06 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:22:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:22:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:22:06 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:22:06 --> Helper loaded: form_helper
INFO - 2016-05-20 19:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:22:06 --> Form Validation Class Initialized
INFO - 2016-05-20 19:22:06 --> Controller Class Initialized
INFO - 2016-05-20 19:22:06 --> Model Class Initialized
INFO - 2016-05-20 19:22:06 --> Database Driver Class Initialized
INFO - 2016-05-20 19:22:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:22:06 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:22:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:22:06 --> Final output sent to browser
DEBUG - 2016-05-20 19:22:06 --> Total execution time: 0.0830
INFO - 2016-05-20 19:22:06 --> Config Class Initialized
INFO - 2016-05-20 19:22:06 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:22:06 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:22:06 --> Utf8 Class Initialized
INFO - 2016-05-20 19:22:06 --> URI Class Initialized
INFO - 2016-05-20 19:22:06 --> Router Class Initialized
INFO - 2016-05-20 19:22:06 --> Output Class Initialized
INFO - 2016-05-20 19:22:06 --> Security Class Initialized
DEBUG - 2016-05-20 19:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:22:06 --> Input Class Initialized
INFO - 2016-05-20 19:22:07 --> Language Class Initialized
INFO - 2016-05-20 19:22:07 --> Loader Class Initialized
INFO - 2016-05-20 19:22:07 --> Helper loaded: url_helper
INFO - 2016-05-20 19:22:07 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:22:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:22:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:22:07 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:22:07 --> Helper loaded: form_helper
INFO - 2016-05-20 19:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:22:07 --> Form Validation Class Initialized
INFO - 2016-05-20 19:22:07 --> Controller Class Initialized
INFO - 2016-05-20 19:22:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:22:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:22:07 --> Final output sent to browser
DEBUG - 2016-05-20 19:22:07 --> Total execution time: 0.0587
INFO - 2016-05-20 19:22:07 --> Config Class Initialized
INFO - 2016-05-20 19:22:07 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:22:07 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:22:07 --> Utf8 Class Initialized
INFO - 2016-05-20 19:22:07 --> URI Class Initialized
INFO - 2016-05-20 19:22:07 --> Router Class Initialized
INFO - 2016-05-20 19:22:07 --> Output Class Initialized
INFO - 2016-05-20 19:22:07 --> Security Class Initialized
DEBUG - 2016-05-20 19:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:22:07 --> Input Class Initialized
INFO - 2016-05-20 19:22:07 --> Language Class Initialized
INFO - 2016-05-20 19:22:07 --> Loader Class Initialized
INFO - 2016-05-20 19:22:07 --> Helper loaded: url_helper
INFO - 2016-05-20 19:22:07 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:22:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:22:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:22:07 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:22:07 --> Helper loaded: form_helper
INFO - 2016-05-20 19:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:22:07 --> Form Validation Class Initialized
INFO - 2016-05-20 19:22:07 --> Controller Class Initialized
INFO - 2016-05-20 19:22:07 --> Model Class Initialized
INFO - 2016-05-20 19:22:07 --> Database Driver Class Initialized
INFO - 2016-05-20 19:22:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:22:07 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:22:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:22:07 --> Final output sent to browser
DEBUG - 2016-05-20 19:22:07 --> Total execution time: 0.1087
INFO - 2016-05-20 19:22:08 --> Config Class Initialized
INFO - 2016-05-20 19:22:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:22:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:22:08 --> Utf8 Class Initialized
INFO - 2016-05-20 19:22:08 --> URI Class Initialized
INFO - 2016-05-20 19:22:08 --> Router Class Initialized
INFO - 2016-05-20 19:22:08 --> Output Class Initialized
INFO - 2016-05-20 19:22:08 --> Security Class Initialized
DEBUG - 2016-05-20 19:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:22:08 --> Input Class Initialized
INFO - 2016-05-20 19:22:08 --> Language Class Initialized
INFO - 2016-05-20 19:22:08 --> Loader Class Initialized
INFO - 2016-05-20 19:22:08 --> Helper loaded: url_helper
INFO - 2016-05-20 19:22:08 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:22:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:22:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:22:08 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:22:08 --> Helper loaded: form_helper
INFO - 2016-05-20 19:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:22:08 --> Form Validation Class Initialized
INFO - 2016-05-20 19:22:08 --> Controller Class Initialized
INFO - 2016-05-20 19:22:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:22:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:22:08 --> Final output sent to browser
DEBUG - 2016-05-20 19:22:08 --> Total execution time: 0.0593
INFO - 2016-05-20 19:22:08 --> Config Class Initialized
INFO - 2016-05-20 19:22:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:22:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:22:08 --> Utf8 Class Initialized
INFO - 2016-05-20 19:22:08 --> URI Class Initialized
INFO - 2016-05-20 19:22:08 --> Router Class Initialized
INFO - 2016-05-20 19:22:08 --> Output Class Initialized
INFO - 2016-05-20 19:22:08 --> Security Class Initialized
DEBUG - 2016-05-20 19:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:22:08 --> Input Class Initialized
INFO - 2016-05-20 19:22:08 --> Language Class Initialized
INFO - 2016-05-20 19:22:08 --> Loader Class Initialized
INFO - 2016-05-20 19:22:08 --> Helper loaded: url_helper
INFO - 2016-05-20 19:22:08 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:22:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:22:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:22:08 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:22:08 --> Helper loaded: form_helper
INFO - 2016-05-20 19:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:22:08 --> Form Validation Class Initialized
INFO - 2016-05-20 19:22:08 --> Controller Class Initialized
INFO - 2016-05-20 19:22:08 --> Model Class Initialized
INFO - 2016-05-20 19:22:08 --> Database Driver Class Initialized
INFO - 2016-05-20 19:22:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:22:08 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:22:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:22:08 --> Final output sent to browser
DEBUG - 2016-05-20 19:22:08 --> Total execution time: 0.1287
INFO - 2016-05-20 19:22:18 --> Config Class Initialized
INFO - 2016-05-20 19:22:18 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:22:18 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:22:18 --> Utf8 Class Initialized
INFO - 2016-05-20 19:22:18 --> URI Class Initialized
INFO - 2016-05-20 19:22:18 --> Router Class Initialized
INFO - 2016-05-20 19:22:18 --> Output Class Initialized
INFO - 2016-05-20 19:22:18 --> Security Class Initialized
DEBUG - 2016-05-20 19:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:22:18 --> Input Class Initialized
INFO - 2016-05-20 19:22:18 --> Language Class Initialized
INFO - 2016-05-20 19:22:18 --> Loader Class Initialized
INFO - 2016-05-20 19:22:18 --> Helper loaded: url_helper
INFO - 2016-05-20 19:22:18 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:22:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:22:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:22:18 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:22:18 --> Helper loaded: form_helper
INFO - 2016-05-20 19:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:22:18 --> Form Validation Class Initialized
INFO - 2016-05-20 19:22:18 --> Controller Class Initialized
INFO - 2016-05-20 19:22:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:22:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:22:18 --> Final output sent to browser
DEBUG - 2016-05-20 19:22:18 --> Total execution time: 0.1157
INFO - 2016-05-20 19:22:18 --> Config Class Initialized
INFO - 2016-05-20 19:22:18 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:22:18 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:22:18 --> Utf8 Class Initialized
INFO - 2016-05-20 19:22:18 --> URI Class Initialized
INFO - 2016-05-20 19:22:18 --> Router Class Initialized
INFO - 2016-05-20 19:22:18 --> Output Class Initialized
INFO - 2016-05-20 19:22:18 --> Security Class Initialized
DEBUG - 2016-05-20 19:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:22:18 --> Input Class Initialized
INFO - 2016-05-20 19:22:18 --> Language Class Initialized
INFO - 2016-05-20 19:22:18 --> Loader Class Initialized
INFO - 2016-05-20 19:22:18 --> Helper loaded: url_helper
INFO - 2016-05-20 19:22:18 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:22:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:22:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:22:18 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:22:18 --> Helper loaded: form_helper
INFO - 2016-05-20 19:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:22:18 --> Form Validation Class Initialized
INFO - 2016-05-20 19:22:18 --> Controller Class Initialized
INFO - 2016-05-20 19:22:18 --> Model Class Initialized
INFO - 2016-05-20 19:22:18 --> Database Driver Class Initialized
INFO - 2016-05-20 19:22:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:22:18 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:22:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:22:18 --> Final output sent to browser
DEBUG - 2016-05-20 19:22:18 --> Total execution time: 0.0939
INFO - 2016-05-20 19:22:21 --> Config Class Initialized
INFO - 2016-05-20 19:22:21 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:22:21 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:22:21 --> Utf8 Class Initialized
INFO - 2016-05-20 19:22:21 --> URI Class Initialized
INFO - 2016-05-20 19:22:21 --> Router Class Initialized
INFO - 2016-05-20 19:22:21 --> Output Class Initialized
INFO - 2016-05-20 19:22:21 --> Security Class Initialized
DEBUG - 2016-05-20 19:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:22:21 --> Input Class Initialized
INFO - 2016-05-20 19:22:21 --> Language Class Initialized
INFO - 2016-05-20 19:22:21 --> Loader Class Initialized
INFO - 2016-05-20 19:22:21 --> Helper loaded: url_helper
INFO - 2016-05-20 19:22:21 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:22:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:22:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:22:21 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:22:21 --> Helper loaded: form_helper
INFO - 2016-05-20 19:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:22:21 --> Form Validation Class Initialized
INFO - 2016-05-20 19:22:21 --> Controller Class Initialized
INFO - 2016-05-20 19:22:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-20 19:22:21 --> Helper loaded: nif_validate_helper
INFO - 2016-05-20 19:22:21 --> Model Class Initialized
INFO - 2016-05-20 19:22:21 --> Database Driver Class Initialized
INFO - 2016-05-20 19:22:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-20 19:22:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:22:21 --> Final output sent to browser
DEBUG - 2016-05-20 19:22:21 --> Total execution time: 0.0814
INFO - 2016-05-20 19:22:22 --> Config Class Initialized
INFO - 2016-05-20 19:22:22 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:22:22 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:22:22 --> Utf8 Class Initialized
INFO - 2016-05-20 19:22:22 --> URI Class Initialized
INFO - 2016-05-20 19:22:22 --> Router Class Initialized
INFO - 2016-05-20 19:22:22 --> Output Class Initialized
INFO - 2016-05-20 19:22:22 --> Security Class Initialized
DEBUG - 2016-05-20 19:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:22:22 --> Input Class Initialized
INFO - 2016-05-20 19:22:22 --> Language Class Initialized
INFO - 2016-05-20 19:22:22 --> Loader Class Initialized
INFO - 2016-05-20 19:22:22 --> Helper loaded: url_helper
INFO - 2016-05-20 19:22:22 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:22:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:22:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:22:22 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:22:22 --> Helper loaded: form_helper
INFO - 2016-05-20 19:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:22:22 --> Form Validation Class Initialized
INFO - 2016-05-20 19:22:22 --> Controller Class Initialized
INFO - 2016-05-20 19:22:22 --> Model Class Initialized
INFO - 2016-05-20 19:22:22 --> Database Driver Class Initialized
INFO - 2016-05-20 19:22:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:22:22 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:22:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:22:22 --> Final output sent to browser
DEBUG - 2016-05-20 19:22:22 --> Total execution time: 0.0850
INFO - 2016-05-20 19:22:23 --> Config Class Initialized
INFO - 2016-05-20 19:22:23 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:22:23 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:22:23 --> Utf8 Class Initialized
INFO - 2016-05-20 19:22:23 --> URI Class Initialized
INFO - 2016-05-20 19:22:23 --> Router Class Initialized
INFO - 2016-05-20 19:22:23 --> Output Class Initialized
INFO - 2016-05-20 19:22:23 --> Security Class Initialized
DEBUG - 2016-05-20 19:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:22:23 --> Input Class Initialized
INFO - 2016-05-20 19:22:23 --> Language Class Initialized
INFO - 2016-05-20 19:22:23 --> Loader Class Initialized
INFO - 2016-05-20 19:22:23 --> Helper loaded: url_helper
INFO - 2016-05-20 19:22:23 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:22:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:22:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:22:23 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:22:23 --> Helper loaded: form_helper
INFO - 2016-05-20 19:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:22:23 --> Form Validation Class Initialized
INFO - 2016-05-20 19:22:23 --> Controller Class Initialized
INFO - 2016-05-20 19:22:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-20 19:22:23 --> Helper loaded: nif_validate_helper
INFO - 2016-05-20 19:22:23 --> Model Class Initialized
INFO - 2016-05-20 19:22:23 --> Database Driver Class Initialized
INFO - 2016-05-20 19:22:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-20 19:22:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:22:23 --> Final output sent to browser
DEBUG - 2016-05-20 19:22:23 --> Total execution time: 0.0876
INFO - 2016-05-20 19:22:24 --> Config Class Initialized
INFO - 2016-05-20 19:22:24 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:22:24 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:22:24 --> Utf8 Class Initialized
INFO - 2016-05-20 19:22:24 --> URI Class Initialized
INFO - 2016-05-20 19:22:24 --> Router Class Initialized
INFO - 2016-05-20 19:22:24 --> Output Class Initialized
INFO - 2016-05-20 19:22:24 --> Security Class Initialized
DEBUG - 2016-05-20 19:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:22:24 --> Input Class Initialized
INFO - 2016-05-20 19:22:24 --> Language Class Initialized
INFO - 2016-05-20 19:22:24 --> Loader Class Initialized
INFO - 2016-05-20 19:22:24 --> Helper loaded: url_helper
INFO - 2016-05-20 19:22:24 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:22:24 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:22:24 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:22:24 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:22:24 --> Helper loaded: form_helper
INFO - 2016-05-20 19:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:22:24 --> Form Validation Class Initialized
INFO - 2016-05-20 19:22:24 --> Controller Class Initialized
INFO - 2016-05-20 19:22:24 --> Model Class Initialized
INFO - 2016-05-20 19:22:24 --> Database Driver Class Initialized
INFO - 2016-05-20 19:22:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:22:24 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:22:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:22:24 --> Final output sent to browser
DEBUG - 2016-05-20 19:22:24 --> Total execution time: 0.1096
INFO - 2016-05-20 19:22:25 --> Config Class Initialized
INFO - 2016-05-20 19:22:25 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:22:25 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:22:25 --> Utf8 Class Initialized
INFO - 2016-05-20 19:22:25 --> URI Class Initialized
INFO - 2016-05-20 19:22:25 --> Router Class Initialized
INFO - 2016-05-20 19:22:25 --> Output Class Initialized
INFO - 2016-05-20 19:22:25 --> Security Class Initialized
DEBUG - 2016-05-20 19:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:22:25 --> Input Class Initialized
INFO - 2016-05-20 19:22:25 --> Language Class Initialized
INFO - 2016-05-20 19:22:25 --> Loader Class Initialized
INFO - 2016-05-20 19:22:25 --> Helper loaded: url_helper
INFO - 2016-05-20 19:22:25 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:22:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:22:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:22:25 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:22:25 --> Helper loaded: form_helper
INFO - 2016-05-20 19:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:22:25 --> Form Validation Class Initialized
INFO - 2016-05-20 19:22:25 --> Controller Class Initialized
INFO - 2016-05-20 19:22:25 --> Helper loaded: creaselect_helper
INFO - 2016-05-20 19:22:25 --> Helper loaded: nif_validate_helper
INFO - 2016-05-20 19:22:25 --> Model Class Initialized
INFO - 2016-05-20 19:22:25 --> Database Driver Class Initialized
INFO - 2016-05-20 19:22:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-20 19:22:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:22:25 --> Final output sent to browser
DEBUG - 2016-05-20 19:22:25 --> Total execution time: 0.0886
INFO - 2016-05-20 19:22:25 --> Config Class Initialized
INFO - 2016-05-20 19:22:25 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:22:25 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:22:25 --> Utf8 Class Initialized
INFO - 2016-05-20 19:22:25 --> URI Class Initialized
INFO - 2016-05-20 19:22:25 --> Router Class Initialized
INFO - 2016-05-20 19:22:25 --> Output Class Initialized
INFO - 2016-05-20 19:22:25 --> Security Class Initialized
DEBUG - 2016-05-20 19:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:22:25 --> Input Class Initialized
INFO - 2016-05-20 19:22:25 --> Language Class Initialized
INFO - 2016-05-20 19:22:25 --> Loader Class Initialized
INFO - 2016-05-20 19:22:25 --> Helper loaded: url_helper
INFO - 2016-05-20 19:22:25 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:22:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:22:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:22:25 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:22:25 --> Helper loaded: form_helper
INFO - 2016-05-20 19:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:22:25 --> Form Validation Class Initialized
INFO - 2016-05-20 19:22:25 --> Controller Class Initialized
INFO - 2016-05-20 19:22:25 --> Model Class Initialized
INFO - 2016-05-20 19:22:25 --> Database Driver Class Initialized
INFO - 2016-05-20 19:22:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:22:25 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:22:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:22:25 --> Final output sent to browser
DEBUG - 2016-05-20 19:22:25 --> Total execution time: 0.1322
INFO - 2016-05-20 19:23:25 --> Config Class Initialized
INFO - 2016-05-20 19:23:25 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:23:25 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:23:25 --> Utf8 Class Initialized
INFO - 2016-05-20 19:23:25 --> URI Class Initialized
INFO - 2016-05-20 19:23:25 --> Router Class Initialized
INFO - 2016-05-20 19:23:25 --> Output Class Initialized
INFO - 2016-05-20 19:23:25 --> Security Class Initialized
DEBUG - 2016-05-20 19:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:23:25 --> Input Class Initialized
INFO - 2016-05-20 19:23:25 --> Language Class Initialized
INFO - 2016-05-20 19:23:25 --> Loader Class Initialized
INFO - 2016-05-20 19:23:25 --> Helper loaded: url_helper
INFO - 2016-05-20 19:23:25 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:23:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:23:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:23:25 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:23:25 --> Helper loaded: form_helper
INFO - 2016-05-20 19:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:23:25 --> Form Validation Class Initialized
INFO - 2016-05-20 19:23:25 --> Controller Class Initialized
INFO - 2016-05-20 19:23:25 --> Model Class Initialized
INFO - 2016-05-20 19:23:25 --> Database Driver Class Initialized
INFO - 2016-05-20 19:23:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:23:25 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:23:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:23:25 --> Final output sent to browser
DEBUG - 2016-05-20 19:23:25 --> Total execution time: 0.0820
INFO - 2016-05-20 19:24:25 --> Config Class Initialized
INFO - 2016-05-20 19:24:25 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:24:25 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:24:25 --> Utf8 Class Initialized
INFO - 2016-05-20 19:24:25 --> URI Class Initialized
INFO - 2016-05-20 19:24:25 --> Router Class Initialized
INFO - 2016-05-20 19:24:25 --> Output Class Initialized
INFO - 2016-05-20 19:24:25 --> Security Class Initialized
DEBUG - 2016-05-20 19:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:24:25 --> Input Class Initialized
INFO - 2016-05-20 19:24:25 --> Language Class Initialized
INFO - 2016-05-20 19:24:25 --> Loader Class Initialized
INFO - 2016-05-20 19:24:25 --> Helper loaded: url_helper
INFO - 2016-05-20 19:24:25 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:24:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:24:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:24:25 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:24:25 --> Helper loaded: form_helper
INFO - 2016-05-20 19:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:24:25 --> Form Validation Class Initialized
INFO - 2016-05-20 19:24:25 --> Controller Class Initialized
INFO - 2016-05-20 19:24:25 --> Model Class Initialized
INFO - 2016-05-20 19:24:25 --> Database Driver Class Initialized
INFO - 2016-05-20 19:24:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:24:25 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:24:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:24:25 --> Final output sent to browser
DEBUG - 2016-05-20 19:24:25 --> Total execution time: 0.0782
INFO - 2016-05-20 19:24:55 --> Config Class Initialized
INFO - 2016-05-20 19:24:55 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:24:55 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:24:55 --> Utf8 Class Initialized
INFO - 2016-05-20 19:24:55 --> URI Class Initialized
INFO - 2016-05-20 19:24:55 --> Router Class Initialized
INFO - 2016-05-20 19:24:55 --> Output Class Initialized
INFO - 2016-05-20 19:24:55 --> Security Class Initialized
DEBUG - 2016-05-20 19:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:24:55 --> Input Class Initialized
INFO - 2016-05-20 19:24:55 --> Language Class Initialized
INFO - 2016-05-20 19:24:55 --> Loader Class Initialized
INFO - 2016-05-20 19:24:55 --> Helper loaded: url_helper
INFO - 2016-05-20 19:24:55 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:24:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:24:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:24:55 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:24:55 --> Helper loaded: form_helper
INFO - 2016-05-20 19:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:24:55 --> Form Validation Class Initialized
INFO - 2016-05-20 19:24:55 --> Controller Class Initialized
INFO - 2016-05-20 19:24:55 --> Helper loaded: creaselect_helper
INFO - 2016-05-20 19:24:55 --> Helper loaded: nif_validate_helper
INFO - 2016-05-20 19:24:55 --> Model Class Initialized
INFO - 2016-05-20 19:24:55 --> Database Driver Class Initialized
INFO - 2016-05-20 19:24:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-20 19:24:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:24:55 --> Final output sent to browser
DEBUG - 2016-05-20 19:24:55 --> Total execution time: 0.0766
INFO - 2016-05-20 19:24:55 --> Config Class Initialized
INFO - 2016-05-20 19:24:55 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:24:55 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:24:55 --> Utf8 Class Initialized
INFO - 2016-05-20 19:24:55 --> URI Class Initialized
INFO - 2016-05-20 19:24:55 --> Router Class Initialized
INFO - 2016-05-20 19:24:55 --> Output Class Initialized
INFO - 2016-05-20 19:24:55 --> Security Class Initialized
DEBUG - 2016-05-20 19:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:24:55 --> Input Class Initialized
INFO - 2016-05-20 19:24:55 --> Language Class Initialized
INFO - 2016-05-20 19:24:55 --> Loader Class Initialized
INFO - 2016-05-20 19:24:55 --> Helper loaded: url_helper
INFO - 2016-05-20 19:24:55 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:24:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:24:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:24:55 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:24:55 --> Helper loaded: form_helper
INFO - 2016-05-20 19:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:24:55 --> Form Validation Class Initialized
INFO - 2016-05-20 19:24:55 --> Controller Class Initialized
INFO - 2016-05-20 19:24:55 --> Model Class Initialized
INFO - 2016-05-20 19:24:55 --> Database Driver Class Initialized
INFO - 2016-05-20 19:24:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:24:55 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:24:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:24:55 --> Final output sent to browser
DEBUG - 2016-05-20 19:24:55 --> Total execution time: 0.1012
INFO - 2016-05-20 19:25:55 --> Config Class Initialized
INFO - 2016-05-20 19:25:55 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:25:55 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:25:55 --> Utf8 Class Initialized
INFO - 2016-05-20 19:25:55 --> URI Class Initialized
INFO - 2016-05-20 19:25:55 --> Router Class Initialized
INFO - 2016-05-20 19:25:55 --> Output Class Initialized
INFO - 2016-05-20 19:25:55 --> Security Class Initialized
DEBUG - 2016-05-20 19:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:25:55 --> Input Class Initialized
INFO - 2016-05-20 19:25:55 --> Language Class Initialized
INFO - 2016-05-20 19:25:55 --> Loader Class Initialized
INFO - 2016-05-20 19:25:55 --> Helper loaded: url_helper
INFO - 2016-05-20 19:25:55 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:25:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:25:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:25:55 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:25:55 --> Helper loaded: form_helper
INFO - 2016-05-20 19:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:25:55 --> Form Validation Class Initialized
INFO - 2016-05-20 19:25:55 --> Controller Class Initialized
INFO - 2016-05-20 19:25:55 --> Model Class Initialized
INFO - 2016-05-20 19:25:55 --> Database Driver Class Initialized
INFO - 2016-05-20 19:25:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:25:55 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:25:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:25:55 --> Final output sent to browser
DEBUG - 2016-05-20 19:25:55 --> Total execution time: 0.0692
INFO - 2016-05-20 19:26:43 --> Config Class Initialized
INFO - 2016-05-20 19:26:43 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:26:43 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:26:43 --> Utf8 Class Initialized
INFO - 2016-05-20 19:26:43 --> URI Class Initialized
INFO - 2016-05-20 19:26:43 --> Router Class Initialized
INFO - 2016-05-20 19:26:43 --> Output Class Initialized
INFO - 2016-05-20 19:26:43 --> Security Class Initialized
DEBUG - 2016-05-20 19:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:26:43 --> Input Class Initialized
INFO - 2016-05-20 19:26:43 --> Language Class Initialized
INFO - 2016-05-20 19:26:43 --> Loader Class Initialized
INFO - 2016-05-20 19:26:43 --> Helper loaded: url_helper
INFO - 2016-05-20 19:26:43 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:26:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:26:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:26:43 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:26:43 --> Helper loaded: form_helper
INFO - 2016-05-20 19:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:26:43 --> Form Validation Class Initialized
INFO - 2016-05-20 19:26:43 --> Controller Class Initialized
INFO - 2016-05-20 19:26:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:26:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:26:43 --> Final output sent to browser
DEBUG - 2016-05-20 19:26:43 --> Total execution time: 0.0539
INFO - 2016-05-20 19:26:43 --> Config Class Initialized
INFO - 2016-05-20 19:26:43 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:26:43 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:26:43 --> Utf8 Class Initialized
INFO - 2016-05-20 19:26:43 --> URI Class Initialized
INFO - 2016-05-20 19:26:43 --> Router Class Initialized
INFO - 2016-05-20 19:26:43 --> Output Class Initialized
INFO - 2016-05-20 19:26:43 --> Security Class Initialized
DEBUG - 2016-05-20 19:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:26:43 --> Input Class Initialized
INFO - 2016-05-20 19:26:43 --> Language Class Initialized
INFO - 2016-05-20 19:26:43 --> Loader Class Initialized
INFO - 2016-05-20 19:26:43 --> Helper loaded: url_helper
INFO - 2016-05-20 19:26:43 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:26:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:26:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:26:43 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:26:43 --> Helper loaded: form_helper
INFO - 2016-05-20 19:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:26:43 --> Form Validation Class Initialized
INFO - 2016-05-20 19:26:43 --> Controller Class Initialized
INFO - 2016-05-20 19:26:43 --> Model Class Initialized
INFO - 2016-05-20 19:26:43 --> Database Driver Class Initialized
INFO - 2016-05-20 19:26:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:26:43 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:26:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:26:43 --> Final output sent to browser
DEBUG - 2016-05-20 19:26:43 --> Total execution time: 0.1117
INFO - 2016-05-20 19:26:44 --> Config Class Initialized
INFO - 2016-05-20 19:26:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:26:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:26:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:26:44 --> URI Class Initialized
INFO - 2016-05-20 19:26:44 --> Router Class Initialized
INFO - 2016-05-20 19:26:44 --> Output Class Initialized
INFO - 2016-05-20 19:26:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:26:44 --> Input Class Initialized
INFO - 2016-05-20 19:26:44 --> Language Class Initialized
INFO - 2016-05-20 19:26:44 --> Loader Class Initialized
INFO - 2016-05-20 19:26:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:26:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:26:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:26:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:26:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:26:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:26:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:26:44 --> Controller Class Initialized
INFO - 2016-05-20 19:26:44 --> Config Class Initialized
INFO - 2016-05-20 19:26:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:26:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:26:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:26:44 --> URI Class Initialized
INFO - 2016-05-20 19:26:44 --> Router Class Initialized
INFO - 2016-05-20 19:26:44 --> Output Class Initialized
INFO - 2016-05-20 19:26:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:26:44 --> Input Class Initialized
INFO - 2016-05-20 19:26:44 --> Language Class Initialized
INFO - 2016-05-20 19:26:44 --> Loader Class Initialized
INFO - 2016-05-20 19:26:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:26:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:26:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:26:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:26:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:26:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:26:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:26:44 --> Controller Class Initialized
INFO - 2016-05-20 19:26:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:26:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:26:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:26:44 --> Total execution time: 0.0655
INFO - 2016-05-20 19:26:45 --> Config Class Initialized
INFO - 2016-05-20 19:26:45 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:26:45 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:26:45 --> Utf8 Class Initialized
INFO - 2016-05-20 19:26:45 --> URI Class Initialized
INFO - 2016-05-20 19:26:45 --> Router Class Initialized
INFO - 2016-05-20 19:26:45 --> Output Class Initialized
INFO - 2016-05-20 19:26:45 --> Security Class Initialized
DEBUG - 2016-05-20 19:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:26:45 --> Input Class Initialized
INFO - 2016-05-20 19:26:45 --> Language Class Initialized
INFO - 2016-05-20 19:26:45 --> Loader Class Initialized
INFO - 2016-05-20 19:26:45 --> Helper loaded: url_helper
INFO - 2016-05-20 19:26:45 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:26:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:26:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:26:45 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:26:45 --> Helper loaded: form_helper
INFO - 2016-05-20 19:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:26:45 --> Form Validation Class Initialized
INFO - 2016-05-20 19:26:45 --> Controller Class Initialized
INFO - 2016-05-20 19:26:45 --> Model Class Initialized
INFO - 2016-05-20 19:26:45 --> Database Driver Class Initialized
INFO - 2016-05-20 19:26:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:26:45 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:26:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:26:45 --> Final output sent to browser
DEBUG - 2016-05-20 19:26:45 --> Total execution time: 0.0865
INFO - 2016-05-20 19:26:46 --> Config Class Initialized
INFO - 2016-05-20 19:26:46 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:26:46 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:26:46 --> Utf8 Class Initialized
INFO - 2016-05-20 19:26:46 --> URI Class Initialized
INFO - 2016-05-20 19:26:46 --> Router Class Initialized
INFO - 2016-05-20 19:26:46 --> Output Class Initialized
INFO - 2016-05-20 19:26:46 --> Security Class Initialized
DEBUG - 2016-05-20 19:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:26:46 --> Input Class Initialized
INFO - 2016-05-20 19:26:46 --> Language Class Initialized
INFO - 2016-05-20 19:26:46 --> Loader Class Initialized
INFO - 2016-05-20 19:26:46 --> Helper loaded: url_helper
INFO - 2016-05-20 19:26:46 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:26:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:26:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:26:46 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:26:46 --> Helper loaded: form_helper
INFO - 2016-05-20 19:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:26:46 --> Form Validation Class Initialized
INFO - 2016-05-20 19:26:46 --> Controller Class Initialized
INFO - 2016-05-20 19:26:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:26:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:26:46 --> Final output sent to browser
DEBUG - 2016-05-20 19:26:46 --> Total execution time: 0.0690
INFO - 2016-05-20 19:26:47 --> Config Class Initialized
INFO - 2016-05-20 19:26:47 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:26:47 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:26:47 --> Utf8 Class Initialized
INFO - 2016-05-20 19:26:47 --> URI Class Initialized
INFO - 2016-05-20 19:26:47 --> Router Class Initialized
INFO - 2016-05-20 19:26:47 --> Output Class Initialized
INFO - 2016-05-20 19:26:47 --> Security Class Initialized
DEBUG - 2016-05-20 19:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:26:47 --> Input Class Initialized
INFO - 2016-05-20 19:26:47 --> Language Class Initialized
INFO - 2016-05-20 19:26:47 --> Loader Class Initialized
INFO - 2016-05-20 19:26:47 --> Helper loaded: url_helper
INFO - 2016-05-20 19:26:47 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:26:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:26:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:26:47 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:26:47 --> Helper loaded: form_helper
INFO - 2016-05-20 19:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:26:47 --> Form Validation Class Initialized
INFO - 2016-05-20 19:26:47 --> Controller Class Initialized
INFO - 2016-05-20 19:26:47 --> Model Class Initialized
INFO - 2016-05-20 19:26:47 --> Database Driver Class Initialized
INFO - 2016-05-20 19:26:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:26:47 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:26:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:26:47 --> Final output sent to browser
DEBUG - 2016-05-20 19:26:47 --> Total execution time: 0.0980
INFO - 2016-05-20 19:26:47 --> Config Class Initialized
INFO - 2016-05-20 19:26:47 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:26:47 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:26:47 --> Utf8 Class Initialized
INFO - 2016-05-20 19:26:47 --> URI Class Initialized
INFO - 2016-05-20 19:26:47 --> Router Class Initialized
INFO - 2016-05-20 19:26:47 --> Output Class Initialized
INFO - 2016-05-20 19:26:47 --> Security Class Initialized
DEBUG - 2016-05-20 19:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:26:47 --> Input Class Initialized
INFO - 2016-05-20 19:26:47 --> Language Class Initialized
INFO - 2016-05-20 19:26:47 --> Loader Class Initialized
INFO - 2016-05-20 19:26:47 --> Helper loaded: url_helper
INFO - 2016-05-20 19:26:47 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:26:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:26:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:26:47 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:26:47 --> Helper loaded: form_helper
INFO - 2016-05-20 19:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:26:47 --> Form Validation Class Initialized
INFO - 2016-05-20 19:26:47 --> Controller Class Initialized
INFO - 2016-05-20 19:26:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:26:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:26:47 --> Final output sent to browser
DEBUG - 2016-05-20 19:26:47 --> Total execution time: 0.0592
INFO - 2016-05-20 19:26:48 --> Config Class Initialized
INFO - 2016-05-20 19:26:48 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:26:48 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:26:48 --> Utf8 Class Initialized
INFO - 2016-05-20 19:26:48 --> URI Class Initialized
INFO - 2016-05-20 19:26:48 --> Router Class Initialized
INFO - 2016-05-20 19:26:48 --> Output Class Initialized
INFO - 2016-05-20 19:26:48 --> Security Class Initialized
DEBUG - 2016-05-20 19:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:26:48 --> Input Class Initialized
INFO - 2016-05-20 19:26:48 --> Language Class Initialized
INFO - 2016-05-20 19:26:48 --> Loader Class Initialized
INFO - 2016-05-20 19:26:48 --> Helper loaded: url_helper
INFO - 2016-05-20 19:26:48 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:26:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:26:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:26:48 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:26:48 --> Helper loaded: form_helper
INFO - 2016-05-20 19:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:26:48 --> Form Validation Class Initialized
INFO - 2016-05-20 19:26:48 --> Controller Class Initialized
INFO - 2016-05-20 19:26:48 --> Model Class Initialized
INFO - 2016-05-20 19:26:48 --> Database Driver Class Initialized
INFO - 2016-05-20 19:26:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:26:48 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:26:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:26:48 --> Final output sent to browser
DEBUG - 2016-05-20 19:26:48 --> Total execution time: 0.0939
INFO - 2016-05-20 19:27:06 --> Config Class Initialized
INFO - 2016-05-20 19:27:06 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:06 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:06 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:06 --> URI Class Initialized
INFO - 2016-05-20 19:27:06 --> Router Class Initialized
INFO - 2016-05-20 19:27:06 --> Output Class Initialized
INFO - 2016-05-20 19:27:06 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:06 --> Input Class Initialized
INFO - 2016-05-20 19:27:06 --> Language Class Initialized
INFO - 2016-05-20 19:27:06 --> Loader Class Initialized
INFO - 2016-05-20 19:27:06 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:06 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:06 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:06 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:06 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:06 --> Controller Class Initialized
INFO - 2016-05-20 19:27:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:27:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:27:06 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:06 --> Total execution time: 0.0640
INFO - 2016-05-20 19:27:07 --> Config Class Initialized
INFO - 2016-05-20 19:27:07 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:07 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:07 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:07 --> URI Class Initialized
INFO - 2016-05-20 19:27:07 --> Router Class Initialized
INFO - 2016-05-20 19:27:07 --> Output Class Initialized
INFO - 2016-05-20 19:27:07 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:07 --> Input Class Initialized
INFO - 2016-05-20 19:27:07 --> Language Class Initialized
INFO - 2016-05-20 19:27:07 --> Loader Class Initialized
INFO - 2016-05-20 19:27:07 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:07 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:07 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:07 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:07 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:07 --> Controller Class Initialized
INFO - 2016-05-20 19:27:07 --> Model Class Initialized
INFO - 2016-05-20 19:27:07 --> Database Driver Class Initialized
INFO - 2016-05-20 19:27:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:27:07 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:27:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:27:07 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:07 --> Total execution time: 0.1113
INFO - 2016-05-20 19:27:07 --> Config Class Initialized
INFO - 2016-05-20 19:27:07 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:07 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:07 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:07 --> URI Class Initialized
INFO - 2016-05-20 19:27:07 --> Router Class Initialized
INFO - 2016-05-20 19:27:07 --> Output Class Initialized
INFO - 2016-05-20 19:27:07 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:07 --> Input Class Initialized
INFO - 2016-05-20 19:27:07 --> Language Class Initialized
INFO - 2016-05-20 19:27:07 --> Loader Class Initialized
INFO - 2016-05-20 19:27:07 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:07 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:07 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:07 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:07 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:07 --> Controller Class Initialized
INFO - 2016-05-20 19:27:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:27:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:27:07 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:07 --> Total execution time: 0.0578
INFO - 2016-05-20 19:27:07 --> Config Class Initialized
INFO - 2016-05-20 19:27:07 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:07 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:07 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:07 --> URI Class Initialized
INFO - 2016-05-20 19:27:07 --> Router Class Initialized
INFO - 2016-05-20 19:27:07 --> Output Class Initialized
INFO - 2016-05-20 19:27:07 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:07 --> Input Class Initialized
INFO - 2016-05-20 19:27:07 --> Language Class Initialized
INFO - 2016-05-20 19:27:08 --> Loader Class Initialized
INFO - 2016-05-20 19:27:08 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:08 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:08 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:08 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:08 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:08 --> Controller Class Initialized
INFO - 2016-05-20 19:27:08 --> Model Class Initialized
INFO - 2016-05-20 19:27:08 --> Database Driver Class Initialized
INFO - 2016-05-20 19:27:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:27:08 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:27:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:27:08 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:08 --> Total execution time: 0.1026
INFO - 2016-05-20 19:27:08 --> Config Class Initialized
INFO - 2016-05-20 19:27:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:08 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:08 --> URI Class Initialized
INFO - 2016-05-20 19:27:08 --> Router Class Initialized
INFO - 2016-05-20 19:27:08 --> Output Class Initialized
INFO - 2016-05-20 19:27:08 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:08 --> Input Class Initialized
INFO - 2016-05-20 19:27:08 --> Language Class Initialized
INFO - 2016-05-20 19:27:08 --> Loader Class Initialized
INFO - 2016-05-20 19:27:08 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:08 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:08 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:08 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:08 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:08 --> Controller Class Initialized
INFO - 2016-05-20 19:27:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:27:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:27:08 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:08 --> Total execution time: 0.0559
INFO - 2016-05-20 19:27:08 --> Config Class Initialized
INFO - 2016-05-20 19:27:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:08 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:08 --> URI Class Initialized
INFO - 2016-05-20 19:27:08 --> Router Class Initialized
INFO - 2016-05-20 19:27:08 --> Output Class Initialized
INFO - 2016-05-20 19:27:08 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:08 --> Input Class Initialized
INFO - 2016-05-20 19:27:08 --> Language Class Initialized
INFO - 2016-05-20 19:27:08 --> Loader Class Initialized
INFO - 2016-05-20 19:27:08 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:08 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:08 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:08 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:08 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:08 --> Controller Class Initialized
INFO - 2016-05-20 19:27:08 --> Model Class Initialized
INFO - 2016-05-20 19:27:08 --> Database Driver Class Initialized
INFO - 2016-05-20 19:27:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:27:08 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:27:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:27:08 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:08 --> Total execution time: 0.1096
INFO - 2016-05-20 19:27:35 --> Config Class Initialized
INFO - 2016-05-20 19:27:35 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:35 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:35 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:35 --> URI Class Initialized
INFO - 2016-05-20 19:27:35 --> Router Class Initialized
INFO - 2016-05-20 19:27:35 --> Output Class Initialized
INFO - 2016-05-20 19:27:35 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:35 --> Input Class Initialized
INFO - 2016-05-20 19:27:35 --> Language Class Initialized
INFO - 2016-05-20 19:27:35 --> Loader Class Initialized
INFO - 2016-05-20 19:27:35 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:35 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:35 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:35 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:35 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:35 --> Controller Class Initialized
INFO - 2016-05-20 19:27:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:27:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:27:35 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:35 --> Total execution time: 0.0560
INFO - 2016-05-20 19:27:36 --> Config Class Initialized
INFO - 2016-05-20 19:27:36 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:36 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:36 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:36 --> URI Class Initialized
INFO - 2016-05-20 19:27:36 --> Router Class Initialized
INFO - 2016-05-20 19:27:36 --> Output Class Initialized
INFO - 2016-05-20 19:27:36 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:36 --> Input Class Initialized
INFO - 2016-05-20 19:27:36 --> Language Class Initialized
INFO - 2016-05-20 19:27:36 --> Loader Class Initialized
INFO - 2016-05-20 19:27:36 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:36 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:36 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:36 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:36 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:36 --> Controller Class Initialized
INFO - 2016-05-20 19:27:36 --> Model Class Initialized
INFO - 2016-05-20 19:27:36 --> Database Driver Class Initialized
INFO - 2016-05-20 19:27:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:27:36 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:27:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:27:36 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:36 --> Total execution time: 0.1109
INFO - 2016-05-20 19:27:37 --> Config Class Initialized
INFO - 2016-05-20 19:27:37 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:37 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:37 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:37 --> URI Class Initialized
INFO - 2016-05-20 19:27:37 --> Router Class Initialized
INFO - 2016-05-20 19:27:37 --> Output Class Initialized
INFO - 2016-05-20 19:27:37 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:37 --> Input Class Initialized
INFO - 2016-05-20 19:27:37 --> Language Class Initialized
INFO - 2016-05-20 19:27:37 --> Loader Class Initialized
INFO - 2016-05-20 19:27:37 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:37 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:37 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:37 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:37 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:37 --> Controller Class Initialized
INFO - 2016-05-20 19:27:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:27:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:27:37 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:37 --> Total execution time: 0.0579
INFO - 2016-05-20 19:27:37 --> Config Class Initialized
INFO - 2016-05-20 19:27:37 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:37 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:37 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:37 --> URI Class Initialized
INFO - 2016-05-20 19:27:37 --> Router Class Initialized
INFO - 2016-05-20 19:27:37 --> Output Class Initialized
INFO - 2016-05-20 19:27:37 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:37 --> Input Class Initialized
INFO - 2016-05-20 19:27:37 --> Language Class Initialized
INFO - 2016-05-20 19:27:37 --> Loader Class Initialized
INFO - 2016-05-20 19:27:37 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:37 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:37 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:37 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:37 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:37 --> Controller Class Initialized
INFO - 2016-05-20 19:27:37 --> Model Class Initialized
INFO - 2016-05-20 19:27:37 --> Database Driver Class Initialized
INFO - 2016-05-20 19:27:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:27:37 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:27:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:27:37 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:37 --> Total execution time: 0.1004
INFO - 2016-05-20 19:27:38 --> Config Class Initialized
INFO - 2016-05-20 19:27:38 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:38 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:38 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:38 --> URI Class Initialized
INFO - 2016-05-20 19:27:38 --> Router Class Initialized
INFO - 2016-05-20 19:27:38 --> Output Class Initialized
INFO - 2016-05-20 19:27:38 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:38 --> Input Class Initialized
INFO - 2016-05-20 19:27:38 --> Language Class Initialized
INFO - 2016-05-20 19:27:38 --> Loader Class Initialized
INFO - 2016-05-20 19:27:38 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:38 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:38 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:38 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:38 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:38 --> Controller Class Initialized
INFO - 2016-05-20 19:27:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:27:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:27:38 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:38 --> Total execution time: 0.0659
INFO - 2016-05-20 19:27:38 --> Config Class Initialized
INFO - 2016-05-20 19:27:38 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:38 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:38 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:38 --> URI Class Initialized
INFO - 2016-05-20 19:27:38 --> Router Class Initialized
INFO - 2016-05-20 19:27:38 --> Output Class Initialized
INFO - 2016-05-20 19:27:38 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:38 --> Input Class Initialized
INFO - 2016-05-20 19:27:38 --> Language Class Initialized
INFO - 2016-05-20 19:27:38 --> Loader Class Initialized
INFO - 2016-05-20 19:27:38 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:38 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:38 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:38 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:38 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:38 --> Controller Class Initialized
INFO - 2016-05-20 19:27:38 --> Model Class Initialized
INFO - 2016-05-20 19:27:38 --> Database Driver Class Initialized
INFO - 2016-05-20 19:27:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:27:38 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:27:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:27:38 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:38 --> Total execution time: 0.0968
INFO - 2016-05-20 19:27:41 --> Config Class Initialized
INFO - 2016-05-20 19:27:41 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:41 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:41 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:41 --> URI Class Initialized
INFO - 2016-05-20 19:27:41 --> Router Class Initialized
INFO - 2016-05-20 19:27:41 --> Output Class Initialized
INFO - 2016-05-20 19:27:41 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:41 --> Input Class Initialized
INFO - 2016-05-20 19:27:41 --> Language Class Initialized
INFO - 2016-05-20 19:27:41 --> Loader Class Initialized
INFO - 2016-05-20 19:27:41 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:41 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:41 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:41 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:41 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:41 --> Controller Class Initialized
INFO - 2016-05-20 19:27:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:27:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:27:41 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:41 --> Total execution time: 0.0578
INFO - 2016-05-20 19:27:41 --> Config Class Initialized
INFO - 2016-05-20 19:27:41 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:41 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:41 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:41 --> URI Class Initialized
INFO - 2016-05-20 19:27:41 --> Router Class Initialized
INFO - 2016-05-20 19:27:41 --> Output Class Initialized
INFO - 2016-05-20 19:27:41 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:41 --> Input Class Initialized
INFO - 2016-05-20 19:27:41 --> Language Class Initialized
INFO - 2016-05-20 19:27:41 --> Loader Class Initialized
INFO - 2016-05-20 19:27:41 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:41 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:41 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:41 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:41 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:41 --> Controller Class Initialized
INFO - 2016-05-20 19:27:41 --> Model Class Initialized
INFO - 2016-05-20 19:27:41 --> Database Driver Class Initialized
INFO - 2016-05-20 19:27:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:27:41 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:27:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:27:41 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:41 --> Total execution time: 0.0873
INFO - 2016-05-20 19:27:42 --> Config Class Initialized
INFO - 2016-05-20 19:27:42 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:42 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:42 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:42 --> URI Class Initialized
INFO - 2016-05-20 19:27:42 --> Router Class Initialized
INFO - 2016-05-20 19:27:42 --> Output Class Initialized
INFO - 2016-05-20 19:27:42 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:42 --> Input Class Initialized
INFO - 2016-05-20 19:27:42 --> Language Class Initialized
INFO - 2016-05-20 19:27:42 --> Loader Class Initialized
INFO - 2016-05-20 19:27:42 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:42 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:42 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:42 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:42 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:42 --> Controller Class Initialized
INFO - 2016-05-20 19:27:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:27:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:27:42 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:42 --> Total execution time: 0.0665
INFO - 2016-05-20 19:27:43 --> Config Class Initialized
INFO - 2016-05-20 19:27:43 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:43 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:43 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:43 --> URI Class Initialized
INFO - 2016-05-20 19:27:43 --> Router Class Initialized
INFO - 2016-05-20 19:27:43 --> Output Class Initialized
INFO - 2016-05-20 19:27:43 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:43 --> Input Class Initialized
INFO - 2016-05-20 19:27:43 --> Language Class Initialized
INFO - 2016-05-20 19:27:43 --> Loader Class Initialized
INFO - 2016-05-20 19:27:43 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:43 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:43 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:43 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:43 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:43 --> Controller Class Initialized
INFO - 2016-05-20 19:27:43 --> Model Class Initialized
INFO - 2016-05-20 19:27:43 --> Database Driver Class Initialized
INFO - 2016-05-20 19:27:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:27:43 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:27:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:27:43 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:43 --> Total execution time: 0.1064
INFO - 2016-05-20 19:27:43 --> Config Class Initialized
INFO - 2016-05-20 19:27:43 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:43 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:43 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:43 --> URI Class Initialized
INFO - 2016-05-20 19:27:43 --> Router Class Initialized
INFO - 2016-05-20 19:27:43 --> Output Class Initialized
INFO - 2016-05-20 19:27:43 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:43 --> Input Class Initialized
INFO - 2016-05-20 19:27:43 --> Language Class Initialized
INFO - 2016-05-20 19:27:43 --> Loader Class Initialized
INFO - 2016-05-20 19:27:43 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:43 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:43 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:43 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:43 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:43 --> Controller Class Initialized
INFO - 2016-05-20 19:27:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:27:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:27:43 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:43 --> Total execution time: 0.0573
INFO - 2016-05-20 19:27:44 --> Config Class Initialized
INFO - 2016-05-20 19:27:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:44 --> URI Class Initialized
INFO - 2016-05-20 19:27:44 --> Router Class Initialized
INFO - 2016-05-20 19:27:44 --> Output Class Initialized
INFO - 2016-05-20 19:27:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:44 --> Input Class Initialized
INFO - 2016-05-20 19:27:44 --> Language Class Initialized
INFO - 2016-05-20 19:27:44 --> Loader Class Initialized
INFO - 2016-05-20 19:27:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:44 --> Controller Class Initialized
INFO - 2016-05-20 19:27:44 --> Model Class Initialized
INFO - 2016-05-20 19:27:44 --> Database Driver Class Initialized
INFO - 2016-05-20 19:27:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:27:44 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:27:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:27:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:44 --> Total execution time: 0.1122
INFO - 2016-05-20 19:27:44 --> Config Class Initialized
INFO - 2016-05-20 19:27:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:44 --> URI Class Initialized
INFO - 2016-05-20 19:27:44 --> Router Class Initialized
INFO - 2016-05-20 19:27:44 --> Output Class Initialized
INFO - 2016-05-20 19:27:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:44 --> Input Class Initialized
INFO - 2016-05-20 19:27:44 --> Language Class Initialized
INFO - 2016-05-20 19:27:44 --> Loader Class Initialized
INFO - 2016-05-20 19:27:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:44 --> Controller Class Initialized
INFO - 2016-05-20 19:27:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:27:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:27:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:44 --> Total execution time: 0.0633
INFO - 2016-05-20 19:27:45 --> Config Class Initialized
INFO - 2016-05-20 19:27:45 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:45 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:45 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:45 --> URI Class Initialized
INFO - 2016-05-20 19:27:45 --> Router Class Initialized
INFO - 2016-05-20 19:27:45 --> Output Class Initialized
INFO - 2016-05-20 19:27:45 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:45 --> Input Class Initialized
INFO - 2016-05-20 19:27:45 --> Language Class Initialized
INFO - 2016-05-20 19:27:45 --> Loader Class Initialized
INFO - 2016-05-20 19:27:45 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:45 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:45 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:45 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:45 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:45 --> Controller Class Initialized
INFO - 2016-05-20 19:27:45 --> Model Class Initialized
INFO - 2016-05-20 19:27:45 --> Database Driver Class Initialized
INFO - 2016-05-20 19:27:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:27:45 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:27:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:27:45 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:45 --> Total execution time: 0.1142
INFO - 2016-05-20 19:27:56 --> Config Class Initialized
INFO - 2016-05-20 19:27:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:56 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:56 --> URI Class Initialized
INFO - 2016-05-20 19:27:56 --> Router Class Initialized
INFO - 2016-05-20 19:27:56 --> Output Class Initialized
INFO - 2016-05-20 19:27:56 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:56 --> Input Class Initialized
INFO - 2016-05-20 19:27:56 --> Language Class Initialized
INFO - 2016-05-20 19:27:56 --> Loader Class Initialized
INFO - 2016-05-20 19:27:56 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:56 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:56 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:56 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:56 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:56 --> Controller Class Initialized
INFO - 2016-05-20 19:27:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:27:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:27:56 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:56 --> Total execution time: 0.0551
INFO - 2016-05-20 19:27:57 --> Config Class Initialized
INFO - 2016-05-20 19:27:57 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:57 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:57 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:57 --> URI Class Initialized
INFO - 2016-05-20 19:27:57 --> Router Class Initialized
INFO - 2016-05-20 19:27:57 --> Output Class Initialized
INFO - 2016-05-20 19:27:57 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:57 --> Input Class Initialized
INFO - 2016-05-20 19:27:57 --> Language Class Initialized
INFO - 2016-05-20 19:27:57 --> Loader Class Initialized
INFO - 2016-05-20 19:27:57 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:57 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:57 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:57 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:57 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:57 --> Controller Class Initialized
INFO - 2016-05-20 19:27:57 --> Model Class Initialized
INFO - 2016-05-20 19:27:57 --> Database Driver Class Initialized
INFO - 2016-05-20 19:27:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:27:57 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:27:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:27:57 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:57 --> Total execution time: 0.1121
INFO - 2016-05-20 19:27:58 --> Config Class Initialized
INFO - 2016-05-20 19:27:58 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:58 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:58 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:58 --> URI Class Initialized
INFO - 2016-05-20 19:27:58 --> Router Class Initialized
INFO - 2016-05-20 19:27:58 --> Output Class Initialized
INFO - 2016-05-20 19:27:58 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:58 --> Input Class Initialized
INFO - 2016-05-20 19:27:58 --> Language Class Initialized
INFO - 2016-05-20 19:27:58 --> Loader Class Initialized
INFO - 2016-05-20 19:27:58 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:58 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:58 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:58 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:58 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:58 --> Controller Class Initialized
INFO - 2016-05-20 19:27:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:27:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:27:58 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:58 --> Total execution time: 0.0794
INFO - 2016-05-20 19:27:58 --> Config Class Initialized
INFO - 2016-05-20 19:27:58 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:27:58 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:27:58 --> Utf8 Class Initialized
INFO - 2016-05-20 19:27:58 --> URI Class Initialized
INFO - 2016-05-20 19:27:58 --> Router Class Initialized
INFO - 2016-05-20 19:27:58 --> Output Class Initialized
INFO - 2016-05-20 19:27:58 --> Security Class Initialized
DEBUG - 2016-05-20 19:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:27:58 --> Input Class Initialized
INFO - 2016-05-20 19:27:58 --> Language Class Initialized
INFO - 2016-05-20 19:27:58 --> Loader Class Initialized
INFO - 2016-05-20 19:27:58 --> Helper loaded: url_helper
INFO - 2016-05-20 19:27:58 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:27:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:27:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:27:58 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:27:58 --> Helper loaded: form_helper
INFO - 2016-05-20 19:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:27:58 --> Form Validation Class Initialized
INFO - 2016-05-20 19:27:58 --> Controller Class Initialized
INFO - 2016-05-20 19:27:58 --> Model Class Initialized
INFO - 2016-05-20 19:27:58 --> Database Driver Class Initialized
INFO - 2016-05-20 19:27:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:27:58 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:27:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:27:58 --> Final output sent to browser
DEBUG - 2016-05-20 19:27:58 --> Total execution time: 0.1231
INFO - 2016-05-20 19:28:30 --> Config Class Initialized
INFO - 2016-05-20 19:28:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:30 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:30 --> URI Class Initialized
INFO - 2016-05-20 19:28:30 --> Router Class Initialized
INFO - 2016-05-20 19:28:30 --> Output Class Initialized
INFO - 2016-05-20 19:28:30 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:30 --> Input Class Initialized
INFO - 2016-05-20 19:28:30 --> Language Class Initialized
INFO - 2016-05-20 19:28:30 --> Loader Class Initialized
INFO - 2016-05-20 19:28:30 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:30 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:30 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:30 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:30 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:30 --> Controller Class Initialized
INFO - 2016-05-20 19:28:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:28:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:28:30 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:30 --> Total execution time: 0.1562
INFO - 2016-05-20 19:28:31 --> Config Class Initialized
INFO - 2016-05-20 19:28:31 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:31 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:31 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:31 --> URI Class Initialized
INFO - 2016-05-20 19:28:31 --> Router Class Initialized
INFO - 2016-05-20 19:28:31 --> Output Class Initialized
INFO - 2016-05-20 19:28:31 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:31 --> Input Class Initialized
INFO - 2016-05-20 19:28:31 --> Language Class Initialized
INFO - 2016-05-20 19:28:31 --> Loader Class Initialized
INFO - 2016-05-20 19:28:31 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:31 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:31 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:31 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:31 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:31 --> Controller Class Initialized
INFO - 2016-05-20 19:28:31 --> Model Class Initialized
INFO - 2016-05-20 19:28:31 --> Database Driver Class Initialized
INFO - 2016-05-20 19:28:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:28:31 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:28:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:28:31 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:31 --> Total execution time: 0.1081
INFO - 2016-05-20 19:28:32 --> Config Class Initialized
INFO - 2016-05-20 19:28:32 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:32 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:32 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:32 --> URI Class Initialized
INFO - 2016-05-20 19:28:32 --> Router Class Initialized
INFO - 2016-05-20 19:28:32 --> Output Class Initialized
INFO - 2016-05-20 19:28:32 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:32 --> Input Class Initialized
INFO - 2016-05-20 19:28:32 --> Language Class Initialized
INFO - 2016-05-20 19:28:32 --> Loader Class Initialized
INFO - 2016-05-20 19:28:32 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:32 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:32 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:32 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:32 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:32 --> Controller Class Initialized
INFO - 2016-05-20 19:28:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:28:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:28:32 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:32 --> Total execution time: 0.0890
INFO - 2016-05-20 19:28:32 --> Config Class Initialized
INFO - 2016-05-20 19:28:32 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:32 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:32 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:32 --> URI Class Initialized
INFO - 2016-05-20 19:28:32 --> Router Class Initialized
INFO - 2016-05-20 19:28:32 --> Output Class Initialized
INFO - 2016-05-20 19:28:32 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:32 --> Input Class Initialized
INFO - 2016-05-20 19:28:32 --> Language Class Initialized
INFO - 2016-05-20 19:28:32 --> Loader Class Initialized
INFO - 2016-05-20 19:28:32 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:32 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:32 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:32 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:32 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:32 --> Controller Class Initialized
INFO - 2016-05-20 19:28:32 --> Model Class Initialized
INFO - 2016-05-20 19:28:32 --> Database Driver Class Initialized
INFO - 2016-05-20 19:28:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:28:32 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:28:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:28:32 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:32 --> Total execution time: 0.1089
INFO - 2016-05-20 19:28:33 --> Config Class Initialized
INFO - 2016-05-20 19:28:33 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:33 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:33 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:33 --> URI Class Initialized
INFO - 2016-05-20 19:28:33 --> Router Class Initialized
INFO - 2016-05-20 19:28:33 --> Output Class Initialized
INFO - 2016-05-20 19:28:33 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:33 --> Input Class Initialized
INFO - 2016-05-20 19:28:33 --> Language Class Initialized
INFO - 2016-05-20 19:28:33 --> Loader Class Initialized
INFO - 2016-05-20 19:28:33 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:33 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:33 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:33 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:33 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:33 --> Controller Class Initialized
INFO - 2016-05-20 19:28:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:28:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:28:33 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:33 --> Total execution time: 0.0777
INFO - 2016-05-20 19:28:34 --> Config Class Initialized
INFO - 2016-05-20 19:28:34 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:34 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:34 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:34 --> URI Class Initialized
INFO - 2016-05-20 19:28:34 --> Router Class Initialized
INFO - 2016-05-20 19:28:34 --> Output Class Initialized
INFO - 2016-05-20 19:28:34 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:34 --> Input Class Initialized
INFO - 2016-05-20 19:28:34 --> Language Class Initialized
INFO - 2016-05-20 19:28:34 --> Loader Class Initialized
INFO - 2016-05-20 19:28:34 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:34 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:34 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:34 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:34 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:34 --> Controller Class Initialized
INFO - 2016-05-20 19:28:34 --> Model Class Initialized
INFO - 2016-05-20 19:28:34 --> Database Driver Class Initialized
INFO - 2016-05-20 19:28:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:28:34 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:28:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:28:34 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:34 --> Total execution time: 0.1026
INFO - 2016-05-20 19:28:37 --> Config Class Initialized
INFO - 2016-05-20 19:28:37 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:37 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:37 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:37 --> URI Class Initialized
INFO - 2016-05-20 19:28:37 --> Router Class Initialized
INFO - 2016-05-20 19:28:37 --> Output Class Initialized
INFO - 2016-05-20 19:28:37 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:37 --> Input Class Initialized
INFO - 2016-05-20 19:28:37 --> Language Class Initialized
INFO - 2016-05-20 19:28:37 --> Loader Class Initialized
INFO - 2016-05-20 19:28:37 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:37 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:37 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:37 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:37 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:37 --> Controller Class Initialized
INFO - 2016-05-20 19:28:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:28:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:28:37 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:37 --> Total execution time: 0.0752
INFO - 2016-05-20 19:28:38 --> Config Class Initialized
INFO - 2016-05-20 19:28:38 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:38 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:38 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:38 --> URI Class Initialized
INFO - 2016-05-20 19:28:38 --> Router Class Initialized
INFO - 2016-05-20 19:28:38 --> Output Class Initialized
INFO - 2016-05-20 19:28:38 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:38 --> Input Class Initialized
INFO - 2016-05-20 19:28:38 --> Language Class Initialized
INFO - 2016-05-20 19:28:38 --> Loader Class Initialized
INFO - 2016-05-20 19:28:38 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:38 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:38 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:38 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:38 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:38 --> Controller Class Initialized
INFO - 2016-05-20 19:28:38 --> Model Class Initialized
INFO - 2016-05-20 19:28:38 --> Database Driver Class Initialized
INFO - 2016-05-20 19:28:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:28:38 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:28:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:28:38 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:38 --> Total execution time: 0.1010
INFO - 2016-05-20 19:28:39 --> Config Class Initialized
INFO - 2016-05-20 19:28:39 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:39 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:39 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:39 --> URI Class Initialized
INFO - 2016-05-20 19:28:39 --> Router Class Initialized
INFO - 2016-05-20 19:28:39 --> Output Class Initialized
INFO - 2016-05-20 19:28:39 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:39 --> Input Class Initialized
INFO - 2016-05-20 19:28:39 --> Language Class Initialized
INFO - 2016-05-20 19:28:39 --> Loader Class Initialized
INFO - 2016-05-20 19:28:39 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:39 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:39 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:39 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:39 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:39 --> Controller Class Initialized
INFO - 2016-05-20 19:28:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:28:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:28:39 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:39 --> Total execution time: 0.1103
INFO - 2016-05-20 19:28:39 --> Config Class Initialized
INFO - 2016-05-20 19:28:39 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:39 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:39 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:39 --> URI Class Initialized
INFO - 2016-05-20 19:28:39 --> Router Class Initialized
INFO - 2016-05-20 19:28:39 --> Output Class Initialized
INFO - 2016-05-20 19:28:39 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:39 --> Input Class Initialized
INFO - 2016-05-20 19:28:39 --> Language Class Initialized
INFO - 2016-05-20 19:28:39 --> Loader Class Initialized
INFO - 2016-05-20 19:28:39 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:39 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:39 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:39 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:39 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:39 --> Controller Class Initialized
INFO - 2016-05-20 19:28:39 --> Model Class Initialized
INFO - 2016-05-20 19:28:39 --> Database Driver Class Initialized
INFO - 2016-05-20 19:28:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:28:39 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:28:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:28:39 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:39 --> Total execution time: 0.1113
INFO - 2016-05-20 19:28:45 --> Config Class Initialized
INFO - 2016-05-20 19:28:45 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:45 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:45 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:45 --> URI Class Initialized
INFO - 2016-05-20 19:28:45 --> Router Class Initialized
INFO - 2016-05-20 19:28:45 --> Output Class Initialized
INFO - 2016-05-20 19:28:45 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:45 --> Input Class Initialized
INFO - 2016-05-20 19:28:45 --> Language Class Initialized
INFO - 2016-05-20 19:28:45 --> Loader Class Initialized
INFO - 2016-05-20 19:28:45 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:45 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:45 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:45 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:45 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:45 --> Controller Class Initialized
INFO - 2016-05-20 19:28:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:28:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:28:45 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:45 --> Total execution time: 0.0742
INFO - 2016-05-20 19:28:46 --> Config Class Initialized
INFO - 2016-05-20 19:28:46 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:46 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:46 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:46 --> URI Class Initialized
INFO - 2016-05-20 19:28:46 --> Router Class Initialized
INFO - 2016-05-20 19:28:46 --> Output Class Initialized
INFO - 2016-05-20 19:28:46 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:46 --> Input Class Initialized
INFO - 2016-05-20 19:28:46 --> Language Class Initialized
INFO - 2016-05-20 19:28:46 --> Loader Class Initialized
INFO - 2016-05-20 19:28:46 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:46 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:46 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:46 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:46 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:46 --> Controller Class Initialized
INFO - 2016-05-20 19:28:46 --> Model Class Initialized
INFO - 2016-05-20 19:28:46 --> Database Driver Class Initialized
INFO - 2016-05-20 19:28:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:28:46 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:28:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:28:46 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:46 --> Total execution time: 0.0914
INFO - 2016-05-20 19:28:48 --> Config Class Initialized
INFO - 2016-05-20 19:28:48 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:48 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:48 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:48 --> URI Class Initialized
INFO - 2016-05-20 19:28:48 --> Router Class Initialized
INFO - 2016-05-20 19:28:48 --> Output Class Initialized
INFO - 2016-05-20 19:28:48 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:48 --> Input Class Initialized
INFO - 2016-05-20 19:28:48 --> Language Class Initialized
INFO - 2016-05-20 19:28:48 --> Loader Class Initialized
INFO - 2016-05-20 19:28:48 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:48 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:48 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:48 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:48 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:48 --> Controller Class Initialized
INFO - 2016-05-20 19:28:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:28:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:28:48 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:48 --> Total execution time: 0.0594
INFO - 2016-05-20 19:28:49 --> Config Class Initialized
INFO - 2016-05-20 19:28:49 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:49 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:49 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:49 --> URI Class Initialized
INFO - 2016-05-20 19:28:49 --> Router Class Initialized
INFO - 2016-05-20 19:28:49 --> Output Class Initialized
INFO - 2016-05-20 19:28:49 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:49 --> Input Class Initialized
INFO - 2016-05-20 19:28:49 --> Language Class Initialized
INFO - 2016-05-20 19:28:49 --> Loader Class Initialized
INFO - 2016-05-20 19:28:49 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:49 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:49 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:49 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:49 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:49 --> Controller Class Initialized
INFO - 2016-05-20 19:28:49 --> Model Class Initialized
INFO - 2016-05-20 19:28:49 --> Database Driver Class Initialized
INFO - 2016-05-20 19:28:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:28:49 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:28:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:28:49 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:49 --> Total execution time: 0.0914
INFO - 2016-05-20 19:28:49 --> Config Class Initialized
INFO - 2016-05-20 19:28:49 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:49 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:49 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:49 --> URI Class Initialized
INFO - 2016-05-20 19:28:49 --> Router Class Initialized
INFO - 2016-05-20 19:28:49 --> Output Class Initialized
INFO - 2016-05-20 19:28:49 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:49 --> Input Class Initialized
INFO - 2016-05-20 19:28:49 --> Language Class Initialized
INFO - 2016-05-20 19:28:49 --> Loader Class Initialized
INFO - 2016-05-20 19:28:49 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:49 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:49 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:49 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:49 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:49 --> Controller Class Initialized
INFO - 2016-05-20 19:28:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:28:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:28:49 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:49 --> Total execution time: 0.0689
INFO - 2016-05-20 19:28:50 --> Config Class Initialized
INFO - 2016-05-20 19:28:50 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:28:50 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:28:50 --> Utf8 Class Initialized
INFO - 2016-05-20 19:28:50 --> URI Class Initialized
INFO - 2016-05-20 19:28:50 --> Router Class Initialized
INFO - 2016-05-20 19:28:50 --> Output Class Initialized
INFO - 2016-05-20 19:28:50 --> Security Class Initialized
DEBUG - 2016-05-20 19:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:28:50 --> Input Class Initialized
INFO - 2016-05-20 19:28:50 --> Language Class Initialized
INFO - 2016-05-20 19:28:50 --> Loader Class Initialized
INFO - 2016-05-20 19:28:50 --> Helper loaded: url_helper
INFO - 2016-05-20 19:28:50 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:28:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:28:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:28:50 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:28:50 --> Helper loaded: form_helper
INFO - 2016-05-20 19:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:28:50 --> Form Validation Class Initialized
INFO - 2016-05-20 19:28:50 --> Controller Class Initialized
INFO - 2016-05-20 19:28:50 --> Model Class Initialized
INFO - 2016-05-20 19:28:50 --> Database Driver Class Initialized
INFO - 2016-05-20 19:28:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:28:50 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:28:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:28:50 --> Final output sent to browser
DEBUG - 2016-05-20 19:28:50 --> Total execution time: 0.1197
INFO - 2016-05-20 19:29:04 --> Config Class Initialized
INFO - 2016-05-20 19:29:04 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:04 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:04 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:04 --> URI Class Initialized
INFO - 2016-05-20 19:29:04 --> Router Class Initialized
INFO - 2016-05-20 19:29:04 --> Output Class Initialized
INFO - 2016-05-20 19:29:04 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:04 --> Input Class Initialized
INFO - 2016-05-20 19:29:04 --> Language Class Initialized
INFO - 2016-05-20 19:29:04 --> Loader Class Initialized
INFO - 2016-05-20 19:29:04 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:04 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:04 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:04 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:04 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:04 --> Controller Class Initialized
INFO - 2016-05-20 19:29:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:29:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:29:04 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:04 --> Total execution time: 0.1518
INFO - 2016-05-20 19:29:05 --> Config Class Initialized
INFO - 2016-05-20 19:29:05 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:05 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:05 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:05 --> URI Class Initialized
INFO - 2016-05-20 19:29:05 --> Router Class Initialized
INFO - 2016-05-20 19:29:05 --> Output Class Initialized
INFO - 2016-05-20 19:29:05 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:05 --> Input Class Initialized
INFO - 2016-05-20 19:29:05 --> Language Class Initialized
INFO - 2016-05-20 19:29:05 --> Loader Class Initialized
INFO - 2016-05-20 19:29:05 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:05 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:05 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:05 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:05 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:05 --> Controller Class Initialized
INFO - 2016-05-20 19:29:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:29:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:29:05 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:05 --> Total execution time: 0.0736
INFO - 2016-05-20 19:29:27 --> Config Class Initialized
INFO - 2016-05-20 19:29:27 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:27 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:27 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:27 --> URI Class Initialized
INFO - 2016-05-20 19:29:27 --> Router Class Initialized
INFO - 2016-05-20 19:29:27 --> Output Class Initialized
INFO - 2016-05-20 19:29:27 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:27 --> Input Class Initialized
INFO - 2016-05-20 19:29:27 --> Language Class Initialized
INFO - 2016-05-20 19:29:27 --> Loader Class Initialized
INFO - 2016-05-20 19:29:27 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:27 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:27 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:27 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:27 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:27 --> Controller Class Initialized
INFO - 2016-05-20 19:29:27 --> Model Class Initialized
INFO - 2016-05-20 19:29:27 --> Database Driver Class Initialized
INFO - 2016-05-20 19:29:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:29:27 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:29:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:29:27 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:27 --> Total execution time: 0.0856
INFO - 2016-05-20 19:29:32 --> Config Class Initialized
INFO - 2016-05-20 19:29:32 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:32 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:32 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:32 --> URI Class Initialized
INFO - 2016-05-20 19:29:32 --> Router Class Initialized
INFO - 2016-05-20 19:29:32 --> Output Class Initialized
INFO - 2016-05-20 19:29:32 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:32 --> Input Class Initialized
INFO - 2016-05-20 19:29:32 --> Language Class Initialized
INFO - 2016-05-20 19:29:32 --> Loader Class Initialized
INFO - 2016-05-20 19:29:32 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:32 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:32 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:32 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:32 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:32 --> Controller Class Initialized
INFO - 2016-05-20 19:29:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:29:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-20 19:29:32 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:32 --> Total execution time: 0.0587
INFO - 2016-05-20 19:29:33 --> Config Class Initialized
INFO - 2016-05-20 19:29:33 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:33 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:33 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:33 --> URI Class Initialized
INFO - 2016-05-20 19:29:33 --> Router Class Initialized
INFO - 2016-05-20 19:29:33 --> Output Class Initialized
INFO - 2016-05-20 19:29:33 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:33 --> Input Class Initialized
INFO - 2016-05-20 19:29:33 --> Language Class Initialized
INFO - 2016-05-20 19:29:33 --> Loader Class Initialized
INFO - 2016-05-20 19:29:33 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:33 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:33 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:33 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:33 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:33 --> Controller Class Initialized
INFO - 2016-05-20 19:29:33 --> Model Class Initialized
INFO - 2016-05-20 19:29:33 --> Database Driver Class Initialized
INFO - 2016-05-20 19:29:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:29:33 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:29:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:29:33 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:33 --> Total execution time: 0.1042
INFO - 2016-05-20 19:29:39 --> Config Class Initialized
INFO - 2016-05-20 19:29:39 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:39 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:39 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:39 --> URI Class Initialized
INFO - 2016-05-20 19:29:39 --> Router Class Initialized
INFO - 2016-05-20 19:29:39 --> Output Class Initialized
INFO - 2016-05-20 19:29:39 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:39 --> Input Class Initialized
INFO - 2016-05-20 19:29:39 --> Language Class Initialized
INFO - 2016-05-20 19:29:39 --> Loader Class Initialized
INFO - 2016-05-20 19:29:39 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:39 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:39 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:39 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:39 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:39 --> Controller Class Initialized
INFO - 2016-05-20 19:29:39 --> Config Class Initialized
INFO - 2016-05-20 19:29:39 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:39 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:39 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:39 --> URI Class Initialized
INFO - 2016-05-20 19:29:39 --> Router Class Initialized
INFO - 2016-05-20 19:29:39 --> Output Class Initialized
INFO - 2016-05-20 19:29:39 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:39 --> Input Class Initialized
INFO - 2016-05-20 19:29:39 --> Language Class Initialized
INFO - 2016-05-20 19:29:39 --> Loader Class Initialized
INFO - 2016-05-20 19:29:39 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:39 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:39 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:39 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:39 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:39 --> Controller Class Initialized
INFO - 2016-05-20 19:29:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:29:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:29:39 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:39 --> Total execution time: 0.0882
INFO - 2016-05-20 19:29:39 --> Config Class Initialized
INFO - 2016-05-20 19:29:39 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:39 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:39 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:39 --> URI Class Initialized
INFO - 2016-05-20 19:29:39 --> Router Class Initialized
INFO - 2016-05-20 19:29:39 --> Output Class Initialized
INFO - 2016-05-20 19:29:39 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:39 --> Input Class Initialized
INFO - 2016-05-20 19:29:39 --> Language Class Initialized
INFO - 2016-05-20 19:29:39 --> Loader Class Initialized
INFO - 2016-05-20 19:29:39 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:39 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:39 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:39 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:39 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:39 --> Controller Class Initialized
INFO - 2016-05-20 19:29:39 --> Model Class Initialized
INFO - 2016-05-20 19:29:39 --> Database Driver Class Initialized
INFO - 2016-05-20 19:29:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:29:39 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:29:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:29:39 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:39 --> Total execution time: 0.1066
INFO - 2016-05-20 19:29:42 --> Config Class Initialized
INFO - 2016-05-20 19:29:42 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:42 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:42 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:42 --> URI Class Initialized
INFO - 2016-05-20 19:29:42 --> Router Class Initialized
INFO - 2016-05-20 19:29:42 --> Output Class Initialized
INFO - 2016-05-20 19:29:42 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:42 --> Input Class Initialized
INFO - 2016-05-20 19:29:42 --> Language Class Initialized
INFO - 2016-05-20 19:29:42 --> Loader Class Initialized
INFO - 2016-05-20 19:29:42 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:42 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:42 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:42 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:42 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:42 --> Controller Class Initialized
INFO - 2016-05-20 19:29:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:29:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:29:42 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:42 --> Total execution time: 0.0902
INFO - 2016-05-20 19:29:42 --> Config Class Initialized
INFO - 2016-05-20 19:29:42 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:42 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:42 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:42 --> URI Class Initialized
INFO - 2016-05-20 19:29:42 --> Router Class Initialized
INFO - 2016-05-20 19:29:42 --> Output Class Initialized
INFO - 2016-05-20 19:29:42 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:42 --> Input Class Initialized
INFO - 2016-05-20 19:29:42 --> Language Class Initialized
INFO - 2016-05-20 19:29:42 --> Loader Class Initialized
INFO - 2016-05-20 19:29:42 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:42 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:42 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:42 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:42 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:42 --> Controller Class Initialized
INFO - 2016-05-20 19:29:42 --> Model Class Initialized
INFO - 2016-05-20 19:29:42 --> Database Driver Class Initialized
INFO - 2016-05-20 19:29:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:29:42 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:29:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:29:42 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:42 --> Total execution time: 0.1006
INFO - 2016-05-20 19:29:49 --> Config Class Initialized
INFO - 2016-05-20 19:29:49 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:49 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:49 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:49 --> URI Class Initialized
INFO - 2016-05-20 19:29:49 --> Router Class Initialized
INFO - 2016-05-20 19:29:49 --> Output Class Initialized
INFO - 2016-05-20 19:29:49 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:49 --> Input Class Initialized
INFO - 2016-05-20 19:29:49 --> Language Class Initialized
INFO - 2016-05-20 19:29:49 --> Loader Class Initialized
INFO - 2016-05-20 19:29:49 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:49 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:49 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:49 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:49 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:49 --> Controller Class Initialized
INFO - 2016-05-20 19:29:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:29:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:29:49 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:49 --> Total execution time: 0.0644
INFO - 2016-05-20 19:29:50 --> Config Class Initialized
INFO - 2016-05-20 19:29:50 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:50 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:50 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:50 --> URI Class Initialized
INFO - 2016-05-20 19:29:50 --> Router Class Initialized
INFO - 2016-05-20 19:29:50 --> Output Class Initialized
INFO - 2016-05-20 19:29:50 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:50 --> Input Class Initialized
INFO - 2016-05-20 19:29:50 --> Language Class Initialized
INFO - 2016-05-20 19:29:50 --> Loader Class Initialized
INFO - 2016-05-20 19:29:50 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:50 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:50 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:50 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:50 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:50 --> Controller Class Initialized
INFO - 2016-05-20 19:29:50 --> Model Class Initialized
INFO - 2016-05-20 19:29:50 --> Database Driver Class Initialized
INFO - 2016-05-20 19:29:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:29:50 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:29:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:29:50 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:50 --> Total execution time: 0.1019
INFO - 2016-05-20 19:29:51 --> Config Class Initialized
INFO - 2016-05-20 19:29:51 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:51 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:51 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:51 --> URI Class Initialized
INFO - 2016-05-20 19:29:51 --> Router Class Initialized
INFO - 2016-05-20 19:29:51 --> Output Class Initialized
INFO - 2016-05-20 19:29:51 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:51 --> Input Class Initialized
INFO - 2016-05-20 19:29:51 --> Language Class Initialized
INFO - 2016-05-20 19:29:51 --> Loader Class Initialized
INFO - 2016-05-20 19:29:51 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:51 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:51 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:51 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:51 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:51 --> Controller Class Initialized
INFO - 2016-05-20 19:29:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:29:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:29:51 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:51 --> Total execution time: 0.0681
INFO - 2016-05-20 19:29:52 --> Config Class Initialized
INFO - 2016-05-20 19:29:52 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:52 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:52 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:52 --> URI Class Initialized
INFO - 2016-05-20 19:29:52 --> Router Class Initialized
INFO - 2016-05-20 19:29:52 --> Output Class Initialized
INFO - 2016-05-20 19:29:52 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:52 --> Input Class Initialized
INFO - 2016-05-20 19:29:52 --> Language Class Initialized
INFO - 2016-05-20 19:29:52 --> Loader Class Initialized
INFO - 2016-05-20 19:29:52 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:52 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:52 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:52 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:52 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:52 --> Controller Class Initialized
INFO - 2016-05-20 19:29:52 --> Model Class Initialized
INFO - 2016-05-20 19:29:52 --> Database Driver Class Initialized
INFO - 2016-05-20 19:29:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:29:52 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:29:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:29:52 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:52 --> Total execution time: 0.1167
INFO - 2016-05-20 19:29:53 --> Config Class Initialized
INFO - 2016-05-20 19:29:53 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:53 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:53 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:53 --> URI Class Initialized
INFO - 2016-05-20 19:29:53 --> Router Class Initialized
INFO - 2016-05-20 19:29:53 --> Output Class Initialized
INFO - 2016-05-20 19:29:53 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:53 --> Input Class Initialized
INFO - 2016-05-20 19:29:53 --> Language Class Initialized
INFO - 2016-05-20 19:29:53 --> Loader Class Initialized
INFO - 2016-05-20 19:29:53 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:53 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:53 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:53 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:53 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:53 --> Controller Class Initialized
INFO - 2016-05-20 19:29:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:29:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:29:53 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:53 --> Total execution time: 0.0690
INFO - 2016-05-20 19:29:54 --> Config Class Initialized
INFO - 2016-05-20 19:29:54 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:54 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:54 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:54 --> URI Class Initialized
INFO - 2016-05-20 19:29:54 --> Router Class Initialized
INFO - 2016-05-20 19:29:54 --> Output Class Initialized
INFO - 2016-05-20 19:29:54 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:54 --> Input Class Initialized
INFO - 2016-05-20 19:29:54 --> Language Class Initialized
INFO - 2016-05-20 19:29:54 --> Loader Class Initialized
INFO - 2016-05-20 19:29:54 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:54 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:54 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:54 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:54 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:54 --> Controller Class Initialized
INFO - 2016-05-20 19:29:54 --> Model Class Initialized
INFO - 2016-05-20 19:29:54 --> Database Driver Class Initialized
INFO - 2016-05-20 19:29:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:29:54 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:29:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:29:54 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:54 --> Total execution time: 0.1157
INFO - 2016-05-20 19:29:54 --> Config Class Initialized
INFO - 2016-05-20 19:29:54 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:54 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:54 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:54 --> URI Class Initialized
INFO - 2016-05-20 19:29:54 --> Router Class Initialized
INFO - 2016-05-20 19:29:54 --> Output Class Initialized
INFO - 2016-05-20 19:29:54 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:54 --> Input Class Initialized
INFO - 2016-05-20 19:29:54 --> Language Class Initialized
INFO - 2016-05-20 19:29:54 --> Loader Class Initialized
INFO - 2016-05-20 19:29:54 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:54 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:54 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:54 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:54 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:54 --> Controller Class Initialized
INFO - 2016-05-20 19:29:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:29:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:29:54 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:54 --> Total execution time: 0.0571
INFO - 2016-05-20 19:29:55 --> Config Class Initialized
INFO - 2016-05-20 19:29:55 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:55 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:55 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:55 --> URI Class Initialized
INFO - 2016-05-20 19:29:55 --> Router Class Initialized
INFO - 2016-05-20 19:29:55 --> Output Class Initialized
INFO - 2016-05-20 19:29:55 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:55 --> Input Class Initialized
INFO - 2016-05-20 19:29:55 --> Language Class Initialized
INFO - 2016-05-20 19:29:55 --> Loader Class Initialized
INFO - 2016-05-20 19:29:55 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:55 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:55 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:55 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:55 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:55 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:55 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:55 --> Controller Class Initialized
INFO - 2016-05-20 19:29:55 --> Model Class Initialized
INFO - 2016-05-20 19:29:55 --> Database Driver Class Initialized
INFO - 2016-05-20 19:29:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:29:55 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:29:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:29:55 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:55 --> Total execution time: 0.1088
INFO - 2016-05-20 19:29:58 --> Config Class Initialized
INFO - 2016-05-20 19:29:58 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:58 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:58 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:58 --> URI Class Initialized
INFO - 2016-05-20 19:29:58 --> Router Class Initialized
INFO - 2016-05-20 19:29:58 --> Output Class Initialized
INFO - 2016-05-20 19:29:58 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:58 --> Input Class Initialized
INFO - 2016-05-20 19:29:58 --> Language Class Initialized
INFO - 2016-05-20 19:29:58 --> Loader Class Initialized
INFO - 2016-05-20 19:29:58 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:58 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:58 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:58 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:58 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:58 --> Controller Class Initialized
INFO - 2016-05-20 19:29:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:29:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:29:58 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:58 --> Total execution time: 0.0648
INFO - 2016-05-20 19:29:58 --> Config Class Initialized
INFO - 2016-05-20 19:29:58 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:29:58 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:29:58 --> Utf8 Class Initialized
INFO - 2016-05-20 19:29:58 --> URI Class Initialized
INFO - 2016-05-20 19:29:58 --> Router Class Initialized
INFO - 2016-05-20 19:29:58 --> Output Class Initialized
INFO - 2016-05-20 19:29:58 --> Security Class Initialized
DEBUG - 2016-05-20 19:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:29:58 --> Input Class Initialized
INFO - 2016-05-20 19:29:58 --> Language Class Initialized
INFO - 2016-05-20 19:29:58 --> Loader Class Initialized
INFO - 2016-05-20 19:29:58 --> Helper loaded: url_helper
INFO - 2016-05-20 19:29:58 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:29:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:29:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:29:58 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:29:58 --> Helper loaded: form_helper
INFO - 2016-05-20 19:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:29:58 --> Form Validation Class Initialized
INFO - 2016-05-20 19:29:58 --> Controller Class Initialized
INFO - 2016-05-20 19:29:58 --> Model Class Initialized
INFO - 2016-05-20 19:29:58 --> Database Driver Class Initialized
INFO - 2016-05-20 19:29:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:29:59 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:29:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:29:59 --> Final output sent to browser
DEBUG - 2016-05-20 19:29:59 --> Total execution time: 0.1139
INFO - 2016-05-20 19:30:00 --> Config Class Initialized
INFO - 2016-05-20 19:30:00 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:30:00 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:30:00 --> Utf8 Class Initialized
INFO - 2016-05-20 19:30:00 --> URI Class Initialized
INFO - 2016-05-20 19:30:00 --> Router Class Initialized
INFO - 2016-05-20 19:30:00 --> Output Class Initialized
INFO - 2016-05-20 19:30:00 --> Security Class Initialized
DEBUG - 2016-05-20 19:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:30:00 --> Input Class Initialized
INFO - 2016-05-20 19:30:00 --> Language Class Initialized
INFO - 2016-05-20 19:30:00 --> Loader Class Initialized
INFO - 2016-05-20 19:30:00 --> Helper loaded: url_helper
INFO - 2016-05-20 19:30:00 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:30:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:30:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:30:00 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:30:00 --> Helper loaded: form_helper
INFO - 2016-05-20 19:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:30:00 --> Form Validation Class Initialized
INFO - 2016-05-20 19:30:00 --> Controller Class Initialized
INFO - 2016-05-20 19:30:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:30:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:30:00 --> Final output sent to browser
DEBUG - 2016-05-20 19:30:00 --> Total execution time: 0.0536
INFO - 2016-05-20 19:30:04 --> Config Class Initialized
INFO - 2016-05-20 19:30:04 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:30:04 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:30:04 --> Utf8 Class Initialized
INFO - 2016-05-20 19:30:04 --> URI Class Initialized
INFO - 2016-05-20 19:30:04 --> Router Class Initialized
INFO - 2016-05-20 19:30:04 --> Output Class Initialized
INFO - 2016-05-20 19:30:04 --> Security Class Initialized
DEBUG - 2016-05-20 19:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:30:04 --> Input Class Initialized
INFO - 2016-05-20 19:30:04 --> Language Class Initialized
INFO - 2016-05-20 19:30:04 --> Loader Class Initialized
INFO - 2016-05-20 19:30:04 --> Helper loaded: url_helper
INFO - 2016-05-20 19:30:04 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:30:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:30:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:30:04 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:30:04 --> Helper loaded: form_helper
INFO - 2016-05-20 19:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:30:04 --> Form Validation Class Initialized
INFO - 2016-05-20 19:30:04 --> Controller Class Initialized
INFO - 2016-05-20 19:30:04 --> Model Class Initialized
INFO - 2016-05-20 19:30:04 --> Database Driver Class Initialized
INFO - 2016-05-20 19:30:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:30:04 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:30:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:30:04 --> Final output sent to browser
DEBUG - 2016-05-20 19:30:04 --> Total execution time: 0.0847
INFO - 2016-05-20 19:30:05 --> Config Class Initialized
INFO - 2016-05-20 19:30:05 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:30:05 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:30:05 --> Utf8 Class Initialized
INFO - 2016-05-20 19:30:05 --> URI Class Initialized
INFO - 2016-05-20 19:30:05 --> Router Class Initialized
INFO - 2016-05-20 19:30:05 --> Output Class Initialized
INFO - 2016-05-20 19:30:05 --> Security Class Initialized
DEBUG - 2016-05-20 19:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:30:05 --> Input Class Initialized
INFO - 2016-05-20 19:30:05 --> Language Class Initialized
INFO - 2016-05-20 19:30:05 --> Loader Class Initialized
INFO - 2016-05-20 19:30:05 --> Helper loaded: url_helper
INFO - 2016-05-20 19:30:05 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:30:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:30:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:30:05 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:30:05 --> Helper loaded: form_helper
INFO - 2016-05-20 19:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:30:05 --> Form Validation Class Initialized
INFO - 2016-05-20 19:30:05 --> Controller Class Initialized
INFO - 2016-05-20 19:30:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:30:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:30:05 --> Final output sent to browser
DEBUG - 2016-05-20 19:30:05 --> Total execution time: 0.1596
INFO - 2016-05-20 19:30:06 --> Config Class Initialized
INFO - 2016-05-20 19:30:06 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:30:06 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:30:06 --> Utf8 Class Initialized
INFO - 2016-05-20 19:30:06 --> URI Class Initialized
INFO - 2016-05-20 19:30:06 --> Router Class Initialized
INFO - 2016-05-20 19:30:06 --> Output Class Initialized
INFO - 2016-05-20 19:30:06 --> Security Class Initialized
DEBUG - 2016-05-20 19:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:30:06 --> Input Class Initialized
INFO - 2016-05-20 19:30:06 --> Language Class Initialized
INFO - 2016-05-20 19:30:06 --> Loader Class Initialized
INFO - 2016-05-20 19:30:06 --> Helper loaded: url_helper
INFO - 2016-05-20 19:30:06 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:30:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:30:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:30:06 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:30:06 --> Helper loaded: form_helper
INFO - 2016-05-20 19:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:30:06 --> Form Validation Class Initialized
INFO - 2016-05-20 19:30:06 --> Controller Class Initialized
INFO - 2016-05-20 19:30:06 --> Model Class Initialized
INFO - 2016-05-20 19:30:06 --> Database Driver Class Initialized
INFO - 2016-05-20 19:30:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:30:06 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:30:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:30:06 --> Final output sent to browser
DEBUG - 2016-05-20 19:30:06 --> Total execution time: 0.1065
INFO - 2016-05-20 19:31:06 --> Config Class Initialized
INFO - 2016-05-20 19:31:06 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:31:06 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:31:06 --> Utf8 Class Initialized
INFO - 2016-05-20 19:31:06 --> URI Class Initialized
INFO - 2016-05-20 19:31:06 --> Router Class Initialized
INFO - 2016-05-20 19:31:06 --> Output Class Initialized
INFO - 2016-05-20 19:31:06 --> Security Class Initialized
DEBUG - 2016-05-20 19:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:31:06 --> Input Class Initialized
INFO - 2016-05-20 19:31:06 --> Language Class Initialized
INFO - 2016-05-20 19:31:06 --> Loader Class Initialized
INFO - 2016-05-20 19:31:06 --> Helper loaded: url_helper
INFO - 2016-05-20 19:31:06 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:31:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:31:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:31:06 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:31:06 --> Helper loaded: form_helper
INFO - 2016-05-20 19:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:31:06 --> Form Validation Class Initialized
INFO - 2016-05-20 19:31:06 --> Controller Class Initialized
INFO - 2016-05-20 19:31:06 --> Model Class Initialized
INFO - 2016-05-20 19:31:06 --> Database Driver Class Initialized
INFO - 2016-05-20 19:31:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:31:06 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:31:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:31:06 --> Final output sent to browser
DEBUG - 2016-05-20 19:31:06 --> Total execution time: 0.0879
INFO - 2016-05-20 19:34:43 --> Config Class Initialized
INFO - 2016-05-20 19:34:43 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:34:43 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:34:43 --> Utf8 Class Initialized
INFO - 2016-05-20 19:34:43 --> URI Class Initialized
INFO - 2016-05-20 19:34:43 --> Router Class Initialized
INFO - 2016-05-20 19:34:43 --> Output Class Initialized
INFO - 2016-05-20 19:34:43 --> Security Class Initialized
DEBUG - 2016-05-20 19:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:34:43 --> Input Class Initialized
INFO - 2016-05-20 19:34:43 --> Language Class Initialized
INFO - 2016-05-20 19:34:43 --> Loader Class Initialized
INFO - 2016-05-20 19:34:43 --> Helper loaded: url_helper
INFO - 2016-05-20 19:34:43 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:34:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:34:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:34:43 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:34:43 --> Helper loaded: form_helper
INFO - 2016-05-20 19:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:34:43 --> Form Validation Class Initialized
INFO - 2016-05-20 19:34:43 --> Controller Class Initialized
INFO - 2016-05-20 19:34:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-20 19:34:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:34:43 --> Final output sent to browser
DEBUG - 2016-05-20 19:34:43 --> Total execution time: 0.1013
INFO - 2016-05-20 19:34:44 --> Config Class Initialized
INFO - 2016-05-20 19:34:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:34:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:34:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:34:44 --> URI Class Initialized
INFO - 2016-05-20 19:34:44 --> Router Class Initialized
INFO - 2016-05-20 19:34:44 --> Output Class Initialized
INFO - 2016-05-20 19:34:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:34:44 --> Input Class Initialized
INFO - 2016-05-20 19:34:44 --> Language Class Initialized
INFO - 2016-05-20 19:34:44 --> Loader Class Initialized
INFO - 2016-05-20 19:34:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:34:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:34:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:34:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:34:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:34:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:34:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:34:44 --> Controller Class Initialized
INFO - 2016-05-20 19:34:44 --> Model Class Initialized
INFO - 2016-05-20 19:34:44 --> Database Driver Class Initialized
INFO - 2016-05-20 19:34:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:34:44 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:34:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:34:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:34:44 --> Total execution time: 0.0796
INFO - 2016-05-20 19:35:44 --> Config Class Initialized
INFO - 2016-05-20 19:35:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:35:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:35:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:35:44 --> URI Class Initialized
INFO - 2016-05-20 19:35:44 --> Router Class Initialized
INFO - 2016-05-20 19:35:44 --> Output Class Initialized
INFO - 2016-05-20 19:35:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:35:44 --> Input Class Initialized
INFO - 2016-05-20 19:35:44 --> Language Class Initialized
INFO - 2016-05-20 19:35:44 --> Loader Class Initialized
INFO - 2016-05-20 19:35:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:35:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:35:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:35:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:35:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:35:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:35:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:35:44 --> Controller Class Initialized
INFO - 2016-05-20 19:35:44 --> Model Class Initialized
INFO - 2016-05-20 19:35:44 --> Database Driver Class Initialized
INFO - 2016-05-20 19:35:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:35:44 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:35:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:35:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:35:44 --> Total execution time: 0.0911
INFO - 2016-05-20 19:36:44 --> Config Class Initialized
INFO - 2016-05-20 19:36:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:36:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:36:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:36:44 --> URI Class Initialized
INFO - 2016-05-20 19:36:44 --> Router Class Initialized
INFO - 2016-05-20 19:36:44 --> Output Class Initialized
INFO - 2016-05-20 19:36:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:36:44 --> Input Class Initialized
INFO - 2016-05-20 19:36:44 --> Language Class Initialized
INFO - 2016-05-20 19:36:44 --> Loader Class Initialized
INFO - 2016-05-20 19:36:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:36:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:36:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:36:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:36:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:36:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:36:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:36:44 --> Controller Class Initialized
INFO - 2016-05-20 19:36:44 --> Model Class Initialized
INFO - 2016-05-20 19:36:44 --> Database Driver Class Initialized
INFO - 2016-05-20 19:36:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:36:44 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:36:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:36:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:36:44 --> Total execution time: 0.0929
INFO - 2016-05-20 19:37:44 --> Config Class Initialized
INFO - 2016-05-20 19:37:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:37:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:37:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:37:44 --> URI Class Initialized
INFO - 2016-05-20 19:37:44 --> Router Class Initialized
INFO - 2016-05-20 19:37:44 --> Output Class Initialized
INFO - 2016-05-20 19:37:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:37:44 --> Input Class Initialized
INFO - 2016-05-20 19:37:44 --> Language Class Initialized
INFO - 2016-05-20 19:37:44 --> Loader Class Initialized
INFO - 2016-05-20 19:37:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:37:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:37:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:37:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:37:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:37:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:37:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:37:44 --> Controller Class Initialized
INFO - 2016-05-20 19:37:44 --> Model Class Initialized
INFO - 2016-05-20 19:37:44 --> Database Driver Class Initialized
INFO - 2016-05-20 19:37:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:37:44 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:37:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:37:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:37:44 --> Total execution time: 0.0963
INFO - 2016-05-20 19:38:44 --> Config Class Initialized
INFO - 2016-05-20 19:38:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:38:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:38:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:38:44 --> URI Class Initialized
INFO - 2016-05-20 19:38:44 --> Router Class Initialized
INFO - 2016-05-20 19:38:44 --> Output Class Initialized
INFO - 2016-05-20 19:38:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:38:44 --> Input Class Initialized
INFO - 2016-05-20 19:38:44 --> Language Class Initialized
INFO - 2016-05-20 19:38:44 --> Loader Class Initialized
INFO - 2016-05-20 19:38:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:38:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:38:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:38:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:38:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:38:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:38:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:38:44 --> Controller Class Initialized
INFO - 2016-05-20 19:38:44 --> Model Class Initialized
INFO - 2016-05-20 19:38:44 --> Database Driver Class Initialized
INFO - 2016-05-20 19:38:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:38:44 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:38:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:38:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:38:44 --> Total execution time: 0.0773
INFO - 2016-05-20 19:39:44 --> Config Class Initialized
INFO - 2016-05-20 19:39:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:39:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:39:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:39:44 --> URI Class Initialized
INFO - 2016-05-20 19:39:44 --> Router Class Initialized
INFO - 2016-05-20 19:39:44 --> Output Class Initialized
INFO - 2016-05-20 19:39:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:39:44 --> Input Class Initialized
INFO - 2016-05-20 19:39:44 --> Language Class Initialized
INFO - 2016-05-20 19:39:44 --> Loader Class Initialized
INFO - 2016-05-20 19:39:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:39:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:39:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:39:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:39:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:39:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:39:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:39:44 --> Controller Class Initialized
INFO - 2016-05-20 19:39:44 --> Model Class Initialized
INFO - 2016-05-20 19:39:44 --> Database Driver Class Initialized
INFO - 2016-05-20 19:39:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:39:44 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:39:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:39:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:39:44 --> Total execution time: 0.0738
INFO - 2016-05-20 19:40:44 --> Config Class Initialized
INFO - 2016-05-20 19:40:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:40:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:40:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:40:44 --> URI Class Initialized
INFO - 2016-05-20 19:40:44 --> Router Class Initialized
INFO - 2016-05-20 19:40:44 --> Output Class Initialized
INFO - 2016-05-20 19:40:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:40:44 --> Input Class Initialized
INFO - 2016-05-20 19:40:44 --> Language Class Initialized
INFO - 2016-05-20 19:40:44 --> Loader Class Initialized
INFO - 2016-05-20 19:40:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:40:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:40:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:40:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:40:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:40:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:40:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:40:44 --> Controller Class Initialized
INFO - 2016-05-20 19:40:44 --> Model Class Initialized
INFO - 2016-05-20 19:40:44 --> Database Driver Class Initialized
INFO - 2016-05-20 19:40:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:40:44 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:40:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:40:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:40:44 --> Total execution time: 0.0679
INFO - 2016-05-20 19:41:44 --> Config Class Initialized
INFO - 2016-05-20 19:41:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:41:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:41:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:41:44 --> URI Class Initialized
INFO - 2016-05-20 19:41:44 --> Router Class Initialized
INFO - 2016-05-20 19:41:44 --> Output Class Initialized
INFO - 2016-05-20 19:41:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:41:44 --> Input Class Initialized
INFO - 2016-05-20 19:41:44 --> Language Class Initialized
INFO - 2016-05-20 19:41:44 --> Loader Class Initialized
INFO - 2016-05-20 19:41:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:41:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:41:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:41:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:41:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:41:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:41:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:41:44 --> Controller Class Initialized
INFO - 2016-05-20 19:41:44 --> Model Class Initialized
INFO - 2016-05-20 19:41:44 --> Database Driver Class Initialized
INFO - 2016-05-20 19:41:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:41:44 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:41:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:41:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:41:44 --> Total execution time: 0.0748
INFO - 2016-05-20 19:42:44 --> Config Class Initialized
INFO - 2016-05-20 19:42:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:42:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:42:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:42:44 --> URI Class Initialized
INFO - 2016-05-20 19:42:44 --> Router Class Initialized
INFO - 2016-05-20 19:42:44 --> Output Class Initialized
INFO - 2016-05-20 19:42:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:42:44 --> Input Class Initialized
INFO - 2016-05-20 19:42:44 --> Language Class Initialized
INFO - 2016-05-20 19:42:44 --> Loader Class Initialized
INFO - 2016-05-20 19:42:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:42:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:42:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:42:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:42:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:42:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:42:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:42:44 --> Controller Class Initialized
INFO - 2016-05-20 19:42:44 --> Model Class Initialized
INFO - 2016-05-20 19:42:44 --> Database Driver Class Initialized
INFO - 2016-05-20 19:42:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:42:44 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:42:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:42:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:42:44 --> Total execution time: 0.0750
INFO - 2016-05-20 19:43:44 --> Config Class Initialized
INFO - 2016-05-20 19:43:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:43:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:43:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:43:44 --> URI Class Initialized
INFO - 2016-05-20 19:43:44 --> Router Class Initialized
INFO - 2016-05-20 19:43:44 --> Output Class Initialized
INFO - 2016-05-20 19:43:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:43:44 --> Input Class Initialized
INFO - 2016-05-20 19:43:44 --> Language Class Initialized
INFO - 2016-05-20 19:43:44 --> Loader Class Initialized
INFO - 2016-05-20 19:43:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:43:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:43:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:43:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:43:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:43:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:43:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:43:44 --> Controller Class Initialized
INFO - 2016-05-20 19:43:44 --> Model Class Initialized
INFO - 2016-05-20 19:43:44 --> Database Driver Class Initialized
INFO - 2016-05-20 19:43:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:43:44 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:43:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:43:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:43:44 --> Total execution time: 0.0699
INFO - 2016-05-20 19:44:44 --> Config Class Initialized
INFO - 2016-05-20 19:44:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:44:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:44:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:44:44 --> URI Class Initialized
INFO - 2016-05-20 19:44:44 --> Router Class Initialized
INFO - 2016-05-20 19:44:44 --> Output Class Initialized
INFO - 2016-05-20 19:44:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:44:44 --> Input Class Initialized
INFO - 2016-05-20 19:44:44 --> Language Class Initialized
INFO - 2016-05-20 19:44:44 --> Loader Class Initialized
INFO - 2016-05-20 19:44:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:44:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:44:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:44:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:44:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:44:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:44:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:44:44 --> Controller Class Initialized
INFO - 2016-05-20 19:44:44 --> Model Class Initialized
INFO - 2016-05-20 19:44:44 --> Database Driver Class Initialized
INFO - 2016-05-20 19:44:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:44:44 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:44:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:44:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:44:44 --> Total execution time: 0.0724
INFO - 2016-05-20 19:45:44 --> Config Class Initialized
INFO - 2016-05-20 19:45:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:45:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:45:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:45:44 --> URI Class Initialized
INFO - 2016-05-20 19:45:44 --> Router Class Initialized
INFO - 2016-05-20 19:45:44 --> Output Class Initialized
INFO - 2016-05-20 19:45:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:45:44 --> Input Class Initialized
INFO - 2016-05-20 19:45:44 --> Language Class Initialized
INFO - 2016-05-20 19:45:44 --> Loader Class Initialized
INFO - 2016-05-20 19:45:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:45:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:45:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:45:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:45:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:45:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:45:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:45:44 --> Controller Class Initialized
INFO - 2016-05-20 19:45:44 --> Model Class Initialized
INFO - 2016-05-20 19:45:44 --> Database Driver Class Initialized
INFO - 2016-05-20 19:45:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:45:44 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:45:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:45:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:45:44 --> Total execution time: 0.0754
INFO - 2016-05-20 19:45:50 --> Config Class Initialized
INFO - 2016-05-20 19:45:50 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:45:50 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:45:50 --> Utf8 Class Initialized
INFO - 2016-05-20 19:45:50 --> URI Class Initialized
INFO - 2016-05-20 19:45:50 --> Router Class Initialized
INFO - 2016-05-20 19:45:50 --> Output Class Initialized
INFO - 2016-05-20 19:45:50 --> Security Class Initialized
DEBUG - 2016-05-20 19:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:45:50 --> Input Class Initialized
INFO - 2016-05-20 19:45:50 --> Language Class Initialized
INFO - 2016-05-20 19:45:50 --> Loader Class Initialized
INFO - 2016-05-20 19:45:50 --> Helper loaded: url_helper
INFO - 2016-05-20 19:45:50 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:45:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:45:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:45:50 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:45:50 --> Helper loaded: form_helper
INFO - 2016-05-20 19:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:45:50 --> Form Validation Class Initialized
INFO - 2016-05-20 19:45:50 --> Controller Class Initialized
DEBUG - 2016-05-20 19:45:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:45:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:45:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:45:50 --> Final output sent to browser
DEBUG - 2016-05-20 19:45:50 --> Total execution time: 0.0655
INFO - 2016-05-20 19:45:51 --> Config Class Initialized
INFO - 2016-05-20 19:45:51 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:45:51 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:45:51 --> Utf8 Class Initialized
INFO - 2016-05-20 19:45:51 --> URI Class Initialized
INFO - 2016-05-20 19:45:51 --> Router Class Initialized
INFO - 2016-05-20 19:45:51 --> Output Class Initialized
INFO - 2016-05-20 19:45:51 --> Security Class Initialized
DEBUG - 2016-05-20 19:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:45:51 --> Input Class Initialized
INFO - 2016-05-20 19:45:51 --> Language Class Initialized
INFO - 2016-05-20 19:45:51 --> Loader Class Initialized
INFO - 2016-05-20 19:45:51 --> Helper loaded: url_helper
INFO - 2016-05-20 19:45:51 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:45:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:45:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:45:51 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:45:51 --> Helper loaded: form_helper
INFO - 2016-05-20 19:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:45:52 --> Form Validation Class Initialized
INFO - 2016-05-20 19:45:52 --> Controller Class Initialized
INFO - 2016-05-20 19:45:52 --> Model Class Initialized
INFO - 2016-05-20 19:45:52 --> Database Driver Class Initialized
INFO - 2016-05-20 19:45:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:45:52 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:45:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:45:52 --> Final output sent to browser
DEBUG - 2016-05-20 19:45:52 --> Total execution time: 0.3478
INFO - 2016-05-20 19:45:56 --> Config Class Initialized
INFO - 2016-05-20 19:45:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:45:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:45:56 --> Utf8 Class Initialized
INFO - 2016-05-20 19:45:56 --> URI Class Initialized
INFO - 2016-05-20 19:45:56 --> Router Class Initialized
INFO - 2016-05-20 19:45:56 --> Output Class Initialized
INFO - 2016-05-20 19:45:56 --> Security Class Initialized
DEBUG - 2016-05-20 19:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:45:56 --> Input Class Initialized
INFO - 2016-05-20 19:45:56 --> Language Class Initialized
INFO - 2016-05-20 19:45:56 --> Loader Class Initialized
INFO - 2016-05-20 19:45:56 --> Helper loaded: url_helper
INFO - 2016-05-20 19:45:56 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:45:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:45:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:45:56 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:45:56 --> Helper loaded: form_helper
INFO - 2016-05-20 19:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:45:56 --> Form Validation Class Initialized
INFO - 2016-05-20 19:45:56 --> Controller Class Initialized
DEBUG - 2016-05-20 19:45:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:45:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:45:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:45:56 --> Final output sent to browser
DEBUG - 2016-05-20 19:45:56 --> Total execution time: 0.0611
INFO - 2016-05-20 19:45:56 --> Config Class Initialized
INFO - 2016-05-20 19:45:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:45:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:45:56 --> Utf8 Class Initialized
INFO - 2016-05-20 19:45:56 --> URI Class Initialized
INFO - 2016-05-20 19:45:56 --> Router Class Initialized
INFO - 2016-05-20 19:45:56 --> Output Class Initialized
INFO - 2016-05-20 19:45:56 --> Security Class Initialized
DEBUG - 2016-05-20 19:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:45:56 --> Input Class Initialized
INFO - 2016-05-20 19:45:56 --> Language Class Initialized
INFO - 2016-05-20 19:45:56 --> Loader Class Initialized
INFO - 2016-05-20 19:45:56 --> Helper loaded: url_helper
INFO - 2016-05-20 19:45:56 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:45:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:45:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:45:56 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:45:56 --> Helper loaded: form_helper
INFO - 2016-05-20 19:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:45:56 --> Form Validation Class Initialized
INFO - 2016-05-20 19:45:56 --> Controller Class Initialized
INFO - 2016-05-20 19:45:56 --> Model Class Initialized
INFO - 2016-05-20 19:45:56 --> Database Driver Class Initialized
INFO - 2016-05-20 19:45:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:45:56 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:45:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:45:56 --> Final output sent to browser
DEBUG - 2016-05-20 19:45:56 --> Total execution time: 0.0849
INFO - 2016-05-20 19:46:04 --> Config Class Initialized
INFO - 2016-05-20 19:46:04 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:46:04 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:46:04 --> Utf8 Class Initialized
INFO - 2016-05-20 19:46:04 --> URI Class Initialized
INFO - 2016-05-20 19:46:04 --> Router Class Initialized
INFO - 2016-05-20 19:46:04 --> Output Class Initialized
INFO - 2016-05-20 19:46:04 --> Security Class Initialized
DEBUG - 2016-05-20 19:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:46:04 --> Input Class Initialized
INFO - 2016-05-20 19:46:04 --> Language Class Initialized
INFO - 2016-05-20 19:46:04 --> Loader Class Initialized
INFO - 2016-05-20 19:46:04 --> Helper loaded: url_helper
INFO - 2016-05-20 19:46:04 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:46:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:46:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:46:04 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:46:04 --> Helper loaded: form_helper
INFO - 2016-05-20 19:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:46:04 --> Form Validation Class Initialized
INFO - 2016-05-20 19:46:04 --> Controller Class Initialized
DEBUG - 2016-05-20 19:46:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:46:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:46:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:46:04 --> Final output sent to browser
DEBUG - 2016-05-20 19:46:04 --> Total execution time: 0.0550
INFO - 2016-05-20 19:46:04 --> Config Class Initialized
INFO - 2016-05-20 19:46:04 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:46:04 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:46:04 --> Utf8 Class Initialized
INFO - 2016-05-20 19:46:04 --> URI Class Initialized
INFO - 2016-05-20 19:46:04 --> Router Class Initialized
INFO - 2016-05-20 19:46:04 --> Output Class Initialized
INFO - 2016-05-20 19:46:04 --> Security Class Initialized
DEBUG - 2016-05-20 19:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:46:04 --> Input Class Initialized
INFO - 2016-05-20 19:46:04 --> Language Class Initialized
INFO - 2016-05-20 19:46:04 --> Loader Class Initialized
INFO - 2016-05-20 19:46:04 --> Helper loaded: url_helper
INFO - 2016-05-20 19:46:04 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:46:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:46:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:46:04 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:46:04 --> Helper loaded: form_helper
INFO - 2016-05-20 19:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:46:04 --> Form Validation Class Initialized
INFO - 2016-05-20 19:46:04 --> Controller Class Initialized
INFO - 2016-05-20 19:46:04 --> Model Class Initialized
INFO - 2016-05-20 19:46:04 --> Database Driver Class Initialized
INFO - 2016-05-20 19:46:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:46:04 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:46:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:46:04 --> Final output sent to browser
DEBUG - 2016-05-20 19:46:04 --> Total execution time: 0.1023
INFO - 2016-05-20 19:47:04 --> Config Class Initialized
INFO - 2016-05-20 19:47:04 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:47:04 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:47:04 --> Utf8 Class Initialized
INFO - 2016-05-20 19:47:04 --> URI Class Initialized
INFO - 2016-05-20 19:47:04 --> Router Class Initialized
INFO - 2016-05-20 19:47:04 --> Output Class Initialized
INFO - 2016-05-20 19:47:04 --> Security Class Initialized
DEBUG - 2016-05-20 19:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:47:04 --> Input Class Initialized
INFO - 2016-05-20 19:47:04 --> Language Class Initialized
INFO - 2016-05-20 19:47:04 --> Loader Class Initialized
INFO - 2016-05-20 19:47:04 --> Helper loaded: url_helper
INFO - 2016-05-20 19:47:04 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:47:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:47:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:47:04 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:47:04 --> Helper loaded: form_helper
INFO - 2016-05-20 19:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:47:04 --> Form Validation Class Initialized
INFO - 2016-05-20 19:47:04 --> Controller Class Initialized
INFO - 2016-05-20 19:47:04 --> Model Class Initialized
INFO - 2016-05-20 19:47:04 --> Database Driver Class Initialized
INFO - 2016-05-20 19:47:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:47:04 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:47:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:47:04 --> Final output sent to browser
DEBUG - 2016-05-20 19:47:04 --> Total execution time: 0.0678
INFO - 2016-05-20 19:48:04 --> Config Class Initialized
INFO - 2016-05-20 19:48:04 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:48:04 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:48:04 --> Utf8 Class Initialized
INFO - 2016-05-20 19:48:04 --> URI Class Initialized
INFO - 2016-05-20 19:48:04 --> Router Class Initialized
INFO - 2016-05-20 19:48:04 --> Output Class Initialized
INFO - 2016-05-20 19:48:04 --> Security Class Initialized
DEBUG - 2016-05-20 19:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:48:04 --> Input Class Initialized
INFO - 2016-05-20 19:48:04 --> Language Class Initialized
INFO - 2016-05-20 19:48:04 --> Loader Class Initialized
INFO - 2016-05-20 19:48:04 --> Helper loaded: url_helper
INFO - 2016-05-20 19:48:04 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:48:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:48:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:48:04 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:48:04 --> Helper loaded: form_helper
INFO - 2016-05-20 19:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:48:04 --> Form Validation Class Initialized
INFO - 2016-05-20 19:48:04 --> Controller Class Initialized
INFO - 2016-05-20 19:48:04 --> Model Class Initialized
INFO - 2016-05-20 19:48:04 --> Database Driver Class Initialized
INFO - 2016-05-20 19:48:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:48:04 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:48:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:48:04 --> Final output sent to browser
DEBUG - 2016-05-20 19:48:04 --> Total execution time: 0.0741
INFO - 2016-05-20 19:49:05 --> Config Class Initialized
INFO - 2016-05-20 19:49:05 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:49:05 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:49:05 --> Utf8 Class Initialized
INFO - 2016-05-20 19:49:05 --> URI Class Initialized
INFO - 2016-05-20 19:49:05 --> Router Class Initialized
INFO - 2016-05-20 19:49:05 --> Output Class Initialized
INFO - 2016-05-20 19:49:05 --> Security Class Initialized
DEBUG - 2016-05-20 19:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:49:05 --> Input Class Initialized
INFO - 2016-05-20 19:49:05 --> Language Class Initialized
INFO - 2016-05-20 19:49:05 --> Loader Class Initialized
INFO - 2016-05-20 19:49:05 --> Helper loaded: url_helper
INFO - 2016-05-20 19:49:05 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:49:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:49:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:49:05 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:49:05 --> Helper loaded: form_helper
INFO - 2016-05-20 19:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:49:05 --> Form Validation Class Initialized
INFO - 2016-05-20 19:49:05 --> Controller Class Initialized
INFO - 2016-05-20 19:49:05 --> Model Class Initialized
INFO - 2016-05-20 19:49:05 --> Database Driver Class Initialized
INFO - 2016-05-20 19:49:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:49:05 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:49:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:49:05 --> Final output sent to browser
DEBUG - 2016-05-20 19:49:05 --> Total execution time: 0.0761
INFO - 2016-05-20 19:50:05 --> Config Class Initialized
INFO - 2016-05-20 19:50:05 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:50:05 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:50:05 --> Utf8 Class Initialized
INFO - 2016-05-20 19:50:05 --> URI Class Initialized
INFO - 2016-05-20 19:50:05 --> Router Class Initialized
INFO - 2016-05-20 19:50:05 --> Output Class Initialized
INFO - 2016-05-20 19:50:05 --> Security Class Initialized
DEBUG - 2016-05-20 19:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:50:05 --> Input Class Initialized
INFO - 2016-05-20 19:50:05 --> Language Class Initialized
INFO - 2016-05-20 19:50:05 --> Loader Class Initialized
INFO - 2016-05-20 19:50:05 --> Helper loaded: url_helper
INFO - 2016-05-20 19:50:05 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:50:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:50:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:50:05 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:50:05 --> Helper loaded: form_helper
INFO - 2016-05-20 19:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:50:05 --> Form Validation Class Initialized
INFO - 2016-05-20 19:50:05 --> Controller Class Initialized
INFO - 2016-05-20 19:50:05 --> Model Class Initialized
INFO - 2016-05-20 19:50:05 --> Database Driver Class Initialized
INFO - 2016-05-20 19:50:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:50:05 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:50:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:50:05 --> Final output sent to browser
DEBUG - 2016-05-20 19:50:05 --> Total execution time: 0.0889
INFO - 2016-05-20 19:51:05 --> Config Class Initialized
INFO - 2016-05-20 19:51:05 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:51:05 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:51:05 --> Utf8 Class Initialized
INFO - 2016-05-20 19:51:05 --> URI Class Initialized
INFO - 2016-05-20 19:51:05 --> Router Class Initialized
INFO - 2016-05-20 19:51:05 --> Output Class Initialized
INFO - 2016-05-20 19:51:05 --> Security Class Initialized
DEBUG - 2016-05-20 19:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:51:05 --> Input Class Initialized
INFO - 2016-05-20 19:51:05 --> Language Class Initialized
INFO - 2016-05-20 19:51:05 --> Loader Class Initialized
INFO - 2016-05-20 19:51:05 --> Helper loaded: url_helper
INFO - 2016-05-20 19:51:05 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:51:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:51:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:51:05 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:51:05 --> Helper loaded: form_helper
INFO - 2016-05-20 19:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:51:05 --> Form Validation Class Initialized
INFO - 2016-05-20 19:51:05 --> Controller Class Initialized
INFO - 2016-05-20 19:51:05 --> Model Class Initialized
INFO - 2016-05-20 19:51:05 --> Database Driver Class Initialized
INFO - 2016-05-20 19:51:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:51:05 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:51:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:51:05 --> Final output sent to browser
DEBUG - 2016-05-20 19:51:05 --> Total execution time: 0.0923
INFO - 2016-05-20 19:52:05 --> Config Class Initialized
INFO - 2016-05-20 19:52:05 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:52:05 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:52:05 --> Utf8 Class Initialized
INFO - 2016-05-20 19:52:05 --> URI Class Initialized
INFO - 2016-05-20 19:52:05 --> Router Class Initialized
INFO - 2016-05-20 19:52:05 --> Output Class Initialized
INFO - 2016-05-20 19:52:05 --> Security Class Initialized
DEBUG - 2016-05-20 19:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:52:05 --> Input Class Initialized
INFO - 2016-05-20 19:52:05 --> Language Class Initialized
INFO - 2016-05-20 19:52:05 --> Loader Class Initialized
INFO - 2016-05-20 19:52:05 --> Helper loaded: url_helper
INFO - 2016-05-20 19:52:05 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:52:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:52:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:52:05 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:52:05 --> Helper loaded: form_helper
INFO - 2016-05-20 19:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:52:05 --> Form Validation Class Initialized
INFO - 2016-05-20 19:52:05 --> Controller Class Initialized
INFO - 2016-05-20 19:52:05 --> Model Class Initialized
INFO - 2016-05-20 19:52:05 --> Database Driver Class Initialized
INFO - 2016-05-20 19:52:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:52:05 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:52:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:52:05 --> Final output sent to browser
DEBUG - 2016-05-20 19:52:05 --> Total execution time: 0.0740
INFO - 2016-05-20 19:52:08 --> Config Class Initialized
INFO - 2016-05-20 19:52:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:52:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:52:08 --> Utf8 Class Initialized
INFO - 2016-05-20 19:52:08 --> URI Class Initialized
INFO - 2016-05-20 19:52:08 --> Router Class Initialized
INFO - 2016-05-20 19:52:08 --> Output Class Initialized
INFO - 2016-05-20 19:52:08 --> Security Class Initialized
DEBUG - 2016-05-20 19:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:52:08 --> Input Class Initialized
INFO - 2016-05-20 19:52:08 --> Language Class Initialized
INFO - 2016-05-20 19:52:08 --> Loader Class Initialized
INFO - 2016-05-20 19:52:08 --> Helper loaded: url_helper
INFO - 2016-05-20 19:52:08 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:52:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:52:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:52:08 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:52:08 --> Helper loaded: form_helper
INFO - 2016-05-20 19:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:52:08 --> Form Validation Class Initialized
INFO - 2016-05-20 19:52:08 --> Controller Class Initialized
DEBUG - 2016-05-20 19:52:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:52:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:52:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:52:08 --> Final output sent to browser
DEBUG - 2016-05-20 19:52:08 --> Total execution time: 0.0754
INFO - 2016-05-20 19:52:08 --> Config Class Initialized
INFO - 2016-05-20 19:52:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:52:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:52:08 --> Utf8 Class Initialized
INFO - 2016-05-20 19:52:08 --> URI Class Initialized
INFO - 2016-05-20 19:52:08 --> Router Class Initialized
INFO - 2016-05-20 19:52:08 --> Output Class Initialized
INFO - 2016-05-20 19:52:08 --> Security Class Initialized
DEBUG - 2016-05-20 19:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:52:08 --> Input Class Initialized
INFO - 2016-05-20 19:52:08 --> Language Class Initialized
INFO - 2016-05-20 19:52:08 --> Loader Class Initialized
INFO - 2016-05-20 19:52:08 --> Helper loaded: url_helper
INFO - 2016-05-20 19:52:08 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:52:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:52:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:52:08 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:52:08 --> Helper loaded: form_helper
INFO - 2016-05-20 19:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:52:08 --> Form Validation Class Initialized
INFO - 2016-05-20 19:52:08 --> Controller Class Initialized
INFO - 2016-05-20 19:52:08 --> Model Class Initialized
INFO - 2016-05-20 19:52:09 --> Database Driver Class Initialized
INFO - 2016-05-20 19:52:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:52:09 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:52:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:52:09 --> Final output sent to browser
DEBUG - 2016-05-20 19:52:09 --> Total execution time: 0.0830
INFO - 2016-05-20 19:52:11 --> Config Class Initialized
INFO - 2016-05-20 19:52:11 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:52:11 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:52:11 --> Utf8 Class Initialized
INFO - 2016-05-20 19:52:11 --> URI Class Initialized
INFO - 2016-05-20 19:52:11 --> Router Class Initialized
INFO - 2016-05-20 19:52:11 --> Output Class Initialized
INFO - 2016-05-20 19:52:11 --> Security Class Initialized
DEBUG - 2016-05-20 19:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:52:11 --> Input Class Initialized
INFO - 2016-05-20 19:52:11 --> Language Class Initialized
INFO - 2016-05-20 19:52:11 --> Loader Class Initialized
INFO - 2016-05-20 19:52:11 --> Helper loaded: url_helper
INFO - 2016-05-20 19:52:11 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:52:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:52:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:52:11 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:52:11 --> Helper loaded: form_helper
INFO - 2016-05-20 19:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:52:11 --> Form Validation Class Initialized
INFO - 2016-05-20 19:52:11 --> Controller Class Initialized
DEBUG - 2016-05-20 19:52:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:52:11 --> Config Class Initialized
INFO - 2016-05-20 19:52:11 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:52:11 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:52:11 --> Utf8 Class Initialized
INFO - 2016-05-20 19:52:11 --> URI Class Initialized
INFO - 2016-05-20 19:52:11 --> Router Class Initialized
INFO - 2016-05-20 19:52:11 --> Output Class Initialized
INFO - 2016-05-20 19:52:11 --> Security Class Initialized
DEBUG - 2016-05-20 19:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:52:11 --> Input Class Initialized
INFO - 2016-05-20 19:52:11 --> Language Class Initialized
INFO - 2016-05-20 19:52:11 --> Loader Class Initialized
INFO - 2016-05-20 19:52:11 --> Helper loaded: url_helper
INFO - 2016-05-20 19:52:11 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:52:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:52:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:52:11 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:52:11 --> Helper loaded: form_helper
INFO - 2016-05-20 19:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:52:11 --> Form Validation Class Initialized
INFO - 2016-05-20 19:52:11 --> Controller Class Initialized
DEBUG - 2016-05-20 19:52:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:52:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:52:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:52:11 --> Final output sent to browser
DEBUG - 2016-05-20 19:52:11 --> Total execution time: 0.0528
INFO - 2016-05-20 19:52:11 --> Config Class Initialized
INFO - 2016-05-20 19:52:11 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:52:11 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:52:11 --> Utf8 Class Initialized
INFO - 2016-05-20 19:52:11 --> URI Class Initialized
INFO - 2016-05-20 19:52:11 --> Router Class Initialized
INFO - 2016-05-20 19:52:11 --> Output Class Initialized
INFO - 2016-05-20 19:52:11 --> Security Class Initialized
DEBUG - 2016-05-20 19:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:52:11 --> Input Class Initialized
INFO - 2016-05-20 19:52:11 --> Language Class Initialized
INFO - 2016-05-20 19:52:11 --> Loader Class Initialized
INFO - 2016-05-20 19:52:11 --> Helper loaded: url_helper
INFO - 2016-05-20 19:52:11 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:52:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:52:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:52:11 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:52:11 --> Helper loaded: form_helper
INFO - 2016-05-20 19:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:52:11 --> Form Validation Class Initialized
INFO - 2016-05-20 19:52:11 --> Controller Class Initialized
INFO - 2016-05-20 19:52:11 --> Model Class Initialized
INFO - 2016-05-20 19:52:11 --> Database Driver Class Initialized
INFO - 2016-05-20 19:52:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:52:11 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:52:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:52:11 --> Final output sent to browser
DEBUG - 2016-05-20 19:52:11 --> Total execution time: 0.0825
INFO - 2016-05-20 19:52:13 --> Config Class Initialized
INFO - 2016-05-20 19:52:13 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:52:13 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:52:13 --> Utf8 Class Initialized
INFO - 2016-05-20 19:52:13 --> URI Class Initialized
INFO - 2016-05-20 19:52:13 --> Router Class Initialized
INFO - 2016-05-20 19:52:13 --> Output Class Initialized
INFO - 2016-05-20 19:52:13 --> Security Class Initialized
DEBUG - 2016-05-20 19:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:52:13 --> Input Class Initialized
INFO - 2016-05-20 19:52:13 --> Language Class Initialized
INFO - 2016-05-20 19:52:13 --> Loader Class Initialized
INFO - 2016-05-20 19:52:13 --> Helper loaded: url_helper
INFO - 2016-05-20 19:52:13 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:52:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:52:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:52:13 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:52:13 --> Helper loaded: form_helper
INFO - 2016-05-20 19:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:52:13 --> Form Validation Class Initialized
INFO - 2016-05-20 19:52:13 --> Controller Class Initialized
DEBUG - 2016-05-20 19:52:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:52:13 --> Config Class Initialized
INFO - 2016-05-20 19:52:13 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:52:13 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:52:13 --> Utf8 Class Initialized
INFO - 2016-05-20 19:52:13 --> URI Class Initialized
INFO - 2016-05-20 19:52:13 --> Router Class Initialized
INFO - 2016-05-20 19:52:13 --> Output Class Initialized
INFO - 2016-05-20 19:52:13 --> Security Class Initialized
DEBUG - 2016-05-20 19:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:52:13 --> Input Class Initialized
INFO - 2016-05-20 19:52:13 --> Language Class Initialized
INFO - 2016-05-20 19:52:13 --> Loader Class Initialized
INFO - 2016-05-20 19:52:13 --> Helper loaded: url_helper
INFO - 2016-05-20 19:52:13 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:52:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:52:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:52:13 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:52:13 --> Helper loaded: form_helper
INFO - 2016-05-20 19:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:52:13 --> Form Validation Class Initialized
INFO - 2016-05-20 19:52:13 --> Controller Class Initialized
DEBUG - 2016-05-20 19:52:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:52:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:52:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:52:13 --> Final output sent to browser
DEBUG - 2016-05-20 19:52:13 --> Total execution time: 0.0638
INFO - 2016-05-20 19:52:13 --> Config Class Initialized
INFO - 2016-05-20 19:52:13 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:52:13 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:52:13 --> Utf8 Class Initialized
INFO - 2016-05-20 19:52:13 --> URI Class Initialized
INFO - 2016-05-20 19:52:13 --> Router Class Initialized
INFO - 2016-05-20 19:52:13 --> Output Class Initialized
INFO - 2016-05-20 19:52:13 --> Security Class Initialized
DEBUG - 2016-05-20 19:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:52:13 --> Input Class Initialized
INFO - 2016-05-20 19:52:13 --> Language Class Initialized
INFO - 2016-05-20 19:52:13 --> Loader Class Initialized
INFO - 2016-05-20 19:52:13 --> Helper loaded: url_helper
INFO - 2016-05-20 19:52:13 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:52:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:52:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:52:13 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:52:13 --> Helper loaded: form_helper
INFO - 2016-05-20 19:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:52:13 --> Form Validation Class Initialized
INFO - 2016-05-20 19:52:13 --> Controller Class Initialized
INFO - 2016-05-20 19:52:13 --> Model Class Initialized
INFO - 2016-05-20 19:52:13 --> Database Driver Class Initialized
INFO - 2016-05-20 19:52:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:52:13 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:52:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:52:13 --> Final output sent to browser
DEBUG - 2016-05-20 19:52:13 --> Total execution time: 0.1069
INFO - 2016-05-20 19:53:02 --> Config Class Initialized
INFO - 2016-05-20 19:53:02 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:53:02 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:53:02 --> Utf8 Class Initialized
INFO - 2016-05-20 19:53:02 --> URI Class Initialized
INFO - 2016-05-20 19:53:02 --> Router Class Initialized
INFO - 2016-05-20 19:53:02 --> Output Class Initialized
INFO - 2016-05-20 19:53:02 --> Security Class Initialized
DEBUG - 2016-05-20 19:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:53:02 --> Input Class Initialized
INFO - 2016-05-20 19:53:02 --> Language Class Initialized
INFO - 2016-05-20 19:53:02 --> Loader Class Initialized
INFO - 2016-05-20 19:53:02 --> Helper loaded: url_helper
INFO - 2016-05-20 19:53:02 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:53:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:53:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:53:02 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:53:02 --> Helper loaded: form_helper
INFO - 2016-05-20 19:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:53:02 --> Form Validation Class Initialized
INFO - 2016-05-20 19:53:02 --> Controller Class Initialized
DEBUG - 2016-05-20 19:53:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:53:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:53:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:53:02 --> Final output sent to browser
DEBUG - 2016-05-20 19:53:02 --> Total execution time: 0.0598
INFO - 2016-05-20 19:53:03 --> Config Class Initialized
INFO - 2016-05-20 19:53:03 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:53:03 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:53:03 --> Utf8 Class Initialized
INFO - 2016-05-20 19:53:03 --> URI Class Initialized
INFO - 2016-05-20 19:53:03 --> Router Class Initialized
INFO - 2016-05-20 19:53:03 --> Output Class Initialized
INFO - 2016-05-20 19:53:03 --> Security Class Initialized
DEBUG - 2016-05-20 19:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:53:03 --> Input Class Initialized
INFO - 2016-05-20 19:53:03 --> Language Class Initialized
INFO - 2016-05-20 19:53:03 --> Loader Class Initialized
INFO - 2016-05-20 19:53:03 --> Helper loaded: url_helper
INFO - 2016-05-20 19:53:03 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:53:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:53:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:53:03 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:53:03 --> Helper loaded: form_helper
INFO - 2016-05-20 19:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:53:03 --> Form Validation Class Initialized
INFO - 2016-05-20 19:53:03 --> Controller Class Initialized
INFO - 2016-05-20 19:53:03 --> Model Class Initialized
INFO - 2016-05-20 19:53:03 --> Database Driver Class Initialized
INFO - 2016-05-20 19:53:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:53:03 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:53:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:53:03 --> Final output sent to browser
DEBUG - 2016-05-20 19:53:03 --> Total execution time: 0.0850
INFO - 2016-05-20 19:53:04 --> Config Class Initialized
INFO - 2016-05-20 19:53:04 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:53:04 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:53:04 --> Utf8 Class Initialized
INFO - 2016-05-20 19:53:04 --> URI Class Initialized
INFO - 2016-05-20 19:53:04 --> Router Class Initialized
INFO - 2016-05-20 19:53:04 --> Output Class Initialized
INFO - 2016-05-20 19:53:04 --> Security Class Initialized
DEBUG - 2016-05-20 19:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:53:04 --> Input Class Initialized
INFO - 2016-05-20 19:53:04 --> Language Class Initialized
INFO - 2016-05-20 19:53:04 --> Loader Class Initialized
INFO - 2016-05-20 19:53:04 --> Helper loaded: url_helper
INFO - 2016-05-20 19:53:04 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:53:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:53:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:53:04 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:53:04 --> Helper loaded: form_helper
INFO - 2016-05-20 19:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:53:04 --> Form Validation Class Initialized
INFO - 2016-05-20 19:53:04 --> Controller Class Initialized
DEBUG - 2016-05-20 19:53:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:53:04 --> Final output sent to browser
DEBUG - 2016-05-20 19:53:04 --> Total execution time: 0.0607
INFO - 2016-05-20 19:53:34 --> Config Class Initialized
INFO - 2016-05-20 19:53:34 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:53:34 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:53:34 --> Utf8 Class Initialized
INFO - 2016-05-20 19:53:34 --> URI Class Initialized
INFO - 2016-05-20 19:53:34 --> Router Class Initialized
INFO - 2016-05-20 19:53:34 --> Output Class Initialized
INFO - 2016-05-20 19:53:34 --> Security Class Initialized
DEBUG - 2016-05-20 19:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:53:34 --> Input Class Initialized
INFO - 2016-05-20 19:53:34 --> Language Class Initialized
INFO - 2016-05-20 19:53:34 --> Loader Class Initialized
INFO - 2016-05-20 19:53:34 --> Helper loaded: url_helper
INFO - 2016-05-20 19:53:34 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:53:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:53:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:53:34 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:53:34 --> Helper loaded: form_helper
INFO - 2016-05-20 19:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:53:34 --> Form Validation Class Initialized
INFO - 2016-05-20 19:53:34 --> Controller Class Initialized
DEBUG - 2016-05-20 19:53:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:53:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:53:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:53:34 --> Final output sent to browser
DEBUG - 2016-05-20 19:53:34 --> Total execution time: 0.0558
INFO - 2016-05-20 19:53:34 --> Config Class Initialized
INFO - 2016-05-20 19:53:34 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:53:34 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:53:34 --> Utf8 Class Initialized
INFO - 2016-05-20 19:53:34 --> URI Class Initialized
INFO - 2016-05-20 19:53:34 --> Router Class Initialized
INFO - 2016-05-20 19:53:34 --> Output Class Initialized
INFO - 2016-05-20 19:53:34 --> Security Class Initialized
DEBUG - 2016-05-20 19:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:53:34 --> Input Class Initialized
INFO - 2016-05-20 19:53:34 --> Language Class Initialized
INFO - 2016-05-20 19:53:34 --> Loader Class Initialized
INFO - 2016-05-20 19:53:34 --> Helper loaded: url_helper
INFO - 2016-05-20 19:53:34 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:53:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:53:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:53:34 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:53:34 --> Helper loaded: form_helper
INFO - 2016-05-20 19:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:53:34 --> Form Validation Class Initialized
INFO - 2016-05-20 19:53:34 --> Controller Class Initialized
INFO - 2016-05-20 19:53:34 --> Model Class Initialized
INFO - 2016-05-20 19:53:34 --> Database Driver Class Initialized
INFO - 2016-05-20 19:53:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:53:34 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:53:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:53:34 --> Final output sent to browser
DEBUG - 2016-05-20 19:53:34 --> Total execution time: 0.1014
INFO - 2016-05-20 19:53:40 --> Config Class Initialized
INFO - 2016-05-20 19:53:40 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:53:40 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:53:40 --> Utf8 Class Initialized
INFO - 2016-05-20 19:53:40 --> URI Class Initialized
INFO - 2016-05-20 19:53:40 --> Router Class Initialized
INFO - 2016-05-20 19:53:40 --> Output Class Initialized
INFO - 2016-05-20 19:53:40 --> Security Class Initialized
DEBUG - 2016-05-20 19:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:53:40 --> Input Class Initialized
INFO - 2016-05-20 19:53:40 --> Language Class Initialized
INFO - 2016-05-20 19:53:40 --> Loader Class Initialized
INFO - 2016-05-20 19:53:40 --> Helper loaded: url_helper
INFO - 2016-05-20 19:53:40 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:53:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:53:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:53:40 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:53:40 --> Helper loaded: form_helper
INFO - 2016-05-20 19:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:53:40 --> Form Validation Class Initialized
INFO - 2016-05-20 19:53:40 --> Controller Class Initialized
DEBUG - 2016-05-20 19:53:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:53:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:53:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:53:40 --> Final output sent to browser
DEBUG - 2016-05-20 19:53:40 --> Total execution time: 0.0597
INFO - 2016-05-20 19:53:41 --> Config Class Initialized
INFO - 2016-05-20 19:53:41 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:53:41 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:53:41 --> Utf8 Class Initialized
INFO - 2016-05-20 19:53:41 --> URI Class Initialized
INFO - 2016-05-20 19:53:41 --> Router Class Initialized
INFO - 2016-05-20 19:53:41 --> Output Class Initialized
INFO - 2016-05-20 19:53:41 --> Security Class Initialized
DEBUG - 2016-05-20 19:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:53:41 --> Input Class Initialized
INFO - 2016-05-20 19:53:41 --> Language Class Initialized
INFO - 2016-05-20 19:53:41 --> Loader Class Initialized
INFO - 2016-05-20 19:53:41 --> Helper loaded: url_helper
INFO - 2016-05-20 19:53:41 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:53:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:53:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:53:41 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:53:41 --> Helper loaded: form_helper
INFO - 2016-05-20 19:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:53:41 --> Form Validation Class Initialized
INFO - 2016-05-20 19:53:41 --> Controller Class Initialized
INFO - 2016-05-20 19:53:41 --> Model Class Initialized
INFO - 2016-05-20 19:53:41 --> Database Driver Class Initialized
INFO - 2016-05-20 19:53:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:53:41 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:53:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:53:41 --> Final output sent to browser
DEBUG - 2016-05-20 19:53:41 --> Total execution time: 0.0957
INFO - 2016-05-20 19:53:43 --> Config Class Initialized
INFO - 2016-05-20 19:53:43 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:53:43 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:53:43 --> Utf8 Class Initialized
INFO - 2016-05-20 19:53:43 --> URI Class Initialized
INFO - 2016-05-20 19:53:43 --> Router Class Initialized
INFO - 2016-05-20 19:53:43 --> Output Class Initialized
INFO - 2016-05-20 19:53:43 --> Security Class Initialized
DEBUG - 2016-05-20 19:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:53:43 --> Input Class Initialized
INFO - 2016-05-20 19:53:43 --> Language Class Initialized
INFO - 2016-05-20 19:53:43 --> Loader Class Initialized
INFO - 2016-05-20 19:53:43 --> Helper loaded: url_helper
INFO - 2016-05-20 19:53:43 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:53:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:53:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:53:43 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:53:43 --> Helper loaded: form_helper
INFO - 2016-05-20 19:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:53:43 --> Form Validation Class Initialized
INFO - 2016-05-20 19:53:43 --> Controller Class Initialized
DEBUG - 2016-05-20 19:53:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:53:43 --> Config Class Initialized
INFO - 2016-05-20 19:53:43 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:53:43 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:53:43 --> Utf8 Class Initialized
INFO - 2016-05-20 19:53:43 --> URI Class Initialized
INFO - 2016-05-20 19:53:43 --> Router Class Initialized
INFO - 2016-05-20 19:53:43 --> Output Class Initialized
INFO - 2016-05-20 19:53:43 --> Security Class Initialized
DEBUG - 2016-05-20 19:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:53:43 --> Input Class Initialized
INFO - 2016-05-20 19:53:43 --> Language Class Initialized
INFO - 2016-05-20 19:53:43 --> Loader Class Initialized
INFO - 2016-05-20 19:53:43 --> Helper loaded: url_helper
INFO - 2016-05-20 19:53:43 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:53:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:53:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:53:43 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:53:43 --> Helper loaded: form_helper
INFO - 2016-05-20 19:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:53:43 --> Form Validation Class Initialized
INFO - 2016-05-20 19:53:43 --> Controller Class Initialized
DEBUG - 2016-05-20 19:53:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:53:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:53:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:53:43 --> Final output sent to browser
DEBUG - 2016-05-20 19:53:43 --> Total execution time: 0.0626
INFO - 2016-05-20 19:53:43 --> Config Class Initialized
INFO - 2016-05-20 19:53:43 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:53:43 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:53:43 --> Utf8 Class Initialized
INFO - 2016-05-20 19:53:43 --> URI Class Initialized
INFO - 2016-05-20 19:53:43 --> Router Class Initialized
INFO - 2016-05-20 19:53:43 --> Output Class Initialized
INFO - 2016-05-20 19:53:43 --> Security Class Initialized
DEBUG - 2016-05-20 19:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:53:43 --> Input Class Initialized
INFO - 2016-05-20 19:53:43 --> Language Class Initialized
INFO - 2016-05-20 19:53:43 --> Loader Class Initialized
INFO - 2016-05-20 19:53:43 --> Helper loaded: url_helper
INFO - 2016-05-20 19:53:43 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:53:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:53:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:53:43 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:53:43 --> Helper loaded: form_helper
INFO - 2016-05-20 19:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:53:43 --> Form Validation Class Initialized
INFO - 2016-05-20 19:53:43 --> Controller Class Initialized
INFO - 2016-05-20 19:53:43 --> Model Class Initialized
INFO - 2016-05-20 19:53:43 --> Database Driver Class Initialized
INFO - 2016-05-20 19:53:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:53:43 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:53:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:53:43 --> Final output sent to browser
DEBUG - 2016-05-20 19:53:43 --> Total execution time: 0.1232
INFO - 2016-05-20 19:54:36 --> Config Class Initialized
INFO - 2016-05-20 19:54:36 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:54:36 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:54:36 --> Utf8 Class Initialized
INFO - 2016-05-20 19:54:36 --> URI Class Initialized
INFO - 2016-05-20 19:54:36 --> Router Class Initialized
INFO - 2016-05-20 19:54:36 --> Output Class Initialized
INFO - 2016-05-20 19:54:36 --> Security Class Initialized
DEBUG - 2016-05-20 19:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:54:36 --> Input Class Initialized
INFO - 2016-05-20 19:54:36 --> Language Class Initialized
INFO - 2016-05-20 19:54:36 --> Loader Class Initialized
INFO - 2016-05-20 19:54:36 --> Helper loaded: url_helper
INFO - 2016-05-20 19:54:36 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:54:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:54:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:54:36 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:54:36 --> Helper loaded: form_helper
INFO - 2016-05-20 19:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:54:36 --> Form Validation Class Initialized
INFO - 2016-05-20 19:54:36 --> Controller Class Initialized
DEBUG - 2016-05-20 19:54:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:54:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:54:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:54:36 --> Final output sent to browser
DEBUG - 2016-05-20 19:54:36 --> Total execution time: 0.0580
INFO - 2016-05-20 19:54:36 --> Config Class Initialized
INFO - 2016-05-20 19:54:36 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:54:36 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:54:36 --> Utf8 Class Initialized
INFO - 2016-05-20 19:54:36 --> URI Class Initialized
INFO - 2016-05-20 19:54:36 --> Router Class Initialized
INFO - 2016-05-20 19:54:36 --> Output Class Initialized
INFO - 2016-05-20 19:54:36 --> Security Class Initialized
DEBUG - 2016-05-20 19:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:54:36 --> Input Class Initialized
INFO - 2016-05-20 19:54:36 --> Language Class Initialized
INFO - 2016-05-20 19:54:36 --> Loader Class Initialized
INFO - 2016-05-20 19:54:36 --> Helper loaded: url_helper
INFO - 2016-05-20 19:54:36 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:54:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:54:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:54:36 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:54:36 --> Helper loaded: form_helper
INFO - 2016-05-20 19:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:54:36 --> Form Validation Class Initialized
INFO - 2016-05-20 19:54:36 --> Controller Class Initialized
INFO - 2016-05-20 19:54:36 --> Model Class Initialized
INFO - 2016-05-20 19:54:36 --> Database Driver Class Initialized
INFO - 2016-05-20 19:54:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:54:36 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:54:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:54:36 --> Final output sent to browser
DEBUG - 2016-05-20 19:54:36 --> Total execution time: 0.0773
INFO - 2016-05-20 19:54:44 --> Config Class Initialized
INFO - 2016-05-20 19:54:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:54:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:54:44 --> Utf8 Class Initialized
INFO - 2016-05-20 19:54:44 --> URI Class Initialized
INFO - 2016-05-20 19:54:44 --> Router Class Initialized
INFO - 2016-05-20 19:54:44 --> Output Class Initialized
INFO - 2016-05-20 19:54:44 --> Security Class Initialized
DEBUG - 2016-05-20 19:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:54:44 --> Input Class Initialized
INFO - 2016-05-20 19:54:44 --> Language Class Initialized
INFO - 2016-05-20 19:54:44 --> Loader Class Initialized
INFO - 2016-05-20 19:54:44 --> Helper loaded: url_helper
INFO - 2016-05-20 19:54:44 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:54:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:54:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:54:44 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:54:44 --> Helper loaded: form_helper
INFO - 2016-05-20 19:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:54:44 --> Form Validation Class Initialized
INFO - 2016-05-20 19:54:44 --> Controller Class Initialized
DEBUG - 2016-05-20 19:54:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:54:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:54:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:54:44 --> Final output sent to browser
DEBUG - 2016-05-20 19:54:44 --> Total execution time: 0.0627
INFO - 2016-05-20 19:54:45 --> Config Class Initialized
INFO - 2016-05-20 19:54:45 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:54:45 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:54:45 --> Utf8 Class Initialized
INFO - 2016-05-20 19:54:45 --> URI Class Initialized
INFO - 2016-05-20 19:54:45 --> Router Class Initialized
INFO - 2016-05-20 19:54:45 --> Output Class Initialized
INFO - 2016-05-20 19:54:45 --> Security Class Initialized
DEBUG - 2016-05-20 19:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:54:45 --> Input Class Initialized
INFO - 2016-05-20 19:54:45 --> Language Class Initialized
INFO - 2016-05-20 19:54:45 --> Loader Class Initialized
INFO - 2016-05-20 19:54:45 --> Helper loaded: url_helper
INFO - 2016-05-20 19:54:45 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:54:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:54:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:54:45 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:54:45 --> Helper loaded: form_helper
INFO - 2016-05-20 19:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:54:45 --> Form Validation Class Initialized
INFO - 2016-05-20 19:54:45 --> Controller Class Initialized
INFO - 2016-05-20 19:54:45 --> Model Class Initialized
INFO - 2016-05-20 19:54:45 --> Database Driver Class Initialized
INFO - 2016-05-20 19:54:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:54:45 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:54:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:54:45 --> Final output sent to browser
DEBUG - 2016-05-20 19:54:45 --> Total execution time: 0.0827
INFO - 2016-05-20 19:54:56 --> Config Class Initialized
INFO - 2016-05-20 19:54:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:54:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:54:56 --> Utf8 Class Initialized
INFO - 2016-05-20 19:54:56 --> URI Class Initialized
INFO - 2016-05-20 19:54:56 --> Router Class Initialized
INFO - 2016-05-20 19:54:56 --> Output Class Initialized
INFO - 2016-05-20 19:54:56 --> Security Class Initialized
DEBUG - 2016-05-20 19:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:54:56 --> Input Class Initialized
INFO - 2016-05-20 19:54:56 --> Language Class Initialized
INFO - 2016-05-20 19:54:56 --> Loader Class Initialized
INFO - 2016-05-20 19:54:56 --> Helper loaded: url_helper
INFO - 2016-05-20 19:54:56 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:54:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:54:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:54:56 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:54:56 --> Helper loaded: form_helper
INFO - 2016-05-20 19:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:54:56 --> Form Validation Class Initialized
INFO - 2016-05-20 19:54:56 --> Controller Class Initialized
DEBUG - 2016-05-20 19:54:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:54:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:54:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:54:56 --> Final output sent to browser
DEBUG - 2016-05-20 19:54:56 --> Total execution time: 0.0670
INFO - 2016-05-20 19:54:56 --> Config Class Initialized
INFO - 2016-05-20 19:54:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:54:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:54:56 --> Utf8 Class Initialized
INFO - 2016-05-20 19:54:56 --> URI Class Initialized
INFO - 2016-05-20 19:54:56 --> Router Class Initialized
INFO - 2016-05-20 19:54:56 --> Output Class Initialized
INFO - 2016-05-20 19:54:56 --> Security Class Initialized
DEBUG - 2016-05-20 19:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:54:56 --> Input Class Initialized
INFO - 2016-05-20 19:54:56 --> Language Class Initialized
INFO - 2016-05-20 19:54:56 --> Loader Class Initialized
INFO - 2016-05-20 19:54:56 --> Helper loaded: url_helper
INFO - 2016-05-20 19:54:56 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:54:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:54:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:54:56 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:54:56 --> Helper loaded: form_helper
INFO - 2016-05-20 19:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:54:56 --> Form Validation Class Initialized
INFO - 2016-05-20 19:54:56 --> Controller Class Initialized
INFO - 2016-05-20 19:54:56 --> Model Class Initialized
INFO - 2016-05-20 19:54:56 --> Database Driver Class Initialized
INFO - 2016-05-20 19:54:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:54:56 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:54:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:54:56 --> Final output sent to browser
DEBUG - 2016-05-20 19:54:56 --> Total execution time: 0.0839
INFO - 2016-05-20 19:55:25 --> Config Class Initialized
INFO - 2016-05-20 19:55:25 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:55:25 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:55:25 --> Utf8 Class Initialized
INFO - 2016-05-20 19:55:25 --> URI Class Initialized
INFO - 2016-05-20 19:55:25 --> Router Class Initialized
INFO - 2016-05-20 19:55:25 --> Output Class Initialized
INFO - 2016-05-20 19:55:25 --> Security Class Initialized
DEBUG - 2016-05-20 19:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:55:25 --> Input Class Initialized
INFO - 2016-05-20 19:55:25 --> Language Class Initialized
INFO - 2016-05-20 19:55:25 --> Loader Class Initialized
INFO - 2016-05-20 19:55:25 --> Helper loaded: url_helper
INFO - 2016-05-20 19:55:25 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:55:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:55:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:55:25 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:55:25 --> Helper loaded: form_helper
INFO - 2016-05-20 19:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:55:25 --> Form Validation Class Initialized
INFO - 2016-05-20 19:55:25 --> Controller Class Initialized
DEBUG - 2016-05-20 19:55:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:55:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:56:22 --> Config Class Initialized
INFO - 2016-05-20 19:56:22 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:22 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:22 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:22 --> URI Class Initialized
INFO - 2016-05-20 19:56:22 --> Router Class Initialized
INFO - 2016-05-20 19:56:22 --> Output Class Initialized
INFO - 2016-05-20 19:56:22 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:22 --> Input Class Initialized
INFO - 2016-05-20 19:56:22 --> Language Class Initialized
INFO - 2016-05-20 19:56:22 --> Loader Class Initialized
INFO - 2016-05-20 19:56:22 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:22 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:22 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:22 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:22 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:22 --> Controller Class Initialized
DEBUG - 2016-05-20 19:56:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:56:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:56:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:56:22 --> Final output sent to browser
DEBUG - 2016-05-20 19:56:22 --> Total execution time: 0.0613
INFO - 2016-05-20 19:56:22 --> Config Class Initialized
INFO - 2016-05-20 19:56:22 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:22 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:22 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:22 --> URI Class Initialized
INFO - 2016-05-20 19:56:22 --> Router Class Initialized
INFO - 2016-05-20 19:56:22 --> Output Class Initialized
INFO - 2016-05-20 19:56:22 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:22 --> Input Class Initialized
INFO - 2016-05-20 19:56:22 --> Language Class Initialized
INFO - 2016-05-20 19:56:22 --> Loader Class Initialized
INFO - 2016-05-20 19:56:22 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:23 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:23 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:23 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:23 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:23 --> Controller Class Initialized
INFO - 2016-05-20 19:56:23 --> Model Class Initialized
INFO - 2016-05-20 19:56:23 --> Database Driver Class Initialized
INFO - 2016-05-20 19:56:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:56:23 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:56:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:56:23 --> Final output sent to browser
DEBUG - 2016-05-20 19:56:23 --> Total execution time: 0.1041
INFO - 2016-05-20 19:56:25 --> Config Class Initialized
INFO - 2016-05-20 19:56:25 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:25 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:25 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:25 --> URI Class Initialized
INFO - 2016-05-20 19:56:25 --> Router Class Initialized
INFO - 2016-05-20 19:56:25 --> Output Class Initialized
INFO - 2016-05-20 19:56:25 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:25 --> Input Class Initialized
INFO - 2016-05-20 19:56:25 --> Language Class Initialized
INFO - 2016-05-20 19:56:25 --> Loader Class Initialized
INFO - 2016-05-20 19:56:25 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:25 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:25 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:25 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:25 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:25 --> Controller Class Initialized
DEBUG - 2016-05-20 19:56:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:56:25 --> Config Class Initialized
INFO - 2016-05-20 19:56:25 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:25 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:25 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:25 --> URI Class Initialized
INFO - 2016-05-20 19:56:25 --> Router Class Initialized
INFO - 2016-05-20 19:56:25 --> Output Class Initialized
INFO - 2016-05-20 19:56:25 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:25 --> Input Class Initialized
INFO - 2016-05-20 19:56:25 --> Language Class Initialized
INFO - 2016-05-20 19:56:25 --> Loader Class Initialized
INFO - 2016-05-20 19:56:25 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:25 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:25 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:25 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:25 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:25 --> Controller Class Initialized
DEBUG - 2016-05-20 19:56:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:56:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:56:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:56:25 --> Final output sent to browser
DEBUG - 2016-05-20 19:56:25 --> Total execution time: 0.0529
INFO - 2016-05-20 19:56:25 --> Config Class Initialized
INFO - 2016-05-20 19:56:25 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:25 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:25 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:25 --> URI Class Initialized
INFO - 2016-05-20 19:56:25 --> Router Class Initialized
INFO - 2016-05-20 19:56:25 --> Output Class Initialized
INFO - 2016-05-20 19:56:25 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:25 --> Input Class Initialized
INFO - 2016-05-20 19:56:25 --> Language Class Initialized
INFO - 2016-05-20 19:56:25 --> Loader Class Initialized
INFO - 2016-05-20 19:56:25 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:25 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:25 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:25 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:25 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:25 --> Controller Class Initialized
INFO - 2016-05-20 19:56:25 --> Model Class Initialized
INFO - 2016-05-20 19:56:25 --> Database Driver Class Initialized
INFO - 2016-05-20 19:56:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:56:25 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:56:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:56:25 --> Final output sent to browser
DEBUG - 2016-05-20 19:56:25 --> Total execution time: 0.0864
INFO - 2016-05-20 19:56:26 --> Config Class Initialized
INFO - 2016-05-20 19:56:26 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:26 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:26 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:26 --> URI Class Initialized
INFO - 2016-05-20 19:56:26 --> Router Class Initialized
INFO - 2016-05-20 19:56:26 --> Output Class Initialized
INFO - 2016-05-20 19:56:26 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:26 --> Input Class Initialized
INFO - 2016-05-20 19:56:26 --> Language Class Initialized
INFO - 2016-05-20 19:56:26 --> Loader Class Initialized
INFO - 2016-05-20 19:56:26 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:26 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:26 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:26 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:26 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:26 --> Controller Class Initialized
DEBUG - 2016-05-20 19:56:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:56:26 --> Config Class Initialized
INFO - 2016-05-20 19:56:26 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:26 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:26 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:26 --> URI Class Initialized
INFO - 2016-05-20 19:56:26 --> Router Class Initialized
INFO - 2016-05-20 19:56:26 --> Output Class Initialized
INFO - 2016-05-20 19:56:26 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:26 --> Input Class Initialized
INFO - 2016-05-20 19:56:26 --> Language Class Initialized
INFO - 2016-05-20 19:56:26 --> Loader Class Initialized
INFO - 2016-05-20 19:56:26 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:26 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:26 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:26 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:26 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:26 --> Controller Class Initialized
DEBUG - 2016-05-20 19:56:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:56:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:56:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:56:26 --> Final output sent to browser
DEBUG - 2016-05-20 19:56:26 --> Total execution time: 0.0678
INFO - 2016-05-20 19:56:26 --> Config Class Initialized
INFO - 2016-05-20 19:56:26 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:26 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:26 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:26 --> URI Class Initialized
INFO - 2016-05-20 19:56:26 --> Router Class Initialized
INFO - 2016-05-20 19:56:26 --> Output Class Initialized
INFO - 2016-05-20 19:56:26 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:26 --> Input Class Initialized
INFO - 2016-05-20 19:56:26 --> Language Class Initialized
INFO - 2016-05-20 19:56:26 --> Loader Class Initialized
INFO - 2016-05-20 19:56:26 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:26 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:26 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:26 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:26 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:26 --> Controller Class Initialized
INFO - 2016-05-20 19:56:26 --> Model Class Initialized
INFO - 2016-05-20 19:56:26 --> Database Driver Class Initialized
INFO - 2016-05-20 19:56:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:56:26 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:56:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:56:26 --> Final output sent to browser
DEBUG - 2016-05-20 19:56:26 --> Total execution time: 0.1116
INFO - 2016-05-20 19:56:37 --> Config Class Initialized
INFO - 2016-05-20 19:56:37 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:37 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:37 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:37 --> URI Class Initialized
INFO - 2016-05-20 19:56:37 --> Router Class Initialized
INFO - 2016-05-20 19:56:37 --> Output Class Initialized
INFO - 2016-05-20 19:56:37 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:37 --> Input Class Initialized
INFO - 2016-05-20 19:56:37 --> Language Class Initialized
INFO - 2016-05-20 19:56:37 --> Loader Class Initialized
INFO - 2016-05-20 19:56:37 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:37 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:37 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:37 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:37 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:37 --> Controller Class Initialized
DEBUG - 2016-05-20 19:56:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:56:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:56:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:56:37 --> Final output sent to browser
DEBUG - 2016-05-20 19:56:37 --> Total execution time: 0.0608
INFO - 2016-05-20 19:56:37 --> Config Class Initialized
INFO - 2016-05-20 19:56:37 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:37 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:37 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:37 --> URI Class Initialized
INFO - 2016-05-20 19:56:37 --> Router Class Initialized
INFO - 2016-05-20 19:56:37 --> Output Class Initialized
INFO - 2016-05-20 19:56:37 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:37 --> Input Class Initialized
INFO - 2016-05-20 19:56:37 --> Language Class Initialized
INFO - 2016-05-20 19:56:37 --> Loader Class Initialized
INFO - 2016-05-20 19:56:37 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:37 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:37 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:37 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:37 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:37 --> Controller Class Initialized
INFO - 2016-05-20 19:56:37 --> Model Class Initialized
INFO - 2016-05-20 19:56:37 --> Database Driver Class Initialized
INFO - 2016-05-20 19:56:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:56:37 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:56:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:56:37 --> Final output sent to browser
DEBUG - 2016-05-20 19:56:37 --> Total execution time: 0.0991
INFO - 2016-05-20 19:56:39 --> Config Class Initialized
INFO - 2016-05-20 19:56:39 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:39 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:39 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:39 --> URI Class Initialized
INFO - 2016-05-20 19:56:39 --> Router Class Initialized
INFO - 2016-05-20 19:56:39 --> Output Class Initialized
INFO - 2016-05-20 19:56:39 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:39 --> Input Class Initialized
INFO - 2016-05-20 19:56:39 --> Language Class Initialized
INFO - 2016-05-20 19:56:39 --> Loader Class Initialized
INFO - 2016-05-20 19:56:39 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:39 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:39 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:39 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:39 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:39 --> Controller Class Initialized
DEBUG - 2016-05-20 19:56:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:56:39 --> Config Class Initialized
INFO - 2016-05-20 19:56:39 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:39 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:39 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:39 --> URI Class Initialized
INFO - 2016-05-20 19:56:39 --> Router Class Initialized
INFO - 2016-05-20 19:56:39 --> Output Class Initialized
INFO - 2016-05-20 19:56:39 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:39 --> Input Class Initialized
INFO - 2016-05-20 19:56:39 --> Language Class Initialized
INFO - 2016-05-20 19:56:39 --> Loader Class Initialized
INFO - 2016-05-20 19:56:39 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:39 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:39 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:39 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:39 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:39 --> Controller Class Initialized
DEBUG - 2016-05-20 19:56:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:56:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:56:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:56:39 --> Final output sent to browser
DEBUG - 2016-05-20 19:56:39 --> Total execution time: 0.0595
INFO - 2016-05-20 19:56:39 --> Config Class Initialized
INFO - 2016-05-20 19:56:39 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:39 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:39 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:39 --> URI Class Initialized
INFO - 2016-05-20 19:56:39 --> Router Class Initialized
INFO - 2016-05-20 19:56:39 --> Output Class Initialized
INFO - 2016-05-20 19:56:39 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:39 --> Input Class Initialized
INFO - 2016-05-20 19:56:39 --> Language Class Initialized
INFO - 2016-05-20 19:56:39 --> Loader Class Initialized
INFO - 2016-05-20 19:56:39 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:39 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:39 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:39 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:39 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:39 --> Controller Class Initialized
INFO - 2016-05-20 19:56:39 --> Model Class Initialized
INFO - 2016-05-20 19:56:39 --> Database Driver Class Initialized
INFO - 2016-05-20 19:56:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:56:39 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:56:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:56:39 --> Final output sent to browser
DEBUG - 2016-05-20 19:56:39 --> Total execution time: 0.1246
INFO - 2016-05-20 19:56:40 --> Config Class Initialized
INFO - 2016-05-20 19:56:40 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:40 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:40 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:40 --> URI Class Initialized
INFO - 2016-05-20 19:56:40 --> Router Class Initialized
INFO - 2016-05-20 19:56:40 --> Output Class Initialized
INFO - 2016-05-20 19:56:40 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:40 --> Input Class Initialized
INFO - 2016-05-20 19:56:40 --> Language Class Initialized
INFO - 2016-05-20 19:56:40 --> Loader Class Initialized
INFO - 2016-05-20 19:56:40 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:40 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:40 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:40 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:40 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:40 --> Controller Class Initialized
DEBUG - 2016-05-20 19:56:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:56:40 --> Config Class Initialized
INFO - 2016-05-20 19:56:40 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:40 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:40 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:40 --> URI Class Initialized
INFO - 2016-05-20 19:56:40 --> Router Class Initialized
INFO - 2016-05-20 19:56:40 --> Output Class Initialized
INFO - 2016-05-20 19:56:40 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:40 --> Input Class Initialized
INFO - 2016-05-20 19:56:40 --> Language Class Initialized
INFO - 2016-05-20 19:56:40 --> Loader Class Initialized
INFO - 2016-05-20 19:56:40 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:40 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:40 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:40 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:40 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:40 --> Controller Class Initialized
DEBUG - 2016-05-20 19:56:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:56:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:56:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:56:40 --> Final output sent to browser
DEBUG - 2016-05-20 19:56:40 --> Total execution time: 0.0527
INFO - 2016-05-20 19:56:41 --> Config Class Initialized
INFO - 2016-05-20 19:56:41 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:56:41 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:56:41 --> Utf8 Class Initialized
INFO - 2016-05-20 19:56:41 --> URI Class Initialized
INFO - 2016-05-20 19:56:41 --> Router Class Initialized
INFO - 2016-05-20 19:56:41 --> Output Class Initialized
INFO - 2016-05-20 19:56:41 --> Security Class Initialized
DEBUG - 2016-05-20 19:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:56:41 --> Input Class Initialized
INFO - 2016-05-20 19:56:41 --> Language Class Initialized
INFO - 2016-05-20 19:56:41 --> Loader Class Initialized
INFO - 2016-05-20 19:56:41 --> Helper loaded: url_helper
INFO - 2016-05-20 19:56:41 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:56:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:56:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:56:41 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:56:41 --> Helper loaded: form_helper
INFO - 2016-05-20 19:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:56:41 --> Form Validation Class Initialized
INFO - 2016-05-20 19:56:41 --> Controller Class Initialized
INFO - 2016-05-20 19:56:41 --> Model Class Initialized
INFO - 2016-05-20 19:56:41 --> Database Driver Class Initialized
INFO - 2016-05-20 19:56:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:56:41 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:56:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:56:41 --> Final output sent to browser
DEBUG - 2016-05-20 19:56:41 --> Total execution time: 0.1039
INFO - 2016-05-20 19:57:08 --> Config Class Initialized
INFO - 2016-05-20 19:57:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:57:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:57:08 --> Utf8 Class Initialized
INFO - 2016-05-20 19:57:08 --> URI Class Initialized
INFO - 2016-05-20 19:57:08 --> Router Class Initialized
INFO - 2016-05-20 19:57:08 --> Output Class Initialized
INFO - 2016-05-20 19:57:08 --> Security Class Initialized
DEBUG - 2016-05-20 19:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:57:08 --> Input Class Initialized
INFO - 2016-05-20 19:57:08 --> Language Class Initialized
INFO - 2016-05-20 19:57:08 --> Loader Class Initialized
INFO - 2016-05-20 19:57:08 --> Helper loaded: url_helper
INFO - 2016-05-20 19:57:08 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:57:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:57:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:57:08 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:57:08 --> Helper loaded: form_helper
INFO - 2016-05-20 19:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:57:08 --> Form Validation Class Initialized
INFO - 2016-05-20 19:57:08 --> Controller Class Initialized
DEBUG - 2016-05-20 19:57:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:57:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:57:16 --> Config Class Initialized
INFO - 2016-05-20 19:57:16 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:57:16 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:57:16 --> Utf8 Class Initialized
INFO - 2016-05-20 19:57:16 --> URI Class Initialized
INFO - 2016-05-20 19:57:16 --> Router Class Initialized
INFO - 2016-05-20 19:57:16 --> Output Class Initialized
INFO - 2016-05-20 19:57:16 --> Security Class Initialized
DEBUG - 2016-05-20 19:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:57:16 --> Input Class Initialized
INFO - 2016-05-20 19:57:16 --> Language Class Initialized
INFO - 2016-05-20 19:57:16 --> Loader Class Initialized
INFO - 2016-05-20 19:57:16 --> Helper loaded: url_helper
INFO - 2016-05-20 19:57:16 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:57:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:57:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:57:16 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:57:16 --> Helper loaded: form_helper
INFO - 2016-05-20 19:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:57:16 --> Form Validation Class Initialized
INFO - 2016-05-20 19:57:16 --> Controller Class Initialized
DEBUG - 2016-05-20 19:57:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:57:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:57:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:57:16 --> Final output sent to browser
DEBUG - 2016-05-20 19:57:16 --> Total execution time: 0.0678
INFO - 2016-05-20 19:57:16 --> Config Class Initialized
INFO - 2016-05-20 19:57:16 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:57:16 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:57:16 --> Utf8 Class Initialized
INFO - 2016-05-20 19:57:16 --> URI Class Initialized
INFO - 2016-05-20 19:57:16 --> Router Class Initialized
INFO - 2016-05-20 19:57:16 --> Output Class Initialized
INFO - 2016-05-20 19:57:16 --> Security Class Initialized
DEBUG - 2016-05-20 19:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:57:16 --> Input Class Initialized
INFO - 2016-05-20 19:57:16 --> Language Class Initialized
INFO - 2016-05-20 19:57:16 --> Loader Class Initialized
INFO - 2016-05-20 19:57:16 --> Helper loaded: url_helper
INFO - 2016-05-20 19:57:16 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:57:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:57:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:57:16 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:57:16 --> Helper loaded: form_helper
INFO - 2016-05-20 19:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:57:16 --> Form Validation Class Initialized
INFO - 2016-05-20 19:57:16 --> Controller Class Initialized
INFO - 2016-05-20 19:57:16 --> Model Class Initialized
INFO - 2016-05-20 19:57:16 --> Database Driver Class Initialized
INFO - 2016-05-20 19:57:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:57:16 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:57:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:57:16 --> Final output sent to browser
DEBUG - 2016-05-20 19:57:16 --> Total execution time: 0.1603
INFO - 2016-05-20 19:57:28 --> Config Class Initialized
INFO - 2016-05-20 19:57:28 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:57:28 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:57:28 --> Utf8 Class Initialized
INFO - 2016-05-20 19:57:28 --> URI Class Initialized
INFO - 2016-05-20 19:57:28 --> Router Class Initialized
INFO - 2016-05-20 19:57:28 --> Output Class Initialized
INFO - 2016-05-20 19:57:28 --> Security Class Initialized
DEBUG - 2016-05-20 19:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:57:28 --> Input Class Initialized
INFO - 2016-05-20 19:57:28 --> Language Class Initialized
INFO - 2016-05-20 19:57:28 --> Loader Class Initialized
INFO - 2016-05-20 19:57:28 --> Helper loaded: url_helper
INFO - 2016-05-20 19:57:28 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:57:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:57:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:57:28 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:57:28 --> Helper loaded: form_helper
INFO - 2016-05-20 19:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:57:28 --> Form Validation Class Initialized
INFO - 2016-05-20 19:57:28 --> Controller Class Initialized
DEBUG - 2016-05-20 19:57:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:57:28 --> Config Class Initialized
INFO - 2016-05-20 19:57:28 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:57:28 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:57:28 --> Utf8 Class Initialized
INFO - 2016-05-20 19:57:28 --> URI Class Initialized
INFO - 2016-05-20 19:57:28 --> Router Class Initialized
INFO - 2016-05-20 19:57:28 --> Output Class Initialized
INFO - 2016-05-20 19:57:28 --> Security Class Initialized
DEBUG - 2016-05-20 19:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:57:28 --> Input Class Initialized
INFO - 2016-05-20 19:57:28 --> Language Class Initialized
INFO - 2016-05-20 19:57:28 --> Loader Class Initialized
INFO - 2016-05-20 19:57:28 --> Helper loaded: url_helper
INFO - 2016-05-20 19:57:28 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:57:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:57:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:57:28 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:57:28 --> Helper loaded: form_helper
INFO - 2016-05-20 19:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:57:28 --> Form Validation Class Initialized
INFO - 2016-05-20 19:57:28 --> Controller Class Initialized
DEBUG - 2016-05-20 19:57:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:57:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:57:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:57:28 --> Final output sent to browser
DEBUG - 2016-05-20 19:57:28 --> Total execution time: 0.0769
INFO - 2016-05-20 19:57:28 --> Config Class Initialized
INFO - 2016-05-20 19:57:28 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:57:28 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:57:28 --> Utf8 Class Initialized
INFO - 2016-05-20 19:57:28 --> URI Class Initialized
INFO - 2016-05-20 19:57:28 --> Router Class Initialized
INFO - 2016-05-20 19:57:28 --> Output Class Initialized
INFO - 2016-05-20 19:57:28 --> Security Class Initialized
DEBUG - 2016-05-20 19:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:57:28 --> Input Class Initialized
INFO - 2016-05-20 19:57:28 --> Language Class Initialized
INFO - 2016-05-20 19:57:28 --> Loader Class Initialized
INFO - 2016-05-20 19:57:28 --> Helper loaded: url_helper
INFO - 2016-05-20 19:57:28 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:57:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:57:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:57:28 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:57:28 --> Helper loaded: form_helper
INFO - 2016-05-20 19:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:57:28 --> Form Validation Class Initialized
INFO - 2016-05-20 19:57:28 --> Controller Class Initialized
INFO - 2016-05-20 19:57:28 --> Model Class Initialized
INFO - 2016-05-20 19:57:28 --> Database Driver Class Initialized
INFO - 2016-05-20 19:57:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:57:28 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:57:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:57:28 --> Final output sent to browser
DEBUG - 2016-05-20 19:57:28 --> Total execution time: 0.0915
INFO - 2016-05-20 19:57:29 --> Config Class Initialized
INFO - 2016-05-20 19:57:29 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:57:29 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:57:29 --> Utf8 Class Initialized
INFO - 2016-05-20 19:57:29 --> URI Class Initialized
INFO - 2016-05-20 19:57:29 --> Router Class Initialized
INFO - 2016-05-20 19:57:29 --> Output Class Initialized
INFO - 2016-05-20 19:57:29 --> Security Class Initialized
DEBUG - 2016-05-20 19:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:57:29 --> Input Class Initialized
INFO - 2016-05-20 19:57:29 --> Language Class Initialized
INFO - 2016-05-20 19:57:29 --> Loader Class Initialized
INFO - 2016-05-20 19:57:29 --> Helper loaded: url_helper
INFO - 2016-05-20 19:57:29 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:57:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:57:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:57:29 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:57:29 --> Helper loaded: form_helper
INFO - 2016-05-20 19:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:57:29 --> Form Validation Class Initialized
INFO - 2016-05-20 19:57:29 --> Controller Class Initialized
DEBUG - 2016-05-20 19:57:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:57:29 --> Config Class Initialized
INFO - 2016-05-20 19:57:29 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:57:29 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:57:29 --> Utf8 Class Initialized
INFO - 2016-05-20 19:57:29 --> URI Class Initialized
INFO - 2016-05-20 19:57:29 --> Router Class Initialized
INFO - 2016-05-20 19:57:29 --> Output Class Initialized
INFO - 2016-05-20 19:57:29 --> Security Class Initialized
DEBUG - 2016-05-20 19:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:57:29 --> Input Class Initialized
INFO - 2016-05-20 19:57:29 --> Language Class Initialized
INFO - 2016-05-20 19:57:29 --> Loader Class Initialized
INFO - 2016-05-20 19:57:29 --> Helper loaded: url_helper
INFO - 2016-05-20 19:57:29 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:57:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:57:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:57:29 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:57:29 --> Helper loaded: form_helper
INFO - 2016-05-20 19:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:57:29 --> Form Validation Class Initialized
INFO - 2016-05-20 19:57:29 --> Controller Class Initialized
DEBUG - 2016-05-20 19:57:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/templates.php
INFO - 2016-05-20 19:57:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-20 19:57:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-20 19:57:29 --> Final output sent to browser
DEBUG - 2016-05-20 19:57:29 --> Total execution time: 0.0687
INFO - 2016-05-20 19:57:30 --> Config Class Initialized
INFO - 2016-05-20 19:57:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:57:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:57:30 --> Utf8 Class Initialized
INFO - 2016-05-20 19:57:30 --> URI Class Initialized
INFO - 2016-05-20 19:57:30 --> Router Class Initialized
INFO - 2016-05-20 19:57:30 --> Output Class Initialized
INFO - 2016-05-20 19:57:30 --> Security Class Initialized
DEBUG - 2016-05-20 19:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:57:30 --> Input Class Initialized
INFO - 2016-05-20 19:57:30 --> Language Class Initialized
INFO - 2016-05-20 19:57:30 --> Loader Class Initialized
INFO - 2016-05-20 19:57:30 --> Helper loaded: url_helper
INFO - 2016-05-20 19:57:30 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:57:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:57:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:57:30 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:57:30 --> Helper loaded: form_helper
INFO - 2016-05-20 19:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:57:30 --> Form Validation Class Initialized
INFO - 2016-05-20 19:57:30 --> Controller Class Initialized
INFO - 2016-05-20 19:57:30 --> Model Class Initialized
INFO - 2016-05-20 19:57:30 --> Database Driver Class Initialized
INFO - 2016-05-20 19:57:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:57:30 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:57:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:57:30 --> Final output sent to browser
DEBUG - 2016-05-20 19:57:30 --> Total execution time: 0.1144
INFO - 2016-05-20 19:58:30 --> Config Class Initialized
INFO - 2016-05-20 19:58:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:58:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:58:30 --> Utf8 Class Initialized
INFO - 2016-05-20 19:58:30 --> URI Class Initialized
INFO - 2016-05-20 19:58:30 --> Router Class Initialized
INFO - 2016-05-20 19:58:30 --> Output Class Initialized
INFO - 2016-05-20 19:58:30 --> Security Class Initialized
DEBUG - 2016-05-20 19:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:58:30 --> Input Class Initialized
INFO - 2016-05-20 19:58:30 --> Language Class Initialized
INFO - 2016-05-20 19:58:30 --> Loader Class Initialized
INFO - 2016-05-20 19:58:30 --> Helper loaded: url_helper
INFO - 2016-05-20 19:58:30 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:58:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:58:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:58:30 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:58:30 --> Helper loaded: form_helper
INFO - 2016-05-20 19:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:58:30 --> Form Validation Class Initialized
INFO - 2016-05-20 19:58:30 --> Controller Class Initialized
INFO - 2016-05-20 19:58:30 --> Model Class Initialized
INFO - 2016-05-20 19:58:30 --> Database Driver Class Initialized
INFO - 2016-05-20 19:58:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:58:30 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:58:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:58:30 --> Final output sent to browser
DEBUG - 2016-05-20 19:58:30 --> Total execution time: 0.0938
INFO - 2016-05-20 19:59:30 --> Config Class Initialized
INFO - 2016-05-20 19:59:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:59:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:59:30 --> Utf8 Class Initialized
INFO - 2016-05-20 19:59:30 --> URI Class Initialized
INFO - 2016-05-20 19:59:30 --> Router Class Initialized
INFO - 2016-05-20 19:59:30 --> Output Class Initialized
INFO - 2016-05-20 19:59:30 --> Security Class Initialized
DEBUG - 2016-05-20 19:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:59:30 --> Input Class Initialized
INFO - 2016-05-20 19:59:30 --> Language Class Initialized
INFO - 2016-05-20 19:59:30 --> Loader Class Initialized
INFO - 2016-05-20 19:59:30 --> Helper loaded: url_helper
INFO - 2016-05-20 19:59:30 --> Helper loaded: sesion_helper
INFO - 2016-05-20 19:59:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 19:59:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 19:59:30 --> Helper loaded: redondear_helper
INFO - 2016-05-20 19:59:30 --> Helper loaded: form_helper
INFO - 2016-05-20 19:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 19:59:30 --> Form Validation Class Initialized
INFO - 2016-05-20 19:59:30 --> Controller Class Initialized
INFO - 2016-05-20 19:59:30 --> Model Class Initialized
INFO - 2016-05-20 19:59:30 --> Database Driver Class Initialized
INFO - 2016-05-20 19:59:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 19:59:30 --> Pagination Class Initialized
DEBUG - 2016-05-20 19:59:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 19:59:30 --> Final output sent to browser
DEBUG - 2016-05-20 19:59:30 --> Total execution time: 0.0725
INFO - 2016-05-20 20:00:30 --> Config Class Initialized
INFO - 2016-05-20 20:00:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 20:00:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 20:00:30 --> Utf8 Class Initialized
INFO - 2016-05-20 20:00:30 --> URI Class Initialized
INFO - 2016-05-20 20:00:30 --> Router Class Initialized
INFO - 2016-05-20 20:00:30 --> Output Class Initialized
INFO - 2016-05-20 20:00:30 --> Security Class Initialized
DEBUG - 2016-05-20 20:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 20:00:30 --> Input Class Initialized
INFO - 2016-05-20 20:00:30 --> Language Class Initialized
INFO - 2016-05-20 20:00:30 --> Loader Class Initialized
INFO - 2016-05-20 20:00:30 --> Helper loaded: url_helper
INFO - 2016-05-20 20:00:30 --> Helper loaded: sesion_helper
INFO - 2016-05-20 20:00:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 20:00:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 20:00:30 --> Helper loaded: redondear_helper
INFO - 2016-05-20 20:00:30 --> Helper loaded: form_helper
INFO - 2016-05-20 20:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 20:00:30 --> Form Validation Class Initialized
INFO - 2016-05-20 20:00:30 --> Controller Class Initialized
INFO - 2016-05-20 20:00:30 --> Model Class Initialized
INFO - 2016-05-20 20:00:30 --> Database Driver Class Initialized
INFO - 2016-05-20 20:00:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 20:00:30 --> Pagination Class Initialized
DEBUG - 2016-05-20 20:00:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 20:00:30 --> Final output sent to browser
DEBUG - 2016-05-20 20:00:30 --> Total execution time: 0.1047
INFO - 2016-05-20 20:01:30 --> Config Class Initialized
INFO - 2016-05-20 20:01:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 20:01:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 20:01:30 --> Utf8 Class Initialized
INFO - 2016-05-20 20:01:30 --> URI Class Initialized
INFO - 2016-05-20 20:01:30 --> Router Class Initialized
INFO - 2016-05-20 20:01:30 --> Output Class Initialized
INFO - 2016-05-20 20:01:30 --> Security Class Initialized
DEBUG - 2016-05-20 20:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 20:01:30 --> Input Class Initialized
INFO - 2016-05-20 20:01:30 --> Language Class Initialized
INFO - 2016-05-20 20:01:30 --> Loader Class Initialized
INFO - 2016-05-20 20:01:30 --> Helper loaded: url_helper
INFO - 2016-05-20 20:01:30 --> Helper loaded: sesion_helper
INFO - 2016-05-20 20:01:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 20:01:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 20:01:30 --> Helper loaded: redondear_helper
INFO - 2016-05-20 20:01:30 --> Helper loaded: form_helper
INFO - 2016-05-20 20:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 20:01:30 --> Form Validation Class Initialized
INFO - 2016-05-20 20:01:30 --> Controller Class Initialized
INFO - 2016-05-20 20:01:30 --> Model Class Initialized
INFO - 2016-05-20 20:01:30 --> Database Driver Class Initialized
INFO - 2016-05-20 20:01:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 20:01:30 --> Pagination Class Initialized
DEBUG - 2016-05-20 20:01:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 20:01:30 --> Final output sent to browser
DEBUG - 2016-05-20 20:01:30 --> Total execution time: 0.0761
INFO - 2016-05-20 20:02:30 --> Config Class Initialized
INFO - 2016-05-20 20:02:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 20:02:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 20:02:30 --> Utf8 Class Initialized
INFO - 2016-05-20 20:02:30 --> URI Class Initialized
INFO - 2016-05-20 20:02:30 --> Router Class Initialized
INFO - 2016-05-20 20:02:30 --> Output Class Initialized
INFO - 2016-05-20 20:02:30 --> Security Class Initialized
DEBUG - 2016-05-20 20:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 20:02:30 --> Input Class Initialized
INFO - 2016-05-20 20:02:30 --> Language Class Initialized
INFO - 2016-05-20 20:02:30 --> Loader Class Initialized
INFO - 2016-05-20 20:02:30 --> Helper loaded: url_helper
INFO - 2016-05-20 20:02:30 --> Helper loaded: sesion_helper
INFO - 2016-05-20 20:02:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 20:02:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 20:02:30 --> Helper loaded: redondear_helper
INFO - 2016-05-20 20:02:30 --> Helper loaded: form_helper
INFO - 2016-05-20 20:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 20:02:30 --> Form Validation Class Initialized
INFO - 2016-05-20 20:02:30 --> Controller Class Initialized
INFO - 2016-05-20 20:02:30 --> Model Class Initialized
INFO - 2016-05-20 20:02:30 --> Database Driver Class Initialized
INFO - 2016-05-20 20:02:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 20:02:30 --> Pagination Class Initialized
DEBUG - 2016-05-20 20:02:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 20:02:30 --> Final output sent to browser
DEBUG - 2016-05-20 20:02:30 --> Total execution time: 0.0759
INFO - 2016-05-20 20:03:30 --> Config Class Initialized
INFO - 2016-05-20 20:03:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 20:03:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 20:03:30 --> Utf8 Class Initialized
INFO - 2016-05-20 20:03:30 --> URI Class Initialized
INFO - 2016-05-20 20:03:30 --> Router Class Initialized
INFO - 2016-05-20 20:03:30 --> Output Class Initialized
INFO - 2016-05-20 20:03:30 --> Security Class Initialized
DEBUG - 2016-05-20 20:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 20:03:30 --> Input Class Initialized
INFO - 2016-05-20 20:03:30 --> Language Class Initialized
INFO - 2016-05-20 20:03:30 --> Loader Class Initialized
INFO - 2016-05-20 20:03:30 --> Helper loaded: url_helper
INFO - 2016-05-20 20:03:30 --> Helper loaded: sesion_helper
INFO - 2016-05-20 20:03:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 20:03:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 20:03:30 --> Helper loaded: redondear_helper
INFO - 2016-05-20 20:03:30 --> Helper loaded: form_helper
INFO - 2016-05-20 20:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 20:03:30 --> Form Validation Class Initialized
INFO - 2016-05-20 20:03:30 --> Controller Class Initialized
INFO - 2016-05-20 20:03:30 --> Model Class Initialized
INFO - 2016-05-20 20:03:30 --> Database Driver Class Initialized
INFO - 2016-05-20 20:03:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 20:03:30 --> Pagination Class Initialized
DEBUG - 2016-05-20 20:03:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 20:03:30 --> Final output sent to browser
DEBUG - 2016-05-20 20:03:30 --> Total execution time: 0.0728
INFO - 2016-05-20 20:04:30 --> Config Class Initialized
INFO - 2016-05-20 20:04:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 20:04:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 20:04:30 --> Utf8 Class Initialized
INFO - 2016-05-20 20:04:30 --> URI Class Initialized
INFO - 2016-05-20 20:04:30 --> Router Class Initialized
INFO - 2016-05-20 20:04:30 --> Output Class Initialized
INFO - 2016-05-20 20:04:30 --> Security Class Initialized
DEBUG - 2016-05-20 20:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 20:04:30 --> Input Class Initialized
INFO - 2016-05-20 20:04:30 --> Language Class Initialized
INFO - 2016-05-20 20:04:30 --> Loader Class Initialized
INFO - 2016-05-20 20:04:30 --> Helper loaded: url_helper
INFO - 2016-05-20 20:04:30 --> Helper loaded: sesion_helper
INFO - 2016-05-20 20:04:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 20:04:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 20:04:30 --> Helper loaded: redondear_helper
INFO - 2016-05-20 20:04:30 --> Helper loaded: form_helper
INFO - 2016-05-20 20:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 20:04:30 --> Form Validation Class Initialized
INFO - 2016-05-20 20:04:30 --> Controller Class Initialized
INFO - 2016-05-20 20:04:30 --> Model Class Initialized
INFO - 2016-05-20 20:04:30 --> Database Driver Class Initialized
INFO - 2016-05-20 20:04:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 20:04:31 --> Pagination Class Initialized
DEBUG - 2016-05-20 20:04:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 20:04:31 --> Final output sent to browser
DEBUG - 2016-05-20 20:04:31 --> Total execution time: 0.2099
INFO - 2016-05-20 20:05:30 --> Config Class Initialized
INFO - 2016-05-20 20:05:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 20:05:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 20:05:30 --> Utf8 Class Initialized
INFO - 2016-05-20 20:05:30 --> URI Class Initialized
INFO - 2016-05-20 20:05:30 --> Router Class Initialized
INFO - 2016-05-20 20:05:30 --> Output Class Initialized
INFO - 2016-05-20 20:05:30 --> Security Class Initialized
DEBUG - 2016-05-20 20:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 20:05:30 --> Input Class Initialized
INFO - 2016-05-20 20:05:30 --> Language Class Initialized
INFO - 2016-05-20 20:05:30 --> Loader Class Initialized
INFO - 2016-05-20 20:05:30 --> Helper loaded: url_helper
INFO - 2016-05-20 20:05:30 --> Helper loaded: sesion_helper
INFO - 2016-05-20 20:05:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-20 20:05:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-20 20:05:30 --> Helper loaded: redondear_helper
INFO - 2016-05-20 20:05:30 --> Helper loaded: form_helper
INFO - 2016-05-20 20:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-20 20:05:30 --> Form Validation Class Initialized
INFO - 2016-05-20 20:05:30 --> Controller Class Initialized
INFO - 2016-05-20 20:05:30 --> Model Class Initialized
INFO - 2016-05-20 20:05:30 --> Database Driver Class Initialized
INFO - 2016-05-20 20:05:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-20 20:05:30 --> Pagination Class Initialized
DEBUG - 2016-05-20 20:05:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-20 20:05:30 --> Final output sent to browser
DEBUG - 2016-05-20 20:05:30 --> Total execution time: 0.0728
