<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-08 09:07:16 --> Config Class Initialized
INFO - 2016-05-08 09:07:16 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:07:16 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:07:16 --> Utf8 Class Initialized
INFO - 2016-05-08 09:07:16 --> URI Class Initialized
INFO - 2016-05-08 09:07:16 --> Router Class Initialized
INFO - 2016-05-08 09:07:16 --> Output Class Initialized
INFO - 2016-05-08 09:07:16 --> Security Class Initialized
DEBUG - 2016-05-08 09:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:07:16 --> Input Class Initialized
INFO - 2016-05-08 09:07:16 --> Language Class Initialized
INFO - 2016-05-08 09:07:16 --> Loader Class Initialized
INFO - 2016-05-08 09:07:16 --> Helper loaded: url_helper
INFO - 2016-05-08 09:07:16 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:07:16 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:07:16 --> Helper loaded: form_helper
INFO - 2016-05-08 09:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:07:16 --> Form Validation Class Initialized
INFO - 2016-05-08 09:07:16 --> Controller Class Initialized
INFO - 2016-05-08 09:07:16 --> Config Class Initialized
INFO - 2016-05-08 09:07:16 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:07:16 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:07:16 --> Utf8 Class Initialized
INFO - 2016-05-08 09:07:16 --> URI Class Initialized
INFO - 2016-05-08 09:07:16 --> Router Class Initialized
INFO - 2016-05-08 09:07:16 --> Output Class Initialized
INFO - 2016-05-08 09:07:16 --> Security Class Initialized
DEBUG - 2016-05-08 09:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:07:16 --> Input Class Initialized
INFO - 2016-05-08 09:07:16 --> Language Class Initialized
INFO - 2016-05-08 09:07:16 --> Loader Class Initialized
INFO - 2016-05-08 09:07:16 --> Helper loaded: url_helper
INFO - 2016-05-08 09:07:16 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:07:16 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:07:16 --> Helper loaded: form_helper
INFO - 2016-05-08 09:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:07:16 --> Form Validation Class Initialized
INFO - 2016-05-08 09:07:16 --> Controller Class Initialized
INFO - 2016-05-08 09:07:16 --> Model Class Initialized
INFO - 2016-05-08 09:07:16 --> Database Driver Class Initialized
INFO - 2016-05-08 09:07:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-08 09:07:16 --> Final output sent to browser
DEBUG - 2016-05-08 09:07:16 --> Total execution time: 0.1378
INFO - 2016-05-08 09:07:24 --> Config Class Initialized
INFO - 2016-05-08 09:07:24 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:07:24 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:07:24 --> Utf8 Class Initialized
INFO - 2016-05-08 09:07:24 --> URI Class Initialized
INFO - 2016-05-08 09:07:24 --> Router Class Initialized
INFO - 2016-05-08 09:07:24 --> Output Class Initialized
INFO - 2016-05-08 09:07:24 --> Security Class Initialized
DEBUG - 2016-05-08 09:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:07:24 --> Input Class Initialized
INFO - 2016-05-08 09:07:24 --> Language Class Initialized
INFO - 2016-05-08 09:07:24 --> Loader Class Initialized
INFO - 2016-05-08 09:07:24 --> Helper loaded: url_helper
INFO - 2016-05-08 09:07:24 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:07:24 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:07:24 --> Helper loaded: form_helper
INFO - 2016-05-08 09:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:07:24 --> Form Validation Class Initialized
INFO - 2016-05-08 09:07:24 --> Controller Class Initialized
INFO - 2016-05-08 09:07:24 --> Model Class Initialized
INFO - 2016-05-08 09:07:24 --> Database Driver Class Initialized
INFO - 2016-05-08 09:07:24 --> Config Class Initialized
INFO - 2016-05-08 09:07:24 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:07:24 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:07:24 --> Utf8 Class Initialized
INFO - 2016-05-08 09:07:24 --> URI Class Initialized
INFO - 2016-05-08 09:07:24 --> Router Class Initialized
INFO - 2016-05-08 09:07:24 --> Output Class Initialized
INFO - 2016-05-08 09:07:24 --> Security Class Initialized
DEBUG - 2016-05-08 09:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:07:24 --> Input Class Initialized
INFO - 2016-05-08 09:07:24 --> Language Class Initialized
INFO - 2016-05-08 09:07:24 --> Loader Class Initialized
INFO - 2016-05-08 09:07:24 --> Helper loaded: url_helper
INFO - 2016-05-08 09:07:24 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:07:24 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:07:24 --> Helper loaded: form_helper
INFO - 2016-05-08 09:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:07:24 --> Form Validation Class Initialized
INFO - 2016-05-08 09:07:24 --> Controller Class Initialized
INFO - 2016-05-08 09:07:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-08 09:07:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 09:07:24 --> Final output sent to browser
DEBUG - 2016-05-08 09:07:24 --> Total execution time: 0.0513
INFO - 2016-05-08 09:07:35 --> Config Class Initialized
INFO - 2016-05-08 09:07:35 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:07:35 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:07:35 --> Utf8 Class Initialized
INFO - 2016-05-08 09:07:35 --> URI Class Initialized
INFO - 2016-05-08 09:07:35 --> Router Class Initialized
INFO - 2016-05-08 09:07:35 --> Output Class Initialized
INFO - 2016-05-08 09:07:35 --> Security Class Initialized
DEBUG - 2016-05-08 09:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:07:35 --> Input Class Initialized
INFO - 2016-05-08 09:07:35 --> Language Class Initialized
INFO - 2016-05-08 09:07:35 --> Loader Class Initialized
INFO - 2016-05-08 09:07:35 --> Helper loaded: url_helper
INFO - 2016-05-08 09:07:35 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:07:35 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:07:35 --> Helper loaded: form_helper
INFO - 2016-05-08 09:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:07:35 --> Form Validation Class Initialized
INFO - 2016-05-08 09:07:35 --> Controller Class Initialized
INFO - 2016-05-08 09:07:35 --> Model Class Initialized
INFO - 2016-05-08 09:07:35 --> Database Driver Class Initialized
INFO - 2016-05-08 09:07:35 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:07:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:07:35 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:07:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:07:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 09:07:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 09:07:35 --> Final output sent to browser
DEBUG - 2016-05-08 09:07:35 --> Total execution time: 0.0882
INFO - 2016-05-08 09:07:37 --> Config Class Initialized
INFO - 2016-05-08 09:07:37 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:07:37 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:07:37 --> Utf8 Class Initialized
INFO - 2016-05-08 09:07:37 --> URI Class Initialized
INFO - 2016-05-08 09:07:37 --> Router Class Initialized
INFO - 2016-05-08 09:07:37 --> Output Class Initialized
INFO - 2016-05-08 09:07:37 --> Security Class Initialized
DEBUG - 2016-05-08 09:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:07:37 --> Input Class Initialized
INFO - 2016-05-08 09:07:37 --> Language Class Initialized
INFO - 2016-05-08 09:07:37 --> Loader Class Initialized
INFO - 2016-05-08 09:07:37 --> Helper loaded: url_helper
INFO - 2016-05-08 09:07:37 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:07:37 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:07:37 --> Helper loaded: form_helper
INFO - 2016-05-08 09:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:07:37 --> Form Validation Class Initialized
INFO - 2016-05-08 09:07:37 --> Controller Class Initialized
INFO - 2016-05-08 09:07:37 --> Model Class Initialized
INFO - 2016-05-08 09:07:37 --> Database Driver Class Initialized
INFO - 2016-05-08 09:07:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:07:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:07:37 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:07:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:07:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-08 09:07:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 09:07:37 --> Final output sent to browser
DEBUG - 2016-05-08 09:07:37 --> Total execution time: 0.0955
INFO - 2016-05-08 09:07:39 --> Config Class Initialized
INFO - 2016-05-08 09:07:39 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:07:39 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:07:39 --> Utf8 Class Initialized
INFO - 2016-05-08 09:07:39 --> URI Class Initialized
INFO - 2016-05-08 09:07:39 --> Router Class Initialized
INFO - 2016-05-08 09:07:39 --> Output Class Initialized
INFO - 2016-05-08 09:07:39 --> Security Class Initialized
DEBUG - 2016-05-08 09:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:07:39 --> Input Class Initialized
INFO - 2016-05-08 09:07:39 --> Language Class Initialized
INFO - 2016-05-08 09:07:39 --> Loader Class Initialized
INFO - 2016-05-08 09:07:39 --> Helper loaded: url_helper
INFO - 2016-05-08 09:07:39 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:07:39 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:07:39 --> Helper loaded: form_helper
INFO - 2016-05-08 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:07:39 --> Form Validation Class Initialized
INFO - 2016-05-08 09:07:39 --> Controller Class Initialized
INFO - 2016-05-08 09:07:39 --> Model Class Initialized
INFO - 2016-05-08 09:07:39 --> Database Driver Class Initialized
INFO - 2016-05-08 09:07:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:07:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:07:39 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:07:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:07:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 09:07:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 09:07:39 --> Final output sent to browser
DEBUG - 2016-05-08 09:07:39 --> Total execution time: 0.1197
INFO - 2016-05-08 09:07:44 --> Config Class Initialized
INFO - 2016-05-08 09:07:44 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:07:44 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:07:44 --> Utf8 Class Initialized
INFO - 2016-05-08 09:07:44 --> URI Class Initialized
INFO - 2016-05-08 09:07:44 --> Router Class Initialized
INFO - 2016-05-08 09:07:44 --> Output Class Initialized
INFO - 2016-05-08 09:07:44 --> Security Class Initialized
DEBUG - 2016-05-08 09:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:07:44 --> Input Class Initialized
INFO - 2016-05-08 09:07:44 --> Language Class Initialized
INFO - 2016-05-08 09:07:44 --> Loader Class Initialized
INFO - 2016-05-08 09:07:44 --> Helper loaded: url_helper
INFO - 2016-05-08 09:07:44 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:07:44 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:07:44 --> Helper loaded: form_helper
INFO - 2016-05-08 09:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:07:44 --> Form Validation Class Initialized
INFO - 2016-05-08 09:07:44 --> Controller Class Initialized
INFO - 2016-05-08 09:07:44 --> Model Class Initialized
INFO - 2016-05-08 09:07:44 --> Database Driver Class Initialized
INFO - 2016-05-08 09:07:44 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:07:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:07:44 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:07:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:07:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 09:07:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 09:07:44 --> Final output sent to browser
DEBUG - 2016-05-08 09:07:44 --> Total execution time: 0.0906
INFO - 2016-05-08 09:07:46 --> Config Class Initialized
INFO - 2016-05-08 09:07:46 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:07:46 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:07:46 --> Utf8 Class Initialized
INFO - 2016-05-08 09:07:46 --> URI Class Initialized
INFO - 2016-05-08 09:07:46 --> Router Class Initialized
INFO - 2016-05-08 09:07:46 --> Output Class Initialized
INFO - 2016-05-08 09:07:46 --> Security Class Initialized
DEBUG - 2016-05-08 09:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:07:46 --> Input Class Initialized
INFO - 2016-05-08 09:07:46 --> Language Class Initialized
INFO - 2016-05-08 09:07:46 --> Loader Class Initialized
INFO - 2016-05-08 09:07:46 --> Helper loaded: url_helper
INFO - 2016-05-08 09:07:46 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:07:46 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:07:46 --> Helper loaded: form_helper
INFO - 2016-05-08 09:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:07:46 --> Form Validation Class Initialized
INFO - 2016-05-08 09:07:46 --> Controller Class Initialized
INFO - 2016-05-08 09:07:46 --> Model Class Initialized
INFO - 2016-05-08 09:07:46 --> Database Driver Class Initialized
INFO - 2016-05-08 09:07:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:07:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:07:46 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:07:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:07:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 09:07:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 09:07:46 --> Final output sent to browser
DEBUG - 2016-05-08 09:07:46 --> Total execution time: 0.1200
INFO - 2016-05-08 09:07:49 --> Config Class Initialized
INFO - 2016-05-08 09:07:49 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:07:49 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:07:49 --> Utf8 Class Initialized
INFO - 2016-05-08 09:07:49 --> URI Class Initialized
INFO - 2016-05-08 09:07:49 --> Router Class Initialized
INFO - 2016-05-08 09:07:49 --> Output Class Initialized
INFO - 2016-05-08 09:07:49 --> Security Class Initialized
DEBUG - 2016-05-08 09:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:07:49 --> Input Class Initialized
INFO - 2016-05-08 09:07:49 --> Language Class Initialized
INFO - 2016-05-08 09:07:49 --> Loader Class Initialized
INFO - 2016-05-08 09:07:49 --> Helper loaded: url_helper
INFO - 2016-05-08 09:07:49 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:07:49 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:07:49 --> Helper loaded: form_helper
INFO - 2016-05-08 09:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:07:49 --> Form Validation Class Initialized
INFO - 2016-05-08 09:07:49 --> Controller Class Initialized
INFO - 2016-05-08 09:07:49 --> Model Class Initialized
INFO - 2016-05-08 09:07:49 --> Database Driver Class Initialized
INFO - 2016-05-08 09:07:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:07:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:07:49 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:07:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:07:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 09:07:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 09:07:49 --> Final output sent to browser
DEBUG - 2016-05-08 09:07:49 --> Total execution time: 0.1119
INFO - 2016-05-08 09:07:50 --> Config Class Initialized
INFO - 2016-05-08 09:07:50 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:07:50 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:07:50 --> Utf8 Class Initialized
INFO - 2016-05-08 09:07:50 --> URI Class Initialized
INFO - 2016-05-08 09:07:50 --> Router Class Initialized
INFO - 2016-05-08 09:07:50 --> Output Class Initialized
INFO - 2016-05-08 09:07:50 --> Security Class Initialized
DEBUG - 2016-05-08 09:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:07:50 --> Input Class Initialized
INFO - 2016-05-08 09:07:50 --> Language Class Initialized
INFO - 2016-05-08 09:07:50 --> Loader Class Initialized
INFO - 2016-05-08 09:07:50 --> Helper loaded: url_helper
INFO - 2016-05-08 09:07:50 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:07:50 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:07:50 --> Helper loaded: form_helper
INFO - 2016-05-08 09:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:07:50 --> Form Validation Class Initialized
INFO - 2016-05-08 09:07:50 --> Controller Class Initialized
INFO - 2016-05-08 09:07:50 --> Model Class Initialized
INFO - 2016-05-08 09:07:50 --> Database Driver Class Initialized
INFO - 2016-05-08 09:07:50 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:07:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:07:50 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:07:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:07:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 09:07:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 09:07:50 --> Final output sent to browser
DEBUG - 2016-05-08 09:07:50 --> Total execution time: 0.1198
INFO - 2016-05-08 09:07:57 --> Config Class Initialized
INFO - 2016-05-08 09:07:57 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:07:57 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:07:57 --> Utf8 Class Initialized
INFO - 2016-05-08 09:07:57 --> URI Class Initialized
INFO - 2016-05-08 09:07:57 --> Router Class Initialized
INFO - 2016-05-08 09:07:57 --> Output Class Initialized
INFO - 2016-05-08 09:07:57 --> Security Class Initialized
DEBUG - 2016-05-08 09:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:07:57 --> Input Class Initialized
INFO - 2016-05-08 09:07:57 --> Language Class Initialized
INFO - 2016-05-08 09:07:57 --> Loader Class Initialized
INFO - 2016-05-08 09:07:57 --> Helper loaded: url_helper
INFO - 2016-05-08 09:07:57 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:07:57 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:07:57 --> Helper loaded: form_helper
INFO - 2016-05-08 09:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:07:57 --> Form Validation Class Initialized
INFO - 2016-05-08 09:07:57 --> Controller Class Initialized
INFO - 2016-05-08 09:07:57 --> Model Class Initialized
INFO - 2016-05-08 09:07:57 --> Database Driver Class Initialized
INFO - 2016-05-08 09:07:57 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:07:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:07:57 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:07:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-08 09:07:57 --> Severity: Warning --> mysqli::query(): (21000/1242): Subquery returns more than 1 row C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 264
ERROR - 2016-05-08 09:07:57 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT * FROM producto WHERE referencia LIKE '%ordenadores%' OR nombre LIKE '%ordenadores%' OR marca LIKE '%ordenadores%' OR precio LIKE '%ordenadores%' OR precio_venta LIKE '%ordenadores%' OR iva LIKE '%ordenadores%' OR stock LIKE '%ordenadores%' OR descripcion LIKE '%ordenadores%' OR estado LIKE '%ordenadores%' OR idProveedor = (select idProveedor from proveedor where nombre LIKE '%ordenadores%') OR idCategoria = (select idCategoria from categoria where nombre LIKE '%ordenadores%')LIMIT 0, 5; 
INFO - 2016-05-08 09:07:57 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-08 09:27:35 --> Config Class Initialized
INFO - 2016-05-08 09:27:35 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:27:35 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:27:35 --> Utf8 Class Initialized
INFO - 2016-05-08 09:27:35 --> URI Class Initialized
INFO - 2016-05-08 09:27:35 --> Router Class Initialized
INFO - 2016-05-08 09:27:35 --> Output Class Initialized
INFO - 2016-05-08 09:27:35 --> Security Class Initialized
DEBUG - 2016-05-08 09:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:27:35 --> Input Class Initialized
INFO - 2016-05-08 09:27:35 --> Language Class Initialized
INFO - 2016-05-08 09:27:35 --> Loader Class Initialized
INFO - 2016-05-08 09:27:35 --> Helper loaded: url_helper
INFO - 2016-05-08 09:27:35 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:27:35 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:27:35 --> Helper loaded: form_helper
INFO - 2016-05-08 09:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:27:35 --> Form Validation Class Initialized
INFO - 2016-05-08 09:27:35 --> Controller Class Initialized
INFO - 2016-05-08 09:27:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-08 09:27:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 09:27:35 --> Final output sent to browser
DEBUG - 2016-05-08 09:27:35 --> Total execution time: 0.0554
INFO - 2016-05-08 09:27:39 --> Config Class Initialized
INFO - 2016-05-08 09:27:39 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:27:39 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:27:39 --> Utf8 Class Initialized
INFO - 2016-05-08 09:27:39 --> URI Class Initialized
INFO - 2016-05-08 09:27:39 --> Router Class Initialized
INFO - 2016-05-08 09:27:39 --> Output Class Initialized
INFO - 2016-05-08 09:27:39 --> Security Class Initialized
DEBUG - 2016-05-08 09:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:27:39 --> Input Class Initialized
INFO - 2016-05-08 09:27:39 --> Language Class Initialized
INFO - 2016-05-08 09:27:39 --> Loader Class Initialized
INFO - 2016-05-08 09:27:39 --> Helper loaded: url_helper
INFO - 2016-05-08 09:27:39 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:27:39 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:27:39 --> Helper loaded: form_helper
INFO - 2016-05-08 09:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:27:39 --> Form Validation Class Initialized
INFO - 2016-05-08 09:27:39 --> Controller Class Initialized
INFO - 2016-05-08 09:27:39 --> Model Class Initialized
INFO - 2016-05-08 09:27:39 --> Database Driver Class Initialized
INFO - 2016-05-08 09:27:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:27:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:27:39 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:27:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:27:39 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 09:27:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 09:27:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 09:27:39 --> Final output sent to browser
DEBUG - 2016-05-08 09:27:39 --> Total execution time: 0.0793
INFO - 2016-05-08 09:27:43 --> Config Class Initialized
INFO - 2016-05-08 09:27:43 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:27:43 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:27:43 --> Utf8 Class Initialized
INFO - 2016-05-08 09:27:43 --> URI Class Initialized
INFO - 2016-05-08 09:27:43 --> Router Class Initialized
INFO - 2016-05-08 09:27:43 --> Output Class Initialized
INFO - 2016-05-08 09:27:43 --> Security Class Initialized
DEBUG - 2016-05-08 09:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:27:43 --> Input Class Initialized
INFO - 2016-05-08 09:27:43 --> Language Class Initialized
INFO - 2016-05-08 09:27:43 --> Loader Class Initialized
INFO - 2016-05-08 09:27:43 --> Helper loaded: url_helper
INFO - 2016-05-08 09:27:43 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:27:43 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:27:43 --> Helper loaded: form_helper
INFO - 2016-05-08 09:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:27:43 --> Form Validation Class Initialized
INFO - 2016-05-08 09:27:43 --> Controller Class Initialized
INFO - 2016-05-08 09:27:43 --> Model Class Initialized
INFO - 2016-05-08 09:27:43 --> Database Driver Class Initialized
INFO - 2016-05-08 09:27:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:27:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:27:43 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:27:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:27:43 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 09:27:43 --> Query error: Table 'bdproyecto.provincias' doesn't exist - Invalid query: SELECT count(*) 'cont' FROM proveedor prove INNER JOIN provincias provi ON provi.idProvincia=prove.idProvincia WHERE prove.nombre LIKE '%madrid%' OR prove.nif LIKE '%madrid%' OR prove.correo LIKE '%madrid%' OR prove.telefono LIKE '%madrid%' OR prove.direccion LIKE '%madrid%' OR prove.localidad LIKE '%madrid%' OR prove.cp LIKE '%madrid%' OR prove.anotaciones LIKE '%madrid%' OR prove.estado LIKE '%madrid%' OR provi.nombre LIKE '%madrid%'
INFO - 2016-05-08 09:27:43 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-08 09:28:07 --> Config Class Initialized
INFO - 2016-05-08 09:28:07 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:28:07 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:28:07 --> Utf8 Class Initialized
INFO - 2016-05-08 09:28:07 --> URI Class Initialized
INFO - 2016-05-08 09:28:07 --> Router Class Initialized
INFO - 2016-05-08 09:28:07 --> Output Class Initialized
INFO - 2016-05-08 09:28:07 --> Security Class Initialized
DEBUG - 2016-05-08 09:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:28:07 --> Input Class Initialized
INFO - 2016-05-08 09:28:07 --> Language Class Initialized
INFO - 2016-05-08 09:28:07 --> Loader Class Initialized
INFO - 2016-05-08 09:28:07 --> Helper loaded: url_helper
INFO - 2016-05-08 09:28:07 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:28:07 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:28:07 --> Helper loaded: form_helper
INFO - 2016-05-08 09:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:28:07 --> Form Validation Class Initialized
INFO - 2016-05-08 09:28:07 --> Controller Class Initialized
INFO - 2016-05-08 09:28:07 --> Model Class Initialized
INFO - 2016-05-08 09:28:07 --> Database Driver Class Initialized
INFO - 2016-05-08 09:28:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:28:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:28:07 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:28:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:28:07 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 09:28:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 09:28:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 09:28:07 --> Final output sent to browser
DEBUG - 2016-05-08 09:28:07 --> Total execution time: 0.1671
INFO - 2016-05-08 09:28:17 --> Config Class Initialized
INFO - 2016-05-08 09:28:17 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:28:17 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:28:17 --> Utf8 Class Initialized
INFO - 2016-05-08 09:28:17 --> URI Class Initialized
INFO - 2016-05-08 09:28:17 --> Router Class Initialized
INFO - 2016-05-08 09:28:17 --> Output Class Initialized
INFO - 2016-05-08 09:28:17 --> Security Class Initialized
DEBUG - 2016-05-08 09:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:28:17 --> Input Class Initialized
INFO - 2016-05-08 09:28:17 --> Language Class Initialized
INFO - 2016-05-08 09:28:17 --> Loader Class Initialized
INFO - 2016-05-08 09:28:17 --> Helper loaded: url_helper
INFO - 2016-05-08 09:28:17 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:28:17 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:28:17 --> Helper loaded: form_helper
INFO - 2016-05-08 09:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:28:17 --> Form Validation Class Initialized
INFO - 2016-05-08 09:28:17 --> Controller Class Initialized
INFO - 2016-05-08 09:28:17 --> Model Class Initialized
INFO - 2016-05-08 09:28:17 --> Database Driver Class Initialized
INFO - 2016-05-08 09:28:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:28:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:28:17 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:28:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:28:17 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 09:28:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 09:28:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 09:28:17 --> Final output sent to browser
DEBUG - 2016-05-08 09:28:17 --> Total execution time: 0.0814
INFO - 2016-05-08 09:28:25 --> Config Class Initialized
INFO - 2016-05-08 09:28:25 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:28:25 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:28:25 --> Utf8 Class Initialized
INFO - 2016-05-08 09:28:25 --> URI Class Initialized
INFO - 2016-05-08 09:28:25 --> Router Class Initialized
INFO - 2016-05-08 09:28:25 --> Output Class Initialized
INFO - 2016-05-08 09:28:25 --> Security Class Initialized
DEBUG - 2016-05-08 09:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:28:25 --> Input Class Initialized
INFO - 2016-05-08 09:28:25 --> Language Class Initialized
INFO - 2016-05-08 09:28:25 --> Loader Class Initialized
INFO - 2016-05-08 09:28:25 --> Helper loaded: url_helper
INFO - 2016-05-08 09:28:25 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:28:25 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:28:25 --> Helper loaded: form_helper
INFO - 2016-05-08 09:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:28:25 --> Form Validation Class Initialized
INFO - 2016-05-08 09:28:25 --> Controller Class Initialized
INFO - 2016-05-08 09:28:25 --> Model Class Initialized
INFO - 2016-05-08 09:28:25 --> Database Driver Class Initialized
INFO - 2016-05-08 09:28:25 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:28:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:28:25 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:28:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:28:25 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 09:28:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 09:28:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 09:28:25 --> Final output sent to browser
DEBUG - 2016-05-08 09:28:25 --> Total execution time: 0.0814
INFO - 2016-05-08 09:28:44 --> Config Class Initialized
INFO - 2016-05-08 09:28:44 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:28:44 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:28:44 --> Utf8 Class Initialized
INFO - 2016-05-08 09:28:44 --> URI Class Initialized
INFO - 2016-05-08 09:28:44 --> Router Class Initialized
INFO - 2016-05-08 09:28:44 --> Output Class Initialized
INFO - 2016-05-08 09:28:44 --> Security Class Initialized
DEBUG - 2016-05-08 09:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:28:44 --> Input Class Initialized
INFO - 2016-05-08 09:28:44 --> Language Class Initialized
INFO - 2016-05-08 09:28:44 --> Loader Class Initialized
INFO - 2016-05-08 09:28:44 --> Helper loaded: url_helper
INFO - 2016-05-08 09:28:44 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:28:44 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:28:44 --> Helper loaded: form_helper
INFO - 2016-05-08 09:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:28:44 --> Form Validation Class Initialized
INFO - 2016-05-08 09:28:44 --> Controller Class Initialized
INFO - 2016-05-08 09:28:44 --> Model Class Initialized
INFO - 2016-05-08 09:28:44 --> Database Driver Class Initialized
INFO - 2016-05-08 09:28:44 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:28:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:28:44 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:28:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:28:44 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 09:28:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 09:28:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 09:28:44 --> Final output sent to browser
DEBUG - 2016-05-08 09:28:44 --> Total execution time: 0.0817
INFO - 2016-05-08 09:28:47 --> Config Class Initialized
INFO - 2016-05-08 09:28:47 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:28:47 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:28:47 --> Utf8 Class Initialized
INFO - 2016-05-08 09:28:47 --> URI Class Initialized
INFO - 2016-05-08 09:28:47 --> Router Class Initialized
INFO - 2016-05-08 09:28:47 --> Output Class Initialized
INFO - 2016-05-08 09:28:47 --> Security Class Initialized
DEBUG - 2016-05-08 09:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:28:47 --> Input Class Initialized
INFO - 2016-05-08 09:28:47 --> Language Class Initialized
INFO - 2016-05-08 09:28:47 --> Loader Class Initialized
INFO - 2016-05-08 09:28:47 --> Helper loaded: url_helper
INFO - 2016-05-08 09:28:47 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:28:47 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:28:47 --> Helper loaded: form_helper
INFO - 2016-05-08 09:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:28:47 --> Form Validation Class Initialized
INFO - 2016-05-08 09:28:47 --> Controller Class Initialized
INFO - 2016-05-08 09:28:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-08 09:28:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 09:28:47 --> Final output sent to browser
DEBUG - 2016-05-08 09:28:47 --> Total execution time: 0.0547
INFO - 2016-05-08 09:28:49 --> Config Class Initialized
INFO - 2016-05-08 09:28:49 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:28:49 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:28:49 --> Utf8 Class Initialized
INFO - 2016-05-08 09:28:49 --> URI Class Initialized
INFO - 2016-05-08 09:28:49 --> Router Class Initialized
INFO - 2016-05-08 09:28:49 --> Output Class Initialized
INFO - 2016-05-08 09:28:49 --> Security Class Initialized
DEBUG - 2016-05-08 09:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:28:49 --> Input Class Initialized
INFO - 2016-05-08 09:28:49 --> Language Class Initialized
INFO - 2016-05-08 09:28:49 --> Loader Class Initialized
INFO - 2016-05-08 09:28:49 --> Helper loaded: url_helper
INFO - 2016-05-08 09:28:49 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:28:49 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:28:49 --> Helper loaded: form_helper
INFO - 2016-05-08 09:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:28:49 --> Form Validation Class Initialized
INFO - 2016-05-08 09:28:49 --> Controller Class Initialized
INFO - 2016-05-08 09:28:49 --> Config Class Initialized
INFO - 2016-05-08 09:28:49 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:28:49 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:28:49 --> Utf8 Class Initialized
INFO - 2016-05-08 09:28:49 --> URI Class Initialized
INFO - 2016-05-08 09:28:49 --> Router Class Initialized
INFO - 2016-05-08 09:28:49 --> Output Class Initialized
INFO - 2016-05-08 09:28:49 --> Security Class Initialized
DEBUG - 2016-05-08 09:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:28:49 --> Input Class Initialized
INFO - 2016-05-08 09:28:49 --> Language Class Initialized
INFO - 2016-05-08 09:28:49 --> Loader Class Initialized
INFO - 2016-05-08 09:28:49 --> Helper loaded: url_helper
INFO - 2016-05-08 09:28:49 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:28:49 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:28:49 --> Helper loaded: form_helper
INFO - 2016-05-08 09:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:28:49 --> Form Validation Class Initialized
INFO - 2016-05-08 09:28:49 --> Controller Class Initialized
INFO - 2016-05-08 09:28:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-08 09:28:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 09:28:49 --> Final output sent to browser
DEBUG - 2016-05-08 09:28:49 --> Total execution time: 0.1266
INFO - 2016-05-08 09:28:53 --> Config Class Initialized
INFO - 2016-05-08 09:28:53 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:28:53 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:28:53 --> Utf8 Class Initialized
INFO - 2016-05-08 09:28:53 --> URI Class Initialized
INFO - 2016-05-08 09:28:53 --> Router Class Initialized
INFO - 2016-05-08 09:28:53 --> Output Class Initialized
INFO - 2016-05-08 09:28:53 --> Security Class Initialized
DEBUG - 2016-05-08 09:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:28:53 --> Input Class Initialized
INFO - 2016-05-08 09:28:53 --> Language Class Initialized
INFO - 2016-05-08 09:28:53 --> Loader Class Initialized
INFO - 2016-05-08 09:28:53 --> Helper loaded: url_helper
INFO - 2016-05-08 09:28:53 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:28:53 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:28:53 --> Helper loaded: form_helper
INFO - 2016-05-08 09:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:28:53 --> Form Validation Class Initialized
INFO - 2016-05-08 09:28:53 --> Controller Class Initialized
INFO - 2016-05-08 09:28:53 --> Model Class Initialized
INFO - 2016-05-08 09:28:53 --> Database Driver Class Initialized
INFO - 2016-05-08 09:28:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:28:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:28:53 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:28:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:28:53 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 09:28:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 09:28:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 09:28:53 --> Final output sent to browser
DEBUG - 2016-05-08 09:28:53 --> Total execution time: 0.0999
INFO - 2016-05-08 09:28:56 --> Config Class Initialized
INFO - 2016-05-08 09:28:56 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:28:56 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:28:56 --> Utf8 Class Initialized
INFO - 2016-05-08 09:28:56 --> URI Class Initialized
INFO - 2016-05-08 09:28:56 --> Router Class Initialized
INFO - 2016-05-08 09:28:56 --> Output Class Initialized
INFO - 2016-05-08 09:28:56 --> Security Class Initialized
DEBUG - 2016-05-08 09:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:28:56 --> Input Class Initialized
INFO - 2016-05-08 09:28:56 --> Language Class Initialized
INFO - 2016-05-08 09:28:56 --> Loader Class Initialized
INFO - 2016-05-08 09:28:56 --> Helper loaded: url_helper
INFO - 2016-05-08 09:28:56 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:28:56 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:28:56 --> Helper loaded: form_helper
INFO - 2016-05-08 09:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:28:56 --> Form Validation Class Initialized
INFO - 2016-05-08 09:28:56 --> Controller Class Initialized
INFO - 2016-05-08 09:28:56 --> Model Class Initialized
INFO - 2016-05-08 09:28:56 --> Database Driver Class Initialized
INFO - 2016-05-08 09:28:56 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:28:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:28:56 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:28:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:28:56 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 09:28:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 09:28:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 09:28:56 --> Final output sent to browser
DEBUG - 2016-05-08 09:28:56 --> Total execution time: 0.0803
INFO - 2016-05-08 09:30:17 --> Config Class Initialized
INFO - 2016-05-08 09:30:17 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:30:17 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:30:17 --> Utf8 Class Initialized
INFO - 2016-05-08 09:30:17 --> URI Class Initialized
INFO - 2016-05-08 09:30:17 --> Router Class Initialized
INFO - 2016-05-08 09:30:17 --> Output Class Initialized
INFO - 2016-05-08 09:30:17 --> Security Class Initialized
DEBUG - 2016-05-08 09:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:30:17 --> Input Class Initialized
INFO - 2016-05-08 09:30:17 --> Language Class Initialized
INFO - 2016-05-08 09:30:17 --> Loader Class Initialized
INFO - 2016-05-08 09:30:17 --> Helper loaded: url_helper
INFO - 2016-05-08 09:30:17 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:30:17 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:30:17 --> Helper loaded: form_helper
INFO - 2016-05-08 09:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:30:17 --> Form Validation Class Initialized
INFO - 2016-05-08 09:30:17 --> Controller Class Initialized
INFO - 2016-05-08 09:30:17 --> Model Class Initialized
INFO - 2016-05-08 09:30:17 --> Database Driver Class Initialized
INFO - 2016-05-08 09:30:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:30:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:30:17 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:30:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:30:17 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 09:30:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) 'cont' FROM proveedor prove INNER JOIN provincia provi ON provi.idProvincia=p' at line 1 - Invalid query: SELECT count(prove.*) 'cont' FROM proveedor prove INNER JOIN provincia provi ON provi.idProvincia=prove.idProvincia WHERE prove.nombre LIKE '%madrid%' OR prove.nif LIKE '%madrid%' OR prove.correo LIKE '%madrid%' OR prove.telefono LIKE '%madrid%' OR prove.direccion LIKE '%madrid%' OR prove.localidad LIKE '%madrid%' OR prove.cp LIKE '%madrid%' OR prove.anotaciones LIKE '%madrid%' OR prove.estado LIKE '%madrid%' OR provi.nombre LIKE '%madrid%'
INFO - 2016-05-08 09:30:17 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-08 09:30:35 --> Config Class Initialized
INFO - 2016-05-08 09:30:35 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:30:35 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:30:35 --> Utf8 Class Initialized
INFO - 2016-05-08 09:30:35 --> URI Class Initialized
INFO - 2016-05-08 09:30:35 --> Router Class Initialized
INFO - 2016-05-08 09:30:35 --> Output Class Initialized
INFO - 2016-05-08 09:30:35 --> Security Class Initialized
DEBUG - 2016-05-08 09:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:30:35 --> Input Class Initialized
INFO - 2016-05-08 09:30:35 --> Language Class Initialized
INFO - 2016-05-08 09:30:35 --> Loader Class Initialized
INFO - 2016-05-08 09:30:35 --> Helper loaded: url_helper
INFO - 2016-05-08 09:30:35 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:30:35 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:30:35 --> Helper loaded: form_helper
INFO - 2016-05-08 09:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:30:35 --> Form Validation Class Initialized
INFO - 2016-05-08 09:30:35 --> Controller Class Initialized
INFO - 2016-05-08 09:30:35 --> Model Class Initialized
INFO - 2016-05-08 09:30:35 --> Database Driver Class Initialized
INFO - 2016-05-08 09:30:35 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:30:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:30:35 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:30:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:30:35 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 09:30:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) 'cont' FROM proveedor prove INNER JOIN provincia provi ON provi.idProvincia=p' at line 1 - Invalid query: SELECT count(prove.*) 'cont' FROM proveedor prove INNER JOIN provincia provi ON provi.idProvincia=prove.idProvincia WHERE prove.nombre LIKE '%madrid%' OR prove.nif LIKE '%madrid%' OR prove.correo LIKE '%madrid%' OR prove.telefono LIKE '%madrid%' OR prove.direccion LIKE '%madrid%' OR prove.localidad LIKE '%madrid%' OR prove.cp LIKE '%madrid%' OR prove.anotaciones LIKE '%madrid%' OR prove.estado LIKE '%madrid%' OR provi.nombre LIKE '%madrid%'
INFO - 2016-05-08 09:30:35 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-08 09:31:39 --> Config Class Initialized
INFO - 2016-05-08 09:31:39 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:31:39 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:31:39 --> Utf8 Class Initialized
INFO - 2016-05-08 09:31:39 --> URI Class Initialized
INFO - 2016-05-08 09:31:39 --> Router Class Initialized
INFO - 2016-05-08 09:31:39 --> Output Class Initialized
INFO - 2016-05-08 09:31:39 --> Security Class Initialized
DEBUG - 2016-05-08 09:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:31:39 --> Input Class Initialized
INFO - 2016-05-08 09:31:39 --> Language Class Initialized
INFO - 2016-05-08 09:31:39 --> Loader Class Initialized
INFO - 2016-05-08 09:31:39 --> Helper loaded: url_helper
INFO - 2016-05-08 09:31:39 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:31:39 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:31:39 --> Helper loaded: form_helper
INFO - 2016-05-08 09:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:31:39 --> Form Validation Class Initialized
INFO - 2016-05-08 09:31:39 --> Controller Class Initialized
INFO - 2016-05-08 09:31:39 --> Model Class Initialized
INFO - 2016-05-08 09:31:39 --> Database Driver Class Initialized
INFO - 2016-05-08 09:31:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:31:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:31:39 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:31:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:31:39 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 09:31:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) 'cont' FROM proveedor prove INNER JOIN provincia provi ON provi.idProvincia=p' at line 1 - Invalid query: SELECT count(prove.*) 'cont' FROM proveedor prove INNER JOIN provincia provi ON provi.idProvincia=prove.idProvincia WHERE prove.nombre LIKE '%madrid%' OR prove.nif LIKE '%madrid%' OR prove.correo LIKE '%madrid%' OR prove.telefono LIKE '%madrid%' OR prove.direccion LIKE '%madrid%' OR prove.localidad LIKE '%madrid%' OR prove.cp LIKE '%madrid%' OR prove.anotaciones LIKE '%madrid%' OR prove.estado LIKE '%madrid%' OR provi.nombre LIKE '%madrid%'
INFO - 2016-05-08 09:31:39 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-08 09:31:40 --> Config Class Initialized
INFO - 2016-05-08 09:31:40 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:31:40 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:31:40 --> Utf8 Class Initialized
INFO - 2016-05-08 09:31:40 --> URI Class Initialized
INFO - 2016-05-08 09:31:40 --> Router Class Initialized
INFO - 2016-05-08 09:31:40 --> Output Class Initialized
INFO - 2016-05-08 09:31:40 --> Security Class Initialized
DEBUG - 2016-05-08 09:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:31:40 --> Input Class Initialized
INFO - 2016-05-08 09:31:40 --> Language Class Initialized
INFO - 2016-05-08 09:31:40 --> Loader Class Initialized
INFO - 2016-05-08 09:31:40 --> Helper loaded: url_helper
INFO - 2016-05-08 09:31:40 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:31:40 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:31:40 --> Helper loaded: form_helper
INFO - 2016-05-08 09:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:31:40 --> Form Validation Class Initialized
INFO - 2016-05-08 09:31:40 --> Controller Class Initialized
INFO - 2016-05-08 09:31:40 --> Model Class Initialized
INFO - 2016-05-08 09:31:40 --> Database Driver Class Initialized
INFO - 2016-05-08 09:31:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:31:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:31:40 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:31:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:31:40 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 09:31:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) 'cont' FROM proveedor prove INNER JOIN provincia provi ON provi.idProvincia=p' at line 1 - Invalid query: SELECT count(prove.*) 'cont' FROM proveedor prove INNER JOIN provincia provi ON provi.idProvincia=prove.idProvincia WHERE prove.nombre LIKE '%madrid%' OR prove.nif LIKE '%madrid%' OR prove.correo LIKE '%madrid%' OR prove.telefono LIKE '%madrid%' OR prove.direccion LIKE '%madrid%' OR prove.localidad LIKE '%madrid%' OR prove.cp LIKE '%madrid%' OR prove.anotaciones LIKE '%madrid%' OR prove.estado LIKE '%madrid%' OR provi.nombre LIKE '%madrid%'
INFO - 2016-05-08 09:31:40 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-08 09:31:40 --> Config Class Initialized
INFO - 2016-05-08 09:31:40 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:31:41 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:31:41 --> Utf8 Class Initialized
INFO - 2016-05-08 09:31:41 --> URI Class Initialized
INFO - 2016-05-08 09:31:41 --> Router Class Initialized
INFO - 2016-05-08 09:31:41 --> Output Class Initialized
INFO - 2016-05-08 09:31:41 --> Security Class Initialized
DEBUG - 2016-05-08 09:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:31:41 --> Input Class Initialized
INFO - 2016-05-08 09:31:41 --> Language Class Initialized
INFO - 2016-05-08 09:31:41 --> Loader Class Initialized
INFO - 2016-05-08 09:31:41 --> Helper loaded: url_helper
INFO - 2016-05-08 09:31:41 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:31:41 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:31:41 --> Helper loaded: form_helper
INFO - 2016-05-08 09:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:31:41 --> Form Validation Class Initialized
INFO - 2016-05-08 09:31:41 --> Controller Class Initialized
INFO - 2016-05-08 09:31:41 --> Model Class Initialized
INFO - 2016-05-08 09:31:41 --> Database Driver Class Initialized
INFO - 2016-05-08 09:31:41 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:31:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:31:41 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:31:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:31:41 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 09:31:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) 'cont' FROM proveedor prove INNER JOIN provincia provi ON provi.idProvincia=p' at line 1 - Invalid query: SELECT count(prove.*) 'cont' FROM proveedor prove INNER JOIN provincia provi ON provi.idProvincia=prove.idProvincia WHERE prove.nombre LIKE '%madrid%' OR prove.nif LIKE '%madrid%' OR prove.correo LIKE '%madrid%' OR prove.telefono LIKE '%madrid%' OR prove.direccion LIKE '%madrid%' OR prove.localidad LIKE '%madrid%' OR prove.cp LIKE '%madrid%' OR prove.anotaciones LIKE '%madrid%' OR prove.estado LIKE '%madrid%' OR provi.nombre LIKE '%madrid%'
INFO - 2016-05-08 09:31:41 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-08 09:32:04 --> Config Class Initialized
INFO - 2016-05-08 09:32:04 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:32:04 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:32:04 --> Utf8 Class Initialized
INFO - 2016-05-08 09:32:04 --> URI Class Initialized
INFO - 2016-05-08 09:32:04 --> Router Class Initialized
INFO - 2016-05-08 09:32:04 --> Output Class Initialized
INFO - 2016-05-08 09:32:04 --> Security Class Initialized
DEBUG - 2016-05-08 09:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:32:04 --> Input Class Initialized
INFO - 2016-05-08 09:32:04 --> Language Class Initialized
INFO - 2016-05-08 09:32:04 --> Loader Class Initialized
INFO - 2016-05-08 09:32:04 --> Helper loaded: url_helper
INFO - 2016-05-08 09:32:04 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:32:04 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:32:04 --> Helper loaded: form_helper
INFO - 2016-05-08 09:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:32:04 --> Form Validation Class Initialized
INFO - 2016-05-08 09:32:04 --> Controller Class Initialized
INFO - 2016-05-08 09:32:04 --> Model Class Initialized
INFO - 2016-05-08 09:32:04 --> Database Driver Class Initialized
INFO - 2016-05-08 09:32:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:32:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:32:04 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:32:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:32:04 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 09:32:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*) 'cont' FROM proveedor prove INNER JOIN provincia provi ON provi.idProvincia=p' at line 1 - Invalid query: SELECT count(prove.*) 'cont' FROM proveedor prove INNER JOIN provincia provi ON provi.idProvincia=prove.idProvincia WHERE prove.nombre LIKE '%madrid%' OR prove.nif LIKE '%madrid%' OR prove.correo LIKE '%madrid%' OR prove.telefono LIKE '%madrid%' OR prove.direccion LIKE '%madrid%' OR prove.localidad LIKE '%madrid%' OR prove.cp LIKE '%madrid%' OR prove.anotaciones LIKE '%madrid%' OR prove.estado LIKE '%madrid%' OR provi.nombre LIKE '%madrid%'
INFO - 2016-05-08 09:32:04 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-08 09:33:09 --> Config Class Initialized
INFO - 2016-05-08 09:33:09 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:33:09 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:33:09 --> Utf8 Class Initialized
INFO - 2016-05-08 09:33:09 --> URI Class Initialized
INFO - 2016-05-08 09:33:09 --> Router Class Initialized
INFO - 2016-05-08 09:33:09 --> Output Class Initialized
INFO - 2016-05-08 09:33:09 --> Security Class Initialized
DEBUG - 2016-05-08 09:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:33:09 --> Input Class Initialized
INFO - 2016-05-08 09:33:09 --> Language Class Initialized
INFO - 2016-05-08 09:33:09 --> Loader Class Initialized
INFO - 2016-05-08 09:33:09 --> Helper loaded: url_helper
INFO - 2016-05-08 09:33:09 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:33:09 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:33:09 --> Helper loaded: form_helper
INFO - 2016-05-08 09:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:33:09 --> Form Validation Class Initialized
INFO - 2016-05-08 09:33:09 --> Controller Class Initialized
INFO - 2016-05-08 09:33:09 --> Model Class Initialized
INFO - 2016-05-08 09:33:09 --> Database Driver Class Initialized
INFO - 2016-05-08 09:33:09 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:33:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:33:09 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:33:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:33:09 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 09:33:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 09:33:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 09:33:09 --> Final output sent to browser
DEBUG - 2016-05-08 09:33:09 --> Total execution time: 0.1681
INFO - 2016-05-08 09:33:15 --> Config Class Initialized
INFO - 2016-05-08 09:33:15 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:33:15 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:33:15 --> Utf8 Class Initialized
INFO - 2016-05-08 09:33:15 --> URI Class Initialized
INFO - 2016-05-08 09:33:15 --> Router Class Initialized
INFO - 2016-05-08 09:33:15 --> Output Class Initialized
INFO - 2016-05-08 09:33:15 --> Security Class Initialized
DEBUG - 2016-05-08 09:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:33:15 --> Input Class Initialized
INFO - 2016-05-08 09:33:15 --> Language Class Initialized
INFO - 2016-05-08 09:33:15 --> Loader Class Initialized
INFO - 2016-05-08 09:33:15 --> Helper loaded: url_helper
INFO - 2016-05-08 09:33:15 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:33:15 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:33:15 --> Helper loaded: form_helper
INFO - 2016-05-08 09:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:33:15 --> Form Validation Class Initialized
INFO - 2016-05-08 09:33:15 --> Controller Class Initialized
INFO - 2016-05-08 09:33:15 --> Model Class Initialized
INFO - 2016-05-08 09:33:15 --> Database Driver Class Initialized
INFO - 2016-05-08 09:33:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:33:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:33:15 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:33:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:33:15 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 09:33:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 09:33:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 09:33:15 --> Final output sent to browser
DEBUG - 2016-05-08 09:33:15 --> Total execution time: 0.0917
INFO - 2016-05-08 09:33:19 --> Config Class Initialized
INFO - 2016-05-08 09:33:19 --> Hooks Class Initialized
DEBUG - 2016-05-08 09:33:19 --> UTF-8 Support Enabled
INFO - 2016-05-08 09:33:19 --> Utf8 Class Initialized
INFO - 2016-05-08 09:33:19 --> URI Class Initialized
INFO - 2016-05-08 09:33:19 --> Router Class Initialized
INFO - 2016-05-08 09:33:19 --> Output Class Initialized
INFO - 2016-05-08 09:33:19 --> Security Class Initialized
DEBUG - 2016-05-08 09:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 09:33:19 --> Input Class Initialized
INFO - 2016-05-08 09:33:19 --> Language Class Initialized
INFO - 2016-05-08 09:33:19 --> Loader Class Initialized
INFO - 2016-05-08 09:33:19 --> Helper loaded: url_helper
INFO - 2016-05-08 09:33:19 --> Helper loaded: sesion_helper
INFO - 2016-05-08 09:33:19 --> Helper loaded: templates_helper
INFO - 2016-05-08 09:33:19 --> Helper loaded: form_helper
INFO - 2016-05-08 09:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 09:33:19 --> Form Validation Class Initialized
INFO - 2016-05-08 09:33:19 --> Controller Class Initialized
INFO - 2016-05-08 09:33:19 --> Model Class Initialized
INFO - 2016-05-08 09:33:19 --> Database Driver Class Initialized
INFO - 2016-05-08 09:33:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 09:33:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 09:33:19 --> Pagination Class Initialized
DEBUG - 2016-05-08 09:33:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 09:33:19 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 09:33:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 09:33:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 09:33:19 --> Final output sent to browser
DEBUG - 2016-05-08 09:33:19 --> Total execution time: 0.0781
INFO - 2016-05-08 10:34:47 --> Config Class Initialized
INFO - 2016-05-08 10:34:47 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:34:47 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:34:47 --> Utf8 Class Initialized
INFO - 2016-05-08 10:34:47 --> URI Class Initialized
INFO - 2016-05-08 10:34:47 --> Router Class Initialized
INFO - 2016-05-08 10:34:47 --> Output Class Initialized
INFO - 2016-05-08 10:34:47 --> Security Class Initialized
DEBUG - 2016-05-08 10:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:34:47 --> Input Class Initialized
INFO - 2016-05-08 10:34:47 --> Language Class Initialized
INFO - 2016-05-08 10:34:47 --> Loader Class Initialized
INFO - 2016-05-08 10:34:47 --> Helper loaded: url_helper
INFO - 2016-05-08 10:34:47 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:34:47 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:34:47 --> Helper loaded: form_helper
INFO - 2016-05-08 10:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:34:48 --> Form Validation Class Initialized
INFO - 2016-05-08 10:34:48 --> Controller Class Initialized
INFO - 2016-05-08 10:34:48 --> Model Class Initialized
INFO - 2016-05-08 10:34:48 --> Database Driver Class Initialized
INFO - 2016-05-08 10:34:48 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:34:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:34:48 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:34:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:34:48 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 10:34:48 --> Query error: Unknown column 'sestado' in 'field list' - Invalid query: SELECT nombre, nif, tipo, anotaciones, sestado FROM cliente ORDER BY nombre LIMIT 0, 5; 
INFO - 2016-05-08 10:34:48 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-08 10:35:00 --> Config Class Initialized
INFO - 2016-05-08 10:35:00 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:35:00 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:35:00 --> Utf8 Class Initialized
INFO - 2016-05-08 10:35:00 --> URI Class Initialized
INFO - 2016-05-08 10:35:00 --> Router Class Initialized
INFO - 2016-05-08 10:35:00 --> Output Class Initialized
INFO - 2016-05-08 10:35:00 --> Security Class Initialized
DEBUG - 2016-05-08 10:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:35:00 --> Input Class Initialized
INFO - 2016-05-08 10:35:00 --> Language Class Initialized
INFO - 2016-05-08 10:35:00 --> Loader Class Initialized
INFO - 2016-05-08 10:35:00 --> Helper loaded: url_helper
INFO - 2016-05-08 10:35:00 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:35:00 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:35:00 --> Helper loaded: form_helper
INFO - 2016-05-08 10:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:35:00 --> Form Validation Class Initialized
INFO - 2016-05-08 10:35:00 --> Controller Class Initialized
INFO - 2016-05-08 10:35:00 --> Model Class Initialized
INFO - 2016-05-08 10:35:00 --> Database Driver Class Initialized
INFO - 2016-05-08 10:35:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:35:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:35:00 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:35:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:35:00 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 10:35:00 --> Severity: Notice --> Undefined index: idCliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php 49
ERROR - 2016-05-08 10:35:00 --> Severity: Notice --> Undefined index: idCliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php 50
ERROR - 2016-05-08 10:35:00 --> Severity: Notice --> Undefined index: idCliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php 54
ERROR - 2016-05-08 10:35:00 --> Severity: Notice --> Undefined index: idCliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php 57
ERROR - 2016-05-08 10:35:00 --> Severity: Notice --> Undefined index: idCliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php 72
ERROR - 2016-05-08 10:35:00 --> Severity: Notice --> Undefined index: idCliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php 49
ERROR - 2016-05-08 10:35:00 --> Severity: Notice --> Undefined index: idCliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php 50
ERROR - 2016-05-08 10:35:00 --> Severity: Notice --> Undefined index: idCliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php 54
ERROR - 2016-05-08 10:35:00 --> Severity: Notice --> Undefined index: idCliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php 57
ERROR - 2016-05-08 10:35:00 --> Severity: Notice --> Undefined index: idCliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php 72
INFO - 2016-05-08 10:35:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 10:35:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:35:00 --> Final output sent to browser
DEBUG - 2016-05-08 10:35:00 --> Total execution time: 0.3653
INFO - 2016-05-08 10:35:51 --> Config Class Initialized
INFO - 2016-05-08 10:35:51 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:35:51 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:35:51 --> Utf8 Class Initialized
INFO - 2016-05-08 10:35:51 --> URI Class Initialized
INFO - 2016-05-08 10:35:51 --> Router Class Initialized
INFO - 2016-05-08 10:35:51 --> Output Class Initialized
INFO - 2016-05-08 10:35:51 --> Security Class Initialized
DEBUG - 2016-05-08 10:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:35:51 --> Input Class Initialized
INFO - 2016-05-08 10:35:51 --> Language Class Initialized
INFO - 2016-05-08 10:35:51 --> Loader Class Initialized
INFO - 2016-05-08 10:35:51 --> Helper loaded: url_helper
INFO - 2016-05-08 10:35:51 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:35:51 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:35:51 --> Helper loaded: form_helper
INFO - 2016-05-08 10:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:35:51 --> Form Validation Class Initialized
INFO - 2016-05-08 10:35:51 --> Controller Class Initialized
INFO - 2016-05-08 10:35:51 --> Model Class Initialized
INFO - 2016-05-08 10:35:51 --> Database Driver Class Initialized
INFO - 2016-05-08 10:35:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:35:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:35:51 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:35:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:35:51 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:35:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 10:35:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:35:51 --> Final output sent to browser
DEBUG - 2016-05-08 10:35:51 --> Total execution time: 0.0884
INFO - 2016-05-08 10:36:44 --> Config Class Initialized
INFO - 2016-05-08 10:36:44 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:36:44 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:36:44 --> Utf8 Class Initialized
INFO - 2016-05-08 10:36:44 --> URI Class Initialized
INFO - 2016-05-08 10:36:44 --> Router Class Initialized
INFO - 2016-05-08 10:36:44 --> Output Class Initialized
INFO - 2016-05-08 10:36:44 --> Security Class Initialized
DEBUG - 2016-05-08 10:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:36:44 --> Input Class Initialized
INFO - 2016-05-08 10:36:44 --> Language Class Initialized
INFO - 2016-05-08 10:36:44 --> Loader Class Initialized
INFO - 2016-05-08 10:36:44 --> Helper loaded: url_helper
INFO - 2016-05-08 10:36:44 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:36:44 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:36:45 --> Helper loaded: form_helper
INFO - 2016-05-08 10:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:36:45 --> Form Validation Class Initialized
INFO - 2016-05-08 10:36:45 --> Controller Class Initialized
INFO - 2016-05-08 10:36:45 --> Model Class Initialized
INFO - 2016-05-08 10:36:45 --> Database Driver Class Initialized
INFO - 2016-05-08 10:36:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:36:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:36:45 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:36:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:36:45 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:36:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 10:36:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:36:45 --> Final output sent to browser
DEBUG - 2016-05-08 10:36:45 --> Total execution time: 0.0831
INFO - 2016-05-08 10:36:50 --> Config Class Initialized
INFO - 2016-05-08 10:36:50 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:36:50 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:36:50 --> Utf8 Class Initialized
INFO - 2016-05-08 10:36:50 --> URI Class Initialized
INFO - 2016-05-08 10:36:50 --> Router Class Initialized
INFO - 2016-05-08 10:36:50 --> Output Class Initialized
INFO - 2016-05-08 10:36:50 --> Security Class Initialized
DEBUG - 2016-05-08 10:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:36:50 --> Input Class Initialized
INFO - 2016-05-08 10:36:50 --> Language Class Initialized
INFO - 2016-05-08 10:36:50 --> Loader Class Initialized
INFO - 2016-05-08 10:36:50 --> Helper loaded: url_helper
INFO - 2016-05-08 10:36:50 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:36:50 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:36:50 --> Helper loaded: form_helper
INFO - 2016-05-08 10:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:36:50 --> Form Validation Class Initialized
INFO - 2016-05-08 10:36:50 --> Controller Class Initialized
INFO - 2016-05-08 10:36:50 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:36:50 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:36:50 --> Model Class Initialized
INFO - 2016-05-08 10:36:50 --> Database Driver Class Initialized
INFO - 2016-05-08 10:36:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-05-08 10:36:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:36:50 --> Final output sent to browser
DEBUG - 2016-05-08 10:36:50 --> Total execution time: 0.1350
INFO - 2016-05-08 10:37:44 --> Config Class Initialized
INFO - 2016-05-08 10:37:44 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:37:44 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:37:44 --> Utf8 Class Initialized
INFO - 2016-05-08 10:37:44 --> URI Class Initialized
INFO - 2016-05-08 10:37:44 --> Router Class Initialized
INFO - 2016-05-08 10:37:44 --> Output Class Initialized
INFO - 2016-05-08 10:37:44 --> Security Class Initialized
DEBUG - 2016-05-08 10:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:37:44 --> Input Class Initialized
INFO - 2016-05-08 10:37:44 --> Language Class Initialized
INFO - 2016-05-08 10:37:44 --> Loader Class Initialized
INFO - 2016-05-08 10:37:45 --> Helper loaded: url_helper
INFO - 2016-05-08 10:37:45 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:37:45 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:37:45 --> Helper loaded: form_helper
INFO - 2016-05-08 10:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:37:45 --> Form Validation Class Initialized
INFO - 2016-05-08 10:37:45 --> Controller Class Initialized
INFO - 2016-05-08 10:37:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:37:45 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:37:45 --> Model Class Initialized
INFO - 2016-05-08 10:37:45 --> Database Driver Class Initialized
INFO - 2016-05-08 10:37:45 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 10:37:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-05-08 10:37:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:37:45 --> Final output sent to browser
DEBUG - 2016-05-08 10:37:45 --> Total execution time: 0.4814
INFO - 2016-05-08 10:41:30 --> Config Class Initialized
INFO - 2016-05-08 10:41:30 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:41:30 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:41:30 --> Utf8 Class Initialized
INFO - 2016-05-08 10:41:30 --> URI Class Initialized
INFO - 2016-05-08 10:41:30 --> Router Class Initialized
INFO - 2016-05-08 10:41:30 --> Output Class Initialized
INFO - 2016-05-08 10:41:30 --> Security Class Initialized
DEBUG - 2016-05-08 10:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:41:30 --> Input Class Initialized
INFO - 2016-05-08 10:41:30 --> Language Class Initialized
INFO - 2016-05-08 10:41:30 --> Loader Class Initialized
INFO - 2016-05-08 10:41:30 --> Helper loaded: url_helper
INFO - 2016-05-08 10:41:30 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:41:30 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:41:30 --> Helper loaded: form_helper
INFO - 2016-05-08 10:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:41:30 --> Form Validation Class Initialized
INFO - 2016-05-08 10:41:30 --> Controller Class Initialized
INFO - 2016-05-08 10:41:30 --> Model Class Initialized
INFO - 2016-05-08 10:41:30 --> Database Driver Class Initialized
INFO - 2016-05-08 10:41:30 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:41:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:41:30 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:41:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:41:30 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:41:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 10:41:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:41:30 --> Final output sent to browser
DEBUG - 2016-05-08 10:41:30 --> Total execution time: 0.1113
INFO - 2016-05-08 10:41:45 --> Config Class Initialized
INFO - 2016-05-08 10:41:45 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:41:46 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:41:46 --> Utf8 Class Initialized
INFO - 2016-05-08 10:41:46 --> URI Class Initialized
INFO - 2016-05-08 10:41:46 --> Router Class Initialized
INFO - 2016-05-08 10:41:46 --> Output Class Initialized
INFO - 2016-05-08 10:41:46 --> Security Class Initialized
DEBUG - 2016-05-08 10:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:41:46 --> Input Class Initialized
INFO - 2016-05-08 10:41:46 --> Language Class Initialized
INFO - 2016-05-08 10:41:46 --> Loader Class Initialized
INFO - 2016-05-08 10:41:46 --> Helper loaded: url_helper
INFO - 2016-05-08 10:41:46 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:41:46 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:41:46 --> Helper loaded: form_helper
INFO - 2016-05-08 10:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:41:46 --> Form Validation Class Initialized
INFO - 2016-05-08 10:41:46 --> Controller Class Initialized
INFO - 2016-05-08 10:41:46 --> Model Class Initialized
INFO - 2016-05-08 10:41:46 --> Database Driver Class Initialized
INFO - 2016-05-08 10:41:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:41:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:41:46 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:41:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:41:46 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:41:46 --> Config Class Initialized
INFO - 2016-05-08 10:41:46 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:41:46 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:41:46 --> Utf8 Class Initialized
INFO - 2016-05-08 10:41:46 --> URI Class Initialized
INFO - 2016-05-08 10:41:46 --> Router Class Initialized
INFO - 2016-05-08 10:41:46 --> Output Class Initialized
INFO - 2016-05-08 10:41:46 --> Security Class Initialized
DEBUG - 2016-05-08 10:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:41:46 --> Input Class Initialized
INFO - 2016-05-08 10:41:46 --> Language Class Initialized
INFO - 2016-05-08 10:41:46 --> Loader Class Initialized
INFO - 2016-05-08 10:41:46 --> Helper loaded: url_helper
INFO - 2016-05-08 10:41:46 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:41:46 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:41:46 --> Helper loaded: form_helper
INFO - 2016-05-08 10:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:41:46 --> Form Validation Class Initialized
INFO - 2016-05-08 10:41:46 --> Controller Class Initialized
INFO - 2016-05-08 10:41:46 --> Model Class Initialized
INFO - 2016-05-08 10:41:46 --> Database Driver Class Initialized
INFO - 2016-05-08 10:41:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:41:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:41:46 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:41:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:41:46 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:41:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 10:41:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:41:46 --> Final output sent to browser
DEBUG - 2016-05-08 10:41:46 --> Total execution time: 0.0899
INFO - 2016-05-08 10:41:52 --> Config Class Initialized
INFO - 2016-05-08 10:41:52 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:41:52 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:41:52 --> Utf8 Class Initialized
INFO - 2016-05-08 10:41:52 --> URI Class Initialized
INFO - 2016-05-08 10:41:52 --> Router Class Initialized
INFO - 2016-05-08 10:41:52 --> Output Class Initialized
INFO - 2016-05-08 10:41:52 --> Security Class Initialized
DEBUG - 2016-05-08 10:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:41:52 --> Input Class Initialized
INFO - 2016-05-08 10:41:52 --> Language Class Initialized
INFO - 2016-05-08 10:41:52 --> Loader Class Initialized
INFO - 2016-05-08 10:41:52 --> Helper loaded: url_helper
INFO - 2016-05-08 10:41:52 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:41:52 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:41:52 --> Helper loaded: form_helper
INFO - 2016-05-08 10:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:41:52 --> Form Validation Class Initialized
INFO - 2016-05-08 10:41:52 --> Controller Class Initialized
INFO - 2016-05-08 10:41:52 --> Model Class Initialized
INFO - 2016-05-08 10:41:52 --> Database Driver Class Initialized
INFO - 2016-05-08 10:41:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:41:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:41:52 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:41:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:41:52 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:41:52 --> Config Class Initialized
INFO - 2016-05-08 10:41:52 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:41:52 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:41:52 --> Utf8 Class Initialized
INFO - 2016-05-08 10:41:52 --> URI Class Initialized
INFO - 2016-05-08 10:41:52 --> Router Class Initialized
INFO - 2016-05-08 10:41:52 --> Output Class Initialized
INFO - 2016-05-08 10:41:52 --> Security Class Initialized
DEBUG - 2016-05-08 10:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:41:52 --> Input Class Initialized
INFO - 2016-05-08 10:41:52 --> Language Class Initialized
INFO - 2016-05-08 10:41:52 --> Loader Class Initialized
INFO - 2016-05-08 10:41:52 --> Helper loaded: url_helper
INFO - 2016-05-08 10:41:52 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:41:52 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:41:52 --> Helper loaded: form_helper
INFO - 2016-05-08 10:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:41:52 --> Form Validation Class Initialized
INFO - 2016-05-08 10:41:52 --> Controller Class Initialized
INFO - 2016-05-08 10:41:52 --> Model Class Initialized
INFO - 2016-05-08 10:41:52 --> Database Driver Class Initialized
INFO - 2016-05-08 10:41:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:41:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:41:52 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:41:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:41:52 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:41:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 10:41:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:41:52 --> Final output sent to browser
DEBUG - 2016-05-08 10:41:52 --> Total execution time: 0.0827
INFO - 2016-05-08 10:42:19 --> Config Class Initialized
INFO - 2016-05-08 10:42:19 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:42:19 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:42:19 --> Utf8 Class Initialized
INFO - 2016-05-08 10:42:19 --> URI Class Initialized
INFO - 2016-05-08 10:42:19 --> Router Class Initialized
INFO - 2016-05-08 10:42:19 --> Output Class Initialized
INFO - 2016-05-08 10:42:19 --> Security Class Initialized
DEBUG - 2016-05-08 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:42:19 --> Input Class Initialized
INFO - 2016-05-08 10:42:19 --> Language Class Initialized
INFO - 2016-05-08 10:42:19 --> Loader Class Initialized
INFO - 2016-05-08 10:42:19 --> Helper loaded: url_helper
INFO - 2016-05-08 10:42:19 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:42:19 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:42:19 --> Helper loaded: form_helper
INFO - 2016-05-08 10:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:42:19 --> Form Validation Class Initialized
INFO - 2016-05-08 10:42:19 --> Controller Class Initialized
INFO - 2016-05-08 10:42:19 --> Model Class Initialized
INFO - 2016-05-08 10:42:19 --> Database Driver Class Initialized
INFO - 2016-05-08 10:42:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:42:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:42:19 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:42:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:42:19 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:42:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 10:42:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:42:19 --> Final output sent to browser
DEBUG - 2016-05-08 10:42:19 --> Total execution time: 0.1062
INFO - 2016-05-08 10:42:21 --> Config Class Initialized
INFO - 2016-05-08 10:42:21 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:42:21 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:42:21 --> Utf8 Class Initialized
INFO - 2016-05-08 10:42:21 --> URI Class Initialized
INFO - 2016-05-08 10:42:21 --> Router Class Initialized
INFO - 2016-05-08 10:42:21 --> Output Class Initialized
INFO - 2016-05-08 10:42:21 --> Security Class Initialized
DEBUG - 2016-05-08 10:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:42:21 --> Input Class Initialized
INFO - 2016-05-08 10:42:21 --> Language Class Initialized
INFO - 2016-05-08 10:42:21 --> Loader Class Initialized
INFO - 2016-05-08 10:42:21 --> Helper loaded: url_helper
INFO - 2016-05-08 10:42:21 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:42:21 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:42:21 --> Helper loaded: form_helper
INFO - 2016-05-08 10:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:42:21 --> Form Validation Class Initialized
INFO - 2016-05-08 10:42:21 --> Controller Class Initialized
INFO - 2016-05-08 10:42:21 --> Model Class Initialized
INFO - 2016-05-08 10:42:21 --> Database Driver Class Initialized
INFO - 2016-05-08 10:42:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:42:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:42:21 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:42:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:42:21 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:42:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProveedor.php
INFO - 2016-05-08 10:42:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:42:21 --> Final output sent to browser
DEBUG - 2016-05-08 10:42:21 --> Total execution time: 0.1287
INFO - 2016-05-08 10:42:23 --> Config Class Initialized
INFO - 2016-05-08 10:42:23 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:42:23 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:42:23 --> Utf8 Class Initialized
INFO - 2016-05-08 10:42:23 --> URI Class Initialized
INFO - 2016-05-08 10:42:23 --> Router Class Initialized
INFO - 2016-05-08 10:42:23 --> Output Class Initialized
INFO - 2016-05-08 10:42:23 --> Security Class Initialized
DEBUG - 2016-05-08 10:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:42:23 --> Input Class Initialized
INFO - 2016-05-08 10:42:23 --> Language Class Initialized
INFO - 2016-05-08 10:42:23 --> Loader Class Initialized
INFO - 2016-05-08 10:42:23 --> Helper loaded: url_helper
INFO - 2016-05-08 10:42:23 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:42:23 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:42:23 --> Helper loaded: form_helper
INFO - 2016-05-08 10:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:42:23 --> Form Validation Class Initialized
INFO - 2016-05-08 10:42:23 --> Controller Class Initialized
INFO - 2016-05-08 10:42:23 --> Model Class Initialized
INFO - 2016-05-08 10:42:23 --> Database Driver Class Initialized
INFO - 2016-05-08 10:42:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:42:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:42:23 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:42:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:42:23 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:42:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 10:42:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:42:23 --> Final output sent to browser
DEBUG - 2016-05-08 10:42:23 --> Total execution time: 0.0900
INFO - 2016-05-08 10:46:22 --> Config Class Initialized
INFO - 2016-05-08 10:46:22 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:46:22 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:46:22 --> Utf8 Class Initialized
INFO - 2016-05-08 10:46:22 --> URI Class Initialized
INFO - 2016-05-08 10:46:22 --> Router Class Initialized
INFO - 2016-05-08 10:46:22 --> Output Class Initialized
INFO - 2016-05-08 10:46:22 --> Security Class Initialized
DEBUG - 2016-05-08 10:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:46:22 --> Input Class Initialized
INFO - 2016-05-08 10:46:22 --> Language Class Initialized
INFO - 2016-05-08 10:46:22 --> Loader Class Initialized
INFO - 2016-05-08 10:46:22 --> Helper loaded: url_helper
INFO - 2016-05-08 10:46:22 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:46:22 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:46:22 --> Helper loaded: form_helper
INFO - 2016-05-08 10:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:46:22 --> Form Validation Class Initialized
INFO - 2016-05-08 10:46:22 --> Controller Class Initialized
INFO - 2016-05-08 10:46:22 --> Model Class Initialized
INFO - 2016-05-08 10:46:22 --> Database Driver Class Initialized
INFO - 2016-05-08 10:46:22 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:46:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:46:22 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:46:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:46:22 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:46:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 10:46:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:46:22 --> Final output sent to browser
DEBUG - 2016-05-08 10:46:22 --> Total execution time: 0.0901
INFO - 2016-05-08 10:46:29 --> Config Class Initialized
INFO - 2016-05-08 10:46:29 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:46:29 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:46:29 --> Utf8 Class Initialized
INFO - 2016-05-08 10:46:29 --> URI Class Initialized
INFO - 2016-05-08 10:46:29 --> Router Class Initialized
INFO - 2016-05-08 10:46:29 --> Output Class Initialized
INFO - 2016-05-08 10:46:29 --> Security Class Initialized
DEBUG - 2016-05-08 10:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:46:29 --> Input Class Initialized
INFO - 2016-05-08 10:46:29 --> Language Class Initialized
INFO - 2016-05-08 10:46:29 --> Loader Class Initialized
INFO - 2016-05-08 10:46:29 --> Helper loaded: url_helper
INFO - 2016-05-08 10:46:29 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:46:29 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:46:29 --> Helper loaded: form_helper
INFO - 2016-05-08 10:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:46:29 --> Form Validation Class Initialized
INFO - 2016-05-08 10:46:29 --> Controller Class Initialized
INFO - 2016-05-08 10:46:29 --> Model Class Initialized
INFO - 2016-05-08 10:46:29 --> Database Driver Class Initialized
INFO - 2016-05-08 10:46:29 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:46:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:46:29 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:46:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:46:29 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:46:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 10:46:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:46:29 --> Final output sent to browser
DEBUG - 2016-05-08 10:46:29 --> Total execution time: 0.1075
INFO - 2016-05-08 10:46:31 --> Config Class Initialized
INFO - 2016-05-08 10:46:31 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:46:31 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:46:31 --> Utf8 Class Initialized
INFO - 2016-05-08 10:46:31 --> URI Class Initialized
INFO - 2016-05-08 10:46:31 --> Router Class Initialized
INFO - 2016-05-08 10:46:31 --> Output Class Initialized
INFO - 2016-05-08 10:46:31 --> Security Class Initialized
DEBUG - 2016-05-08 10:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:46:31 --> Input Class Initialized
INFO - 2016-05-08 10:46:31 --> Language Class Initialized
INFO - 2016-05-08 10:46:31 --> Loader Class Initialized
INFO - 2016-05-08 10:46:31 --> Helper loaded: url_helper
INFO - 2016-05-08 10:46:31 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:46:31 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:46:31 --> Helper loaded: form_helper
INFO - 2016-05-08 10:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:46:31 --> Form Validation Class Initialized
INFO - 2016-05-08 10:46:31 --> Controller Class Initialized
INFO - 2016-05-08 10:46:31 --> Model Class Initialized
INFO - 2016-05-08 10:46:31 --> Database Driver Class Initialized
INFO - 2016-05-08 10:46:31 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:46:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:46:31 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:46:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:46:31 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 10:46:31 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 21
ERROR - 2016-05-08 10:46:31 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 22
ERROR - 2016-05-08 10:46:31 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 23
ERROR - 2016-05-08 10:46:31 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 23
ERROR - 2016-05-08 10:46:31 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 24
ERROR - 2016-05-08 10:46:31 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 28
ERROR - 2016-05-08 10:46:31 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 29
ERROR - 2016-05-08 10:46:31 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 30
ERROR - 2016-05-08 10:46:31 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 31
ERROR - 2016-05-08 10:46:31 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 35
INFO - 2016-05-08 10:46:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-08 10:46:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:46:31 --> Final output sent to browser
DEBUG - 2016-05-08 10:46:31 --> Total execution time: 0.1547
INFO - 2016-05-08 10:47:24 --> Config Class Initialized
INFO - 2016-05-08 10:47:24 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:47:24 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:47:24 --> Utf8 Class Initialized
INFO - 2016-05-08 10:47:24 --> URI Class Initialized
INFO - 2016-05-08 10:47:24 --> Router Class Initialized
INFO - 2016-05-08 10:47:24 --> Output Class Initialized
INFO - 2016-05-08 10:47:24 --> Security Class Initialized
DEBUG - 2016-05-08 10:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:47:24 --> Input Class Initialized
INFO - 2016-05-08 10:47:24 --> Language Class Initialized
INFO - 2016-05-08 10:47:24 --> Loader Class Initialized
INFO - 2016-05-08 10:47:24 --> Helper loaded: url_helper
INFO - 2016-05-08 10:47:24 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:47:24 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:47:24 --> Helper loaded: form_helper
INFO - 2016-05-08 10:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:47:24 --> Form Validation Class Initialized
INFO - 2016-05-08 10:47:24 --> Controller Class Initialized
INFO - 2016-05-08 10:47:24 --> Model Class Initialized
INFO - 2016-05-08 10:47:25 --> Database Driver Class Initialized
INFO - 2016-05-08 10:47:25 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:47:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:47:25 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:47:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:47:25 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:47:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 10:47:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:47:25 --> Final output sent to browser
DEBUG - 2016-05-08 10:47:25 --> Total execution time: 0.0981
INFO - 2016-05-08 10:47:26 --> Config Class Initialized
INFO - 2016-05-08 10:47:26 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:47:26 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:47:26 --> Utf8 Class Initialized
INFO - 2016-05-08 10:47:26 --> URI Class Initialized
INFO - 2016-05-08 10:47:26 --> Router Class Initialized
INFO - 2016-05-08 10:47:26 --> Output Class Initialized
INFO - 2016-05-08 10:47:26 --> Security Class Initialized
DEBUG - 2016-05-08 10:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:47:26 --> Input Class Initialized
INFO - 2016-05-08 10:47:26 --> Language Class Initialized
INFO - 2016-05-08 10:47:26 --> Loader Class Initialized
INFO - 2016-05-08 10:47:26 --> Helper loaded: url_helper
INFO - 2016-05-08 10:47:26 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:47:26 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:47:26 --> Helper loaded: form_helper
INFO - 2016-05-08 10:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:47:26 --> Form Validation Class Initialized
INFO - 2016-05-08 10:47:26 --> Controller Class Initialized
INFO - 2016-05-08 10:47:26 --> Model Class Initialized
INFO - 2016-05-08 10:47:26 --> Database Driver Class Initialized
INFO - 2016-05-08 10:47:26 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:47:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:47:26 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:47:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:47:26 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:47:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProveedor.php
INFO - 2016-05-08 10:47:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:47:26 --> Final output sent to browser
DEBUG - 2016-05-08 10:47:26 --> Total execution time: 0.2114
INFO - 2016-05-08 10:47:27 --> Config Class Initialized
INFO - 2016-05-08 10:47:27 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:47:27 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:47:27 --> Utf8 Class Initialized
INFO - 2016-05-08 10:47:27 --> URI Class Initialized
INFO - 2016-05-08 10:47:27 --> Router Class Initialized
INFO - 2016-05-08 10:47:27 --> Output Class Initialized
INFO - 2016-05-08 10:47:27 --> Security Class Initialized
DEBUG - 2016-05-08 10:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:47:27 --> Input Class Initialized
INFO - 2016-05-08 10:47:27 --> Language Class Initialized
INFO - 2016-05-08 10:47:27 --> Loader Class Initialized
INFO - 2016-05-08 10:47:27 --> Helper loaded: url_helper
INFO - 2016-05-08 10:47:27 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:47:27 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:47:27 --> Helper loaded: form_helper
INFO - 2016-05-08 10:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:47:27 --> Form Validation Class Initialized
INFO - 2016-05-08 10:47:27 --> Controller Class Initialized
INFO - 2016-05-08 10:47:27 --> Model Class Initialized
INFO - 2016-05-08 10:47:27 --> Database Driver Class Initialized
INFO - 2016-05-08 10:47:27 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:47:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:47:27 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:47:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:47:27 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:47:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 10:47:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:47:27 --> Final output sent to browser
DEBUG - 2016-05-08 10:47:27 --> Total execution time: 0.0764
INFO - 2016-05-08 10:47:29 --> Config Class Initialized
INFO - 2016-05-08 10:47:29 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:47:29 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:47:29 --> Utf8 Class Initialized
INFO - 2016-05-08 10:47:29 --> URI Class Initialized
INFO - 2016-05-08 10:47:29 --> Router Class Initialized
INFO - 2016-05-08 10:47:29 --> Output Class Initialized
INFO - 2016-05-08 10:47:29 --> Security Class Initialized
DEBUG - 2016-05-08 10:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:47:29 --> Input Class Initialized
INFO - 2016-05-08 10:47:29 --> Language Class Initialized
INFO - 2016-05-08 10:47:29 --> Loader Class Initialized
INFO - 2016-05-08 10:47:29 --> Helper loaded: url_helper
INFO - 2016-05-08 10:47:29 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:47:29 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:47:29 --> Helper loaded: form_helper
INFO - 2016-05-08 10:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:47:29 --> Form Validation Class Initialized
INFO - 2016-05-08 10:47:29 --> Controller Class Initialized
INFO - 2016-05-08 10:47:29 --> Model Class Initialized
INFO - 2016-05-08 10:47:29 --> Database Driver Class Initialized
INFO - 2016-05-08 10:47:29 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:47:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:47:29 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:47:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:47:29 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:47:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProveedor.php
INFO - 2016-05-08 10:47:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:47:29 --> Final output sent to browser
DEBUG - 2016-05-08 10:47:29 --> Total execution time: 0.1344
INFO - 2016-05-08 10:47:33 --> Config Class Initialized
INFO - 2016-05-08 10:47:33 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:47:33 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:47:33 --> Utf8 Class Initialized
INFO - 2016-05-08 10:47:33 --> URI Class Initialized
INFO - 2016-05-08 10:47:33 --> Router Class Initialized
INFO - 2016-05-08 10:47:33 --> Output Class Initialized
INFO - 2016-05-08 10:47:33 --> Security Class Initialized
DEBUG - 2016-05-08 10:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:47:33 --> Input Class Initialized
INFO - 2016-05-08 10:47:33 --> Language Class Initialized
INFO - 2016-05-08 10:47:33 --> Loader Class Initialized
INFO - 2016-05-08 10:47:33 --> Helper loaded: url_helper
INFO - 2016-05-08 10:47:33 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:47:33 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:47:33 --> Helper loaded: form_helper
INFO - 2016-05-08 10:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:47:33 --> Form Validation Class Initialized
INFO - 2016-05-08 10:47:33 --> Controller Class Initialized
INFO - 2016-05-08 10:47:33 --> Model Class Initialized
INFO - 2016-05-08 10:47:33 --> Database Driver Class Initialized
INFO - 2016-05-08 10:47:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:47:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:47:33 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:47:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:47:33 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:47:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 10:47:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:47:33 --> Final output sent to browser
DEBUG - 2016-05-08 10:47:33 --> Total execution time: 0.0804
INFO - 2016-05-08 10:47:34 --> Config Class Initialized
INFO - 2016-05-08 10:47:34 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:47:34 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:47:34 --> Utf8 Class Initialized
INFO - 2016-05-08 10:47:34 --> URI Class Initialized
INFO - 2016-05-08 10:47:34 --> Router Class Initialized
INFO - 2016-05-08 10:47:34 --> Output Class Initialized
INFO - 2016-05-08 10:47:34 --> Security Class Initialized
DEBUG - 2016-05-08 10:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:47:34 --> Input Class Initialized
INFO - 2016-05-08 10:47:34 --> Language Class Initialized
INFO - 2016-05-08 10:47:34 --> Loader Class Initialized
INFO - 2016-05-08 10:47:34 --> Helper loaded: url_helper
INFO - 2016-05-08 10:47:34 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:47:34 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:47:34 --> Helper loaded: form_helper
INFO - 2016-05-08 10:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:47:34 --> Form Validation Class Initialized
INFO - 2016-05-08 10:47:34 --> Controller Class Initialized
INFO - 2016-05-08 10:47:34 --> Model Class Initialized
INFO - 2016-05-08 10:47:34 --> Database Driver Class Initialized
INFO - 2016-05-08 10:47:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:47:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:47:34 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:47:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:47:34 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 10:47:34 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 21
ERROR - 2016-05-08 10:47:34 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 22
ERROR - 2016-05-08 10:47:34 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 23
ERROR - 2016-05-08 10:47:34 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 23
ERROR - 2016-05-08 10:47:34 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 24
ERROR - 2016-05-08 10:47:34 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 28
ERROR - 2016-05-08 10:47:34 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 29
ERROR - 2016-05-08 10:47:34 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 30
ERROR - 2016-05-08 10:47:34 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 31
ERROR - 2016-05-08 10:47:34 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 35
INFO - 2016-05-08 10:47:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-08 10:47:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:47:34 --> Final output sent to browser
DEBUG - 2016-05-08 10:47:34 --> Total execution time: 0.1002
INFO - 2016-05-08 10:47:38 --> Config Class Initialized
INFO - 2016-05-08 10:47:38 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:47:38 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:47:38 --> Utf8 Class Initialized
INFO - 2016-05-08 10:47:38 --> URI Class Initialized
INFO - 2016-05-08 10:47:38 --> Router Class Initialized
INFO - 2016-05-08 10:47:38 --> Output Class Initialized
INFO - 2016-05-08 10:47:38 --> Security Class Initialized
DEBUG - 2016-05-08 10:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:47:38 --> Input Class Initialized
INFO - 2016-05-08 10:47:38 --> Language Class Initialized
INFO - 2016-05-08 10:47:38 --> Loader Class Initialized
INFO - 2016-05-08 10:47:38 --> Helper loaded: url_helper
INFO - 2016-05-08 10:47:38 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:47:38 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:47:38 --> Helper loaded: form_helper
INFO - 2016-05-08 10:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:47:38 --> Form Validation Class Initialized
INFO - 2016-05-08 10:47:38 --> Controller Class Initialized
INFO - 2016-05-08 10:47:38 --> Model Class Initialized
INFO - 2016-05-08 10:47:38 --> Database Driver Class Initialized
INFO - 2016-05-08 10:47:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:47:38 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:47:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:47:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-08 10:47:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:47:38 --> Final output sent to browser
DEBUG - 2016-05-08 10:47:38 --> Total execution time: 0.1192
INFO - 2016-05-08 10:47:39 --> Config Class Initialized
INFO - 2016-05-08 10:47:39 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:47:39 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:47:39 --> Utf8 Class Initialized
INFO - 2016-05-08 10:47:39 --> URI Class Initialized
INFO - 2016-05-08 10:47:39 --> Router Class Initialized
INFO - 2016-05-08 10:47:39 --> Output Class Initialized
INFO - 2016-05-08 10:47:39 --> Security Class Initialized
DEBUG - 2016-05-08 10:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:47:39 --> Input Class Initialized
INFO - 2016-05-08 10:47:39 --> Language Class Initialized
INFO - 2016-05-08 10:47:39 --> Loader Class Initialized
INFO - 2016-05-08 10:47:39 --> Helper loaded: url_helper
INFO - 2016-05-08 10:47:39 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:47:39 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:47:39 --> Helper loaded: form_helper
INFO - 2016-05-08 10:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:47:39 --> Form Validation Class Initialized
INFO - 2016-05-08 10:47:39 --> Controller Class Initialized
INFO - 2016-05-08 10:47:39 --> Model Class Initialized
INFO - 2016-05-08 10:47:39 --> Database Driver Class Initialized
INFO - 2016-05-08 10:47:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:47:39 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:47:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:47:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-08 10:47:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:47:39 --> Final output sent to browser
DEBUG - 2016-05-08 10:47:39 --> Total execution time: 0.1580
INFO - 2016-05-08 10:47:41 --> Config Class Initialized
INFO - 2016-05-08 10:47:41 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:47:41 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:47:41 --> Utf8 Class Initialized
INFO - 2016-05-08 10:47:42 --> URI Class Initialized
INFO - 2016-05-08 10:47:42 --> Router Class Initialized
INFO - 2016-05-08 10:47:42 --> Output Class Initialized
INFO - 2016-05-08 10:47:42 --> Security Class Initialized
DEBUG - 2016-05-08 10:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:47:42 --> Input Class Initialized
INFO - 2016-05-08 10:47:42 --> Language Class Initialized
INFO - 2016-05-08 10:47:42 --> Loader Class Initialized
INFO - 2016-05-08 10:47:42 --> Helper loaded: url_helper
INFO - 2016-05-08 10:47:42 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:47:42 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:47:42 --> Helper loaded: form_helper
INFO - 2016-05-08 10:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:47:42 --> Form Validation Class Initialized
INFO - 2016-05-08 10:47:42 --> Controller Class Initialized
INFO - 2016-05-08 10:47:42 --> Model Class Initialized
INFO - 2016-05-08 10:47:42 --> Database Driver Class Initialized
INFO - 2016-05-08 10:47:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:47:42 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:47:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:47:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-08 10:47:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:47:42 --> Final output sent to browser
DEBUG - 2016-05-08 10:47:42 --> Total execution time: 0.0737
INFO - 2016-05-08 10:47:44 --> Config Class Initialized
INFO - 2016-05-08 10:47:44 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:47:44 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:47:44 --> Utf8 Class Initialized
INFO - 2016-05-08 10:47:44 --> URI Class Initialized
INFO - 2016-05-08 10:47:44 --> Router Class Initialized
INFO - 2016-05-08 10:47:44 --> Output Class Initialized
INFO - 2016-05-08 10:47:44 --> Security Class Initialized
DEBUG - 2016-05-08 10:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:47:44 --> Input Class Initialized
INFO - 2016-05-08 10:47:44 --> Language Class Initialized
INFO - 2016-05-08 10:47:44 --> Loader Class Initialized
INFO - 2016-05-08 10:47:44 --> Helper loaded: url_helper
INFO - 2016-05-08 10:47:44 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:47:44 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:47:44 --> Helper loaded: form_helper
INFO - 2016-05-08 10:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:47:44 --> Form Validation Class Initialized
INFO - 2016-05-08 10:47:44 --> Controller Class Initialized
INFO - 2016-05-08 10:47:44 --> Model Class Initialized
INFO - 2016-05-08 10:47:44 --> Database Driver Class Initialized
INFO - 2016-05-08 10:47:44 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:47:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:47:44 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:47:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:47:44 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 10:47:44 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 21
ERROR - 2016-05-08 10:47:44 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 22
ERROR - 2016-05-08 10:47:44 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 23
ERROR - 2016-05-08 10:47:44 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 23
ERROR - 2016-05-08 10:47:44 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 24
ERROR - 2016-05-08 10:47:44 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 28
ERROR - 2016-05-08 10:47:44 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 29
ERROR - 2016-05-08 10:47:44 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 30
ERROR - 2016-05-08 10:47:44 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 31
ERROR - 2016-05-08 10:47:44 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 35
INFO - 2016-05-08 10:47:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-08 10:47:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:47:44 --> Final output sent to browser
DEBUG - 2016-05-08 10:47:44 --> Total execution time: 0.1053
INFO - 2016-05-08 10:47:48 --> Config Class Initialized
INFO - 2016-05-08 10:47:48 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:47:48 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:47:48 --> Utf8 Class Initialized
INFO - 2016-05-08 10:47:48 --> URI Class Initialized
INFO - 2016-05-08 10:47:48 --> Router Class Initialized
INFO - 2016-05-08 10:47:48 --> Output Class Initialized
INFO - 2016-05-08 10:47:48 --> Security Class Initialized
DEBUG - 2016-05-08 10:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:47:48 --> Input Class Initialized
INFO - 2016-05-08 10:47:48 --> Language Class Initialized
INFO - 2016-05-08 10:47:48 --> Loader Class Initialized
INFO - 2016-05-08 10:47:48 --> Helper loaded: url_helper
INFO - 2016-05-08 10:47:48 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:47:48 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:47:48 --> Helper loaded: form_helper
INFO - 2016-05-08 10:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:47:48 --> Form Validation Class Initialized
INFO - 2016-05-08 10:47:48 --> Controller Class Initialized
INFO - 2016-05-08 10:47:48 --> Model Class Initialized
INFO - 2016-05-08 10:47:48 --> Database Driver Class Initialized
INFO - 2016-05-08 10:47:48 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:47:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:47:48 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:47:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:47:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 10:47:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:47:48 --> Final output sent to browser
DEBUG - 2016-05-08 10:47:48 --> Total execution time: 0.1707
INFO - 2016-05-08 10:47:49 --> Config Class Initialized
INFO - 2016-05-08 10:47:49 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:47:49 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:47:49 --> Utf8 Class Initialized
INFO - 2016-05-08 10:47:49 --> URI Class Initialized
INFO - 2016-05-08 10:47:49 --> Router Class Initialized
INFO - 2016-05-08 10:47:49 --> Output Class Initialized
INFO - 2016-05-08 10:47:49 --> Security Class Initialized
DEBUG - 2016-05-08 10:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:47:49 --> Input Class Initialized
INFO - 2016-05-08 10:47:49 --> Language Class Initialized
INFO - 2016-05-08 10:47:49 --> Loader Class Initialized
INFO - 2016-05-08 10:47:49 --> Helper loaded: url_helper
INFO - 2016-05-08 10:47:49 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:47:49 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:47:49 --> Helper loaded: form_helper
INFO - 2016-05-08 10:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:47:49 --> Form Validation Class Initialized
INFO - 2016-05-08 10:47:49 --> Controller Class Initialized
INFO - 2016-05-08 10:47:49 --> Model Class Initialized
INFO - 2016-05-08 10:47:49 --> Database Driver Class Initialized
INFO - 2016-05-08 10:47:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:47:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:47:49 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:47:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:47:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-08 10:47:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:47:49 --> Final output sent to browser
DEBUG - 2016-05-08 10:47:49 --> Total execution time: 0.1402
INFO - 2016-05-08 10:47:51 --> Config Class Initialized
INFO - 2016-05-08 10:47:51 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:47:51 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:47:51 --> Utf8 Class Initialized
INFO - 2016-05-08 10:47:51 --> URI Class Initialized
INFO - 2016-05-08 10:47:51 --> Router Class Initialized
INFO - 2016-05-08 10:47:51 --> Output Class Initialized
INFO - 2016-05-08 10:47:51 --> Security Class Initialized
DEBUG - 2016-05-08 10:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:47:51 --> Input Class Initialized
INFO - 2016-05-08 10:47:51 --> Language Class Initialized
INFO - 2016-05-08 10:47:51 --> Loader Class Initialized
INFO - 2016-05-08 10:47:51 --> Helper loaded: url_helper
INFO - 2016-05-08 10:47:51 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:47:51 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:47:51 --> Helper loaded: form_helper
INFO - 2016-05-08 10:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:47:51 --> Form Validation Class Initialized
INFO - 2016-05-08 10:47:51 --> Controller Class Initialized
INFO - 2016-05-08 10:47:51 --> Model Class Initialized
INFO - 2016-05-08 10:47:51 --> Database Driver Class Initialized
INFO - 2016-05-08 10:47:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:47:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:47:51 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:47:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:47:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 10:47:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:47:51 --> Final output sent to browser
DEBUG - 2016-05-08 10:47:51 --> Total execution time: 0.1156
INFO - 2016-05-08 10:47:53 --> Config Class Initialized
INFO - 2016-05-08 10:47:53 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:47:53 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:47:53 --> Utf8 Class Initialized
INFO - 2016-05-08 10:47:53 --> URI Class Initialized
INFO - 2016-05-08 10:47:53 --> Router Class Initialized
INFO - 2016-05-08 10:47:53 --> Output Class Initialized
INFO - 2016-05-08 10:47:53 --> Security Class Initialized
DEBUG - 2016-05-08 10:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:47:53 --> Input Class Initialized
INFO - 2016-05-08 10:47:53 --> Language Class Initialized
INFO - 2016-05-08 10:47:53 --> Loader Class Initialized
INFO - 2016-05-08 10:47:53 --> Helper loaded: url_helper
INFO - 2016-05-08 10:47:53 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:47:53 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:47:53 --> Helper loaded: form_helper
INFO - 2016-05-08 10:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:47:53 --> Form Validation Class Initialized
INFO - 2016-05-08 10:47:53 --> Controller Class Initialized
INFO - 2016-05-08 10:47:53 --> Model Class Initialized
INFO - 2016-05-08 10:47:53 --> Database Driver Class Initialized
INFO - 2016-05-08 10:47:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:47:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:47:53 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:47:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:47:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-08 10:47:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:47:53 --> Final output sent to browser
DEBUG - 2016-05-08 10:47:53 --> Total execution time: 0.1345
INFO - 2016-05-08 10:48:28 --> Config Class Initialized
INFO - 2016-05-08 10:48:28 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:48:28 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:48:28 --> Utf8 Class Initialized
INFO - 2016-05-08 10:48:28 --> URI Class Initialized
INFO - 2016-05-08 10:48:28 --> Router Class Initialized
INFO - 2016-05-08 10:48:28 --> Output Class Initialized
INFO - 2016-05-08 10:48:28 --> Security Class Initialized
DEBUG - 2016-05-08 10:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:48:28 --> Input Class Initialized
INFO - 2016-05-08 10:48:28 --> Language Class Initialized
INFO - 2016-05-08 10:48:28 --> Loader Class Initialized
INFO - 2016-05-08 10:48:28 --> Helper loaded: url_helper
INFO - 2016-05-08 10:48:28 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:48:28 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:48:28 --> Helper loaded: form_helper
INFO - 2016-05-08 10:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:48:28 --> Form Validation Class Initialized
INFO - 2016-05-08 10:48:28 --> Controller Class Initialized
INFO - 2016-05-08 10:48:28 --> Model Class Initialized
INFO - 2016-05-08 10:48:28 --> Database Driver Class Initialized
INFO - 2016-05-08 10:48:28 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:48:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:48:28 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:48:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:48:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-08 10:48:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:48:28 --> Final output sent to browser
DEBUG - 2016-05-08 10:48:28 --> Total execution time: 0.0823
INFO - 2016-05-08 10:48:46 --> Config Class Initialized
INFO - 2016-05-08 10:48:46 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:48:46 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:48:46 --> Utf8 Class Initialized
INFO - 2016-05-08 10:48:46 --> URI Class Initialized
INFO - 2016-05-08 10:48:46 --> Router Class Initialized
INFO - 2016-05-08 10:48:46 --> Output Class Initialized
INFO - 2016-05-08 10:48:46 --> Security Class Initialized
DEBUG - 2016-05-08 10:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:48:46 --> Input Class Initialized
INFO - 2016-05-08 10:48:46 --> Language Class Initialized
INFO - 2016-05-08 10:48:46 --> Loader Class Initialized
INFO - 2016-05-08 10:48:46 --> Helper loaded: url_helper
INFO - 2016-05-08 10:48:46 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:48:46 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:48:46 --> Helper loaded: form_helper
INFO - 2016-05-08 10:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:48:46 --> Form Validation Class Initialized
INFO - 2016-05-08 10:48:46 --> Controller Class Initialized
INFO - 2016-05-08 10:48:46 --> Model Class Initialized
INFO - 2016-05-08 10:48:46 --> Database Driver Class Initialized
INFO - 2016-05-08 10:48:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:48:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:48:46 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:48:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:48:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-08 10:48:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:48:46 --> Final output sent to browser
DEBUG - 2016-05-08 10:48:46 --> Total execution time: 0.0945
INFO - 2016-05-08 10:49:05 --> Config Class Initialized
INFO - 2016-05-08 10:49:05 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:49:05 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:49:05 --> Utf8 Class Initialized
INFO - 2016-05-08 10:49:05 --> URI Class Initialized
INFO - 2016-05-08 10:49:05 --> Router Class Initialized
INFO - 2016-05-08 10:49:05 --> Output Class Initialized
INFO - 2016-05-08 10:49:05 --> Security Class Initialized
DEBUG - 2016-05-08 10:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:49:05 --> Input Class Initialized
INFO - 2016-05-08 10:49:05 --> Language Class Initialized
INFO - 2016-05-08 10:49:05 --> Loader Class Initialized
INFO - 2016-05-08 10:49:05 --> Helper loaded: url_helper
INFO - 2016-05-08 10:49:05 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:49:05 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:49:05 --> Helper loaded: form_helper
INFO - 2016-05-08 10:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:49:05 --> Form Validation Class Initialized
INFO - 2016-05-08 10:49:05 --> Controller Class Initialized
INFO - 2016-05-08 10:49:05 --> Model Class Initialized
INFO - 2016-05-08 10:49:05 --> Database Driver Class Initialized
INFO - 2016-05-08 10:49:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:49:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:49:05 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:49:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:49:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-08 10:49:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:49:05 --> Final output sent to browser
DEBUG - 2016-05-08 10:49:05 --> Total execution time: 0.0808
INFO - 2016-05-08 10:49:15 --> Config Class Initialized
INFO - 2016-05-08 10:49:15 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:49:15 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:49:15 --> Utf8 Class Initialized
INFO - 2016-05-08 10:49:15 --> URI Class Initialized
INFO - 2016-05-08 10:49:15 --> Router Class Initialized
INFO - 2016-05-08 10:49:15 --> Output Class Initialized
INFO - 2016-05-08 10:49:15 --> Security Class Initialized
DEBUG - 2016-05-08 10:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:49:15 --> Input Class Initialized
INFO - 2016-05-08 10:49:15 --> Language Class Initialized
INFO - 2016-05-08 10:49:15 --> Loader Class Initialized
INFO - 2016-05-08 10:49:15 --> Helper loaded: url_helper
INFO - 2016-05-08 10:49:15 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:49:15 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:49:15 --> Helper loaded: form_helper
INFO - 2016-05-08 10:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:49:15 --> Form Validation Class Initialized
INFO - 2016-05-08 10:49:15 --> Controller Class Initialized
INFO - 2016-05-08 10:49:15 --> Model Class Initialized
INFO - 2016-05-08 10:49:15 --> Database Driver Class Initialized
INFO - 2016-05-08 10:49:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:49:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:49:15 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:49:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:49:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-08 10:49:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:49:15 --> Final output sent to browser
DEBUG - 2016-05-08 10:49:15 --> Total execution time: 0.0918
INFO - 2016-05-08 10:49:49 --> Config Class Initialized
INFO - 2016-05-08 10:49:49 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:49:49 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:49:49 --> Utf8 Class Initialized
INFO - 2016-05-08 10:49:49 --> URI Class Initialized
INFO - 2016-05-08 10:49:49 --> Router Class Initialized
INFO - 2016-05-08 10:49:50 --> Output Class Initialized
INFO - 2016-05-08 10:49:50 --> Security Class Initialized
DEBUG - 2016-05-08 10:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:49:50 --> Input Class Initialized
INFO - 2016-05-08 10:49:50 --> Language Class Initialized
INFO - 2016-05-08 10:49:50 --> Loader Class Initialized
INFO - 2016-05-08 10:49:50 --> Helper loaded: url_helper
INFO - 2016-05-08 10:49:50 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:49:50 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:49:50 --> Helper loaded: form_helper
INFO - 2016-05-08 10:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:49:50 --> Form Validation Class Initialized
INFO - 2016-05-08 10:49:50 --> Controller Class Initialized
INFO - 2016-05-08 10:49:50 --> Model Class Initialized
INFO - 2016-05-08 10:49:50 --> Database Driver Class Initialized
INFO - 2016-05-08 10:49:50 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:49:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:49:50 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:49:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:49:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-08 10:49:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:49:50 --> Final output sent to browser
DEBUG - 2016-05-08 10:49:50 --> Total execution time: 0.0772
INFO - 2016-05-08 10:50:16 --> Config Class Initialized
INFO - 2016-05-08 10:50:16 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:50:16 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:50:16 --> Utf8 Class Initialized
INFO - 2016-05-08 10:50:16 --> URI Class Initialized
INFO - 2016-05-08 10:50:16 --> Router Class Initialized
INFO - 2016-05-08 10:50:16 --> Output Class Initialized
INFO - 2016-05-08 10:50:16 --> Security Class Initialized
DEBUG - 2016-05-08 10:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:50:16 --> Input Class Initialized
INFO - 2016-05-08 10:50:16 --> Language Class Initialized
INFO - 2016-05-08 10:50:16 --> Loader Class Initialized
INFO - 2016-05-08 10:50:16 --> Helper loaded: url_helper
INFO - 2016-05-08 10:50:16 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:50:16 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:50:16 --> Helper loaded: form_helper
INFO - 2016-05-08 10:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:50:16 --> Form Validation Class Initialized
INFO - 2016-05-08 10:50:16 --> Controller Class Initialized
INFO - 2016-05-08 10:50:16 --> Model Class Initialized
INFO - 2016-05-08 10:50:16 --> Database Driver Class Initialized
INFO - 2016-05-08 10:50:16 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:50:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:50:16 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:50:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:50:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-08 10:50:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:50:16 --> Final output sent to browser
DEBUG - 2016-05-08 10:50:16 --> Total execution time: 0.0887
INFO - 2016-05-08 10:50:46 --> Config Class Initialized
INFO - 2016-05-08 10:50:46 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:50:46 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:50:46 --> Utf8 Class Initialized
INFO - 2016-05-08 10:50:46 --> URI Class Initialized
INFO - 2016-05-08 10:50:46 --> Router Class Initialized
INFO - 2016-05-08 10:50:46 --> Output Class Initialized
INFO - 2016-05-08 10:50:46 --> Security Class Initialized
DEBUG - 2016-05-08 10:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:50:46 --> Input Class Initialized
INFO - 2016-05-08 10:50:46 --> Language Class Initialized
INFO - 2016-05-08 10:50:46 --> Loader Class Initialized
INFO - 2016-05-08 10:50:46 --> Helper loaded: url_helper
INFO - 2016-05-08 10:50:46 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:50:46 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:50:46 --> Helper loaded: form_helper
INFO - 2016-05-08 10:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:50:46 --> Form Validation Class Initialized
INFO - 2016-05-08 10:50:46 --> Controller Class Initialized
INFO - 2016-05-08 10:50:46 --> Model Class Initialized
INFO - 2016-05-08 10:50:47 --> Database Driver Class Initialized
INFO - 2016-05-08 10:50:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:50:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:50:47 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:50:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:50:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-08 10:50:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:50:47 --> Final output sent to browser
DEBUG - 2016-05-08 10:50:47 --> Total execution time: 0.0890
INFO - 2016-05-08 10:51:39 --> Config Class Initialized
INFO - 2016-05-08 10:51:39 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:51:39 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:51:39 --> Utf8 Class Initialized
INFO - 2016-05-08 10:51:39 --> URI Class Initialized
INFO - 2016-05-08 10:51:39 --> Router Class Initialized
INFO - 2016-05-08 10:51:39 --> Output Class Initialized
INFO - 2016-05-08 10:51:39 --> Security Class Initialized
DEBUG - 2016-05-08 10:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:51:39 --> Input Class Initialized
INFO - 2016-05-08 10:51:39 --> Language Class Initialized
INFO - 2016-05-08 10:51:39 --> Loader Class Initialized
INFO - 2016-05-08 10:51:39 --> Helper loaded: url_helper
INFO - 2016-05-08 10:51:39 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:51:39 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:51:39 --> Helper loaded: form_helper
INFO - 2016-05-08 10:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:51:39 --> Form Validation Class Initialized
INFO - 2016-05-08 10:51:39 --> Controller Class Initialized
INFO - 2016-05-08 10:51:39 --> Model Class Initialized
INFO - 2016-05-08 10:51:39 --> Database Driver Class Initialized
INFO - 2016-05-08 10:51:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:51:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:51:39 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:51:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:51:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-08 10:51:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:51:39 --> Final output sent to browser
DEBUG - 2016-05-08 10:51:39 --> Total execution time: 0.0773
INFO - 2016-05-08 10:51:45 --> Config Class Initialized
INFO - 2016-05-08 10:51:45 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:51:45 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:51:45 --> Utf8 Class Initialized
INFO - 2016-05-08 10:51:45 --> URI Class Initialized
INFO - 2016-05-08 10:51:45 --> Router Class Initialized
INFO - 2016-05-08 10:51:45 --> Output Class Initialized
INFO - 2016-05-08 10:51:45 --> Security Class Initialized
DEBUG - 2016-05-08 10:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:51:45 --> Input Class Initialized
INFO - 2016-05-08 10:51:45 --> Language Class Initialized
INFO - 2016-05-08 10:51:45 --> Loader Class Initialized
INFO - 2016-05-08 10:51:45 --> Helper loaded: url_helper
INFO - 2016-05-08 10:51:45 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:51:45 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:51:45 --> Helper loaded: form_helper
INFO - 2016-05-08 10:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:51:45 --> Form Validation Class Initialized
INFO - 2016-05-08 10:51:45 --> Controller Class Initialized
INFO - 2016-05-08 10:51:45 --> Model Class Initialized
INFO - 2016-05-08 10:51:45 --> Database Driver Class Initialized
INFO - 2016-05-08 10:51:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:51:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:51:45 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:51:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:51:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 10:51:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:51:45 --> Final output sent to browser
DEBUG - 2016-05-08 10:51:45 --> Total execution time: 0.1190
INFO - 2016-05-08 10:51:47 --> Config Class Initialized
INFO - 2016-05-08 10:51:47 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:51:47 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:51:47 --> Utf8 Class Initialized
INFO - 2016-05-08 10:51:47 --> URI Class Initialized
INFO - 2016-05-08 10:51:47 --> Router Class Initialized
INFO - 2016-05-08 10:51:47 --> Output Class Initialized
INFO - 2016-05-08 10:51:47 --> Security Class Initialized
DEBUG - 2016-05-08 10:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:51:47 --> Input Class Initialized
INFO - 2016-05-08 10:51:47 --> Language Class Initialized
INFO - 2016-05-08 10:51:47 --> Loader Class Initialized
INFO - 2016-05-08 10:51:47 --> Helper loaded: url_helper
INFO - 2016-05-08 10:51:47 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:51:47 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:51:47 --> Helper loaded: form_helper
INFO - 2016-05-08 10:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:51:47 --> Form Validation Class Initialized
INFO - 2016-05-08 10:51:47 --> Controller Class Initialized
INFO - 2016-05-08 10:51:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-08 10:51:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:51:47 --> Final output sent to browser
DEBUG - 2016-05-08 10:51:47 --> Total execution time: 0.0907
INFO - 2016-05-08 10:51:49 --> Config Class Initialized
INFO - 2016-05-08 10:51:49 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:51:49 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:51:49 --> Utf8 Class Initialized
INFO - 2016-05-08 10:51:49 --> URI Class Initialized
INFO - 2016-05-08 10:51:49 --> Router Class Initialized
INFO - 2016-05-08 10:51:49 --> Output Class Initialized
INFO - 2016-05-08 10:51:49 --> Security Class Initialized
DEBUG - 2016-05-08 10:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:51:49 --> Input Class Initialized
INFO - 2016-05-08 10:51:49 --> Language Class Initialized
INFO - 2016-05-08 10:51:49 --> Loader Class Initialized
INFO - 2016-05-08 10:51:49 --> Helper loaded: url_helper
INFO - 2016-05-08 10:51:49 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:51:49 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:51:49 --> Helper loaded: form_helper
INFO - 2016-05-08 10:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:51:49 --> Form Validation Class Initialized
INFO - 2016-05-08 10:51:49 --> Controller Class Initialized
INFO - 2016-05-08 10:51:49 --> Config Class Initialized
INFO - 2016-05-08 10:51:49 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:51:49 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:51:49 --> Utf8 Class Initialized
INFO - 2016-05-08 10:51:49 --> URI Class Initialized
INFO - 2016-05-08 10:51:49 --> Router Class Initialized
INFO - 2016-05-08 10:51:49 --> Output Class Initialized
INFO - 2016-05-08 10:51:49 --> Security Class Initialized
DEBUG - 2016-05-08 10:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:51:49 --> Input Class Initialized
INFO - 2016-05-08 10:51:49 --> Language Class Initialized
INFO - 2016-05-08 10:51:49 --> Loader Class Initialized
INFO - 2016-05-08 10:51:49 --> Helper loaded: url_helper
INFO - 2016-05-08 10:51:49 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:51:49 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:51:49 --> Helper loaded: form_helper
INFO - 2016-05-08 10:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:51:49 --> Form Validation Class Initialized
INFO - 2016-05-08 10:51:49 --> Controller Class Initialized
INFO - 2016-05-08 10:51:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-08 10:51:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 10:51:49 --> Final output sent to browser
DEBUG - 2016-05-08 10:51:49 --> Total execution time: 0.0828
INFO - 2016-05-08 10:51:54 --> Config Class Initialized
INFO - 2016-05-08 10:51:54 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:51:54 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:51:54 --> Utf8 Class Initialized
INFO - 2016-05-08 10:51:54 --> URI Class Initialized
INFO - 2016-05-08 10:51:54 --> Router Class Initialized
INFO - 2016-05-08 10:51:54 --> Output Class Initialized
INFO - 2016-05-08 10:51:54 --> Security Class Initialized
DEBUG - 2016-05-08 10:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:51:54 --> Input Class Initialized
INFO - 2016-05-08 10:51:54 --> Language Class Initialized
INFO - 2016-05-08 10:51:54 --> Loader Class Initialized
INFO - 2016-05-08 10:51:54 --> Helper loaded: url_helper
INFO - 2016-05-08 10:51:54 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:51:54 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:51:54 --> Helper loaded: form_helper
INFO - 2016-05-08 10:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:51:54 --> Form Validation Class Initialized
INFO - 2016-05-08 10:51:54 --> Controller Class Initialized
INFO - 2016-05-08 10:51:54 --> Model Class Initialized
INFO - 2016-05-08 10:51:54 --> Database Driver Class Initialized
INFO - 2016-05-08 10:51:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:51:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:51:54 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:51:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:51:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 10:51:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 10:51:54 --> Final output sent to browser
DEBUG - 2016-05-08 10:51:54 --> Total execution time: 0.0830
INFO - 2016-05-08 10:51:57 --> Config Class Initialized
INFO - 2016-05-08 10:51:57 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:51:58 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:51:58 --> Utf8 Class Initialized
INFO - 2016-05-08 10:51:58 --> URI Class Initialized
INFO - 2016-05-08 10:51:58 --> Router Class Initialized
INFO - 2016-05-08 10:51:58 --> Output Class Initialized
INFO - 2016-05-08 10:51:58 --> Security Class Initialized
DEBUG - 2016-05-08 10:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:51:58 --> Input Class Initialized
INFO - 2016-05-08 10:51:58 --> Language Class Initialized
INFO - 2016-05-08 10:51:58 --> Loader Class Initialized
INFO - 2016-05-08 10:51:58 --> Helper loaded: url_helper
INFO - 2016-05-08 10:51:58 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:51:58 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:51:58 --> Helper loaded: form_helper
INFO - 2016-05-08 10:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:51:58 --> Form Validation Class Initialized
INFO - 2016-05-08 10:51:58 --> Controller Class Initialized
INFO - 2016-05-08 10:51:58 --> Model Class Initialized
INFO - 2016-05-08 10:51:58 --> Database Driver Class Initialized
INFO - 2016-05-08 10:51:58 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:51:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:51:58 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:51:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:51:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-08 10:51:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 10:51:58 --> Final output sent to browser
DEBUG - 2016-05-08 10:51:58 --> Total execution time: 0.1095
INFO - 2016-05-08 10:52:04 --> Config Class Initialized
INFO - 2016-05-08 10:52:04 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:52:04 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:52:04 --> Utf8 Class Initialized
INFO - 2016-05-08 10:52:04 --> URI Class Initialized
INFO - 2016-05-08 10:52:04 --> Router Class Initialized
INFO - 2016-05-08 10:52:04 --> Output Class Initialized
INFO - 2016-05-08 10:52:04 --> Security Class Initialized
DEBUG - 2016-05-08 10:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:52:04 --> Input Class Initialized
INFO - 2016-05-08 10:52:04 --> Language Class Initialized
INFO - 2016-05-08 10:52:04 --> Loader Class Initialized
INFO - 2016-05-08 10:52:04 --> Helper loaded: url_helper
INFO - 2016-05-08 10:52:04 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:52:04 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:52:04 --> Helper loaded: form_helper
INFO - 2016-05-08 10:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:52:04 --> Form Validation Class Initialized
INFO - 2016-05-08 10:52:04 --> Controller Class Initialized
INFO - 2016-05-08 10:52:04 --> Model Class Initialized
INFO - 2016-05-08 10:52:04 --> Database Driver Class Initialized
INFO - 2016-05-08 10:52:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:52:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:52:04 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:52:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:52:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-08 10:52:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 10:52:04 --> Final output sent to browser
DEBUG - 2016-05-08 10:52:04 --> Total execution time: 0.0990
INFO - 2016-05-08 10:52:07 --> Config Class Initialized
INFO - 2016-05-08 10:52:07 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:52:07 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:52:07 --> Utf8 Class Initialized
INFO - 2016-05-08 10:52:07 --> URI Class Initialized
INFO - 2016-05-08 10:52:07 --> Router Class Initialized
INFO - 2016-05-08 10:52:07 --> Output Class Initialized
INFO - 2016-05-08 10:52:07 --> Security Class Initialized
DEBUG - 2016-05-08 10:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:52:07 --> Input Class Initialized
INFO - 2016-05-08 10:52:07 --> Language Class Initialized
INFO - 2016-05-08 10:52:07 --> Loader Class Initialized
INFO - 2016-05-08 10:52:07 --> Helper loaded: url_helper
INFO - 2016-05-08 10:52:07 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:52:07 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:52:07 --> Helper loaded: form_helper
INFO - 2016-05-08 10:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:52:07 --> Form Validation Class Initialized
INFO - 2016-05-08 10:52:07 --> Controller Class Initialized
INFO - 2016-05-08 10:52:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-08 10:52:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 10:52:07 --> Final output sent to browser
DEBUG - 2016-05-08 10:52:07 --> Total execution time: 0.0536
INFO - 2016-05-08 10:52:37 --> Config Class Initialized
INFO - 2016-05-08 10:52:37 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:52:37 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:52:37 --> Utf8 Class Initialized
INFO - 2016-05-08 10:52:37 --> URI Class Initialized
INFO - 2016-05-08 10:52:37 --> Router Class Initialized
INFO - 2016-05-08 10:52:37 --> Output Class Initialized
INFO - 2016-05-08 10:52:37 --> Security Class Initialized
DEBUG - 2016-05-08 10:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:52:37 --> Input Class Initialized
INFO - 2016-05-08 10:52:37 --> Language Class Initialized
INFO - 2016-05-08 10:52:37 --> Loader Class Initialized
INFO - 2016-05-08 10:52:37 --> Helper loaded: url_helper
INFO - 2016-05-08 10:52:37 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:52:37 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:52:37 --> Helper loaded: form_helper
INFO - 2016-05-08 10:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:52:37 --> Form Validation Class Initialized
INFO - 2016-05-08 10:52:37 --> Controller Class Initialized
INFO - 2016-05-08 10:52:37 --> Config Class Initialized
INFO - 2016-05-08 10:52:37 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:52:37 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:52:37 --> Utf8 Class Initialized
INFO - 2016-05-08 10:52:37 --> URI Class Initialized
INFO - 2016-05-08 10:52:37 --> Router Class Initialized
INFO - 2016-05-08 10:52:37 --> Output Class Initialized
INFO - 2016-05-08 10:52:37 --> Security Class Initialized
DEBUG - 2016-05-08 10:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:52:37 --> Input Class Initialized
INFO - 2016-05-08 10:52:37 --> Language Class Initialized
INFO - 2016-05-08 10:52:37 --> Loader Class Initialized
INFO - 2016-05-08 10:52:37 --> Helper loaded: url_helper
INFO - 2016-05-08 10:52:37 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:52:37 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:52:37 --> Helper loaded: form_helper
INFO - 2016-05-08 10:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:52:37 --> Form Validation Class Initialized
INFO - 2016-05-08 10:52:37 --> Controller Class Initialized
INFO - 2016-05-08 10:52:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-08 10:52:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:52:37 --> Final output sent to browser
DEBUG - 2016-05-08 10:52:37 --> Total execution time: 0.0515
INFO - 2016-05-08 10:52:40 --> Config Class Initialized
INFO - 2016-05-08 10:52:40 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:52:40 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:52:40 --> Utf8 Class Initialized
INFO - 2016-05-08 10:52:40 --> URI Class Initialized
INFO - 2016-05-08 10:52:40 --> Router Class Initialized
INFO - 2016-05-08 10:52:40 --> Output Class Initialized
INFO - 2016-05-08 10:52:40 --> Security Class Initialized
DEBUG - 2016-05-08 10:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:52:40 --> Input Class Initialized
INFO - 2016-05-08 10:52:40 --> Language Class Initialized
INFO - 2016-05-08 10:52:40 --> Loader Class Initialized
INFO - 2016-05-08 10:52:40 --> Helper loaded: url_helper
INFO - 2016-05-08 10:52:40 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:52:40 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:52:40 --> Helper loaded: form_helper
INFO - 2016-05-08 10:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:52:40 --> Form Validation Class Initialized
INFO - 2016-05-08 10:52:40 --> Controller Class Initialized
INFO - 2016-05-08 10:52:40 --> Model Class Initialized
INFO - 2016-05-08 10:52:40 --> Database Driver Class Initialized
INFO - 2016-05-08 10:52:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:52:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:52:40 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:52:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:52:40 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:52:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 10:52:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:52:40 --> Final output sent to browser
DEBUG - 2016-05-08 10:52:40 --> Total execution time: 0.1019
INFO - 2016-05-08 10:52:48 --> Config Class Initialized
INFO - 2016-05-08 10:52:48 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:52:48 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:52:48 --> Utf8 Class Initialized
INFO - 2016-05-08 10:52:48 --> URI Class Initialized
INFO - 2016-05-08 10:52:48 --> Router Class Initialized
INFO - 2016-05-08 10:52:48 --> Output Class Initialized
INFO - 2016-05-08 10:52:48 --> Security Class Initialized
DEBUG - 2016-05-08 10:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:52:48 --> Input Class Initialized
INFO - 2016-05-08 10:52:48 --> Language Class Initialized
INFO - 2016-05-08 10:52:48 --> Loader Class Initialized
INFO - 2016-05-08 10:52:48 --> Helper loaded: url_helper
INFO - 2016-05-08 10:52:48 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:52:48 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:52:48 --> Helper loaded: form_helper
INFO - 2016-05-08 10:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:52:48 --> Form Validation Class Initialized
INFO - 2016-05-08 10:52:48 --> Controller Class Initialized
INFO - 2016-05-08 10:52:48 --> Model Class Initialized
INFO - 2016-05-08 10:52:48 --> Database Driver Class Initialized
INFO - 2016-05-08 10:52:48 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:52:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:52:48 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:52:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:52:48 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 10:52:48 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 21
ERROR - 2016-05-08 10:52:48 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 22
ERROR - 2016-05-08 10:52:48 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 23
ERROR - 2016-05-08 10:52:48 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 23
ERROR - 2016-05-08 10:52:48 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 24
ERROR - 2016-05-08 10:52:48 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 28
ERROR - 2016-05-08 10:52:48 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 29
ERROR - 2016-05-08 10:52:48 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 30
ERROR - 2016-05-08 10:52:48 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 31
ERROR - 2016-05-08 10:52:48 --> Severity: Notice --> Undefined variable: clientes C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 35
INFO - 2016-05-08 10:52:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-08 10:52:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:52:48 --> Final output sent to browser
DEBUG - 2016-05-08 10:52:48 --> Total execution time: 0.1477
INFO - 2016-05-08 10:53:16 --> Config Class Initialized
INFO - 2016-05-08 10:53:16 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:53:16 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:53:16 --> Utf8 Class Initialized
INFO - 2016-05-08 10:53:16 --> URI Class Initialized
INFO - 2016-05-08 10:53:16 --> Router Class Initialized
INFO - 2016-05-08 10:53:16 --> Output Class Initialized
INFO - 2016-05-08 10:53:16 --> Security Class Initialized
DEBUG - 2016-05-08 10:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:53:16 --> Input Class Initialized
INFO - 2016-05-08 10:53:16 --> Language Class Initialized
INFO - 2016-05-08 10:53:16 --> Loader Class Initialized
INFO - 2016-05-08 10:53:16 --> Helper loaded: url_helper
INFO - 2016-05-08 10:53:16 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:53:16 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:53:16 --> Helper loaded: form_helper
INFO - 2016-05-08 10:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:53:16 --> Form Validation Class Initialized
INFO - 2016-05-08 10:53:16 --> Controller Class Initialized
INFO - 2016-05-08 10:53:16 --> Model Class Initialized
INFO - 2016-05-08 10:53:17 --> Database Driver Class Initialized
INFO - 2016-05-08 10:53:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:53:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:53:17 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:53:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:53:17 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 10:53:17 --> Severity: Notice --> Undefined index: provincia C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 31
INFO - 2016-05-08 10:53:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-08 10:53:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:53:17 --> Final output sent to browser
DEBUG - 2016-05-08 10:53:17 --> Total execution time: 0.0868
INFO - 2016-05-08 10:54:42 --> Config Class Initialized
INFO - 2016-05-08 10:54:42 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:54:42 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:54:42 --> Utf8 Class Initialized
INFO - 2016-05-08 10:54:42 --> URI Class Initialized
INFO - 2016-05-08 10:54:42 --> Router Class Initialized
INFO - 2016-05-08 10:54:42 --> Output Class Initialized
INFO - 2016-05-08 10:54:42 --> Security Class Initialized
DEBUG - 2016-05-08 10:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:54:42 --> Input Class Initialized
INFO - 2016-05-08 10:54:42 --> Language Class Initialized
INFO - 2016-05-08 10:54:42 --> Loader Class Initialized
INFO - 2016-05-08 10:54:42 --> Helper loaded: url_helper
INFO - 2016-05-08 10:54:42 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:54:42 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:54:42 --> Helper loaded: form_helper
INFO - 2016-05-08 10:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:54:42 --> Form Validation Class Initialized
INFO - 2016-05-08 10:54:42 --> Controller Class Initialized
INFO - 2016-05-08 10:54:42 --> Model Class Initialized
INFO - 2016-05-08 10:54:42 --> Database Driver Class Initialized
INFO - 2016-05-08 10:54:42 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:54:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:54:42 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:54:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:54:42 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 10:54:43 --> Severity: Notice --> Undefined index: provincia C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php 31
INFO - 2016-05-08 10:54:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-08 10:54:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:54:43 --> Final output sent to browser
DEBUG - 2016-05-08 10:54:43 --> Total execution time: 0.0839
INFO - 2016-05-08 10:54:53 --> Config Class Initialized
INFO - 2016-05-08 10:54:53 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:54:53 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:54:53 --> Utf8 Class Initialized
INFO - 2016-05-08 10:54:53 --> URI Class Initialized
INFO - 2016-05-08 10:54:53 --> Router Class Initialized
INFO - 2016-05-08 10:54:53 --> Output Class Initialized
INFO - 2016-05-08 10:54:53 --> Security Class Initialized
DEBUG - 2016-05-08 10:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:54:53 --> Input Class Initialized
INFO - 2016-05-08 10:54:53 --> Language Class Initialized
INFO - 2016-05-08 10:54:53 --> Loader Class Initialized
INFO - 2016-05-08 10:54:53 --> Helper loaded: url_helper
INFO - 2016-05-08 10:54:53 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:54:53 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:54:53 --> Helper loaded: form_helper
INFO - 2016-05-08 10:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:54:53 --> Form Validation Class Initialized
INFO - 2016-05-08 10:54:53 --> Controller Class Initialized
INFO - 2016-05-08 10:54:53 --> Model Class Initialized
INFO - 2016-05-08 10:54:53 --> Database Driver Class Initialized
INFO - 2016-05-08 10:54:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:54:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:54:53 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:54:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:54:53 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:54:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-08 10:54:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:54:53 --> Final output sent to browser
DEBUG - 2016-05-08 10:54:53 --> Total execution time: 0.0864
INFO - 2016-05-08 10:54:57 --> Config Class Initialized
INFO - 2016-05-08 10:54:57 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:54:57 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:54:57 --> Utf8 Class Initialized
INFO - 2016-05-08 10:54:57 --> URI Class Initialized
INFO - 2016-05-08 10:54:57 --> Router Class Initialized
INFO - 2016-05-08 10:54:57 --> Output Class Initialized
INFO - 2016-05-08 10:54:57 --> Security Class Initialized
DEBUG - 2016-05-08 10:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:54:57 --> Input Class Initialized
INFO - 2016-05-08 10:54:57 --> Language Class Initialized
INFO - 2016-05-08 10:54:57 --> Loader Class Initialized
INFO - 2016-05-08 10:54:57 --> Helper loaded: url_helper
INFO - 2016-05-08 10:54:57 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:54:57 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:54:57 --> Helper loaded: form_helper
INFO - 2016-05-08 10:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:54:57 --> Form Validation Class Initialized
INFO - 2016-05-08 10:54:57 --> Controller Class Initialized
INFO - 2016-05-08 10:54:57 --> Model Class Initialized
INFO - 2016-05-08 10:54:57 --> Database Driver Class Initialized
INFO - 2016-05-08 10:54:57 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:54:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:54:57 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:54:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:54:57 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:54:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 10:54:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:54:57 --> Final output sent to browser
DEBUG - 2016-05-08 10:54:57 --> Total execution time: 0.1073
INFO - 2016-05-08 10:54:58 --> Config Class Initialized
INFO - 2016-05-08 10:54:58 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:54:58 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:54:58 --> Utf8 Class Initialized
INFO - 2016-05-08 10:54:58 --> URI Class Initialized
INFO - 2016-05-08 10:54:58 --> Router Class Initialized
INFO - 2016-05-08 10:54:58 --> Output Class Initialized
INFO - 2016-05-08 10:54:58 --> Security Class Initialized
DEBUG - 2016-05-08 10:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:54:58 --> Input Class Initialized
INFO - 2016-05-08 10:54:58 --> Language Class Initialized
INFO - 2016-05-08 10:54:58 --> Loader Class Initialized
INFO - 2016-05-08 10:54:58 --> Helper loaded: url_helper
INFO - 2016-05-08 10:54:58 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:54:58 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:54:58 --> Helper loaded: form_helper
INFO - 2016-05-08 10:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:54:58 --> Form Validation Class Initialized
INFO - 2016-05-08 10:54:58 --> Controller Class Initialized
INFO - 2016-05-08 10:54:58 --> Model Class Initialized
INFO - 2016-05-08 10:54:58 --> Database Driver Class Initialized
INFO - 2016-05-08 10:54:58 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:54:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:54:58 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:54:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:54:58 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:54:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-08 10:54:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:54:58 --> Final output sent to browser
DEBUG - 2016-05-08 10:54:58 --> Total execution time: 0.1013
INFO - 2016-05-08 10:55:02 --> Config Class Initialized
INFO - 2016-05-08 10:55:02 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:55:02 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:55:02 --> Utf8 Class Initialized
INFO - 2016-05-08 10:55:02 --> URI Class Initialized
INFO - 2016-05-08 10:55:02 --> Router Class Initialized
INFO - 2016-05-08 10:55:02 --> Output Class Initialized
INFO - 2016-05-08 10:55:02 --> Security Class Initialized
DEBUG - 2016-05-08 10:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:55:02 --> Input Class Initialized
INFO - 2016-05-08 10:55:02 --> Language Class Initialized
INFO - 2016-05-08 10:55:02 --> Loader Class Initialized
INFO - 2016-05-08 10:55:02 --> Helper loaded: url_helper
INFO - 2016-05-08 10:55:02 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:55:02 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:55:02 --> Helper loaded: form_helper
INFO - 2016-05-08 10:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:55:02 --> Form Validation Class Initialized
INFO - 2016-05-08 10:55:02 --> Controller Class Initialized
INFO - 2016-05-08 10:55:02 --> Model Class Initialized
INFO - 2016-05-08 10:55:02 --> Database Driver Class Initialized
INFO - 2016-05-08 10:55:02 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:55:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 10:55:02 --> Pagination Class Initialized
DEBUG - 2016-05-08 10:55:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 10:55:02 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:55:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 10:55:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:55:02 --> Final output sent to browser
DEBUG - 2016-05-08 10:55:02 --> Total execution time: 0.1446
INFO - 2016-05-08 10:56:51 --> Config Class Initialized
INFO - 2016-05-08 10:56:51 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:56:51 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:56:51 --> Utf8 Class Initialized
INFO - 2016-05-08 10:56:51 --> URI Class Initialized
INFO - 2016-05-08 10:56:51 --> Router Class Initialized
INFO - 2016-05-08 10:56:51 --> Output Class Initialized
INFO - 2016-05-08 10:56:51 --> Security Class Initialized
DEBUG - 2016-05-08 10:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:56:51 --> Input Class Initialized
INFO - 2016-05-08 10:56:51 --> Language Class Initialized
INFO - 2016-05-08 10:56:51 --> Loader Class Initialized
INFO - 2016-05-08 10:56:51 --> Helper loaded: url_helper
INFO - 2016-05-08 10:56:51 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:56:51 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:56:51 --> Helper loaded: form_helper
INFO - 2016-05-08 10:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:56:51 --> Form Validation Class Initialized
INFO - 2016-05-08 10:56:51 --> Controller Class Initialized
INFO - 2016-05-08 10:56:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-08 10:56:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:56:51 --> Final output sent to browser
DEBUG - 2016-05-08 10:56:51 --> Total execution time: 0.1038
INFO - 2016-05-08 10:56:57 --> Config Class Initialized
INFO - 2016-05-08 10:56:57 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:56:57 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:56:57 --> Utf8 Class Initialized
INFO - 2016-05-08 10:56:57 --> URI Class Initialized
INFO - 2016-05-08 10:56:57 --> Router Class Initialized
INFO - 2016-05-08 10:56:57 --> Output Class Initialized
INFO - 2016-05-08 10:56:57 --> Security Class Initialized
DEBUG - 2016-05-08 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:56:57 --> Input Class Initialized
INFO - 2016-05-08 10:56:57 --> Language Class Initialized
INFO - 2016-05-08 10:56:57 --> Loader Class Initialized
INFO - 2016-05-08 10:56:57 --> Helper loaded: url_helper
INFO - 2016-05-08 10:56:57 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:56:57 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:56:57 --> Helper loaded: form_helper
INFO - 2016-05-08 10:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:56:57 --> Form Validation Class Initialized
INFO - 2016-05-08 10:56:57 --> Controller Class Initialized
INFO - 2016-05-08 10:56:57 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:56:57 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:56:57 --> Model Class Initialized
INFO - 2016-05-08 10:56:57 --> Database Driver Class Initialized
INFO - 2016-05-08 10:56:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-05-08 10:56:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:56:57 --> Final output sent to browser
DEBUG - 2016-05-08 10:56:57 --> Total execution time: 0.1233
INFO - 2016-05-08 10:57:03 --> Config Class Initialized
INFO - 2016-05-08 10:57:03 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:57:03 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:57:03 --> Utf8 Class Initialized
INFO - 2016-05-08 10:57:03 --> URI Class Initialized
INFO - 2016-05-08 10:57:03 --> Router Class Initialized
INFO - 2016-05-08 10:57:03 --> Output Class Initialized
INFO - 2016-05-08 10:57:03 --> Security Class Initialized
DEBUG - 2016-05-08 10:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:57:03 --> Input Class Initialized
INFO - 2016-05-08 10:57:03 --> Language Class Initialized
INFO - 2016-05-08 10:57:03 --> Loader Class Initialized
INFO - 2016-05-08 10:57:03 --> Helper loaded: url_helper
INFO - 2016-05-08 10:57:03 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:57:03 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:57:03 --> Helper loaded: form_helper
INFO - 2016-05-08 10:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:57:03 --> Form Validation Class Initialized
INFO - 2016-05-08 10:57:03 --> Controller Class Initialized
INFO - 2016-05-08 10:57:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:57:03 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:57:03 --> Model Class Initialized
INFO - 2016-05-08 10:57:03 --> Database Driver Class Initialized
INFO - 2016-05-08 10:57:03 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 10:57:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-05-08 10:57:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:57:03 --> Final output sent to browser
DEBUG - 2016-05-08 10:57:03 --> Total execution time: 0.1156
INFO - 2016-05-08 10:57:10 --> Config Class Initialized
INFO - 2016-05-08 10:57:10 --> Hooks Class Initialized
DEBUG - 2016-05-08 10:57:10 --> UTF-8 Support Enabled
INFO - 2016-05-08 10:57:10 --> Utf8 Class Initialized
INFO - 2016-05-08 10:57:10 --> URI Class Initialized
INFO - 2016-05-08 10:57:10 --> Router Class Initialized
INFO - 2016-05-08 10:57:10 --> Output Class Initialized
INFO - 2016-05-08 10:57:10 --> Security Class Initialized
DEBUG - 2016-05-08 10:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 10:57:10 --> Input Class Initialized
INFO - 2016-05-08 10:57:10 --> Language Class Initialized
INFO - 2016-05-08 10:57:10 --> Loader Class Initialized
INFO - 2016-05-08 10:57:10 --> Helper loaded: url_helper
INFO - 2016-05-08 10:57:10 --> Helper loaded: sesion_helper
INFO - 2016-05-08 10:57:10 --> Helper loaded: templates_helper
INFO - 2016-05-08 10:57:10 --> Helper loaded: form_helper
INFO - 2016-05-08 10:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 10:57:10 --> Form Validation Class Initialized
INFO - 2016-05-08 10:57:10 --> Controller Class Initialized
INFO - 2016-05-08 10:57:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 10:57:10 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 10:57:10 --> Model Class Initialized
INFO - 2016-05-08 10:57:10 --> Database Driver Class Initialized
INFO - 2016-05-08 10:57:10 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 10:57:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-05-08 10:57:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 10:57:10 --> Final output sent to browser
DEBUG - 2016-05-08 10:57:10 --> Total execution time: 0.1615
INFO - 2016-05-08 11:06:18 --> Config Class Initialized
INFO - 2016-05-08 11:06:18 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:06:18 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:06:18 --> Utf8 Class Initialized
INFO - 2016-05-08 11:06:18 --> URI Class Initialized
INFO - 2016-05-08 11:06:18 --> Router Class Initialized
INFO - 2016-05-08 11:06:18 --> Output Class Initialized
INFO - 2016-05-08 11:06:18 --> Security Class Initialized
DEBUG - 2016-05-08 11:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:06:18 --> Input Class Initialized
INFO - 2016-05-08 11:06:18 --> Language Class Initialized
INFO - 2016-05-08 11:06:18 --> Loader Class Initialized
INFO - 2016-05-08 11:06:18 --> Helper loaded: url_helper
INFO - 2016-05-08 11:06:18 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:06:18 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:06:18 --> Helper loaded: form_helper
INFO - 2016-05-08 11:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:06:18 --> Form Validation Class Initialized
INFO - 2016-05-08 11:06:18 --> Controller Class Initialized
INFO - 2016-05-08 11:06:18 --> Model Class Initialized
INFO - 2016-05-08 11:06:18 --> Database Driver Class Initialized
INFO - 2016-05-08 11:06:18 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:06:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:06:18 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:06:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:06:18 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:06:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:06:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:06:18 --> Final output sent to browser
DEBUG - 2016-05-08 11:06:18 --> Total execution time: 0.0985
INFO - 2016-05-08 11:06:20 --> Config Class Initialized
INFO - 2016-05-08 11:06:20 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:06:20 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:06:20 --> Utf8 Class Initialized
INFO - 2016-05-08 11:06:20 --> URI Class Initialized
INFO - 2016-05-08 11:06:20 --> Router Class Initialized
INFO - 2016-05-08 11:06:20 --> Output Class Initialized
INFO - 2016-05-08 11:06:20 --> Security Class Initialized
DEBUG - 2016-05-08 11:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:06:20 --> Input Class Initialized
INFO - 2016-05-08 11:06:20 --> Language Class Initialized
INFO - 2016-05-08 11:06:20 --> Loader Class Initialized
INFO - 2016-05-08 11:06:20 --> Helper loaded: url_helper
INFO - 2016-05-08 11:06:20 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:06:20 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:06:20 --> Helper loaded: form_helper
INFO - 2016-05-08 11:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:06:20 --> Form Validation Class Initialized
INFO - 2016-05-08 11:06:20 --> Controller Class Initialized
INFO - 2016-05-08 11:06:20 --> Model Class Initialized
INFO - 2016-05-08 11:06:20 --> Database Driver Class Initialized
INFO - 2016-05-08 11:06:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:06:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:06:20 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:06:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:06:20 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:06:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:06:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:06:20 --> Final output sent to browser
DEBUG - 2016-05-08 11:06:20 --> Total execution time: 0.0989
INFO - 2016-05-08 11:06:23 --> Config Class Initialized
INFO - 2016-05-08 11:06:23 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:06:23 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:06:23 --> Utf8 Class Initialized
INFO - 2016-05-08 11:06:23 --> URI Class Initialized
INFO - 2016-05-08 11:06:23 --> Router Class Initialized
INFO - 2016-05-08 11:06:23 --> Output Class Initialized
INFO - 2016-05-08 11:06:23 --> Security Class Initialized
DEBUG - 2016-05-08 11:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:06:23 --> Input Class Initialized
INFO - 2016-05-08 11:06:23 --> Language Class Initialized
INFO - 2016-05-08 11:06:23 --> Loader Class Initialized
INFO - 2016-05-08 11:06:23 --> Helper loaded: url_helper
INFO - 2016-05-08 11:06:23 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:06:23 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:06:23 --> Helper loaded: form_helper
INFO - 2016-05-08 11:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:06:23 --> Form Validation Class Initialized
INFO - 2016-05-08 11:06:23 --> Controller Class Initialized
INFO - 2016-05-08 11:06:23 --> Model Class Initialized
INFO - 2016-05-08 11:06:23 --> Database Driver Class Initialized
INFO - 2016-05-08 11:06:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:06:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:06:23 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:06:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:06:23 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 11:06:23 --> Severity: Notice --> Undefined variable: selectProvincias C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php 82
INFO - 2016-05-08 11:06:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:06:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:06:23 --> Final output sent to browser
DEBUG - 2016-05-08 11:06:23 --> Total execution time: 0.1352
INFO - 2016-05-08 11:07:04 --> Config Class Initialized
INFO - 2016-05-08 11:07:04 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:07:04 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:07:04 --> Utf8 Class Initialized
INFO - 2016-05-08 11:07:04 --> URI Class Initialized
INFO - 2016-05-08 11:07:04 --> Router Class Initialized
INFO - 2016-05-08 11:07:04 --> Output Class Initialized
INFO - 2016-05-08 11:07:04 --> Security Class Initialized
DEBUG - 2016-05-08 11:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:07:04 --> Input Class Initialized
INFO - 2016-05-08 11:07:04 --> Language Class Initialized
INFO - 2016-05-08 11:07:05 --> Loader Class Initialized
INFO - 2016-05-08 11:07:05 --> Helper loaded: url_helper
INFO - 2016-05-08 11:07:05 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:07:05 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:07:05 --> Helper loaded: form_helper
INFO - 2016-05-08 11:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:07:05 --> Form Validation Class Initialized
INFO - 2016-05-08 11:07:05 --> Controller Class Initialized
INFO - 2016-05-08 11:07:05 --> Model Class Initialized
INFO - 2016-05-08 11:07:05 --> Database Driver Class Initialized
INFO - 2016-05-08 11:07:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:07:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:07:05 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:07:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:07:05 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:07:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:07:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:07:05 --> Final output sent to browser
DEBUG - 2016-05-08 11:07:05 --> Total execution time: 0.0904
INFO - 2016-05-08 11:07:23 --> Config Class Initialized
INFO - 2016-05-08 11:07:23 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:07:23 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:07:23 --> Utf8 Class Initialized
INFO - 2016-05-08 11:07:23 --> URI Class Initialized
INFO - 2016-05-08 11:07:23 --> Router Class Initialized
INFO - 2016-05-08 11:07:23 --> Output Class Initialized
INFO - 2016-05-08 11:07:23 --> Security Class Initialized
DEBUG - 2016-05-08 11:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:07:23 --> Input Class Initialized
INFO - 2016-05-08 11:07:23 --> Language Class Initialized
INFO - 2016-05-08 11:07:23 --> Loader Class Initialized
INFO - 2016-05-08 11:07:23 --> Helper loaded: url_helper
INFO - 2016-05-08 11:07:23 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:07:23 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:07:23 --> Helper loaded: form_helper
INFO - 2016-05-08 11:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:07:23 --> Form Validation Class Initialized
INFO - 2016-05-08 11:07:23 --> Controller Class Initialized
INFO - 2016-05-08 11:07:23 --> Model Class Initialized
INFO - 2016-05-08 11:07:23 --> Database Driver Class Initialized
INFO - 2016-05-08 11:07:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:07:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:07:23 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:07:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:07:23 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:07:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:07:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:07:23 --> Final output sent to browser
DEBUG - 2016-05-08 11:07:23 --> Total execution time: 0.0862
INFO - 2016-05-08 11:07:26 --> Config Class Initialized
INFO - 2016-05-08 11:07:26 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:07:26 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:07:26 --> Utf8 Class Initialized
INFO - 2016-05-08 11:07:26 --> URI Class Initialized
INFO - 2016-05-08 11:07:26 --> Router Class Initialized
INFO - 2016-05-08 11:07:26 --> Output Class Initialized
INFO - 2016-05-08 11:07:26 --> Security Class Initialized
DEBUG - 2016-05-08 11:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:07:26 --> Input Class Initialized
INFO - 2016-05-08 11:07:26 --> Language Class Initialized
INFO - 2016-05-08 11:07:26 --> Loader Class Initialized
INFO - 2016-05-08 11:07:26 --> Helper loaded: url_helper
INFO - 2016-05-08 11:07:26 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:07:26 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:07:26 --> Helper loaded: form_helper
INFO - 2016-05-08 11:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:07:26 --> Form Validation Class Initialized
INFO - 2016-05-08 11:07:26 --> Controller Class Initialized
INFO - 2016-05-08 11:07:26 --> Model Class Initialized
INFO - 2016-05-08 11:07:27 --> Database Driver Class Initialized
INFO - 2016-05-08 11:07:27 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:07:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:07:27 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:07:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:07:27 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:07:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:07:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:07:27 --> Final output sent to browser
DEBUG - 2016-05-08 11:07:27 --> Total execution time: 0.1620
INFO - 2016-05-08 11:07:32 --> Config Class Initialized
INFO - 2016-05-08 11:07:32 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:07:32 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:07:32 --> Utf8 Class Initialized
INFO - 2016-05-08 11:07:32 --> URI Class Initialized
INFO - 2016-05-08 11:07:32 --> Router Class Initialized
INFO - 2016-05-08 11:07:32 --> Output Class Initialized
INFO - 2016-05-08 11:07:32 --> Security Class Initialized
DEBUG - 2016-05-08 11:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:07:32 --> Input Class Initialized
INFO - 2016-05-08 11:07:32 --> Language Class Initialized
INFO - 2016-05-08 11:07:32 --> Loader Class Initialized
INFO - 2016-05-08 11:07:32 --> Helper loaded: url_helper
INFO - 2016-05-08 11:07:32 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:07:32 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:07:32 --> Helper loaded: form_helper
INFO - 2016-05-08 11:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:07:32 --> Form Validation Class Initialized
INFO - 2016-05-08 11:07:32 --> Controller Class Initialized
INFO - 2016-05-08 11:07:32 --> Model Class Initialized
INFO - 2016-05-08 11:07:32 --> Database Driver Class Initialized
INFO - 2016-05-08 11:07:32 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:07:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:07:32 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:07:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:07:32 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:07:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:07:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:07:32 --> Final output sent to browser
DEBUG - 2016-05-08 11:07:32 --> Total execution time: 0.0756
INFO - 2016-05-08 11:07:35 --> Config Class Initialized
INFO - 2016-05-08 11:07:35 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:07:35 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:07:35 --> Utf8 Class Initialized
INFO - 2016-05-08 11:07:35 --> URI Class Initialized
INFO - 2016-05-08 11:07:35 --> Router Class Initialized
INFO - 2016-05-08 11:07:35 --> Output Class Initialized
INFO - 2016-05-08 11:07:35 --> Security Class Initialized
DEBUG - 2016-05-08 11:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:07:35 --> Input Class Initialized
INFO - 2016-05-08 11:07:35 --> Language Class Initialized
INFO - 2016-05-08 11:07:35 --> Loader Class Initialized
INFO - 2016-05-08 11:07:35 --> Helper loaded: url_helper
INFO - 2016-05-08 11:07:35 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:07:35 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:07:35 --> Helper loaded: form_helper
INFO - 2016-05-08 11:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:07:35 --> Form Validation Class Initialized
INFO - 2016-05-08 11:07:35 --> Controller Class Initialized
INFO - 2016-05-08 11:07:35 --> Model Class Initialized
INFO - 2016-05-08 11:07:35 --> Database Driver Class Initialized
INFO - 2016-05-08 11:07:35 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:07:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:07:35 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:07:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:07:35 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:07:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:07:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:07:35 --> Final output sent to browser
DEBUG - 2016-05-08 11:07:35 --> Total execution time: 0.1119
INFO - 2016-05-08 11:07:38 --> Config Class Initialized
INFO - 2016-05-08 11:07:38 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:07:38 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:07:38 --> Utf8 Class Initialized
INFO - 2016-05-08 11:07:38 --> URI Class Initialized
INFO - 2016-05-08 11:07:38 --> Router Class Initialized
INFO - 2016-05-08 11:07:38 --> Output Class Initialized
INFO - 2016-05-08 11:07:38 --> Security Class Initialized
DEBUG - 2016-05-08 11:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:07:38 --> Input Class Initialized
INFO - 2016-05-08 11:07:38 --> Language Class Initialized
INFO - 2016-05-08 11:07:38 --> Loader Class Initialized
INFO - 2016-05-08 11:07:38 --> Helper loaded: url_helper
INFO - 2016-05-08 11:07:38 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:07:38 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:07:38 --> Helper loaded: form_helper
INFO - 2016-05-08 11:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:07:38 --> Form Validation Class Initialized
INFO - 2016-05-08 11:07:38 --> Controller Class Initialized
INFO - 2016-05-08 11:07:38 --> Model Class Initialized
INFO - 2016-05-08 11:07:38 --> Database Driver Class Initialized
INFO - 2016-05-08 11:07:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:07:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:07:38 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:07:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:07:38 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:07:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:07:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:07:38 --> Final output sent to browser
DEBUG - 2016-05-08 11:07:38 --> Total execution time: 0.0813
INFO - 2016-05-08 11:07:40 --> Config Class Initialized
INFO - 2016-05-08 11:07:40 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:07:40 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:07:40 --> Utf8 Class Initialized
INFO - 2016-05-08 11:07:40 --> URI Class Initialized
INFO - 2016-05-08 11:07:40 --> Router Class Initialized
INFO - 2016-05-08 11:07:40 --> Output Class Initialized
INFO - 2016-05-08 11:07:40 --> Security Class Initialized
DEBUG - 2016-05-08 11:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:07:40 --> Input Class Initialized
INFO - 2016-05-08 11:07:40 --> Language Class Initialized
INFO - 2016-05-08 11:07:40 --> Loader Class Initialized
INFO - 2016-05-08 11:07:40 --> Helper loaded: url_helper
INFO - 2016-05-08 11:07:40 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:07:40 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:07:40 --> Helper loaded: form_helper
INFO - 2016-05-08 11:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:07:40 --> Form Validation Class Initialized
INFO - 2016-05-08 11:07:40 --> Controller Class Initialized
INFO - 2016-05-08 11:07:40 --> Model Class Initialized
INFO - 2016-05-08 11:07:40 --> Database Driver Class Initialized
INFO - 2016-05-08 11:07:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:07:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:07:40 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:07:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:07:40 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:07:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:07:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:07:40 --> Final output sent to browser
DEBUG - 2016-05-08 11:07:40 --> Total execution time: 0.1363
INFO - 2016-05-08 11:07:43 --> Config Class Initialized
INFO - 2016-05-08 11:07:43 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:07:43 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:07:43 --> Utf8 Class Initialized
INFO - 2016-05-08 11:07:43 --> URI Class Initialized
INFO - 2016-05-08 11:07:43 --> Router Class Initialized
INFO - 2016-05-08 11:07:43 --> Output Class Initialized
INFO - 2016-05-08 11:07:43 --> Security Class Initialized
DEBUG - 2016-05-08 11:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:07:43 --> Input Class Initialized
INFO - 2016-05-08 11:07:43 --> Language Class Initialized
INFO - 2016-05-08 11:07:43 --> Loader Class Initialized
INFO - 2016-05-08 11:07:43 --> Helper loaded: url_helper
INFO - 2016-05-08 11:07:43 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:07:43 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:07:43 --> Helper loaded: form_helper
INFO - 2016-05-08 11:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:07:43 --> Form Validation Class Initialized
INFO - 2016-05-08 11:07:43 --> Controller Class Initialized
INFO - 2016-05-08 11:07:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:07:43 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:07:43 --> Model Class Initialized
INFO - 2016-05-08 11:07:43 --> Database Driver Class Initialized
INFO - 2016-05-08 11:07:43 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 11:07:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-05-08 11:07:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:07:43 --> Final output sent to browser
DEBUG - 2016-05-08 11:07:43 --> Total execution time: 0.1188
INFO - 2016-05-08 11:08:13 --> Config Class Initialized
INFO - 2016-05-08 11:08:13 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:08:13 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:08:13 --> Utf8 Class Initialized
INFO - 2016-05-08 11:08:13 --> URI Class Initialized
INFO - 2016-05-08 11:08:13 --> Router Class Initialized
INFO - 2016-05-08 11:08:13 --> Output Class Initialized
INFO - 2016-05-08 11:08:13 --> Security Class Initialized
DEBUG - 2016-05-08 11:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:08:13 --> Input Class Initialized
INFO - 2016-05-08 11:08:13 --> Language Class Initialized
INFO - 2016-05-08 11:08:13 --> Loader Class Initialized
INFO - 2016-05-08 11:08:13 --> Helper loaded: url_helper
INFO - 2016-05-08 11:08:13 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:08:13 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:08:13 --> Helper loaded: form_helper
INFO - 2016-05-08 11:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:08:13 --> Form Validation Class Initialized
INFO - 2016-05-08 11:08:13 --> Controller Class Initialized
INFO - 2016-05-08 11:08:13 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:08:13 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:08:13 --> Model Class Initialized
INFO - 2016-05-08 11:08:13 --> Database Driver Class Initialized
INFO - 2016-05-08 11:08:13 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 11:08:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-05-08 11:08:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:08:13 --> Final output sent to browser
DEBUG - 2016-05-08 11:08:13 --> Total execution time: 0.1590
INFO - 2016-05-08 11:08:14 --> Config Class Initialized
INFO - 2016-05-08 11:08:14 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:08:14 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:08:14 --> Utf8 Class Initialized
INFO - 2016-05-08 11:08:14 --> URI Class Initialized
INFO - 2016-05-08 11:08:14 --> Router Class Initialized
INFO - 2016-05-08 11:08:14 --> Output Class Initialized
INFO - 2016-05-08 11:08:14 --> Security Class Initialized
DEBUG - 2016-05-08 11:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:08:14 --> Input Class Initialized
INFO - 2016-05-08 11:08:14 --> Language Class Initialized
INFO - 2016-05-08 11:08:14 --> Loader Class Initialized
INFO - 2016-05-08 11:08:14 --> Helper loaded: url_helper
INFO - 2016-05-08 11:08:14 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:08:14 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:08:14 --> Helper loaded: form_helper
INFO - 2016-05-08 11:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:08:14 --> Form Validation Class Initialized
INFO - 2016-05-08 11:08:14 --> Controller Class Initialized
INFO - 2016-05-08 11:08:14 --> Model Class Initialized
INFO - 2016-05-08 11:08:14 --> Database Driver Class Initialized
INFO - 2016-05-08 11:08:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:08:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:08:14 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:08:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:08:14 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:08:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:08:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:08:14 --> Final output sent to browser
DEBUG - 2016-05-08 11:08:14 --> Total execution time: 0.0826
INFO - 2016-05-08 11:08:15 --> Config Class Initialized
INFO - 2016-05-08 11:08:15 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:08:15 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:08:15 --> Utf8 Class Initialized
INFO - 2016-05-08 11:08:15 --> URI Class Initialized
INFO - 2016-05-08 11:08:15 --> Router Class Initialized
INFO - 2016-05-08 11:08:15 --> Output Class Initialized
INFO - 2016-05-08 11:08:15 --> Security Class Initialized
DEBUG - 2016-05-08 11:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:08:15 --> Input Class Initialized
INFO - 2016-05-08 11:08:15 --> Language Class Initialized
INFO - 2016-05-08 11:08:15 --> Loader Class Initialized
INFO - 2016-05-08 11:08:15 --> Helper loaded: url_helper
INFO - 2016-05-08 11:08:15 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:08:15 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:08:15 --> Helper loaded: form_helper
INFO - 2016-05-08 11:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:08:15 --> Form Validation Class Initialized
INFO - 2016-05-08 11:08:15 --> Controller Class Initialized
INFO - 2016-05-08 11:08:15 --> Model Class Initialized
INFO - 2016-05-08 11:08:15 --> Database Driver Class Initialized
INFO - 2016-05-08 11:08:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:08:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:08:15 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:08:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:08:15 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:08:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:08:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:08:15 --> Final output sent to browser
DEBUG - 2016-05-08 11:08:15 --> Total execution time: 0.1020
INFO - 2016-05-08 11:08:18 --> Config Class Initialized
INFO - 2016-05-08 11:08:18 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:08:18 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:08:18 --> Utf8 Class Initialized
INFO - 2016-05-08 11:08:18 --> URI Class Initialized
INFO - 2016-05-08 11:08:18 --> Router Class Initialized
INFO - 2016-05-08 11:08:18 --> Output Class Initialized
INFO - 2016-05-08 11:08:18 --> Security Class Initialized
DEBUG - 2016-05-08 11:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:08:18 --> Input Class Initialized
INFO - 2016-05-08 11:08:18 --> Language Class Initialized
INFO - 2016-05-08 11:08:18 --> Loader Class Initialized
INFO - 2016-05-08 11:08:18 --> Helper loaded: url_helper
INFO - 2016-05-08 11:08:18 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:08:18 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:08:18 --> Helper loaded: form_helper
INFO - 2016-05-08 11:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:08:18 --> Form Validation Class Initialized
INFO - 2016-05-08 11:08:18 --> Controller Class Initialized
INFO - 2016-05-08 11:08:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-08 11:08:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:08:18 --> Final output sent to browser
DEBUG - 2016-05-08 11:08:18 --> Total execution time: 0.0958
INFO - 2016-05-08 11:08:24 --> Config Class Initialized
INFO - 2016-05-08 11:08:24 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:08:24 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:08:24 --> Utf8 Class Initialized
INFO - 2016-05-08 11:08:24 --> URI Class Initialized
INFO - 2016-05-08 11:08:24 --> Router Class Initialized
INFO - 2016-05-08 11:08:24 --> Output Class Initialized
INFO - 2016-05-08 11:08:24 --> Security Class Initialized
DEBUG - 2016-05-08 11:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:08:24 --> Input Class Initialized
INFO - 2016-05-08 11:08:24 --> Language Class Initialized
INFO - 2016-05-08 11:08:24 --> Loader Class Initialized
INFO - 2016-05-08 11:08:24 --> Helper loaded: url_helper
INFO - 2016-05-08 11:08:24 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:08:24 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:08:24 --> Helper loaded: form_helper
INFO - 2016-05-08 11:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:08:24 --> Form Validation Class Initialized
INFO - 2016-05-08 11:08:24 --> Controller Class Initialized
INFO - 2016-05-08 11:08:24 --> Model Class Initialized
INFO - 2016-05-08 11:08:24 --> Database Driver Class Initialized
INFO - 2016-05-08 11:08:24 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:08:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:08:24 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:08:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:08:24 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:08:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:08:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:08:24 --> Final output sent to browser
DEBUG - 2016-05-08 11:08:24 --> Total execution time: 0.0823
INFO - 2016-05-08 11:08:26 --> Config Class Initialized
INFO - 2016-05-08 11:08:26 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:08:26 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:08:26 --> Utf8 Class Initialized
INFO - 2016-05-08 11:08:26 --> URI Class Initialized
INFO - 2016-05-08 11:08:26 --> Router Class Initialized
INFO - 2016-05-08 11:08:26 --> Output Class Initialized
INFO - 2016-05-08 11:08:26 --> Security Class Initialized
DEBUG - 2016-05-08 11:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:08:26 --> Input Class Initialized
INFO - 2016-05-08 11:08:26 --> Language Class Initialized
INFO - 2016-05-08 11:08:26 --> Loader Class Initialized
INFO - 2016-05-08 11:08:26 --> Helper loaded: url_helper
INFO - 2016-05-08 11:08:26 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:08:26 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:08:26 --> Helper loaded: form_helper
INFO - 2016-05-08 11:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:08:26 --> Form Validation Class Initialized
INFO - 2016-05-08 11:08:26 --> Controller Class Initialized
INFO - 2016-05-08 11:08:26 --> Model Class Initialized
INFO - 2016-05-08 11:08:26 --> Database Driver Class Initialized
INFO - 2016-05-08 11:08:26 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:08:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:08:26 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:08:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:08:26 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:08:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:08:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:08:26 --> Final output sent to browser
DEBUG - 2016-05-08 11:08:26 --> Total execution time: 0.1149
INFO - 2016-05-08 11:08:34 --> Config Class Initialized
INFO - 2016-05-08 11:08:34 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:08:34 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:08:34 --> Utf8 Class Initialized
INFO - 2016-05-08 11:08:34 --> URI Class Initialized
INFO - 2016-05-08 11:08:34 --> Router Class Initialized
INFO - 2016-05-08 11:08:34 --> Output Class Initialized
INFO - 2016-05-08 11:08:34 --> Security Class Initialized
DEBUG - 2016-05-08 11:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:08:34 --> Input Class Initialized
INFO - 2016-05-08 11:08:34 --> Language Class Initialized
INFO - 2016-05-08 11:08:34 --> Loader Class Initialized
INFO - 2016-05-08 11:08:34 --> Helper loaded: url_helper
INFO - 2016-05-08 11:08:34 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:08:34 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:08:34 --> Helper loaded: form_helper
INFO - 2016-05-08 11:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:08:34 --> Form Validation Class Initialized
INFO - 2016-05-08 11:08:34 --> Controller Class Initialized
INFO - 2016-05-08 11:08:34 --> Model Class Initialized
INFO - 2016-05-08 11:08:34 --> Database Driver Class Initialized
INFO - 2016-05-08 11:08:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:08:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:08:34 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:08:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:08:34 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:08:34 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 11:08:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:08:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:08:35 --> Final output sent to browser
DEBUG - 2016-05-08 11:08:35 --> Total execution time: 0.2494
INFO - 2016-05-08 11:08:41 --> Config Class Initialized
INFO - 2016-05-08 11:08:41 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:08:41 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:08:41 --> Utf8 Class Initialized
INFO - 2016-05-08 11:08:41 --> URI Class Initialized
INFO - 2016-05-08 11:08:41 --> Router Class Initialized
INFO - 2016-05-08 11:08:41 --> Output Class Initialized
INFO - 2016-05-08 11:08:41 --> Security Class Initialized
DEBUG - 2016-05-08 11:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:08:41 --> Input Class Initialized
INFO - 2016-05-08 11:08:41 --> Language Class Initialized
INFO - 2016-05-08 11:08:41 --> Loader Class Initialized
INFO - 2016-05-08 11:08:41 --> Helper loaded: url_helper
INFO - 2016-05-08 11:08:41 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:08:41 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:08:41 --> Helper loaded: form_helper
INFO - 2016-05-08 11:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:08:41 --> Form Validation Class Initialized
INFO - 2016-05-08 11:08:41 --> Controller Class Initialized
INFO - 2016-05-08 11:08:41 --> Model Class Initialized
INFO - 2016-05-08 11:08:41 --> Database Driver Class Initialized
INFO - 2016-05-08 11:08:41 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:08:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:08:41 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:08:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:08:41 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:08:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:08:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:08:41 --> Final output sent to browser
DEBUG - 2016-05-08 11:08:41 --> Total execution time: 0.1336
INFO - 2016-05-08 11:09:28 --> Config Class Initialized
INFO - 2016-05-08 11:09:28 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:09:28 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:09:28 --> Utf8 Class Initialized
INFO - 2016-05-08 11:09:28 --> URI Class Initialized
INFO - 2016-05-08 11:09:28 --> Router Class Initialized
INFO - 2016-05-08 11:09:28 --> Output Class Initialized
INFO - 2016-05-08 11:09:28 --> Security Class Initialized
DEBUG - 2016-05-08 11:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:09:28 --> Input Class Initialized
INFO - 2016-05-08 11:09:28 --> Language Class Initialized
INFO - 2016-05-08 11:09:28 --> Loader Class Initialized
INFO - 2016-05-08 11:09:28 --> Helper loaded: url_helper
INFO - 2016-05-08 11:09:28 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:09:28 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:09:28 --> Helper loaded: form_helper
INFO - 2016-05-08 11:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:09:28 --> Form Validation Class Initialized
INFO - 2016-05-08 11:09:28 --> Controller Class Initialized
INFO - 2016-05-08 11:09:28 --> Model Class Initialized
INFO - 2016-05-08 11:09:28 --> Database Driver Class Initialized
INFO - 2016-05-08 11:09:28 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:09:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:09:28 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:09:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:09:28 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:09:28 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 11:09:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:09:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:09:28 --> Final output sent to browser
DEBUG - 2016-05-08 11:09:28 --> Total execution time: 0.1850
INFO - 2016-05-08 11:09:41 --> Config Class Initialized
INFO - 2016-05-08 11:09:41 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:09:41 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:09:41 --> Utf8 Class Initialized
INFO - 2016-05-08 11:09:41 --> URI Class Initialized
INFO - 2016-05-08 11:09:41 --> Router Class Initialized
INFO - 2016-05-08 11:09:41 --> Output Class Initialized
INFO - 2016-05-08 11:09:41 --> Security Class Initialized
DEBUG - 2016-05-08 11:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:09:42 --> Input Class Initialized
INFO - 2016-05-08 11:09:42 --> Language Class Initialized
INFO - 2016-05-08 11:09:42 --> Loader Class Initialized
INFO - 2016-05-08 11:09:42 --> Helper loaded: url_helper
INFO - 2016-05-08 11:09:42 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:09:42 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:09:42 --> Helper loaded: form_helper
INFO - 2016-05-08 11:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:09:42 --> Form Validation Class Initialized
INFO - 2016-05-08 11:09:42 --> Controller Class Initialized
INFO - 2016-05-08 11:09:42 --> Model Class Initialized
INFO - 2016-05-08 11:09:42 --> Database Driver Class Initialized
INFO - 2016-05-08 11:09:42 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:09:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:09:42 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:09:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:09:42 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:09:42 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 11:09:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:09:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:09:42 --> Final output sent to browser
DEBUG - 2016-05-08 11:09:42 --> Total execution time: 0.1327
INFO - 2016-05-08 11:09:51 --> Config Class Initialized
INFO - 2016-05-08 11:09:51 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:09:51 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:09:51 --> Utf8 Class Initialized
INFO - 2016-05-08 11:09:51 --> URI Class Initialized
INFO - 2016-05-08 11:09:51 --> Router Class Initialized
INFO - 2016-05-08 11:09:51 --> Output Class Initialized
INFO - 2016-05-08 11:09:51 --> Security Class Initialized
DEBUG - 2016-05-08 11:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:09:51 --> Input Class Initialized
INFO - 2016-05-08 11:09:51 --> Language Class Initialized
INFO - 2016-05-08 11:09:51 --> Loader Class Initialized
INFO - 2016-05-08 11:09:51 --> Helper loaded: url_helper
INFO - 2016-05-08 11:09:51 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:09:51 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:09:51 --> Helper loaded: form_helper
INFO - 2016-05-08 11:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:09:51 --> Form Validation Class Initialized
INFO - 2016-05-08 11:09:51 --> Controller Class Initialized
INFO - 2016-05-08 11:09:51 --> Model Class Initialized
INFO - 2016-05-08 11:09:51 --> Database Driver Class Initialized
INFO - 2016-05-08 11:09:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:09:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:09:51 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:09:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:09:51 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:09:51 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 11:09:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:09:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:09:52 --> Final output sent to browser
DEBUG - 2016-05-08 11:09:52 --> Total execution time: 0.2004
INFO - 2016-05-08 11:09:53 --> Config Class Initialized
INFO - 2016-05-08 11:09:53 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:09:53 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:09:53 --> Utf8 Class Initialized
INFO - 2016-05-08 11:09:53 --> URI Class Initialized
INFO - 2016-05-08 11:09:53 --> Router Class Initialized
INFO - 2016-05-08 11:09:53 --> Output Class Initialized
INFO - 2016-05-08 11:09:53 --> Security Class Initialized
DEBUG - 2016-05-08 11:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:09:53 --> Input Class Initialized
INFO - 2016-05-08 11:09:53 --> Language Class Initialized
INFO - 2016-05-08 11:09:53 --> Loader Class Initialized
INFO - 2016-05-08 11:09:53 --> Helper loaded: url_helper
INFO - 2016-05-08 11:09:53 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:09:53 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:09:53 --> Helper loaded: form_helper
INFO - 2016-05-08 11:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:09:53 --> Form Validation Class Initialized
INFO - 2016-05-08 11:09:53 --> Controller Class Initialized
INFO - 2016-05-08 11:09:53 --> Model Class Initialized
INFO - 2016-05-08 11:09:53 --> Database Driver Class Initialized
INFO - 2016-05-08 11:09:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:09:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:09:53 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:09:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:09:53 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:09:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:09:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:09:53 --> Final output sent to browser
DEBUG - 2016-05-08 11:09:53 --> Total execution time: 0.1133
INFO - 2016-05-08 11:10:00 --> Config Class Initialized
INFO - 2016-05-08 11:10:00 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:10:00 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:10:00 --> Utf8 Class Initialized
INFO - 2016-05-08 11:10:00 --> URI Class Initialized
INFO - 2016-05-08 11:10:00 --> Router Class Initialized
INFO - 2016-05-08 11:10:01 --> Output Class Initialized
INFO - 2016-05-08 11:10:01 --> Security Class Initialized
DEBUG - 2016-05-08 11:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:10:01 --> Input Class Initialized
INFO - 2016-05-08 11:10:01 --> Language Class Initialized
INFO - 2016-05-08 11:10:01 --> Loader Class Initialized
INFO - 2016-05-08 11:10:01 --> Helper loaded: url_helper
INFO - 2016-05-08 11:10:01 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:10:01 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:10:01 --> Helper loaded: form_helper
INFO - 2016-05-08 11:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:10:01 --> Form Validation Class Initialized
INFO - 2016-05-08 11:10:01 --> Controller Class Initialized
INFO - 2016-05-08 11:10:01 --> Model Class Initialized
INFO - 2016-05-08 11:10:01 --> Database Driver Class Initialized
INFO - 2016-05-08 11:10:01 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:10:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:10:01 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:10:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:10:01 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:10:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:10:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:10:01 --> Final output sent to browser
DEBUG - 2016-05-08 11:10:01 --> Total execution time: 0.1123
INFO - 2016-05-08 11:10:05 --> Config Class Initialized
INFO - 2016-05-08 11:10:05 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:10:05 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:10:05 --> Utf8 Class Initialized
INFO - 2016-05-08 11:10:05 --> URI Class Initialized
INFO - 2016-05-08 11:10:05 --> Router Class Initialized
INFO - 2016-05-08 11:10:05 --> Output Class Initialized
INFO - 2016-05-08 11:10:05 --> Security Class Initialized
DEBUG - 2016-05-08 11:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:10:05 --> Input Class Initialized
INFO - 2016-05-08 11:10:05 --> Language Class Initialized
INFO - 2016-05-08 11:10:05 --> Loader Class Initialized
INFO - 2016-05-08 11:10:05 --> Helper loaded: url_helper
INFO - 2016-05-08 11:10:05 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:10:05 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:10:05 --> Helper loaded: form_helper
INFO - 2016-05-08 11:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:10:05 --> Form Validation Class Initialized
INFO - 2016-05-08 11:10:05 --> Controller Class Initialized
INFO - 2016-05-08 11:10:05 --> Model Class Initialized
INFO - 2016-05-08 11:10:05 --> Database Driver Class Initialized
INFO - 2016-05-08 11:10:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:10:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:10:05 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:10:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:10:05 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:10:05 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 11:10:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:10:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:10:05 --> Final output sent to browser
DEBUG - 2016-05-08 11:10:05 --> Total execution time: 0.2699
INFO - 2016-05-08 11:10:22 --> Config Class Initialized
INFO - 2016-05-08 11:10:22 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:10:22 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:10:22 --> Utf8 Class Initialized
INFO - 2016-05-08 11:10:22 --> URI Class Initialized
INFO - 2016-05-08 11:10:22 --> Router Class Initialized
INFO - 2016-05-08 11:10:22 --> Output Class Initialized
INFO - 2016-05-08 11:10:22 --> Security Class Initialized
DEBUG - 2016-05-08 11:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:10:22 --> Input Class Initialized
INFO - 2016-05-08 11:10:22 --> Language Class Initialized
INFO - 2016-05-08 11:10:22 --> Loader Class Initialized
INFO - 2016-05-08 11:10:22 --> Helper loaded: url_helper
INFO - 2016-05-08 11:10:22 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:10:22 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:10:22 --> Helper loaded: form_helper
INFO - 2016-05-08 11:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:10:22 --> Form Validation Class Initialized
INFO - 2016-05-08 11:10:22 --> Controller Class Initialized
INFO - 2016-05-08 11:10:22 --> Model Class Initialized
INFO - 2016-05-08 11:10:22 --> Database Driver Class Initialized
INFO - 2016-05-08 11:10:22 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:10:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:10:22 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:10:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:10:22 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:10:22 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 11:10:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:10:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:10:22 --> Final output sent to browser
DEBUG - 2016-05-08 11:10:22 --> Total execution time: 0.1441
INFO - 2016-05-08 11:10:32 --> Config Class Initialized
INFO - 2016-05-08 11:10:32 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:10:32 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:10:32 --> Utf8 Class Initialized
INFO - 2016-05-08 11:10:32 --> URI Class Initialized
INFO - 2016-05-08 11:10:32 --> Router Class Initialized
INFO - 2016-05-08 11:10:32 --> Output Class Initialized
INFO - 2016-05-08 11:10:32 --> Security Class Initialized
DEBUG - 2016-05-08 11:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:10:32 --> Input Class Initialized
INFO - 2016-05-08 11:10:32 --> Language Class Initialized
INFO - 2016-05-08 11:10:32 --> Loader Class Initialized
INFO - 2016-05-08 11:10:32 --> Helper loaded: url_helper
INFO - 2016-05-08 11:10:32 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:10:32 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:10:32 --> Helper loaded: form_helper
INFO - 2016-05-08 11:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:10:32 --> Form Validation Class Initialized
INFO - 2016-05-08 11:10:32 --> Controller Class Initialized
INFO - 2016-05-08 11:10:32 --> Model Class Initialized
INFO - 2016-05-08 11:10:32 --> Database Driver Class Initialized
INFO - 2016-05-08 11:10:32 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:10:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:10:32 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:10:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:10:32 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:10:32 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 11:10:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:10:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:10:32 --> Final output sent to browser
DEBUG - 2016-05-08 11:10:32 --> Total execution time: 0.1552
INFO - 2016-05-08 11:11:03 --> Config Class Initialized
INFO - 2016-05-08 11:11:03 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:11:03 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:11:03 --> Utf8 Class Initialized
INFO - 2016-05-08 11:11:03 --> URI Class Initialized
INFO - 2016-05-08 11:11:03 --> Router Class Initialized
INFO - 2016-05-08 11:11:03 --> Output Class Initialized
INFO - 2016-05-08 11:11:03 --> Security Class Initialized
DEBUG - 2016-05-08 11:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:11:03 --> Input Class Initialized
INFO - 2016-05-08 11:11:03 --> Language Class Initialized
INFO - 2016-05-08 11:11:03 --> Loader Class Initialized
INFO - 2016-05-08 11:11:03 --> Helper loaded: url_helper
INFO - 2016-05-08 11:11:03 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:11:03 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:11:03 --> Helper loaded: form_helper
INFO - 2016-05-08 11:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:11:03 --> Form Validation Class Initialized
INFO - 2016-05-08 11:11:03 --> Controller Class Initialized
INFO - 2016-05-08 11:11:03 --> Model Class Initialized
INFO - 2016-05-08 11:11:03 --> Database Driver Class Initialized
INFO - 2016-05-08 11:11:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:11:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:11:03 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:11:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:11:03 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:11:03 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 11:11:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCliente.php
INFO - 2016-05-08 11:11:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:11:03 --> Final output sent to browser
DEBUG - 2016-05-08 11:11:03 --> Total execution time: 0.2543
INFO - 2016-05-08 11:11:06 --> Config Class Initialized
INFO - 2016-05-08 11:11:06 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:11:06 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:11:06 --> Utf8 Class Initialized
INFO - 2016-05-08 11:11:06 --> URI Class Initialized
INFO - 2016-05-08 11:11:06 --> Router Class Initialized
INFO - 2016-05-08 11:11:06 --> Output Class Initialized
INFO - 2016-05-08 11:11:06 --> Security Class Initialized
DEBUG - 2016-05-08 11:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:11:06 --> Input Class Initialized
INFO - 2016-05-08 11:11:06 --> Language Class Initialized
INFO - 2016-05-08 11:11:06 --> Loader Class Initialized
INFO - 2016-05-08 11:11:06 --> Helper loaded: url_helper
INFO - 2016-05-08 11:11:06 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:11:06 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:11:06 --> Helper loaded: form_helper
INFO - 2016-05-08 11:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:11:06 --> Form Validation Class Initialized
INFO - 2016-05-08 11:11:06 --> Controller Class Initialized
INFO - 2016-05-08 11:11:06 --> Model Class Initialized
INFO - 2016-05-08 11:11:06 --> Database Driver Class Initialized
INFO - 2016-05-08 11:11:06 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:11:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:11:06 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:11:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:11:06 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:11:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:11:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:11:06 --> Final output sent to browser
DEBUG - 2016-05-08 11:11:06 --> Total execution time: 0.1293
INFO - 2016-05-08 11:18:32 --> Config Class Initialized
INFO - 2016-05-08 11:18:32 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:18:32 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:18:32 --> Utf8 Class Initialized
INFO - 2016-05-08 11:18:32 --> URI Class Initialized
INFO - 2016-05-08 11:18:32 --> Router Class Initialized
INFO - 2016-05-08 11:18:32 --> Output Class Initialized
INFO - 2016-05-08 11:18:32 --> Security Class Initialized
DEBUG - 2016-05-08 11:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:18:32 --> Input Class Initialized
INFO - 2016-05-08 11:18:32 --> Language Class Initialized
INFO - 2016-05-08 11:18:32 --> Loader Class Initialized
INFO - 2016-05-08 11:18:32 --> Helper loaded: url_helper
INFO - 2016-05-08 11:18:32 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:18:32 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:18:32 --> Helper loaded: form_helper
INFO - 2016-05-08 11:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:18:32 --> Form Validation Class Initialized
INFO - 2016-05-08 11:18:32 --> Controller Class Initialized
INFO - 2016-05-08 11:18:32 --> Model Class Initialized
INFO - 2016-05-08 11:18:32 --> Database Driver Class Initialized
INFO - 2016-05-08 11:18:32 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:18:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:18:32 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:18:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:18:32 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:18:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:18:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:18:32 --> Final output sent to browser
DEBUG - 2016-05-08 11:18:32 --> Total execution time: 0.1005
INFO - 2016-05-08 11:18:37 --> Config Class Initialized
INFO - 2016-05-08 11:18:37 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:18:37 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:18:37 --> Utf8 Class Initialized
INFO - 2016-05-08 11:18:37 --> URI Class Initialized
INFO - 2016-05-08 11:18:37 --> Router Class Initialized
INFO - 2016-05-08 11:18:37 --> Output Class Initialized
INFO - 2016-05-08 11:18:37 --> Security Class Initialized
DEBUG - 2016-05-08 11:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:18:37 --> Input Class Initialized
INFO - 2016-05-08 11:18:37 --> Language Class Initialized
INFO - 2016-05-08 11:18:37 --> Loader Class Initialized
INFO - 2016-05-08 11:18:37 --> Helper loaded: url_helper
INFO - 2016-05-08 11:18:37 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:18:37 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:18:37 --> Helper loaded: form_helper
INFO - 2016-05-08 11:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:18:37 --> Form Validation Class Initialized
INFO - 2016-05-08 11:18:37 --> Controller Class Initialized
INFO - 2016-05-08 11:18:37 --> Model Class Initialized
INFO - 2016-05-08 11:18:37 --> Database Driver Class Initialized
INFO - 2016-05-08 11:18:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:18:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:18:37 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:18:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:18:37 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 11:18:37 --> Query error: Table 'bdproyecto.idprovincia' doesn't exist - Invalid query: SELECT count(*) 'cont' FROM cliente c INNER JOIN provincia p ON p.idProvincia=c,idProvincia WHERE c.nombre LIKE '%minorista%' OR c.nif LIKE '%minorista%' OR c.correo LIKE '%minorista%' OR c.direccion LIKE '%minorista%' OR c.localidad LIKE '%minorista%' OR c.cp LIKE '%minorista%' OR c.cuenta_corriente LIKE '%minorista%' OR c.tipo LIKE '%minorista%' OR c.anotaciones LIKE '%minorista%' OR c.estado LIKE '%minorista%' OR p.nombre LIKE '%minorista%'
INFO - 2016-05-08 11:18:37 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-08 11:19:00 --> Config Class Initialized
INFO - 2016-05-08 11:19:00 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:19:00 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:19:00 --> Utf8 Class Initialized
INFO - 2016-05-08 11:19:00 --> URI Class Initialized
INFO - 2016-05-08 11:19:00 --> Router Class Initialized
INFO - 2016-05-08 11:19:00 --> Output Class Initialized
INFO - 2016-05-08 11:19:00 --> Security Class Initialized
DEBUG - 2016-05-08 11:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:19:00 --> Input Class Initialized
INFO - 2016-05-08 11:19:00 --> Language Class Initialized
INFO - 2016-05-08 11:19:00 --> Loader Class Initialized
INFO - 2016-05-08 11:19:00 --> Helper loaded: url_helper
INFO - 2016-05-08 11:19:00 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:19:00 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:19:00 --> Helper loaded: form_helper
INFO - 2016-05-08 11:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:19:00 --> Form Validation Class Initialized
INFO - 2016-05-08 11:19:00 --> Controller Class Initialized
INFO - 2016-05-08 11:19:00 --> Model Class Initialized
INFO - 2016-05-08 11:19:00 --> Database Driver Class Initialized
INFO - 2016-05-08 11:19:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:19:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:19:00 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:19:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:19:00 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-08 11:19:00 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 49
ERROR - 2016-05-08 11:19:00 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 50
ERROR - 2016-05-08 11:19:00 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 54
ERROR - 2016-05-08 11:19:00 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 57
ERROR - 2016-05-08 11:19:00 --> Severity: Notice --> Undefined index: idProveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php 72
INFO - 2016-05-08 11:19:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 11:19:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:19:00 --> Final output sent to browser
DEBUG - 2016-05-08 11:19:00 --> Total execution time: 0.0999
INFO - 2016-05-08 11:20:36 --> Config Class Initialized
INFO - 2016-05-08 11:20:36 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:20:36 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:20:36 --> Utf8 Class Initialized
INFO - 2016-05-08 11:20:36 --> URI Class Initialized
INFO - 2016-05-08 11:20:36 --> Router Class Initialized
INFO - 2016-05-08 11:20:36 --> Output Class Initialized
INFO - 2016-05-08 11:20:36 --> Security Class Initialized
DEBUG - 2016-05-08 11:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:20:36 --> Input Class Initialized
INFO - 2016-05-08 11:20:36 --> Language Class Initialized
INFO - 2016-05-08 11:20:36 --> Loader Class Initialized
INFO - 2016-05-08 11:20:36 --> Helper loaded: url_helper
INFO - 2016-05-08 11:20:36 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:20:36 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:20:36 --> Helper loaded: form_helper
INFO - 2016-05-08 11:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:20:36 --> Form Validation Class Initialized
INFO - 2016-05-08 11:20:36 --> Controller Class Initialized
INFO - 2016-05-08 11:20:36 --> Model Class Initialized
INFO - 2016-05-08 11:20:36 --> Database Driver Class Initialized
INFO - 2016-05-08 11:20:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:20:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:20:36 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:20:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:20:36 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:20:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:20:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:20:36 --> Final output sent to browser
DEBUG - 2016-05-08 11:20:36 --> Total execution time: 0.0817
INFO - 2016-05-08 11:20:43 --> Config Class Initialized
INFO - 2016-05-08 11:20:43 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:20:43 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:20:43 --> Utf8 Class Initialized
INFO - 2016-05-08 11:20:43 --> URI Class Initialized
INFO - 2016-05-08 11:20:43 --> Router Class Initialized
INFO - 2016-05-08 11:20:43 --> Output Class Initialized
INFO - 2016-05-08 11:20:43 --> Security Class Initialized
DEBUG - 2016-05-08 11:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:20:43 --> Input Class Initialized
INFO - 2016-05-08 11:20:43 --> Language Class Initialized
INFO - 2016-05-08 11:20:43 --> Loader Class Initialized
INFO - 2016-05-08 11:20:43 --> Helper loaded: url_helper
INFO - 2016-05-08 11:20:43 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:20:43 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:20:43 --> Helper loaded: form_helper
INFO - 2016-05-08 11:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:20:43 --> Form Validation Class Initialized
INFO - 2016-05-08 11:20:43 --> Controller Class Initialized
INFO - 2016-05-08 11:20:43 --> Model Class Initialized
INFO - 2016-05-08 11:20:43 --> Database Driver Class Initialized
INFO - 2016-05-08 11:20:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:20:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:20:43 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:20:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:20:43 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:20:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:20:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:20:43 --> Final output sent to browser
DEBUG - 2016-05-08 11:20:43 --> Total execution time: 0.0954
INFO - 2016-05-08 11:20:50 --> Config Class Initialized
INFO - 2016-05-08 11:20:50 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:20:50 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:20:50 --> Utf8 Class Initialized
INFO - 2016-05-08 11:20:50 --> URI Class Initialized
INFO - 2016-05-08 11:20:50 --> Router Class Initialized
INFO - 2016-05-08 11:20:50 --> Output Class Initialized
INFO - 2016-05-08 11:20:50 --> Security Class Initialized
DEBUG - 2016-05-08 11:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:20:50 --> Input Class Initialized
INFO - 2016-05-08 11:20:50 --> Language Class Initialized
INFO - 2016-05-08 11:20:50 --> Loader Class Initialized
INFO - 2016-05-08 11:20:50 --> Helper loaded: url_helper
INFO - 2016-05-08 11:20:50 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:20:50 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:20:50 --> Helper loaded: form_helper
INFO - 2016-05-08 11:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:20:50 --> Form Validation Class Initialized
INFO - 2016-05-08 11:20:50 --> Controller Class Initialized
INFO - 2016-05-08 11:20:50 --> Model Class Initialized
INFO - 2016-05-08 11:20:50 --> Database Driver Class Initialized
INFO - 2016-05-08 11:20:50 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:20:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:20:50 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:20:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:20:50 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:20:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:20:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:20:50 --> Final output sent to browser
DEBUG - 2016-05-08 11:20:50 --> Total execution time: 0.0973
INFO - 2016-05-08 11:21:00 --> Config Class Initialized
INFO - 2016-05-08 11:21:00 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:21:00 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:21:00 --> Utf8 Class Initialized
INFO - 2016-05-08 11:21:00 --> URI Class Initialized
INFO - 2016-05-08 11:21:00 --> Router Class Initialized
INFO - 2016-05-08 11:21:00 --> Output Class Initialized
INFO - 2016-05-08 11:21:00 --> Security Class Initialized
DEBUG - 2016-05-08 11:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:21:00 --> Input Class Initialized
INFO - 2016-05-08 11:21:00 --> Language Class Initialized
INFO - 2016-05-08 11:21:00 --> Loader Class Initialized
INFO - 2016-05-08 11:21:00 --> Helper loaded: url_helper
INFO - 2016-05-08 11:21:00 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:21:00 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:21:00 --> Helper loaded: form_helper
INFO - 2016-05-08 11:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:21:00 --> Form Validation Class Initialized
INFO - 2016-05-08 11:21:00 --> Controller Class Initialized
INFO - 2016-05-08 11:21:00 --> Model Class Initialized
INFO - 2016-05-08 11:21:00 --> Database Driver Class Initialized
INFO - 2016-05-08 11:21:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:21:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:21:00 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:21:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:21:00 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:21:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:21:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:21:00 --> Final output sent to browser
DEBUG - 2016-05-08 11:21:00 --> Total execution time: 0.0983
INFO - 2016-05-08 11:21:04 --> Config Class Initialized
INFO - 2016-05-08 11:21:04 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:21:04 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:21:04 --> Utf8 Class Initialized
INFO - 2016-05-08 11:21:04 --> URI Class Initialized
INFO - 2016-05-08 11:21:04 --> Router Class Initialized
INFO - 2016-05-08 11:21:04 --> Output Class Initialized
INFO - 2016-05-08 11:21:04 --> Security Class Initialized
DEBUG - 2016-05-08 11:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:21:04 --> Input Class Initialized
INFO - 2016-05-08 11:21:04 --> Language Class Initialized
INFO - 2016-05-08 11:21:04 --> Loader Class Initialized
INFO - 2016-05-08 11:21:04 --> Helper loaded: url_helper
INFO - 2016-05-08 11:21:04 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:21:04 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:21:04 --> Helper loaded: form_helper
INFO - 2016-05-08 11:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:21:04 --> Form Validation Class Initialized
INFO - 2016-05-08 11:21:04 --> Controller Class Initialized
INFO - 2016-05-08 11:21:04 --> Model Class Initialized
INFO - 2016-05-08 11:21:04 --> Database Driver Class Initialized
INFO - 2016-05-08 11:21:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:21:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:21:04 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:21:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:21:04 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:21:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 11:21:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:21:04 --> Final output sent to browser
DEBUG - 2016-05-08 11:21:04 --> Total execution time: 0.0978
INFO - 2016-05-08 11:21:22 --> Config Class Initialized
INFO - 2016-05-08 11:21:22 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:21:22 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:21:22 --> Utf8 Class Initialized
INFO - 2016-05-08 11:21:22 --> URI Class Initialized
INFO - 2016-05-08 11:21:22 --> Router Class Initialized
INFO - 2016-05-08 11:21:22 --> Output Class Initialized
INFO - 2016-05-08 11:21:22 --> Security Class Initialized
DEBUG - 2016-05-08 11:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:21:22 --> Input Class Initialized
INFO - 2016-05-08 11:21:22 --> Language Class Initialized
INFO - 2016-05-08 11:21:22 --> Loader Class Initialized
INFO - 2016-05-08 11:21:22 --> Helper loaded: url_helper
INFO - 2016-05-08 11:21:22 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:21:22 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:21:22 --> Helper loaded: form_helper
INFO - 2016-05-08 11:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:21:22 --> Form Validation Class Initialized
INFO - 2016-05-08 11:21:22 --> Controller Class Initialized
INFO - 2016-05-08 11:21:22 --> Model Class Initialized
INFO - 2016-05-08 11:21:22 --> Database Driver Class Initialized
INFO - 2016-05-08 11:21:22 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:21:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:21:22 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:21:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:21:22 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:21:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:21:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:21:22 --> Final output sent to browser
DEBUG - 2016-05-08 11:21:22 --> Total execution time: 0.0879
INFO - 2016-05-08 11:21:24 --> Config Class Initialized
INFO - 2016-05-08 11:21:24 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:21:24 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:21:24 --> Utf8 Class Initialized
INFO - 2016-05-08 11:21:24 --> URI Class Initialized
INFO - 2016-05-08 11:21:24 --> Router Class Initialized
INFO - 2016-05-08 11:21:24 --> Output Class Initialized
INFO - 2016-05-08 11:21:24 --> Security Class Initialized
DEBUG - 2016-05-08 11:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:21:24 --> Input Class Initialized
INFO - 2016-05-08 11:21:24 --> Language Class Initialized
INFO - 2016-05-08 11:21:24 --> Loader Class Initialized
INFO - 2016-05-08 11:21:24 --> Helper loaded: url_helper
INFO - 2016-05-08 11:21:24 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:21:24 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:21:24 --> Helper loaded: form_helper
INFO - 2016-05-08 11:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:21:24 --> Form Validation Class Initialized
INFO - 2016-05-08 11:21:24 --> Controller Class Initialized
INFO - 2016-05-08 11:21:24 --> Model Class Initialized
INFO - 2016-05-08 11:21:24 --> Database Driver Class Initialized
INFO - 2016-05-08 11:21:24 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:21:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:21:24 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:21:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:21:24 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:21:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:21:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:21:24 --> Final output sent to browser
DEBUG - 2016-05-08 11:21:24 --> Total execution time: 0.1047
INFO - 2016-05-08 11:21:25 --> Config Class Initialized
INFO - 2016-05-08 11:21:25 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:21:25 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:21:25 --> Utf8 Class Initialized
INFO - 2016-05-08 11:21:25 --> URI Class Initialized
INFO - 2016-05-08 11:21:25 --> Router Class Initialized
INFO - 2016-05-08 11:21:25 --> Output Class Initialized
INFO - 2016-05-08 11:21:25 --> Security Class Initialized
DEBUG - 2016-05-08 11:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:21:25 --> Input Class Initialized
INFO - 2016-05-08 11:21:25 --> Language Class Initialized
INFO - 2016-05-08 11:21:25 --> Loader Class Initialized
INFO - 2016-05-08 11:21:25 --> Helper loaded: url_helper
INFO - 2016-05-08 11:21:25 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:21:25 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:21:25 --> Helper loaded: form_helper
INFO - 2016-05-08 11:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:21:25 --> Form Validation Class Initialized
INFO - 2016-05-08 11:21:25 --> Controller Class Initialized
INFO - 2016-05-08 11:21:25 --> Model Class Initialized
INFO - 2016-05-08 11:21:25 --> Database Driver Class Initialized
INFO - 2016-05-08 11:21:25 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:21:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:21:25 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:21:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:21:25 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 11:21:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-08 11:21:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:21:25 --> Final output sent to browser
DEBUG - 2016-05-08 11:21:25 --> Total execution time: 0.0934
INFO - 2016-05-08 11:21:28 --> Config Class Initialized
INFO - 2016-05-08 11:21:28 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:21:28 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:21:28 --> Utf8 Class Initialized
INFO - 2016-05-08 11:21:28 --> URI Class Initialized
INFO - 2016-05-08 11:21:28 --> Router Class Initialized
INFO - 2016-05-08 11:21:28 --> Output Class Initialized
INFO - 2016-05-08 11:21:28 --> Security Class Initialized
DEBUG - 2016-05-08 11:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:21:28 --> Input Class Initialized
INFO - 2016-05-08 11:21:28 --> Language Class Initialized
INFO - 2016-05-08 11:21:28 --> Loader Class Initialized
INFO - 2016-05-08 11:21:28 --> Helper loaded: url_helper
INFO - 2016-05-08 11:21:28 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:21:28 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:21:28 --> Helper loaded: form_helper
INFO - 2016-05-08 11:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:21:28 --> Form Validation Class Initialized
INFO - 2016-05-08 11:21:28 --> Controller Class Initialized
INFO - 2016-05-08 11:21:28 --> Model Class Initialized
INFO - 2016-05-08 11:21:28 --> Database Driver Class Initialized
INFO - 2016-05-08 11:21:28 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:21:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:21:28 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:21:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:21:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 11:21:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:21:28 --> Final output sent to browser
DEBUG - 2016-05-08 11:21:28 --> Total execution time: 0.1002
INFO - 2016-05-08 11:21:30 --> Config Class Initialized
INFO - 2016-05-08 11:21:30 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:21:30 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:21:30 --> Utf8 Class Initialized
INFO - 2016-05-08 11:21:30 --> URI Class Initialized
INFO - 2016-05-08 11:21:30 --> Router Class Initialized
INFO - 2016-05-08 11:21:30 --> Output Class Initialized
INFO - 2016-05-08 11:21:30 --> Security Class Initialized
DEBUG - 2016-05-08 11:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:21:30 --> Input Class Initialized
INFO - 2016-05-08 11:21:30 --> Language Class Initialized
INFO - 2016-05-08 11:21:30 --> Loader Class Initialized
INFO - 2016-05-08 11:21:30 --> Helper loaded: url_helper
INFO - 2016-05-08 11:21:30 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:21:30 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:21:30 --> Helper loaded: form_helper
INFO - 2016-05-08 11:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:21:30 --> Form Validation Class Initialized
INFO - 2016-05-08 11:21:30 --> Controller Class Initialized
INFO - 2016-05-08 11:21:30 --> Model Class Initialized
INFO - 2016-05-08 11:21:30 --> Database Driver Class Initialized
INFO - 2016-05-08 11:21:30 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:21:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:21:30 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:21:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-08 11:21:30 --> Query error: Unknown column 'prod.referencia' in 'where clause' - Invalid query: SELECT count(*) 'cont' FROM producto prodINNER JOIN categoria cat ON prod.idCategoria=cat.idCategoria INNER JOIN proveedor prv ON prod.idProveedor=prv.idProveedor WHERE prod.referencia LIKE '%ñkjfsd%' OR prod.nombre LIKE '%ñkjfsd%' OR prod.marca LIKE '%ñkjfsd%' OR prod.precio LIKE '%ñkjfsd%' OR prod.precio_venta LIKE '%ñkjfsd%' OR prod.iva LIKE '%ñkjfsd%' OR prod.stock LIKE '%ñkjfsd%' OR prod.descripcion LIKE '%ñkjfsd%' OR prod.estado LIKE '%ñkjfsd%' OR cat.nombre LIKE '%ñkjfsd%' OR prv.nombre LIKE '%ñkjfsd%'
INFO - 2016-05-08 11:21:30 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-08 11:22:10 --> Config Class Initialized
INFO - 2016-05-08 11:22:10 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:22:10 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:22:10 --> Utf8 Class Initialized
INFO - 2016-05-08 11:22:10 --> URI Class Initialized
INFO - 2016-05-08 11:22:10 --> Router Class Initialized
INFO - 2016-05-08 11:22:10 --> Output Class Initialized
INFO - 2016-05-08 11:22:10 --> Security Class Initialized
DEBUG - 2016-05-08 11:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:22:10 --> Input Class Initialized
INFO - 2016-05-08 11:22:10 --> Language Class Initialized
INFO - 2016-05-08 11:22:10 --> Loader Class Initialized
INFO - 2016-05-08 11:22:10 --> Helper loaded: url_helper
INFO - 2016-05-08 11:22:10 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:22:10 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:22:10 --> Helper loaded: form_helper
INFO - 2016-05-08 11:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:22:10 --> Form Validation Class Initialized
INFO - 2016-05-08 11:22:10 --> Controller Class Initialized
INFO - 2016-05-08 11:22:10 --> Model Class Initialized
INFO - 2016-05-08 11:22:10 --> Database Driver Class Initialized
INFO - 2016-05-08 11:22:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:22:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:22:10 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:22:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:22:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-08 11:22:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:22:10 --> Final output sent to browser
DEBUG - 2016-05-08 11:22:10 --> Total execution time: 0.0836
INFO - 2016-05-08 11:22:13 --> Config Class Initialized
INFO - 2016-05-08 11:22:13 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:22:13 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:22:13 --> Utf8 Class Initialized
INFO - 2016-05-08 11:22:13 --> URI Class Initialized
INFO - 2016-05-08 11:22:13 --> Router Class Initialized
INFO - 2016-05-08 11:22:13 --> Output Class Initialized
INFO - 2016-05-08 11:22:13 --> Security Class Initialized
DEBUG - 2016-05-08 11:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:22:13 --> Input Class Initialized
INFO - 2016-05-08 11:22:13 --> Language Class Initialized
INFO - 2016-05-08 11:22:13 --> Loader Class Initialized
INFO - 2016-05-08 11:22:13 --> Helper loaded: url_helper
INFO - 2016-05-08 11:22:13 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:22:13 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:22:13 --> Helper loaded: form_helper
INFO - 2016-05-08 11:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:22:13 --> Form Validation Class Initialized
INFO - 2016-05-08 11:22:13 --> Controller Class Initialized
INFO - 2016-05-08 11:22:13 --> Model Class Initialized
INFO - 2016-05-08 11:22:13 --> Database Driver Class Initialized
INFO - 2016-05-08 11:22:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:22:13 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:22:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:22:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-08 11:22:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:22:13 --> Final output sent to browser
DEBUG - 2016-05-08 11:22:13 --> Total execution time: 0.0971
INFO - 2016-05-08 11:22:53 --> Config Class Initialized
INFO - 2016-05-08 11:22:53 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:22:53 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:22:53 --> Utf8 Class Initialized
INFO - 2016-05-08 11:22:53 --> URI Class Initialized
INFO - 2016-05-08 11:22:53 --> Router Class Initialized
INFO - 2016-05-08 11:22:53 --> Output Class Initialized
INFO - 2016-05-08 11:22:53 --> Security Class Initialized
DEBUG - 2016-05-08 11:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:22:53 --> Input Class Initialized
INFO - 2016-05-08 11:22:53 --> Language Class Initialized
INFO - 2016-05-08 11:22:53 --> Loader Class Initialized
INFO - 2016-05-08 11:22:53 --> Helper loaded: url_helper
INFO - 2016-05-08 11:22:53 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:22:53 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:22:53 --> Helper loaded: form_helper
INFO - 2016-05-08 11:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:22:53 --> Form Validation Class Initialized
INFO - 2016-05-08 11:22:53 --> Controller Class Initialized
INFO - 2016-05-08 11:22:53 --> Model Class Initialized
INFO - 2016-05-08 11:22:53 --> Database Driver Class Initialized
INFO - 2016-05-08 11:22:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:22:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:22:53 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:22:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:22:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-08 11:22:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:22:53 --> Final output sent to browser
DEBUG - 2016-05-08 11:22:53 --> Total execution time: 0.0804
INFO - 2016-05-08 11:22:57 --> Config Class Initialized
INFO - 2016-05-08 11:22:57 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:22:57 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:22:57 --> Utf8 Class Initialized
INFO - 2016-05-08 11:22:57 --> URI Class Initialized
INFO - 2016-05-08 11:22:57 --> Router Class Initialized
INFO - 2016-05-08 11:22:57 --> Output Class Initialized
INFO - 2016-05-08 11:22:57 --> Security Class Initialized
DEBUG - 2016-05-08 11:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:22:57 --> Input Class Initialized
INFO - 2016-05-08 11:22:57 --> Language Class Initialized
INFO - 2016-05-08 11:22:57 --> Loader Class Initialized
INFO - 2016-05-08 11:22:57 --> Helper loaded: url_helper
INFO - 2016-05-08 11:22:57 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:22:57 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:22:57 --> Helper loaded: form_helper
INFO - 2016-05-08 11:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:22:57 --> Form Validation Class Initialized
INFO - 2016-05-08 11:22:57 --> Controller Class Initialized
INFO - 2016-05-08 11:22:57 --> Model Class Initialized
INFO - 2016-05-08 11:22:57 --> Database Driver Class Initialized
INFO - 2016-05-08 11:22:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:22:57 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:22:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:22:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-08 11:22:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:22:57 --> Final output sent to browser
DEBUG - 2016-05-08 11:22:57 --> Total execution time: 0.0792
INFO - 2016-05-08 11:23:00 --> Config Class Initialized
INFO - 2016-05-08 11:23:00 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:23:00 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:23:00 --> Utf8 Class Initialized
INFO - 2016-05-08 11:23:00 --> URI Class Initialized
INFO - 2016-05-08 11:23:00 --> Router Class Initialized
INFO - 2016-05-08 11:23:00 --> Output Class Initialized
INFO - 2016-05-08 11:23:00 --> Security Class Initialized
DEBUG - 2016-05-08 11:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:23:00 --> Input Class Initialized
INFO - 2016-05-08 11:23:00 --> Language Class Initialized
INFO - 2016-05-08 11:23:00 --> Loader Class Initialized
INFO - 2016-05-08 11:23:00 --> Helper loaded: url_helper
INFO - 2016-05-08 11:23:00 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:23:00 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:23:00 --> Helper loaded: form_helper
INFO - 2016-05-08 11:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:23:00 --> Form Validation Class Initialized
INFO - 2016-05-08 11:23:00 --> Controller Class Initialized
INFO - 2016-05-08 11:23:00 --> Model Class Initialized
INFO - 2016-05-08 11:23:00 --> Database Driver Class Initialized
INFO - 2016-05-08 11:23:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:23:00 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:23:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:23:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-08 11:23:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:23:00 --> Final output sent to browser
DEBUG - 2016-05-08 11:23:00 --> Total execution time: 0.1077
INFO - 2016-05-08 11:23:06 --> Config Class Initialized
INFO - 2016-05-08 11:23:06 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:23:06 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:23:06 --> Utf8 Class Initialized
INFO - 2016-05-08 11:23:06 --> URI Class Initialized
INFO - 2016-05-08 11:23:06 --> Router Class Initialized
INFO - 2016-05-08 11:23:06 --> Output Class Initialized
INFO - 2016-05-08 11:23:06 --> Security Class Initialized
DEBUG - 2016-05-08 11:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:23:06 --> Input Class Initialized
INFO - 2016-05-08 11:23:06 --> Language Class Initialized
INFO - 2016-05-08 11:23:06 --> Loader Class Initialized
INFO - 2016-05-08 11:23:06 --> Helper loaded: url_helper
INFO - 2016-05-08 11:23:06 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:23:06 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:23:06 --> Helper loaded: form_helper
INFO - 2016-05-08 11:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:23:06 --> Form Validation Class Initialized
INFO - 2016-05-08 11:23:06 --> Controller Class Initialized
INFO - 2016-05-08 11:23:06 --> Model Class Initialized
INFO - 2016-05-08 11:23:06 --> Database Driver Class Initialized
INFO - 2016-05-08 11:23:06 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:23:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:23:06 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:23:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:23:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 11:23:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:23:06 --> Final output sent to browser
DEBUG - 2016-05-08 11:23:06 --> Total execution time: 0.1026
INFO - 2016-05-08 11:23:09 --> Config Class Initialized
INFO - 2016-05-08 11:23:09 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:23:09 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:23:09 --> Utf8 Class Initialized
INFO - 2016-05-08 11:23:09 --> URI Class Initialized
INFO - 2016-05-08 11:23:09 --> Router Class Initialized
INFO - 2016-05-08 11:23:09 --> Output Class Initialized
INFO - 2016-05-08 11:23:09 --> Security Class Initialized
DEBUG - 2016-05-08 11:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:23:09 --> Input Class Initialized
INFO - 2016-05-08 11:23:09 --> Language Class Initialized
INFO - 2016-05-08 11:23:09 --> Loader Class Initialized
INFO - 2016-05-08 11:23:09 --> Helper loaded: url_helper
INFO - 2016-05-08 11:23:09 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:23:09 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:23:09 --> Helper loaded: form_helper
INFO - 2016-05-08 11:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:23:09 --> Form Validation Class Initialized
INFO - 2016-05-08 11:23:09 --> Controller Class Initialized
INFO - 2016-05-08 11:23:09 --> Model Class Initialized
INFO - 2016-05-08 11:23:09 --> Database Driver Class Initialized
INFO - 2016-05-08 11:23:09 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 11:23:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:23:09 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:23:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:23:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-08 11:23:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:23:09 --> Final output sent to browser
DEBUG - 2016-05-08 11:23:09 --> Total execution time: 0.0819
INFO - 2016-05-08 11:31:22 --> Config Class Initialized
INFO - 2016-05-08 11:31:22 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:31:22 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:31:22 --> Utf8 Class Initialized
INFO - 2016-05-08 11:31:22 --> URI Class Initialized
INFO - 2016-05-08 11:31:23 --> Router Class Initialized
INFO - 2016-05-08 11:31:23 --> Output Class Initialized
INFO - 2016-05-08 11:31:23 --> Security Class Initialized
DEBUG - 2016-05-08 11:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:31:23 --> Input Class Initialized
INFO - 2016-05-08 11:31:23 --> Language Class Initialized
INFO - 2016-05-08 11:31:23 --> Loader Class Initialized
INFO - 2016-05-08 11:31:23 --> Helper loaded: url_helper
INFO - 2016-05-08 11:31:23 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:31:23 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:31:23 --> Helper loaded: form_helper
INFO - 2016-05-08 11:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:31:23 --> Form Validation Class Initialized
INFO - 2016-05-08 11:31:23 --> Controller Class Initialized
INFO - 2016-05-08 11:31:23 --> Model Class Initialized
INFO - 2016-05-08 11:31:23 --> Database Driver Class Initialized
INFO - 2016-05-08 11:31:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:31:23 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:31:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:31:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-08 11:31:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:31:23 --> Final output sent to browser
DEBUG - 2016-05-08 11:31:23 --> Total execution time: 0.1066
INFO - 2016-05-08 11:38:27 --> Config Class Initialized
INFO - 2016-05-08 11:38:27 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:38:27 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:38:27 --> Utf8 Class Initialized
INFO - 2016-05-08 11:38:27 --> URI Class Initialized
INFO - 2016-05-08 11:38:27 --> Router Class Initialized
INFO - 2016-05-08 11:38:27 --> Output Class Initialized
INFO - 2016-05-08 11:38:27 --> Security Class Initialized
DEBUG - 2016-05-08 11:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:38:27 --> Input Class Initialized
INFO - 2016-05-08 11:38:27 --> Language Class Initialized
INFO - 2016-05-08 11:38:27 --> Loader Class Initialized
INFO - 2016-05-08 11:38:27 --> Helper loaded: url_helper
INFO - 2016-05-08 11:38:27 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:38:27 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:38:27 --> Helper loaded: form_helper
INFO - 2016-05-08 11:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:38:27 --> Form Validation Class Initialized
INFO - 2016-05-08 11:38:27 --> Controller Class Initialized
INFO - 2016-05-08 11:38:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-08 11:38:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:38:27 --> Final output sent to browser
DEBUG - 2016-05-08 11:38:27 --> Total execution time: 0.0795
INFO - 2016-05-08 11:38:58 --> Config Class Initialized
INFO - 2016-05-08 11:38:58 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:38:58 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:38:58 --> Utf8 Class Initialized
INFO - 2016-05-08 11:38:58 --> URI Class Initialized
INFO - 2016-05-08 11:38:58 --> Router Class Initialized
INFO - 2016-05-08 11:38:58 --> Output Class Initialized
INFO - 2016-05-08 11:38:58 --> Security Class Initialized
DEBUG - 2016-05-08 11:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:38:58 --> Input Class Initialized
INFO - 2016-05-08 11:38:58 --> Language Class Initialized
INFO - 2016-05-08 11:38:58 --> Loader Class Initialized
INFO - 2016-05-08 11:38:58 --> Helper loaded: url_helper
INFO - 2016-05-08 11:38:58 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:38:58 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:38:58 --> Helper loaded: form_helper
INFO - 2016-05-08 11:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:38:58 --> Form Validation Class Initialized
INFO - 2016-05-08 11:38:58 --> Controller Class Initialized
INFO - 2016-05-08 11:38:58 --> Model Class Initialized
INFO - 2016-05-08 11:38:58 --> Database Driver Class Initialized
INFO - 2016-05-08 11:38:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:38:58 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:38:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-08 11:38:58 --> Severity: Notice --> Undefined index: nif C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php 44
ERROR - 2016-05-08 11:38:58 --> Severity: Notice --> Undefined index: telefono C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php 46
ERROR - 2016-05-08 11:38:58 --> Severity: Notice --> Undefined index: nif C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php 44
ERROR - 2016-05-08 11:38:58 --> Severity: Notice --> Undefined index: telefono C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php 46
INFO - 2016-05-08 11:38:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 11:38:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:38:58 --> Final output sent to browser
DEBUG - 2016-05-08 11:38:58 --> Total execution time: 0.1114
INFO - 2016-05-08 11:39:52 --> Config Class Initialized
INFO - 2016-05-08 11:39:52 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:39:52 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:39:52 --> Utf8 Class Initialized
INFO - 2016-05-08 11:39:52 --> URI Class Initialized
INFO - 2016-05-08 11:39:52 --> Router Class Initialized
INFO - 2016-05-08 11:39:52 --> Output Class Initialized
INFO - 2016-05-08 11:39:52 --> Security Class Initialized
DEBUG - 2016-05-08 11:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:39:52 --> Input Class Initialized
INFO - 2016-05-08 11:39:52 --> Language Class Initialized
INFO - 2016-05-08 11:39:52 --> Loader Class Initialized
INFO - 2016-05-08 11:39:52 --> Helper loaded: url_helper
INFO - 2016-05-08 11:39:52 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:39:52 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:39:52 --> Helper loaded: form_helper
INFO - 2016-05-08 11:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:39:52 --> Form Validation Class Initialized
INFO - 2016-05-08 11:39:52 --> Controller Class Initialized
INFO - 2016-05-08 11:39:52 --> Model Class Initialized
INFO - 2016-05-08 11:39:52 --> Database Driver Class Initialized
INFO - 2016-05-08 11:39:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:39:52 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:39:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:39:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 11:39:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:39:52 --> Final output sent to browser
DEBUG - 2016-05-08 11:39:52 --> Total execution time: 0.0782
INFO - 2016-05-08 11:40:00 --> Config Class Initialized
INFO - 2016-05-08 11:40:00 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:40:00 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:40:00 --> Utf8 Class Initialized
INFO - 2016-05-08 11:40:00 --> URI Class Initialized
INFO - 2016-05-08 11:40:00 --> Router Class Initialized
INFO - 2016-05-08 11:40:00 --> Output Class Initialized
INFO - 2016-05-08 11:40:00 --> Security Class Initialized
DEBUG - 2016-05-08 11:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:40:00 --> Input Class Initialized
INFO - 2016-05-08 11:40:00 --> Language Class Initialized
INFO - 2016-05-08 11:40:00 --> Loader Class Initialized
INFO - 2016-05-08 11:40:00 --> Helper loaded: url_helper
INFO - 2016-05-08 11:40:00 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:40:00 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:40:00 --> Helper loaded: form_helper
INFO - 2016-05-08 11:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:40:00 --> Form Validation Class Initialized
INFO - 2016-05-08 11:40:00 --> Controller Class Initialized
INFO - 2016-05-08 11:40:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-08 11:40:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:40:00 --> Final output sent to browser
DEBUG - 2016-05-08 11:40:00 --> Total execution time: 0.0502
INFO - 2016-05-08 11:40:05 --> Config Class Initialized
INFO - 2016-05-08 11:40:05 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:40:05 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:40:05 --> Utf8 Class Initialized
INFO - 2016-05-08 11:40:05 --> URI Class Initialized
INFO - 2016-05-08 11:40:05 --> Router Class Initialized
INFO - 2016-05-08 11:40:05 --> Output Class Initialized
INFO - 2016-05-08 11:40:05 --> Security Class Initialized
DEBUG - 2016-05-08 11:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:40:05 --> Input Class Initialized
INFO - 2016-05-08 11:40:05 --> Language Class Initialized
INFO - 2016-05-08 11:40:05 --> Loader Class Initialized
INFO - 2016-05-08 11:40:05 --> Helper loaded: url_helper
INFO - 2016-05-08 11:40:05 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:40:05 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:40:05 --> Helper loaded: form_helper
INFO - 2016-05-08 11:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:40:05 --> Form Validation Class Initialized
INFO - 2016-05-08 11:40:05 --> Controller Class Initialized
INFO - 2016-05-08 11:40:05 --> Model Class Initialized
INFO - 2016-05-08 11:40:05 --> Database Driver Class Initialized
INFO - 2016-05-08 11:40:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:40:05 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:40:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:40:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 11:40:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:40:05 --> Final output sent to browser
DEBUG - 2016-05-08 11:40:05 --> Total execution time: 0.1227
INFO - 2016-05-08 11:40:09 --> Config Class Initialized
INFO - 2016-05-08 11:40:09 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:40:09 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:40:09 --> Utf8 Class Initialized
INFO - 2016-05-08 11:40:09 --> URI Class Initialized
INFO - 2016-05-08 11:40:09 --> Router Class Initialized
INFO - 2016-05-08 11:40:09 --> Output Class Initialized
INFO - 2016-05-08 11:40:09 --> Security Class Initialized
DEBUG - 2016-05-08 11:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:40:09 --> Input Class Initialized
INFO - 2016-05-08 11:40:09 --> Language Class Initialized
INFO - 2016-05-08 11:40:09 --> Loader Class Initialized
INFO - 2016-05-08 11:40:09 --> Helper loaded: url_helper
INFO - 2016-05-08 11:40:09 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:40:09 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:40:09 --> Helper loaded: form_helper
INFO - 2016-05-08 11:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:40:09 --> Form Validation Class Initialized
INFO - 2016-05-08 11:40:09 --> Controller Class Initialized
INFO - 2016-05-08 11:40:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-08 11:40:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:40:09 --> Final output sent to browser
DEBUG - 2016-05-08 11:40:09 --> Total execution time: 0.0501
INFO - 2016-05-08 11:41:53 --> Config Class Initialized
INFO - 2016-05-08 11:41:53 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:41:53 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:41:53 --> Utf8 Class Initialized
INFO - 2016-05-08 11:41:53 --> URI Class Initialized
INFO - 2016-05-08 11:41:53 --> Router Class Initialized
INFO - 2016-05-08 11:41:53 --> Output Class Initialized
INFO - 2016-05-08 11:41:53 --> Security Class Initialized
DEBUG - 2016-05-08 11:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:41:53 --> Input Class Initialized
INFO - 2016-05-08 11:41:53 --> Language Class Initialized
INFO - 2016-05-08 11:41:53 --> Loader Class Initialized
INFO - 2016-05-08 11:41:53 --> Helper loaded: url_helper
INFO - 2016-05-08 11:41:53 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:41:53 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:41:53 --> Helper loaded: form_helper
INFO - 2016-05-08 11:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:41:53 --> Form Validation Class Initialized
INFO - 2016-05-08 11:41:53 --> Controller Class Initialized
INFO - 2016-05-08 11:41:53 --> Model Class Initialized
INFO - 2016-05-08 11:41:53 --> Database Driver Class Initialized
INFO - 2016-05-08 11:41:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:41:53 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:41:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:41:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 11:41:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:41:53 --> Final output sent to browser
DEBUG - 2016-05-08 11:41:53 --> Total execution time: 0.0769
INFO - 2016-05-08 11:41:56 --> Config Class Initialized
INFO - 2016-05-08 11:41:56 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:41:56 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:41:56 --> Utf8 Class Initialized
INFO - 2016-05-08 11:41:56 --> URI Class Initialized
INFO - 2016-05-08 11:41:56 --> Router Class Initialized
INFO - 2016-05-08 11:41:56 --> Output Class Initialized
INFO - 2016-05-08 11:41:56 --> Security Class Initialized
DEBUG - 2016-05-08 11:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:41:56 --> Input Class Initialized
INFO - 2016-05-08 11:41:56 --> Language Class Initialized
INFO - 2016-05-08 11:41:56 --> Loader Class Initialized
INFO - 2016-05-08 11:41:56 --> Helper loaded: url_helper
INFO - 2016-05-08 11:41:56 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:41:56 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:41:56 --> Helper loaded: form_helper
INFO - 2016-05-08 11:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:41:56 --> Form Validation Class Initialized
INFO - 2016-05-08 11:41:56 --> Controller Class Initialized
INFO - 2016-05-08 11:41:56 --> Model Class Initialized
INFO - 2016-05-08 11:41:56 --> Database Driver Class Initialized
INFO - 2016-05-08 11:41:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:41:56 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:41:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:41:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 11:41:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:41:56 --> Final output sent to browser
DEBUG - 2016-05-08 11:41:56 --> Total execution time: 0.0971
INFO - 2016-05-08 11:42:52 --> Config Class Initialized
INFO - 2016-05-08 11:42:52 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:42:52 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:42:52 --> Utf8 Class Initialized
INFO - 2016-05-08 11:42:52 --> URI Class Initialized
INFO - 2016-05-08 11:42:52 --> Router Class Initialized
INFO - 2016-05-08 11:42:52 --> Output Class Initialized
INFO - 2016-05-08 11:42:52 --> Security Class Initialized
DEBUG - 2016-05-08 11:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:42:52 --> Input Class Initialized
INFO - 2016-05-08 11:42:52 --> Language Class Initialized
INFO - 2016-05-08 11:42:52 --> Loader Class Initialized
INFO - 2016-05-08 11:42:52 --> Helper loaded: url_helper
INFO - 2016-05-08 11:42:52 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:42:52 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:42:52 --> Helper loaded: form_helper
INFO - 2016-05-08 11:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:42:52 --> Form Validation Class Initialized
INFO - 2016-05-08 11:42:52 --> Controller Class Initialized
INFO - 2016-05-08 11:42:52 --> Model Class Initialized
INFO - 2016-05-08 11:42:52 --> Database Driver Class Initialized
INFO - 2016-05-08 11:42:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:42:52 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:42:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:42:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 11:42:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:42:52 --> Final output sent to browser
DEBUG - 2016-05-08 11:42:52 --> Total execution time: 0.0782
INFO - 2016-05-08 11:43:01 --> Config Class Initialized
INFO - 2016-05-08 11:43:01 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:43:01 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:43:01 --> Utf8 Class Initialized
INFO - 2016-05-08 11:43:01 --> URI Class Initialized
INFO - 2016-05-08 11:43:01 --> Router Class Initialized
INFO - 2016-05-08 11:43:01 --> Output Class Initialized
INFO - 2016-05-08 11:43:01 --> Security Class Initialized
DEBUG - 2016-05-08 11:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:43:01 --> Input Class Initialized
INFO - 2016-05-08 11:43:01 --> Language Class Initialized
INFO - 2016-05-08 11:43:02 --> Loader Class Initialized
INFO - 2016-05-08 11:43:02 --> Helper loaded: url_helper
INFO - 2016-05-08 11:43:02 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:43:02 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:43:02 --> Helper loaded: form_helper
INFO - 2016-05-08 11:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:43:02 --> Form Validation Class Initialized
INFO - 2016-05-08 11:43:02 --> Controller Class Initialized
INFO - 2016-05-08 11:43:02 --> Model Class Initialized
INFO - 2016-05-08 11:43:02 --> Database Driver Class Initialized
INFO - 2016-05-08 11:43:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:43:02 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:43:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:43:02 --> Config Class Initialized
INFO - 2016-05-08 11:43:02 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:43:02 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:43:02 --> Utf8 Class Initialized
INFO - 2016-05-08 11:43:02 --> URI Class Initialized
INFO - 2016-05-08 11:43:02 --> Router Class Initialized
INFO - 2016-05-08 11:43:02 --> Output Class Initialized
INFO - 2016-05-08 11:43:02 --> Security Class Initialized
DEBUG - 2016-05-08 11:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:43:02 --> Input Class Initialized
INFO - 2016-05-08 11:43:02 --> Language Class Initialized
INFO - 2016-05-08 11:43:02 --> Loader Class Initialized
INFO - 2016-05-08 11:43:02 --> Helper loaded: url_helper
INFO - 2016-05-08 11:43:02 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:43:02 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:43:02 --> Helper loaded: form_helper
INFO - 2016-05-08 11:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:43:02 --> Form Validation Class Initialized
INFO - 2016-05-08 11:43:02 --> Controller Class Initialized
INFO - 2016-05-08 11:43:02 --> Model Class Initialized
INFO - 2016-05-08 11:43:02 --> Database Driver Class Initialized
INFO - 2016-05-08 11:43:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:43:02 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:43:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:43:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 11:43:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:43:02 --> Final output sent to browser
DEBUG - 2016-05-08 11:43:02 --> Total execution time: 0.0793
INFO - 2016-05-08 11:43:06 --> Config Class Initialized
INFO - 2016-05-08 11:43:06 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:43:06 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:43:06 --> Utf8 Class Initialized
INFO - 2016-05-08 11:43:06 --> URI Class Initialized
INFO - 2016-05-08 11:43:06 --> Router Class Initialized
INFO - 2016-05-08 11:43:06 --> Output Class Initialized
INFO - 2016-05-08 11:43:06 --> Security Class Initialized
DEBUG - 2016-05-08 11:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:43:06 --> Input Class Initialized
INFO - 2016-05-08 11:43:06 --> Language Class Initialized
INFO - 2016-05-08 11:43:06 --> Loader Class Initialized
INFO - 2016-05-08 11:43:06 --> Helper loaded: url_helper
INFO - 2016-05-08 11:43:06 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:43:06 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:43:06 --> Helper loaded: form_helper
INFO - 2016-05-08 11:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:43:06 --> Form Validation Class Initialized
INFO - 2016-05-08 11:43:06 --> Controller Class Initialized
INFO - 2016-05-08 11:43:06 --> Model Class Initialized
INFO - 2016-05-08 11:43:06 --> Database Driver Class Initialized
INFO - 2016-05-08 11:43:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:43:06 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:43:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:43:06 --> Config Class Initialized
INFO - 2016-05-08 11:43:06 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:43:06 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:43:06 --> Utf8 Class Initialized
INFO - 2016-05-08 11:43:06 --> URI Class Initialized
INFO - 2016-05-08 11:43:06 --> Router Class Initialized
INFO - 2016-05-08 11:43:06 --> Output Class Initialized
INFO - 2016-05-08 11:43:06 --> Security Class Initialized
DEBUG - 2016-05-08 11:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:43:06 --> Input Class Initialized
INFO - 2016-05-08 11:43:06 --> Language Class Initialized
INFO - 2016-05-08 11:43:06 --> Loader Class Initialized
INFO - 2016-05-08 11:43:06 --> Helper loaded: url_helper
INFO - 2016-05-08 11:43:06 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:43:06 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:43:06 --> Helper loaded: form_helper
INFO - 2016-05-08 11:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:43:06 --> Form Validation Class Initialized
INFO - 2016-05-08 11:43:06 --> Controller Class Initialized
INFO - 2016-05-08 11:43:06 --> Model Class Initialized
INFO - 2016-05-08 11:43:06 --> Database Driver Class Initialized
INFO - 2016-05-08 11:43:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:43:06 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:43:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:43:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 11:43:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:43:06 --> Final output sent to browser
DEBUG - 2016-05-08 11:43:06 --> Total execution time: 0.0704
INFO - 2016-05-08 11:43:10 --> Config Class Initialized
INFO - 2016-05-08 11:43:10 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:43:10 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:43:10 --> Utf8 Class Initialized
INFO - 2016-05-08 11:43:10 --> URI Class Initialized
INFO - 2016-05-08 11:43:10 --> Router Class Initialized
INFO - 2016-05-08 11:43:10 --> Output Class Initialized
INFO - 2016-05-08 11:43:10 --> Security Class Initialized
DEBUG - 2016-05-08 11:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:43:10 --> Input Class Initialized
INFO - 2016-05-08 11:43:10 --> Language Class Initialized
INFO - 2016-05-08 11:43:10 --> Loader Class Initialized
INFO - 2016-05-08 11:43:10 --> Helper loaded: url_helper
INFO - 2016-05-08 11:43:10 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:43:10 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:43:10 --> Helper loaded: form_helper
INFO - 2016-05-08 11:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:43:10 --> Form Validation Class Initialized
INFO - 2016-05-08 11:43:10 --> Controller Class Initialized
INFO - 2016-05-08 11:43:10 --> Model Class Initialized
INFO - 2016-05-08 11:43:10 --> Database Driver Class Initialized
INFO - 2016-05-08 11:43:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:43:10 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:43:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:43:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 11:43:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:43:10 --> Final output sent to browser
DEBUG - 2016-05-08 11:43:10 --> Total execution time: 0.1037
INFO - 2016-05-08 11:43:16 --> Config Class Initialized
INFO - 2016-05-08 11:43:16 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:43:16 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:43:16 --> Utf8 Class Initialized
INFO - 2016-05-08 11:43:16 --> URI Class Initialized
INFO - 2016-05-08 11:43:16 --> Router Class Initialized
INFO - 2016-05-08 11:43:16 --> Output Class Initialized
INFO - 2016-05-08 11:43:16 --> Security Class Initialized
DEBUG - 2016-05-08 11:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:43:16 --> Input Class Initialized
INFO - 2016-05-08 11:43:16 --> Language Class Initialized
INFO - 2016-05-08 11:43:16 --> Loader Class Initialized
INFO - 2016-05-08 11:43:16 --> Helper loaded: url_helper
INFO - 2016-05-08 11:43:16 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:43:16 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:43:16 --> Helper loaded: form_helper
INFO - 2016-05-08 11:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:43:16 --> Form Validation Class Initialized
INFO - 2016-05-08 11:43:16 --> Controller Class Initialized
INFO - 2016-05-08 11:43:16 --> Model Class Initialized
INFO - 2016-05-08 11:43:16 --> Database Driver Class Initialized
INFO - 2016-05-08 11:43:16 --> Config Class Initialized
INFO - 2016-05-08 11:43:16 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:43:16 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:43:16 --> Utf8 Class Initialized
INFO - 2016-05-08 11:43:16 --> URI Class Initialized
INFO - 2016-05-08 11:43:16 --> Router Class Initialized
INFO - 2016-05-08 11:43:16 --> Output Class Initialized
INFO - 2016-05-08 11:43:16 --> Security Class Initialized
DEBUG - 2016-05-08 11:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:43:16 --> Input Class Initialized
INFO - 2016-05-08 11:43:16 --> Language Class Initialized
INFO - 2016-05-08 11:43:16 --> Loader Class Initialized
INFO - 2016-05-08 11:43:16 --> Helper loaded: url_helper
INFO - 2016-05-08 11:43:16 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:43:16 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:43:16 --> Helper loaded: form_helper
INFO - 2016-05-08 11:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:43:16 --> Form Validation Class Initialized
INFO - 2016-05-08 11:43:16 --> Controller Class Initialized
INFO - 2016-05-08 11:43:16 --> Model Class Initialized
INFO - 2016-05-08 11:43:16 --> Database Driver Class Initialized
INFO - 2016-05-08 11:43:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-08 11:43:16 --> Final output sent to browser
DEBUG - 2016-05-08 11:43:16 --> Total execution time: 0.0933
INFO - 2016-05-08 11:43:20 --> Config Class Initialized
INFO - 2016-05-08 11:43:20 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:43:20 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:43:20 --> Utf8 Class Initialized
INFO - 2016-05-08 11:43:20 --> URI Class Initialized
INFO - 2016-05-08 11:43:20 --> Router Class Initialized
INFO - 2016-05-08 11:43:20 --> Output Class Initialized
INFO - 2016-05-08 11:43:20 --> Security Class Initialized
DEBUG - 2016-05-08 11:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:43:20 --> Input Class Initialized
INFO - 2016-05-08 11:43:20 --> Language Class Initialized
INFO - 2016-05-08 11:43:20 --> Loader Class Initialized
INFO - 2016-05-08 11:43:20 --> Helper loaded: url_helper
INFO - 2016-05-08 11:43:20 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:43:20 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:43:20 --> Helper loaded: form_helper
INFO - 2016-05-08 11:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:43:20 --> Form Validation Class Initialized
INFO - 2016-05-08 11:43:20 --> Controller Class Initialized
INFO - 2016-05-08 11:43:20 --> Model Class Initialized
INFO - 2016-05-08 11:43:20 --> Database Driver Class Initialized
INFO - 2016-05-08 11:43:20 --> Config Class Initialized
INFO - 2016-05-08 11:43:20 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:43:20 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:43:20 --> Utf8 Class Initialized
INFO - 2016-05-08 11:43:20 --> URI Class Initialized
INFO - 2016-05-08 11:43:20 --> Router Class Initialized
INFO - 2016-05-08 11:43:20 --> Output Class Initialized
INFO - 2016-05-08 11:43:20 --> Security Class Initialized
DEBUG - 2016-05-08 11:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:43:20 --> Input Class Initialized
INFO - 2016-05-08 11:43:20 --> Language Class Initialized
INFO - 2016-05-08 11:43:20 --> Loader Class Initialized
INFO - 2016-05-08 11:43:20 --> Helper loaded: url_helper
INFO - 2016-05-08 11:43:20 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:43:20 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:43:20 --> Helper loaded: form_helper
INFO - 2016-05-08 11:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:43:20 --> Form Validation Class Initialized
INFO - 2016-05-08 11:43:20 --> Controller Class Initialized
INFO - 2016-05-08 11:43:20 --> Model Class Initialized
INFO - 2016-05-08 11:43:20 --> Database Driver Class Initialized
INFO - 2016-05-08 11:43:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:43:20 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:43:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:43:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 11:43:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:43:20 --> Final output sent to browser
DEBUG - 2016-05-08 11:43:20 --> Total execution time: 0.0719
INFO - 2016-05-08 11:44:37 --> Config Class Initialized
INFO - 2016-05-08 11:44:37 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:44:37 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:44:37 --> Utf8 Class Initialized
INFO - 2016-05-08 11:44:37 --> URI Class Initialized
INFO - 2016-05-08 11:44:37 --> Router Class Initialized
INFO - 2016-05-08 11:44:37 --> Output Class Initialized
INFO - 2016-05-08 11:44:37 --> Security Class Initialized
DEBUG - 2016-05-08 11:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:44:37 --> Input Class Initialized
INFO - 2016-05-08 11:44:37 --> Language Class Initialized
INFO - 2016-05-08 11:44:37 --> Loader Class Initialized
INFO - 2016-05-08 11:44:37 --> Helper loaded: url_helper
INFO - 2016-05-08 11:44:37 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:44:37 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:44:37 --> Helper loaded: form_helper
INFO - 2016-05-08 11:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:44:37 --> Form Validation Class Initialized
INFO - 2016-05-08 11:44:37 --> Controller Class Initialized
INFO - 2016-05-08 11:44:37 --> Model Class Initialized
INFO - 2016-05-08 11:44:37 --> Database Driver Class Initialized
INFO - 2016-05-08 11:44:37 --> Config Class Initialized
INFO - 2016-05-08 11:44:37 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:44:37 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:44:37 --> Utf8 Class Initialized
INFO - 2016-05-08 11:44:37 --> URI Class Initialized
INFO - 2016-05-08 11:44:37 --> Router Class Initialized
INFO - 2016-05-08 11:44:37 --> Output Class Initialized
INFO - 2016-05-08 11:44:37 --> Security Class Initialized
DEBUG - 2016-05-08 11:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:44:37 --> Input Class Initialized
INFO - 2016-05-08 11:44:37 --> Language Class Initialized
INFO - 2016-05-08 11:44:37 --> Loader Class Initialized
INFO - 2016-05-08 11:44:37 --> Helper loaded: url_helper
INFO - 2016-05-08 11:44:37 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:44:37 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:44:37 --> Helper loaded: form_helper
INFO - 2016-05-08 11:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:44:37 --> Form Validation Class Initialized
INFO - 2016-05-08 11:44:37 --> Controller Class Initialized
INFO - 2016-05-08 11:44:37 --> Model Class Initialized
INFO - 2016-05-08 11:44:37 --> Database Driver Class Initialized
INFO - 2016-05-08 11:44:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-08 11:44:37 --> Final output sent to browser
DEBUG - 2016-05-08 11:44:37 --> Total execution time: 0.0659
INFO - 2016-05-08 11:44:38 --> Config Class Initialized
INFO - 2016-05-08 11:44:38 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:44:38 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:44:38 --> Utf8 Class Initialized
INFO - 2016-05-08 11:44:38 --> URI Class Initialized
INFO - 2016-05-08 11:44:38 --> Router Class Initialized
INFO - 2016-05-08 11:44:38 --> Output Class Initialized
INFO - 2016-05-08 11:44:38 --> Security Class Initialized
DEBUG - 2016-05-08 11:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:44:38 --> Input Class Initialized
INFO - 2016-05-08 11:44:38 --> Language Class Initialized
INFO - 2016-05-08 11:44:38 --> Loader Class Initialized
INFO - 2016-05-08 11:44:38 --> Helper loaded: url_helper
INFO - 2016-05-08 11:44:38 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:44:38 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:44:38 --> Helper loaded: form_helper
INFO - 2016-05-08 11:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:44:38 --> Form Validation Class Initialized
INFO - 2016-05-08 11:44:38 --> Controller Class Initialized
INFO - 2016-05-08 11:44:38 --> Model Class Initialized
INFO - 2016-05-08 11:44:38 --> Database Driver Class Initialized
INFO - 2016-05-08 11:44:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-08 11:44:38 --> Final output sent to browser
DEBUG - 2016-05-08 11:44:38 --> Total execution time: 0.0724
INFO - 2016-05-08 11:44:42 --> Config Class Initialized
INFO - 2016-05-08 11:44:42 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:44:42 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:44:42 --> Utf8 Class Initialized
INFO - 2016-05-08 11:44:42 --> URI Class Initialized
INFO - 2016-05-08 11:44:42 --> Router Class Initialized
INFO - 2016-05-08 11:44:42 --> Output Class Initialized
INFO - 2016-05-08 11:44:42 --> Security Class Initialized
DEBUG - 2016-05-08 11:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:44:42 --> Input Class Initialized
INFO - 2016-05-08 11:44:42 --> Language Class Initialized
INFO - 2016-05-08 11:44:42 --> Loader Class Initialized
INFO - 2016-05-08 11:44:42 --> Helper loaded: url_helper
INFO - 2016-05-08 11:44:42 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:44:42 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:44:42 --> Helper loaded: form_helper
INFO - 2016-05-08 11:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:44:42 --> Form Validation Class Initialized
INFO - 2016-05-08 11:44:42 --> Controller Class Initialized
INFO - 2016-05-08 11:44:42 --> Model Class Initialized
INFO - 2016-05-08 11:44:42 --> Database Driver Class Initialized
INFO - 2016-05-08 11:44:43 --> Config Class Initialized
INFO - 2016-05-08 11:44:43 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:44:43 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:44:43 --> Utf8 Class Initialized
INFO - 2016-05-08 11:44:43 --> URI Class Initialized
INFO - 2016-05-08 11:44:43 --> Router Class Initialized
INFO - 2016-05-08 11:44:43 --> Output Class Initialized
INFO - 2016-05-08 11:44:43 --> Security Class Initialized
DEBUG - 2016-05-08 11:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:44:43 --> Input Class Initialized
INFO - 2016-05-08 11:44:43 --> Language Class Initialized
INFO - 2016-05-08 11:44:43 --> Loader Class Initialized
INFO - 2016-05-08 11:44:43 --> Helper loaded: url_helper
INFO - 2016-05-08 11:44:43 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:44:43 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:44:43 --> Helper loaded: form_helper
INFO - 2016-05-08 11:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:44:43 --> Form Validation Class Initialized
INFO - 2016-05-08 11:44:43 --> Controller Class Initialized
INFO - 2016-05-08 11:44:43 --> Model Class Initialized
INFO - 2016-05-08 11:44:43 --> Database Driver Class Initialized
INFO - 2016-05-08 11:44:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:44:43 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:44:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:44:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 11:44:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:44:43 --> Final output sent to browser
DEBUG - 2016-05-08 11:44:43 --> Total execution time: 0.0704
INFO - 2016-05-08 11:45:07 --> Config Class Initialized
INFO - 2016-05-08 11:45:07 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:45:07 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:45:07 --> Utf8 Class Initialized
INFO - 2016-05-08 11:45:07 --> URI Class Initialized
INFO - 2016-05-08 11:45:07 --> Router Class Initialized
INFO - 2016-05-08 11:45:07 --> Output Class Initialized
INFO - 2016-05-08 11:45:07 --> Security Class Initialized
DEBUG - 2016-05-08 11:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:45:07 --> Input Class Initialized
INFO - 2016-05-08 11:45:07 --> Language Class Initialized
INFO - 2016-05-08 11:45:07 --> Loader Class Initialized
INFO - 2016-05-08 11:45:07 --> Helper loaded: url_helper
INFO - 2016-05-08 11:45:07 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:45:07 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:45:07 --> Helper loaded: form_helper
INFO - 2016-05-08 11:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:45:07 --> Form Validation Class Initialized
INFO - 2016-05-08 11:45:07 --> Controller Class Initialized
INFO - 2016-05-08 11:45:07 --> Model Class Initialized
INFO - 2016-05-08 11:45:07 --> Database Driver Class Initialized
INFO - 2016-05-08 11:45:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:45:07 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:45:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:45:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 11:45:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:45:07 --> Final output sent to browser
DEBUG - 2016-05-08 11:45:07 --> Total execution time: 0.0872
INFO - 2016-05-08 11:45:52 --> Config Class Initialized
INFO - 2016-05-08 11:45:52 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:45:52 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:45:52 --> Utf8 Class Initialized
INFO - 2016-05-08 11:45:52 --> URI Class Initialized
INFO - 2016-05-08 11:45:52 --> Router Class Initialized
INFO - 2016-05-08 11:45:52 --> Output Class Initialized
INFO - 2016-05-08 11:45:52 --> Security Class Initialized
DEBUG - 2016-05-08 11:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:45:52 --> Input Class Initialized
INFO - 2016-05-08 11:45:52 --> Language Class Initialized
INFO - 2016-05-08 11:45:52 --> Loader Class Initialized
INFO - 2016-05-08 11:45:52 --> Helper loaded: url_helper
INFO - 2016-05-08 11:45:52 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:45:52 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:45:52 --> Helper loaded: form_helper
INFO - 2016-05-08 11:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:45:52 --> Form Validation Class Initialized
INFO - 2016-05-08 11:45:52 --> Controller Class Initialized
INFO - 2016-05-08 11:45:52 --> Model Class Initialized
INFO - 2016-05-08 11:45:52 --> Database Driver Class Initialized
INFO - 2016-05-08 11:45:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:45:52 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:45:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:45:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 11:45:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:45:52 --> Final output sent to browser
DEBUG - 2016-05-08 11:45:52 --> Total execution time: 0.0898
INFO - 2016-05-08 11:45:55 --> Config Class Initialized
INFO - 2016-05-08 11:45:55 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:45:55 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:45:55 --> Utf8 Class Initialized
INFO - 2016-05-08 11:45:55 --> URI Class Initialized
INFO - 2016-05-08 11:45:55 --> Router Class Initialized
INFO - 2016-05-08 11:45:55 --> Output Class Initialized
INFO - 2016-05-08 11:45:55 --> Security Class Initialized
DEBUG - 2016-05-08 11:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:45:55 --> Input Class Initialized
INFO - 2016-05-08 11:45:55 --> Language Class Initialized
INFO - 2016-05-08 11:45:56 --> Loader Class Initialized
INFO - 2016-05-08 11:45:56 --> Helper loaded: url_helper
INFO - 2016-05-08 11:45:56 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:45:56 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:45:56 --> Helper loaded: form_helper
INFO - 2016-05-08 11:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:45:56 --> Form Validation Class Initialized
INFO - 2016-05-08 11:45:56 --> Controller Class Initialized
INFO - 2016-05-08 11:45:56 --> Model Class Initialized
INFO - 2016-05-08 11:45:56 --> Database Driver Class Initialized
INFO - 2016-05-08 11:45:56 --> Config Class Initialized
INFO - 2016-05-08 11:45:56 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:45:56 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:45:56 --> Utf8 Class Initialized
INFO - 2016-05-08 11:45:56 --> URI Class Initialized
INFO - 2016-05-08 11:45:56 --> Router Class Initialized
INFO - 2016-05-08 11:45:56 --> Output Class Initialized
INFO - 2016-05-08 11:45:56 --> Security Class Initialized
DEBUG - 2016-05-08 11:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:45:56 --> Input Class Initialized
INFO - 2016-05-08 11:45:56 --> Language Class Initialized
INFO - 2016-05-08 11:45:56 --> Loader Class Initialized
INFO - 2016-05-08 11:45:56 --> Helper loaded: url_helper
INFO - 2016-05-08 11:45:56 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:45:56 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:45:56 --> Helper loaded: form_helper
INFO - 2016-05-08 11:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:45:56 --> Form Validation Class Initialized
INFO - 2016-05-08 11:45:56 --> Controller Class Initialized
INFO - 2016-05-08 11:45:56 --> Model Class Initialized
INFO - 2016-05-08 11:45:56 --> Database Driver Class Initialized
INFO - 2016-05-08 11:45:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-08 11:45:56 --> Final output sent to browser
DEBUG - 2016-05-08 11:45:56 --> Total execution time: 0.0641
INFO - 2016-05-08 11:46:00 --> Config Class Initialized
INFO - 2016-05-08 11:46:00 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:46:00 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:46:00 --> Utf8 Class Initialized
INFO - 2016-05-08 11:46:00 --> URI Class Initialized
INFO - 2016-05-08 11:46:00 --> Router Class Initialized
INFO - 2016-05-08 11:46:00 --> Output Class Initialized
INFO - 2016-05-08 11:46:00 --> Security Class Initialized
DEBUG - 2016-05-08 11:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:46:00 --> Input Class Initialized
INFO - 2016-05-08 11:46:00 --> Language Class Initialized
INFO - 2016-05-08 11:46:00 --> Loader Class Initialized
INFO - 2016-05-08 11:46:00 --> Helper loaded: url_helper
INFO - 2016-05-08 11:46:00 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:46:00 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:46:00 --> Helper loaded: form_helper
INFO - 2016-05-08 11:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:46:00 --> Form Validation Class Initialized
INFO - 2016-05-08 11:46:00 --> Controller Class Initialized
INFO - 2016-05-08 11:46:00 --> Model Class Initialized
INFO - 2016-05-08 11:46:00 --> Database Driver Class Initialized
INFO - 2016-05-08 11:46:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-08 11:46:00 --> Final output sent to browser
DEBUG - 2016-05-08 11:46:00 --> Total execution time: 0.0627
INFO - 2016-05-08 11:46:14 --> Config Class Initialized
INFO - 2016-05-08 11:46:14 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:46:14 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:46:14 --> Utf8 Class Initialized
INFO - 2016-05-08 11:46:14 --> URI Class Initialized
INFO - 2016-05-08 11:46:14 --> Router Class Initialized
INFO - 2016-05-08 11:46:14 --> Output Class Initialized
INFO - 2016-05-08 11:46:14 --> Security Class Initialized
DEBUG - 2016-05-08 11:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:46:14 --> Input Class Initialized
INFO - 2016-05-08 11:46:14 --> Language Class Initialized
INFO - 2016-05-08 11:46:14 --> Loader Class Initialized
INFO - 2016-05-08 11:46:14 --> Helper loaded: url_helper
INFO - 2016-05-08 11:46:14 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:46:14 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:46:14 --> Helper loaded: form_helper
INFO - 2016-05-08 11:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:46:14 --> Form Validation Class Initialized
INFO - 2016-05-08 11:46:14 --> Controller Class Initialized
INFO - 2016-05-08 11:46:14 --> Model Class Initialized
INFO - 2016-05-08 11:46:14 --> Database Driver Class Initialized
INFO - 2016-05-08 11:46:14 --> Config Class Initialized
INFO - 2016-05-08 11:46:14 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:46:14 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:46:14 --> Utf8 Class Initialized
INFO - 2016-05-08 11:46:14 --> URI Class Initialized
INFO - 2016-05-08 11:46:14 --> Router Class Initialized
INFO - 2016-05-08 11:46:14 --> Output Class Initialized
INFO - 2016-05-08 11:46:14 --> Security Class Initialized
DEBUG - 2016-05-08 11:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:46:14 --> Input Class Initialized
INFO - 2016-05-08 11:46:14 --> Language Class Initialized
INFO - 2016-05-08 11:46:14 --> Loader Class Initialized
INFO - 2016-05-08 11:46:14 --> Helper loaded: url_helper
INFO - 2016-05-08 11:46:14 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:46:14 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:46:14 --> Helper loaded: form_helper
INFO - 2016-05-08 11:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:46:14 --> Form Validation Class Initialized
INFO - 2016-05-08 11:46:14 --> Controller Class Initialized
INFO - 2016-05-08 11:46:14 --> Model Class Initialized
INFO - 2016-05-08 11:46:14 --> Database Driver Class Initialized
INFO - 2016-05-08 11:46:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:46:14 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:46:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:46:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 11:46:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:46:14 --> Final output sent to browser
DEBUG - 2016-05-08 11:46:14 --> Total execution time: 0.0736
INFO - 2016-05-08 11:58:52 --> Config Class Initialized
INFO - 2016-05-08 11:58:52 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:58:52 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:58:52 --> Utf8 Class Initialized
INFO - 2016-05-08 11:58:52 --> URI Class Initialized
INFO - 2016-05-08 11:58:52 --> Router Class Initialized
INFO - 2016-05-08 11:58:52 --> Output Class Initialized
INFO - 2016-05-08 11:58:52 --> Security Class Initialized
DEBUG - 2016-05-08 11:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:58:52 --> Input Class Initialized
INFO - 2016-05-08 11:58:52 --> Language Class Initialized
INFO - 2016-05-08 11:58:52 --> Loader Class Initialized
INFO - 2016-05-08 11:58:52 --> Helper loaded: url_helper
INFO - 2016-05-08 11:58:52 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:58:52 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:58:52 --> Helper loaded: form_helper
INFO - 2016-05-08 11:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:58:52 --> Form Validation Class Initialized
INFO - 2016-05-08 11:58:52 --> Controller Class Initialized
INFO - 2016-05-08 11:58:52 --> Model Class Initialized
INFO - 2016-05-08 11:58:52 --> Database Driver Class Initialized
INFO - 2016-05-08 11:58:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:58:52 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:58:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 11:58:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 11:58:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 11:58:52 --> Final output sent to browser
DEBUG - 2016-05-08 11:58:52 --> Total execution time: 0.0803
INFO - 2016-05-08 11:59:00 --> Config Class Initialized
INFO - 2016-05-08 11:59:00 --> Hooks Class Initialized
DEBUG - 2016-05-08 11:59:00 --> UTF-8 Support Enabled
INFO - 2016-05-08 11:59:00 --> Utf8 Class Initialized
INFO - 2016-05-08 11:59:00 --> URI Class Initialized
INFO - 2016-05-08 11:59:00 --> Router Class Initialized
INFO - 2016-05-08 11:59:00 --> Output Class Initialized
INFO - 2016-05-08 11:59:00 --> Security Class Initialized
DEBUG - 2016-05-08 11:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 11:59:00 --> Input Class Initialized
INFO - 2016-05-08 11:59:00 --> Language Class Initialized
INFO - 2016-05-08 11:59:00 --> Loader Class Initialized
INFO - 2016-05-08 11:59:00 --> Helper loaded: url_helper
INFO - 2016-05-08 11:59:00 --> Helper loaded: sesion_helper
INFO - 2016-05-08 11:59:00 --> Helper loaded: templates_helper
INFO - 2016-05-08 11:59:00 --> Helper loaded: form_helper
INFO - 2016-05-08 11:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 11:59:00 --> Form Validation Class Initialized
INFO - 2016-05-08 11:59:00 --> Controller Class Initialized
INFO - 2016-05-08 11:59:00 --> Model Class Initialized
INFO - 2016-05-08 11:59:00 --> Database Driver Class Initialized
INFO - 2016-05-08 11:59:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 11:59:00 --> Pagination Class Initialized
DEBUG - 2016-05-08 11:59:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-08 11:59:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'estado LIKE '%isa%'' at line 1 - Invalid query: SELECT count(*) 'cont' FROM usuario WHERE username LIKE '%isa%' OR tipo LIKE '%isa%' OR nombre LIKE '%isa%' OR correo LIKE '%isa%' estado LIKE '%isa%'
INFO - 2016-05-08 11:59:00 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-08 12:00:43 --> Config Class Initialized
INFO - 2016-05-08 12:00:43 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:00:43 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:00:43 --> Utf8 Class Initialized
INFO - 2016-05-08 12:00:43 --> URI Class Initialized
INFO - 2016-05-08 12:00:43 --> Router Class Initialized
INFO - 2016-05-08 12:00:43 --> Output Class Initialized
INFO - 2016-05-08 12:00:43 --> Security Class Initialized
DEBUG - 2016-05-08 12:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:00:43 --> Input Class Initialized
INFO - 2016-05-08 12:00:43 --> Language Class Initialized
INFO - 2016-05-08 12:00:43 --> Loader Class Initialized
INFO - 2016-05-08 12:00:43 --> Helper loaded: url_helper
INFO - 2016-05-08 12:00:43 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:00:43 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:00:43 --> Helper loaded: form_helper
INFO - 2016-05-08 12:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:00:43 --> Form Validation Class Initialized
INFO - 2016-05-08 12:00:43 --> Controller Class Initialized
INFO - 2016-05-08 12:00:43 --> Model Class Initialized
INFO - 2016-05-08 12:00:43 --> Database Driver Class Initialized
INFO - 2016-05-08 12:00:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:00:43 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:00:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-08 12:00:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'estado LIKE '%isa%'' at line 1 - Invalid query: SELECT count(*) 'cont' FROM usuario WHERE username LIKE '%isa%' OR tipo LIKE '%isa%' OR nombre LIKE '%isa%' OR correo LIKE '%isa%' estado LIKE '%isa%'
INFO - 2016-05-08 12:00:43 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-08 12:01:10 --> Config Class Initialized
INFO - 2016-05-08 12:01:10 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:01:10 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:01:10 --> Utf8 Class Initialized
INFO - 2016-05-08 12:01:10 --> URI Class Initialized
INFO - 2016-05-08 12:01:10 --> Router Class Initialized
INFO - 2016-05-08 12:01:10 --> Output Class Initialized
INFO - 2016-05-08 12:01:10 --> Security Class Initialized
DEBUG - 2016-05-08 12:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:01:10 --> Input Class Initialized
INFO - 2016-05-08 12:01:10 --> Language Class Initialized
INFO - 2016-05-08 12:01:10 --> Loader Class Initialized
INFO - 2016-05-08 12:01:10 --> Helper loaded: url_helper
INFO - 2016-05-08 12:01:10 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:01:10 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:01:10 --> Helper loaded: form_helper
INFO - 2016-05-08 12:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:01:10 --> Form Validation Class Initialized
INFO - 2016-05-08 12:01:10 --> Controller Class Initialized
INFO - 2016-05-08 12:01:10 --> Model Class Initialized
INFO - 2016-05-08 12:01:10 --> Database Driver Class Initialized
INFO - 2016-05-08 12:01:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:01:10 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:01:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-08 12:01:10 --> Severity: Error --> Call to undefined method Mdl_lista::BusquedaUsuarios() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Usuarios.php 57
INFO - 2016-05-08 12:01:25 --> Config Class Initialized
INFO - 2016-05-08 12:01:25 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:01:25 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:01:25 --> Utf8 Class Initialized
INFO - 2016-05-08 12:01:25 --> URI Class Initialized
INFO - 2016-05-08 12:01:25 --> Router Class Initialized
INFO - 2016-05-08 12:01:25 --> Output Class Initialized
INFO - 2016-05-08 12:01:25 --> Security Class Initialized
DEBUG - 2016-05-08 12:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:01:25 --> Input Class Initialized
INFO - 2016-05-08 12:01:25 --> Language Class Initialized
INFO - 2016-05-08 12:01:25 --> Loader Class Initialized
INFO - 2016-05-08 12:01:25 --> Helper loaded: url_helper
INFO - 2016-05-08 12:01:25 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:01:25 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:01:25 --> Helper loaded: form_helper
INFO - 2016-05-08 12:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:01:25 --> Form Validation Class Initialized
INFO - 2016-05-08 12:01:25 --> Controller Class Initialized
INFO - 2016-05-08 12:01:25 --> Model Class Initialized
INFO - 2016-05-08 12:01:25 --> Database Driver Class Initialized
INFO - 2016-05-08 12:01:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:01:25 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:01:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:01:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 12:01:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:01:25 --> Final output sent to browser
DEBUG - 2016-05-08 12:01:25 --> Total execution time: 0.0951
INFO - 2016-05-08 12:01:35 --> Config Class Initialized
INFO - 2016-05-08 12:01:35 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:01:35 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:01:35 --> Utf8 Class Initialized
INFO - 2016-05-08 12:01:35 --> URI Class Initialized
INFO - 2016-05-08 12:01:35 --> Router Class Initialized
INFO - 2016-05-08 12:01:35 --> Output Class Initialized
INFO - 2016-05-08 12:01:35 --> Security Class Initialized
DEBUG - 2016-05-08 12:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:01:35 --> Input Class Initialized
INFO - 2016-05-08 12:01:35 --> Language Class Initialized
INFO - 2016-05-08 12:01:35 --> Loader Class Initialized
INFO - 2016-05-08 12:01:35 --> Helper loaded: url_helper
INFO - 2016-05-08 12:01:35 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:01:35 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:01:35 --> Helper loaded: form_helper
INFO - 2016-05-08 12:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:01:35 --> Form Validation Class Initialized
INFO - 2016-05-08 12:01:35 --> Controller Class Initialized
INFO - 2016-05-08 12:01:35 --> Model Class Initialized
INFO - 2016-05-08 12:01:35 --> Database Driver Class Initialized
INFO - 2016-05-08 12:01:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:01:35 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:01:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:01:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 12:01:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:01:35 --> Final output sent to browser
DEBUG - 2016-05-08 12:01:35 --> Total execution time: 0.0718
INFO - 2016-05-08 12:01:55 --> Config Class Initialized
INFO - 2016-05-08 12:01:55 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:01:55 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:01:55 --> Utf8 Class Initialized
INFO - 2016-05-08 12:01:55 --> URI Class Initialized
INFO - 2016-05-08 12:01:55 --> Router Class Initialized
INFO - 2016-05-08 12:01:55 --> Output Class Initialized
INFO - 2016-05-08 12:01:55 --> Security Class Initialized
DEBUG - 2016-05-08 12:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:01:55 --> Input Class Initialized
INFO - 2016-05-08 12:01:55 --> Language Class Initialized
INFO - 2016-05-08 12:01:55 --> Loader Class Initialized
INFO - 2016-05-08 12:01:55 --> Helper loaded: url_helper
INFO - 2016-05-08 12:01:55 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:01:55 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:01:55 --> Helper loaded: form_helper
INFO - 2016-05-08 12:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:01:55 --> Form Validation Class Initialized
INFO - 2016-05-08 12:01:55 --> Controller Class Initialized
INFO - 2016-05-08 12:01:55 --> Model Class Initialized
INFO - 2016-05-08 12:01:55 --> Database Driver Class Initialized
INFO - 2016-05-08 12:01:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:01:55 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:01:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:01:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 12:01:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:01:55 --> Final output sent to browser
DEBUG - 2016-05-08 12:01:55 --> Total execution time: 0.0947
INFO - 2016-05-08 12:02:00 --> Config Class Initialized
INFO - 2016-05-08 12:02:00 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:02:00 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:02:00 --> Utf8 Class Initialized
INFO - 2016-05-08 12:02:00 --> URI Class Initialized
INFO - 2016-05-08 12:02:00 --> Router Class Initialized
INFO - 2016-05-08 12:02:00 --> Output Class Initialized
INFO - 2016-05-08 12:02:00 --> Security Class Initialized
DEBUG - 2016-05-08 12:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:02:00 --> Input Class Initialized
INFO - 2016-05-08 12:02:00 --> Language Class Initialized
INFO - 2016-05-08 12:02:00 --> Loader Class Initialized
INFO - 2016-05-08 12:02:00 --> Helper loaded: url_helper
INFO - 2016-05-08 12:02:00 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:02:00 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:02:00 --> Helper loaded: form_helper
INFO - 2016-05-08 12:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:02:00 --> Form Validation Class Initialized
INFO - 2016-05-08 12:02:00 --> Controller Class Initialized
INFO - 2016-05-08 12:02:00 --> Model Class Initialized
INFO - 2016-05-08 12:02:00 --> Database Driver Class Initialized
INFO - 2016-05-08 12:02:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:02:00 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:02:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:02:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 12:02:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:02:00 --> Final output sent to browser
DEBUG - 2016-05-08 12:02:00 --> Total execution time: 0.0731
INFO - 2016-05-08 12:02:05 --> Config Class Initialized
INFO - 2016-05-08 12:02:05 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:02:05 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:02:05 --> Utf8 Class Initialized
INFO - 2016-05-08 12:02:05 --> URI Class Initialized
INFO - 2016-05-08 12:02:05 --> Router Class Initialized
INFO - 2016-05-08 12:02:05 --> Output Class Initialized
INFO - 2016-05-08 12:02:05 --> Security Class Initialized
DEBUG - 2016-05-08 12:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:02:05 --> Input Class Initialized
INFO - 2016-05-08 12:02:05 --> Language Class Initialized
INFO - 2016-05-08 12:02:05 --> Loader Class Initialized
INFO - 2016-05-08 12:02:05 --> Helper loaded: url_helper
INFO - 2016-05-08 12:02:05 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:02:05 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:02:05 --> Helper loaded: form_helper
INFO - 2016-05-08 12:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:02:05 --> Form Validation Class Initialized
INFO - 2016-05-08 12:02:05 --> Controller Class Initialized
INFO - 2016-05-08 12:02:05 --> Model Class Initialized
INFO - 2016-05-08 12:02:05 --> Database Driver Class Initialized
INFO - 2016-05-08 12:02:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:02:05 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:02:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:02:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 12:02:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:02:06 --> Final output sent to browser
DEBUG - 2016-05-08 12:02:06 --> Total execution time: 0.0739
INFO - 2016-05-08 12:02:10 --> Config Class Initialized
INFO - 2016-05-08 12:02:10 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:02:10 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:02:10 --> Utf8 Class Initialized
INFO - 2016-05-08 12:02:10 --> URI Class Initialized
INFO - 2016-05-08 12:02:10 --> Router Class Initialized
INFO - 2016-05-08 12:02:10 --> Output Class Initialized
INFO - 2016-05-08 12:02:10 --> Security Class Initialized
DEBUG - 2016-05-08 12:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:02:10 --> Input Class Initialized
INFO - 2016-05-08 12:02:10 --> Language Class Initialized
INFO - 2016-05-08 12:02:10 --> Loader Class Initialized
INFO - 2016-05-08 12:02:10 --> Helper loaded: url_helper
INFO - 2016-05-08 12:02:10 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:02:10 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:02:10 --> Helper loaded: form_helper
INFO - 2016-05-08 12:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:02:10 --> Form Validation Class Initialized
INFO - 2016-05-08 12:02:10 --> Controller Class Initialized
INFO - 2016-05-08 12:02:10 --> Model Class Initialized
INFO - 2016-05-08 12:02:10 --> Database Driver Class Initialized
INFO - 2016-05-08 12:02:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:02:10 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:02:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:02:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-08 12:02:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:02:10 --> Final output sent to browser
DEBUG - 2016-05-08 12:02:10 --> Total execution time: 0.0892
INFO - 2016-05-08 12:02:23 --> Config Class Initialized
INFO - 2016-05-08 12:02:23 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:02:23 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:02:23 --> Utf8 Class Initialized
INFO - 2016-05-08 12:02:23 --> URI Class Initialized
INFO - 2016-05-08 12:02:23 --> Router Class Initialized
INFO - 2016-05-08 12:02:23 --> Output Class Initialized
INFO - 2016-05-08 12:02:23 --> Security Class Initialized
DEBUG - 2016-05-08 12:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:02:23 --> Input Class Initialized
INFO - 2016-05-08 12:02:23 --> Language Class Initialized
INFO - 2016-05-08 12:02:23 --> Loader Class Initialized
INFO - 2016-05-08 12:02:23 --> Helper loaded: url_helper
INFO - 2016-05-08 12:02:23 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:02:23 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:02:23 --> Helper loaded: form_helper
INFO - 2016-05-08 12:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:02:23 --> Form Validation Class Initialized
INFO - 2016-05-08 12:02:23 --> Controller Class Initialized
INFO - 2016-05-08 12:02:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:02:23 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:02:23 --> Model Class Initialized
INFO - 2016-05-08 12:02:23 --> Database Driver Class Initialized
INFO - 2016-05-08 12:02:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-08 12:02:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:02:23 --> Final output sent to browser
DEBUG - 2016-05-08 12:02:23 --> Total execution time: 0.1545
INFO - 2016-05-08 12:04:09 --> Config Class Initialized
INFO - 2016-05-08 12:04:09 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:04:09 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:04:09 --> Utf8 Class Initialized
INFO - 2016-05-08 12:04:09 --> URI Class Initialized
INFO - 2016-05-08 12:04:09 --> Router Class Initialized
INFO - 2016-05-08 12:04:09 --> Output Class Initialized
INFO - 2016-05-08 12:04:09 --> Security Class Initialized
DEBUG - 2016-05-08 12:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:04:09 --> Input Class Initialized
INFO - 2016-05-08 12:04:09 --> Language Class Initialized
INFO - 2016-05-08 12:04:09 --> Loader Class Initialized
INFO - 2016-05-08 12:04:09 --> Helper loaded: url_helper
INFO - 2016-05-08 12:04:09 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:04:09 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:04:09 --> Helper loaded: form_helper
INFO - 2016-05-08 12:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:04:09 --> Form Validation Class Initialized
INFO - 2016-05-08 12:04:09 --> Controller Class Initialized
INFO - 2016-05-08 12:04:09 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:04:09 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:04:09 --> Model Class Initialized
INFO - 2016-05-08 12:04:09 --> Database Driver Class Initialized
INFO - 2016-05-08 12:04:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-08 12:04:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:04:10 --> Final output sent to browser
DEBUG - 2016-05-08 12:04:10 --> Total execution time: 0.1317
INFO - 2016-05-08 12:04:16 --> Config Class Initialized
INFO - 2016-05-08 12:04:16 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:04:16 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:04:16 --> Utf8 Class Initialized
INFO - 2016-05-08 12:04:16 --> URI Class Initialized
INFO - 2016-05-08 12:04:16 --> Router Class Initialized
INFO - 2016-05-08 12:04:16 --> Output Class Initialized
INFO - 2016-05-08 12:04:16 --> Security Class Initialized
DEBUG - 2016-05-08 12:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:04:16 --> Input Class Initialized
INFO - 2016-05-08 12:04:16 --> Language Class Initialized
INFO - 2016-05-08 12:04:16 --> Loader Class Initialized
INFO - 2016-05-08 12:04:17 --> Helper loaded: url_helper
INFO - 2016-05-08 12:04:17 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:04:17 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:04:17 --> Helper loaded: form_helper
INFO - 2016-05-08 12:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:04:17 --> Form Validation Class Initialized
INFO - 2016-05-08 12:04:17 --> Controller Class Initialized
INFO - 2016-05-08 12:04:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:04:17 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:04:17 --> Model Class Initialized
INFO - 2016-05-08 12:04:17 --> Database Driver Class Initialized
INFO - 2016-05-08 12:04:17 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 12:04:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCategoria.php
INFO - 2016-05-08 12:04:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:04:17 --> Final output sent to browser
DEBUG - 2016-05-08 12:04:17 --> Total execution time: 0.2451
INFO - 2016-05-08 12:04:19 --> Config Class Initialized
INFO - 2016-05-08 12:04:19 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:04:19 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:04:19 --> Utf8 Class Initialized
INFO - 2016-05-08 12:04:19 --> URI Class Initialized
INFO - 2016-05-08 12:04:19 --> Router Class Initialized
INFO - 2016-05-08 12:04:19 --> Output Class Initialized
INFO - 2016-05-08 12:04:19 --> Security Class Initialized
DEBUG - 2016-05-08 12:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:04:19 --> Input Class Initialized
INFO - 2016-05-08 12:04:19 --> Language Class Initialized
INFO - 2016-05-08 12:04:19 --> Loader Class Initialized
INFO - 2016-05-08 12:04:19 --> Helper loaded: url_helper
INFO - 2016-05-08 12:04:19 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:04:19 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:04:19 --> Helper loaded: form_helper
INFO - 2016-05-08 12:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:04:19 --> Form Validation Class Initialized
INFO - 2016-05-08 12:04:19 --> Controller Class Initialized
INFO - 2016-05-08 12:04:19 --> Model Class Initialized
INFO - 2016-05-08 12:04:19 --> Database Driver Class Initialized
INFO - 2016-05-08 12:04:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:04:19 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:04:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:04:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-08 12:04:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:04:19 --> Final output sent to browser
DEBUG - 2016-05-08 12:04:19 --> Total execution time: 0.1041
INFO - 2016-05-08 12:05:23 --> Config Class Initialized
INFO - 2016-05-08 12:05:23 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:05:23 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:05:23 --> Utf8 Class Initialized
INFO - 2016-05-08 12:05:23 --> URI Class Initialized
INFO - 2016-05-08 12:05:23 --> Router Class Initialized
INFO - 2016-05-08 12:05:23 --> Output Class Initialized
INFO - 2016-05-08 12:05:23 --> Security Class Initialized
DEBUG - 2016-05-08 12:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:05:23 --> Input Class Initialized
INFO - 2016-05-08 12:05:23 --> Language Class Initialized
INFO - 2016-05-08 12:05:23 --> Loader Class Initialized
INFO - 2016-05-08 12:05:23 --> Helper loaded: url_helper
INFO - 2016-05-08 12:05:23 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:05:23 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:05:23 --> Helper loaded: form_helper
INFO - 2016-05-08 12:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:05:23 --> Form Validation Class Initialized
INFO - 2016-05-08 12:05:23 --> Controller Class Initialized
INFO - 2016-05-08 12:05:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:05:23 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:05:23 --> Model Class Initialized
INFO - 2016-05-08 12:05:23 --> Database Driver Class Initialized
INFO - 2016-05-08 12:05:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-08 12:05:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:05:23 --> Final output sent to browser
DEBUG - 2016-05-08 12:05:23 --> Total execution time: 0.1190
INFO - 2016-05-08 12:06:07 --> Config Class Initialized
INFO - 2016-05-08 12:06:07 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:06:07 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:06:07 --> Utf8 Class Initialized
INFO - 2016-05-08 12:06:07 --> URI Class Initialized
INFO - 2016-05-08 12:06:07 --> Router Class Initialized
INFO - 2016-05-08 12:06:07 --> Output Class Initialized
INFO - 2016-05-08 12:06:07 --> Security Class Initialized
DEBUG - 2016-05-08 12:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:06:07 --> Input Class Initialized
INFO - 2016-05-08 12:06:07 --> Language Class Initialized
INFO - 2016-05-08 12:06:07 --> Loader Class Initialized
INFO - 2016-05-08 12:06:07 --> Helper loaded: url_helper
INFO - 2016-05-08 12:06:07 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:06:07 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:06:07 --> Helper loaded: form_helper
INFO - 2016-05-08 12:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:06:07 --> Form Validation Class Initialized
INFO - 2016-05-08 12:06:07 --> Controller Class Initialized
INFO - 2016-05-08 12:06:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:06:07 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:06:07 --> Model Class Initialized
INFO - 2016-05-08 12:06:07 --> Database Driver Class Initialized
INFO - 2016-05-08 12:06:08 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 12:06:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-08 12:06:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:06:08 --> Final output sent to browser
DEBUG - 2016-05-08 12:06:08 --> Total execution time: 0.1979
INFO - 2016-05-08 12:06:10 --> Config Class Initialized
INFO - 2016-05-08 12:06:10 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:06:10 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:06:10 --> Utf8 Class Initialized
INFO - 2016-05-08 12:06:10 --> URI Class Initialized
INFO - 2016-05-08 12:06:10 --> Router Class Initialized
INFO - 2016-05-08 12:06:10 --> Output Class Initialized
INFO - 2016-05-08 12:06:10 --> Security Class Initialized
DEBUG - 2016-05-08 12:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:06:10 --> Input Class Initialized
INFO - 2016-05-08 12:06:10 --> Language Class Initialized
INFO - 2016-05-08 12:06:10 --> Loader Class Initialized
INFO - 2016-05-08 12:06:10 --> Helper loaded: url_helper
INFO - 2016-05-08 12:06:10 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:06:10 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:06:10 --> Helper loaded: form_helper
INFO - 2016-05-08 12:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:06:10 --> Form Validation Class Initialized
INFO - 2016-05-08 12:06:10 --> Controller Class Initialized
INFO - 2016-05-08 12:06:10 --> Model Class Initialized
INFO - 2016-05-08 12:06:10 --> Database Driver Class Initialized
INFO - 2016-05-08 12:06:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:06:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:06:10 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:06:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:06:10 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:06:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 12:06:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:06:10 --> Final output sent to browser
DEBUG - 2016-05-08 12:06:10 --> Total execution time: 0.1120
INFO - 2016-05-08 12:07:51 --> Config Class Initialized
INFO - 2016-05-08 12:07:51 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:07:51 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:07:51 --> Utf8 Class Initialized
INFO - 2016-05-08 12:07:51 --> URI Class Initialized
INFO - 2016-05-08 12:07:51 --> Router Class Initialized
INFO - 2016-05-08 12:07:51 --> Output Class Initialized
INFO - 2016-05-08 12:07:51 --> Security Class Initialized
DEBUG - 2016-05-08 12:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:07:51 --> Input Class Initialized
INFO - 2016-05-08 12:07:51 --> Language Class Initialized
INFO - 2016-05-08 12:07:51 --> Loader Class Initialized
INFO - 2016-05-08 12:07:51 --> Helper loaded: url_helper
INFO - 2016-05-08 12:07:51 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:07:51 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:07:51 --> Helper loaded: form_helper
INFO - 2016-05-08 12:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:07:51 --> Form Validation Class Initialized
INFO - 2016-05-08 12:07:51 --> Controller Class Initialized
INFO - 2016-05-08 12:07:51 --> Model Class Initialized
INFO - 2016-05-08 12:07:51 --> Database Driver Class Initialized
INFO - 2016-05-08 12:07:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:07:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:07:51 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:07:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:07:51 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:07:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-08 12:07:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:07:51 --> Final output sent to browser
DEBUG - 2016-05-08 12:07:51 --> Total execution time: 0.0793
INFO - 2016-05-08 12:08:49 --> Config Class Initialized
INFO - 2016-05-08 12:08:49 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:08:49 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:08:49 --> Utf8 Class Initialized
INFO - 2016-05-08 12:08:49 --> URI Class Initialized
INFO - 2016-05-08 12:08:49 --> Router Class Initialized
INFO - 2016-05-08 12:08:49 --> Output Class Initialized
INFO - 2016-05-08 12:08:49 --> Security Class Initialized
DEBUG - 2016-05-08 12:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:08:49 --> Input Class Initialized
INFO - 2016-05-08 12:08:49 --> Language Class Initialized
INFO - 2016-05-08 12:08:49 --> Loader Class Initialized
INFO - 2016-05-08 12:08:49 --> Helper loaded: url_helper
INFO - 2016-05-08 12:08:49 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:08:49 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:08:49 --> Helper loaded: form_helper
INFO - 2016-05-08 12:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:08:49 --> Form Validation Class Initialized
INFO - 2016-05-08 12:08:49 --> Controller Class Initialized
INFO - 2016-05-08 12:08:49 --> Model Class Initialized
INFO - 2016-05-08 12:08:49 --> Database Driver Class Initialized
INFO - 2016-05-08 12:08:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:08:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:08:49 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:08:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:08:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 12:08:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:08:49 --> Final output sent to browser
DEBUG - 2016-05-08 12:08:49 --> Total execution time: 0.1185
INFO - 2016-05-08 12:08:52 --> Config Class Initialized
INFO - 2016-05-08 12:08:52 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:08:52 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:08:52 --> Utf8 Class Initialized
INFO - 2016-05-08 12:08:52 --> URI Class Initialized
INFO - 2016-05-08 12:08:52 --> Router Class Initialized
INFO - 2016-05-08 12:08:52 --> Output Class Initialized
INFO - 2016-05-08 12:08:52 --> Security Class Initialized
DEBUG - 2016-05-08 12:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:08:52 --> Input Class Initialized
INFO - 2016-05-08 12:08:52 --> Language Class Initialized
INFO - 2016-05-08 12:08:52 --> Loader Class Initialized
INFO - 2016-05-08 12:08:52 --> Helper loaded: url_helper
INFO - 2016-05-08 12:08:52 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:08:52 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:08:52 --> Helper loaded: form_helper
INFO - 2016-05-08 12:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:08:52 --> Form Validation Class Initialized
INFO - 2016-05-08 12:08:52 --> Controller Class Initialized
INFO - 2016-05-08 12:08:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:08:52 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:08:52 --> Model Class Initialized
INFO - 2016-05-08 12:08:52 --> Database Driver Class Initialized
INFO - 2016-05-08 12:08:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-08 12:08:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:08:52 --> Final output sent to browser
DEBUG - 2016-05-08 12:08:52 --> Total execution time: 0.0997
INFO - 2016-05-08 12:10:46 --> Config Class Initialized
INFO - 2016-05-08 12:10:46 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:10:46 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:10:46 --> Utf8 Class Initialized
INFO - 2016-05-08 12:10:46 --> URI Class Initialized
INFO - 2016-05-08 12:10:46 --> Router Class Initialized
INFO - 2016-05-08 12:10:46 --> Output Class Initialized
INFO - 2016-05-08 12:10:46 --> Security Class Initialized
DEBUG - 2016-05-08 12:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:10:46 --> Input Class Initialized
INFO - 2016-05-08 12:10:46 --> Language Class Initialized
INFO - 2016-05-08 12:10:46 --> Loader Class Initialized
INFO - 2016-05-08 12:10:46 --> Helper loaded: url_helper
INFO - 2016-05-08 12:10:46 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:10:46 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:10:46 --> Helper loaded: form_helper
INFO - 2016-05-08 12:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:10:46 --> Form Validation Class Initialized
INFO - 2016-05-08 12:10:46 --> Controller Class Initialized
INFO - 2016-05-08 12:10:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:10:46 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:10:46 --> Model Class Initialized
INFO - 2016-05-08 12:10:46 --> Database Driver Class Initialized
INFO - 2016-05-08 12:10:46 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-05-08 12:10:46 --> Severity: Error --> Call to private method Producto::NombreProducto_unico_check() from context 'CI_Form_validation' C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\libraries\Form_validation.php 748
INFO - 2016-05-08 12:11:15 --> Config Class Initialized
INFO - 2016-05-08 12:11:15 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:11:15 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:11:15 --> Utf8 Class Initialized
INFO - 2016-05-08 12:11:15 --> URI Class Initialized
INFO - 2016-05-08 12:11:15 --> Router Class Initialized
INFO - 2016-05-08 12:11:15 --> Output Class Initialized
INFO - 2016-05-08 12:11:15 --> Security Class Initialized
DEBUG - 2016-05-08 12:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:11:15 --> Input Class Initialized
INFO - 2016-05-08 12:11:15 --> Language Class Initialized
INFO - 2016-05-08 12:11:15 --> Loader Class Initialized
INFO - 2016-05-08 12:11:15 --> Helper loaded: url_helper
INFO - 2016-05-08 12:11:15 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:11:15 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:11:15 --> Helper loaded: form_helper
INFO - 2016-05-08 12:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:11:15 --> Form Validation Class Initialized
INFO - 2016-05-08 12:11:15 --> Controller Class Initialized
INFO - 2016-05-08 12:11:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:11:15 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:11:15 --> Model Class Initialized
INFO - 2016-05-08 12:11:15 --> Database Driver Class Initialized
INFO - 2016-05-08 12:11:15 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-05-08 12:11:15 --> Severity: Error --> Call to private method Producto::CategoriaSeleccionada_check() from context 'CI_Form_validation' C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\libraries\Form_validation.php 748
INFO - 2016-05-08 12:11:28 --> Config Class Initialized
INFO - 2016-05-08 12:11:28 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:11:29 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:11:29 --> Utf8 Class Initialized
INFO - 2016-05-08 12:11:29 --> URI Class Initialized
INFO - 2016-05-08 12:11:29 --> Router Class Initialized
INFO - 2016-05-08 12:11:29 --> Output Class Initialized
INFO - 2016-05-08 12:11:29 --> Security Class Initialized
DEBUG - 2016-05-08 12:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:11:29 --> Input Class Initialized
INFO - 2016-05-08 12:11:29 --> Language Class Initialized
INFO - 2016-05-08 12:11:29 --> Loader Class Initialized
INFO - 2016-05-08 12:11:29 --> Helper loaded: url_helper
INFO - 2016-05-08 12:11:29 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:11:29 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:11:29 --> Helper loaded: form_helper
INFO - 2016-05-08 12:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:11:29 --> Form Validation Class Initialized
INFO - 2016-05-08 12:11:29 --> Controller Class Initialized
INFO - 2016-05-08 12:11:29 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:11:29 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:11:29 --> Model Class Initialized
INFO - 2016-05-08 12:11:29 --> Database Driver Class Initialized
INFO - 2016-05-08 12:11:29 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-05-08 12:11:29 --> Severity: Error --> Call to protected method Producto::NombreProducto_unico_check() from context 'CI_Form_validation' C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\libraries\Form_validation.php 748
INFO - 2016-05-08 12:11:41 --> Config Class Initialized
INFO - 2016-05-08 12:11:41 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:11:41 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:11:41 --> Utf8 Class Initialized
INFO - 2016-05-08 12:11:41 --> URI Class Initialized
INFO - 2016-05-08 12:11:41 --> Router Class Initialized
INFO - 2016-05-08 12:11:41 --> Output Class Initialized
INFO - 2016-05-08 12:11:41 --> Security Class Initialized
DEBUG - 2016-05-08 12:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:11:41 --> Input Class Initialized
INFO - 2016-05-08 12:11:41 --> Language Class Initialized
INFO - 2016-05-08 12:11:41 --> Loader Class Initialized
INFO - 2016-05-08 12:11:41 --> Helper loaded: url_helper
INFO - 2016-05-08 12:11:41 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:11:41 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:11:41 --> Helper loaded: form_helper
INFO - 2016-05-08 12:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:11:41 --> Form Validation Class Initialized
INFO - 2016-05-08 12:11:41 --> Controller Class Initialized
INFO - 2016-05-08 12:11:41 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:11:41 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:11:41 --> Model Class Initialized
INFO - 2016-05-08 12:11:41 --> Database Driver Class Initialized
INFO - 2016-05-08 12:11:41 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 12:11:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-08 12:11:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:11:41 --> Final output sent to browser
DEBUG - 2016-05-08 12:11:41 --> Total execution time: 0.0916
INFO - 2016-05-08 12:12:04 --> Config Class Initialized
INFO - 2016-05-08 12:12:04 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:12:04 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:12:04 --> Utf8 Class Initialized
INFO - 2016-05-08 12:12:04 --> URI Class Initialized
INFO - 2016-05-08 12:12:04 --> Router Class Initialized
INFO - 2016-05-08 12:12:04 --> Output Class Initialized
INFO - 2016-05-08 12:12:04 --> Security Class Initialized
DEBUG - 2016-05-08 12:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:12:04 --> Input Class Initialized
INFO - 2016-05-08 12:12:04 --> Language Class Initialized
INFO - 2016-05-08 12:12:04 --> Loader Class Initialized
INFO - 2016-05-08 12:12:04 --> Helper loaded: url_helper
INFO - 2016-05-08 12:12:04 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:12:04 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:12:04 --> Helper loaded: form_helper
INFO - 2016-05-08 12:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:12:04 --> Form Validation Class Initialized
INFO - 2016-05-08 12:12:04 --> Controller Class Initialized
INFO - 2016-05-08 12:12:04 --> Model Class Initialized
INFO - 2016-05-08 12:12:05 --> Database Driver Class Initialized
INFO - 2016-05-08 12:12:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:12:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:12:05 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:12:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-08 12:12:05 --> Severity: Notice --> Undefined index: idProducto C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 300
ERROR - 2016-05-08 12:12:05 --> Severity: Notice --> Undefined index: imagen C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php 79
INFO - 2016-05-08 12:12:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-08 12:12:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:12:05 --> Final output sent to browser
DEBUG - 2016-05-08 12:12:05 --> Total execution time: 0.1015
INFO - 2016-05-08 12:12:05 --> Config Class Initialized
INFO - 2016-05-08 12:12:05 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:12:05 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:12:05 --> Utf8 Class Initialized
INFO - 2016-05-08 12:13:16 --> Config Class Initialized
INFO - 2016-05-08 12:13:16 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:13:16 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:13:16 --> Utf8 Class Initialized
INFO - 2016-05-08 12:13:16 --> URI Class Initialized
INFO - 2016-05-08 12:13:16 --> Router Class Initialized
INFO - 2016-05-08 12:13:16 --> Output Class Initialized
INFO - 2016-05-08 12:13:16 --> Security Class Initialized
DEBUG - 2016-05-08 12:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:13:16 --> Input Class Initialized
INFO - 2016-05-08 12:13:16 --> Language Class Initialized
INFO - 2016-05-08 12:13:16 --> Loader Class Initialized
INFO - 2016-05-08 12:13:16 --> Helper loaded: url_helper
INFO - 2016-05-08 12:13:16 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:13:16 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:13:16 --> Helper loaded: form_helper
INFO - 2016-05-08 12:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:13:16 --> Form Validation Class Initialized
INFO - 2016-05-08 12:13:16 --> Controller Class Initialized
INFO - 2016-05-08 12:13:16 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:13:16 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:13:16 --> Model Class Initialized
INFO - 2016-05-08 12:13:16 --> Database Driver Class Initialized
INFO - 2016-05-08 12:13:16 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 12:13:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-08 12:13:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:13:16 --> Final output sent to browser
DEBUG - 2016-05-08 12:13:16 --> Total execution time: 0.0834
INFO - 2016-05-08 12:14:20 --> Config Class Initialized
INFO - 2016-05-08 12:14:20 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:14:20 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:14:20 --> Utf8 Class Initialized
INFO - 2016-05-08 12:14:20 --> URI Class Initialized
INFO - 2016-05-08 12:14:20 --> Router Class Initialized
INFO - 2016-05-08 12:14:20 --> Output Class Initialized
INFO - 2016-05-08 12:14:20 --> Security Class Initialized
DEBUG - 2016-05-08 12:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:14:20 --> Input Class Initialized
INFO - 2016-05-08 12:14:20 --> Language Class Initialized
INFO - 2016-05-08 12:14:20 --> Loader Class Initialized
INFO - 2016-05-08 12:14:20 --> Helper loaded: url_helper
INFO - 2016-05-08 12:14:20 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:14:20 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:14:20 --> Helper loaded: form_helper
INFO - 2016-05-08 12:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:14:20 --> Form Validation Class Initialized
INFO - 2016-05-08 12:14:20 --> Controller Class Initialized
INFO - 2016-05-08 12:14:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:14:20 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:14:20 --> Model Class Initialized
INFO - 2016-05-08 12:14:20 --> Database Driver Class Initialized
INFO - 2016-05-08 12:14:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-08 12:14:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:14:20 --> Final output sent to browser
DEBUG - 2016-05-08 12:14:20 --> Total execution time: 0.1775
INFO - 2016-05-08 12:14:29 --> Config Class Initialized
INFO - 2016-05-08 12:14:29 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:14:29 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:14:29 --> Utf8 Class Initialized
INFO - 2016-05-08 12:14:29 --> URI Class Initialized
INFO - 2016-05-08 12:14:29 --> Router Class Initialized
INFO - 2016-05-08 12:14:29 --> Output Class Initialized
INFO - 2016-05-08 12:14:29 --> Security Class Initialized
DEBUG - 2016-05-08 12:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:14:29 --> Input Class Initialized
INFO - 2016-05-08 12:14:29 --> Language Class Initialized
INFO - 2016-05-08 12:14:29 --> Loader Class Initialized
INFO - 2016-05-08 12:14:29 --> Helper loaded: url_helper
INFO - 2016-05-08 12:14:29 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:14:29 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:14:29 --> Helper loaded: form_helper
INFO - 2016-05-08 12:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:14:29 --> Form Validation Class Initialized
INFO - 2016-05-08 12:14:29 --> Controller Class Initialized
INFO - 2016-05-08 12:14:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-08 12:14:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:14:29 --> Final output sent to browser
DEBUG - 2016-05-08 12:14:29 --> Total execution time: 0.0498
INFO - 2016-05-08 12:14:38 --> Config Class Initialized
INFO - 2016-05-08 12:14:38 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:14:38 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:14:38 --> Utf8 Class Initialized
INFO - 2016-05-08 12:14:38 --> URI Class Initialized
INFO - 2016-05-08 12:14:38 --> Router Class Initialized
INFO - 2016-05-08 12:14:38 --> Output Class Initialized
INFO - 2016-05-08 12:14:38 --> Security Class Initialized
DEBUG - 2016-05-08 12:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:14:38 --> Input Class Initialized
INFO - 2016-05-08 12:14:38 --> Language Class Initialized
INFO - 2016-05-08 12:14:38 --> Loader Class Initialized
INFO - 2016-05-08 12:14:38 --> Helper loaded: url_helper
INFO - 2016-05-08 12:14:38 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:14:38 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:14:38 --> Helper loaded: form_helper
INFO - 2016-05-08 12:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:14:38 --> Form Validation Class Initialized
INFO - 2016-05-08 12:14:38 --> Controller Class Initialized
INFO - 2016-05-08 12:14:38 --> Model Class Initialized
INFO - 2016-05-08 12:14:38 --> Database Driver Class Initialized
INFO - 2016-05-08 12:14:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:14:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:14:38 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:14:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:14:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 12:14:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:14:38 --> Final output sent to browser
DEBUG - 2016-05-08 12:14:38 --> Total execution time: 0.1340
INFO - 2016-05-08 12:14:41 --> Config Class Initialized
INFO - 2016-05-08 12:14:41 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:14:41 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:14:41 --> Utf8 Class Initialized
INFO - 2016-05-08 12:14:41 --> URI Class Initialized
INFO - 2016-05-08 12:14:41 --> Router Class Initialized
INFO - 2016-05-08 12:14:41 --> Output Class Initialized
INFO - 2016-05-08 12:14:41 --> Security Class Initialized
DEBUG - 2016-05-08 12:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:14:41 --> Input Class Initialized
INFO - 2016-05-08 12:14:41 --> Language Class Initialized
INFO - 2016-05-08 12:14:41 --> Loader Class Initialized
INFO - 2016-05-08 12:14:41 --> Helper loaded: url_helper
INFO - 2016-05-08 12:14:41 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:14:41 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:14:41 --> Helper loaded: form_helper
INFO - 2016-05-08 12:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:14:41 --> Form Validation Class Initialized
INFO - 2016-05-08 12:14:41 --> Controller Class Initialized
INFO - 2016-05-08 12:14:41 --> Model Class Initialized
INFO - 2016-05-08 12:14:41 --> Database Driver Class Initialized
INFO - 2016-05-08 12:14:41 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:14:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:14:41 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:14:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:14:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 12:14:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:14:41 --> Final output sent to browser
DEBUG - 2016-05-08 12:14:41 --> Total execution time: 0.1102
INFO - 2016-05-08 12:14:43 --> Config Class Initialized
INFO - 2016-05-08 12:14:43 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:14:43 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:14:43 --> Utf8 Class Initialized
INFO - 2016-05-08 12:14:43 --> URI Class Initialized
INFO - 2016-05-08 12:14:43 --> Router Class Initialized
INFO - 2016-05-08 12:14:43 --> Output Class Initialized
INFO - 2016-05-08 12:14:43 --> Security Class Initialized
DEBUG - 2016-05-08 12:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:14:43 --> Input Class Initialized
INFO - 2016-05-08 12:14:43 --> Language Class Initialized
INFO - 2016-05-08 12:14:43 --> Loader Class Initialized
INFO - 2016-05-08 12:14:43 --> Helper loaded: url_helper
INFO - 2016-05-08 12:14:43 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:14:43 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:14:43 --> Helper loaded: form_helper
INFO - 2016-05-08 12:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:14:43 --> Form Validation Class Initialized
INFO - 2016-05-08 12:14:43 --> Controller Class Initialized
INFO - 2016-05-08 12:14:43 --> Model Class Initialized
INFO - 2016-05-08 12:14:43 --> Database Driver Class Initialized
INFO - 2016-05-08 12:14:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:14:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:14:43 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:14:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:14:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-08 12:14:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:14:43 --> Final output sent to browser
DEBUG - 2016-05-08 12:14:43 --> Total execution time: 0.1343
INFO - 2016-05-08 12:17:05 --> Config Class Initialized
INFO - 2016-05-08 12:17:05 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:17:05 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:17:05 --> Utf8 Class Initialized
INFO - 2016-05-08 12:17:05 --> URI Class Initialized
INFO - 2016-05-08 12:17:05 --> Router Class Initialized
INFO - 2016-05-08 12:17:05 --> Output Class Initialized
INFO - 2016-05-08 12:17:05 --> Security Class Initialized
DEBUG - 2016-05-08 12:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:17:05 --> Input Class Initialized
INFO - 2016-05-08 12:17:05 --> Language Class Initialized
INFO - 2016-05-08 12:17:05 --> Loader Class Initialized
INFO - 2016-05-08 12:17:05 --> Helper loaded: url_helper
INFO - 2016-05-08 12:17:05 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:17:05 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:17:05 --> Helper loaded: form_helper
INFO - 2016-05-08 12:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:17:05 --> Form Validation Class Initialized
INFO - 2016-05-08 12:17:05 --> Controller Class Initialized
INFO - 2016-05-08 12:17:05 --> Model Class Initialized
INFO - 2016-05-08 12:17:05 --> Database Driver Class Initialized
INFO - 2016-05-08 12:17:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:17:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:17:05 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:17:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:17:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-08 12:17:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:17:05 --> Final output sent to browser
DEBUG - 2016-05-08 12:17:05 --> Total execution time: 0.1143
INFO - 2016-05-08 12:17:07 --> Config Class Initialized
INFO - 2016-05-08 12:17:07 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:17:07 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:17:07 --> Utf8 Class Initialized
INFO - 2016-05-08 12:17:07 --> URI Class Initialized
INFO - 2016-05-08 12:17:07 --> Router Class Initialized
INFO - 2016-05-08 12:17:07 --> Output Class Initialized
INFO - 2016-05-08 12:17:07 --> Security Class Initialized
DEBUG - 2016-05-08 12:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:17:07 --> Input Class Initialized
INFO - 2016-05-08 12:17:07 --> Language Class Initialized
INFO - 2016-05-08 12:17:07 --> Loader Class Initialized
INFO - 2016-05-08 12:17:07 --> Helper loaded: url_helper
INFO - 2016-05-08 12:17:07 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:17:07 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:17:07 --> Helper loaded: form_helper
INFO - 2016-05-08 12:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:17:07 --> Form Validation Class Initialized
INFO - 2016-05-08 12:17:07 --> Controller Class Initialized
INFO - 2016-05-08 12:17:07 --> Model Class Initialized
INFO - 2016-05-08 12:17:07 --> Database Driver Class Initialized
INFO - 2016-05-08 12:17:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:17:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:17:07 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:17:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:17:07 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 12:17:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-08 12:17:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:17:07 --> Final output sent to browser
DEBUG - 2016-05-08 12:17:07 --> Total execution time: 0.1827
INFO - 2016-05-08 12:17:48 --> Config Class Initialized
INFO - 2016-05-08 12:17:48 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:17:48 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:17:48 --> Utf8 Class Initialized
INFO - 2016-05-08 12:17:48 --> URI Class Initialized
INFO - 2016-05-08 12:17:48 --> Router Class Initialized
INFO - 2016-05-08 12:17:48 --> Output Class Initialized
INFO - 2016-05-08 12:17:48 --> Security Class Initialized
DEBUG - 2016-05-08 12:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:17:48 --> Input Class Initialized
INFO - 2016-05-08 12:17:48 --> Language Class Initialized
INFO - 2016-05-08 12:17:48 --> Loader Class Initialized
INFO - 2016-05-08 12:17:48 --> Helper loaded: url_helper
INFO - 2016-05-08 12:17:48 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:17:48 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:17:48 --> Helper loaded: form_helper
INFO - 2016-05-08 12:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:17:48 --> Form Validation Class Initialized
INFO - 2016-05-08 12:17:48 --> Controller Class Initialized
INFO - 2016-05-08 12:17:48 --> Model Class Initialized
INFO - 2016-05-08 12:17:48 --> Database Driver Class Initialized
INFO - 2016-05-08 12:17:48 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:17:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:17:48 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:17:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:17:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-08 12:17:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:17:49 --> Final output sent to browser
DEBUG - 2016-05-08 12:17:49 --> Total execution time: 0.2146
INFO - 2016-05-08 12:17:51 --> Config Class Initialized
INFO - 2016-05-08 12:17:51 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:17:51 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:17:51 --> Utf8 Class Initialized
INFO - 2016-05-08 12:17:51 --> URI Class Initialized
INFO - 2016-05-08 12:17:51 --> Router Class Initialized
INFO - 2016-05-08 12:17:51 --> Output Class Initialized
INFO - 2016-05-08 12:17:51 --> Security Class Initialized
DEBUG - 2016-05-08 12:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:17:51 --> Input Class Initialized
INFO - 2016-05-08 12:17:51 --> Language Class Initialized
INFO - 2016-05-08 12:17:51 --> Loader Class Initialized
INFO - 2016-05-08 12:17:51 --> Helper loaded: url_helper
INFO - 2016-05-08 12:17:51 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:17:51 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:17:51 --> Helper loaded: form_helper
INFO - 2016-05-08 12:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:17:51 --> Form Validation Class Initialized
INFO - 2016-05-08 12:17:51 --> Controller Class Initialized
INFO - 2016-05-08 12:17:51 --> Model Class Initialized
INFO - 2016-05-08 12:17:51 --> Database Driver Class Initialized
INFO - 2016-05-08 12:17:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:17:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:17:51 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:17:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:17:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 12:17:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:17:51 --> Final output sent to browser
DEBUG - 2016-05-08 12:17:51 --> Total execution time: 0.1981
INFO - 2016-05-08 12:17:53 --> Config Class Initialized
INFO - 2016-05-08 12:17:53 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:17:53 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:17:53 --> Utf8 Class Initialized
INFO - 2016-05-08 12:17:53 --> URI Class Initialized
INFO - 2016-05-08 12:17:54 --> Router Class Initialized
INFO - 2016-05-08 12:17:54 --> Output Class Initialized
INFO - 2016-05-08 12:17:54 --> Security Class Initialized
DEBUG - 2016-05-08 12:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:17:54 --> Input Class Initialized
INFO - 2016-05-08 12:17:54 --> Language Class Initialized
INFO - 2016-05-08 12:17:54 --> Loader Class Initialized
INFO - 2016-05-08 12:17:54 --> Helper loaded: url_helper
INFO - 2016-05-08 12:17:54 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:17:54 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:17:54 --> Helper loaded: form_helper
INFO - 2016-05-08 12:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:17:54 --> Form Validation Class Initialized
INFO - 2016-05-08 12:17:54 --> Controller Class Initialized
INFO - 2016-05-08 12:17:54 --> Model Class Initialized
INFO - 2016-05-08 12:17:54 --> Database Driver Class Initialized
INFO - 2016-05-08 12:17:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:17:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:17:54 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:17:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:17:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 12:17:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:17:54 --> Final output sent to browser
DEBUG - 2016-05-08 12:17:54 --> Total execution time: 0.1388
INFO - 2016-05-08 12:18:03 --> Config Class Initialized
INFO - 2016-05-08 12:18:03 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:18:03 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:18:03 --> Utf8 Class Initialized
INFO - 2016-05-08 12:18:03 --> URI Class Initialized
INFO - 2016-05-08 12:18:03 --> Router Class Initialized
INFO - 2016-05-08 12:18:03 --> Output Class Initialized
INFO - 2016-05-08 12:18:03 --> Security Class Initialized
DEBUG - 2016-05-08 12:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:18:03 --> Input Class Initialized
INFO - 2016-05-08 12:18:03 --> Language Class Initialized
INFO - 2016-05-08 12:18:03 --> Loader Class Initialized
INFO - 2016-05-08 12:18:03 --> Helper loaded: url_helper
INFO - 2016-05-08 12:18:03 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:18:03 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:18:03 --> Helper loaded: form_helper
INFO - 2016-05-08 12:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:18:03 --> Form Validation Class Initialized
INFO - 2016-05-08 12:18:03 --> Controller Class Initialized
INFO - 2016-05-08 12:18:03 --> Model Class Initialized
INFO - 2016-05-08 12:18:03 --> Database Driver Class Initialized
INFO - 2016-05-08 12:18:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:18:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:18:03 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:18:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:18:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-08 12:18:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:18:04 --> Final output sent to browser
DEBUG - 2016-05-08 12:18:04 --> Total execution time: 0.1220
INFO - 2016-05-08 12:18:05 --> Config Class Initialized
INFO - 2016-05-08 12:18:05 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:18:05 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:18:05 --> Utf8 Class Initialized
INFO - 2016-05-08 12:18:05 --> URI Class Initialized
INFO - 2016-05-08 12:18:05 --> Router Class Initialized
INFO - 2016-05-08 12:18:05 --> Output Class Initialized
INFO - 2016-05-08 12:18:05 --> Security Class Initialized
DEBUG - 2016-05-08 12:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:18:05 --> Input Class Initialized
INFO - 2016-05-08 12:18:05 --> Language Class Initialized
INFO - 2016-05-08 12:18:05 --> Loader Class Initialized
INFO - 2016-05-08 12:18:05 --> Helper loaded: url_helper
INFO - 2016-05-08 12:18:05 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:18:05 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:18:05 --> Helper loaded: form_helper
INFO - 2016-05-08 12:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:18:05 --> Form Validation Class Initialized
INFO - 2016-05-08 12:18:05 --> Controller Class Initialized
INFO - 2016-05-08 12:18:05 --> Model Class Initialized
INFO - 2016-05-08 12:18:05 --> Database Driver Class Initialized
INFO - 2016-05-08 12:18:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:18:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:18:05 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:18:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:18:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 12:18:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:18:05 --> Final output sent to browser
DEBUG - 2016-05-08 12:18:05 --> Total execution time: 0.0882
INFO - 2016-05-08 12:18:07 --> Config Class Initialized
INFO - 2016-05-08 12:18:07 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:18:07 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:18:07 --> Utf8 Class Initialized
INFO - 2016-05-08 12:18:07 --> URI Class Initialized
INFO - 2016-05-08 12:18:07 --> Router Class Initialized
INFO - 2016-05-08 12:18:07 --> Output Class Initialized
INFO - 2016-05-08 12:18:07 --> Security Class Initialized
DEBUG - 2016-05-08 12:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:18:07 --> Input Class Initialized
INFO - 2016-05-08 12:18:07 --> Language Class Initialized
INFO - 2016-05-08 12:18:07 --> Loader Class Initialized
INFO - 2016-05-08 12:18:07 --> Helper loaded: url_helper
INFO - 2016-05-08 12:18:07 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:18:07 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:18:07 --> Helper loaded: form_helper
INFO - 2016-05-08 12:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:18:07 --> Form Validation Class Initialized
INFO - 2016-05-08 12:18:07 --> Controller Class Initialized
INFO - 2016-05-08 12:18:07 --> Model Class Initialized
INFO - 2016-05-08 12:18:07 --> Database Driver Class Initialized
INFO - 2016-05-08 12:18:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:18:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:18:07 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:18:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:18:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-08 12:18:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:18:07 --> Final output sent to browser
DEBUG - 2016-05-08 12:18:07 --> Total execution time: 0.1568
INFO - 2016-05-08 12:18:12 --> Config Class Initialized
INFO - 2016-05-08 12:18:12 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:18:12 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:18:12 --> Utf8 Class Initialized
INFO - 2016-05-08 12:18:12 --> URI Class Initialized
INFO - 2016-05-08 12:18:12 --> Router Class Initialized
INFO - 2016-05-08 12:18:12 --> Output Class Initialized
INFO - 2016-05-08 12:18:12 --> Security Class Initialized
DEBUG - 2016-05-08 12:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:18:12 --> Input Class Initialized
INFO - 2016-05-08 12:18:12 --> Language Class Initialized
INFO - 2016-05-08 12:18:12 --> Loader Class Initialized
INFO - 2016-05-08 12:18:12 --> Helper loaded: url_helper
INFO - 2016-05-08 12:18:12 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:18:12 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:18:12 --> Helper loaded: form_helper
INFO - 2016-05-08 12:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:18:12 --> Form Validation Class Initialized
INFO - 2016-05-08 12:18:12 --> Controller Class Initialized
INFO - 2016-05-08 12:18:12 --> Model Class Initialized
INFO - 2016-05-08 12:18:12 --> Database Driver Class Initialized
INFO - 2016-05-08 12:18:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:18:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:18:12 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:18:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:18:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 12:18:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:18:12 --> Final output sent to browser
DEBUG - 2016-05-08 12:18:12 --> Total execution time: 0.0905
INFO - 2016-05-08 12:18:16 --> Config Class Initialized
INFO - 2016-05-08 12:18:16 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:18:16 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:18:16 --> Utf8 Class Initialized
INFO - 2016-05-08 12:18:16 --> URI Class Initialized
INFO - 2016-05-08 12:18:16 --> Router Class Initialized
INFO - 2016-05-08 12:18:16 --> Output Class Initialized
INFO - 2016-05-08 12:18:16 --> Security Class Initialized
DEBUG - 2016-05-08 12:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:18:16 --> Input Class Initialized
INFO - 2016-05-08 12:18:16 --> Language Class Initialized
INFO - 2016-05-08 12:18:16 --> Loader Class Initialized
INFO - 2016-05-08 12:18:16 --> Helper loaded: url_helper
INFO - 2016-05-08 12:18:16 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:18:16 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:18:16 --> Helper loaded: form_helper
INFO - 2016-05-08 12:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:18:16 --> Form Validation Class Initialized
INFO - 2016-05-08 12:18:16 --> Controller Class Initialized
INFO - 2016-05-08 12:18:16 --> Model Class Initialized
INFO - 2016-05-08 12:18:16 --> Database Driver Class Initialized
INFO - 2016-05-08 12:18:16 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:18:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:18:16 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:18:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:18:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-08 12:18:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:18:16 --> Final output sent to browser
DEBUG - 2016-05-08 12:18:16 --> Total execution time: 0.1075
INFO - 2016-05-08 12:18:44 --> Config Class Initialized
INFO - 2016-05-08 12:18:44 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:18:44 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:18:44 --> Utf8 Class Initialized
INFO - 2016-05-08 12:18:44 --> URI Class Initialized
INFO - 2016-05-08 12:18:44 --> Router Class Initialized
INFO - 2016-05-08 12:18:44 --> Output Class Initialized
INFO - 2016-05-08 12:18:44 --> Security Class Initialized
DEBUG - 2016-05-08 12:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:18:44 --> Input Class Initialized
INFO - 2016-05-08 12:18:44 --> Language Class Initialized
INFO - 2016-05-08 12:18:44 --> Loader Class Initialized
INFO - 2016-05-08 12:18:44 --> Helper loaded: url_helper
INFO - 2016-05-08 12:18:44 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:18:44 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:18:44 --> Helper loaded: form_helper
INFO - 2016-05-08 12:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:18:44 --> Form Validation Class Initialized
INFO - 2016-05-08 12:18:44 --> Controller Class Initialized
INFO - 2016-05-08 12:18:44 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:18:44 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:18:44 --> Model Class Initialized
INFO - 2016-05-08 12:18:44 --> Database Driver Class Initialized
INFO - 2016-05-08 12:18:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-08 12:18:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:18:44 --> Final output sent to browser
DEBUG - 2016-05-08 12:18:44 --> Total execution time: 0.1059
INFO - 2016-05-08 12:19:07 --> Config Class Initialized
INFO - 2016-05-08 12:19:07 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:19:07 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:19:07 --> Utf8 Class Initialized
INFO - 2016-05-08 12:19:07 --> URI Class Initialized
INFO - 2016-05-08 12:19:07 --> Router Class Initialized
INFO - 2016-05-08 12:19:07 --> Output Class Initialized
INFO - 2016-05-08 12:19:07 --> Security Class Initialized
DEBUG - 2016-05-08 12:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:19:07 --> Input Class Initialized
INFO - 2016-05-08 12:19:07 --> Language Class Initialized
INFO - 2016-05-08 12:19:07 --> Loader Class Initialized
INFO - 2016-05-08 12:19:07 --> Helper loaded: url_helper
INFO - 2016-05-08 12:19:07 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:19:07 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:19:07 --> Helper loaded: form_helper
INFO - 2016-05-08 12:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:19:07 --> Form Validation Class Initialized
INFO - 2016-05-08 12:19:07 --> Controller Class Initialized
INFO - 2016-05-08 12:19:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:19:07 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:19:07 --> Model Class Initialized
INFO - 2016-05-08 12:19:07 --> Database Driver Class Initialized
INFO - 2016-05-08 12:19:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-08 12:19:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:19:07 --> Final output sent to browser
DEBUG - 2016-05-08 12:19:07 --> Total execution time: 0.0963
INFO - 2016-05-08 12:19:09 --> Config Class Initialized
INFO - 2016-05-08 12:19:09 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:19:09 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:19:09 --> Utf8 Class Initialized
INFO - 2016-05-08 12:19:09 --> URI Class Initialized
INFO - 2016-05-08 12:19:09 --> Router Class Initialized
INFO - 2016-05-08 12:19:09 --> Output Class Initialized
INFO - 2016-05-08 12:19:09 --> Security Class Initialized
DEBUG - 2016-05-08 12:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:19:09 --> Input Class Initialized
INFO - 2016-05-08 12:19:09 --> Language Class Initialized
INFO - 2016-05-08 12:19:09 --> Loader Class Initialized
INFO - 2016-05-08 12:19:09 --> Helper loaded: url_helper
INFO - 2016-05-08 12:19:09 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:19:09 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:19:09 --> Helper loaded: form_helper
INFO - 2016-05-08 12:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:19:09 --> Form Validation Class Initialized
INFO - 2016-05-08 12:19:09 --> Controller Class Initialized
INFO - 2016-05-08 12:19:09 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:19:09 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:19:09 --> Model Class Initialized
INFO - 2016-05-08 12:19:09 --> Database Driver Class Initialized
INFO - 2016-05-08 12:19:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-08 12:19:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:19:10 --> Final output sent to browser
DEBUG - 2016-05-08 12:19:10 --> Total execution time: 0.0990
INFO - 2016-05-08 12:23:12 --> Config Class Initialized
INFO - 2016-05-08 12:23:12 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:23:12 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:23:12 --> Utf8 Class Initialized
INFO - 2016-05-08 12:23:12 --> URI Class Initialized
INFO - 2016-05-08 12:23:12 --> Router Class Initialized
INFO - 2016-05-08 12:23:12 --> Output Class Initialized
INFO - 2016-05-08 12:23:12 --> Security Class Initialized
DEBUG - 2016-05-08 12:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:23:12 --> Input Class Initialized
INFO - 2016-05-08 12:23:12 --> Language Class Initialized
INFO - 2016-05-08 12:23:12 --> Loader Class Initialized
INFO - 2016-05-08 12:23:12 --> Helper loaded: url_helper
INFO - 2016-05-08 12:23:12 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:23:12 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:23:12 --> Helper loaded: form_helper
INFO - 2016-05-08 12:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:23:12 --> Form Validation Class Initialized
INFO - 2016-05-08 12:23:12 --> Controller Class Initialized
INFO - 2016-05-08 12:23:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:23:12 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:23:12 --> Model Class Initialized
INFO - 2016-05-08 12:23:12 --> Database Driver Class Initialized
INFO - 2016-05-08 12:23:12 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-08 12:23:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-08 12:23:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:23:12 --> Final output sent to browser
DEBUG - 2016-05-08 12:23:12 --> Total execution time: 0.1309
INFO - 2016-05-08 12:23:54 --> Config Class Initialized
INFO - 2016-05-08 12:23:54 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:23:54 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:23:54 --> Utf8 Class Initialized
INFO - 2016-05-08 12:23:54 --> URI Class Initialized
INFO - 2016-05-08 12:23:54 --> Router Class Initialized
INFO - 2016-05-08 12:23:54 --> Output Class Initialized
INFO - 2016-05-08 12:23:54 --> Security Class Initialized
DEBUG - 2016-05-08 12:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:23:54 --> Input Class Initialized
INFO - 2016-05-08 12:23:54 --> Language Class Initialized
INFO - 2016-05-08 12:23:54 --> Loader Class Initialized
INFO - 2016-05-08 12:23:54 --> Helper loaded: url_helper
INFO - 2016-05-08 12:23:54 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:23:54 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:23:54 --> Helper loaded: form_helper
INFO - 2016-05-08 12:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:23:54 --> Form Validation Class Initialized
INFO - 2016-05-08 12:23:54 --> Controller Class Initialized
INFO - 2016-05-08 12:23:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:23:54 --> Helper loaded: nif_validate_helper
INFO - 2016-05-08 12:23:54 --> Model Class Initialized
INFO - 2016-05-08 12:23:54 --> Database Driver Class Initialized
INFO - 2016-05-08 12:23:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-08 12:23:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:23:54 --> Final output sent to browser
DEBUG - 2016-05-08 12:23:54 --> Total execution time: 0.1687
INFO - 2016-05-08 12:23:57 --> Config Class Initialized
INFO - 2016-05-08 12:23:57 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:23:57 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:23:57 --> Utf8 Class Initialized
INFO - 2016-05-08 12:23:57 --> URI Class Initialized
INFO - 2016-05-08 12:23:57 --> Router Class Initialized
INFO - 2016-05-08 12:23:57 --> Output Class Initialized
INFO - 2016-05-08 12:23:57 --> Security Class Initialized
DEBUG - 2016-05-08 12:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:23:57 --> Input Class Initialized
INFO - 2016-05-08 12:23:57 --> Language Class Initialized
INFO - 2016-05-08 12:23:57 --> Loader Class Initialized
INFO - 2016-05-08 12:23:57 --> Helper loaded: url_helper
INFO - 2016-05-08 12:23:57 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:23:57 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:23:57 --> Helper loaded: form_helper
INFO - 2016-05-08 12:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:23:57 --> Form Validation Class Initialized
INFO - 2016-05-08 12:23:57 --> Controller Class Initialized
INFO - 2016-05-08 12:23:57 --> Model Class Initialized
INFO - 2016-05-08 12:23:57 --> Database Driver Class Initialized
INFO - 2016-05-08 12:23:57 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:23:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:23:57 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:23:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:23:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 12:23:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:23:57 --> Final output sent to browser
DEBUG - 2016-05-08 12:23:57 --> Total execution time: 0.1075
INFO - 2016-05-08 12:24:00 --> Config Class Initialized
INFO - 2016-05-08 12:24:00 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:24:00 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:24:00 --> Utf8 Class Initialized
INFO - 2016-05-08 12:24:00 --> URI Class Initialized
INFO - 2016-05-08 12:24:00 --> Router Class Initialized
INFO - 2016-05-08 12:24:00 --> Output Class Initialized
INFO - 2016-05-08 12:24:00 --> Security Class Initialized
DEBUG - 2016-05-08 12:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:24:00 --> Input Class Initialized
INFO - 2016-05-08 12:24:00 --> Language Class Initialized
INFO - 2016-05-08 12:24:00 --> Loader Class Initialized
INFO - 2016-05-08 12:24:00 --> Helper loaded: url_helper
INFO - 2016-05-08 12:24:00 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:24:00 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:24:00 --> Helper loaded: form_helper
INFO - 2016-05-08 12:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:24:00 --> Form Validation Class Initialized
INFO - 2016-05-08 12:24:00 --> Controller Class Initialized
INFO - 2016-05-08 12:24:00 --> Model Class Initialized
INFO - 2016-05-08 12:24:00 --> Database Driver Class Initialized
INFO - 2016-05-08 12:24:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:24:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:24:00 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:24:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:24:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-08 12:24:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:24:00 --> Final output sent to browser
DEBUG - 2016-05-08 12:24:00 --> Total execution time: 0.1015
INFO - 2016-05-08 12:24:03 --> Config Class Initialized
INFO - 2016-05-08 12:24:03 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:24:03 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:24:03 --> Utf8 Class Initialized
INFO - 2016-05-08 12:24:03 --> URI Class Initialized
INFO - 2016-05-08 12:24:03 --> Router Class Initialized
INFO - 2016-05-08 12:24:03 --> Output Class Initialized
INFO - 2016-05-08 12:24:03 --> Security Class Initialized
DEBUG - 2016-05-08 12:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:24:03 --> Input Class Initialized
INFO - 2016-05-08 12:24:03 --> Language Class Initialized
INFO - 2016-05-08 12:24:03 --> Loader Class Initialized
INFO - 2016-05-08 12:24:03 --> Helper loaded: url_helper
INFO - 2016-05-08 12:24:03 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:24:03 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:24:03 --> Helper loaded: form_helper
INFO - 2016-05-08 12:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:24:03 --> Form Validation Class Initialized
INFO - 2016-05-08 12:24:03 --> Controller Class Initialized
INFO - 2016-05-08 12:24:03 --> Model Class Initialized
INFO - 2016-05-08 12:24:03 --> Database Driver Class Initialized
INFO - 2016-05-08 12:24:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-08 12:24:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-08 12:24:04 --> Pagination Class Initialized
DEBUG - 2016-05-08 12:24:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-08 12:24:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-08 12:24:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:24:04 --> Final output sent to browser
DEBUG - 2016-05-08 12:24:04 --> Total execution time: 0.1493
INFO - 2016-05-08 12:25:30 --> Config Class Initialized
INFO - 2016-05-08 12:25:30 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:25:30 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:25:30 --> Utf8 Class Initialized
INFO - 2016-05-08 12:25:30 --> URI Class Initialized
INFO - 2016-05-08 12:25:30 --> Router Class Initialized
INFO - 2016-05-08 12:25:30 --> Output Class Initialized
INFO - 2016-05-08 12:25:30 --> Security Class Initialized
DEBUG - 2016-05-08 12:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:25:30 --> Input Class Initialized
INFO - 2016-05-08 12:25:30 --> Language Class Initialized
INFO - 2016-05-08 12:25:30 --> Loader Class Initialized
INFO - 2016-05-08 12:25:30 --> Helper loaded: url_helper
INFO - 2016-05-08 12:25:30 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:25:30 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:25:30 --> Helper loaded: form_helper
INFO - 2016-05-08 12:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:25:30 --> Form Validation Class Initialized
INFO - 2016-05-08 12:25:30 --> Controller Class Initialized
INFO - 2016-05-08 12:25:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-08 12:25:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:25:30 --> Final output sent to browser
DEBUG - 2016-05-08 12:25:30 --> Total execution time: 0.7107
INFO - 2016-05-08 12:25:32 --> Config Class Initialized
INFO - 2016-05-08 12:25:32 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:25:32 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:25:32 --> Utf8 Class Initialized
INFO - 2016-05-08 12:25:32 --> URI Class Initialized
INFO - 2016-05-08 12:25:32 --> Router Class Initialized
INFO - 2016-05-08 12:25:32 --> Output Class Initialized
INFO - 2016-05-08 12:25:32 --> Security Class Initialized
DEBUG - 2016-05-08 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:25:32 --> Input Class Initialized
INFO - 2016-05-08 12:25:32 --> Language Class Initialized
INFO - 2016-05-08 12:25:32 --> Loader Class Initialized
INFO - 2016-05-08 12:25:32 --> Helper loaded: url_helper
INFO - 2016-05-08 12:25:32 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:25:35 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:25:35 --> Helper loaded: form_helper
INFO - 2016-05-08 12:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:25:35 --> Form Validation Class Initialized
INFO - 2016-05-08 12:25:35 --> Controller Class Initialized
INFO - 2016-05-08 12:25:35 --> Config Class Initialized
INFO - 2016-05-08 12:25:35 --> Hooks Class Initialized
INFO - 2016-05-08 12:25:35 --> Config Class Initialized
INFO - 2016-05-08 12:25:35 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:25:35 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:25:35 --> Utf8 Class Initialized
INFO - 2016-05-08 12:25:35 --> URI Class Initialized
DEBUG - 2016-05-08 12:25:35 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:25:35 --> Router Class Initialized
INFO - 2016-05-08 12:25:35 --> Utf8 Class Initialized
INFO - 2016-05-08 12:25:35 --> URI Class Initialized
INFO - 2016-05-08 12:25:35 --> Output Class Initialized
INFO - 2016-05-08 12:25:35 --> Router Class Initialized
INFO - 2016-05-08 12:25:35 --> Security Class Initialized
DEBUG - 2016-05-08 12:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:25:35 --> Output Class Initialized
INFO - 2016-05-08 12:25:35 --> Input Class Initialized
INFO - 2016-05-08 12:25:35 --> Language Class Initialized
INFO - 2016-05-08 12:25:35 --> Security Class Initialized
DEBUG - 2016-05-08 12:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:25:35 --> Input Class Initialized
INFO - 2016-05-08 12:25:35 --> Loader Class Initialized
INFO - 2016-05-08 12:25:35 --> Language Class Initialized
INFO - 2016-05-08 12:25:35 --> Helper loaded: url_helper
INFO - 2016-05-08 12:25:35 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:25:35 --> Loader Class Initialized
INFO - 2016-05-08 12:25:35 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:25:35 --> Helper loaded: url_helper
INFO - 2016-05-08 12:25:35 --> Helper loaded: form_helper
INFO - 2016-05-08 12:25:35 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:25:35 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:25:35 --> Helper loaded: form_helper
INFO - 2016-05-08 12:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:25:35 --> Form Validation Class Initialized
INFO - 2016-05-08 12:25:35 --> Controller Class Initialized
INFO - 2016-05-08 12:25:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-08 12:25:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 12:25:35 --> Final output sent to browser
DEBUG - 2016-05-08 12:25:35 --> Total execution time: 0.1745
INFO - 2016-05-08 12:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:25:35 --> Form Validation Class Initialized
INFO - 2016-05-08 12:25:35 --> Controller Class Initialized
INFO - 2016-05-08 12:25:35 --> Config Class Initialized
INFO - 2016-05-08 12:25:35 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:25:35 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:25:35 --> Utf8 Class Initialized
INFO - 2016-05-08 12:25:35 --> URI Class Initialized
INFO - 2016-05-08 12:25:35 --> Router Class Initialized
INFO - 2016-05-08 12:25:35 --> Output Class Initialized
INFO - 2016-05-08 12:25:35 --> Security Class Initialized
DEBUG - 2016-05-08 12:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:25:35 --> Input Class Initialized
INFO - 2016-05-08 12:25:35 --> Language Class Initialized
INFO - 2016-05-08 12:25:35 --> Loader Class Initialized
INFO - 2016-05-08 12:25:35 --> Helper loaded: url_helper
INFO - 2016-05-08 12:25:35 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:25:35 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:25:35 --> Helper loaded: form_helper
INFO - 2016-05-08 12:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:25:35 --> Form Validation Class Initialized
INFO - 2016-05-08 12:25:35 --> Controller Class Initialized
INFO - 2016-05-08 12:25:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-08 12:25:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-08 12:25:35 --> Final output sent to browser
DEBUG - 2016-05-08 12:25:35 --> Total execution time: 0.0672
INFO - 2016-05-08 12:26:19 --> Config Class Initialized
INFO - 2016-05-08 12:26:19 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:26:19 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:26:19 --> Utf8 Class Initialized
INFO - 2016-05-08 12:26:19 --> URI Class Initialized
INFO - 2016-05-08 12:26:19 --> Router Class Initialized
INFO - 2016-05-08 12:26:19 --> Output Class Initialized
INFO - 2016-05-08 12:26:19 --> Security Class Initialized
DEBUG - 2016-05-08 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:26:19 --> Input Class Initialized
INFO - 2016-05-08 12:26:19 --> Language Class Initialized
INFO - 2016-05-08 12:26:19 --> Loader Class Initialized
INFO - 2016-05-08 12:26:19 --> Helper loaded: url_helper
INFO - 2016-05-08 12:26:19 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:26:19 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:26:19 --> Helper loaded: form_helper
INFO - 2016-05-08 12:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:26:19 --> Form Validation Class Initialized
INFO - 2016-05-08 12:26:19 --> Controller Class Initialized
INFO - 2016-05-08 12:26:22 --> Config Class Initialized
INFO - 2016-05-08 12:26:22 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:26:22 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:26:22 --> Utf8 Class Initialized
INFO - 2016-05-08 12:26:22 --> URI Class Initialized
INFO - 2016-05-08 12:26:22 --> Router Class Initialized
INFO - 2016-05-08 12:26:22 --> Output Class Initialized
INFO - 2016-05-08 12:26:22 --> Security Class Initialized
DEBUG - 2016-05-08 12:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:26:22 --> Input Class Initialized
INFO - 2016-05-08 12:26:22 --> Language Class Initialized
INFO - 2016-05-08 12:26:22 --> Loader Class Initialized
INFO - 2016-05-08 12:26:22 --> Helper loaded: url_helper
INFO - 2016-05-08 12:26:22 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:26:22 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:26:22 --> Helper loaded: form_helper
INFO - 2016-05-08 12:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:26:23 --> Form Validation Class Initialized
INFO - 2016-05-08 12:26:23 --> Controller Class Initialized
INFO - 2016-05-08 12:26:23 --> Config Class Initialized
INFO - 2016-05-08 12:26:23 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:26:23 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:26:23 --> Utf8 Class Initialized
INFO - 2016-05-08 12:26:23 --> URI Class Initialized
INFO - 2016-05-08 12:26:23 --> Router Class Initialized
INFO - 2016-05-08 12:26:23 --> Output Class Initialized
INFO - 2016-05-08 12:26:23 --> Security Class Initialized
DEBUG - 2016-05-08 12:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:26:23 --> Input Class Initialized
INFO - 2016-05-08 12:26:23 --> Language Class Initialized
INFO - 2016-05-08 12:26:23 --> Loader Class Initialized
INFO - 2016-05-08 12:26:23 --> Helper loaded: url_helper
INFO - 2016-05-08 12:26:23 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:26:23 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:26:23 --> Helper loaded: form_helper
INFO - 2016-05-08 12:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:26:23 --> Form Validation Class Initialized
INFO - 2016-05-08 12:26:23 --> Controller Class Initialized
INFO - 2016-05-08 12:26:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-08 12:26:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:26:23 --> Final output sent to browser
DEBUG - 2016-05-08 12:26:23 --> Total execution time: 0.0711
INFO - 2016-05-08 12:30:42 --> Config Class Initialized
INFO - 2016-05-08 12:30:42 --> Hooks Class Initialized
DEBUG - 2016-05-08 12:30:42 --> UTF-8 Support Enabled
INFO - 2016-05-08 12:30:42 --> Utf8 Class Initialized
INFO - 2016-05-08 12:30:42 --> URI Class Initialized
INFO - 2016-05-08 12:30:42 --> Router Class Initialized
INFO - 2016-05-08 12:30:42 --> Output Class Initialized
INFO - 2016-05-08 12:30:42 --> Security Class Initialized
DEBUG - 2016-05-08 12:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-08 12:30:42 --> Input Class Initialized
INFO - 2016-05-08 12:30:42 --> Language Class Initialized
INFO - 2016-05-08 12:30:42 --> Loader Class Initialized
INFO - 2016-05-08 12:30:42 --> Helper loaded: url_helper
INFO - 2016-05-08 12:30:42 --> Helper loaded: sesion_helper
INFO - 2016-05-08 12:30:42 --> Helper loaded: templates_helper
INFO - 2016-05-08 12:30:42 --> Helper loaded: form_helper
INFO - 2016-05-08 12:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-08 12:30:42 --> Form Validation Class Initialized
INFO - 2016-05-08 12:30:42 --> Controller Class Initialized
INFO - 2016-05-08 12:30:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-08 12:30:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-08 12:30:42 --> Final output sent to browser
DEBUG - 2016-05-08 12:30:42 --> Total execution time: 0.0667
