<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-07 09:01:23 --> Config Class Initialized
INFO - 2016-05-07 09:01:23 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:01:23 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:01:23 --> Utf8 Class Initialized
INFO - 2016-05-07 09:01:23 --> URI Class Initialized
INFO - 2016-05-07 09:01:23 --> Router Class Initialized
INFO - 2016-05-07 09:01:23 --> Output Class Initialized
INFO - 2016-05-07 09:01:23 --> Security Class Initialized
DEBUG - 2016-05-07 09:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:01:23 --> Input Class Initialized
INFO - 2016-05-07 09:01:23 --> Language Class Initialized
INFO - 2016-05-07 09:01:23 --> Loader Class Initialized
INFO - 2016-05-07 09:01:23 --> Helper loaded: url_helper
INFO - 2016-05-07 09:01:23 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:01:23 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:01:23 --> Helper loaded: form_helper
INFO - 2016-05-07 09:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:01:23 --> Form Validation Class Initialized
INFO - 2016-05-07 09:01:23 --> Controller Class Initialized
INFO - 2016-05-07 09:01:23 --> Config Class Initialized
INFO - 2016-05-07 09:01:23 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:01:23 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:01:23 --> Utf8 Class Initialized
INFO - 2016-05-07 09:01:23 --> URI Class Initialized
INFO - 2016-05-07 09:01:23 --> Router Class Initialized
INFO - 2016-05-07 09:01:23 --> Output Class Initialized
INFO - 2016-05-07 09:01:23 --> Security Class Initialized
DEBUG - 2016-05-07 09:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:01:23 --> Input Class Initialized
INFO - 2016-05-07 09:01:23 --> Language Class Initialized
INFO - 2016-05-07 09:01:23 --> Loader Class Initialized
INFO - 2016-05-07 09:01:23 --> Helper loaded: url_helper
INFO - 2016-05-07 09:01:23 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:01:23 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:01:23 --> Helper loaded: form_helper
INFO - 2016-05-07 09:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:01:23 --> Form Validation Class Initialized
INFO - 2016-05-07 09:01:23 --> Controller Class Initialized
INFO - 2016-05-07 09:01:23 --> Model Class Initialized
INFO - 2016-05-07 09:01:23 --> Database Driver Class Initialized
INFO - 2016-05-07 09:01:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-07 09:01:23 --> Final output sent to browser
DEBUG - 2016-05-07 09:01:23 --> Total execution time: 0.0803
INFO - 2016-05-07 09:01:32 --> Config Class Initialized
INFO - 2016-05-07 09:01:32 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:01:32 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:01:32 --> Utf8 Class Initialized
INFO - 2016-05-07 09:01:32 --> URI Class Initialized
INFO - 2016-05-07 09:01:32 --> Router Class Initialized
INFO - 2016-05-07 09:01:32 --> Output Class Initialized
INFO - 2016-05-07 09:01:32 --> Security Class Initialized
DEBUG - 2016-05-07 09:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:01:32 --> Input Class Initialized
INFO - 2016-05-07 09:01:32 --> Language Class Initialized
INFO - 2016-05-07 09:01:32 --> Loader Class Initialized
INFO - 2016-05-07 09:01:32 --> Helper loaded: url_helper
INFO - 2016-05-07 09:01:32 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:01:32 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:01:32 --> Helper loaded: form_helper
INFO - 2016-05-07 09:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:01:32 --> Form Validation Class Initialized
INFO - 2016-05-07 09:01:32 --> Controller Class Initialized
INFO - 2016-05-07 09:01:32 --> Model Class Initialized
INFO - 2016-05-07 09:01:32 --> Database Driver Class Initialized
INFO - 2016-05-07 09:01:32 --> Config Class Initialized
INFO - 2016-05-07 09:01:32 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:01:32 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:01:32 --> Utf8 Class Initialized
INFO - 2016-05-07 09:01:32 --> URI Class Initialized
INFO - 2016-05-07 09:01:32 --> Router Class Initialized
INFO - 2016-05-07 09:01:32 --> Output Class Initialized
INFO - 2016-05-07 09:01:32 --> Security Class Initialized
DEBUG - 2016-05-07 09:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:01:32 --> Input Class Initialized
INFO - 2016-05-07 09:01:32 --> Language Class Initialized
INFO - 2016-05-07 09:01:32 --> Loader Class Initialized
INFO - 2016-05-07 09:01:32 --> Helper loaded: url_helper
INFO - 2016-05-07 09:01:32 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:01:32 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:01:32 --> Helper loaded: form_helper
INFO - 2016-05-07 09:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:01:32 --> Form Validation Class Initialized
INFO - 2016-05-07 09:01:32 --> Controller Class Initialized
INFO - 2016-05-07 09:01:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-07 09:01:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:01:32 --> Final output sent to browser
DEBUG - 2016-05-07 09:01:32 --> Total execution time: 0.1516
INFO - 2016-05-07 09:01:43 --> Config Class Initialized
INFO - 2016-05-07 09:01:43 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:01:43 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:01:43 --> Utf8 Class Initialized
INFO - 2016-05-07 09:01:43 --> URI Class Initialized
INFO - 2016-05-07 09:01:43 --> Router Class Initialized
INFO - 2016-05-07 09:01:43 --> Output Class Initialized
INFO - 2016-05-07 09:01:43 --> Security Class Initialized
DEBUG - 2016-05-07 09:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:01:43 --> Input Class Initialized
INFO - 2016-05-07 09:01:43 --> Language Class Initialized
INFO - 2016-05-07 09:01:43 --> Loader Class Initialized
INFO - 2016-05-07 09:01:43 --> Helper loaded: url_helper
INFO - 2016-05-07 09:01:43 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:01:43 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:01:43 --> Helper loaded: form_helper
INFO - 2016-05-07 09:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:01:43 --> Form Validation Class Initialized
INFO - 2016-05-07 09:01:43 --> Controller Class Initialized
INFO - 2016-05-07 09:01:43 --> Model Class Initialized
INFO - 2016-05-07 09:01:43 --> Database Driver Class Initialized
INFO - 2016-05-07 09:01:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:01:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:01:43 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:01:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:01:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 09:01:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:01:43 --> Final output sent to browser
DEBUG - 2016-05-07 09:01:43 --> Total execution time: 0.1706
INFO - 2016-05-07 09:01:47 --> Config Class Initialized
INFO - 2016-05-07 09:01:47 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:01:47 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:01:47 --> Utf8 Class Initialized
INFO - 2016-05-07 09:01:47 --> URI Class Initialized
INFO - 2016-05-07 09:01:47 --> Router Class Initialized
INFO - 2016-05-07 09:01:47 --> Output Class Initialized
INFO - 2016-05-07 09:01:47 --> Security Class Initialized
DEBUG - 2016-05-07 09:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:01:47 --> Input Class Initialized
INFO - 2016-05-07 09:01:47 --> Language Class Initialized
INFO - 2016-05-07 09:01:47 --> Loader Class Initialized
INFO - 2016-05-07 09:01:47 --> Helper loaded: url_helper
INFO - 2016-05-07 09:01:47 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:01:47 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:01:47 --> Helper loaded: form_helper
INFO - 2016-05-07 09:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:01:47 --> Form Validation Class Initialized
INFO - 2016-05-07 09:01:47 --> Controller Class Initialized
INFO - 2016-05-07 09:01:47 --> Model Class Initialized
INFO - 2016-05-07 09:01:47 --> Database Driver Class Initialized
INFO - 2016-05-07 09:01:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:01:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:01:47 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:01:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:01:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 09:01:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:01:47 --> Final output sent to browser
DEBUG - 2016-05-07 09:01:47 --> Total execution time: 0.1084
INFO - 2016-05-07 09:01:49 --> Config Class Initialized
INFO - 2016-05-07 09:01:49 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:01:49 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:01:49 --> Utf8 Class Initialized
INFO - 2016-05-07 09:01:49 --> URI Class Initialized
INFO - 2016-05-07 09:01:49 --> Router Class Initialized
INFO - 2016-05-07 09:01:49 --> Output Class Initialized
INFO - 2016-05-07 09:01:49 --> Security Class Initialized
DEBUG - 2016-05-07 09:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:01:49 --> Input Class Initialized
INFO - 2016-05-07 09:01:49 --> Language Class Initialized
INFO - 2016-05-07 09:01:49 --> Loader Class Initialized
INFO - 2016-05-07 09:01:49 --> Helper loaded: url_helper
INFO - 2016-05-07 09:01:49 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:01:49 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:01:49 --> Helper loaded: form_helper
INFO - 2016-05-07 09:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:01:49 --> Form Validation Class Initialized
INFO - 2016-05-07 09:01:49 --> Controller Class Initialized
INFO - 2016-05-07 09:01:49 --> Model Class Initialized
INFO - 2016-05-07 09:01:49 --> Database Driver Class Initialized
INFO - 2016-05-07 09:01:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:01:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:01:49 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:01:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:01:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 09:01:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:01:49 --> Final output sent to browser
DEBUG - 2016-05-07 09:01:49 --> Total execution time: 0.1251
INFO - 2016-05-07 09:01:51 --> Config Class Initialized
INFO - 2016-05-07 09:01:51 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:01:51 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:01:51 --> Utf8 Class Initialized
INFO - 2016-05-07 09:01:51 --> URI Class Initialized
INFO - 2016-05-07 09:01:51 --> Router Class Initialized
INFO - 2016-05-07 09:01:51 --> Output Class Initialized
INFO - 2016-05-07 09:01:51 --> Security Class Initialized
DEBUG - 2016-05-07 09:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:01:51 --> Input Class Initialized
INFO - 2016-05-07 09:01:51 --> Language Class Initialized
INFO - 2016-05-07 09:01:51 --> Loader Class Initialized
INFO - 2016-05-07 09:01:51 --> Helper loaded: url_helper
INFO - 2016-05-07 09:01:51 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:01:51 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:01:51 --> Helper loaded: form_helper
INFO - 2016-05-07 09:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:01:51 --> Form Validation Class Initialized
INFO - 2016-05-07 09:01:51 --> Controller Class Initialized
INFO - 2016-05-07 09:01:51 --> Model Class Initialized
INFO - 2016-05-07 09:01:51 --> Database Driver Class Initialized
INFO - 2016-05-07 09:01:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:01:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:01:51 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:01:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:01:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 09:01:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:01:51 --> Final output sent to browser
DEBUG - 2016-05-07 09:01:51 --> Total execution time: 0.0857
INFO - 2016-05-07 09:02:39 --> Config Class Initialized
INFO - 2016-05-07 09:02:39 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:02:39 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:02:39 --> Utf8 Class Initialized
INFO - 2016-05-07 09:02:39 --> URI Class Initialized
INFO - 2016-05-07 09:02:39 --> Router Class Initialized
INFO - 2016-05-07 09:02:39 --> Output Class Initialized
INFO - 2016-05-07 09:02:39 --> Security Class Initialized
DEBUG - 2016-05-07 09:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:02:39 --> Input Class Initialized
INFO - 2016-05-07 09:02:39 --> Language Class Initialized
INFO - 2016-05-07 09:02:39 --> Loader Class Initialized
INFO - 2016-05-07 09:02:39 --> Helper loaded: url_helper
INFO - 2016-05-07 09:02:39 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:02:39 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:02:39 --> Helper loaded: form_helper
INFO - 2016-05-07 09:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:02:39 --> Form Validation Class Initialized
INFO - 2016-05-07 09:02:39 --> Controller Class Initialized
INFO - 2016-05-07 09:02:39 --> Model Class Initialized
INFO - 2016-05-07 09:02:39 --> Database Driver Class Initialized
INFO - 2016-05-07 09:02:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:02:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:02:39 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:02:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:02:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 09:02:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:02:39 --> Final output sent to browser
DEBUG - 2016-05-07 09:02:39 --> Total execution time: 0.0952
INFO - 2016-05-07 09:02:49 --> Config Class Initialized
INFO - 2016-05-07 09:02:49 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:02:49 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:02:49 --> Utf8 Class Initialized
INFO - 2016-05-07 09:02:49 --> URI Class Initialized
INFO - 2016-05-07 09:02:49 --> Router Class Initialized
INFO - 2016-05-07 09:02:49 --> Output Class Initialized
INFO - 2016-05-07 09:02:49 --> Security Class Initialized
DEBUG - 2016-05-07 09:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:02:49 --> Input Class Initialized
INFO - 2016-05-07 09:02:49 --> Language Class Initialized
INFO - 2016-05-07 09:02:49 --> Loader Class Initialized
INFO - 2016-05-07 09:02:49 --> Helper loaded: url_helper
INFO - 2016-05-07 09:02:49 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:02:49 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:02:49 --> Helper loaded: form_helper
INFO - 2016-05-07 09:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:02:49 --> Form Validation Class Initialized
INFO - 2016-05-07 09:02:49 --> Controller Class Initialized
INFO - 2016-05-07 09:02:49 --> Model Class Initialized
INFO - 2016-05-07 09:02:50 --> Database Driver Class Initialized
INFO - 2016-05-07 09:02:50 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:02:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:02:50 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:02:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:02:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 09:02:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:02:50 --> Final output sent to browser
DEBUG - 2016-05-07 09:02:50 --> Total execution time: 0.1436
INFO - 2016-05-07 09:03:01 --> Config Class Initialized
INFO - 2016-05-07 09:03:01 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:03:01 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:03:01 --> Utf8 Class Initialized
INFO - 2016-05-07 09:03:01 --> URI Class Initialized
INFO - 2016-05-07 09:03:01 --> Router Class Initialized
INFO - 2016-05-07 09:03:01 --> Output Class Initialized
INFO - 2016-05-07 09:03:01 --> Security Class Initialized
DEBUG - 2016-05-07 09:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:03:01 --> Input Class Initialized
INFO - 2016-05-07 09:03:01 --> Language Class Initialized
INFO - 2016-05-07 09:03:01 --> Loader Class Initialized
INFO - 2016-05-07 09:03:01 --> Helper loaded: url_helper
INFO - 2016-05-07 09:03:01 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:03:01 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:03:01 --> Helper loaded: form_helper
INFO - 2016-05-07 09:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:03:01 --> Form Validation Class Initialized
INFO - 2016-05-07 09:03:01 --> Controller Class Initialized
INFO - 2016-05-07 09:03:01 --> Model Class Initialized
INFO - 2016-05-07 09:03:01 --> Database Driver Class Initialized
INFO - 2016-05-07 09:03:01 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:03:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:03:01 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:03:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:03:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 09:03:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:03:01 --> Final output sent to browser
DEBUG - 2016-05-07 09:03:01 --> Total execution time: 0.0880
INFO - 2016-05-07 09:03:16 --> Config Class Initialized
INFO - 2016-05-07 09:03:16 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:03:16 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:03:16 --> Utf8 Class Initialized
INFO - 2016-05-07 09:03:16 --> URI Class Initialized
INFO - 2016-05-07 09:03:16 --> Router Class Initialized
INFO - 2016-05-07 09:03:16 --> Output Class Initialized
INFO - 2016-05-07 09:03:16 --> Security Class Initialized
DEBUG - 2016-05-07 09:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:03:16 --> Input Class Initialized
INFO - 2016-05-07 09:03:16 --> Language Class Initialized
INFO - 2016-05-07 09:03:16 --> Loader Class Initialized
INFO - 2016-05-07 09:03:16 --> Helper loaded: url_helper
INFO - 2016-05-07 09:03:16 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:03:16 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:03:16 --> Helper loaded: form_helper
INFO - 2016-05-07 09:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:03:16 --> Form Validation Class Initialized
INFO - 2016-05-07 09:03:16 --> Controller Class Initialized
INFO - 2016-05-07 09:03:16 --> Model Class Initialized
INFO - 2016-05-07 09:03:16 --> Database Driver Class Initialized
INFO - 2016-05-07 09:03:16 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:03:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:03:16 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:03:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:03:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 09:03:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:03:16 --> Final output sent to browser
DEBUG - 2016-05-07 09:03:16 --> Total execution time: 0.1024
INFO - 2016-05-07 09:03:25 --> Config Class Initialized
INFO - 2016-05-07 09:03:25 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:03:25 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:03:25 --> Utf8 Class Initialized
INFO - 2016-05-07 09:03:25 --> URI Class Initialized
INFO - 2016-05-07 09:03:25 --> Router Class Initialized
INFO - 2016-05-07 09:03:25 --> Output Class Initialized
INFO - 2016-05-07 09:03:25 --> Security Class Initialized
DEBUG - 2016-05-07 09:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:03:25 --> Input Class Initialized
INFO - 2016-05-07 09:03:25 --> Language Class Initialized
INFO - 2016-05-07 09:03:25 --> Loader Class Initialized
INFO - 2016-05-07 09:03:25 --> Helper loaded: url_helper
INFO - 2016-05-07 09:03:25 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:03:25 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:03:25 --> Helper loaded: form_helper
INFO - 2016-05-07 09:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:03:25 --> Form Validation Class Initialized
INFO - 2016-05-07 09:03:25 --> Controller Class Initialized
INFO - 2016-05-07 09:03:25 --> Model Class Initialized
INFO - 2016-05-07 09:03:25 --> Database Driver Class Initialized
INFO - 2016-05-07 09:03:25 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:03:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:03:25 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:03:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:03:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 09:03:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:03:25 --> Final output sent to browser
DEBUG - 2016-05-07 09:03:25 --> Total execution time: 0.1314
INFO - 2016-05-07 09:03:34 --> Config Class Initialized
INFO - 2016-05-07 09:03:34 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:03:34 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:03:34 --> Utf8 Class Initialized
INFO - 2016-05-07 09:03:34 --> URI Class Initialized
INFO - 2016-05-07 09:03:34 --> Router Class Initialized
INFO - 2016-05-07 09:03:34 --> Output Class Initialized
INFO - 2016-05-07 09:03:34 --> Security Class Initialized
DEBUG - 2016-05-07 09:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:03:34 --> Input Class Initialized
INFO - 2016-05-07 09:03:34 --> Language Class Initialized
INFO - 2016-05-07 09:03:34 --> Loader Class Initialized
INFO - 2016-05-07 09:03:34 --> Helper loaded: url_helper
INFO - 2016-05-07 09:03:34 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:03:34 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:03:34 --> Helper loaded: form_helper
INFO - 2016-05-07 09:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:03:34 --> Form Validation Class Initialized
INFO - 2016-05-07 09:03:34 --> Controller Class Initialized
INFO - 2016-05-07 09:03:34 --> Model Class Initialized
INFO - 2016-05-07 09:03:34 --> Database Driver Class Initialized
INFO - 2016-05-07 09:03:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:03:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:03:34 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:03:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:03:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 09:03:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:03:34 --> Final output sent to browser
DEBUG - 2016-05-07 09:03:34 --> Total execution time: 0.1331
INFO - 2016-05-07 09:03:38 --> Config Class Initialized
INFO - 2016-05-07 09:03:38 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:03:38 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:03:38 --> Utf8 Class Initialized
INFO - 2016-05-07 09:03:38 --> URI Class Initialized
INFO - 2016-05-07 09:03:38 --> Router Class Initialized
INFO - 2016-05-07 09:03:38 --> Output Class Initialized
INFO - 2016-05-07 09:03:38 --> Security Class Initialized
DEBUG - 2016-05-07 09:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:03:38 --> Input Class Initialized
INFO - 2016-05-07 09:03:38 --> Language Class Initialized
INFO - 2016-05-07 09:03:38 --> Loader Class Initialized
INFO - 2016-05-07 09:03:38 --> Helper loaded: url_helper
INFO - 2016-05-07 09:03:38 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:03:38 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:03:38 --> Helper loaded: form_helper
INFO - 2016-05-07 09:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:03:38 --> Form Validation Class Initialized
INFO - 2016-05-07 09:03:38 --> Controller Class Initialized
INFO - 2016-05-07 09:03:38 --> Model Class Initialized
INFO - 2016-05-07 09:03:38 --> Database Driver Class Initialized
INFO - 2016-05-07 09:03:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:03:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:03:38 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:03:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:03:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 09:03:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:03:38 --> Final output sent to browser
DEBUG - 2016-05-07 09:03:38 --> Total execution time: 0.1027
INFO - 2016-05-07 09:03:41 --> Config Class Initialized
INFO - 2016-05-07 09:03:41 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:03:41 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:03:41 --> Utf8 Class Initialized
INFO - 2016-05-07 09:03:41 --> URI Class Initialized
INFO - 2016-05-07 09:03:41 --> Router Class Initialized
INFO - 2016-05-07 09:03:41 --> Output Class Initialized
INFO - 2016-05-07 09:03:41 --> Security Class Initialized
DEBUG - 2016-05-07 09:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:03:41 --> Input Class Initialized
INFO - 2016-05-07 09:03:41 --> Language Class Initialized
INFO - 2016-05-07 09:03:41 --> Loader Class Initialized
INFO - 2016-05-07 09:03:41 --> Helper loaded: url_helper
INFO - 2016-05-07 09:03:41 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:03:41 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:03:41 --> Helper loaded: form_helper
INFO - 2016-05-07 09:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:03:41 --> Form Validation Class Initialized
INFO - 2016-05-07 09:03:41 --> Controller Class Initialized
INFO - 2016-05-07 09:03:41 --> Model Class Initialized
INFO - 2016-05-07 09:03:41 --> Database Driver Class Initialized
INFO - 2016-05-07 09:03:41 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:03:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:03:41 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:03:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:03:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:03:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:03:41 --> Final output sent to browser
DEBUG - 2016-05-07 09:03:41 --> Total execution time: 0.1115
INFO - 2016-05-07 09:13:09 --> Config Class Initialized
INFO - 2016-05-07 09:13:09 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:13:09 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:13:09 --> Utf8 Class Initialized
INFO - 2016-05-07 09:13:09 --> URI Class Initialized
INFO - 2016-05-07 09:13:09 --> Router Class Initialized
INFO - 2016-05-07 09:13:09 --> Output Class Initialized
INFO - 2016-05-07 09:13:09 --> Security Class Initialized
DEBUG - 2016-05-07 09:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:13:09 --> Input Class Initialized
INFO - 2016-05-07 09:13:09 --> Language Class Initialized
INFO - 2016-05-07 09:13:09 --> Loader Class Initialized
INFO - 2016-05-07 09:13:09 --> Helper loaded: url_helper
INFO - 2016-05-07 09:13:09 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:13:09 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:13:09 --> Helper loaded: form_helper
INFO - 2016-05-07 09:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:13:09 --> Form Validation Class Initialized
INFO - 2016-05-07 09:13:09 --> Controller Class Initialized
INFO - 2016-05-07 09:13:09 --> Model Class Initialized
INFO - 2016-05-07 09:13:09 --> Database Driver Class Initialized
INFO - 2016-05-07 09:13:09 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:13:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:13:09 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:13:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 09:13:09 --> Severity: Error --> Call to undefined method Productos::NombreCategoria_unico_check() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 224
INFO - 2016-05-07 09:13:54 --> Config Class Initialized
INFO - 2016-05-07 09:13:54 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:13:54 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:13:54 --> Utf8 Class Initialized
INFO - 2016-05-07 09:13:54 --> URI Class Initialized
INFO - 2016-05-07 09:13:54 --> Router Class Initialized
INFO - 2016-05-07 09:13:54 --> Output Class Initialized
INFO - 2016-05-07 09:13:54 --> Security Class Initialized
DEBUG - 2016-05-07 09:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:13:54 --> Input Class Initialized
INFO - 2016-05-07 09:13:54 --> Language Class Initialized
INFO - 2016-05-07 09:13:54 --> Loader Class Initialized
INFO - 2016-05-07 09:13:54 --> Helper loaded: url_helper
INFO - 2016-05-07 09:13:54 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:13:54 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:13:54 --> Helper loaded: form_helper
INFO - 2016-05-07 09:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:13:54 --> Form Validation Class Initialized
INFO - 2016-05-07 09:13:54 --> Controller Class Initialized
INFO - 2016-05-07 09:13:54 --> Model Class Initialized
INFO - 2016-05-07 09:13:54 --> Database Driver Class Initialized
INFO - 2016-05-07 09:13:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:13:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:13:54 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:13:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:13:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:13:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:13:54 --> Final output sent to browser
DEBUG - 2016-05-07 09:13:54 --> Total execution time: 0.1072
INFO - 2016-05-07 09:14:02 --> Config Class Initialized
INFO - 2016-05-07 09:14:02 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:14:02 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:14:02 --> Utf8 Class Initialized
INFO - 2016-05-07 09:14:02 --> URI Class Initialized
INFO - 2016-05-07 09:14:02 --> Router Class Initialized
INFO - 2016-05-07 09:14:02 --> Output Class Initialized
INFO - 2016-05-07 09:14:02 --> Security Class Initialized
DEBUG - 2016-05-07 09:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:14:02 --> Input Class Initialized
INFO - 2016-05-07 09:14:02 --> Language Class Initialized
INFO - 2016-05-07 09:14:02 --> Loader Class Initialized
INFO - 2016-05-07 09:14:02 --> Helper loaded: url_helper
INFO - 2016-05-07 09:14:02 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:14:02 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:14:02 --> Helper loaded: form_helper
INFO - 2016-05-07 09:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:14:02 --> Form Validation Class Initialized
INFO - 2016-05-07 09:14:02 --> Controller Class Initialized
INFO - 2016-05-07 09:14:02 --> Model Class Initialized
INFO - 2016-05-07 09:14:02 --> Database Driver Class Initialized
INFO - 2016-05-07 09:14:02 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:14:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:14:02 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:14:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:14:02 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-05-07 09:14:02 --> Severity: Notice --> Undefined index: idProducto C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php 17
INFO - 2016-05-07 09:14:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:14:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:14:02 --> Final output sent to browser
DEBUG - 2016-05-07 09:14:02 --> Total execution time: 0.0878
INFO - 2016-05-07 09:14:40 --> Config Class Initialized
INFO - 2016-05-07 09:14:40 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:14:40 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:14:40 --> Utf8 Class Initialized
INFO - 2016-05-07 09:14:40 --> URI Class Initialized
INFO - 2016-05-07 09:14:40 --> Router Class Initialized
INFO - 2016-05-07 09:14:40 --> Output Class Initialized
INFO - 2016-05-07 09:14:40 --> Security Class Initialized
DEBUG - 2016-05-07 09:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:14:40 --> Input Class Initialized
INFO - 2016-05-07 09:14:40 --> Language Class Initialized
INFO - 2016-05-07 09:14:40 --> Loader Class Initialized
INFO - 2016-05-07 09:14:40 --> Helper loaded: url_helper
INFO - 2016-05-07 09:14:40 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:14:40 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:14:40 --> Helper loaded: form_helper
INFO - 2016-05-07 09:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:14:40 --> Form Validation Class Initialized
INFO - 2016-05-07 09:14:40 --> Controller Class Initialized
INFO - 2016-05-07 09:14:40 --> Model Class Initialized
INFO - 2016-05-07 09:14:40 --> Database Driver Class Initialized
INFO - 2016-05-07 09:14:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:14:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:14:40 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:14:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:14:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:14:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:14:40 --> Final output sent to browser
DEBUG - 2016-05-07 09:14:40 --> Total execution time: 0.1446
INFO - 2016-05-07 09:15:09 --> Config Class Initialized
INFO - 2016-05-07 09:15:09 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:15:09 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:15:09 --> Utf8 Class Initialized
INFO - 2016-05-07 09:15:09 --> URI Class Initialized
INFO - 2016-05-07 09:15:09 --> Router Class Initialized
INFO - 2016-05-07 09:15:09 --> Output Class Initialized
INFO - 2016-05-07 09:15:09 --> Security Class Initialized
DEBUG - 2016-05-07 09:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:15:09 --> Input Class Initialized
INFO - 2016-05-07 09:15:09 --> Language Class Initialized
INFO - 2016-05-07 09:15:09 --> Loader Class Initialized
INFO - 2016-05-07 09:15:09 --> Helper loaded: url_helper
INFO - 2016-05-07 09:15:09 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:15:09 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:15:09 --> Helper loaded: form_helper
INFO - 2016-05-07 09:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:15:09 --> Form Validation Class Initialized
INFO - 2016-05-07 09:15:09 --> Controller Class Initialized
INFO - 2016-05-07 09:15:09 --> Model Class Initialized
INFO - 2016-05-07 09:15:09 --> Database Driver Class Initialized
INFO - 2016-05-07 09:15:09 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:15:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:15:09 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:15:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:15:09 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-05-07 09:15:09 --> Severity: Notice --> Undefined index: idProducto C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php 17
INFO - 2016-05-07 09:15:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:15:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:15:09 --> Final output sent to browser
DEBUG - 2016-05-07 09:15:09 --> Total execution time: 0.1118
INFO - 2016-05-07 09:15:27 --> Config Class Initialized
INFO - 2016-05-07 09:15:27 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:15:27 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:15:27 --> Utf8 Class Initialized
INFO - 2016-05-07 09:15:27 --> URI Class Initialized
INFO - 2016-05-07 09:15:27 --> Router Class Initialized
INFO - 2016-05-07 09:15:27 --> Output Class Initialized
INFO - 2016-05-07 09:15:27 --> Security Class Initialized
DEBUG - 2016-05-07 09:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:15:27 --> Input Class Initialized
INFO - 2016-05-07 09:15:27 --> Language Class Initialized
INFO - 2016-05-07 09:15:27 --> Loader Class Initialized
INFO - 2016-05-07 09:15:27 --> Helper loaded: url_helper
INFO - 2016-05-07 09:15:27 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:15:27 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:15:27 --> Helper loaded: form_helper
INFO - 2016-05-07 09:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:15:27 --> Form Validation Class Initialized
INFO - 2016-05-07 09:15:27 --> Controller Class Initialized
INFO - 2016-05-07 09:15:27 --> Model Class Initialized
INFO - 2016-05-07 09:15:27 --> Database Driver Class Initialized
INFO - 2016-05-07 09:15:27 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:15:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:15:27 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:15:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:15:27 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:15:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:15:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:15:27 --> Final output sent to browser
DEBUG - 2016-05-07 09:15:27 --> Total execution time: 0.0845
INFO - 2016-05-07 09:15:43 --> Config Class Initialized
INFO - 2016-05-07 09:15:43 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:15:43 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:15:43 --> Utf8 Class Initialized
INFO - 2016-05-07 09:15:43 --> URI Class Initialized
INFO - 2016-05-07 09:15:43 --> Router Class Initialized
INFO - 2016-05-07 09:15:43 --> Output Class Initialized
INFO - 2016-05-07 09:15:43 --> Security Class Initialized
DEBUG - 2016-05-07 09:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:15:43 --> Input Class Initialized
INFO - 2016-05-07 09:15:43 --> Language Class Initialized
INFO - 2016-05-07 09:15:43 --> Loader Class Initialized
INFO - 2016-05-07 09:15:43 --> Helper loaded: url_helper
INFO - 2016-05-07 09:15:43 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:15:43 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:15:43 --> Helper loaded: form_helper
INFO - 2016-05-07 09:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:15:43 --> Form Validation Class Initialized
INFO - 2016-05-07 09:15:43 --> Controller Class Initialized
INFO - 2016-05-07 09:15:43 --> Model Class Initialized
INFO - 2016-05-07 09:15:43 --> Database Driver Class Initialized
INFO - 2016-05-07 09:15:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:15:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:15:43 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:15:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:15:43 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:15:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:15:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:15:43 --> Final output sent to browser
DEBUG - 2016-05-07 09:15:43 --> Total execution time: 0.0786
INFO - 2016-05-07 09:23:15 --> Config Class Initialized
INFO - 2016-05-07 09:23:15 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:23:15 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:23:15 --> Utf8 Class Initialized
INFO - 2016-05-07 09:23:15 --> URI Class Initialized
INFO - 2016-05-07 09:23:15 --> Router Class Initialized
INFO - 2016-05-07 09:23:15 --> Output Class Initialized
INFO - 2016-05-07 09:23:15 --> Security Class Initialized
DEBUG - 2016-05-07 09:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:23:15 --> Input Class Initialized
INFO - 2016-05-07 09:23:15 --> Language Class Initialized
INFO - 2016-05-07 09:23:15 --> Loader Class Initialized
INFO - 2016-05-07 09:23:15 --> Helper loaded: url_helper
INFO - 2016-05-07 09:23:15 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:23:15 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:23:15 --> Helper loaded: form_helper
INFO - 2016-05-07 09:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:23:15 --> Form Validation Class Initialized
INFO - 2016-05-07 09:23:15 --> Controller Class Initialized
INFO - 2016-05-07 09:23:15 --> Model Class Initialized
INFO - 2016-05-07 09:23:15 --> Database Driver Class Initialized
INFO - 2016-05-07 09:23:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:23:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:23:15 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:23:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:23:15 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:23:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:23:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:23:15 --> Final output sent to browser
DEBUG - 2016-05-07 09:23:15 --> Total execution time: 0.0949
INFO - 2016-05-07 09:23:19 --> Config Class Initialized
INFO - 2016-05-07 09:23:19 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:23:19 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:23:19 --> Utf8 Class Initialized
INFO - 2016-05-07 09:23:19 --> URI Class Initialized
INFO - 2016-05-07 09:23:19 --> Router Class Initialized
INFO - 2016-05-07 09:23:19 --> Output Class Initialized
INFO - 2016-05-07 09:23:19 --> Security Class Initialized
DEBUG - 2016-05-07 09:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:23:19 --> Input Class Initialized
INFO - 2016-05-07 09:23:19 --> Language Class Initialized
INFO - 2016-05-07 09:23:19 --> Loader Class Initialized
INFO - 2016-05-07 09:23:19 --> Helper loaded: url_helper
INFO - 2016-05-07 09:23:19 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:23:19 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:23:19 --> Helper loaded: form_helper
INFO - 2016-05-07 09:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:23:19 --> Form Validation Class Initialized
INFO - 2016-05-07 09:23:19 --> Controller Class Initialized
INFO - 2016-05-07 09:23:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-07 09:23:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:23:19 --> Final output sent to browser
DEBUG - 2016-05-07 09:23:19 --> Total execution time: 0.0517
INFO - 2016-05-07 09:23:22 --> Config Class Initialized
INFO - 2016-05-07 09:23:22 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:23:22 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:23:22 --> Utf8 Class Initialized
INFO - 2016-05-07 09:23:22 --> URI Class Initialized
INFO - 2016-05-07 09:23:22 --> Router Class Initialized
INFO - 2016-05-07 09:23:22 --> Output Class Initialized
INFO - 2016-05-07 09:23:22 --> Security Class Initialized
DEBUG - 2016-05-07 09:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:23:22 --> Input Class Initialized
INFO - 2016-05-07 09:23:22 --> Language Class Initialized
INFO - 2016-05-07 09:23:22 --> Loader Class Initialized
INFO - 2016-05-07 09:23:22 --> Helper loaded: url_helper
INFO - 2016-05-07 09:23:22 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:23:22 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:23:22 --> Helper loaded: form_helper
INFO - 2016-05-07 09:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:23:22 --> Form Validation Class Initialized
INFO - 2016-05-07 09:23:22 --> Controller Class Initialized
INFO - 2016-05-07 09:23:22 --> Model Class Initialized
INFO - 2016-05-07 09:23:22 --> Database Driver Class Initialized
INFO - 2016-05-07 09:23:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:23:22 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:23:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:23:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-07 09:23:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:23:22 --> Final output sent to browser
DEBUG - 2016-05-07 09:23:22 --> Total execution time: 0.0735
INFO - 2016-05-07 09:23:24 --> Config Class Initialized
INFO - 2016-05-07 09:23:24 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:23:24 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:23:24 --> Utf8 Class Initialized
INFO - 2016-05-07 09:23:24 --> URI Class Initialized
INFO - 2016-05-07 09:23:24 --> Router Class Initialized
INFO - 2016-05-07 09:23:24 --> Output Class Initialized
INFO - 2016-05-07 09:23:24 --> Security Class Initialized
DEBUG - 2016-05-07 09:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:23:24 --> Input Class Initialized
INFO - 2016-05-07 09:23:24 --> Language Class Initialized
INFO - 2016-05-07 09:23:24 --> Loader Class Initialized
INFO - 2016-05-07 09:23:24 --> Helper loaded: url_helper
INFO - 2016-05-07 09:23:24 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:23:24 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:23:24 --> Helper loaded: form_helper
INFO - 2016-05-07 09:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:23:24 --> Form Validation Class Initialized
INFO - 2016-05-07 09:23:24 --> Controller Class Initialized
INFO - 2016-05-07 09:23:24 --> Model Class Initialized
INFO - 2016-05-07 09:23:24 --> Database Driver Class Initialized
INFO - 2016-05-07 09:23:24 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:23:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:23:24 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:23:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 09:23:24 --> Severity: Notice --> Undefined index: precio C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 48
ERROR - 2016-05-07 09:23:24 --> Severity: Notice --> Undefined index: precio_venta C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 49
ERROR - 2016-05-07 09:23:24 --> Severity: Notice --> Undefined index: precio C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 48
ERROR - 2016-05-07 09:23:24 --> Severity: Notice --> Undefined index: precio_venta C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 49
ERROR - 2016-05-07 09:23:24 --> Severity: Notice --> Undefined index: precio C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 48
ERROR - 2016-05-07 09:23:24 --> Severity: Notice --> Undefined index: precio_venta C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 49
ERROR - 2016-05-07 09:23:24 --> Severity: Notice --> Undefined index: precio C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 48
ERROR - 2016-05-07 09:23:24 --> Severity: Notice --> Undefined index: precio_venta C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 49
ERROR - 2016-05-07 09:23:24 --> Severity: Notice --> Undefined index: precio C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 48
ERROR - 2016-05-07 09:23:24 --> Severity: Notice --> Undefined index: precio_venta C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 49
INFO - 2016-05-07 09:23:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 09:23:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:23:24 --> Final output sent to browser
DEBUG - 2016-05-07 09:23:24 --> Total execution time: 0.0946
INFO - 2016-05-07 09:24:48 --> Config Class Initialized
INFO - 2016-05-07 09:24:48 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:24:48 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:24:48 --> Utf8 Class Initialized
INFO - 2016-05-07 09:24:48 --> URI Class Initialized
INFO - 2016-05-07 09:24:48 --> Router Class Initialized
INFO - 2016-05-07 09:24:48 --> Output Class Initialized
INFO - 2016-05-07 09:24:48 --> Security Class Initialized
DEBUG - 2016-05-07 09:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:24:48 --> Input Class Initialized
INFO - 2016-05-07 09:24:48 --> Language Class Initialized
INFO - 2016-05-07 09:24:48 --> Loader Class Initialized
INFO - 2016-05-07 09:24:48 --> Helper loaded: url_helper
INFO - 2016-05-07 09:24:48 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:24:48 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:24:48 --> Helper loaded: form_helper
INFO - 2016-05-07 09:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:24:48 --> Form Validation Class Initialized
INFO - 2016-05-07 09:24:48 --> Controller Class Initialized
INFO - 2016-05-07 09:24:48 --> Model Class Initialized
INFO - 2016-05-07 09:24:48 --> Database Driver Class Initialized
INFO - 2016-05-07 09:24:48 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:24:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:24:48 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:24:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:24:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 09:24:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:24:48 --> Final output sent to browser
DEBUG - 2016-05-07 09:24:48 --> Total execution time: 0.0842
INFO - 2016-05-07 09:25:11 --> Config Class Initialized
INFO - 2016-05-07 09:25:11 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:25:11 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:25:11 --> Utf8 Class Initialized
INFO - 2016-05-07 09:25:11 --> URI Class Initialized
INFO - 2016-05-07 09:25:11 --> Router Class Initialized
INFO - 2016-05-07 09:25:11 --> Output Class Initialized
INFO - 2016-05-07 09:25:11 --> Security Class Initialized
DEBUG - 2016-05-07 09:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:25:11 --> Input Class Initialized
INFO - 2016-05-07 09:25:11 --> Language Class Initialized
INFO - 2016-05-07 09:25:11 --> Loader Class Initialized
INFO - 2016-05-07 09:25:11 --> Helper loaded: url_helper
INFO - 2016-05-07 09:25:11 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:25:11 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:25:11 --> Helper loaded: form_helper
INFO - 2016-05-07 09:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:25:11 --> Form Validation Class Initialized
INFO - 2016-05-07 09:25:11 --> Controller Class Initialized
INFO - 2016-05-07 09:25:11 --> Model Class Initialized
INFO - 2016-05-07 09:25:11 --> Database Driver Class Initialized
INFO - 2016-05-07 09:25:11 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:25:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:25:11 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:25:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:25:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 09:25:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:25:11 --> Final output sent to browser
DEBUG - 2016-05-07 09:25:11 --> Total execution time: 0.1413
INFO - 2016-05-07 09:25:20 --> Config Class Initialized
INFO - 2016-05-07 09:25:20 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:25:20 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:25:20 --> Utf8 Class Initialized
INFO - 2016-05-07 09:25:20 --> URI Class Initialized
INFO - 2016-05-07 09:25:20 --> Router Class Initialized
INFO - 2016-05-07 09:25:20 --> Output Class Initialized
INFO - 2016-05-07 09:25:20 --> Security Class Initialized
DEBUG - 2016-05-07 09:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:25:20 --> Input Class Initialized
INFO - 2016-05-07 09:25:20 --> Language Class Initialized
INFO - 2016-05-07 09:25:20 --> Loader Class Initialized
INFO - 2016-05-07 09:25:20 --> Helper loaded: url_helper
INFO - 2016-05-07 09:25:20 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:25:20 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:25:20 --> Helper loaded: form_helper
INFO - 2016-05-07 09:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:25:20 --> Form Validation Class Initialized
INFO - 2016-05-07 09:25:20 --> Controller Class Initialized
INFO - 2016-05-07 09:25:20 --> Model Class Initialized
INFO - 2016-05-07 09:25:20 --> Database Driver Class Initialized
INFO - 2016-05-07 09:25:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:25:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:25:20 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:25:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:25:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 09:25:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:25:20 --> Final output sent to browser
DEBUG - 2016-05-07 09:25:20 --> Total execution time: 0.2046
INFO - 2016-05-07 09:33:02 --> Config Class Initialized
INFO - 2016-05-07 09:33:02 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:33:02 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:33:02 --> Utf8 Class Initialized
INFO - 2016-05-07 09:33:02 --> URI Class Initialized
INFO - 2016-05-07 09:33:02 --> Router Class Initialized
INFO - 2016-05-07 09:33:02 --> Output Class Initialized
INFO - 2016-05-07 09:33:02 --> Security Class Initialized
DEBUG - 2016-05-07 09:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:33:02 --> Input Class Initialized
INFO - 2016-05-07 09:33:02 --> Language Class Initialized
INFO - 2016-05-07 09:33:02 --> Loader Class Initialized
INFO - 2016-05-07 09:33:02 --> Helper loaded: url_helper
INFO - 2016-05-07 09:33:02 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:33:02 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:33:02 --> Helper loaded: form_helper
INFO - 2016-05-07 09:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:33:02 --> Form Validation Class Initialized
INFO - 2016-05-07 09:33:02 --> Controller Class Initialized
INFO - 2016-05-07 09:33:02 --> Model Class Initialized
INFO - 2016-05-07 09:33:02 --> Database Driver Class Initialized
INFO - 2016-05-07 09:33:02 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:33:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:33:02 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:33:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 09:33:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'INNER JOIN categoria cat on prod.idCategoria = cat.idCategoria LIMIT 0, 5' at line 1 - Invalid query: SELECT prod.*, cat.nombre 'categoria' FROM producto prod ORDER BY prod.referencia INNER JOIN categoria cat on prod.idCategoria = cat.idCategoria LIMIT 0, 5; 
INFO - 2016-05-07 09:33:02 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 09:34:23 --> Config Class Initialized
INFO - 2016-05-07 09:34:23 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:34:23 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:34:23 --> Utf8 Class Initialized
INFO - 2016-05-07 09:34:23 --> URI Class Initialized
INFO - 2016-05-07 09:34:23 --> Router Class Initialized
INFO - 2016-05-07 09:34:23 --> Output Class Initialized
INFO - 2016-05-07 09:34:23 --> Security Class Initialized
DEBUG - 2016-05-07 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:34:23 --> Input Class Initialized
INFO - 2016-05-07 09:34:23 --> Language Class Initialized
INFO - 2016-05-07 09:34:23 --> Loader Class Initialized
INFO - 2016-05-07 09:34:23 --> Helper loaded: url_helper
INFO - 2016-05-07 09:34:23 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:34:23 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:34:23 --> Helper loaded: form_helper
INFO - 2016-05-07 09:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:34:23 --> Form Validation Class Initialized
INFO - 2016-05-07 09:34:23 --> Controller Class Initialized
INFO - 2016-05-07 09:34:23 --> Model Class Initialized
INFO - 2016-05-07 09:34:23 --> Database Driver Class Initialized
INFO - 2016-05-07 09:34:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:34:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:34:23 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:34:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:34:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 09:34:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:34:23 --> Final output sent to browser
DEBUG - 2016-05-07 09:34:23 --> Total execution time: 0.1376
INFO - 2016-05-07 09:34:29 --> Config Class Initialized
INFO - 2016-05-07 09:34:29 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:34:29 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:34:29 --> Utf8 Class Initialized
INFO - 2016-05-07 09:34:29 --> URI Class Initialized
INFO - 2016-05-07 09:34:29 --> Router Class Initialized
INFO - 2016-05-07 09:34:29 --> Output Class Initialized
INFO - 2016-05-07 09:34:29 --> Security Class Initialized
DEBUG - 2016-05-07 09:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:34:29 --> Input Class Initialized
INFO - 2016-05-07 09:34:29 --> Language Class Initialized
INFO - 2016-05-07 09:34:29 --> Loader Class Initialized
INFO - 2016-05-07 09:34:29 --> Helper loaded: url_helper
INFO - 2016-05-07 09:34:29 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:34:29 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:34:29 --> Helper loaded: form_helper
INFO - 2016-05-07 09:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:34:29 --> Form Validation Class Initialized
INFO - 2016-05-07 09:34:29 --> Controller Class Initialized
INFO - 2016-05-07 09:34:29 --> Model Class Initialized
INFO - 2016-05-07 09:34:29 --> Database Driver Class Initialized
INFO - 2016-05-07 09:34:29 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:34:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:34:29 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:34:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:34:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 09:34:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:34:29 --> Final output sent to browser
DEBUG - 2016-05-07 09:34:29 --> Total execution time: 0.1019
INFO - 2016-05-07 09:34:30 --> Config Class Initialized
INFO - 2016-05-07 09:34:30 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:34:30 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:34:30 --> Utf8 Class Initialized
INFO - 2016-05-07 09:34:30 --> URI Class Initialized
INFO - 2016-05-07 09:34:30 --> Router Class Initialized
INFO - 2016-05-07 09:34:30 --> Output Class Initialized
INFO - 2016-05-07 09:34:30 --> Security Class Initialized
DEBUG - 2016-05-07 09:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:34:30 --> Input Class Initialized
INFO - 2016-05-07 09:34:30 --> Language Class Initialized
INFO - 2016-05-07 09:34:30 --> Loader Class Initialized
INFO - 2016-05-07 09:34:30 --> Helper loaded: url_helper
INFO - 2016-05-07 09:34:30 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:34:30 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:34:30 --> Helper loaded: form_helper
INFO - 2016-05-07 09:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:34:30 --> Form Validation Class Initialized
INFO - 2016-05-07 09:34:30 --> Controller Class Initialized
INFO - 2016-05-07 09:34:30 --> Model Class Initialized
INFO - 2016-05-07 09:34:30 --> Database Driver Class Initialized
INFO - 2016-05-07 09:34:30 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:34:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:34:30 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:34:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:34:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 09:34:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:34:30 --> Final output sent to browser
DEBUG - 2016-05-07 09:34:30 --> Total execution time: 0.1272
INFO - 2016-05-07 09:34:42 --> Config Class Initialized
INFO - 2016-05-07 09:34:42 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:34:42 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:34:42 --> Utf8 Class Initialized
INFO - 2016-05-07 09:34:42 --> URI Class Initialized
INFO - 2016-05-07 09:34:42 --> Router Class Initialized
INFO - 2016-05-07 09:34:42 --> Output Class Initialized
INFO - 2016-05-07 09:34:42 --> Security Class Initialized
DEBUG - 2016-05-07 09:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:34:42 --> Input Class Initialized
INFO - 2016-05-07 09:34:42 --> Language Class Initialized
INFO - 2016-05-07 09:34:42 --> Loader Class Initialized
INFO - 2016-05-07 09:34:42 --> Helper loaded: url_helper
INFO - 2016-05-07 09:34:42 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:34:42 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:34:42 --> Helper loaded: form_helper
INFO - 2016-05-07 09:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:34:42 --> Form Validation Class Initialized
INFO - 2016-05-07 09:34:42 --> Controller Class Initialized
INFO - 2016-05-07 09:34:42 --> Model Class Initialized
INFO - 2016-05-07 09:34:42 --> Database Driver Class Initialized
INFO - 2016-05-07 09:34:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:34:42 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:34:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:34:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-07 09:34:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:34:42 --> Final output sent to browser
DEBUG - 2016-05-07 09:34:42 --> Total execution time: 0.0742
INFO - 2016-05-07 09:34:54 --> Config Class Initialized
INFO - 2016-05-07 09:34:54 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:34:54 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:34:54 --> Utf8 Class Initialized
INFO - 2016-05-07 09:34:54 --> URI Class Initialized
INFO - 2016-05-07 09:34:54 --> Router Class Initialized
INFO - 2016-05-07 09:34:54 --> Output Class Initialized
INFO - 2016-05-07 09:34:54 --> Security Class Initialized
DEBUG - 2016-05-07 09:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:34:54 --> Input Class Initialized
INFO - 2016-05-07 09:34:54 --> Language Class Initialized
INFO - 2016-05-07 09:34:54 --> Loader Class Initialized
INFO - 2016-05-07 09:34:54 --> Helper loaded: url_helper
INFO - 2016-05-07 09:34:54 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:34:54 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:34:54 --> Helper loaded: form_helper
INFO - 2016-05-07 09:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:34:54 --> Form Validation Class Initialized
INFO - 2016-05-07 09:34:54 --> Controller Class Initialized
INFO - 2016-05-07 09:34:54 --> Model Class Initialized
INFO - 2016-05-07 09:34:54 --> Database Driver Class Initialized
INFO - 2016-05-07 09:34:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:34:54 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:34:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:34:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-07 09:34:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:34:54 --> Final output sent to browser
DEBUG - 2016-05-07 09:34:54 --> Total execution time: 0.1098
INFO - 2016-05-07 09:34:58 --> Config Class Initialized
INFO - 2016-05-07 09:34:58 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:34:58 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:34:58 --> Utf8 Class Initialized
INFO - 2016-05-07 09:34:58 --> URI Class Initialized
INFO - 2016-05-07 09:34:58 --> Router Class Initialized
INFO - 2016-05-07 09:34:58 --> Output Class Initialized
INFO - 2016-05-07 09:34:58 --> Security Class Initialized
DEBUG - 2016-05-07 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:34:58 --> Input Class Initialized
INFO - 2016-05-07 09:34:58 --> Language Class Initialized
INFO - 2016-05-07 09:34:58 --> Loader Class Initialized
INFO - 2016-05-07 09:34:58 --> Helper loaded: url_helper
INFO - 2016-05-07 09:34:58 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:34:58 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:34:58 --> Helper loaded: form_helper
INFO - 2016-05-07 09:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:34:58 --> Form Validation Class Initialized
INFO - 2016-05-07 09:34:58 --> Controller Class Initialized
INFO - 2016-05-07 09:34:58 --> Model Class Initialized
INFO - 2016-05-07 09:34:58 --> Database Driver Class Initialized
INFO - 2016-05-07 09:34:58 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:34:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:34:58 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:34:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:34:58 --> Helper loaded: nif_validate_helper
INFO - 2016-05-07 09:34:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-07 09:34:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:34:58 --> Final output sent to browser
DEBUG - 2016-05-07 09:34:58 --> Total execution time: 0.0749
INFO - 2016-05-07 09:36:09 --> Config Class Initialized
INFO - 2016-05-07 09:36:09 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:36:09 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:36:09 --> Utf8 Class Initialized
INFO - 2016-05-07 09:36:09 --> URI Class Initialized
INFO - 2016-05-07 09:36:09 --> Router Class Initialized
INFO - 2016-05-07 09:36:09 --> Output Class Initialized
INFO - 2016-05-07 09:36:10 --> Security Class Initialized
DEBUG - 2016-05-07 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:36:10 --> Input Class Initialized
INFO - 2016-05-07 09:36:10 --> Language Class Initialized
INFO - 2016-05-07 09:36:10 --> Loader Class Initialized
INFO - 2016-05-07 09:36:10 --> Helper loaded: url_helper
INFO - 2016-05-07 09:36:10 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:36:10 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:36:10 --> Helper loaded: form_helper
INFO - 2016-05-07 09:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:36:10 --> Form Validation Class Initialized
INFO - 2016-05-07 09:36:10 --> Controller Class Initialized
INFO - 2016-05-07 09:36:10 --> Model Class Initialized
INFO - 2016-05-07 09:36:10 --> Database Driver Class Initialized
INFO - 2016-05-07 09:36:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:36:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:36:10 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:36:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:36:10 --> Helper loaded: nif_validate_helper
ERROR - 2016-05-07 09:36:10 --> Query error: Unknown column 'ascending' in 'order clause' - Invalid query: SELECT idProveedor, nombre, nif, correo, estado, telefono FROM proveedor ORDER BY ascending LIMIT 0, 5; 
INFO - 2016-05-07 09:36:10 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 09:36:26 --> Config Class Initialized
INFO - 2016-05-07 09:36:26 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:36:26 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:36:26 --> Utf8 Class Initialized
INFO - 2016-05-07 09:36:26 --> URI Class Initialized
INFO - 2016-05-07 09:36:26 --> Router Class Initialized
INFO - 2016-05-07 09:36:26 --> Output Class Initialized
INFO - 2016-05-07 09:36:26 --> Security Class Initialized
DEBUG - 2016-05-07 09:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:36:26 --> Input Class Initialized
INFO - 2016-05-07 09:36:26 --> Language Class Initialized
INFO - 2016-05-07 09:36:26 --> Loader Class Initialized
INFO - 2016-05-07 09:36:26 --> Helper loaded: url_helper
INFO - 2016-05-07 09:36:26 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:36:26 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:36:26 --> Helper loaded: form_helper
INFO - 2016-05-07 09:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:36:26 --> Form Validation Class Initialized
INFO - 2016-05-07 09:36:26 --> Controller Class Initialized
INFO - 2016-05-07 09:36:26 --> Model Class Initialized
INFO - 2016-05-07 09:36:26 --> Database Driver Class Initialized
INFO - 2016-05-07 09:36:26 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:36:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:36:26 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:36:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:36:26 --> Helper loaded: nif_validate_helper
INFO - 2016-05-07 09:36:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-07 09:36:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:36:26 --> Final output sent to browser
DEBUG - 2016-05-07 09:36:26 --> Total execution time: 0.1009
INFO - 2016-05-07 09:36:41 --> Config Class Initialized
INFO - 2016-05-07 09:36:41 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:36:41 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:36:41 --> Utf8 Class Initialized
INFO - 2016-05-07 09:36:41 --> URI Class Initialized
INFO - 2016-05-07 09:36:41 --> Router Class Initialized
INFO - 2016-05-07 09:36:41 --> Output Class Initialized
INFO - 2016-05-07 09:36:41 --> Security Class Initialized
DEBUG - 2016-05-07 09:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:36:41 --> Input Class Initialized
INFO - 2016-05-07 09:36:41 --> Language Class Initialized
INFO - 2016-05-07 09:36:41 --> Loader Class Initialized
INFO - 2016-05-07 09:36:41 --> Helper loaded: url_helper
INFO - 2016-05-07 09:36:41 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:36:41 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:36:41 --> Helper loaded: form_helper
INFO - 2016-05-07 09:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:36:41 --> Form Validation Class Initialized
INFO - 2016-05-07 09:36:41 --> Controller Class Initialized
INFO - 2016-05-07 09:36:41 --> Model Class Initialized
INFO - 2016-05-07 09:36:41 --> Database Driver Class Initialized
INFO - 2016-05-07 09:36:41 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:36:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:36:41 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:36:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:36:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 09:36:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:36:41 --> Final output sent to browser
DEBUG - 2016-05-07 09:36:41 --> Total execution time: 0.0752
INFO - 2016-05-07 09:36:46 --> Config Class Initialized
INFO - 2016-05-07 09:36:46 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:36:46 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:36:46 --> Utf8 Class Initialized
INFO - 2016-05-07 09:36:46 --> URI Class Initialized
INFO - 2016-05-07 09:36:46 --> Router Class Initialized
INFO - 2016-05-07 09:36:46 --> Output Class Initialized
INFO - 2016-05-07 09:36:46 --> Security Class Initialized
DEBUG - 2016-05-07 09:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:36:46 --> Input Class Initialized
INFO - 2016-05-07 09:36:46 --> Language Class Initialized
INFO - 2016-05-07 09:36:46 --> Loader Class Initialized
INFO - 2016-05-07 09:36:46 --> Helper loaded: url_helper
INFO - 2016-05-07 09:36:46 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:36:46 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:36:46 --> Helper loaded: form_helper
INFO - 2016-05-07 09:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:36:46 --> Form Validation Class Initialized
INFO - 2016-05-07 09:36:46 --> Controller Class Initialized
INFO - 2016-05-07 09:36:46 --> Model Class Initialized
INFO - 2016-05-07 09:36:46 --> Database Driver Class Initialized
INFO - 2016-05-07 09:36:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:36:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:36:46 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:36:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:36:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:36:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:36:46 --> Final output sent to browser
DEBUG - 2016-05-07 09:36:46 --> Total execution time: 0.0771
INFO - 2016-05-07 09:38:00 --> Config Class Initialized
INFO - 2016-05-07 09:38:00 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:38:00 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:38:00 --> Utf8 Class Initialized
INFO - 2016-05-07 09:38:00 --> URI Class Initialized
INFO - 2016-05-07 09:38:00 --> Router Class Initialized
INFO - 2016-05-07 09:38:00 --> Output Class Initialized
INFO - 2016-05-07 09:38:00 --> Security Class Initialized
DEBUG - 2016-05-07 09:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:38:00 --> Input Class Initialized
INFO - 2016-05-07 09:38:00 --> Language Class Initialized
INFO - 2016-05-07 09:38:00 --> Loader Class Initialized
INFO - 2016-05-07 09:38:00 --> Helper loaded: url_helper
INFO - 2016-05-07 09:38:00 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:38:00 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:38:00 --> Helper loaded: form_helper
INFO - 2016-05-07 09:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:38:00 --> Form Validation Class Initialized
INFO - 2016-05-07 09:38:00 --> Controller Class Initialized
INFO - 2016-05-07 09:38:00 --> Model Class Initialized
INFO - 2016-05-07 09:38:00 --> Database Driver Class Initialized
INFO - 2016-05-07 09:38:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:38:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:38:00 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:38:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:38:00 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:38:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:38:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:38:00 --> Final output sent to browser
DEBUG - 2016-05-07 09:38:00 --> Total execution time: 0.0875
INFO - 2016-05-07 09:38:14 --> Config Class Initialized
INFO - 2016-05-07 09:38:14 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:38:14 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:38:14 --> Utf8 Class Initialized
INFO - 2016-05-07 09:38:14 --> URI Class Initialized
INFO - 2016-05-07 09:38:14 --> Router Class Initialized
INFO - 2016-05-07 09:38:14 --> Output Class Initialized
INFO - 2016-05-07 09:38:14 --> Security Class Initialized
DEBUG - 2016-05-07 09:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:38:14 --> Input Class Initialized
INFO - 2016-05-07 09:38:14 --> Language Class Initialized
INFO - 2016-05-07 09:38:14 --> Loader Class Initialized
INFO - 2016-05-07 09:38:14 --> Helper loaded: url_helper
INFO - 2016-05-07 09:38:14 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:38:14 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:38:14 --> Helper loaded: form_helper
INFO - 2016-05-07 09:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:38:14 --> Form Validation Class Initialized
INFO - 2016-05-07 09:38:14 --> Controller Class Initialized
INFO - 2016-05-07 09:38:14 --> Model Class Initialized
INFO - 2016-05-07 09:38:14 --> Database Driver Class Initialized
INFO - 2016-05-07 09:38:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:38:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:38:14 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:38:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:38:14 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-05-07 09:38:14 --> Query error: Duplicate entry 'LG G4' for key 'nombre_UNIQUE' - Invalid query: UPDATE `producto` SET `nombre` = 'LG G4', `marca` = 'Huawei', `precio` = '50.00', `precio_venta` = '219.62', `iva` = '21.00', `stock` = '10', `idCategoria` = '2', `idProveedor` = '2', `descripcion` = ''
WHERE `idproducto` = '5'
INFO - 2016-05-07 09:38:14 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 09:39:03 --> Config Class Initialized
INFO - 2016-05-07 09:39:03 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:39:03 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:39:03 --> Utf8 Class Initialized
INFO - 2016-05-07 09:39:03 --> URI Class Initialized
INFO - 2016-05-07 09:39:03 --> Router Class Initialized
INFO - 2016-05-07 09:39:03 --> Output Class Initialized
INFO - 2016-05-07 09:39:03 --> Security Class Initialized
DEBUG - 2016-05-07 09:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:39:03 --> Input Class Initialized
INFO - 2016-05-07 09:39:03 --> Language Class Initialized
INFO - 2016-05-07 09:39:03 --> Loader Class Initialized
INFO - 2016-05-07 09:39:03 --> Helper loaded: url_helper
INFO - 2016-05-07 09:39:03 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:39:03 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:39:03 --> Helper loaded: form_helper
INFO - 2016-05-07 09:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:39:03 --> Form Validation Class Initialized
INFO - 2016-05-07 09:39:03 --> Controller Class Initialized
INFO - 2016-05-07 09:39:03 --> Model Class Initialized
INFO - 2016-05-07 09:39:03 --> Database Driver Class Initialized
INFO - 2016-05-07 09:39:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:39:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:39:03 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:39:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:39:03 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:39:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:39:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:39:03 --> Final output sent to browser
DEBUG - 2016-05-07 09:39:03 --> Total execution time: 0.0804
INFO - 2016-05-07 09:39:40 --> Config Class Initialized
INFO - 2016-05-07 09:39:40 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:39:40 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:39:40 --> Utf8 Class Initialized
INFO - 2016-05-07 09:39:40 --> URI Class Initialized
INFO - 2016-05-07 09:39:40 --> Router Class Initialized
INFO - 2016-05-07 09:39:40 --> Output Class Initialized
INFO - 2016-05-07 09:39:40 --> Security Class Initialized
DEBUG - 2016-05-07 09:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:39:40 --> Input Class Initialized
INFO - 2016-05-07 09:39:40 --> Language Class Initialized
INFO - 2016-05-07 09:39:40 --> Loader Class Initialized
INFO - 2016-05-07 09:39:40 --> Helper loaded: url_helper
INFO - 2016-05-07 09:39:40 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:39:40 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:39:40 --> Helper loaded: form_helper
INFO - 2016-05-07 09:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:39:40 --> Form Validation Class Initialized
INFO - 2016-05-07 09:39:40 --> Controller Class Initialized
INFO - 2016-05-07 09:39:40 --> Model Class Initialized
INFO - 2016-05-07 09:39:40 --> Database Driver Class Initialized
INFO - 2016-05-07 09:39:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:39:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:39:40 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:39:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:39:40 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:39:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:39:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:39:40 --> Final output sent to browser
DEBUG - 2016-05-07 09:39:40 --> Total execution time: 0.1171
INFO - 2016-05-07 09:39:47 --> Config Class Initialized
INFO - 2016-05-07 09:39:47 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:39:47 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:39:47 --> Utf8 Class Initialized
INFO - 2016-05-07 09:39:47 --> URI Class Initialized
INFO - 2016-05-07 09:39:47 --> Router Class Initialized
INFO - 2016-05-07 09:39:47 --> Output Class Initialized
INFO - 2016-05-07 09:39:47 --> Security Class Initialized
DEBUG - 2016-05-07 09:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:39:47 --> Input Class Initialized
INFO - 2016-05-07 09:39:47 --> Language Class Initialized
INFO - 2016-05-07 09:39:47 --> Loader Class Initialized
INFO - 2016-05-07 09:39:47 --> Helper loaded: url_helper
INFO - 2016-05-07 09:39:47 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:39:47 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:39:47 --> Helper loaded: form_helper
INFO - 2016-05-07 09:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:39:47 --> Form Validation Class Initialized
INFO - 2016-05-07 09:39:47 --> Controller Class Initialized
INFO - 2016-05-07 09:39:47 --> Model Class Initialized
INFO - 2016-05-07 09:39:47 --> Database Driver Class Initialized
INFO - 2016-05-07 09:39:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:39:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:39:47 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:39:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:39:47 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:39:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:39:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:39:47 --> Final output sent to browser
DEBUG - 2016-05-07 09:39:47 --> Total execution time: 0.0962
INFO - 2016-05-07 09:40:33 --> Config Class Initialized
INFO - 2016-05-07 09:40:33 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:40:33 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:40:33 --> Utf8 Class Initialized
INFO - 2016-05-07 09:40:33 --> URI Class Initialized
INFO - 2016-05-07 09:40:33 --> Router Class Initialized
INFO - 2016-05-07 09:40:33 --> Output Class Initialized
INFO - 2016-05-07 09:40:33 --> Security Class Initialized
DEBUG - 2016-05-07 09:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:40:33 --> Input Class Initialized
INFO - 2016-05-07 09:40:33 --> Language Class Initialized
INFO - 2016-05-07 09:40:33 --> Loader Class Initialized
INFO - 2016-05-07 09:40:33 --> Helper loaded: url_helper
INFO - 2016-05-07 09:40:33 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:40:33 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:40:33 --> Helper loaded: form_helper
INFO - 2016-05-07 09:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:40:33 --> Form Validation Class Initialized
INFO - 2016-05-07 09:40:33 --> Controller Class Initialized
INFO - 2016-05-07 09:40:33 --> Model Class Initialized
INFO - 2016-05-07 09:40:33 --> Database Driver Class Initialized
INFO - 2016-05-07 09:40:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:40:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:40:33 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:40:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:40:33 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:40:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:40:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:40:33 --> Final output sent to browser
DEBUG - 2016-05-07 09:40:33 --> Total execution time: 0.0821
INFO - 2016-05-07 09:40:57 --> Config Class Initialized
INFO - 2016-05-07 09:40:57 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:40:57 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:40:57 --> Utf8 Class Initialized
INFO - 2016-05-07 09:40:57 --> URI Class Initialized
INFO - 2016-05-07 09:40:57 --> Router Class Initialized
INFO - 2016-05-07 09:40:57 --> Output Class Initialized
INFO - 2016-05-07 09:40:57 --> Security Class Initialized
DEBUG - 2016-05-07 09:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:40:57 --> Input Class Initialized
INFO - 2016-05-07 09:40:57 --> Language Class Initialized
INFO - 2016-05-07 09:40:57 --> Loader Class Initialized
INFO - 2016-05-07 09:40:57 --> Helper loaded: url_helper
INFO - 2016-05-07 09:40:57 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:40:57 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:40:57 --> Helper loaded: form_helper
INFO - 2016-05-07 09:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:40:57 --> Form Validation Class Initialized
INFO - 2016-05-07 09:40:57 --> Controller Class Initialized
INFO - 2016-05-07 09:40:57 --> Model Class Initialized
INFO - 2016-05-07 09:40:57 --> Database Driver Class Initialized
INFO - 2016-05-07 09:40:57 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:40:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:40:57 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:40:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:40:57 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:40:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:40:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:40:57 --> Final output sent to browser
DEBUG - 2016-05-07 09:40:57 --> Total execution time: 0.1724
INFO - 2016-05-07 09:43:37 --> Config Class Initialized
INFO - 2016-05-07 09:43:37 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:43:37 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:43:37 --> Utf8 Class Initialized
INFO - 2016-05-07 09:43:37 --> URI Class Initialized
INFO - 2016-05-07 09:43:37 --> Router Class Initialized
INFO - 2016-05-07 09:43:37 --> Output Class Initialized
INFO - 2016-05-07 09:43:37 --> Security Class Initialized
DEBUG - 2016-05-07 09:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:43:37 --> Input Class Initialized
INFO - 2016-05-07 09:43:37 --> Language Class Initialized
INFO - 2016-05-07 09:43:37 --> Loader Class Initialized
INFO - 2016-05-07 09:43:37 --> Helper loaded: url_helper
INFO - 2016-05-07 09:43:37 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:43:37 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:43:37 --> Helper loaded: form_helper
INFO - 2016-05-07 09:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:43:37 --> Form Validation Class Initialized
INFO - 2016-05-07 09:43:37 --> Controller Class Initialized
INFO - 2016-05-07 09:43:37 --> Model Class Initialized
INFO - 2016-05-07 09:43:38 --> Database Driver Class Initialized
INFO - 2016-05-07 09:43:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:43:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:43:38 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:43:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:43:38 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:43:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 09:43:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:43:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:43:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:43:38 --> Final output sent to browser
DEBUG - 2016-05-07 09:43:38 --> Total execution time: 0.0872
INFO - 2016-05-07 09:44:18 --> Config Class Initialized
INFO - 2016-05-07 09:44:18 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:44:18 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:44:18 --> Utf8 Class Initialized
INFO - 2016-05-07 09:44:18 --> URI Class Initialized
INFO - 2016-05-07 09:44:18 --> Router Class Initialized
INFO - 2016-05-07 09:44:18 --> Output Class Initialized
INFO - 2016-05-07 09:44:18 --> Security Class Initialized
DEBUG - 2016-05-07 09:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:44:18 --> Input Class Initialized
INFO - 2016-05-07 09:44:18 --> Language Class Initialized
INFO - 2016-05-07 09:44:18 --> Loader Class Initialized
INFO - 2016-05-07 09:44:18 --> Helper loaded: url_helper
INFO - 2016-05-07 09:44:18 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:44:18 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:44:18 --> Helper loaded: form_helper
INFO - 2016-05-07 09:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:44:18 --> Form Validation Class Initialized
INFO - 2016-05-07 09:44:18 --> Controller Class Initialized
INFO - 2016-05-07 09:44:18 --> Model Class Initialized
INFO - 2016-05-07 09:44:18 --> Database Driver Class Initialized
INFO - 2016-05-07 09:44:18 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:44:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:44:18 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:44:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:44:18 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-05-07 09:44:18 --> Severity: Notice --> Undefined index: categoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php 43
ERROR - 2016-05-07 09:44:18 --> Severity: Notice --> Undefined index: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php 47
INFO - 2016-05-07 09:44:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 09:44:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:44:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:44:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:44:18 --> Final output sent to browser
DEBUG - 2016-05-07 09:44:18 --> Total execution time: 0.0989
INFO - 2016-05-07 09:44:46 --> Config Class Initialized
INFO - 2016-05-07 09:44:46 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:44:46 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:44:46 --> Utf8 Class Initialized
INFO - 2016-05-07 09:44:46 --> URI Class Initialized
INFO - 2016-05-07 09:44:46 --> Router Class Initialized
INFO - 2016-05-07 09:44:46 --> Output Class Initialized
INFO - 2016-05-07 09:44:46 --> Security Class Initialized
DEBUG - 2016-05-07 09:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:44:46 --> Input Class Initialized
INFO - 2016-05-07 09:44:46 --> Language Class Initialized
INFO - 2016-05-07 09:44:46 --> Loader Class Initialized
INFO - 2016-05-07 09:44:46 --> Helper loaded: url_helper
INFO - 2016-05-07 09:44:46 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:44:46 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:44:46 --> Helper loaded: form_helper
INFO - 2016-05-07 09:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:44:46 --> Form Validation Class Initialized
INFO - 2016-05-07 09:44:46 --> Controller Class Initialized
INFO - 2016-05-07 09:44:46 --> Model Class Initialized
INFO - 2016-05-07 09:44:46 --> Database Driver Class Initialized
INFO - 2016-05-07 09:44:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:44:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:44:46 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:44:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:44:46 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:44:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 09:44:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:44:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:44:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:44:46 --> Final output sent to browser
DEBUG - 2016-05-07 09:44:46 --> Total execution time: 0.0829
INFO - 2016-05-07 09:45:03 --> Config Class Initialized
INFO - 2016-05-07 09:45:03 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:45:03 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:45:03 --> Utf8 Class Initialized
INFO - 2016-05-07 09:45:03 --> URI Class Initialized
INFO - 2016-05-07 09:45:03 --> Router Class Initialized
INFO - 2016-05-07 09:45:03 --> Output Class Initialized
INFO - 2016-05-07 09:45:03 --> Security Class Initialized
DEBUG - 2016-05-07 09:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:45:03 --> Input Class Initialized
INFO - 2016-05-07 09:45:03 --> Language Class Initialized
INFO - 2016-05-07 09:45:03 --> Loader Class Initialized
INFO - 2016-05-07 09:45:03 --> Helper loaded: url_helper
INFO - 2016-05-07 09:45:03 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:45:03 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:45:03 --> Helper loaded: form_helper
INFO - 2016-05-07 09:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:45:03 --> Form Validation Class Initialized
INFO - 2016-05-07 09:45:03 --> Controller Class Initialized
INFO - 2016-05-07 09:45:03 --> Model Class Initialized
INFO - 2016-05-07 09:45:03 --> Database Driver Class Initialized
INFO - 2016-05-07 09:45:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:45:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:45:03 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:45:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:45:03 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:45:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 09:45:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:45:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:45:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:45:03 --> Final output sent to browser
DEBUG - 2016-05-07 09:45:03 --> Total execution time: 0.0852
INFO - 2016-05-07 09:45:10 --> Config Class Initialized
INFO - 2016-05-07 09:45:10 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:45:10 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:45:10 --> Utf8 Class Initialized
INFO - 2016-05-07 09:45:10 --> URI Class Initialized
INFO - 2016-05-07 09:45:10 --> Router Class Initialized
INFO - 2016-05-07 09:45:10 --> Output Class Initialized
INFO - 2016-05-07 09:45:10 --> Security Class Initialized
DEBUG - 2016-05-07 09:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:45:10 --> Input Class Initialized
INFO - 2016-05-07 09:45:10 --> Language Class Initialized
INFO - 2016-05-07 09:45:10 --> Loader Class Initialized
INFO - 2016-05-07 09:45:10 --> Helper loaded: url_helper
INFO - 2016-05-07 09:45:10 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:45:10 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:45:10 --> Helper loaded: form_helper
INFO - 2016-05-07 09:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:45:10 --> Form Validation Class Initialized
INFO - 2016-05-07 09:45:10 --> Controller Class Initialized
INFO - 2016-05-07 09:45:10 --> Model Class Initialized
INFO - 2016-05-07 09:45:10 --> Database Driver Class Initialized
INFO - 2016-05-07 09:45:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:45:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:45:10 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:45:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:45:10 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:45:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:45:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:45:10 --> Final output sent to browser
DEBUG - 2016-05-07 09:45:10 --> Total execution time: 0.0806
INFO - 2016-05-07 09:45:22 --> Config Class Initialized
INFO - 2016-05-07 09:45:22 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:45:22 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:45:22 --> Utf8 Class Initialized
INFO - 2016-05-07 09:45:22 --> URI Class Initialized
INFO - 2016-05-07 09:45:22 --> Router Class Initialized
INFO - 2016-05-07 09:45:22 --> Output Class Initialized
INFO - 2016-05-07 09:45:22 --> Security Class Initialized
DEBUG - 2016-05-07 09:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:45:22 --> Input Class Initialized
INFO - 2016-05-07 09:45:22 --> Language Class Initialized
INFO - 2016-05-07 09:45:22 --> Loader Class Initialized
INFO - 2016-05-07 09:45:22 --> Helper loaded: url_helper
INFO - 2016-05-07 09:45:22 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:45:22 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:45:22 --> Helper loaded: form_helper
INFO - 2016-05-07 09:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:45:22 --> Form Validation Class Initialized
INFO - 2016-05-07 09:45:22 --> Controller Class Initialized
INFO - 2016-05-07 09:45:22 --> Model Class Initialized
INFO - 2016-05-07 09:45:22 --> Database Driver Class Initialized
INFO - 2016-05-07 09:45:22 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:45:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:45:22 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:45:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:45:22 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:45:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 09:45:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:45:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 09:45:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:45:22 --> Final output sent to browser
DEBUG - 2016-05-07 09:45:22 --> Total execution time: 0.1288
INFO - 2016-05-07 09:46:04 --> Config Class Initialized
INFO - 2016-05-07 09:46:04 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:46:04 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:46:04 --> Utf8 Class Initialized
INFO - 2016-05-07 09:46:04 --> URI Class Initialized
INFO - 2016-05-07 09:46:04 --> Router Class Initialized
INFO - 2016-05-07 09:46:04 --> Output Class Initialized
INFO - 2016-05-07 09:46:04 --> Security Class Initialized
DEBUG - 2016-05-07 09:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:46:04 --> Input Class Initialized
INFO - 2016-05-07 09:46:04 --> Language Class Initialized
INFO - 2016-05-07 09:46:04 --> Loader Class Initialized
INFO - 2016-05-07 09:46:04 --> Helper loaded: url_helper
INFO - 2016-05-07 09:46:04 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:46:04 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:46:04 --> Helper loaded: form_helper
INFO - 2016-05-07 09:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:46:04 --> Form Validation Class Initialized
INFO - 2016-05-07 09:46:04 --> Controller Class Initialized
INFO - 2016-05-07 09:46:04 --> Model Class Initialized
INFO - 2016-05-07 09:46:04 --> Database Driver Class Initialized
INFO - 2016-05-07 09:46:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:46:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:46:04 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:46:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:46:04 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:46:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 09:46:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:46:04 --> Final output sent to browser
DEBUG - 2016-05-07 09:46:04 --> Total execution time: 0.1105
INFO - 2016-05-07 09:46:54 --> Config Class Initialized
INFO - 2016-05-07 09:46:54 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:46:54 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:46:54 --> Utf8 Class Initialized
INFO - 2016-05-07 09:46:54 --> URI Class Initialized
INFO - 2016-05-07 09:46:54 --> Router Class Initialized
INFO - 2016-05-07 09:46:54 --> Output Class Initialized
INFO - 2016-05-07 09:46:54 --> Security Class Initialized
DEBUG - 2016-05-07 09:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:46:54 --> Input Class Initialized
INFO - 2016-05-07 09:46:54 --> Language Class Initialized
INFO - 2016-05-07 09:46:54 --> Loader Class Initialized
INFO - 2016-05-07 09:46:54 --> Helper loaded: url_helper
INFO - 2016-05-07 09:46:54 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:46:54 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:46:54 --> Helper loaded: form_helper
INFO - 2016-05-07 09:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:46:54 --> Form Validation Class Initialized
INFO - 2016-05-07 09:46:54 --> Controller Class Initialized
INFO - 2016-05-07 09:46:54 --> Model Class Initialized
INFO - 2016-05-07 09:46:54 --> Database Driver Class Initialized
INFO - 2016-05-07 09:46:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:46:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:46:54 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:46:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:46:54 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-05-07 09:46:54 --> Severity: Notice --> Undefined variable: producto C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php 67
INFO - 2016-05-07 09:46:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 09:46:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:46:54 --> Final output sent to browser
DEBUG - 2016-05-07 09:46:54 --> Total execution time: 0.1197
INFO - 2016-05-07 09:46:55 --> Config Class Initialized
INFO - 2016-05-07 09:46:55 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:46:55 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:46:55 --> Utf8 Class Initialized
INFO - 2016-05-07 09:47:10 --> Config Class Initialized
INFO - 2016-05-07 09:47:10 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:47:10 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:47:10 --> Utf8 Class Initialized
INFO - 2016-05-07 09:47:10 --> URI Class Initialized
INFO - 2016-05-07 09:47:10 --> Router Class Initialized
INFO - 2016-05-07 09:47:10 --> Output Class Initialized
INFO - 2016-05-07 09:47:10 --> Security Class Initialized
DEBUG - 2016-05-07 09:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:47:10 --> Input Class Initialized
INFO - 2016-05-07 09:47:10 --> Language Class Initialized
INFO - 2016-05-07 09:47:10 --> Loader Class Initialized
INFO - 2016-05-07 09:47:10 --> Helper loaded: url_helper
INFO - 2016-05-07 09:47:10 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:47:10 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:47:10 --> Helper loaded: form_helper
INFO - 2016-05-07 09:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:47:10 --> Form Validation Class Initialized
INFO - 2016-05-07 09:47:10 --> Controller Class Initialized
INFO - 2016-05-07 09:47:10 --> Model Class Initialized
INFO - 2016-05-07 09:47:10 --> Database Driver Class Initialized
INFO - 2016-05-07 09:47:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:47:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:47:10 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:47:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:47:10 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-05-07 09:47:10 --> Severity: Notice --> Undefined index: imagen C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php 67
INFO - 2016-05-07 09:47:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 09:47:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:47:10 --> Final output sent to browser
DEBUG - 2016-05-07 09:47:10 --> Total execution time: 0.1070
INFO - 2016-05-07 09:47:11 --> Config Class Initialized
INFO - 2016-05-07 09:47:11 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:47:11 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:47:11 --> Utf8 Class Initialized
INFO - 2016-05-07 09:49:36 --> Config Class Initialized
INFO - 2016-05-07 09:49:36 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:49:36 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:49:36 --> Utf8 Class Initialized
INFO - 2016-05-07 09:49:36 --> URI Class Initialized
INFO - 2016-05-07 09:49:36 --> Router Class Initialized
INFO - 2016-05-07 09:49:36 --> Output Class Initialized
INFO - 2016-05-07 09:49:36 --> Security Class Initialized
DEBUG - 2016-05-07 09:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:49:36 --> Input Class Initialized
INFO - 2016-05-07 09:49:36 --> Language Class Initialized
INFO - 2016-05-07 09:49:36 --> Loader Class Initialized
INFO - 2016-05-07 09:49:36 --> Helper loaded: url_helper
INFO - 2016-05-07 09:49:36 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:49:36 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:49:36 --> Helper loaded: form_helper
INFO - 2016-05-07 09:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:49:36 --> Form Validation Class Initialized
INFO - 2016-05-07 09:49:36 --> Controller Class Initialized
INFO - 2016-05-07 09:49:36 --> Model Class Initialized
INFO - 2016-05-07 09:49:36 --> Database Driver Class Initialized
INFO - 2016-05-07 09:49:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:49:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:49:36 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:49:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:49:36 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-05-07 09:49:36 --> Severity: Notice --> Undefined index: cont C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 249
INFO - 2016-05-07 09:49:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 09:49:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:49:36 --> Final output sent to browser
DEBUG - 2016-05-07 09:49:36 --> Total execution time: 0.0949
INFO - 2016-05-07 09:49:49 --> Config Class Initialized
INFO - 2016-05-07 09:49:49 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:49:49 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:49:49 --> Utf8 Class Initialized
INFO - 2016-05-07 09:49:49 --> URI Class Initialized
INFO - 2016-05-07 09:49:49 --> Router Class Initialized
INFO - 2016-05-07 09:49:49 --> Output Class Initialized
INFO - 2016-05-07 09:49:49 --> Security Class Initialized
DEBUG - 2016-05-07 09:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:49:49 --> Input Class Initialized
INFO - 2016-05-07 09:49:49 --> Language Class Initialized
INFO - 2016-05-07 09:49:49 --> Loader Class Initialized
INFO - 2016-05-07 09:49:49 --> Helper loaded: url_helper
INFO - 2016-05-07 09:49:49 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:49:49 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:49:49 --> Helper loaded: form_helper
INFO - 2016-05-07 09:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:49:49 --> Form Validation Class Initialized
INFO - 2016-05-07 09:49:49 --> Controller Class Initialized
INFO - 2016-05-07 09:49:49 --> Model Class Initialized
INFO - 2016-05-07 09:49:49 --> Database Driver Class Initialized
INFO - 2016-05-07 09:49:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:49:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:49:49 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:49:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:49:49 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-05-07 09:49:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php 67
INFO - 2016-05-07 09:49:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 09:49:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:49:49 --> Final output sent to browser
DEBUG - 2016-05-07 09:49:49 --> Total execution time: 0.0864
INFO - 2016-05-07 09:49:49 --> Config Class Initialized
INFO - 2016-05-07 09:49:49 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:49:49 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:49:49 --> Utf8 Class Initialized
INFO - 2016-05-07 09:50:00 --> Config Class Initialized
INFO - 2016-05-07 09:50:00 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:50:00 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:50:00 --> Utf8 Class Initialized
INFO - 2016-05-07 09:50:00 --> URI Class Initialized
INFO - 2016-05-07 09:50:00 --> Router Class Initialized
INFO - 2016-05-07 09:50:00 --> Output Class Initialized
INFO - 2016-05-07 09:50:00 --> Security Class Initialized
DEBUG - 2016-05-07 09:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:50:00 --> Input Class Initialized
INFO - 2016-05-07 09:50:00 --> Language Class Initialized
INFO - 2016-05-07 09:50:00 --> Loader Class Initialized
INFO - 2016-05-07 09:50:00 --> Helper loaded: url_helper
INFO - 2016-05-07 09:50:00 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:50:00 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:50:00 --> Helper loaded: form_helper
INFO - 2016-05-07 09:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:50:00 --> Form Validation Class Initialized
INFO - 2016-05-07 09:50:00 --> Controller Class Initialized
INFO - 2016-05-07 09:50:00 --> Model Class Initialized
INFO - 2016-05-07 09:50:00 --> Database Driver Class Initialized
INFO - 2016-05-07 09:50:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:50:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:50:00 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:50:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:50:00 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:50:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 09:50:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:50:00 --> Final output sent to browser
DEBUG - 2016-05-07 09:50:00 --> Total execution time: 0.0859
INFO - 2016-05-07 09:50:58 --> Config Class Initialized
INFO - 2016-05-07 09:50:58 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:50:58 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:50:58 --> Utf8 Class Initialized
INFO - 2016-05-07 09:50:58 --> URI Class Initialized
INFO - 2016-05-07 09:50:58 --> Router Class Initialized
INFO - 2016-05-07 09:50:58 --> Output Class Initialized
INFO - 2016-05-07 09:50:58 --> Security Class Initialized
DEBUG - 2016-05-07 09:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:50:58 --> Input Class Initialized
INFO - 2016-05-07 09:50:58 --> Language Class Initialized
INFO - 2016-05-07 09:50:58 --> Loader Class Initialized
INFO - 2016-05-07 09:50:58 --> Helper loaded: url_helper
INFO - 2016-05-07 09:50:58 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:50:58 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:50:58 --> Helper loaded: form_helper
INFO - 2016-05-07 09:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:50:58 --> Form Validation Class Initialized
INFO - 2016-05-07 09:50:58 --> Controller Class Initialized
INFO - 2016-05-07 09:50:58 --> Model Class Initialized
INFO - 2016-05-07 09:50:58 --> Database Driver Class Initialized
INFO - 2016-05-07 09:50:58 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:50:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:50:58 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:50:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:50:58 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:50:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 09:50:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:50:58 --> Final output sent to browser
DEBUG - 2016-05-07 09:50:58 --> Total execution time: 0.1318
INFO - 2016-05-07 09:51:39 --> Config Class Initialized
INFO - 2016-05-07 09:51:39 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:51:39 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:51:39 --> Utf8 Class Initialized
INFO - 2016-05-07 09:51:39 --> URI Class Initialized
INFO - 2016-05-07 09:51:39 --> Router Class Initialized
INFO - 2016-05-07 09:51:39 --> Output Class Initialized
INFO - 2016-05-07 09:51:39 --> Security Class Initialized
DEBUG - 2016-05-07 09:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:51:39 --> Input Class Initialized
INFO - 2016-05-07 09:51:39 --> Language Class Initialized
INFO - 2016-05-07 09:51:39 --> Loader Class Initialized
INFO - 2016-05-07 09:51:39 --> Helper loaded: url_helper
INFO - 2016-05-07 09:51:39 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:51:39 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:51:39 --> Helper loaded: form_helper
INFO - 2016-05-07 09:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:51:39 --> Form Validation Class Initialized
INFO - 2016-05-07 09:51:39 --> Controller Class Initialized
INFO - 2016-05-07 09:51:39 --> Model Class Initialized
INFO - 2016-05-07 09:51:39 --> Database Driver Class Initialized
INFO - 2016-05-07 09:51:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:51:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:51:39 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:51:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:51:39 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:51:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 09:51:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:51:39 --> Final output sent to browser
DEBUG - 2016-05-07 09:51:39 --> Total execution time: 0.0864
INFO - 2016-05-07 09:51:53 --> Config Class Initialized
INFO - 2016-05-07 09:51:53 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:51:53 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:51:53 --> Utf8 Class Initialized
INFO - 2016-05-07 09:51:53 --> URI Class Initialized
INFO - 2016-05-07 09:51:53 --> Router Class Initialized
INFO - 2016-05-07 09:51:53 --> Output Class Initialized
INFO - 2016-05-07 09:51:53 --> Security Class Initialized
DEBUG - 2016-05-07 09:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:51:53 --> Input Class Initialized
INFO - 2016-05-07 09:51:53 --> Language Class Initialized
INFO - 2016-05-07 09:51:53 --> Loader Class Initialized
INFO - 2016-05-07 09:51:53 --> Helper loaded: url_helper
INFO - 2016-05-07 09:51:53 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:51:53 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:51:53 --> Helper loaded: form_helper
INFO - 2016-05-07 09:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:51:53 --> Form Validation Class Initialized
INFO - 2016-05-07 09:51:53 --> Controller Class Initialized
INFO - 2016-05-07 09:51:53 --> Model Class Initialized
INFO - 2016-05-07 09:51:53 --> Database Driver Class Initialized
INFO - 2016-05-07 09:51:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:51:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:51:53 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:51:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:51:53 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:51:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 09:51:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:51:53 --> Final output sent to browser
DEBUG - 2016-05-07 09:51:53 --> Total execution time: 0.0821
INFO - 2016-05-07 09:57:42 --> Config Class Initialized
INFO - 2016-05-07 09:57:42 --> Hooks Class Initialized
DEBUG - 2016-05-07 09:57:42 --> UTF-8 Support Enabled
INFO - 2016-05-07 09:57:42 --> Utf8 Class Initialized
INFO - 2016-05-07 09:57:42 --> URI Class Initialized
INFO - 2016-05-07 09:57:42 --> Router Class Initialized
INFO - 2016-05-07 09:57:42 --> Output Class Initialized
INFO - 2016-05-07 09:57:42 --> Security Class Initialized
DEBUG - 2016-05-07 09:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 09:57:42 --> Input Class Initialized
INFO - 2016-05-07 09:57:42 --> Language Class Initialized
INFO - 2016-05-07 09:57:42 --> Loader Class Initialized
INFO - 2016-05-07 09:57:42 --> Helper loaded: url_helper
INFO - 2016-05-07 09:57:42 --> Helper loaded: sesion_helper
INFO - 2016-05-07 09:57:42 --> Helper loaded: templates_helper
INFO - 2016-05-07 09:57:42 --> Helper loaded: form_helper
INFO - 2016-05-07 09:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 09:57:42 --> Form Validation Class Initialized
INFO - 2016-05-07 09:57:42 --> Controller Class Initialized
INFO - 2016-05-07 09:57:42 --> Model Class Initialized
INFO - 2016-05-07 09:57:42 --> Database Driver Class Initialized
INFO - 2016-05-07 09:57:42 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 09:57:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 09:57:42 --> Pagination Class Initialized
DEBUG - 2016-05-07 09:57:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 09:57:42 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 09:57:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 09:57:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 09:57:42 --> Final output sent to browser
DEBUG - 2016-05-07 09:57:42 --> Total execution time: 0.0812
INFO - 2016-05-07 10:01:33 --> Config Class Initialized
INFO - 2016-05-07 10:01:33 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:01:33 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:01:33 --> Utf8 Class Initialized
INFO - 2016-05-07 10:01:33 --> URI Class Initialized
INFO - 2016-05-07 10:01:33 --> Router Class Initialized
INFO - 2016-05-07 10:01:33 --> Output Class Initialized
INFO - 2016-05-07 10:01:33 --> Security Class Initialized
DEBUG - 2016-05-07 10:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:01:33 --> Input Class Initialized
INFO - 2016-05-07 10:01:33 --> Language Class Initialized
INFO - 2016-05-07 10:01:33 --> Loader Class Initialized
INFO - 2016-05-07 10:01:33 --> Helper loaded: url_helper
INFO - 2016-05-07 10:01:33 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:01:33 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:01:33 --> Helper loaded: form_helper
INFO - 2016-05-07 10:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:01:33 --> Form Validation Class Initialized
INFO - 2016-05-07 10:01:33 --> Controller Class Initialized
INFO - 2016-05-07 10:01:33 --> Model Class Initialized
INFO - 2016-05-07 10:01:33 --> Database Driver Class Initialized
INFO - 2016-05-07 10:01:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:01:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:01:33 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:01:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:01:33 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:01:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:01:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:01:33 --> Final output sent to browser
DEBUG - 2016-05-07 10:01:33 --> Total execution time: 0.1038
INFO - 2016-05-07 10:02:35 --> Config Class Initialized
INFO - 2016-05-07 10:02:35 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:02:35 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:02:35 --> Utf8 Class Initialized
INFO - 2016-05-07 10:02:35 --> URI Class Initialized
INFO - 2016-05-07 10:02:35 --> Router Class Initialized
INFO - 2016-05-07 10:02:35 --> Output Class Initialized
INFO - 2016-05-07 10:02:35 --> Security Class Initialized
DEBUG - 2016-05-07 10:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:02:35 --> Input Class Initialized
INFO - 2016-05-07 10:02:35 --> Language Class Initialized
INFO - 2016-05-07 10:02:35 --> Loader Class Initialized
INFO - 2016-05-07 10:02:35 --> Helper loaded: url_helper
INFO - 2016-05-07 10:02:35 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:02:35 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:02:35 --> Helper loaded: form_helper
INFO - 2016-05-07 10:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:02:35 --> Form Validation Class Initialized
INFO - 2016-05-07 10:02:35 --> Controller Class Initialized
INFO - 2016-05-07 10:02:35 --> Model Class Initialized
INFO - 2016-05-07 10:02:35 --> Database Driver Class Initialized
INFO - 2016-05-07 10:02:35 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:02:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:02:35 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:02:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:02:35 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:02:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:02:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:02:35 --> Final output sent to browser
DEBUG - 2016-05-07 10:02:35 --> Total execution time: 0.0833
INFO - 2016-05-07 10:02:51 --> Config Class Initialized
INFO - 2016-05-07 10:02:51 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:02:51 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:02:51 --> Utf8 Class Initialized
INFO - 2016-05-07 10:02:51 --> URI Class Initialized
INFO - 2016-05-07 10:02:51 --> Router Class Initialized
INFO - 2016-05-07 10:02:51 --> Output Class Initialized
INFO - 2016-05-07 10:02:51 --> Security Class Initialized
DEBUG - 2016-05-07 10:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:02:51 --> Input Class Initialized
INFO - 2016-05-07 10:02:51 --> Language Class Initialized
INFO - 2016-05-07 10:02:51 --> Loader Class Initialized
INFO - 2016-05-07 10:02:51 --> Helper loaded: url_helper
INFO - 2016-05-07 10:02:51 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:02:51 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:02:51 --> Helper loaded: form_helper
INFO - 2016-05-07 10:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:02:51 --> Form Validation Class Initialized
INFO - 2016-05-07 10:02:51 --> Controller Class Initialized
INFO - 2016-05-07 10:02:51 --> Model Class Initialized
INFO - 2016-05-07 10:02:51 --> Database Driver Class Initialized
INFO - 2016-05-07 10:02:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:02:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:02:51 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:02:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:02:51 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:02:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:02:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:02:51 --> Final output sent to browser
DEBUG - 2016-05-07 10:02:51 --> Total execution time: 0.0861
INFO - 2016-05-07 10:03:32 --> Config Class Initialized
INFO - 2016-05-07 10:03:32 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:03:32 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:03:32 --> Utf8 Class Initialized
INFO - 2016-05-07 10:03:32 --> URI Class Initialized
INFO - 2016-05-07 10:03:32 --> Router Class Initialized
INFO - 2016-05-07 10:03:32 --> Output Class Initialized
INFO - 2016-05-07 10:03:32 --> Security Class Initialized
DEBUG - 2016-05-07 10:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:03:32 --> Input Class Initialized
INFO - 2016-05-07 10:03:32 --> Language Class Initialized
INFO - 2016-05-07 10:03:32 --> Loader Class Initialized
INFO - 2016-05-07 10:03:32 --> Helper loaded: url_helper
INFO - 2016-05-07 10:03:32 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:03:32 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:03:32 --> Helper loaded: form_helper
INFO - 2016-05-07 10:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:03:32 --> Form Validation Class Initialized
INFO - 2016-05-07 10:03:32 --> Controller Class Initialized
INFO - 2016-05-07 10:03:32 --> Model Class Initialized
INFO - 2016-05-07 10:03:32 --> Database Driver Class Initialized
INFO - 2016-05-07 10:03:32 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:03:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:03:32 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:03:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:03:32 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:03:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:03:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:03:32 --> Final output sent to browser
DEBUG - 2016-05-07 10:03:32 --> Total execution time: 0.0839
INFO - 2016-05-07 10:07:26 --> Config Class Initialized
INFO - 2016-05-07 10:07:26 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:07:26 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:07:26 --> Utf8 Class Initialized
INFO - 2016-05-07 10:07:26 --> URI Class Initialized
INFO - 2016-05-07 10:07:26 --> Router Class Initialized
INFO - 2016-05-07 10:07:26 --> Output Class Initialized
INFO - 2016-05-07 10:07:26 --> Security Class Initialized
DEBUG - 2016-05-07 10:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:07:26 --> Input Class Initialized
INFO - 2016-05-07 10:07:26 --> Language Class Initialized
INFO - 2016-05-07 10:07:26 --> Loader Class Initialized
INFO - 2016-05-07 10:07:26 --> Helper loaded: url_helper
INFO - 2016-05-07 10:07:26 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:07:26 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:07:26 --> Helper loaded: form_helper
INFO - 2016-05-07 10:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:07:26 --> Form Validation Class Initialized
INFO - 2016-05-07 10:07:26 --> Controller Class Initialized
INFO - 2016-05-07 10:07:26 --> Model Class Initialized
INFO - 2016-05-07 10:07:26 --> Database Driver Class Initialized
INFO - 2016-05-07 10:07:26 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:07:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:07:26 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:07:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:07:26 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:07:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:07:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:07:26 --> Final output sent to browser
DEBUG - 2016-05-07 10:07:26 --> Total execution time: 0.0924
INFO - 2016-05-07 10:07:53 --> Config Class Initialized
INFO - 2016-05-07 10:07:53 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:07:53 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:07:53 --> Utf8 Class Initialized
INFO - 2016-05-07 10:07:53 --> URI Class Initialized
INFO - 2016-05-07 10:07:53 --> Router Class Initialized
INFO - 2016-05-07 10:07:53 --> Output Class Initialized
INFO - 2016-05-07 10:07:53 --> Security Class Initialized
DEBUG - 2016-05-07 10:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:07:53 --> Input Class Initialized
INFO - 2016-05-07 10:07:53 --> Language Class Initialized
INFO - 2016-05-07 10:07:53 --> Loader Class Initialized
INFO - 2016-05-07 10:07:53 --> Helper loaded: url_helper
INFO - 2016-05-07 10:07:53 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:07:53 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:07:53 --> Helper loaded: form_helper
INFO - 2016-05-07 10:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:07:53 --> Form Validation Class Initialized
INFO - 2016-05-07 10:07:53 --> Controller Class Initialized
INFO - 2016-05-07 10:07:53 --> Model Class Initialized
INFO - 2016-05-07 10:07:53 --> Database Driver Class Initialized
INFO - 2016-05-07 10:07:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:07:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:07:53 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:07:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:07:53 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:07:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:07:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:07:53 --> Final output sent to browser
DEBUG - 2016-05-07 10:07:53 --> Total execution time: 0.0823
INFO - 2016-05-07 10:08:18 --> Config Class Initialized
INFO - 2016-05-07 10:08:18 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:08:18 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:08:18 --> Utf8 Class Initialized
INFO - 2016-05-07 10:08:18 --> URI Class Initialized
INFO - 2016-05-07 10:08:18 --> Router Class Initialized
INFO - 2016-05-07 10:08:18 --> Output Class Initialized
INFO - 2016-05-07 10:08:18 --> Security Class Initialized
DEBUG - 2016-05-07 10:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:08:18 --> Input Class Initialized
INFO - 2016-05-07 10:08:18 --> Language Class Initialized
INFO - 2016-05-07 10:08:18 --> Loader Class Initialized
INFO - 2016-05-07 10:08:18 --> Helper loaded: url_helper
INFO - 2016-05-07 10:08:18 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:08:18 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:08:18 --> Helper loaded: form_helper
INFO - 2016-05-07 10:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:08:18 --> Form Validation Class Initialized
INFO - 2016-05-07 10:08:18 --> Controller Class Initialized
INFO - 2016-05-07 10:08:18 --> Model Class Initialized
INFO - 2016-05-07 10:08:18 --> Database Driver Class Initialized
INFO - 2016-05-07 10:08:18 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:08:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:08:18 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:08:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:08:18 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:08:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:08:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:08:18 --> Final output sent to browser
DEBUG - 2016-05-07 10:08:18 --> Total execution time: 0.0841
INFO - 2016-05-07 10:08:28 --> Config Class Initialized
INFO - 2016-05-07 10:08:28 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:08:28 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:08:28 --> Utf8 Class Initialized
INFO - 2016-05-07 10:08:28 --> URI Class Initialized
INFO - 2016-05-07 10:08:28 --> Router Class Initialized
INFO - 2016-05-07 10:08:28 --> Output Class Initialized
INFO - 2016-05-07 10:08:28 --> Security Class Initialized
DEBUG - 2016-05-07 10:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:08:28 --> Input Class Initialized
INFO - 2016-05-07 10:08:28 --> Language Class Initialized
INFO - 2016-05-07 10:08:28 --> Loader Class Initialized
INFO - 2016-05-07 10:08:28 --> Helper loaded: url_helper
INFO - 2016-05-07 10:08:28 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:08:28 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:08:28 --> Helper loaded: form_helper
INFO - 2016-05-07 10:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:08:28 --> Form Validation Class Initialized
INFO - 2016-05-07 10:08:28 --> Controller Class Initialized
INFO - 2016-05-07 10:08:28 --> Model Class Initialized
INFO - 2016-05-07 10:08:28 --> Database Driver Class Initialized
INFO - 2016-05-07 10:08:28 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:08:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:08:28 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:08:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:08:28 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:08:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:08:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:08:28 --> Final output sent to browser
DEBUG - 2016-05-07 10:08:28 --> Total execution time: 0.0823
INFO - 2016-05-07 10:08:57 --> Config Class Initialized
INFO - 2016-05-07 10:08:57 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:08:57 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:08:57 --> Utf8 Class Initialized
INFO - 2016-05-07 10:08:57 --> URI Class Initialized
INFO - 2016-05-07 10:08:57 --> Router Class Initialized
INFO - 2016-05-07 10:08:57 --> Output Class Initialized
INFO - 2016-05-07 10:08:57 --> Security Class Initialized
DEBUG - 2016-05-07 10:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:08:57 --> Input Class Initialized
INFO - 2016-05-07 10:08:57 --> Language Class Initialized
INFO - 2016-05-07 10:08:57 --> Loader Class Initialized
INFO - 2016-05-07 10:08:57 --> Helper loaded: url_helper
INFO - 2016-05-07 10:08:57 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:08:57 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:08:57 --> Helper loaded: form_helper
INFO - 2016-05-07 10:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:08:57 --> Form Validation Class Initialized
INFO - 2016-05-07 10:08:57 --> Controller Class Initialized
INFO - 2016-05-07 10:08:57 --> Model Class Initialized
INFO - 2016-05-07 10:08:57 --> Database Driver Class Initialized
INFO - 2016-05-07 10:08:57 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:08:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:08:57 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:08:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:08:57 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:08:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:08:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:08:57 --> Final output sent to browser
DEBUG - 2016-05-07 10:08:57 --> Total execution time: 0.0844
INFO - 2016-05-07 10:09:19 --> Config Class Initialized
INFO - 2016-05-07 10:09:19 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:09:19 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:09:19 --> Utf8 Class Initialized
INFO - 2016-05-07 10:09:19 --> URI Class Initialized
INFO - 2016-05-07 10:09:19 --> Router Class Initialized
INFO - 2016-05-07 10:09:19 --> Output Class Initialized
INFO - 2016-05-07 10:09:20 --> Security Class Initialized
DEBUG - 2016-05-07 10:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:09:20 --> Input Class Initialized
INFO - 2016-05-07 10:09:20 --> Language Class Initialized
INFO - 2016-05-07 10:09:20 --> Loader Class Initialized
INFO - 2016-05-07 10:09:20 --> Helper loaded: url_helper
INFO - 2016-05-07 10:09:20 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:09:20 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:09:20 --> Helper loaded: form_helper
INFO - 2016-05-07 10:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:09:20 --> Form Validation Class Initialized
INFO - 2016-05-07 10:09:20 --> Controller Class Initialized
INFO - 2016-05-07 10:09:20 --> Model Class Initialized
INFO - 2016-05-07 10:09:20 --> Database Driver Class Initialized
INFO - 2016-05-07 10:09:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:09:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:09:20 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:09:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:09:20 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:09:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:09:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:09:20 --> Final output sent to browser
DEBUG - 2016-05-07 10:09:20 --> Total execution time: 0.0818
INFO - 2016-05-07 10:09:33 --> Config Class Initialized
INFO - 2016-05-07 10:09:33 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:09:33 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:09:33 --> Utf8 Class Initialized
INFO - 2016-05-07 10:09:33 --> URI Class Initialized
INFO - 2016-05-07 10:09:33 --> Router Class Initialized
INFO - 2016-05-07 10:09:33 --> Output Class Initialized
INFO - 2016-05-07 10:09:33 --> Security Class Initialized
DEBUG - 2016-05-07 10:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:09:33 --> Input Class Initialized
INFO - 2016-05-07 10:09:33 --> Language Class Initialized
INFO - 2016-05-07 10:09:33 --> Loader Class Initialized
INFO - 2016-05-07 10:09:33 --> Helper loaded: url_helper
INFO - 2016-05-07 10:09:33 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:09:33 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:09:33 --> Helper loaded: form_helper
INFO - 2016-05-07 10:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:09:33 --> Form Validation Class Initialized
INFO - 2016-05-07 10:09:33 --> Controller Class Initialized
INFO - 2016-05-07 10:09:33 --> Model Class Initialized
INFO - 2016-05-07 10:09:33 --> Database Driver Class Initialized
INFO - 2016-05-07 10:09:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:09:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:09:33 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:09:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:09:33 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:09:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:09:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:09:33 --> Final output sent to browser
DEBUG - 2016-05-07 10:09:33 --> Total execution time: 0.0846
INFO - 2016-05-07 10:09:53 --> Config Class Initialized
INFO - 2016-05-07 10:09:53 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:09:53 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:09:53 --> Utf8 Class Initialized
INFO - 2016-05-07 10:09:53 --> URI Class Initialized
INFO - 2016-05-07 10:09:53 --> Router Class Initialized
INFO - 2016-05-07 10:09:53 --> Output Class Initialized
INFO - 2016-05-07 10:09:53 --> Security Class Initialized
DEBUG - 2016-05-07 10:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:09:53 --> Input Class Initialized
INFO - 2016-05-07 10:09:53 --> Language Class Initialized
INFO - 2016-05-07 10:09:53 --> Loader Class Initialized
INFO - 2016-05-07 10:09:53 --> Helper loaded: url_helper
INFO - 2016-05-07 10:09:53 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:09:53 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:09:53 --> Helper loaded: form_helper
INFO - 2016-05-07 10:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:09:53 --> Form Validation Class Initialized
INFO - 2016-05-07 10:09:53 --> Controller Class Initialized
INFO - 2016-05-07 10:09:53 --> Model Class Initialized
INFO - 2016-05-07 10:09:53 --> Database Driver Class Initialized
INFO - 2016-05-07 10:09:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:09:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:09:53 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:09:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:09:53 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:09:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:09:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:09:53 --> Final output sent to browser
DEBUG - 2016-05-07 10:09:53 --> Total execution time: 0.0850
INFO - 2016-05-07 10:10:15 --> Config Class Initialized
INFO - 2016-05-07 10:10:15 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:10:15 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:10:15 --> Utf8 Class Initialized
INFO - 2016-05-07 10:10:15 --> URI Class Initialized
INFO - 2016-05-07 10:10:15 --> Router Class Initialized
INFO - 2016-05-07 10:10:15 --> Output Class Initialized
INFO - 2016-05-07 10:10:15 --> Security Class Initialized
DEBUG - 2016-05-07 10:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:10:15 --> Input Class Initialized
INFO - 2016-05-07 10:10:15 --> Language Class Initialized
INFO - 2016-05-07 10:10:15 --> Loader Class Initialized
INFO - 2016-05-07 10:10:15 --> Helper loaded: url_helper
INFO - 2016-05-07 10:10:15 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:10:15 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:10:15 --> Helper loaded: form_helper
INFO - 2016-05-07 10:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:10:15 --> Form Validation Class Initialized
INFO - 2016-05-07 10:10:15 --> Controller Class Initialized
INFO - 2016-05-07 10:10:15 --> Model Class Initialized
INFO - 2016-05-07 10:10:15 --> Database Driver Class Initialized
INFO - 2016-05-07 10:10:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:10:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:10:15 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:10:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:10:15 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:10:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:10:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:10:16 --> Final output sent to browser
DEBUG - 2016-05-07 10:10:16 --> Total execution time: 0.0823
INFO - 2016-05-07 10:10:31 --> Config Class Initialized
INFO - 2016-05-07 10:10:31 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:10:31 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:10:31 --> Utf8 Class Initialized
INFO - 2016-05-07 10:10:31 --> URI Class Initialized
INFO - 2016-05-07 10:10:31 --> Router Class Initialized
INFO - 2016-05-07 10:10:31 --> Output Class Initialized
INFO - 2016-05-07 10:10:31 --> Security Class Initialized
DEBUG - 2016-05-07 10:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:10:31 --> Input Class Initialized
INFO - 2016-05-07 10:10:31 --> Language Class Initialized
INFO - 2016-05-07 10:10:31 --> Loader Class Initialized
INFO - 2016-05-07 10:10:31 --> Helper loaded: url_helper
INFO - 2016-05-07 10:10:31 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:10:31 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:10:31 --> Helper loaded: form_helper
INFO - 2016-05-07 10:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:10:31 --> Form Validation Class Initialized
INFO - 2016-05-07 10:10:31 --> Controller Class Initialized
INFO - 2016-05-07 10:10:31 --> Model Class Initialized
INFO - 2016-05-07 10:10:31 --> Database Driver Class Initialized
INFO - 2016-05-07 10:10:31 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:10:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:10:31 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:10:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:10:31 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:10:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:10:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:10:31 --> Final output sent to browser
DEBUG - 2016-05-07 10:10:31 --> Total execution time: 0.0830
INFO - 2016-05-07 10:10:41 --> Config Class Initialized
INFO - 2016-05-07 10:10:41 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:10:41 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:10:41 --> Utf8 Class Initialized
INFO - 2016-05-07 10:10:41 --> URI Class Initialized
INFO - 2016-05-07 10:10:41 --> Router Class Initialized
INFO - 2016-05-07 10:10:41 --> Output Class Initialized
INFO - 2016-05-07 10:10:41 --> Security Class Initialized
DEBUG - 2016-05-07 10:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:10:41 --> Input Class Initialized
INFO - 2016-05-07 10:10:41 --> Language Class Initialized
INFO - 2016-05-07 10:10:41 --> Loader Class Initialized
INFO - 2016-05-07 10:10:41 --> Helper loaded: url_helper
INFO - 2016-05-07 10:10:41 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:10:41 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:10:41 --> Helper loaded: form_helper
INFO - 2016-05-07 10:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:10:41 --> Form Validation Class Initialized
INFO - 2016-05-07 10:10:41 --> Controller Class Initialized
INFO - 2016-05-07 10:10:41 --> Model Class Initialized
INFO - 2016-05-07 10:10:41 --> Database Driver Class Initialized
INFO - 2016-05-07 10:10:41 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:10:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:10:41 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:10:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:10:41 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:10:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:10:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:10:41 --> Final output sent to browser
DEBUG - 2016-05-07 10:10:41 --> Total execution time: 0.0820
INFO - 2016-05-07 10:10:49 --> Config Class Initialized
INFO - 2016-05-07 10:10:49 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:10:49 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:10:49 --> Utf8 Class Initialized
INFO - 2016-05-07 10:10:49 --> URI Class Initialized
INFO - 2016-05-07 10:10:49 --> Router Class Initialized
INFO - 2016-05-07 10:10:49 --> Output Class Initialized
INFO - 2016-05-07 10:10:49 --> Security Class Initialized
DEBUG - 2016-05-07 10:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:10:49 --> Input Class Initialized
INFO - 2016-05-07 10:10:49 --> Language Class Initialized
INFO - 2016-05-07 10:10:49 --> Loader Class Initialized
INFO - 2016-05-07 10:10:49 --> Helper loaded: url_helper
INFO - 2016-05-07 10:10:49 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:10:49 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:10:49 --> Helper loaded: form_helper
INFO - 2016-05-07 10:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:10:49 --> Form Validation Class Initialized
INFO - 2016-05-07 10:10:49 --> Controller Class Initialized
INFO - 2016-05-07 10:10:49 --> Model Class Initialized
INFO - 2016-05-07 10:10:49 --> Database Driver Class Initialized
INFO - 2016-05-07 10:10:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:10:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:10:49 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:10:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:10:49 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:10:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:10:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:10:49 --> Final output sent to browser
DEBUG - 2016-05-07 10:10:49 --> Total execution time: 0.0843
INFO - 2016-05-07 10:17:04 --> Config Class Initialized
INFO - 2016-05-07 10:17:04 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:17:04 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:17:04 --> Utf8 Class Initialized
INFO - 2016-05-07 10:17:04 --> URI Class Initialized
INFO - 2016-05-07 10:17:04 --> Router Class Initialized
INFO - 2016-05-07 10:17:04 --> Output Class Initialized
INFO - 2016-05-07 10:17:04 --> Security Class Initialized
DEBUG - 2016-05-07 10:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:17:04 --> Input Class Initialized
INFO - 2016-05-07 10:17:04 --> Language Class Initialized
INFO - 2016-05-07 10:17:04 --> Loader Class Initialized
INFO - 2016-05-07 10:17:04 --> Helper loaded: url_helper
INFO - 2016-05-07 10:17:04 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:17:04 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:17:04 --> Helper loaded: form_helper
INFO - 2016-05-07 10:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:17:04 --> Form Validation Class Initialized
INFO - 2016-05-07 10:17:04 --> Controller Class Initialized
INFO - 2016-05-07 10:17:04 --> Model Class Initialized
INFO - 2016-05-07 10:17:04 --> Database Driver Class Initialized
INFO - 2016-05-07 10:17:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:17:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:17:04 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:17:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:17:04 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:17:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:17:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:17:04 --> Final output sent to browser
DEBUG - 2016-05-07 10:17:04 --> Total execution time: 0.0841
INFO - 2016-05-07 10:18:48 --> Config Class Initialized
INFO - 2016-05-07 10:18:48 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:18:48 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:18:48 --> Utf8 Class Initialized
INFO - 2016-05-07 10:18:48 --> URI Class Initialized
INFO - 2016-05-07 10:18:48 --> Router Class Initialized
INFO - 2016-05-07 10:18:48 --> Output Class Initialized
INFO - 2016-05-07 10:18:48 --> Security Class Initialized
DEBUG - 2016-05-07 10:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:18:48 --> Input Class Initialized
INFO - 2016-05-07 10:18:48 --> Language Class Initialized
INFO - 2016-05-07 10:18:48 --> Loader Class Initialized
INFO - 2016-05-07 10:18:48 --> Helper loaded: url_helper
INFO - 2016-05-07 10:18:48 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:18:48 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:18:48 --> Helper loaded: form_helper
INFO - 2016-05-07 10:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:18:48 --> Form Validation Class Initialized
INFO - 2016-05-07 10:18:48 --> Controller Class Initialized
INFO - 2016-05-07 10:18:48 --> Model Class Initialized
INFO - 2016-05-07 10:18:48 --> Database Driver Class Initialized
INFO - 2016-05-07 10:18:48 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:18:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:18:48 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:18:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:18:48 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:18:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:18:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:18:48 --> Final output sent to browser
DEBUG - 2016-05-07 10:18:48 --> Total execution time: 0.0835
INFO - 2016-05-07 10:19:09 --> Config Class Initialized
INFO - 2016-05-07 10:19:09 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:19:09 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:19:09 --> Utf8 Class Initialized
INFO - 2016-05-07 10:19:09 --> URI Class Initialized
INFO - 2016-05-07 10:19:09 --> Router Class Initialized
INFO - 2016-05-07 10:19:09 --> Output Class Initialized
INFO - 2016-05-07 10:19:09 --> Security Class Initialized
DEBUG - 2016-05-07 10:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:19:09 --> Input Class Initialized
INFO - 2016-05-07 10:19:09 --> Language Class Initialized
INFO - 2016-05-07 10:19:09 --> Loader Class Initialized
INFO - 2016-05-07 10:19:09 --> Helper loaded: url_helper
INFO - 2016-05-07 10:19:09 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:19:09 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:19:09 --> Helper loaded: form_helper
INFO - 2016-05-07 10:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:19:09 --> Form Validation Class Initialized
INFO - 2016-05-07 10:19:09 --> Controller Class Initialized
INFO - 2016-05-07 10:19:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-07 10:19:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 10:19:09 --> Final output sent to browser
DEBUG - 2016-05-07 10:19:09 --> Total execution time: 0.0495
INFO - 2016-05-07 10:19:11 --> Config Class Initialized
INFO - 2016-05-07 10:19:11 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:19:11 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:19:11 --> Utf8 Class Initialized
INFO - 2016-05-07 10:19:11 --> URI Class Initialized
INFO - 2016-05-07 10:19:11 --> Router Class Initialized
INFO - 2016-05-07 10:19:11 --> Output Class Initialized
INFO - 2016-05-07 10:19:11 --> Security Class Initialized
DEBUG - 2016-05-07 10:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:19:11 --> Input Class Initialized
INFO - 2016-05-07 10:19:11 --> Language Class Initialized
INFO - 2016-05-07 10:19:11 --> Loader Class Initialized
INFO - 2016-05-07 10:19:11 --> Helper loaded: url_helper
INFO - 2016-05-07 10:19:11 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:19:11 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:19:11 --> Helper loaded: form_helper
INFO - 2016-05-07 10:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:19:11 --> Form Validation Class Initialized
INFO - 2016-05-07 10:19:11 --> Controller Class Initialized
INFO - 2016-05-07 10:19:11 --> Config Class Initialized
INFO - 2016-05-07 10:19:11 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:19:11 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:19:11 --> Utf8 Class Initialized
INFO - 2016-05-07 10:19:11 --> URI Class Initialized
INFO - 2016-05-07 10:19:11 --> Router Class Initialized
INFO - 2016-05-07 10:19:11 --> Output Class Initialized
INFO - 2016-05-07 10:19:11 --> Security Class Initialized
DEBUG - 2016-05-07 10:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:19:11 --> Input Class Initialized
INFO - 2016-05-07 10:19:11 --> Language Class Initialized
INFO - 2016-05-07 10:19:11 --> Loader Class Initialized
INFO - 2016-05-07 10:19:11 --> Helper loaded: url_helper
INFO - 2016-05-07 10:19:11 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:19:11 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:19:11 --> Helper loaded: form_helper
INFO - 2016-05-07 10:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:19:11 --> Form Validation Class Initialized
INFO - 2016-05-07 10:19:11 --> Controller Class Initialized
INFO - 2016-05-07 10:19:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-07 10:19:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:19:11 --> Final output sent to browser
DEBUG - 2016-05-07 10:19:11 --> Total execution time: 0.0559
INFO - 2016-05-07 10:19:15 --> Config Class Initialized
INFO - 2016-05-07 10:19:15 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:19:15 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:19:15 --> Utf8 Class Initialized
INFO - 2016-05-07 10:19:15 --> URI Class Initialized
INFO - 2016-05-07 10:19:15 --> Router Class Initialized
INFO - 2016-05-07 10:19:15 --> Output Class Initialized
INFO - 2016-05-07 10:19:15 --> Security Class Initialized
DEBUG - 2016-05-07 10:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:19:15 --> Input Class Initialized
INFO - 2016-05-07 10:19:15 --> Language Class Initialized
INFO - 2016-05-07 10:19:15 --> Loader Class Initialized
INFO - 2016-05-07 10:19:15 --> Helper loaded: url_helper
INFO - 2016-05-07 10:19:15 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:19:15 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:19:15 --> Helper loaded: form_helper
INFO - 2016-05-07 10:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:19:15 --> Form Validation Class Initialized
INFO - 2016-05-07 10:19:15 --> Controller Class Initialized
INFO - 2016-05-07 10:19:15 --> Model Class Initialized
INFO - 2016-05-07 10:19:15 --> Database Driver Class Initialized
INFO - 2016-05-07 10:19:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:19:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:19:15 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:19:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:19:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 10:19:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:19:15 --> Final output sent to browser
DEBUG - 2016-05-07 10:19:15 --> Total execution time: 0.1154
INFO - 2016-05-07 10:19:18 --> Config Class Initialized
INFO - 2016-05-07 10:19:18 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:19:18 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:19:18 --> Utf8 Class Initialized
INFO - 2016-05-07 10:19:18 --> URI Class Initialized
INFO - 2016-05-07 10:19:18 --> Router Class Initialized
INFO - 2016-05-07 10:19:18 --> Output Class Initialized
INFO - 2016-05-07 10:19:18 --> Security Class Initialized
DEBUG - 2016-05-07 10:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:19:18 --> Input Class Initialized
INFO - 2016-05-07 10:19:18 --> Language Class Initialized
INFO - 2016-05-07 10:19:18 --> Loader Class Initialized
INFO - 2016-05-07 10:19:18 --> Helper loaded: url_helper
INFO - 2016-05-07 10:19:18 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:19:18 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:19:18 --> Helper loaded: form_helper
INFO - 2016-05-07 10:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:19:18 --> Form Validation Class Initialized
INFO - 2016-05-07 10:19:18 --> Controller Class Initialized
INFO - 2016-05-07 10:19:18 --> Model Class Initialized
INFO - 2016-05-07 10:19:18 --> Database Driver Class Initialized
INFO - 2016-05-07 10:19:18 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:19:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:19:18 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:19:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:19:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 10:19:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:19:18 --> Final output sent to browser
DEBUG - 2016-05-07 10:19:18 --> Total execution time: 0.1157
INFO - 2016-05-07 10:19:21 --> Config Class Initialized
INFO - 2016-05-07 10:19:21 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:19:21 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:19:21 --> Utf8 Class Initialized
INFO - 2016-05-07 10:19:21 --> URI Class Initialized
INFO - 2016-05-07 10:19:21 --> Router Class Initialized
INFO - 2016-05-07 10:19:21 --> Output Class Initialized
INFO - 2016-05-07 10:19:21 --> Security Class Initialized
DEBUG - 2016-05-07 10:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:19:21 --> Input Class Initialized
INFO - 2016-05-07 10:19:21 --> Language Class Initialized
INFO - 2016-05-07 10:19:21 --> Loader Class Initialized
INFO - 2016-05-07 10:19:21 --> Helper loaded: url_helper
INFO - 2016-05-07 10:19:21 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:19:21 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:19:21 --> Helper loaded: form_helper
INFO - 2016-05-07 10:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:19:21 --> Form Validation Class Initialized
INFO - 2016-05-07 10:19:21 --> Controller Class Initialized
INFO - 2016-05-07 10:19:21 --> Model Class Initialized
INFO - 2016-05-07 10:19:21 --> Database Driver Class Initialized
INFO - 2016-05-07 10:19:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:19:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:19:21 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:19:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:19:21 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:19:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:19:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:19:21 --> Final output sent to browser
DEBUG - 2016-05-07 10:19:21 --> Total execution time: 0.1402
INFO - 2016-05-07 10:20:08 --> Config Class Initialized
INFO - 2016-05-07 10:20:08 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:20:08 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:20:08 --> Utf8 Class Initialized
INFO - 2016-05-07 10:20:08 --> URI Class Initialized
INFO - 2016-05-07 10:20:08 --> Router Class Initialized
INFO - 2016-05-07 10:20:08 --> Output Class Initialized
INFO - 2016-05-07 10:20:08 --> Security Class Initialized
DEBUG - 2016-05-07 10:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:20:08 --> Input Class Initialized
INFO - 2016-05-07 10:20:08 --> Language Class Initialized
INFO - 2016-05-07 10:20:08 --> Loader Class Initialized
INFO - 2016-05-07 10:20:08 --> Helper loaded: url_helper
INFO - 2016-05-07 10:20:08 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:20:08 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:20:08 --> Helper loaded: form_helper
INFO - 2016-05-07 10:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:20:08 --> Form Validation Class Initialized
INFO - 2016-05-07 10:20:08 --> Controller Class Initialized
INFO - 2016-05-07 10:20:08 --> Model Class Initialized
INFO - 2016-05-07 10:20:08 --> Database Driver Class Initialized
INFO - 2016-05-07 10:20:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:20:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:20:08 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:20:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:20:08 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:20:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:20:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:20:08 --> Final output sent to browser
DEBUG - 2016-05-07 10:20:08 --> Total execution time: 0.1339
INFO - 2016-05-07 10:20:17 --> Config Class Initialized
INFO - 2016-05-07 10:20:17 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:20:17 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:20:17 --> Utf8 Class Initialized
INFO - 2016-05-07 10:20:17 --> URI Class Initialized
INFO - 2016-05-07 10:20:17 --> Router Class Initialized
INFO - 2016-05-07 10:20:17 --> Output Class Initialized
INFO - 2016-05-07 10:20:17 --> Security Class Initialized
DEBUG - 2016-05-07 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:20:17 --> Input Class Initialized
INFO - 2016-05-07 10:20:17 --> Language Class Initialized
INFO - 2016-05-07 10:20:17 --> Loader Class Initialized
INFO - 2016-05-07 10:20:17 --> Helper loaded: url_helper
INFO - 2016-05-07 10:20:17 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:20:17 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:20:17 --> Helper loaded: form_helper
INFO - 2016-05-07 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:20:17 --> Form Validation Class Initialized
INFO - 2016-05-07 10:20:17 --> Controller Class Initialized
INFO - 2016-05-07 10:20:17 --> Model Class Initialized
INFO - 2016-05-07 10:20:17 --> Database Driver Class Initialized
INFO - 2016-05-07 10:20:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:20:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:20:17 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:20:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:20:17 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:20:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_ModImagenProducto.php
INFO - 2016-05-07 10:20:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:20:17 --> Final output sent to browser
DEBUG - 2016-05-07 10:20:17 --> Total execution time: 0.2469
INFO - 2016-05-07 10:21:19 --> Config Class Initialized
INFO - 2016-05-07 10:21:19 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:21:19 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:21:19 --> Utf8 Class Initialized
INFO - 2016-05-07 10:21:19 --> URI Class Initialized
INFO - 2016-05-07 10:21:19 --> Router Class Initialized
INFO - 2016-05-07 10:21:19 --> Output Class Initialized
INFO - 2016-05-07 10:21:19 --> Security Class Initialized
DEBUG - 2016-05-07 10:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:21:19 --> Input Class Initialized
INFO - 2016-05-07 10:21:19 --> Language Class Initialized
INFO - 2016-05-07 10:21:19 --> Loader Class Initialized
INFO - 2016-05-07 10:21:19 --> Helper loaded: url_helper
INFO - 2016-05-07 10:21:19 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:21:19 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:21:19 --> Helper loaded: form_helper
INFO - 2016-05-07 10:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:21:19 --> Form Validation Class Initialized
INFO - 2016-05-07 10:21:19 --> Controller Class Initialized
INFO - 2016-05-07 10:21:19 --> Model Class Initialized
INFO - 2016-05-07 10:21:19 --> Database Driver Class Initialized
INFO - 2016-05-07 10:21:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:21:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:21:19 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:21:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:21:19 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:21:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 10:21:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:21:19 --> Final output sent to browser
DEBUG - 2016-05-07 10:21:19 --> Total execution time: 0.0801
INFO - 2016-05-07 10:21:33 --> Config Class Initialized
INFO - 2016-05-07 10:21:33 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:21:33 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:21:33 --> Utf8 Class Initialized
INFO - 2016-05-07 10:21:33 --> URI Class Initialized
INFO - 2016-05-07 10:21:33 --> Router Class Initialized
INFO - 2016-05-07 10:21:33 --> Output Class Initialized
INFO - 2016-05-07 10:21:33 --> Security Class Initialized
DEBUG - 2016-05-07 10:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:21:33 --> Input Class Initialized
INFO - 2016-05-07 10:21:33 --> Language Class Initialized
INFO - 2016-05-07 10:21:33 --> Loader Class Initialized
INFO - 2016-05-07 10:21:33 --> Helper loaded: url_helper
INFO - 2016-05-07 10:21:33 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:21:33 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:21:33 --> Helper loaded: form_helper
INFO - 2016-05-07 10:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:21:33 --> Form Validation Class Initialized
INFO - 2016-05-07 10:21:33 --> Controller Class Initialized
INFO - 2016-05-07 10:21:33 --> Model Class Initialized
INFO - 2016-05-07 10:21:33 --> Database Driver Class Initialized
INFO - 2016-05-07 10:21:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:21:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:21:33 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:21:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:21:33 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:21:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 10:21:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:21:33 --> Final output sent to browser
DEBUG - 2016-05-07 10:21:33 --> Total execution time: 0.1408
INFO - 2016-05-07 10:22:59 --> Config Class Initialized
INFO - 2016-05-07 10:22:59 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:22:59 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:22:59 --> Utf8 Class Initialized
INFO - 2016-05-07 10:22:59 --> URI Class Initialized
INFO - 2016-05-07 10:22:59 --> Router Class Initialized
INFO - 2016-05-07 10:22:59 --> Output Class Initialized
INFO - 2016-05-07 10:22:59 --> Security Class Initialized
DEBUG - 2016-05-07 10:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:22:59 --> Input Class Initialized
INFO - 2016-05-07 10:22:59 --> Language Class Initialized
INFO - 2016-05-07 10:22:59 --> Loader Class Initialized
INFO - 2016-05-07 10:22:59 --> Helper loaded: url_helper
INFO - 2016-05-07 10:22:59 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:22:59 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:22:59 --> Helper loaded: form_helper
INFO - 2016-05-07 10:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:22:59 --> Form Validation Class Initialized
INFO - 2016-05-07 10:22:59 --> Controller Class Initialized
INFO - 2016-05-07 10:22:59 --> Model Class Initialized
INFO - 2016-05-07 10:22:59 --> Database Driver Class Initialized
INFO - 2016-05-07 10:22:59 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:22:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:22:59 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:22:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:22:59 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:22:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 10:22:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:22:59 --> Final output sent to browser
DEBUG - 2016-05-07 10:22:59 --> Total execution time: 0.2328
INFO - 2016-05-07 10:23:04 --> Config Class Initialized
INFO - 2016-05-07 10:23:04 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:23:04 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:23:04 --> Utf8 Class Initialized
INFO - 2016-05-07 10:23:04 --> URI Class Initialized
INFO - 2016-05-07 10:23:04 --> Router Class Initialized
INFO - 2016-05-07 10:23:04 --> Output Class Initialized
INFO - 2016-05-07 10:23:04 --> Security Class Initialized
DEBUG - 2016-05-07 10:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:23:04 --> Input Class Initialized
INFO - 2016-05-07 10:23:04 --> Language Class Initialized
INFO - 2016-05-07 10:23:04 --> Loader Class Initialized
INFO - 2016-05-07 10:23:04 --> Helper loaded: url_helper
INFO - 2016-05-07 10:23:04 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:23:04 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:23:04 --> Helper loaded: form_helper
INFO - 2016-05-07 10:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:23:04 --> Form Validation Class Initialized
INFO - 2016-05-07 10:23:04 --> Controller Class Initialized
INFO - 2016-05-07 10:23:04 --> Model Class Initialized
INFO - 2016-05-07 10:23:04 --> Database Driver Class Initialized
INFO - 2016-05-07 10:23:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:23:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:23:04 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:23:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:23:04 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:23:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 10:23:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:23:04 --> Final output sent to browser
DEBUG - 2016-05-07 10:23:04 --> Total execution time: 0.1422
INFO - 2016-05-07 10:23:20 --> Config Class Initialized
INFO - 2016-05-07 10:23:20 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:23:20 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:23:20 --> Utf8 Class Initialized
INFO - 2016-05-07 10:23:20 --> URI Class Initialized
INFO - 2016-05-07 10:23:20 --> Router Class Initialized
INFO - 2016-05-07 10:23:20 --> Output Class Initialized
INFO - 2016-05-07 10:23:20 --> Security Class Initialized
DEBUG - 2016-05-07 10:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:23:20 --> Input Class Initialized
INFO - 2016-05-07 10:23:20 --> Language Class Initialized
INFO - 2016-05-07 10:23:20 --> Loader Class Initialized
INFO - 2016-05-07 10:23:20 --> Helper loaded: url_helper
INFO - 2016-05-07 10:23:20 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:23:20 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:23:20 --> Helper loaded: form_helper
INFO - 2016-05-07 10:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:23:20 --> Form Validation Class Initialized
INFO - 2016-05-07 10:23:20 --> Controller Class Initialized
INFO - 2016-05-07 10:23:20 --> Model Class Initialized
INFO - 2016-05-07 10:23:20 --> Database Driver Class Initialized
INFO - 2016-05-07 10:23:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:23:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:23:20 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:23:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:23:20 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:23:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 10:23:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:23:20 --> Final output sent to browser
DEBUG - 2016-05-07 10:23:20 --> Total execution time: 0.1423
INFO - 2016-05-07 10:23:38 --> Config Class Initialized
INFO - 2016-05-07 10:23:38 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:23:38 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:23:38 --> Utf8 Class Initialized
INFO - 2016-05-07 10:23:38 --> URI Class Initialized
INFO - 2016-05-07 10:23:38 --> Router Class Initialized
INFO - 2016-05-07 10:23:38 --> Output Class Initialized
INFO - 2016-05-07 10:23:38 --> Security Class Initialized
DEBUG - 2016-05-07 10:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:23:38 --> Input Class Initialized
INFO - 2016-05-07 10:23:38 --> Language Class Initialized
INFO - 2016-05-07 10:23:38 --> Loader Class Initialized
INFO - 2016-05-07 10:23:38 --> Helper loaded: url_helper
INFO - 2016-05-07 10:23:38 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:23:38 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:23:38 --> Helper loaded: form_helper
INFO - 2016-05-07 10:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:23:38 --> Form Validation Class Initialized
INFO - 2016-05-07 10:23:38 --> Controller Class Initialized
INFO - 2016-05-07 10:23:38 --> Model Class Initialized
INFO - 2016-05-07 10:23:38 --> Database Driver Class Initialized
INFO - 2016-05-07 10:23:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:23:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:23:38 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:23:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:23:38 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:23:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 10:23:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:23:38 --> Final output sent to browser
DEBUG - 2016-05-07 10:23:38 --> Total execution time: 0.0835
INFO - 2016-05-07 10:24:05 --> Config Class Initialized
INFO - 2016-05-07 10:24:05 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:24:05 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:24:05 --> Utf8 Class Initialized
INFO - 2016-05-07 10:24:05 --> URI Class Initialized
INFO - 2016-05-07 10:24:05 --> Router Class Initialized
INFO - 2016-05-07 10:24:05 --> Output Class Initialized
INFO - 2016-05-07 10:24:05 --> Security Class Initialized
DEBUG - 2016-05-07 10:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:24:05 --> Input Class Initialized
INFO - 2016-05-07 10:24:05 --> Language Class Initialized
INFO - 2016-05-07 10:24:05 --> Loader Class Initialized
INFO - 2016-05-07 10:24:05 --> Helper loaded: url_helper
INFO - 2016-05-07 10:24:05 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:24:05 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:24:05 --> Helper loaded: form_helper
INFO - 2016-05-07 10:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:24:05 --> Form Validation Class Initialized
INFO - 2016-05-07 10:24:05 --> Controller Class Initialized
INFO - 2016-05-07 10:24:05 --> Model Class Initialized
INFO - 2016-05-07 10:24:05 --> Database Driver Class Initialized
INFO - 2016-05-07 10:24:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:24:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:24:05 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:24:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:24:05 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:24:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 10:24:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:24:05 --> Final output sent to browser
DEBUG - 2016-05-07 10:24:05 --> Total execution time: 0.0931
INFO - 2016-05-07 10:24:47 --> Config Class Initialized
INFO - 2016-05-07 10:24:47 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:24:47 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:24:47 --> Utf8 Class Initialized
INFO - 2016-05-07 10:24:47 --> URI Class Initialized
INFO - 2016-05-07 10:24:47 --> Router Class Initialized
INFO - 2016-05-07 10:24:47 --> Output Class Initialized
INFO - 2016-05-07 10:24:47 --> Security Class Initialized
DEBUG - 2016-05-07 10:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:24:47 --> Input Class Initialized
INFO - 2016-05-07 10:24:47 --> Language Class Initialized
INFO - 2016-05-07 10:24:47 --> Loader Class Initialized
INFO - 2016-05-07 10:24:47 --> Helper loaded: url_helper
INFO - 2016-05-07 10:24:47 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:24:47 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:24:47 --> Helper loaded: form_helper
INFO - 2016-05-07 10:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:24:47 --> Form Validation Class Initialized
INFO - 2016-05-07 10:24:47 --> Controller Class Initialized
INFO - 2016-05-07 10:24:47 --> Model Class Initialized
INFO - 2016-05-07 10:24:47 --> Database Driver Class Initialized
INFO - 2016-05-07 10:24:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:24:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:24:47 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:24:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:24:47 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:24:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 10:24:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:24:47 --> Final output sent to browser
DEBUG - 2016-05-07 10:24:47 --> Total execution time: 0.1020
INFO - 2016-05-07 10:25:33 --> Config Class Initialized
INFO - 2016-05-07 10:25:33 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:25:33 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:25:33 --> Utf8 Class Initialized
INFO - 2016-05-07 10:25:33 --> URI Class Initialized
INFO - 2016-05-07 10:25:33 --> Router Class Initialized
INFO - 2016-05-07 10:25:33 --> Output Class Initialized
INFO - 2016-05-07 10:25:33 --> Security Class Initialized
DEBUG - 2016-05-07 10:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:25:33 --> Input Class Initialized
INFO - 2016-05-07 10:25:33 --> Language Class Initialized
INFO - 2016-05-07 10:25:33 --> Loader Class Initialized
INFO - 2016-05-07 10:25:33 --> Helper loaded: url_helper
INFO - 2016-05-07 10:25:33 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:25:33 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:25:33 --> Helper loaded: form_helper
INFO - 2016-05-07 10:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:25:33 --> Form Validation Class Initialized
INFO - 2016-05-07 10:25:33 --> Controller Class Initialized
INFO - 2016-05-07 10:25:33 --> Model Class Initialized
INFO - 2016-05-07 10:25:33 --> Database Driver Class Initialized
INFO - 2016-05-07 10:25:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:25:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:25:33 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:25:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:25:33 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:25:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 10:25:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:25:33 --> Final output sent to browser
DEBUG - 2016-05-07 10:25:33 --> Total execution time: 0.1558
INFO - 2016-05-07 10:25:49 --> Config Class Initialized
INFO - 2016-05-07 10:25:49 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:25:49 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:25:49 --> Utf8 Class Initialized
INFO - 2016-05-07 10:25:49 --> URI Class Initialized
INFO - 2016-05-07 10:25:49 --> Router Class Initialized
INFO - 2016-05-07 10:25:49 --> Output Class Initialized
INFO - 2016-05-07 10:25:49 --> Security Class Initialized
DEBUG - 2016-05-07 10:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:25:49 --> Input Class Initialized
INFO - 2016-05-07 10:25:49 --> Language Class Initialized
INFO - 2016-05-07 10:25:49 --> Loader Class Initialized
INFO - 2016-05-07 10:25:49 --> Helper loaded: url_helper
INFO - 2016-05-07 10:25:49 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:25:49 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:25:49 --> Helper loaded: form_helper
INFO - 2016-05-07 10:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:25:49 --> Form Validation Class Initialized
INFO - 2016-05-07 10:25:49 --> Controller Class Initialized
INFO - 2016-05-07 10:25:49 --> Model Class Initialized
INFO - 2016-05-07 10:25:49 --> Database Driver Class Initialized
INFO - 2016-05-07 10:25:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:25:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:25:49 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:25:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:25:49 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:25:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 10:25:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:25:49 --> Final output sent to browser
DEBUG - 2016-05-07 10:25:49 --> Total execution time: 0.1680
INFO - 2016-05-07 10:26:04 --> Config Class Initialized
INFO - 2016-05-07 10:26:04 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:26:04 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:26:04 --> Utf8 Class Initialized
INFO - 2016-05-07 10:26:04 --> URI Class Initialized
INFO - 2016-05-07 10:26:05 --> Router Class Initialized
INFO - 2016-05-07 10:26:05 --> Output Class Initialized
INFO - 2016-05-07 10:26:05 --> Security Class Initialized
DEBUG - 2016-05-07 10:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:26:05 --> Input Class Initialized
INFO - 2016-05-07 10:26:05 --> Language Class Initialized
INFO - 2016-05-07 10:26:05 --> Loader Class Initialized
INFO - 2016-05-07 10:26:05 --> Helper loaded: url_helper
INFO - 2016-05-07 10:26:05 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:26:05 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:26:05 --> Helper loaded: form_helper
INFO - 2016-05-07 10:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:26:05 --> Form Validation Class Initialized
INFO - 2016-05-07 10:26:05 --> Controller Class Initialized
INFO - 2016-05-07 10:26:05 --> Model Class Initialized
INFO - 2016-05-07 10:26:05 --> Database Driver Class Initialized
INFO - 2016-05-07 10:26:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:26:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:26:05 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:26:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:26:05 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:26:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 10:26:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:26:05 --> Final output sent to browser
DEBUG - 2016-05-07 10:26:05 --> Total execution time: 0.1178
INFO - 2016-05-07 10:29:36 --> Config Class Initialized
INFO - 2016-05-07 10:29:36 --> Hooks Class Initialized
DEBUG - 2016-05-07 10:29:36 --> UTF-8 Support Enabled
INFO - 2016-05-07 10:29:36 --> Utf8 Class Initialized
INFO - 2016-05-07 10:29:36 --> URI Class Initialized
INFO - 2016-05-07 10:29:36 --> Router Class Initialized
INFO - 2016-05-07 10:29:36 --> Output Class Initialized
INFO - 2016-05-07 10:29:36 --> Security Class Initialized
DEBUG - 2016-05-07 10:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 10:29:36 --> Input Class Initialized
INFO - 2016-05-07 10:29:36 --> Language Class Initialized
INFO - 2016-05-07 10:29:36 --> Loader Class Initialized
INFO - 2016-05-07 10:29:36 --> Helper loaded: url_helper
INFO - 2016-05-07 10:29:36 --> Helper loaded: sesion_helper
INFO - 2016-05-07 10:29:36 --> Helper loaded: templates_helper
INFO - 2016-05-07 10:29:36 --> Helper loaded: form_helper
INFO - 2016-05-07 10:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 10:29:36 --> Form Validation Class Initialized
INFO - 2016-05-07 10:29:36 --> Controller Class Initialized
INFO - 2016-05-07 10:29:36 --> Model Class Initialized
INFO - 2016-05-07 10:29:36 --> Database Driver Class Initialized
INFO - 2016-05-07 10:29:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 10:29:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 10:29:36 --> Pagination Class Initialized
DEBUG - 2016-05-07 10:29:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 10:29:36 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 10:29:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 10:29:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 10:29:36 --> Final output sent to browser
DEBUG - 2016-05-07 10:29:36 --> Total execution time: 0.1339
INFO - 2016-05-07 16:39:20 --> Config Class Initialized
INFO - 2016-05-07 16:39:21 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:39:21 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:39:21 --> Utf8 Class Initialized
INFO - 2016-05-07 16:39:21 --> URI Class Initialized
INFO - 2016-05-07 16:39:21 --> Router Class Initialized
INFO - 2016-05-07 16:39:21 --> Output Class Initialized
INFO - 2016-05-07 16:39:21 --> Security Class Initialized
DEBUG - 2016-05-07 16:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:39:21 --> Input Class Initialized
INFO - 2016-05-07 16:39:21 --> Language Class Initialized
INFO - 2016-05-07 16:39:21 --> Loader Class Initialized
INFO - 2016-05-07 16:39:21 --> Helper loaded: url_helper
INFO - 2016-05-07 16:39:21 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:39:21 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:39:21 --> Helper loaded: form_helper
INFO - 2016-05-07 16:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:39:21 --> Form Validation Class Initialized
INFO - 2016-05-07 16:39:21 --> Controller Class Initialized
INFO - 2016-05-07 16:39:21 --> Config Class Initialized
INFO - 2016-05-07 16:39:21 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:39:21 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:39:21 --> Utf8 Class Initialized
INFO - 2016-05-07 16:39:21 --> URI Class Initialized
INFO - 2016-05-07 16:39:21 --> Router Class Initialized
INFO - 2016-05-07 16:39:21 --> Output Class Initialized
INFO - 2016-05-07 16:39:21 --> Security Class Initialized
DEBUG - 2016-05-07 16:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:39:21 --> Input Class Initialized
INFO - 2016-05-07 16:39:21 --> Language Class Initialized
INFO - 2016-05-07 16:39:21 --> Loader Class Initialized
INFO - 2016-05-07 16:39:21 --> Helper loaded: url_helper
INFO - 2016-05-07 16:39:21 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:39:21 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:39:21 --> Helper loaded: form_helper
INFO - 2016-05-07 16:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:39:21 --> Form Validation Class Initialized
INFO - 2016-05-07 16:39:21 --> Controller Class Initialized
INFO - 2016-05-07 16:39:21 --> Model Class Initialized
INFO - 2016-05-07 16:39:21 --> Database Driver Class Initialized
INFO - 2016-05-07 16:39:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-07 16:39:22 --> Final output sent to browser
DEBUG - 2016-05-07 16:39:22 --> Total execution time: 0.3632
INFO - 2016-05-07 16:41:44 --> Config Class Initialized
INFO - 2016-05-07 16:41:44 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:41:44 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:41:44 --> Utf8 Class Initialized
INFO - 2016-05-07 16:41:44 --> URI Class Initialized
INFO - 2016-05-07 16:41:44 --> Router Class Initialized
INFO - 2016-05-07 16:41:44 --> Output Class Initialized
INFO - 2016-05-07 16:41:44 --> Security Class Initialized
DEBUG - 2016-05-07 16:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:41:44 --> Input Class Initialized
INFO - 2016-05-07 16:41:44 --> Language Class Initialized
INFO - 2016-05-07 16:41:44 --> Loader Class Initialized
INFO - 2016-05-07 16:41:44 --> Helper loaded: url_helper
INFO - 2016-05-07 16:41:44 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:41:44 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:41:44 --> Helper loaded: form_helper
INFO - 2016-05-07 16:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:41:44 --> Form Validation Class Initialized
INFO - 2016-05-07 16:41:44 --> Controller Class Initialized
INFO - 2016-05-07 16:41:44 --> Model Class Initialized
INFO - 2016-05-07 16:41:44 --> Database Driver Class Initialized
INFO - 2016-05-07 16:41:44 --> Config Class Initialized
INFO - 2016-05-07 16:41:44 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:41:44 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:41:44 --> Utf8 Class Initialized
INFO - 2016-05-07 16:41:44 --> URI Class Initialized
INFO - 2016-05-07 16:41:44 --> Router Class Initialized
INFO - 2016-05-07 16:41:44 --> Output Class Initialized
INFO - 2016-05-07 16:41:44 --> Security Class Initialized
DEBUG - 2016-05-07 16:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:41:44 --> Input Class Initialized
INFO - 2016-05-07 16:41:44 --> Language Class Initialized
INFO - 2016-05-07 16:41:44 --> Loader Class Initialized
INFO - 2016-05-07 16:41:44 --> Helper loaded: url_helper
INFO - 2016-05-07 16:41:44 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:41:44 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:41:44 --> Helper loaded: form_helper
INFO - 2016-05-07 16:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:41:44 --> Form Validation Class Initialized
INFO - 2016-05-07 16:41:44 --> Controller Class Initialized
INFO - 2016-05-07 16:41:44 --> Model Class Initialized
INFO - 2016-05-07 16:41:44 --> Database Driver Class Initialized
INFO - 2016-05-07 16:41:44 --> Config Class Initialized
INFO - 2016-05-07 16:41:44 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:41:44 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:41:44 --> Utf8 Class Initialized
INFO - 2016-05-07 16:41:44 --> URI Class Initialized
INFO - 2016-05-07 16:41:44 --> Router Class Initialized
INFO - 2016-05-07 16:41:44 --> Output Class Initialized
INFO - 2016-05-07 16:41:44 --> Security Class Initialized
DEBUG - 2016-05-07 16:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:41:44 --> Input Class Initialized
INFO - 2016-05-07 16:41:44 --> Language Class Initialized
INFO - 2016-05-07 16:41:44 --> Loader Class Initialized
INFO - 2016-05-07 16:41:44 --> Helper loaded: url_helper
INFO - 2016-05-07 16:41:44 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:41:44 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:41:44 --> Helper loaded: form_helper
INFO - 2016-05-07 16:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:41:44 --> Form Validation Class Initialized
INFO - 2016-05-07 16:41:44 --> Controller Class Initialized
INFO - 2016-05-07 16:41:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-07 16:41:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:41:44 --> Final output sent to browser
DEBUG - 2016-05-07 16:41:44 --> Total execution time: 0.0540
INFO - 2016-05-07 16:41:51 --> Config Class Initialized
INFO - 2016-05-07 16:41:51 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:41:51 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:41:51 --> Utf8 Class Initialized
INFO - 2016-05-07 16:41:51 --> URI Class Initialized
INFO - 2016-05-07 16:41:51 --> Router Class Initialized
INFO - 2016-05-07 16:41:51 --> Output Class Initialized
INFO - 2016-05-07 16:41:51 --> Security Class Initialized
DEBUG - 2016-05-07 16:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:41:51 --> Input Class Initialized
INFO - 2016-05-07 16:41:51 --> Language Class Initialized
INFO - 2016-05-07 16:41:52 --> Loader Class Initialized
INFO - 2016-05-07 16:41:52 --> Helper loaded: url_helper
INFO - 2016-05-07 16:41:52 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:41:52 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:41:52 --> Helper loaded: form_helper
INFO - 2016-05-07 16:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:41:52 --> Form Validation Class Initialized
INFO - 2016-05-07 16:41:52 --> Controller Class Initialized
INFO - 2016-05-07 16:41:52 --> Model Class Initialized
INFO - 2016-05-07 16:41:52 --> Database Driver Class Initialized
INFO - 2016-05-07 16:41:52 --> Config Class Initialized
INFO - 2016-05-07 16:41:52 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:41:52 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:41:52 --> Utf8 Class Initialized
INFO - 2016-05-07 16:41:52 --> URI Class Initialized
INFO - 2016-05-07 16:41:52 --> Router Class Initialized
INFO - 2016-05-07 16:41:52 --> Output Class Initialized
INFO - 2016-05-07 16:41:52 --> Security Class Initialized
DEBUG - 2016-05-07 16:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:41:52 --> Input Class Initialized
INFO - 2016-05-07 16:41:52 --> Language Class Initialized
INFO - 2016-05-07 16:41:52 --> Loader Class Initialized
INFO - 2016-05-07 16:41:52 --> Helper loaded: url_helper
INFO - 2016-05-07 16:41:52 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:41:52 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:41:52 --> Helper loaded: form_helper
INFO - 2016-05-07 16:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:41:52 --> Form Validation Class Initialized
INFO - 2016-05-07 16:41:52 --> Controller Class Initialized
INFO - 2016-05-07 16:41:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-07 16:41:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:41:52 --> Final output sent to browser
DEBUG - 2016-05-07 16:41:52 --> Total execution time: 0.0611
INFO - 2016-05-07 16:41:55 --> Config Class Initialized
INFO - 2016-05-07 16:41:55 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:41:55 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:41:55 --> Utf8 Class Initialized
INFO - 2016-05-07 16:41:55 --> URI Class Initialized
INFO - 2016-05-07 16:41:55 --> Router Class Initialized
INFO - 2016-05-07 16:41:55 --> Output Class Initialized
INFO - 2016-05-07 16:41:55 --> Security Class Initialized
DEBUG - 2016-05-07 16:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:41:55 --> Input Class Initialized
INFO - 2016-05-07 16:41:55 --> Language Class Initialized
INFO - 2016-05-07 16:41:55 --> Loader Class Initialized
INFO - 2016-05-07 16:41:55 --> Helper loaded: url_helper
INFO - 2016-05-07 16:41:55 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:41:55 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:41:55 --> Helper loaded: form_helper
INFO - 2016-05-07 16:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:41:55 --> Form Validation Class Initialized
INFO - 2016-05-07 16:41:55 --> Controller Class Initialized
INFO - 2016-05-07 16:41:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-07 16:41:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:41:55 --> Final output sent to browser
DEBUG - 2016-05-07 16:41:55 --> Total execution time: 0.0815
INFO - 2016-05-07 16:41:56 --> Config Class Initialized
INFO - 2016-05-07 16:41:56 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:41:56 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:41:56 --> Utf8 Class Initialized
INFO - 2016-05-07 16:41:56 --> URI Class Initialized
INFO - 2016-05-07 16:41:56 --> Router Class Initialized
INFO - 2016-05-07 16:41:56 --> Output Class Initialized
INFO - 2016-05-07 16:41:56 --> Security Class Initialized
DEBUG - 2016-05-07 16:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:41:57 --> Input Class Initialized
INFO - 2016-05-07 16:41:57 --> Language Class Initialized
INFO - 2016-05-07 16:41:57 --> Loader Class Initialized
INFO - 2016-05-07 16:41:57 --> Helper loaded: url_helper
INFO - 2016-05-07 16:41:57 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:41:57 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:41:57 --> Helper loaded: form_helper
INFO - 2016-05-07 16:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:41:57 --> Form Validation Class Initialized
INFO - 2016-05-07 16:41:57 --> Controller Class Initialized
INFO - 2016-05-07 16:41:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-07 16:41:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:41:57 --> Final output sent to browser
DEBUG - 2016-05-07 16:41:57 --> Total execution time: 0.0726
INFO - 2016-05-07 16:41:59 --> Config Class Initialized
INFO - 2016-05-07 16:41:59 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:41:59 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:41:59 --> Utf8 Class Initialized
INFO - 2016-05-07 16:41:59 --> URI Class Initialized
INFO - 2016-05-07 16:41:59 --> Router Class Initialized
INFO - 2016-05-07 16:41:59 --> Output Class Initialized
INFO - 2016-05-07 16:41:59 --> Security Class Initialized
DEBUG - 2016-05-07 16:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:41:59 --> Input Class Initialized
INFO - 2016-05-07 16:41:59 --> Language Class Initialized
INFO - 2016-05-07 16:41:59 --> Loader Class Initialized
INFO - 2016-05-07 16:41:59 --> Helper loaded: url_helper
INFO - 2016-05-07 16:41:59 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:41:59 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:41:59 --> Helper loaded: form_helper
INFO - 2016-05-07 16:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:41:59 --> Form Validation Class Initialized
INFO - 2016-05-07 16:41:59 --> Controller Class Initialized
INFO - 2016-05-07 16:41:59 --> Model Class Initialized
INFO - 2016-05-07 16:41:59 --> Database Driver Class Initialized
INFO - 2016-05-07 16:41:59 --> Config Class Initialized
INFO - 2016-05-07 16:41:59 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:41:59 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:41:59 --> Utf8 Class Initialized
INFO - 2016-05-07 16:41:59 --> URI Class Initialized
INFO - 2016-05-07 16:41:59 --> Router Class Initialized
INFO - 2016-05-07 16:41:59 --> Output Class Initialized
INFO - 2016-05-07 16:41:59 --> Security Class Initialized
DEBUG - 2016-05-07 16:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:41:59 --> Input Class Initialized
INFO - 2016-05-07 16:41:59 --> Language Class Initialized
INFO - 2016-05-07 16:41:59 --> Loader Class Initialized
INFO - 2016-05-07 16:41:59 --> Helper loaded: url_helper
INFO - 2016-05-07 16:41:59 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:41:59 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:41:59 --> Helper loaded: form_helper
INFO - 2016-05-07 16:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:41:59 --> Form Validation Class Initialized
INFO - 2016-05-07 16:41:59 --> Controller Class Initialized
INFO - 2016-05-07 16:41:59 --> Model Class Initialized
INFO - 2016-05-07 16:41:59 --> Database Driver Class Initialized
INFO - 2016-05-07 16:41:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-07 16:41:59 --> Final output sent to browser
DEBUG - 2016-05-07 16:41:59 --> Total execution time: 0.1069
INFO - 2016-05-07 16:42:02 --> Config Class Initialized
INFO - 2016-05-07 16:42:02 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:42:02 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:42:02 --> Utf8 Class Initialized
INFO - 2016-05-07 16:42:02 --> URI Class Initialized
INFO - 2016-05-07 16:42:02 --> Router Class Initialized
INFO - 2016-05-07 16:42:02 --> Output Class Initialized
INFO - 2016-05-07 16:42:02 --> Security Class Initialized
DEBUG - 2016-05-07 16:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:42:02 --> Input Class Initialized
INFO - 2016-05-07 16:42:02 --> Language Class Initialized
INFO - 2016-05-07 16:42:02 --> Loader Class Initialized
INFO - 2016-05-07 16:42:02 --> Helper loaded: url_helper
INFO - 2016-05-07 16:42:02 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:42:02 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:42:02 --> Helper loaded: form_helper
INFO - 2016-05-07 16:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:42:02 --> Form Validation Class Initialized
INFO - 2016-05-07 16:42:02 --> Controller Class Initialized
INFO - 2016-05-07 16:42:02 --> Config Class Initialized
INFO - 2016-05-07 16:42:02 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:42:02 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:42:02 --> Utf8 Class Initialized
INFO - 2016-05-07 16:42:02 --> URI Class Initialized
INFO - 2016-05-07 16:42:02 --> Router Class Initialized
INFO - 2016-05-07 16:42:02 --> Output Class Initialized
INFO - 2016-05-07 16:42:02 --> Security Class Initialized
DEBUG - 2016-05-07 16:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:42:02 --> Input Class Initialized
INFO - 2016-05-07 16:42:02 --> Language Class Initialized
INFO - 2016-05-07 16:42:02 --> Loader Class Initialized
INFO - 2016-05-07 16:42:02 --> Helper loaded: url_helper
INFO - 2016-05-07 16:42:02 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:42:02 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:42:02 --> Helper loaded: form_helper
INFO - 2016-05-07 16:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:42:02 --> Form Validation Class Initialized
INFO - 2016-05-07 16:42:02 --> Controller Class Initialized
INFO - 2016-05-07 16:42:02 --> Model Class Initialized
INFO - 2016-05-07 16:42:02 --> Database Driver Class Initialized
INFO - 2016-05-07 16:42:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-07 16:42:02 --> Final output sent to browser
DEBUG - 2016-05-07 16:42:02 --> Total execution time: 0.0713
INFO - 2016-05-07 16:42:06 --> Config Class Initialized
INFO - 2016-05-07 16:42:06 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:42:06 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:42:06 --> Utf8 Class Initialized
INFO - 2016-05-07 16:42:06 --> URI Class Initialized
INFO - 2016-05-07 16:42:06 --> Router Class Initialized
INFO - 2016-05-07 16:42:06 --> Output Class Initialized
INFO - 2016-05-07 16:42:06 --> Security Class Initialized
DEBUG - 2016-05-07 16:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:42:06 --> Input Class Initialized
INFO - 2016-05-07 16:42:06 --> Language Class Initialized
INFO - 2016-05-07 16:42:06 --> Loader Class Initialized
INFO - 2016-05-07 16:42:06 --> Helper loaded: url_helper
INFO - 2016-05-07 16:42:06 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:42:06 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:42:06 --> Helper loaded: form_helper
INFO - 2016-05-07 16:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:42:06 --> Form Validation Class Initialized
INFO - 2016-05-07 16:42:06 --> Controller Class Initialized
INFO - 2016-05-07 16:42:06 --> Model Class Initialized
INFO - 2016-05-07 16:42:06 --> Database Driver Class Initialized
INFO - 2016-05-07 16:42:07 --> Config Class Initialized
INFO - 2016-05-07 16:42:07 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:42:07 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:42:07 --> Utf8 Class Initialized
INFO - 2016-05-07 16:42:07 --> URI Class Initialized
INFO - 2016-05-07 16:42:07 --> Router Class Initialized
INFO - 2016-05-07 16:42:07 --> Output Class Initialized
INFO - 2016-05-07 16:42:07 --> Security Class Initialized
DEBUG - 2016-05-07 16:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:42:07 --> Input Class Initialized
INFO - 2016-05-07 16:42:07 --> Language Class Initialized
INFO - 2016-05-07 16:42:07 --> Loader Class Initialized
INFO - 2016-05-07 16:42:07 --> Helper loaded: url_helper
INFO - 2016-05-07 16:42:07 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:42:07 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:42:07 --> Helper loaded: form_helper
INFO - 2016-05-07 16:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:42:07 --> Form Validation Class Initialized
INFO - 2016-05-07 16:42:07 --> Controller Class Initialized
INFO - 2016-05-07 16:42:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-07 16:42:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:42:07 --> Final output sent to browser
DEBUG - 2016-05-07 16:42:07 --> Total execution time: 0.0532
INFO - 2016-05-07 16:42:16 --> Config Class Initialized
INFO - 2016-05-07 16:42:16 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:42:16 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:42:16 --> Utf8 Class Initialized
INFO - 2016-05-07 16:42:16 --> URI Class Initialized
INFO - 2016-05-07 16:42:16 --> Router Class Initialized
INFO - 2016-05-07 16:42:16 --> Output Class Initialized
INFO - 2016-05-07 16:42:16 --> Security Class Initialized
DEBUG - 2016-05-07 16:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:42:16 --> Input Class Initialized
INFO - 2016-05-07 16:42:16 --> Language Class Initialized
INFO - 2016-05-07 16:42:16 --> Loader Class Initialized
INFO - 2016-05-07 16:42:16 --> Helper loaded: url_helper
INFO - 2016-05-07 16:42:16 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:42:16 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:42:16 --> Helper loaded: form_helper
INFO - 2016-05-07 16:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:42:16 --> Form Validation Class Initialized
INFO - 2016-05-07 16:42:16 --> Controller Class Initialized
INFO - 2016-05-07 16:42:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-07 16:42:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:42:16 --> Final output sent to browser
DEBUG - 2016-05-07 16:42:16 --> Total execution time: 0.0507
INFO - 2016-05-07 16:42:20 --> Config Class Initialized
INFO - 2016-05-07 16:42:20 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:42:20 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:42:20 --> Utf8 Class Initialized
INFO - 2016-05-07 16:42:20 --> URI Class Initialized
INFO - 2016-05-07 16:42:20 --> Router Class Initialized
INFO - 2016-05-07 16:42:20 --> Output Class Initialized
INFO - 2016-05-07 16:42:20 --> Security Class Initialized
DEBUG - 2016-05-07 16:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:42:20 --> Input Class Initialized
INFO - 2016-05-07 16:42:20 --> Language Class Initialized
INFO - 2016-05-07 16:42:20 --> Loader Class Initialized
INFO - 2016-05-07 16:42:20 --> Helper loaded: url_helper
INFO - 2016-05-07 16:42:20 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:42:20 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:42:20 --> Helper loaded: form_helper
INFO - 2016-05-07 16:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:42:20 --> Form Validation Class Initialized
INFO - 2016-05-07 16:42:20 --> Controller Class Initialized
INFO - 2016-05-07 16:42:20 --> Model Class Initialized
INFO - 2016-05-07 16:42:20 --> Database Driver Class Initialized
INFO - 2016-05-07 16:42:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:42:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:42:20 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:42:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:42:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 16:42:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:42:21 --> Final output sent to browser
DEBUG - 2016-05-07 16:42:21 --> Total execution time: 0.2662
INFO - 2016-05-07 16:42:43 --> Config Class Initialized
INFO - 2016-05-07 16:42:43 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:42:43 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:42:43 --> Utf8 Class Initialized
INFO - 2016-05-07 16:42:43 --> URI Class Initialized
INFO - 2016-05-07 16:42:43 --> Router Class Initialized
INFO - 2016-05-07 16:42:43 --> Output Class Initialized
INFO - 2016-05-07 16:42:43 --> Security Class Initialized
DEBUG - 2016-05-07 16:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:42:43 --> Input Class Initialized
INFO - 2016-05-07 16:42:43 --> Language Class Initialized
INFO - 2016-05-07 16:42:43 --> Loader Class Initialized
INFO - 2016-05-07 16:42:43 --> Helper loaded: url_helper
INFO - 2016-05-07 16:42:43 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:42:43 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:42:43 --> Helper loaded: form_helper
INFO - 2016-05-07 16:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:42:44 --> Form Validation Class Initialized
INFO - 2016-05-07 16:42:44 --> Controller Class Initialized
INFO - 2016-05-07 16:42:44 --> Model Class Initialized
INFO - 2016-05-07 16:42:44 --> Database Driver Class Initialized
INFO - 2016-05-07 16:42:44 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:42:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:42:44 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:42:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:42:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 16:42:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:42:44 --> Final output sent to browser
DEBUG - 2016-05-07 16:42:44 --> Total execution time: 0.1248
INFO - 2016-05-07 16:42:47 --> Config Class Initialized
INFO - 2016-05-07 16:42:47 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:42:47 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:42:47 --> Utf8 Class Initialized
INFO - 2016-05-07 16:42:47 --> URI Class Initialized
INFO - 2016-05-07 16:42:47 --> Router Class Initialized
INFO - 2016-05-07 16:42:47 --> Output Class Initialized
INFO - 2016-05-07 16:42:47 --> Security Class Initialized
DEBUG - 2016-05-07 16:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:42:47 --> Input Class Initialized
INFO - 2016-05-07 16:42:47 --> Language Class Initialized
INFO - 2016-05-07 16:42:47 --> Loader Class Initialized
INFO - 2016-05-07 16:42:47 --> Helper loaded: url_helper
INFO - 2016-05-07 16:42:47 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:42:47 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:42:47 --> Helper loaded: form_helper
INFO - 2016-05-07 16:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:42:47 --> Form Validation Class Initialized
INFO - 2016-05-07 16:42:47 --> Controller Class Initialized
INFO - 2016-05-07 16:42:47 --> Model Class Initialized
INFO - 2016-05-07 16:42:47 --> Database Driver Class Initialized
INFO - 2016-05-07 16:42:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:42:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:42:47 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:42:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:42:47 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 16:42:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:42:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:42:47 --> Final output sent to browser
DEBUG - 2016-05-07 16:42:47 --> Total execution time: 0.0973
INFO - 2016-05-07 16:43:01 --> Config Class Initialized
INFO - 2016-05-07 16:43:01 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:43:01 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:43:01 --> Utf8 Class Initialized
INFO - 2016-05-07 16:43:01 --> URI Class Initialized
INFO - 2016-05-07 16:43:01 --> Router Class Initialized
INFO - 2016-05-07 16:43:01 --> Output Class Initialized
INFO - 2016-05-07 16:43:01 --> Security Class Initialized
DEBUG - 2016-05-07 16:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:43:01 --> Input Class Initialized
INFO - 2016-05-07 16:43:01 --> Language Class Initialized
INFO - 2016-05-07 16:43:01 --> Loader Class Initialized
INFO - 2016-05-07 16:43:01 --> Helper loaded: url_helper
INFO - 2016-05-07 16:43:01 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:43:01 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:43:01 --> Helper loaded: form_helper
INFO - 2016-05-07 16:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:43:01 --> Form Validation Class Initialized
INFO - 2016-05-07 16:43:01 --> Controller Class Initialized
INFO - 2016-05-07 16:43:01 --> Model Class Initialized
INFO - 2016-05-07 16:43:01 --> Database Driver Class Initialized
INFO - 2016-05-07 16:43:01 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:43:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:43:01 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:43:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:43:01 --> Helper loaded: nif_validate_helper
INFO - 2016-05-07 16:43:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-07 16:43:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:43:01 --> Final output sent to browser
DEBUG - 2016-05-07 16:43:01 --> Total execution time: 0.0816
INFO - 2016-05-07 16:43:05 --> Config Class Initialized
INFO - 2016-05-07 16:43:05 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:43:05 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:43:05 --> Utf8 Class Initialized
INFO - 2016-05-07 16:43:05 --> URI Class Initialized
INFO - 2016-05-07 16:43:05 --> Router Class Initialized
INFO - 2016-05-07 16:43:05 --> Output Class Initialized
INFO - 2016-05-07 16:43:05 --> Security Class Initialized
DEBUG - 2016-05-07 16:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:43:05 --> Input Class Initialized
INFO - 2016-05-07 16:43:05 --> Language Class Initialized
INFO - 2016-05-07 16:43:05 --> Loader Class Initialized
INFO - 2016-05-07 16:43:05 --> Helper loaded: url_helper
INFO - 2016-05-07 16:43:05 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:43:05 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:43:05 --> Helper loaded: form_helper
INFO - 2016-05-07 16:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:43:05 --> Form Validation Class Initialized
INFO - 2016-05-07 16:43:05 --> Controller Class Initialized
INFO - 2016-05-07 16:43:05 --> Model Class Initialized
INFO - 2016-05-07 16:43:05 --> Database Driver Class Initialized
INFO - 2016-05-07 16:43:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:43:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:43:05 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:43:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:43:05 --> Helper loaded: nif_validate_helper
INFO - 2016-05-07 16:43:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProveedor.php
INFO - 2016-05-07 16:43:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:43:05 --> Final output sent to browser
DEBUG - 2016-05-07 16:43:05 --> Total execution time: 0.1278
INFO - 2016-05-07 16:43:07 --> Config Class Initialized
INFO - 2016-05-07 16:43:07 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:43:07 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:43:07 --> Utf8 Class Initialized
INFO - 2016-05-07 16:43:07 --> URI Class Initialized
INFO - 2016-05-07 16:43:07 --> Router Class Initialized
INFO - 2016-05-07 16:43:07 --> Output Class Initialized
INFO - 2016-05-07 16:43:07 --> Security Class Initialized
DEBUG - 2016-05-07 16:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:43:07 --> Input Class Initialized
INFO - 2016-05-07 16:43:07 --> Language Class Initialized
INFO - 2016-05-07 16:43:07 --> Loader Class Initialized
INFO - 2016-05-07 16:43:07 --> Helper loaded: url_helper
INFO - 2016-05-07 16:43:07 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:43:07 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:43:07 --> Helper loaded: form_helper
INFO - 2016-05-07 16:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:43:07 --> Form Validation Class Initialized
INFO - 2016-05-07 16:43:07 --> Controller Class Initialized
INFO - 2016-05-07 16:43:07 --> Model Class Initialized
INFO - 2016-05-07 16:43:07 --> Database Driver Class Initialized
INFO - 2016-05-07 16:43:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:43:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:43:07 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:43:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:43:07 --> Helper loaded: nif_validate_helper
INFO - 2016-05-07 16:43:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-07 16:43:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:43:07 --> Final output sent to browser
DEBUG - 2016-05-07 16:43:07 --> Total execution time: 0.0958
INFO - 2016-05-07 16:43:09 --> Config Class Initialized
INFO - 2016-05-07 16:43:09 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:43:09 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:43:09 --> Utf8 Class Initialized
INFO - 2016-05-07 16:43:09 --> URI Class Initialized
INFO - 2016-05-07 16:43:09 --> Router Class Initialized
INFO - 2016-05-07 16:43:09 --> Output Class Initialized
INFO - 2016-05-07 16:43:09 --> Security Class Initialized
DEBUG - 2016-05-07 16:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:43:09 --> Input Class Initialized
INFO - 2016-05-07 16:43:09 --> Language Class Initialized
INFO - 2016-05-07 16:43:09 --> Loader Class Initialized
INFO - 2016-05-07 16:43:09 --> Helper loaded: url_helper
INFO - 2016-05-07 16:43:09 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:43:09 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:43:09 --> Helper loaded: form_helper
INFO - 2016-05-07 16:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:43:09 --> Form Validation Class Initialized
INFO - 2016-05-07 16:43:09 --> Controller Class Initialized
INFO - 2016-05-07 16:43:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-07 16:43:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:43:09 --> Final output sent to browser
DEBUG - 2016-05-07 16:43:09 --> Total execution time: 0.0588
INFO - 2016-05-07 16:43:12 --> Config Class Initialized
INFO - 2016-05-07 16:43:12 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:43:12 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:43:12 --> Utf8 Class Initialized
INFO - 2016-05-07 16:43:12 --> URI Class Initialized
INFO - 2016-05-07 16:43:12 --> Router Class Initialized
INFO - 2016-05-07 16:43:12 --> Output Class Initialized
INFO - 2016-05-07 16:43:12 --> Security Class Initialized
DEBUG - 2016-05-07 16:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:43:12 --> Input Class Initialized
INFO - 2016-05-07 16:43:12 --> Language Class Initialized
INFO - 2016-05-07 16:43:12 --> Loader Class Initialized
INFO - 2016-05-07 16:43:12 --> Helper loaded: url_helper
INFO - 2016-05-07 16:43:12 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:43:12 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:43:12 --> Helper loaded: form_helper
INFO - 2016-05-07 16:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:43:12 --> Form Validation Class Initialized
INFO - 2016-05-07 16:43:12 --> Controller Class Initialized
INFO - 2016-05-07 16:43:12 --> Model Class Initialized
INFO - 2016-05-07 16:43:12 --> Database Driver Class Initialized
INFO - 2016-05-07 16:43:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:43:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:43:12 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:43:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:43:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 16:43:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:43:12 --> Final output sent to browser
DEBUG - 2016-05-07 16:43:12 --> Total execution time: 0.1155
INFO - 2016-05-07 16:43:13 --> Config Class Initialized
INFO - 2016-05-07 16:43:13 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:43:14 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:43:14 --> Utf8 Class Initialized
INFO - 2016-05-07 16:43:14 --> URI Class Initialized
INFO - 2016-05-07 16:43:14 --> Router Class Initialized
INFO - 2016-05-07 16:43:14 --> Output Class Initialized
INFO - 2016-05-07 16:43:14 --> Security Class Initialized
DEBUG - 2016-05-07 16:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:43:14 --> Input Class Initialized
INFO - 2016-05-07 16:43:14 --> Language Class Initialized
INFO - 2016-05-07 16:43:14 --> Loader Class Initialized
INFO - 2016-05-07 16:43:14 --> Helper loaded: url_helper
INFO - 2016-05-07 16:43:14 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:43:14 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:43:14 --> Helper loaded: form_helper
INFO - 2016-05-07 16:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:43:14 --> Form Validation Class Initialized
INFO - 2016-05-07 16:43:14 --> Controller Class Initialized
INFO - 2016-05-07 16:43:14 --> Model Class Initialized
INFO - 2016-05-07 16:43:14 --> Database Driver Class Initialized
INFO - 2016-05-07 16:43:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:43:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:43:14 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:43:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:43:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 16:43:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:43:14 --> Final output sent to browser
DEBUG - 2016-05-07 16:43:14 --> Total execution time: 0.2852
INFO - 2016-05-07 16:43:17 --> Config Class Initialized
INFO - 2016-05-07 16:43:17 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:43:17 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:43:17 --> Utf8 Class Initialized
INFO - 2016-05-07 16:43:17 --> URI Class Initialized
INFO - 2016-05-07 16:43:17 --> Router Class Initialized
INFO - 2016-05-07 16:43:17 --> Output Class Initialized
INFO - 2016-05-07 16:43:17 --> Security Class Initialized
DEBUG - 2016-05-07 16:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:43:17 --> Input Class Initialized
INFO - 2016-05-07 16:43:17 --> Language Class Initialized
INFO - 2016-05-07 16:43:17 --> Loader Class Initialized
INFO - 2016-05-07 16:43:17 --> Helper loaded: url_helper
INFO - 2016-05-07 16:43:17 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:43:17 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:43:17 --> Helper loaded: form_helper
INFO - 2016-05-07 16:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:43:17 --> Form Validation Class Initialized
INFO - 2016-05-07 16:43:17 --> Controller Class Initialized
INFO - 2016-05-07 16:43:17 --> Model Class Initialized
INFO - 2016-05-07 16:43:17 --> Database Driver Class Initialized
INFO - 2016-05-07 16:43:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:43:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:43:17 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:43:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:43:17 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 16:43:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:43:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:43:17 --> Final output sent to browser
DEBUG - 2016-05-07 16:43:17 --> Total execution time: 0.0892
INFO - 2016-05-07 16:43:43 --> Config Class Initialized
INFO - 2016-05-07 16:43:43 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:43:43 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:43:43 --> Utf8 Class Initialized
INFO - 2016-05-07 16:43:43 --> URI Class Initialized
INFO - 2016-05-07 16:43:43 --> Router Class Initialized
INFO - 2016-05-07 16:43:43 --> Output Class Initialized
INFO - 2016-05-07 16:43:43 --> Security Class Initialized
DEBUG - 2016-05-07 16:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:43:43 --> Input Class Initialized
INFO - 2016-05-07 16:43:43 --> Language Class Initialized
INFO - 2016-05-07 16:43:43 --> Loader Class Initialized
INFO - 2016-05-07 16:43:43 --> Helper loaded: url_helper
INFO - 2016-05-07 16:43:43 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:43:43 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:43:43 --> Helper loaded: form_helper
INFO - 2016-05-07 16:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:43:43 --> Form Validation Class Initialized
INFO - 2016-05-07 16:43:43 --> Controller Class Initialized
INFO - 2016-05-07 16:43:43 --> Model Class Initialized
INFO - 2016-05-07 16:43:43 --> Database Driver Class Initialized
INFO - 2016-05-07 16:43:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:43:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:43:43 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:43:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:43:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 16:43:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:43:43 --> Final output sent to browser
DEBUG - 2016-05-07 16:43:43 --> Total execution time: 0.2373
INFO - 2016-05-07 16:43:53 --> Config Class Initialized
INFO - 2016-05-07 16:43:53 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:43:53 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:43:53 --> Utf8 Class Initialized
INFO - 2016-05-07 16:43:53 --> URI Class Initialized
INFO - 2016-05-07 16:43:53 --> Router Class Initialized
INFO - 2016-05-07 16:43:53 --> Output Class Initialized
INFO - 2016-05-07 16:43:53 --> Security Class Initialized
DEBUG - 2016-05-07 16:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:43:53 --> Input Class Initialized
INFO - 2016-05-07 16:43:53 --> Language Class Initialized
INFO - 2016-05-07 16:43:53 --> Loader Class Initialized
INFO - 2016-05-07 16:43:53 --> Helper loaded: url_helper
INFO - 2016-05-07 16:43:53 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:43:53 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:43:53 --> Helper loaded: form_helper
INFO - 2016-05-07 16:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:43:53 --> Form Validation Class Initialized
INFO - 2016-05-07 16:43:53 --> Controller Class Initialized
INFO - 2016-05-07 16:43:53 --> Model Class Initialized
INFO - 2016-05-07 16:43:53 --> Database Driver Class Initialized
INFO - 2016-05-07 16:43:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:43:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:43:53 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:43:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:43:53 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 16:43:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:43:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:43:53 --> Final output sent to browser
DEBUG - 2016-05-07 16:43:53 --> Total execution time: 0.1171
INFO - 2016-05-07 16:43:54 --> Config Class Initialized
INFO - 2016-05-07 16:43:54 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:43:55 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:43:55 --> Utf8 Class Initialized
INFO - 2016-05-07 16:43:55 --> URI Class Initialized
INFO - 2016-05-07 16:43:55 --> Router Class Initialized
INFO - 2016-05-07 16:43:55 --> Output Class Initialized
INFO - 2016-05-07 16:43:55 --> Security Class Initialized
DEBUG - 2016-05-07 16:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:43:55 --> Input Class Initialized
INFO - 2016-05-07 16:43:55 --> Language Class Initialized
INFO - 2016-05-07 16:43:55 --> Loader Class Initialized
INFO - 2016-05-07 16:43:55 --> Helper loaded: url_helper
INFO - 2016-05-07 16:43:55 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:43:55 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:43:55 --> Helper loaded: form_helper
INFO - 2016-05-07 16:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:43:55 --> Form Validation Class Initialized
INFO - 2016-05-07 16:43:55 --> Controller Class Initialized
INFO - 2016-05-07 16:43:55 --> Model Class Initialized
INFO - 2016-05-07 16:43:55 --> Database Driver Class Initialized
INFO - 2016-05-07 16:43:55 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:43:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:43:55 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:43:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:43:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 16:43:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:43:55 --> Final output sent to browser
DEBUG - 2016-05-07 16:43:55 --> Total execution time: 0.1101
INFO - 2016-05-07 16:43:56 --> Config Class Initialized
INFO - 2016-05-07 16:43:56 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:43:56 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:43:56 --> Utf8 Class Initialized
INFO - 2016-05-07 16:43:56 --> URI Class Initialized
INFO - 2016-05-07 16:43:56 --> Router Class Initialized
INFO - 2016-05-07 16:43:56 --> Output Class Initialized
INFO - 2016-05-07 16:43:56 --> Security Class Initialized
DEBUG - 2016-05-07 16:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:43:56 --> Input Class Initialized
INFO - 2016-05-07 16:43:56 --> Language Class Initialized
INFO - 2016-05-07 16:43:56 --> Loader Class Initialized
INFO - 2016-05-07 16:43:56 --> Helper loaded: url_helper
INFO - 2016-05-07 16:43:56 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:43:56 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:43:56 --> Helper loaded: form_helper
INFO - 2016-05-07 16:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:43:56 --> Form Validation Class Initialized
INFO - 2016-05-07 16:43:56 --> Controller Class Initialized
INFO - 2016-05-07 16:43:56 --> Model Class Initialized
INFO - 2016-05-07 16:43:56 --> Database Driver Class Initialized
INFO - 2016-05-07 16:43:56 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:43:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:43:56 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:43:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:43:56 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 16:43:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:43:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:43:56 --> Final output sent to browser
DEBUG - 2016-05-07 16:43:56 --> Total execution time: 0.0838
INFO - 2016-05-07 16:43:58 --> Config Class Initialized
INFO - 2016-05-07 16:43:58 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:43:58 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:43:58 --> Utf8 Class Initialized
INFO - 2016-05-07 16:43:58 --> URI Class Initialized
INFO - 2016-05-07 16:43:58 --> Router Class Initialized
INFO - 2016-05-07 16:43:58 --> Output Class Initialized
INFO - 2016-05-07 16:43:58 --> Security Class Initialized
DEBUG - 2016-05-07 16:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:43:58 --> Input Class Initialized
INFO - 2016-05-07 16:43:58 --> Language Class Initialized
INFO - 2016-05-07 16:43:58 --> Loader Class Initialized
INFO - 2016-05-07 16:43:58 --> Helper loaded: url_helper
INFO - 2016-05-07 16:43:58 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:43:58 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:43:58 --> Helper loaded: form_helper
INFO - 2016-05-07 16:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:43:58 --> Form Validation Class Initialized
INFO - 2016-05-07 16:43:58 --> Controller Class Initialized
INFO - 2016-05-07 16:43:58 --> Model Class Initialized
INFO - 2016-05-07 16:43:58 --> Database Driver Class Initialized
INFO - 2016-05-07 16:43:58 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:43:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:43:58 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:43:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:43:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 16:43:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:43:58 --> Final output sent to browser
DEBUG - 2016-05-07 16:43:58 --> Total execution time: 0.1033
INFO - 2016-05-07 16:44:03 --> Config Class Initialized
INFO - 2016-05-07 16:44:03 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:44:03 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:44:03 --> Utf8 Class Initialized
INFO - 2016-05-07 16:44:03 --> URI Class Initialized
INFO - 2016-05-07 16:44:03 --> Router Class Initialized
INFO - 2016-05-07 16:44:03 --> Output Class Initialized
INFO - 2016-05-07 16:44:03 --> Security Class Initialized
DEBUG - 2016-05-07 16:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:44:03 --> Input Class Initialized
INFO - 2016-05-07 16:44:03 --> Language Class Initialized
INFO - 2016-05-07 16:44:03 --> Loader Class Initialized
INFO - 2016-05-07 16:44:03 --> Helper loaded: url_helper
INFO - 2016-05-07 16:44:03 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:44:03 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:44:03 --> Helper loaded: form_helper
INFO - 2016-05-07 16:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:44:03 --> Form Validation Class Initialized
INFO - 2016-05-07 16:44:03 --> Controller Class Initialized
INFO - 2016-05-07 16:44:03 --> Model Class Initialized
INFO - 2016-05-07 16:44:03 --> Database Driver Class Initialized
INFO - 2016-05-07 16:44:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:44:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:44:04 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:44:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:44:04 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 16:44:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:44:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:44:04 --> Final output sent to browser
DEBUG - 2016-05-07 16:44:04 --> Total execution time: 0.0848
INFO - 2016-05-07 16:50:01 --> Config Class Initialized
INFO - 2016-05-07 16:50:01 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:50:01 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:50:01 --> Utf8 Class Initialized
INFO - 2016-05-07 16:50:01 --> URI Class Initialized
INFO - 2016-05-07 16:50:01 --> Router Class Initialized
INFO - 2016-05-07 16:50:01 --> Output Class Initialized
INFO - 2016-05-07 16:50:01 --> Security Class Initialized
DEBUG - 2016-05-07 16:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:50:01 --> Input Class Initialized
INFO - 2016-05-07 16:50:01 --> Language Class Initialized
INFO - 2016-05-07 16:50:01 --> Loader Class Initialized
INFO - 2016-05-07 16:50:01 --> Helper loaded: url_helper
INFO - 2016-05-07 16:50:01 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:50:01 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:50:01 --> Helper loaded: form_helper
INFO - 2016-05-07 16:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:50:01 --> Form Validation Class Initialized
INFO - 2016-05-07 16:50:01 --> Controller Class Initialized
INFO - 2016-05-07 16:50:01 --> Model Class Initialized
INFO - 2016-05-07 16:50:01 --> Database Driver Class Initialized
INFO - 2016-05-07 16:50:01 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:50:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:50:01 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:50:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:50:01 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 16:50:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:50:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:50:01 --> Final output sent to browser
DEBUG - 2016-05-07 16:50:01 --> Total execution time: 0.0858
INFO - 2016-05-07 16:50:47 --> Config Class Initialized
INFO - 2016-05-07 16:50:47 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:50:47 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:50:47 --> Utf8 Class Initialized
INFO - 2016-05-07 16:50:47 --> URI Class Initialized
INFO - 2016-05-07 16:50:47 --> Router Class Initialized
INFO - 2016-05-07 16:50:47 --> Output Class Initialized
INFO - 2016-05-07 16:50:47 --> Security Class Initialized
DEBUG - 2016-05-07 16:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:50:47 --> Input Class Initialized
INFO - 2016-05-07 16:50:47 --> Language Class Initialized
INFO - 2016-05-07 16:50:47 --> Loader Class Initialized
INFO - 2016-05-07 16:50:47 --> Helper loaded: url_helper
INFO - 2016-05-07 16:50:47 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:50:47 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:50:47 --> Helper loaded: form_helper
INFO - 2016-05-07 16:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:50:47 --> Form Validation Class Initialized
INFO - 2016-05-07 16:50:47 --> Controller Class Initialized
INFO - 2016-05-07 16:50:47 --> Model Class Initialized
INFO - 2016-05-07 16:50:47 --> Database Driver Class Initialized
INFO - 2016-05-07 16:50:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:50:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:50:47 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:50:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:50:47 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-05-07 16:50:47 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php 19
ERROR - 2016-05-07 16:50:47 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php 23
ERROR - 2016-05-07 16:50:47 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php 27
ERROR - 2016-05-07 16:50:47 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php 31
ERROR - 2016-05-07 16:50:47 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php 35
ERROR - 2016-05-07 16:50:47 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php 39
ERROR - 2016-05-07 16:50:47 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php 43
ERROR - 2016-05-07 16:50:47 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php 47
ERROR - 2016-05-07 16:50:47 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php 51
ERROR - 2016-05-07 16:50:47 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php 67
INFO - 2016-05-07 16:50:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:50:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:50:47 --> Final output sent to browser
DEBUG - 2016-05-07 16:50:47 --> Total execution time: 0.1185
INFO - 2016-05-07 16:50:47 --> Config Class Initialized
INFO - 2016-05-07 16:50:47 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:50:47 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:50:47 --> Utf8 Class Initialized
INFO - 2016-05-07 16:51:36 --> Config Class Initialized
INFO - 2016-05-07 16:51:36 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:51:36 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:51:36 --> Utf8 Class Initialized
INFO - 2016-05-07 16:51:36 --> URI Class Initialized
INFO - 2016-05-07 16:51:36 --> Router Class Initialized
INFO - 2016-05-07 16:51:36 --> Output Class Initialized
INFO - 2016-05-07 16:51:36 --> Security Class Initialized
DEBUG - 2016-05-07 16:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:51:36 --> Input Class Initialized
INFO - 2016-05-07 16:51:36 --> Language Class Initialized
INFO - 2016-05-07 16:51:36 --> Loader Class Initialized
INFO - 2016-05-07 16:51:36 --> Helper loaded: url_helper
INFO - 2016-05-07 16:51:36 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:51:36 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:51:36 --> Helper loaded: form_helper
INFO - 2016-05-07 16:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:51:36 --> Form Validation Class Initialized
INFO - 2016-05-07 16:51:36 --> Controller Class Initialized
INFO - 2016-05-07 16:51:36 --> Model Class Initialized
INFO - 2016-05-07 16:51:36 --> Database Driver Class Initialized
INFO - 2016-05-07 16:51:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:51:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:51:36 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:51:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:51:36 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 16:51:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:51:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:51:36 --> Final output sent to browser
DEBUG - 2016-05-07 16:51:36 --> Total execution time: 0.0855
INFO - 2016-05-07 16:51:40 --> Config Class Initialized
INFO - 2016-05-07 16:51:40 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:51:40 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:51:40 --> Utf8 Class Initialized
INFO - 2016-05-07 16:51:40 --> URI Class Initialized
INFO - 2016-05-07 16:51:40 --> Router Class Initialized
INFO - 2016-05-07 16:51:40 --> Output Class Initialized
INFO - 2016-05-07 16:51:40 --> Security Class Initialized
DEBUG - 2016-05-07 16:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:51:40 --> Input Class Initialized
INFO - 2016-05-07 16:51:40 --> Language Class Initialized
INFO - 2016-05-07 16:51:40 --> Loader Class Initialized
INFO - 2016-05-07 16:51:40 --> Helper loaded: url_helper
INFO - 2016-05-07 16:51:40 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:51:40 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:51:40 --> Helper loaded: form_helper
INFO - 2016-05-07 16:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:51:40 --> Form Validation Class Initialized
INFO - 2016-05-07 16:51:40 --> Controller Class Initialized
INFO - 2016-05-07 16:51:40 --> Model Class Initialized
INFO - 2016-05-07 16:51:40 --> Database Driver Class Initialized
INFO - 2016-05-07 16:51:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:51:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:51:40 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:51:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 16:51:40 --> Severity: Error --> Call to undefined method Productos::checkImagenEnviada() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 260
INFO - 2016-05-07 16:52:03 --> Config Class Initialized
INFO - 2016-05-07 16:52:03 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:52:03 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:52:03 --> Utf8 Class Initialized
INFO - 2016-05-07 16:52:03 --> URI Class Initialized
INFO - 2016-05-07 16:52:03 --> Router Class Initialized
INFO - 2016-05-07 16:52:03 --> Output Class Initialized
INFO - 2016-05-07 16:52:03 --> Security Class Initialized
DEBUG - 2016-05-07 16:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:52:03 --> Input Class Initialized
INFO - 2016-05-07 16:52:03 --> Language Class Initialized
INFO - 2016-05-07 16:52:03 --> Loader Class Initialized
INFO - 2016-05-07 16:52:03 --> Helper loaded: url_helper
INFO - 2016-05-07 16:52:03 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:52:03 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:52:03 --> Helper loaded: form_helper
INFO - 2016-05-07 16:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:52:03 --> Form Validation Class Initialized
INFO - 2016-05-07 16:52:03 --> Controller Class Initialized
INFO - 2016-05-07 16:52:03 --> Model Class Initialized
INFO - 2016-05-07 16:52:03 --> Database Driver Class Initialized
INFO - 2016-05-07 16:52:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:52:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:52:03 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:52:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 16:52:03 --> Severity: Notice --> Undefined variable: mensajeok C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 281
INFO - 2016-05-07 16:52:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:52:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:52:03 --> Final output sent to browser
DEBUG - 2016-05-07 16:52:03 --> Total execution time: 0.0767
INFO - 2016-05-07 16:52:09 --> Config Class Initialized
INFO - 2016-05-07 16:52:09 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:52:09 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:52:09 --> Utf8 Class Initialized
INFO - 2016-05-07 16:52:09 --> URI Class Initialized
INFO - 2016-05-07 16:52:09 --> Router Class Initialized
INFO - 2016-05-07 16:52:09 --> Output Class Initialized
INFO - 2016-05-07 16:52:09 --> Security Class Initialized
DEBUG - 2016-05-07 16:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:52:09 --> Input Class Initialized
INFO - 2016-05-07 16:52:09 --> Language Class Initialized
INFO - 2016-05-07 16:52:09 --> Loader Class Initialized
INFO - 2016-05-07 16:52:09 --> Helper loaded: url_helper
INFO - 2016-05-07 16:52:09 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:52:09 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:52:09 --> Helper loaded: form_helper
INFO - 2016-05-07 16:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:52:09 --> Form Validation Class Initialized
INFO - 2016-05-07 16:52:09 --> Controller Class Initialized
INFO - 2016-05-07 16:52:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-07 16:52:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 16:52:09 --> Final output sent to browser
DEBUG - 2016-05-07 16:52:09 --> Total execution time: 0.0691
INFO - 2016-05-07 16:52:11 --> Config Class Initialized
INFO - 2016-05-07 16:52:11 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:52:11 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:52:11 --> Utf8 Class Initialized
INFO - 2016-05-07 16:52:11 --> URI Class Initialized
INFO - 2016-05-07 16:52:11 --> Router Class Initialized
INFO - 2016-05-07 16:52:11 --> Output Class Initialized
INFO - 2016-05-07 16:52:11 --> Security Class Initialized
DEBUG - 2016-05-07 16:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:52:11 --> Input Class Initialized
INFO - 2016-05-07 16:52:11 --> Language Class Initialized
INFO - 2016-05-07 16:52:11 --> Loader Class Initialized
INFO - 2016-05-07 16:52:11 --> Helper loaded: url_helper
INFO - 2016-05-07 16:52:11 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:52:11 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:52:11 --> Helper loaded: form_helper
INFO - 2016-05-07 16:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:52:11 --> Form Validation Class Initialized
INFO - 2016-05-07 16:52:11 --> Controller Class Initialized
INFO - 2016-05-07 16:52:11 --> Config Class Initialized
INFO - 2016-05-07 16:52:11 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:52:11 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:52:11 --> Utf8 Class Initialized
INFO - 2016-05-07 16:52:11 --> URI Class Initialized
INFO - 2016-05-07 16:52:11 --> Router Class Initialized
INFO - 2016-05-07 16:52:11 --> Output Class Initialized
INFO - 2016-05-07 16:52:11 --> Security Class Initialized
DEBUG - 2016-05-07 16:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:52:11 --> Input Class Initialized
INFO - 2016-05-07 16:52:11 --> Language Class Initialized
INFO - 2016-05-07 16:52:11 --> Loader Class Initialized
INFO - 2016-05-07 16:52:11 --> Helper loaded: url_helper
INFO - 2016-05-07 16:52:11 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:52:11 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:52:11 --> Helper loaded: form_helper
INFO - 2016-05-07 16:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:52:11 --> Form Validation Class Initialized
INFO - 2016-05-07 16:52:11 --> Controller Class Initialized
INFO - 2016-05-07 16:52:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-07 16:52:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 16:52:11 --> Final output sent to browser
DEBUG - 2016-05-07 16:52:11 --> Total execution time: 0.0591
INFO - 2016-05-07 16:52:15 --> Config Class Initialized
INFO - 2016-05-07 16:52:15 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:52:15 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:52:15 --> Utf8 Class Initialized
INFO - 2016-05-07 16:52:15 --> URI Class Initialized
INFO - 2016-05-07 16:52:15 --> Router Class Initialized
INFO - 2016-05-07 16:52:15 --> Output Class Initialized
INFO - 2016-05-07 16:52:15 --> Security Class Initialized
DEBUG - 2016-05-07 16:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:52:15 --> Input Class Initialized
INFO - 2016-05-07 16:52:15 --> Language Class Initialized
INFO - 2016-05-07 16:52:15 --> Loader Class Initialized
INFO - 2016-05-07 16:52:15 --> Helper loaded: url_helper
INFO - 2016-05-07 16:52:15 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:52:15 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:52:15 --> Helper loaded: form_helper
INFO - 2016-05-07 16:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:52:15 --> Form Validation Class Initialized
INFO - 2016-05-07 16:52:15 --> Controller Class Initialized
INFO - 2016-05-07 16:52:15 --> Model Class Initialized
INFO - 2016-05-07 16:52:15 --> Database Driver Class Initialized
INFO - 2016-05-07 16:52:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:52:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:52:15 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:52:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:52:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 16:52:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 16:52:15 --> Final output sent to browser
DEBUG - 2016-05-07 16:52:15 --> Total execution time: 0.0916
INFO - 2016-05-07 16:52:18 --> Config Class Initialized
INFO - 2016-05-07 16:52:18 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:52:18 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:52:18 --> Utf8 Class Initialized
INFO - 2016-05-07 16:52:18 --> URI Class Initialized
INFO - 2016-05-07 16:52:18 --> Router Class Initialized
INFO - 2016-05-07 16:52:18 --> Output Class Initialized
INFO - 2016-05-07 16:52:18 --> Security Class Initialized
DEBUG - 2016-05-07 16:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:52:18 --> Input Class Initialized
INFO - 2016-05-07 16:52:18 --> Language Class Initialized
INFO - 2016-05-07 16:52:18 --> Loader Class Initialized
INFO - 2016-05-07 16:52:18 --> Helper loaded: url_helper
INFO - 2016-05-07 16:52:18 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:52:18 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:52:18 --> Helper loaded: form_helper
INFO - 2016-05-07 16:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:52:18 --> Form Validation Class Initialized
INFO - 2016-05-07 16:52:18 --> Controller Class Initialized
INFO - 2016-05-07 16:52:18 --> Model Class Initialized
INFO - 2016-05-07 16:52:18 --> Database Driver Class Initialized
INFO - 2016-05-07 16:52:18 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:52:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:52:18 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:52:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:52:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 16:52:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 16:52:18 --> Final output sent to browser
DEBUG - 2016-05-07 16:52:18 --> Total execution time: 0.1030
INFO - 2016-05-07 16:52:20 --> Config Class Initialized
INFO - 2016-05-07 16:52:20 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:52:20 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:52:20 --> Utf8 Class Initialized
INFO - 2016-05-07 16:52:20 --> URI Class Initialized
INFO - 2016-05-07 16:52:20 --> Router Class Initialized
INFO - 2016-05-07 16:52:20 --> Output Class Initialized
INFO - 2016-05-07 16:52:20 --> Security Class Initialized
DEBUG - 2016-05-07 16:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:52:20 --> Input Class Initialized
INFO - 2016-05-07 16:52:20 --> Language Class Initialized
INFO - 2016-05-07 16:52:20 --> Loader Class Initialized
INFO - 2016-05-07 16:52:20 --> Helper loaded: url_helper
INFO - 2016-05-07 16:52:20 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:52:20 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:52:20 --> Helper loaded: form_helper
INFO - 2016-05-07 16:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:52:20 --> Form Validation Class Initialized
INFO - 2016-05-07 16:52:20 --> Controller Class Initialized
INFO - 2016-05-07 16:52:20 --> Model Class Initialized
INFO - 2016-05-07 16:52:20 --> Database Driver Class Initialized
INFO - 2016-05-07 16:52:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:52:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:52:20 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:52:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:52:20 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 16:52:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:52:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 16:52:20 --> Final output sent to browser
DEBUG - 2016-05-07 16:52:20 --> Total execution time: 0.1674
INFO - 2016-05-07 16:52:23 --> Config Class Initialized
INFO - 2016-05-07 16:52:23 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:52:23 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:52:23 --> Utf8 Class Initialized
INFO - 2016-05-07 16:52:23 --> URI Class Initialized
INFO - 2016-05-07 16:52:23 --> Router Class Initialized
INFO - 2016-05-07 16:52:23 --> Output Class Initialized
INFO - 2016-05-07 16:52:23 --> Security Class Initialized
DEBUG - 2016-05-07 16:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:52:23 --> Input Class Initialized
INFO - 2016-05-07 16:52:23 --> Language Class Initialized
INFO - 2016-05-07 16:52:23 --> Loader Class Initialized
INFO - 2016-05-07 16:52:23 --> Helper loaded: url_helper
INFO - 2016-05-07 16:52:23 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:52:23 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:52:23 --> Helper loaded: form_helper
INFO - 2016-05-07 16:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:52:23 --> Form Validation Class Initialized
INFO - 2016-05-07 16:52:23 --> Controller Class Initialized
INFO - 2016-05-07 16:52:23 --> Model Class Initialized
INFO - 2016-05-07 16:52:23 --> Database Driver Class Initialized
INFO - 2016-05-07 16:52:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:52:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:52:23 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:52:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 16:52:23 --> Severity: Notice --> Undefined variable: mensajeok C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 281
INFO - 2016-05-07 16:52:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:52:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 16:52:23 --> Final output sent to browser
DEBUG - 2016-05-07 16:52:23 --> Total execution time: 0.0973
INFO - 2016-05-07 16:52:51 --> Config Class Initialized
INFO - 2016-05-07 16:52:51 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:52:51 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:52:51 --> Utf8 Class Initialized
INFO - 2016-05-07 16:52:51 --> URI Class Initialized
INFO - 2016-05-07 16:52:51 --> Router Class Initialized
INFO - 2016-05-07 16:52:51 --> Output Class Initialized
INFO - 2016-05-07 16:52:51 --> Security Class Initialized
DEBUG - 2016-05-07 16:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:52:51 --> Input Class Initialized
INFO - 2016-05-07 16:52:51 --> Language Class Initialized
INFO - 2016-05-07 16:52:51 --> Loader Class Initialized
INFO - 2016-05-07 16:52:51 --> Helper loaded: url_helper
INFO - 2016-05-07 16:52:51 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:52:51 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:52:51 --> Helper loaded: form_helper
INFO - 2016-05-07 16:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:52:51 --> Form Validation Class Initialized
INFO - 2016-05-07 16:52:51 --> Controller Class Initialized
INFO - 2016-05-07 16:52:51 --> Model Class Initialized
INFO - 2016-05-07 16:52:51 --> Database Driver Class Initialized
INFO - 2016-05-07 16:52:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:52:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:52:51 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:52:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 16:52:51 --> Severity: Notice --> Undefined variable: mensajeok C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 283
INFO - 2016-05-07 16:52:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:52:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 16:52:51 --> Final output sent to browser
DEBUG - 2016-05-07 16:52:51 --> Total execution time: 0.0785
INFO - 2016-05-07 16:53:11 --> Config Class Initialized
INFO - 2016-05-07 16:53:11 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:53:11 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:53:11 --> Utf8 Class Initialized
INFO - 2016-05-07 16:53:11 --> URI Class Initialized
INFO - 2016-05-07 16:53:11 --> Router Class Initialized
INFO - 2016-05-07 16:53:11 --> Output Class Initialized
INFO - 2016-05-07 16:53:11 --> Security Class Initialized
DEBUG - 2016-05-07 16:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:53:11 --> Input Class Initialized
INFO - 2016-05-07 16:53:11 --> Language Class Initialized
INFO - 2016-05-07 16:53:11 --> Loader Class Initialized
INFO - 2016-05-07 16:53:11 --> Helper loaded: url_helper
INFO - 2016-05-07 16:53:11 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:53:11 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:53:11 --> Helper loaded: form_helper
INFO - 2016-05-07 16:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:53:11 --> Form Validation Class Initialized
INFO - 2016-05-07 16:53:11 --> Controller Class Initialized
INFO - 2016-05-07 16:53:11 --> Model Class Initialized
INFO - 2016-05-07 16:53:11 --> Database Driver Class Initialized
INFO - 2016-05-07 16:53:11 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:53:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:53:11 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:53:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 16:53:11 --> Severity: Notice --> Undefined variable: mensajeok C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 283
INFO - 2016-05-07 16:53:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:53:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 16:53:11 --> Final output sent to browser
DEBUG - 2016-05-07 16:53:11 --> Total execution time: 0.0766
INFO - 2016-05-07 16:53:28 --> Config Class Initialized
INFO - 2016-05-07 16:53:28 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:53:28 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:53:28 --> Utf8 Class Initialized
INFO - 2016-05-07 16:53:28 --> URI Class Initialized
INFO - 2016-05-07 16:53:28 --> Router Class Initialized
INFO - 2016-05-07 16:53:28 --> Output Class Initialized
INFO - 2016-05-07 16:53:28 --> Security Class Initialized
DEBUG - 2016-05-07 16:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:53:28 --> Input Class Initialized
INFO - 2016-05-07 16:53:28 --> Language Class Initialized
INFO - 2016-05-07 16:53:28 --> Loader Class Initialized
INFO - 2016-05-07 16:53:28 --> Helper loaded: url_helper
INFO - 2016-05-07 16:53:28 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:53:28 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:53:28 --> Helper loaded: form_helper
INFO - 2016-05-07 16:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:53:28 --> Form Validation Class Initialized
INFO - 2016-05-07 16:53:28 --> Controller Class Initialized
INFO - 2016-05-07 16:53:28 --> Model Class Initialized
INFO - 2016-05-07 16:53:28 --> Database Driver Class Initialized
INFO - 2016-05-07 16:53:28 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:53:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:53:28 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:53:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 16:53:28 --> Severity: Notice --> Undefined variable: mensajeok C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 283
INFO - 2016-05-07 16:53:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:53:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 16:53:28 --> Final output sent to browser
DEBUG - 2016-05-07 16:53:28 --> Total execution time: 0.0777
INFO - 2016-05-07 16:53:46 --> Config Class Initialized
INFO - 2016-05-07 16:53:46 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:53:46 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:53:46 --> Utf8 Class Initialized
INFO - 2016-05-07 16:53:46 --> URI Class Initialized
INFO - 2016-05-07 16:53:46 --> Router Class Initialized
INFO - 2016-05-07 16:53:46 --> Output Class Initialized
INFO - 2016-05-07 16:53:46 --> Security Class Initialized
DEBUG - 2016-05-07 16:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:53:46 --> Input Class Initialized
INFO - 2016-05-07 16:53:46 --> Language Class Initialized
INFO - 2016-05-07 16:53:46 --> Loader Class Initialized
INFO - 2016-05-07 16:53:46 --> Helper loaded: url_helper
INFO - 2016-05-07 16:53:46 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:53:46 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:53:46 --> Helper loaded: form_helper
INFO - 2016-05-07 16:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:53:46 --> Form Validation Class Initialized
INFO - 2016-05-07 16:53:46 --> Controller Class Initialized
INFO - 2016-05-07 16:53:46 --> Model Class Initialized
INFO - 2016-05-07 16:53:46 --> Database Driver Class Initialized
INFO - 2016-05-07 16:53:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:53:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:53:46 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:53:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:53:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:53:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 16:53:46 --> Final output sent to browser
DEBUG - 2016-05-07 16:53:46 --> Total execution time: 0.0774
INFO - 2016-05-07 16:53:56 --> Config Class Initialized
INFO - 2016-05-07 16:53:56 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:53:56 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:53:56 --> Utf8 Class Initialized
INFO - 2016-05-07 16:53:56 --> URI Class Initialized
INFO - 2016-05-07 16:53:56 --> Router Class Initialized
INFO - 2016-05-07 16:53:56 --> Output Class Initialized
INFO - 2016-05-07 16:53:56 --> Security Class Initialized
DEBUG - 2016-05-07 16:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:53:56 --> Input Class Initialized
INFO - 2016-05-07 16:53:56 --> Language Class Initialized
INFO - 2016-05-07 16:53:56 --> Loader Class Initialized
INFO - 2016-05-07 16:53:56 --> Helper loaded: url_helper
INFO - 2016-05-07 16:53:56 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:53:56 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:53:56 --> Helper loaded: form_helper
INFO - 2016-05-07 16:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:53:56 --> Form Validation Class Initialized
INFO - 2016-05-07 16:53:56 --> Controller Class Initialized
INFO - 2016-05-07 16:53:56 --> Model Class Initialized
INFO - 2016-05-07 16:53:56 --> Database Driver Class Initialized
INFO - 2016-05-07 16:53:56 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:53:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:53:56 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:53:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:53:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:53:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 16:53:56 --> Final output sent to browser
DEBUG - 2016-05-07 16:53:56 --> Total execution time: 0.0988
INFO - 2016-05-07 16:54:42 --> Config Class Initialized
INFO - 2016-05-07 16:54:42 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:54:42 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:54:42 --> Utf8 Class Initialized
INFO - 2016-05-07 16:54:42 --> URI Class Initialized
INFO - 2016-05-07 16:54:42 --> Router Class Initialized
INFO - 2016-05-07 16:54:42 --> Output Class Initialized
INFO - 2016-05-07 16:54:42 --> Security Class Initialized
DEBUG - 2016-05-07 16:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:54:42 --> Input Class Initialized
INFO - 2016-05-07 16:54:42 --> Language Class Initialized
INFO - 2016-05-07 16:54:42 --> Loader Class Initialized
INFO - 2016-05-07 16:54:42 --> Helper loaded: url_helper
INFO - 2016-05-07 16:54:42 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:54:42 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:54:42 --> Helper loaded: form_helper
INFO - 2016-05-07 16:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:54:42 --> Form Validation Class Initialized
INFO - 2016-05-07 16:54:42 --> Controller Class Initialized
INFO - 2016-05-07 16:54:42 --> Model Class Initialized
INFO - 2016-05-07 16:54:42 --> Database Driver Class Initialized
INFO - 2016-05-07 16:54:42 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:54:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:54:42 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:54:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:54:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:54:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 16:54:42 --> Final output sent to browser
DEBUG - 2016-05-07 16:54:42 --> Total execution time: 0.0767
INFO - 2016-05-07 16:54:51 --> Config Class Initialized
INFO - 2016-05-07 16:54:51 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:54:51 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:54:51 --> Utf8 Class Initialized
INFO - 2016-05-07 16:54:51 --> URI Class Initialized
INFO - 2016-05-07 16:54:51 --> Router Class Initialized
INFO - 2016-05-07 16:54:51 --> Output Class Initialized
INFO - 2016-05-07 16:54:51 --> Security Class Initialized
DEBUG - 2016-05-07 16:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:54:51 --> Input Class Initialized
INFO - 2016-05-07 16:54:51 --> Language Class Initialized
INFO - 2016-05-07 16:54:51 --> Loader Class Initialized
INFO - 2016-05-07 16:54:51 --> Helper loaded: url_helper
INFO - 2016-05-07 16:54:51 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:54:51 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:54:51 --> Helper loaded: form_helper
INFO - 2016-05-07 16:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:54:51 --> Form Validation Class Initialized
INFO - 2016-05-07 16:54:51 --> Controller Class Initialized
INFO - 2016-05-07 16:54:51 --> Model Class Initialized
INFO - 2016-05-07 16:54:51 --> Database Driver Class Initialized
INFO - 2016-05-07 16:54:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:54:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:54:51 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:54:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:54:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:54:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 16:54:51 --> Final output sent to browser
DEBUG - 2016-05-07 16:54:51 --> Total execution time: 0.0985
INFO - 2016-05-07 16:54:56 --> Config Class Initialized
INFO - 2016-05-07 16:54:56 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:54:56 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:54:56 --> Utf8 Class Initialized
INFO - 2016-05-07 16:54:56 --> URI Class Initialized
INFO - 2016-05-07 16:54:56 --> Router Class Initialized
INFO - 2016-05-07 16:54:56 --> Output Class Initialized
INFO - 2016-05-07 16:54:56 --> Security Class Initialized
DEBUG - 2016-05-07 16:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:54:56 --> Input Class Initialized
INFO - 2016-05-07 16:54:56 --> Language Class Initialized
INFO - 2016-05-07 16:54:56 --> Loader Class Initialized
INFO - 2016-05-07 16:54:56 --> Helper loaded: url_helper
INFO - 2016-05-07 16:54:56 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:54:56 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:54:56 --> Helper loaded: form_helper
INFO - 2016-05-07 16:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:54:56 --> Form Validation Class Initialized
INFO - 2016-05-07 16:54:56 --> Controller Class Initialized
INFO - 2016-05-07 16:54:56 --> Model Class Initialized
INFO - 2016-05-07 16:54:56 --> Database Driver Class Initialized
INFO - 2016-05-07 16:54:56 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:54:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:54:56 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:54:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:54:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:54:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 16:54:56 --> Final output sent to browser
DEBUG - 2016-05-07 16:54:56 --> Total execution time: 0.0955
INFO - 2016-05-07 16:55:47 --> Config Class Initialized
INFO - 2016-05-07 16:55:47 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:55:47 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:55:47 --> Utf8 Class Initialized
INFO - 2016-05-07 16:55:47 --> URI Class Initialized
INFO - 2016-05-07 16:55:47 --> Router Class Initialized
INFO - 2016-05-07 16:55:47 --> Output Class Initialized
INFO - 2016-05-07 16:55:47 --> Security Class Initialized
DEBUG - 2016-05-07 16:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:55:47 --> Input Class Initialized
INFO - 2016-05-07 16:55:47 --> Language Class Initialized
INFO - 2016-05-07 16:55:47 --> Loader Class Initialized
INFO - 2016-05-07 16:55:47 --> Helper loaded: url_helper
INFO - 2016-05-07 16:55:47 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:55:47 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:55:47 --> Helper loaded: form_helper
INFO - 2016-05-07 16:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:55:47 --> Form Validation Class Initialized
INFO - 2016-05-07 16:55:47 --> Controller Class Initialized
INFO - 2016-05-07 16:55:47 --> Model Class Initialized
INFO - 2016-05-07 16:55:47 --> Database Driver Class Initialized
INFO - 2016-05-07 16:55:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:55:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:55:47 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:55:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:55:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:55:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 16:55:47 --> Final output sent to browser
DEBUG - 2016-05-07 16:55:47 --> Total execution time: 0.0763
INFO - 2016-05-07 16:58:22 --> Config Class Initialized
INFO - 2016-05-07 16:58:22 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:58:22 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:58:22 --> Utf8 Class Initialized
INFO - 2016-05-07 16:58:22 --> URI Class Initialized
INFO - 2016-05-07 16:58:22 --> Router Class Initialized
INFO - 2016-05-07 16:58:22 --> Output Class Initialized
INFO - 2016-05-07 16:58:22 --> Security Class Initialized
DEBUG - 2016-05-07 16:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:58:22 --> Input Class Initialized
INFO - 2016-05-07 16:58:22 --> Language Class Initialized
ERROR - 2016-05-07 16:58:22 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 260
INFO - 2016-05-07 16:58:41 --> Config Class Initialized
INFO - 2016-05-07 16:58:41 --> Hooks Class Initialized
DEBUG - 2016-05-07 16:58:41 --> UTF-8 Support Enabled
INFO - 2016-05-07 16:58:41 --> Utf8 Class Initialized
INFO - 2016-05-07 16:58:41 --> URI Class Initialized
INFO - 2016-05-07 16:58:41 --> Router Class Initialized
INFO - 2016-05-07 16:58:41 --> Output Class Initialized
INFO - 2016-05-07 16:58:41 --> Security Class Initialized
DEBUG - 2016-05-07 16:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 16:58:41 --> Input Class Initialized
INFO - 2016-05-07 16:58:41 --> Language Class Initialized
INFO - 2016-05-07 16:58:41 --> Loader Class Initialized
INFO - 2016-05-07 16:58:41 --> Helper loaded: url_helper
INFO - 2016-05-07 16:58:41 --> Helper loaded: sesion_helper
INFO - 2016-05-07 16:58:41 --> Helper loaded: templates_helper
INFO - 2016-05-07 16:58:41 --> Helper loaded: form_helper
INFO - 2016-05-07 16:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 16:58:41 --> Form Validation Class Initialized
INFO - 2016-05-07 16:58:41 --> Controller Class Initialized
INFO - 2016-05-07 16:58:41 --> Model Class Initialized
INFO - 2016-05-07 16:58:41 --> Database Driver Class Initialized
INFO - 2016-05-07 16:58:41 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 16:58:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 16:58:41 --> Pagination Class Initialized
DEBUG - 2016-05-07 16:58:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 16:58:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 16:58:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 16:58:41 --> Final output sent to browser
DEBUG - 2016-05-07 16:58:41 --> Total execution time: 0.0774
INFO - 2016-05-07 17:07:32 --> Config Class Initialized
INFO - 2016-05-07 17:07:32 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:07:32 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:07:32 --> Utf8 Class Initialized
INFO - 2016-05-07 17:07:32 --> URI Class Initialized
INFO - 2016-05-07 17:07:32 --> Router Class Initialized
INFO - 2016-05-07 17:07:32 --> Output Class Initialized
INFO - 2016-05-07 17:07:32 --> Security Class Initialized
DEBUG - 2016-05-07 17:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:07:32 --> Input Class Initialized
INFO - 2016-05-07 17:07:32 --> Language Class Initialized
INFO - 2016-05-07 17:07:32 --> Loader Class Initialized
INFO - 2016-05-07 17:07:32 --> Helper loaded: url_helper
INFO - 2016-05-07 17:07:32 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:07:32 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:07:32 --> Helper loaded: form_helper
INFO - 2016-05-07 17:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:07:32 --> Form Validation Class Initialized
INFO - 2016-05-07 17:07:32 --> Controller Class Initialized
INFO - 2016-05-07 17:07:32 --> Model Class Initialized
INFO - 2016-05-07 17:07:32 --> Database Driver Class Initialized
INFO - 2016-05-07 17:07:32 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:07:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:07:32 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:07:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:07:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:07:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:07:32 --> Final output sent to browser
DEBUG - 2016-05-07 17:07:32 --> Total execution time: 0.0721
INFO - 2016-05-07 17:07:48 --> Config Class Initialized
INFO - 2016-05-07 17:07:48 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:07:48 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:07:48 --> Utf8 Class Initialized
INFO - 2016-05-07 17:07:48 --> URI Class Initialized
INFO - 2016-05-07 17:07:48 --> Router Class Initialized
INFO - 2016-05-07 17:07:48 --> Output Class Initialized
INFO - 2016-05-07 17:07:48 --> Security Class Initialized
DEBUG - 2016-05-07 17:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:07:48 --> Input Class Initialized
INFO - 2016-05-07 17:07:48 --> Language Class Initialized
INFO - 2016-05-07 17:07:48 --> Loader Class Initialized
INFO - 2016-05-07 17:07:48 --> Helper loaded: url_helper
INFO - 2016-05-07 17:07:48 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:07:48 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:07:48 --> Helper loaded: form_helper
INFO - 2016-05-07 17:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:07:48 --> Form Validation Class Initialized
INFO - 2016-05-07 17:07:48 --> Controller Class Initialized
INFO - 2016-05-07 17:07:48 --> Model Class Initialized
INFO - 2016-05-07 17:07:48 --> Database Driver Class Initialized
INFO - 2016-05-07 17:07:48 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:07:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:07:48 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:07:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:07:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:07:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:07:48 --> Final output sent to browser
DEBUG - 2016-05-07 17:07:48 --> Total execution time: 0.0764
INFO - 2016-05-07 17:07:52 --> Config Class Initialized
INFO - 2016-05-07 17:07:52 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:07:52 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:07:52 --> Utf8 Class Initialized
INFO - 2016-05-07 17:07:52 --> URI Class Initialized
INFO - 2016-05-07 17:07:52 --> Router Class Initialized
INFO - 2016-05-07 17:07:52 --> Output Class Initialized
INFO - 2016-05-07 17:07:52 --> Security Class Initialized
DEBUG - 2016-05-07 17:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:07:52 --> Input Class Initialized
INFO - 2016-05-07 17:07:52 --> Language Class Initialized
INFO - 2016-05-07 17:07:52 --> Loader Class Initialized
INFO - 2016-05-07 17:07:52 --> Helper loaded: url_helper
INFO - 2016-05-07 17:07:52 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:07:52 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:07:52 --> Helper loaded: form_helper
INFO - 2016-05-07 17:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:07:52 --> Form Validation Class Initialized
INFO - 2016-05-07 17:07:52 --> Controller Class Initialized
INFO - 2016-05-07 17:07:52 --> Model Class Initialized
INFO - 2016-05-07 17:07:52 --> Database Driver Class Initialized
INFO - 2016-05-07 17:07:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:07:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:07:52 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:07:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 17:07:52 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 280
ERROR - 2016-05-07 17:07:52 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: UPDATE `producto` SET `nombre` = 'SAMSUNG GALAXY J5', `marca` = 'Samsung', `precio` = '150.00', `precio_venta` = '297.68', `iva` = '22.00', `stock` = '15', `categoria` = 'Smartphones', `proveedor` = 'InfoTelwi', `idCategoria` = '2', `idProveedor` = '2', `descripcion` = '', `imagen` = 'samsunggalaxy.jpg'
WHERE `idproducto` IS NULL
INFO - 2016-05-07 17:07:52 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 17:10:04 --> Config Class Initialized
INFO - 2016-05-07 17:10:04 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:10:04 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:10:04 --> Utf8 Class Initialized
INFO - 2016-05-07 17:10:04 --> URI Class Initialized
INFO - 2016-05-07 17:10:04 --> Router Class Initialized
INFO - 2016-05-07 17:10:04 --> Output Class Initialized
INFO - 2016-05-07 17:10:04 --> Security Class Initialized
DEBUG - 2016-05-07 17:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:10:04 --> Input Class Initialized
INFO - 2016-05-07 17:10:04 --> Language Class Initialized
INFO - 2016-05-07 17:10:04 --> Loader Class Initialized
INFO - 2016-05-07 17:10:04 --> Helper loaded: url_helper
INFO - 2016-05-07 17:10:04 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:10:04 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:10:04 --> Helper loaded: form_helper
INFO - 2016-05-07 17:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:10:04 --> Form Validation Class Initialized
INFO - 2016-05-07 17:10:04 --> Controller Class Initialized
INFO - 2016-05-07 17:10:04 --> Model Class Initialized
INFO - 2016-05-07 17:10:04 --> Database Driver Class Initialized
INFO - 2016-05-07 17:10:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:10:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:10:04 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:10:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 17:10:04 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 294
ERROR - 2016-05-07 17:10:04 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: UPDATE `producto` SET `nombre` = 'SAMSUNG GALAXY J5', `marca` = 'Samsung', `precio` = '150.00', `precio_venta` = '297.68', `iva` = '22.00', `stock` = '15', `categoria` = 'Smartphones', `proveedor` = 'InfoTelwi', `idCategoria` = '2', `idProveedor` = '2', `descripcion` = '', `imagen` = 'samsunggalaxy.jpg'
WHERE `idproducto` IS NULL
INFO - 2016-05-07 17:10:04 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 17:11:13 --> Config Class Initialized
INFO - 2016-05-07 17:11:13 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:11:13 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:11:13 --> Utf8 Class Initialized
INFO - 2016-05-07 17:11:13 --> URI Class Initialized
INFO - 2016-05-07 17:11:13 --> Router Class Initialized
INFO - 2016-05-07 17:11:13 --> Output Class Initialized
INFO - 2016-05-07 17:11:13 --> Security Class Initialized
DEBUG - 2016-05-07 17:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:11:13 --> Input Class Initialized
INFO - 2016-05-07 17:11:13 --> Language Class Initialized
INFO - 2016-05-07 17:11:13 --> Loader Class Initialized
INFO - 2016-05-07 17:11:13 --> Helper loaded: url_helper
INFO - 2016-05-07 17:11:13 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:11:13 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:11:13 --> Helper loaded: form_helper
INFO - 2016-05-07 17:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:11:13 --> Form Validation Class Initialized
INFO - 2016-05-07 17:11:13 --> Controller Class Initialized
INFO - 2016-05-07 17:11:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-07 17:11:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:11:13 --> Final output sent to browser
DEBUG - 2016-05-07 17:11:13 --> Total execution time: 0.0707
INFO - 2016-05-07 17:11:16 --> Config Class Initialized
INFO - 2016-05-07 17:11:16 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:11:16 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:11:16 --> Utf8 Class Initialized
INFO - 2016-05-07 17:11:16 --> URI Class Initialized
INFO - 2016-05-07 17:11:16 --> Router Class Initialized
INFO - 2016-05-07 17:11:16 --> Output Class Initialized
INFO - 2016-05-07 17:11:16 --> Security Class Initialized
DEBUG - 2016-05-07 17:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:11:16 --> Input Class Initialized
INFO - 2016-05-07 17:11:16 --> Language Class Initialized
INFO - 2016-05-07 17:11:16 --> Loader Class Initialized
INFO - 2016-05-07 17:11:16 --> Helper loaded: url_helper
INFO - 2016-05-07 17:11:16 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:11:16 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:11:16 --> Helper loaded: form_helper
INFO - 2016-05-07 17:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:11:16 --> Form Validation Class Initialized
INFO - 2016-05-07 17:11:16 --> Controller Class Initialized
INFO - 2016-05-07 17:11:16 --> Model Class Initialized
INFO - 2016-05-07 17:11:16 --> Database Driver Class Initialized
INFO - 2016-05-07 17:11:16 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:11:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:11:16 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:11:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:11:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:11:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:11:16 --> Final output sent to browser
DEBUG - 2016-05-07 17:11:16 --> Total execution time: 0.1150
INFO - 2016-05-07 17:11:19 --> Config Class Initialized
INFO - 2016-05-07 17:11:19 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:11:19 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:11:19 --> Utf8 Class Initialized
INFO - 2016-05-07 17:11:19 --> URI Class Initialized
INFO - 2016-05-07 17:11:19 --> Router Class Initialized
INFO - 2016-05-07 17:11:19 --> Output Class Initialized
INFO - 2016-05-07 17:11:19 --> Security Class Initialized
DEBUG - 2016-05-07 17:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:11:19 --> Input Class Initialized
INFO - 2016-05-07 17:11:19 --> Language Class Initialized
INFO - 2016-05-07 17:11:19 --> Loader Class Initialized
INFO - 2016-05-07 17:11:19 --> Helper loaded: url_helper
INFO - 2016-05-07 17:11:19 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:11:19 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:11:19 --> Helper loaded: form_helper
INFO - 2016-05-07 17:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:11:19 --> Form Validation Class Initialized
INFO - 2016-05-07 17:11:19 --> Controller Class Initialized
INFO - 2016-05-07 17:11:19 --> Model Class Initialized
INFO - 2016-05-07 17:11:19 --> Database Driver Class Initialized
INFO - 2016-05-07 17:11:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:11:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:11:19 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:11:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:11:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 17:11:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:11:19 --> Final output sent to browser
DEBUG - 2016-05-07 17:11:19 --> Total execution time: 0.1103
INFO - 2016-05-07 17:11:21 --> Config Class Initialized
INFO - 2016-05-07 17:11:21 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:11:21 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:11:21 --> Utf8 Class Initialized
INFO - 2016-05-07 17:11:21 --> URI Class Initialized
INFO - 2016-05-07 17:11:21 --> Router Class Initialized
INFO - 2016-05-07 17:11:21 --> Output Class Initialized
INFO - 2016-05-07 17:11:21 --> Security Class Initialized
DEBUG - 2016-05-07 17:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:11:21 --> Input Class Initialized
INFO - 2016-05-07 17:11:21 --> Language Class Initialized
INFO - 2016-05-07 17:11:21 --> Loader Class Initialized
INFO - 2016-05-07 17:11:22 --> Helper loaded: url_helper
INFO - 2016-05-07 17:11:22 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:11:22 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:11:22 --> Helper loaded: form_helper
INFO - 2016-05-07 17:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:11:22 --> Form Validation Class Initialized
INFO - 2016-05-07 17:11:22 --> Controller Class Initialized
INFO - 2016-05-07 17:11:22 --> Model Class Initialized
INFO - 2016-05-07 17:11:22 --> Database Driver Class Initialized
INFO - 2016-05-07 17:11:22 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:11:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:11:22 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:11:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:11:22 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 17:11:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:11:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:11:22 --> Final output sent to browser
DEBUG - 2016-05-07 17:11:22 --> Total execution time: 0.1499
INFO - 2016-05-07 17:11:29 --> Config Class Initialized
INFO - 2016-05-07 17:11:29 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:11:29 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:11:29 --> Utf8 Class Initialized
INFO - 2016-05-07 17:11:29 --> URI Class Initialized
INFO - 2016-05-07 17:11:29 --> Router Class Initialized
INFO - 2016-05-07 17:11:29 --> Output Class Initialized
INFO - 2016-05-07 17:11:29 --> Security Class Initialized
DEBUG - 2016-05-07 17:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:11:29 --> Input Class Initialized
INFO - 2016-05-07 17:11:29 --> Language Class Initialized
INFO - 2016-05-07 17:11:29 --> Loader Class Initialized
INFO - 2016-05-07 17:11:29 --> Helper loaded: url_helper
INFO - 2016-05-07 17:11:29 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:11:29 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:11:29 --> Helper loaded: form_helper
INFO - 2016-05-07 17:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:11:29 --> Form Validation Class Initialized
INFO - 2016-05-07 17:11:29 --> Controller Class Initialized
INFO - 2016-05-07 17:11:29 --> Model Class Initialized
INFO - 2016-05-07 17:11:29 --> Database Driver Class Initialized
INFO - 2016-05-07 17:11:29 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:11:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:11:29 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:11:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 17:11:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 295
ERROR - 2016-05-07 17:11:29 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: UPDATE `producto` SET `nombre` = 'HP Hardaily', `marca` = 'HP', `precio` = '400.00', `precio_venta` = '700.00', `iva` = '21.00', `stock` = '63', `categoria` = 'Ordenadores de Sobremesa', `proveedor` = 'Movelia', `idCategoria` = '5', `idProveedor` = '11', `descripcion` = 'Windows 10\r\nProcesador Intel® Core™ i3-4170T\r\nGráficos Intel HD Graphics 4400\r\nMemoria 4 GB DDR3L (1 x 4 GB)\r\nDisco duro SATA de 1 TB 7200 rpm\r\nUn año ilimitado, piezas, mano de obra y servicio de entrega y devolución', `imagen` = '1462473411_hp-pc-hardaily.jpg', `idProducto` = '20'
WHERE `idproducto` IS NULL
INFO - 2016-05-07 17:11:29 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 17:13:02 --> Config Class Initialized
INFO - 2016-05-07 17:13:02 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:13:02 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:13:02 --> Utf8 Class Initialized
INFO - 2016-05-07 17:13:02 --> URI Class Initialized
INFO - 2016-05-07 17:13:02 --> Router Class Initialized
INFO - 2016-05-07 17:13:02 --> Output Class Initialized
INFO - 2016-05-07 17:13:02 --> Security Class Initialized
DEBUG - 2016-05-07 17:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:13:02 --> Input Class Initialized
INFO - 2016-05-07 17:13:02 --> Language Class Initialized
INFO - 2016-05-07 17:13:02 --> Loader Class Initialized
INFO - 2016-05-07 17:13:02 --> Helper loaded: url_helper
INFO - 2016-05-07 17:13:02 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:13:02 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:13:02 --> Helper loaded: form_helper
INFO - 2016-05-07 17:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:13:02 --> Form Validation Class Initialized
INFO - 2016-05-07 17:13:02 --> Controller Class Initialized
INFO - 2016-05-07 17:13:02 --> Model Class Initialized
INFO - 2016-05-07 17:13:02 --> Database Driver Class Initialized
INFO - 2016-05-07 17:13:02 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:13:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:13:02 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:13:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 17:13:02 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: UPDATE `producto` SET `nombre` = 'HP Hardaily', `marca` = 'HP', `precio` = '400.00', `precio_venta` = '700.00', `iva` = '21.00', `stock` = '63', `categoria` = 'Ordenadores de Sobremesa', `proveedor` = 'Movelia', `idCategoria` = '5', `idProveedor` = '11', `descripcion` = 'Windows 10\r\nProcesador Intel® Core™ i3-4170T\r\nGráficos Intel HD Graphics 4400\r\nMemoria 4 GB DDR3L (1 x 4 GB)\r\nDisco duro SATA de 1 TB 7200 rpm\r\nUn año ilimitado, piezas, mano de obra y servicio de entrega y devolución', `imagen` = '1462473411_hp-pc-hardaily.jpg', `idProducto` = '20'
WHERE `idproducto` = '20'
INFO - 2016-05-07 17:13:02 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 17:13:37 --> Config Class Initialized
INFO - 2016-05-07 17:13:37 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:13:37 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:13:37 --> Utf8 Class Initialized
INFO - 2016-05-07 17:13:37 --> URI Class Initialized
INFO - 2016-05-07 17:13:37 --> Router Class Initialized
INFO - 2016-05-07 17:13:37 --> Output Class Initialized
INFO - 2016-05-07 17:13:37 --> Security Class Initialized
DEBUG - 2016-05-07 17:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:13:37 --> Input Class Initialized
INFO - 2016-05-07 17:13:37 --> Language Class Initialized
INFO - 2016-05-07 17:13:37 --> Loader Class Initialized
INFO - 2016-05-07 17:13:37 --> Helper loaded: url_helper
INFO - 2016-05-07 17:13:37 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:13:37 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:13:37 --> Helper loaded: form_helper
INFO - 2016-05-07 17:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:13:37 --> Form Validation Class Initialized
INFO - 2016-05-07 17:13:37 --> Controller Class Initialized
INFO - 2016-05-07 17:13:37 --> Model Class Initialized
INFO - 2016-05-07 17:13:37 --> Database Driver Class Initialized
INFO - 2016-05-07 17:13:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:13:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:13:37 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:13:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:13:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:13:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
ERROR - 2016-05-07 17:13:37 --> Severity: Notice --> Undefined variable: error_img C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 282
INFO - 2016-05-07 17:13:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:13:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:13:37 --> Final output sent to browser
DEBUG - 2016-05-07 17:13:37 --> Total execution time: 0.1759
INFO - 2016-05-07 17:14:14 --> Config Class Initialized
INFO - 2016-05-07 17:14:14 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:14:14 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:14:14 --> Utf8 Class Initialized
INFO - 2016-05-07 17:14:14 --> URI Class Initialized
INFO - 2016-05-07 17:14:14 --> Router Class Initialized
INFO - 2016-05-07 17:14:14 --> Output Class Initialized
INFO - 2016-05-07 17:14:14 --> Security Class Initialized
DEBUG - 2016-05-07 17:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:14:14 --> Input Class Initialized
INFO - 2016-05-07 17:14:14 --> Language Class Initialized
INFO - 2016-05-07 17:14:14 --> Loader Class Initialized
INFO - 2016-05-07 17:14:14 --> Helper loaded: url_helper
INFO - 2016-05-07 17:14:14 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:14:14 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:14:14 --> Helper loaded: form_helper
INFO - 2016-05-07 17:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:14:14 --> Form Validation Class Initialized
INFO - 2016-05-07 17:14:14 --> Controller Class Initialized
INFO - 2016-05-07 17:14:14 --> Model Class Initialized
INFO - 2016-05-07 17:14:14 --> Database Driver Class Initialized
INFO - 2016-05-07 17:14:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:14:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:14:14 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:14:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 17:14:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 287
ERROR - 2016-05-07 17:14:14 --> Severity: Notice --> Undefined variable: datos C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 292
INFO - 2016-05-07 17:14:14 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 17:15:03 --> Config Class Initialized
INFO - 2016-05-07 17:15:03 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:15:03 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:15:03 --> Utf8 Class Initialized
INFO - 2016-05-07 17:15:03 --> URI Class Initialized
INFO - 2016-05-07 17:15:03 --> Router Class Initialized
INFO - 2016-05-07 17:15:03 --> Output Class Initialized
INFO - 2016-05-07 17:15:03 --> Security Class Initialized
DEBUG - 2016-05-07 17:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:15:03 --> Input Class Initialized
INFO - 2016-05-07 17:15:03 --> Language Class Initialized
INFO - 2016-05-07 17:15:03 --> Loader Class Initialized
INFO - 2016-05-07 17:15:03 --> Helper loaded: url_helper
INFO - 2016-05-07 17:15:03 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:15:03 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:15:03 --> Helper loaded: form_helper
INFO - 2016-05-07 17:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:15:03 --> Form Validation Class Initialized
INFO - 2016-05-07 17:15:03 --> Controller Class Initialized
INFO - 2016-05-07 17:15:03 --> Model Class Initialized
INFO - 2016-05-07 17:15:03 --> Database Driver Class Initialized
INFO - 2016-05-07 17:15:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:15:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:15:03 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:15:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 17:15:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 288
ERROR - 2016-05-07 17:15:03 --> Severity: Notice --> Undefined variable: datos C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 293
INFO - 2016-05-07 17:15:03 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 17:15:06 --> Config Class Initialized
INFO - 2016-05-07 17:15:06 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:15:06 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:15:06 --> Utf8 Class Initialized
INFO - 2016-05-07 17:15:06 --> URI Class Initialized
INFO - 2016-05-07 17:15:06 --> Router Class Initialized
INFO - 2016-05-07 17:15:06 --> Output Class Initialized
INFO - 2016-05-07 17:15:06 --> Security Class Initialized
DEBUG - 2016-05-07 17:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:15:06 --> Input Class Initialized
INFO - 2016-05-07 17:15:06 --> Language Class Initialized
INFO - 2016-05-07 17:15:06 --> Loader Class Initialized
INFO - 2016-05-07 17:15:06 --> Helper loaded: url_helper
INFO - 2016-05-07 17:15:06 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:15:06 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:15:06 --> Helper loaded: form_helper
INFO - 2016-05-07 17:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:15:06 --> Form Validation Class Initialized
INFO - 2016-05-07 17:15:06 --> Controller Class Initialized
INFO - 2016-05-07 17:15:06 --> Model Class Initialized
INFO - 2016-05-07 17:15:06 --> Database Driver Class Initialized
INFO - 2016-05-07 17:15:06 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:15:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:15:06 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:15:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 17:15:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 288
ERROR - 2016-05-07 17:15:06 --> Severity: Notice --> Undefined variable: datos C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 293
INFO - 2016-05-07 17:15:06 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 17:15:20 --> Config Class Initialized
INFO - 2016-05-07 17:15:21 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:15:21 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:15:21 --> Utf8 Class Initialized
INFO - 2016-05-07 17:15:21 --> URI Class Initialized
INFO - 2016-05-07 17:15:21 --> Router Class Initialized
INFO - 2016-05-07 17:15:21 --> Output Class Initialized
INFO - 2016-05-07 17:15:21 --> Security Class Initialized
DEBUG - 2016-05-07 17:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:15:21 --> Input Class Initialized
INFO - 2016-05-07 17:15:21 --> Language Class Initialized
INFO - 2016-05-07 17:15:21 --> Loader Class Initialized
INFO - 2016-05-07 17:15:21 --> Helper loaded: url_helper
INFO - 2016-05-07 17:15:21 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:15:21 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:15:21 --> Helper loaded: form_helper
INFO - 2016-05-07 17:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:15:21 --> Form Validation Class Initialized
INFO - 2016-05-07 17:15:21 --> Controller Class Initialized
INFO - 2016-05-07 17:15:21 --> Model Class Initialized
INFO - 2016-05-07 17:15:21 --> Database Driver Class Initialized
INFO - 2016-05-07 17:15:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:15:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:15:21 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:15:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 17:15:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 288
ERROR - 2016-05-07 17:15:21 --> Severity: Notice --> Undefined variable: datos C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 293
INFO - 2016-05-07 17:15:21 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 17:15:38 --> Config Class Initialized
INFO - 2016-05-07 17:15:38 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:15:38 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:15:38 --> Utf8 Class Initialized
INFO - 2016-05-07 17:15:38 --> URI Class Initialized
INFO - 2016-05-07 17:15:38 --> Router Class Initialized
INFO - 2016-05-07 17:15:38 --> Output Class Initialized
INFO - 2016-05-07 17:15:38 --> Security Class Initialized
DEBUG - 2016-05-07 17:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:15:38 --> Input Class Initialized
INFO - 2016-05-07 17:15:38 --> Language Class Initialized
INFO - 2016-05-07 17:15:38 --> Loader Class Initialized
INFO - 2016-05-07 17:15:38 --> Helper loaded: url_helper
INFO - 2016-05-07 17:15:38 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:15:38 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:15:38 --> Helper loaded: form_helper
INFO - 2016-05-07 17:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:15:38 --> Form Validation Class Initialized
INFO - 2016-05-07 17:15:38 --> Controller Class Initialized
INFO - 2016-05-07 17:15:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-07 17:15:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:15:38 --> Final output sent to browser
DEBUG - 2016-05-07 17:15:38 --> Total execution time: 0.0540
INFO - 2016-05-07 17:15:40 --> Config Class Initialized
INFO - 2016-05-07 17:15:40 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:15:40 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:15:40 --> Utf8 Class Initialized
INFO - 2016-05-07 17:15:40 --> URI Class Initialized
INFO - 2016-05-07 17:15:40 --> Router Class Initialized
INFO - 2016-05-07 17:15:40 --> Output Class Initialized
INFO - 2016-05-07 17:15:40 --> Security Class Initialized
DEBUG - 2016-05-07 17:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:15:40 --> Input Class Initialized
INFO - 2016-05-07 17:15:40 --> Language Class Initialized
INFO - 2016-05-07 17:15:40 --> Loader Class Initialized
INFO - 2016-05-07 17:15:40 --> Helper loaded: url_helper
INFO - 2016-05-07 17:15:40 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:15:40 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:15:40 --> Helper loaded: form_helper
INFO - 2016-05-07 17:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:15:40 --> Form Validation Class Initialized
INFO - 2016-05-07 17:15:40 --> Controller Class Initialized
INFO - 2016-05-07 17:15:40 --> Model Class Initialized
INFO - 2016-05-07 17:15:40 --> Database Driver Class Initialized
INFO - 2016-05-07 17:15:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:15:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:15:40 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:15:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:15:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:15:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:15:40 --> Final output sent to browser
DEBUG - 2016-05-07 17:15:40 --> Total execution time: 0.1046
INFO - 2016-05-07 17:15:43 --> Config Class Initialized
INFO - 2016-05-07 17:15:43 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:15:43 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:15:43 --> Utf8 Class Initialized
INFO - 2016-05-07 17:15:43 --> URI Class Initialized
INFO - 2016-05-07 17:15:43 --> Router Class Initialized
INFO - 2016-05-07 17:15:43 --> Output Class Initialized
INFO - 2016-05-07 17:15:43 --> Security Class Initialized
DEBUG - 2016-05-07 17:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:15:43 --> Input Class Initialized
INFO - 2016-05-07 17:15:43 --> Language Class Initialized
INFO - 2016-05-07 17:15:43 --> Loader Class Initialized
INFO - 2016-05-07 17:15:43 --> Helper loaded: url_helper
INFO - 2016-05-07 17:15:43 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:15:43 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:15:43 --> Helper loaded: form_helper
INFO - 2016-05-07 17:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:15:43 --> Form Validation Class Initialized
INFO - 2016-05-07 17:15:43 --> Controller Class Initialized
INFO - 2016-05-07 17:15:43 --> Model Class Initialized
INFO - 2016-05-07 17:15:43 --> Database Driver Class Initialized
INFO - 2016-05-07 17:15:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:15:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:15:43 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:15:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:15:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 17:15:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:15:43 --> Final output sent to browser
DEBUG - 2016-05-07 17:15:43 --> Total execution time: 0.1689
INFO - 2016-05-07 17:15:45 --> Config Class Initialized
INFO - 2016-05-07 17:15:45 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:15:45 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:15:45 --> Utf8 Class Initialized
INFO - 2016-05-07 17:15:45 --> URI Class Initialized
INFO - 2016-05-07 17:15:45 --> Router Class Initialized
INFO - 2016-05-07 17:15:45 --> Output Class Initialized
INFO - 2016-05-07 17:15:45 --> Security Class Initialized
DEBUG - 2016-05-07 17:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:15:45 --> Input Class Initialized
INFO - 2016-05-07 17:15:45 --> Language Class Initialized
INFO - 2016-05-07 17:15:45 --> Loader Class Initialized
INFO - 2016-05-07 17:15:45 --> Helper loaded: url_helper
INFO - 2016-05-07 17:15:45 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:15:46 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:15:46 --> Helper loaded: form_helper
INFO - 2016-05-07 17:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:15:46 --> Form Validation Class Initialized
INFO - 2016-05-07 17:15:46 --> Controller Class Initialized
INFO - 2016-05-07 17:15:46 --> Model Class Initialized
INFO - 2016-05-07 17:15:46 --> Database Driver Class Initialized
INFO - 2016-05-07 17:15:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:15:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:15:46 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:15:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:15:46 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 17:15:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:15:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:15:46 --> Final output sent to browser
DEBUG - 2016-05-07 17:15:46 --> Total execution time: 0.1207
INFO - 2016-05-07 17:15:49 --> Config Class Initialized
INFO - 2016-05-07 17:15:49 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:15:49 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:15:49 --> Utf8 Class Initialized
INFO - 2016-05-07 17:15:49 --> URI Class Initialized
INFO - 2016-05-07 17:15:49 --> Router Class Initialized
INFO - 2016-05-07 17:15:49 --> Output Class Initialized
INFO - 2016-05-07 17:15:49 --> Security Class Initialized
DEBUG - 2016-05-07 17:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:15:49 --> Input Class Initialized
INFO - 2016-05-07 17:15:49 --> Language Class Initialized
INFO - 2016-05-07 17:15:49 --> Loader Class Initialized
INFO - 2016-05-07 17:15:49 --> Helper loaded: url_helper
INFO - 2016-05-07 17:15:49 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:15:49 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:15:49 --> Helper loaded: form_helper
INFO - 2016-05-07 17:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:15:49 --> Form Validation Class Initialized
INFO - 2016-05-07 17:15:49 --> Controller Class Initialized
INFO - 2016-05-07 17:15:49 --> Model Class Initialized
INFO - 2016-05-07 17:15:49 --> Database Driver Class Initialized
INFO - 2016-05-07 17:15:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:15:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:15:49 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:15:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:15:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:15:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:15:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:15:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:15:49 --> Final output sent to browser
DEBUG - 2016-05-07 17:15:49 --> Total execution time: 0.1688
INFO - 2016-05-07 17:16:35 --> Config Class Initialized
INFO - 2016-05-07 17:16:35 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:16:35 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:16:35 --> Utf8 Class Initialized
INFO - 2016-05-07 17:16:35 --> URI Class Initialized
INFO - 2016-05-07 17:16:35 --> Router Class Initialized
INFO - 2016-05-07 17:16:35 --> Output Class Initialized
INFO - 2016-05-07 17:16:35 --> Security Class Initialized
DEBUG - 2016-05-07 17:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:16:35 --> Input Class Initialized
INFO - 2016-05-07 17:16:35 --> Language Class Initialized
INFO - 2016-05-07 17:16:35 --> Loader Class Initialized
INFO - 2016-05-07 17:16:35 --> Helper loaded: url_helper
INFO - 2016-05-07 17:16:35 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:16:35 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:16:35 --> Helper loaded: form_helper
INFO - 2016-05-07 17:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:16:35 --> Form Validation Class Initialized
INFO - 2016-05-07 17:16:35 --> Controller Class Initialized
INFO - 2016-05-07 17:16:35 --> Model Class Initialized
INFO - 2016-05-07 17:16:35 --> Database Driver Class Initialized
INFO - 2016-05-07 17:16:35 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:16:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:16:35 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:16:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 17:16:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 287
ERROR - 2016-05-07 17:16:35 --> Severity: Notice --> Undefined variable: datos C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 292
INFO - 2016-05-07 17:16:35 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 17:16:39 --> Config Class Initialized
INFO - 2016-05-07 17:16:39 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:16:39 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:16:39 --> Utf8 Class Initialized
INFO - 2016-05-07 17:16:39 --> URI Class Initialized
INFO - 2016-05-07 17:16:39 --> Router Class Initialized
INFO - 2016-05-07 17:16:39 --> Output Class Initialized
INFO - 2016-05-07 17:16:39 --> Security Class Initialized
DEBUG - 2016-05-07 17:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:16:39 --> Input Class Initialized
INFO - 2016-05-07 17:16:39 --> Language Class Initialized
INFO - 2016-05-07 17:16:39 --> Loader Class Initialized
INFO - 2016-05-07 17:16:39 --> Helper loaded: url_helper
INFO - 2016-05-07 17:16:39 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:16:39 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:16:39 --> Helper loaded: form_helper
INFO - 2016-05-07 17:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:16:39 --> Form Validation Class Initialized
INFO - 2016-05-07 17:16:39 --> Controller Class Initialized
INFO - 2016-05-07 17:16:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-07 17:16:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:16:39 --> Final output sent to browser
DEBUG - 2016-05-07 17:16:39 --> Total execution time: 0.0513
INFO - 2016-05-07 17:16:42 --> Config Class Initialized
INFO - 2016-05-07 17:16:42 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:16:42 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:16:42 --> Utf8 Class Initialized
INFO - 2016-05-07 17:16:42 --> URI Class Initialized
INFO - 2016-05-07 17:16:42 --> Router Class Initialized
INFO - 2016-05-07 17:16:42 --> Output Class Initialized
INFO - 2016-05-07 17:16:42 --> Security Class Initialized
DEBUG - 2016-05-07 17:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:16:42 --> Input Class Initialized
INFO - 2016-05-07 17:16:42 --> Language Class Initialized
INFO - 2016-05-07 17:16:42 --> Loader Class Initialized
INFO - 2016-05-07 17:16:42 --> Helper loaded: url_helper
INFO - 2016-05-07 17:16:42 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:16:42 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:16:42 --> Helper loaded: form_helper
INFO - 2016-05-07 17:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:16:42 --> Form Validation Class Initialized
INFO - 2016-05-07 17:16:42 --> Controller Class Initialized
INFO - 2016-05-07 17:16:42 --> Model Class Initialized
INFO - 2016-05-07 17:16:42 --> Database Driver Class Initialized
INFO - 2016-05-07 17:16:42 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:16:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:16:42 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:16:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:16:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:16:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:16:42 --> Final output sent to browser
DEBUG - 2016-05-07 17:16:42 --> Total execution time: 0.0910
INFO - 2016-05-07 17:16:43 --> Config Class Initialized
INFO - 2016-05-07 17:16:43 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:16:43 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:16:43 --> Utf8 Class Initialized
INFO - 2016-05-07 17:16:43 --> URI Class Initialized
INFO - 2016-05-07 17:16:43 --> Router Class Initialized
INFO - 2016-05-07 17:16:43 --> Output Class Initialized
INFO - 2016-05-07 17:16:43 --> Security Class Initialized
DEBUG - 2016-05-07 17:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:16:43 --> Input Class Initialized
INFO - 2016-05-07 17:16:43 --> Language Class Initialized
INFO - 2016-05-07 17:16:43 --> Loader Class Initialized
INFO - 2016-05-07 17:16:43 --> Helper loaded: url_helper
INFO - 2016-05-07 17:16:43 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:16:43 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:16:43 --> Helper loaded: form_helper
INFO - 2016-05-07 17:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:16:43 --> Form Validation Class Initialized
INFO - 2016-05-07 17:16:43 --> Controller Class Initialized
INFO - 2016-05-07 17:16:43 --> Model Class Initialized
INFO - 2016-05-07 17:16:43 --> Database Driver Class Initialized
INFO - 2016-05-07 17:16:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:16:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:16:43 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:16:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:16:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 17:16:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:16:43 --> Final output sent to browser
DEBUG - 2016-05-07 17:16:43 --> Total execution time: 0.1381
INFO - 2016-05-07 17:16:51 --> Config Class Initialized
INFO - 2016-05-07 17:16:51 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:16:51 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:16:51 --> Utf8 Class Initialized
INFO - 2016-05-07 17:16:51 --> URI Class Initialized
INFO - 2016-05-07 17:16:51 --> Router Class Initialized
INFO - 2016-05-07 17:16:51 --> Output Class Initialized
INFO - 2016-05-07 17:16:51 --> Security Class Initialized
DEBUG - 2016-05-07 17:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:16:51 --> Input Class Initialized
INFO - 2016-05-07 17:16:51 --> Language Class Initialized
INFO - 2016-05-07 17:16:51 --> Loader Class Initialized
INFO - 2016-05-07 17:16:51 --> Helper loaded: url_helper
INFO - 2016-05-07 17:16:51 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:16:51 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:16:51 --> Helper loaded: form_helper
INFO - 2016-05-07 17:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:16:51 --> Form Validation Class Initialized
INFO - 2016-05-07 17:16:51 --> Controller Class Initialized
INFO - 2016-05-07 17:16:51 --> Model Class Initialized
INFO - 2016-05-07 17:16:51 --> Database Driver Class Initialized
INFO - 2016-05-07 17:16:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:16:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:16:51 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:16:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:16:51 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 17:16:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:16:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:16:51 --> Final output sent to browser
DEBUG - 2016-05-07 17:16:51 --> Total execution time: 0.1166
INFO - 2016-05-07 17:16:55 --> Config Class Initialized
INFO - 2016-05-07 17:16:55 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:16:55 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:16:55 --> Utf8 Class Initialized
INFO - 2016-05-07 17:16:55 --> URI Class Initialized
INFO - 2016-05-07 17:16:55 --> Router Class Initialized
INFO - 2016-05-07 17:16:55 --> Output Class Initialized
INFO - 2016-05-07 17:16:55 --> Security Class Initialized
DEBUG - 2016-05-07 17:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:16:55 --> Input Class Initialized
INFO - 2016-05-07 17:16:55 --> Language Class Initialized
INFO - 2016-05-07 17:16:55 --> Loader Class Initialized
INFO - 2016-05-07 17:16:55 --> Helper loaded: url_helper
INFO - 2016-05-07 17:16:55 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:16:55 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:16:55 --> Helper loaded: form_helper
INFO - 2016-05-07 17:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:16:55 --> Form Validation Class Initialized
INFO - 2016-05-07 17:16:55 --> Controller Class Initialized
INFO - 2016-05-07 17:16:55 --> Model Class Initialized
INFO - 2016-05-07 17:16:55 --> Database Driver Class Initialized
INFO - 2016-05-07 17:16:55 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:16:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:16:55 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:16:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:16:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:16:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:16:55 --> Final output sent to browser
DEBUG - 2016-05-07 17:16:55 --> Total execution time: 0.1698
INFO - 2016-05-07 17:17:57 --> Config Class Initialized
INFO - 2016-05-07 17:17:57 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:17:57 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:17:57 --> Utf8 Class Initialized
INFO - 2016-05-07 17:17:57 --> URI Class Initialized
INFO - 2016-05-07 17:17:57 --> Router Class Initialized
INFO - 2016-05-07 17:17:57 --> Output Class Initialized
INFO - 2016-05-07 17:17:57 --> Security Class Initialized
DEBUG - 2016-05-07 17:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:17:57 --> Input Class Initialized
INFO - 2016-05-07 17:17:57 --> Language Class Initialized
INFO - 2016-05-07 17:17:57 --> Loader Class Initialized
INFO - 2016-05-07 17:17:57 --> Helper loaded: url_helper
INFO - 2016-05-07 17:17:57 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:17:57 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:17:57 --> Helper loaded: form_helper
INFO - 2016-05-07 17:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:17:57 --> Form Validation Class Initialized
INFO - 2016-05-07 17:17:57 --> Controller Class Initialized
INFO - 2016-05-07 17:17:57 --> Model Class Initialized
INFO - 2016-05-07 17:17:57 --> Database Driver Class Initialized
INFO - 2016-05-07 17:17:57 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:17:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:17:57 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:17:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:17:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:17:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:17:57 --> Final output sent to browser
DEBUG - 2016-05-07 17:17:57 --> Total execution time: 0.1164
INFO - 2016-05-07 17:18:01 --> Config Class Initialized
INFO - 2016-05-07 17:18:01 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:18:01 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:18:01 --> Utf8 Class Initialized
INFO - 2016-05-07 17:18:01 --> URI Class Initialized
INFO - 2016-05-07 17:18:01 --> Router Class Initialized
INFO - 2016-05-07 17:18:01 --> Output Class Initialized
INFO - 2016-05-07 17:18:01 --> Security Class Initialized
DEBUG - 2016-05-07 17:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:18:01 --> Input Class Initialized
INFO - 2016-05-07 17:18:01 --> Language Class Initialized
INFO - 2016-05-07 17:18:01 --> Loader Class Initialized
INFO - 2016-05-07 17:18:01 --> Helper loaded: url_helper
INFO - 2016-05-07 17:18:01 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:18:01 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:18:01 --> Helper loaded: form_helper
INFO - 2016-05-07 17:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:18:01 --> Form Validation Class Initialized
INFO - 2016-05-07 17:18:01 --> Controller Class Initialized
INFO - 2016-05-07 17:18:01 --> Model Class Initialized
INFO - 2016-05-07 17:18:01 --> Database Driver Class Initialized
INFO - 2016-05-07 17:18:01 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:18:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:18:01 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:18:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:18:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 17:18:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:18:01 --> Final output sent to browser
DEBUG - 2016-05-07 17:18:01 --> Total execution time: 0.1190
INFO - 2016-05-07 17:18:17 --> Config Class Initialized
INFO - 2016-05-07 17:18:17 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:18:17 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:18:17 --> Utf8 Class Initialized
INFO - 2016-05-07 17:18:17 --> URI Class Initialized
INFO - 2016-05-07 17:18:17 --> Router Class Initialized
INFO - 2016-05-07 17:18:17 --> Output Class Initialized
INFO - 2016-05-07 17:18:17 --> Security Class Initialized
DEBUG - 2016-05-07 17:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:18:17 --> Input Class Initialized
INFO - 2016-05-07 17:18:17 --> Language Class Initialized
INFO - 2016-05-07 17:18:17 --> Loader Class Initialized
INFO - 2016-05-07 17:18:17 --> Helper loaded: url_helper
INFO - 2016-05-07 17:18:17 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:18:17 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:18:17 --> Helper loaded: form_helper
INFO - 2016-05-07 17:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:18:17 --> Form Validation Class Initialized
INFO - 2016-05-07 17:18:17 --> Controller Class Initialized
INFO - 2016-05-07 17:18:17 --> Model Class Initialized
INFO - 2016-05-07 17:18:17 --> Database Driver Class Initialized
INFO - 2016-05-07 17:18:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:18:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:18:17 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:18:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:18:17 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 17:18:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:18:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:18:17 --> Final output sent to browser
DEBUG - 2016-05-07 17:18:17 --> Total execution time: 0.1204
INFO - 2016-05-07 17:19:07 --> Config Class Initialized
INFO - 2016-05-07 17:19:07 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:19:07 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:19:07 --> Utf8 Class Initialized
INFO - 2016-05-07 17:19:07 --> URI Class Initialized
INFO - 2016-05-07 17:19:07 --> Router Class Initialized
INFO - 2016-05-07 17:19:07 --> Output Class Initialized
INFO - 2016-05-07 17:19:07 --> Security Class Initialized
DEBUG - 2016-05-07 17:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:19:08 --> Input Class Initialized
INFO - 2016-05-07 17:19:08 --> Language Class Initialized
INFO - 2016-05-07 17:19:08 --> Loader Class Initialized
INFO - 2016-05-07 17:19:08 --> Helper loaded: url_helper
INFO - 2016-05-07 17:19:08 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:19:08 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:19:08 --> Helper loaded: form_helper
INFO - 2016-05-07 17:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:19:08 --> Form Validation Class Initialized
INFO - 2016-05-07 17:19:08 --> Controller Class Initialized
INFO - 2016-05-07 17:19:08 --> Model Class Initialized
INFO - 2016-05-07 17:19:08 --> Database Driver Class Initialized
INFO - 2016-05-07 17:19:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:19:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:19:08 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:19:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:19:08 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-05-07 17:19:08 --> Severity: Notice --> Undefined variable: mensajeok C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php 21
INFO - 2016-05-07 17:19:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:19:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:19:08 --> Final output sent to browser
DEBUG - 2016-05-07 17:19:08 --> Total execution time: 0.0878
INFO - 2016-05-07 17:19:47 --> Config Class Initialized
INFO - 2016-05-07 17:19:47 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:19:47 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:19:47 --> Utf8 Class Initialized
INFO - 2016-05-07 17:19:47 --> URI Class Initialized
INFO - 2016-05-07 17:19:47 --> Router Class Initialized
INFO - 2016-05-07 17:19:47 --> Output Class Initialized
INFO - 2016-05-07 17:19:47 --> Security Class Initialized
DEBUG - 2016-05-07 17:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:19:47 --> Input Class Initialized
INFO - 2016-05-07 17:19:47 --> Language Class Initialized
INFO - 2016-05-07 17:19:47 --> Loader Class Initialized
INFO - 2016-05-07 17:19:47 --> Helper loaded: url_helper
INFO - 2016-05-07 17:19:47 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:19:47 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:19:47 --> Helper loaded: form_helper
INFO - 2016-05-07 17:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:19:47 --> Form Validation Class Initialized
INFO - 2016-05-07 17:19:47 --> Controller Class Initialized
INFO - 2016-05-07 17:19:47 --> Model Class Initialized
INFO - 2016-05-07 17:19:47 --> Database Driver Class Initialized
INFO - 2016-05-07 17:19:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:19:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:19:47 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:19:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:19:47 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 17:19:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:19:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:19:47 --> Final output sent to browser
DEBUG - 2016-05-07 17:19:47 --> Total execution time: 0.0991
INFO - 2016-05-07 17:20:06 --> Config Class Initialized
INFO - 2016-05-07 17:20:06 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:20:06 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:20:06 --> Utf8 Class Initialized
INFO - 2016-05-07 17:20:06 --> URI Class Initialized
INFO - 2016-05-07 17:20:06 --> Router Class Initialized
INFO - 2016-05-07 17:20:06 --> Output Class Initialized
INFO - 2016-05-07 17:20:06 --> Security Class Initialized
DEBUG - 2016-05-07 17:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:20:06 --> Input Class Initialized
INFO - 2016-05-07 17:20:06 --> Language Class Initialized
INFO - 2016-05-07 17:20:06 --> Loader Class Initialized
INFO - 2016-05-07 17:20:06 --> Helper loaded: url_helper
INFO - 2016-05-07 17:20:06 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:20:06 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:20:06 --> Helper loaded: form_helper
INFO - 2016-05-07 17:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:20:06 --> Form Validation Class Initialized
INFO - 2016-05-07 17:20:06 --> Controller Class Initialized
INFO - 2016-05-07 17:20:06 --> Model Class Initialized
INFO - 2016-05-07 17:20:06 --> Database Driver Class Initialized
INFO - 2016-05-07 17:20:06 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:20:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:20:06 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:20:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:20:06 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 17:20:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:20:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:20:06 --> Final output sent to browser
DEBUG - 2016-05-07 17:20:06 --> Total execution time: 0.0867
INFO - 2016-05-07 17:20:09 --> Config Class Initialized
INFO - 2016-05-07 17:20:09 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:20:09 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:20:09 --> Utf8 Class Initialized
INFO - 2016-05-07 17:20:09 --> URI Class Initialized
INFO - 2016-05-07 17:20:09 --> Router Class Initialized
INFO - 2016-05-07 17:20:09 --> Output Class Initialized
INFO - 2016-05-07 17:20:09 --> Security Class Initialized
DEBUG - 2016-05-07 17:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:20:09 --> Input Class Initialized
INFO - 2016-05-07 17:20:09 --> Language Class Initialized
INFO - 2016-05-07 17:20:09 --> Loader Class Initialized
INFO - 2016-05-07 17:20:09 --> Helper loaded: url_helper
INFO - 2016-05-07 17:20:09 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:20:09 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:20:09 --> Helper loaded: form_helper
INFO - 2016-05-07 17:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:20:09 --> Form Validation Class Initialized
INFO - 2016-05-07 17:20:09 --> Controller Class Initialized
INFO - 2016-05-07 17:20:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-07 17:20:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:20:09 --> Final output sent to browser
DEBUG - 2016-05-07 17:20:09 --> Total execution time: 0.0489
INFO - 2016-05-07 17:20:15 --> Config Class Initialized
INFO - 2016-05-07 17:20:15 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:20:15 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:20:15 --> Utf8 Class Initialized
INFO - 2016-05-07 17:20:15 --> URI Class Initialized
INFO - 2016-05-07 17:20:15 --> Router Class Initialized
INFO - 2016-05-07 17:20:15 --> Output Class Initialized
INFO - 2016-05-07 17:20:15 --> Security Class Initialized
DEBUG - 2016-05-07 17:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:20:15 --> Input Class Initialized
INFO - 2016-05-07 17:20:15 --> Language Class Initialized
INFO - 2016-05-07 17:20:15 --> Loader Class Initialized
INFO - 2016-05-07 17:20:15 --> Helper loaded: url_helper
INFO - 2016-05-07 17:20:15 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:20:15 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:20:15 --> Helper loaded: form_helper
INFO - 2016-05-07 17:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:20:15 --> Form Validation Class Initialized
INFO - 2016-05-07 17:20:15 --> Controller Class Initialized
INFO - 2016-05-07 17:20:15 --> Model Class Initialized
INFO - 2016-05-07 17:20:15 --> Database Driver Class Initialized
INFO - 2016-05-07 17:20:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:20:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:20:15 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:20:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:20:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:20:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:20:16 --> Final output sent to browser
DEBUG - 2016-05-07 17:20:16 --> Total execution time: 0.0955
INFO - 2016-05-07 17:20:20 --> Config Class Initialized
INFO - 2016-05-07 17:20:20 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:20:20 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:20:20 --> Utf8 Class Initialized
INFO - 2016-05-07 17:20:20 --> URI Class Initialized
INFO - 2016-05-07 17:20:20 --> Router Class Initialized
INFO - 2016-05-07 17:20:20 --> Output Class Initialized
INFO - 2016-05-07 17:20:20 --> Security Class Initialized
DEBUG - 2016-05-07 17:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:20:20 --> Input Class Initialized
INFO - 2016-05-07 17:20:20 --> Language Class Initialized
INFO - 2016-05-07 17:20:20 --> Loader Class Initialized
INFO - 2016-05-07 17:20:20 --> Helper loaded: url_helper
INFO - 2016-05-07 17:20:20 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:20:20 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:20:20 --> Helper loaded: form_helper
INFO - 2016-05-07 17:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:20:20 --> Form Validation Class Initialized
INFO - 2016-05-07 17:20:20 --> Controller Class Initialized
INFO - 2016-05-07 17:20:20 --> Model Class Initialized
INFO - 2016-05-07 17:20:20 --> Database Driver Class Initialized
INFO - 2016-05-07 17:20:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:20:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:20:20 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:20:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:20:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 17:20:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:20:20 --> Final output sent to browser
DEBUG - 2016-05-07 17:20:20 --> Total execution time: 0.1163
INFO - 2016-05-07 17:20:28 --> Config Class Initialized
INFO - 2016-05-07 17:20:28 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:20:28 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:20:28 --> Utf8 Class Initialized
INFO - 2016-05-07 17:20:28 --> URI Class Initialized
INFO - 2016-05-07 17:20:28 --> Router Class Initialized
INFO - 2016-05-07 17:20:28 --> Output Class Initialized
INFO - 2016-05-07 17:20:28 --> Security Class Initialized
DEBUG - 2016-05-07 17:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:20:28 --> Input Class Initialized
INFO - 2016-05-07 17:20:28 --> Language Class Initialized
INFO - 2016-05-07 17:20:28 --> Loader Class Initialized
INFO - 2016-05-07 17:20:28 --> Helper loaded: url_helper
INFO - 2016-05-07 17:20:28 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:20:28 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:20:28 --> Helper loaded: form_helper
INFO - 2016-05-07 17:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:20:28 --> Form Validation Class Initialized
INFO - 2016-05-07 17:20:28 --> Controller Class Initialized
INFO - 2016-05-07 17:20:28 --> Model Class Initialized
INFO - 2016-05-07 17:20:28 --> Database Driver Class Initialized
INFO - 2016-05-07 17:20:28 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:20:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:20:28 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:20:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:20:28 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 17:20:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:20:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:20:28 --> Final output sent to browser
DEBUG - 2016-05-07 17:20:28 --> Total execution time: 0.1102
INFO - 2016-05-07 17:20:36 --> Config Class Initialized
INFO - 2016-05-07 17:20:36 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:20:36 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:20:36 --> Utf8 Class Initialized
INFO - 2016-05-07 17:20:36 --> URI Class Initialized
INFO - 2016-05-07 17:20:36 --> Router Class Initialized
INFO - 2016-05-07 17:20:36 --> Output Class Initialized
INFO - 2016-05-07 17:20:36 --> Security Class Initialized
DEBUG - 2016-05-07 17:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:20:36 --> Input Class Initialized
INFO - 2016-05-07 17:20:36 --> Language Class Initialized
INFO - 2016-05-07 17:20:37 --> Loader Class Initialized
INFO - 2016-05-07 17:20:37 --> Helper loaded: url_helper
INFO - 2016-05-07 17:20:37 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:20:37 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:20:37 --> Helper loaded: form_helper
INFO - 2016-05-07 17:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:20:37 --> Form Validation Class Initialized
INFO - 2016-05-07 17:20:37 --> Controller Class Initialized
INFO - 2016-05-07 17:20:37 --> Model Class Initialized
INFO - 2016-05-07 17:20:37 --> Database Driver Class Initialized
INFO - 2016-05-07 17:20:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:20:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:20:37 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:20:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:20:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:20:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:20:37 --> Final output sent to browser
DEBUG - 2016-05-07 17:20:37 --> Total execution time: 0.1619
INFO - 2016-05-07 17:21:05 --> Config Class Initialized
INFO - 2016-05-07 17:21:05 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:21:05 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:21:05 --> Utf8 Class Initialized
INFO - 2016-05-07 17:21:05 --> URI Class Initialized
INFO - 2016-05-07 17:21:05 --> Router Class Initialized
INFO - 2016-05-07 17:21:05 --> Output Class Initialized
INFO - 2016-05-07 17:21:05 --> Security Class Initialized
DEBUG - 2016-05-07 17:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:21:05 --> Input Class Initialized
INFO - 2016-05-07 17:21:05 --> Language Class Initialized
INFO - 2016-05-07 17:21:05 --> Loader Class Initialized
INFO - 2016-05-07 17:21:05 --> Helper loaded: url_helper
INFO - 2016-05-07 17:21:05 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:21:05 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:21:05 --> Helper loaded: form_helper
INFO - 2016-05-07 17:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:21:05 --> Form Validation Class Initialized
INFO - 2016-05-07 17:21:05 --> Controller Class Initialized
INFO - 2016-05-07 17:21:05 --> Model Class Initialized
INFO - 2016-05-07 17:21:05 --> Database Driver Class Initialized
INFO - 2016-05-07 17:21:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:21:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:21:05 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:21:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 17:21:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 287
ERROR - 2016-05-07 17:21:05 --> Severity: Notice --> Undefined variable: datos C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 292
INFO - 2016-05-07 17:21:05 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 17:21:21 --> Config Class Initialized
INFO - 2016-05-07 17:21:21 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:21:21 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:21:21 --> Utf8 Class Initialized
INFO - 2016-05-07 17:21:21 --> URI Class Initialized
INFO - 2016-05-07 17:21:21 --> Router Class Initialized
INFO - 2016-05-07 17:21:21 --> Output Class Initialized
INFO - 2016-05-07 17:21:21 --> Security Class Initialized
DEBUG - 2016-05-07 17:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:21:21 --> Input Class Initialized
INFO - 2016-05-07 17:21:21 --> Language Class Initialized
INFO - 2016-05-07 17:21:21 --> Loader Class Initialized
INFO - 2016-05-07 17:21:21 --> Helper loaded: url_helper
INFO - 2016-05-07 17:21:21 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:21:21 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:21:21 --> Helper loaded: form_helper
INFO - 2016-05-07 17:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:21:21 --> Form Validation Class Initialized
INFO - 2016-05-07 17:21:21 --> Controller Class Initialized
INFO - 2016-05-07 17:21:21 --> Model Class Initialized
INFO - 2016-05-07 17:21:21 --> Database Driver Class Initialized
INFO - 2016-05-07 17:21:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:21:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:21:21 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:21:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 17:21:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 287
ERROR - 2016-05-07 17:21:21 --> Severity: Notice --> Undefined variable: datos C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 292
INFO - 2016-05-07 17:21:21 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 17:21:22 --> Config Class Initialized
INFO - 2016-05-07 17:21:22 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:21:22 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:21:22 --> Utf8 Class Initialized
INFO - 2016-05-07 17:21:22 --> URI Class Initialized
INFO - 2016-05-07 17:21:22 --> Router Class Initialized
INFO - 2016-05-07 17:21:22 --> Output Class Initialized
INFO - 2016-05-07 17:21:22 --> Security Class Initialized
DEBUG - 2016-05-07 17:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:21:22 --> Input Class Initialized
INFO - 2016-05-07 17:21:22 --> Language Class Initialized
INFO - 2016-05-07 17:21:22 --> Loader Class Initialized
INFO - 2016-05-07 17:21:22 --> Helper loaded: url_helper
INFO - 2016-05-07 17:21:22 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:21:22 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:21:22 --> Helper loaded: form_helper
INFO - 2016-05-07 17:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:21:22 --> Form Validation Class Initialized
INFO - 2016-05-07 17:21:22 --> Controller Class Initialized
INFO - 2016-05-07 17:21:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-07 17:21:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:21:22 --> Final output sent to browser
DEBUG - 2016-05-07 17:21:22 --> Total execution time: 0.0607
INFO - 2016-05-07 17:21:27 --> Config Class Initialized
INFO - 2016-05-07 17:21:27 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:21:27 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:21:27 --> Utf8 Class Initialized
INFO - 2016-05-07 17:21:27 --> URI Class Initialized
INFO - 2016-05-07 17:21:27 --> Router Class Initialized
INFO - 2016-05-07 17:21:27 --> Output Class Initialized
INFO - 2016-05-07 17:21:27 --> Security Class Initialized
DEBUG - 2016-05-07 17:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:21:27 --> Input Class Initialized
INFO - 2016-05-07 17:21:27 --> Language Class Initialized
INFO - 2016-05-07 17:21:27 --> Loader Class Initialized
INFO - 2016-05-07 17:21:27 --> Helper loaded: url_helper
INFO - 2016-05-07 17:21:27 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:21:27 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:21:27 --> Helper loaded: form_helper
INFO - 2016-05-07 17:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:21:27 --> Form Validation Class Initialized
INFO - 2016-05-07 17:21:27 --> Controller Class Initialized
INFO - 2016-05-07 17:21:27 --> Model Class Initialized
INFO - 2016-05-07 17:21:27 --> Database Driver Class Initialized
INFO - 2016-05-07 17:21:27 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:21:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:21:27 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:21:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:21:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:21:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:21:27 --> Final output sent to browser
DEBUG - 2016-05-07 17:21:27 --> Total execution time: 0.0964
INFO - 2016-05-07 17:21:45 --> Config Class Initialized
INFO - 2016-05-07 17:21:45 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:21:45 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:21:45 --> Utf8 Class Initialized
INFO - 2016-05-07 17:21:45 --> URI Class Initialized
INFO - 2016-05-07 17:21:45 --> Router Class Initialized
INFO - 2016-05-07 17:21:45 --> Output Class Initialized
INFO - 2016-05-07 17:21:45 --> Security Class Initialized
DEBUG - 2016-05-07 17:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:21:45 --> Input Class Initialized
INFO - 2016-05-07 17:21:45 --> Language Class Initialized
INFO - 2016-05-07 17:21:45 --> Loader Class Initialized
INFO - 2016-05-07 17:21:45 --> Helper loaded: url_helper
INFO - 2016-05-07 17:21:45 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:21:45 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:21:45 --> Helper loaded: form_helper
INFO - 2016-05-07 17:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:21:45 --> Form Validation Class Initialized
INFO - 2016-05-07 17:21:45 --> Controller Class Initialized
INFO - 2016-05-07 17:21:45 --> Model Class Initialized
INFO - 2016-05-07 17:21:45 --> Database Driver Class Initialized
INFO - 2016-05-07 17:21:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:21:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:21:45 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:21:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:21:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:21:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:21:45 --> Final output sent to browser
DEBUG - 2016-05-07 17:21:45 --> Total execution time: 0.0953
INFO - 2016-05-07 17:21:47 --> Config Class Initialized
INFO - 2016-05-07 17:21:47 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:21:47 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:21:47 --> Utf8 Class Initialized
INFO - 2016-05-07 17:21:47 --> URI Class Initialized
INFO - 2016-05-07 17:21:47 --> Router Class Initialized
INFO - 2016-05-07 17:21:47 --> Output Class Initialized
INFO - 2016-05-07 17:21:47 --> Security Class Initialized
DEBUG - 2016-05-07 17:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:21:47 --> Input Class Initialized
INFO - 2016-05-07 17:21:47 --> Language Class Initialized
INFO - 2016-05-07 17:21:47 --> Loader Class Initialized
INFO - 2016-05-07 17:21:47 --> Helper loaded: url_helper
INFO - 2016-05-07 17:21:47 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:21:47 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:21:47 --> Helper loaded: form_helper
INFO - 2016-05-07 17:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:21:47 --> Form Validation Class Initialized
INFO - 2016-05-07 17:21:47 --> Controller Class Initialized
INFO - 2016-05-07 17:21:47 --> Model Class Initialized
INFO - 2016-05-07 17:21:47 --> Database Driver Class Initialized
INFO - 2016-05-07 17:21:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:21:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:21:47 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:21:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:21:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 17:21:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:21:47 --> Final output sent to browser
DEBUG - 2016-05-07 17:21:47 --> Total execution time: 0.1963
INFO - 2016-05-07 17:21:50 --> Config Class Initialized
INFO - 2016-05-07 17:21:50 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:21:50 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:21:50 --> Utf8 Class Initialized
INFO - 2016-05-07 17:21:50 --> URI Class Initialized
INFO - 2016-05-07 17:21:50 --> Router Class Initialized
INFO - 2016-05-07 17:21:50 --> Output Class Initialized
INFO - 2016-05-07 17:21:50 --> Security Class Initialized
DEBUG - 2016-05-07 17:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:21:50 --> Input Class Initialized
INFO - 2016-05-07 17:21:50 --> Language Class Initialized
INFO - 2016-05-07 17:21:50 --> Loader Class Initialized
INFO - 2016-05-07 17:21:50 --> Helper loaded: url_helper
INFO - 2016-05-07 17:21:50 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:21:50 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:21:50 --> Helper loaded: form_helper
INFO - 2016-05-07 17:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:21:50 --> Form Validation Class Initialized
INFO - 2016-05-07 17:21:50 --> Controller Class Initialized
INFO - 2016-05-07 17:21:50 --> Model Class Initialized
INFO - 2016-05-07 17:21:50 --> Database Driver Class Initialized
INFO - 2016-05-07 17:21:50 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:21:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:21:50 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:21:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:21:50 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 17:21:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:21:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:21:50 --> Final output sent to browser
DEBUG - 2016-05-07 17:21:50 --> Total execution time: 0.1595
INFO - 2016-05-07 17:21:59 --> Config Class Initialized
INFO - 2016-05-07 17:21:59 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:21:59 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:21:59 --> Utf8 Class Initialized
INFO - 2016-05-07 17:21:59 --> URI Class Initialized
INFO - 2016-05-07 17:21:59 --> Router Class Initialized
INFO - 2016-05-07 17:21:59 --> Output Class Initialized
INFO - 2016-05-07 17:21:59 --> Security Class Initialized
DEBUG - 2016-05-07 17:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:21:59 --> Input Class Initialized
INFO - 2016-05-07 17:21:59 --> Language Class Initialized
INFO - 2016-05-07 17:21:59 --> Loader Class Initialized
INFO - 2016-05-07 17:21:59 --> Helper loaded: url_helper
INFO - 2016-05-07 17:21:59 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:21:59 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:21:59 --> Helper loaded: form_helper
INFO - 2016-05-07 17:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:21:59 --> Form Validation Class Initialized
INFO - 2016-05-07 17:21:59 --> Controller Class Initialized
INFO - 2016-05-07 17:21:59 --> Model Class Initialized
INFO - 2016-05-07 17:21:59 --> Database Driver Class Initialized
INFO - 2016-05-07 17:21:59 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:21:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:21:59 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:21:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:22:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:22:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:22:00 --> Final output sent to browser
DEBUG - 2016-05-07 17:22:00 --> Total execution time: 0.1870
INFO - 2016-05-07 17:22:07 --> Config Class Initialized
INFO - 2016-05-07 17:22:07 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:22:07 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:22:07 --> Utf8 Class Initialized
INFO - 2016-05-07 17:22:07 --> URI Class Initialized
INFO - 2016-05-07 17:22:07 --> Router Class Initialized
INFO - 2016-05-07 17:22:07 --> Output Class Initialized
INFO - 2016-05-07 17:22:07 --> Security Class Initialized
DEBUG - 2016-05-07 17:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:22:07 --> Input Class Initialized
INFO - 2016-05-07 17:22:07 --> Language Class Initialized
INFO - 2016-05-07 17:22:07 --> Loader Class Initialized
INFO - 2016-05-07 17:22:07 --> Helper loaded: url_helper
INFO - 2016-05-07 17:22:07 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:22:07 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:22:07 --> Helper loaded: form_helper
INFO - 2016-05-07 17:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:22:07 --> Form Validation Class Initialized
INFO - 2016-05-07 17:22:07 --> Controller Class Initialized
INFO - 2016-05-07 17:22:07 --> Model Class Initialized
INFO - 2016-05-07 17:22:07 --> Database Driver Class Initialized
INFO - 2016-05-07 17:22:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:22:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:22:07 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:22:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:22:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 17:22:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:22:07 --> Final output sent to browser
DEBUG - 2016-05-07 17:22:07 --> Total execution time: 0.0938
INFO - 2016-05-07 17:22:10 --> Config Class Initialized
INFO - 2016-05-07 17:22:10 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:22:10 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:22:10 --> Utf8 Class Initialized
INFO - 2016-05-07 17:22:10 --> URI Class Initialized
INFO - 2016-05-07 17:22:10 --> Router Class Initialized
INFO - 2016-05-07 17:22:10 --> Output Class Initialized
INFO - 2016-05-07 17:22:10 --> Security Class Initialized
DEBUG - 2016-05-07 17:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:22:10 --> Input Class Initialized
INFO - 2016-05-07 17:22:10 --> Language Class Initialized
INFO - 2016-05-07 17:22:10 --> Loader Class Initialized
INFO - 2016-05-07 17:22:10 --> Helper loaded: url_helper
INFO - 2016-05-07 17:22:10 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:22:10 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:22:10 --> Helper loaded: form_helper
INFO - 2016-05-07 17:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:22:10 --> Form Validation Class Initialized
INFO - 2016-05-07 17:22:10 --> Controller Class Initialized
INFO - 2016-05-07 17:22:11 --> Model Class Initialized
INFO - 2016-05-07 17:22:11 --> Database Driver Class Initialized
INFO - 2016-05-07 17:22:11 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:22:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:22:11 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:22:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:22:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 17:22:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:22:11 --> Final output sent to browser
DEBUG - 2016-05-07 17:22:11 --> Total execution time: 0.1012
INFO - 2016-05-07 17:22:15 --> Config Class Initialized
INFO - 2016-05-07 17:22:15 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:22:15 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:22:15 --> Utf8 Class Initialized
INFO - 2016-05-07 17:22:15 --> URI Class Initialized
INFO - 2016-05-07 17:22:15 --> Router Class Initialized
INFO - 2016-05-07 17:22:15 --> Output Class Initialized
INFO - 2016-05-07 17:22:15 --> Security Class Initialized
DEBUG - 2016-05-07 17:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:22:15 --> Input Class Initialized
INFO - 2016-05-07 17:22:15 --> Language Class Initialized
INFO - 2016-05-07 17:22:15 --> Loader Class Initialized
INFO - 2016-05-07 17:22:15 --> Helper loaded: url_helper
INFO - 2016-05-07 17:22:15 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:22:15 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:22:15 --> Helper loaded: form_helper
INFO - 2016-05-07 17:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:22:15 --> Form Validation Class Initialized
INFO - 2016-05-07 17:22:15 --> Controller Class Initialized
INFO - 2016-05-07 17:22:15 --> Model Class Initialized
INFO - 2016-05-07 17:22:15 --> Database Driver Class Initialized
INFO - 2016-05-07 17:22:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:22:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:22:15 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:22:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:22:15 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 17:22:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:22:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:22:15 --> Final output sent to browser
DEBUG - 2016-05-07 17:22:15 --> Total execution time: 0.1093
INFO - 2016-05-07 17:22:24 --> Config Class Initialized
INFO - 2016-05-07 17:22:24 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:22:24 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:22:24 --> Utf8 Class Initialized
INFO - 2016-05-07 17:22:24 --> URI Class Initialized
INFO - 2016-05-07 17:22:24 --> Router Class Initialized
INFO - 2016-05-07 17:22:24 --> Output Class Initialized
INFO - 2016-05-07 17:22:24 --> Security Class Initialized
DEBUG - 2016-05-07 17:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:22:24 --> Input Class Initialized
INFO - 2016-05-07 17:22:24 --> Language Class Initialized
INFO - 2016-05-07 17:22:24 --> Loader Class Initialized
INFO - 2016-05-07 17:22:24 --> Helper loaded: url_helper
INFO - 2016-05-07 17:22:24 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:22:24 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:22:24 --> Helper loaded: form_helper
INFO - 2016-05-07 17:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:22:24 --> Form Validation Class Initialized
INFO - 2016-05-07 17:22:24 --> Controller Class Initialized
INFO - 2016-05-07 17:22:24 --> Model Class Initialized
INFO - 2016-05-07 17:22:24 --> Database Driver Class Initialized
INFO - 2016-05-07 17:22:24 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:22:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:22:24 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:22:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:22:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:22:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:22:24 --> Final output sent to browser
DEBUG - 2016-05-07 17:22:24 --> Total execution time: 0.1815
INFO - 2016-05-07 17:22:28 --> Config Class Initialized
INFO - 2016-05-07 17:22:28 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:22:28 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:22:28 --> Utf8 Class Initialized
INFO - 2016-05-07 17:22:28 --> URI Class Initialized
INFO - 2016-05-07 17:22:28 --> Router Class Initialized
INFO - 2016-05-07 17:22:28 --> Output Class Initialized
INFO - 2016-05-07 17:22:28 --> Security Class Initialized
DEBUG - 2016-05-07 17:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:22:28 --> Input Class Initialized
INFO - 2016-05-07 17:22:28 --> Language Class Initialized
INFO - 2016-05-07 17:22:28 --> Loader Class Initialized
INFO - 2016-05-07 17:22:28 --> Helper loaded: url_helper
INFO - 2016-05-07 17:22:28 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:22:28 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:22:28 --> Helper loaded: form_helper
INFO - 2016-05-07 17:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:22:28 --> Form Validation Class Initialized
INFO - 2016-05-07 17:22:28 --> Controller Class Initialized
INFO - 2016-05-07 17:22:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-07 17:22:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:22:28 --> Final output sent to browser
DEBUG - 2016-05-07 17:22:28 --> Total execution time: 0.0509
INFO - 2016-05-07 17:22:30 --> Config Class Initialized
INFO - 2016-05-07 17:22:30 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:22:30 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:22:30 --> Utf8 Class Initialized
INFO - 2016-05-07 17:22:30 --> URI Class Initialized
INFO - 2016-05-07 17:22:30 --> Router Class Initialized
INFO - 2016-05-07 17:22:30 --> Output Class Initialized
INFO - 2016-05-07 17:22:30 --> Security Class Initialized
DEBUG - 2016-05-07 17:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:22:30 --> Input Class Initialized
INFO - 2016-05-07 17:22:30 --> Language Class Initialized
INFO - 2016-05-07 17:22:31 --> Loader Class Initialized
INFO - 2016-05-07 17:22:31 --> Helper loaded: url_helper
INFO - 2016-05-07 17:22:31 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:22:31 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:22:31 --> Helper loaded: form_helper
INFO - 2016-05-07 17:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:22:31 --> Form Validation Class Initialized
INFO - 2016-05-07 17:22:31 --> Controller Class Initialized
INFO - 2016-05-07 17:22:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-07 17:22:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:22:31 --> Final output sent to browser
DEBUG - 2016-05-07 17:22:31 --> Total execution time: 0.0723
INFO - 2016-05-07 17:22:35 --> Config Class Initialized
INFO - 2016-05-07 17:22:35 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:22:35 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:22:35 --> Utf8 Class Initialized
INFO - 2016-05-07 17:22:35 --> URI Class Initialized
INFO - 2016-05-07 17:22:35 --> Router Class Initialized
INFO - 2016-05-07 17:22:35 --> Output Class Initialized
INFO - 2016-05-07 17:22:35 --> Security Class Initialized
DEBUG - 2016-05-07 17:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:22:35 --> Input Class Initialized
INFO - 2016-05-07 17:22:35 --> Language Class Initialized
INFO - 2016-05-07 17:22:35 --> Loader Class Initialized
INFO - 2016-05-07 17:22:35 --> Helper loaded: url_helper
INFO - 2016-05-07 17:22:35 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:22:35 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:22:35 --> Helper loaded: form_helper
INFO - 2016-05-07 17:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:22:35 --> Form Validation Class Initialized
INFO - 2016-05-07 17:22:35 --> Controller Class Initialized
INFO - 2016-05-07 17:22:35 --> Model Class Initialized
INFO - 2016-05-07 17:22:35 --> Database Driver Class Initialized
INFO - 2016-05-07 17:22:35 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:22:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:22:35 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:22:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:22:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:22:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:22:36 --> Final output sent to browser
DEBUG - 2016-05-07 17:22:36 --> Total execution time: 0.1476
INFO - 2016-05-07 17:22:55 --> Config Class Initialized
INFO - 2016-05-07 17:22:55 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:22:55 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:22:55 --> Utf8 Class Initialized
INFO - 2016-05-07 17:22:55 --> URI Class Initialized
INFO - 2016-05-07 17:22:55 --> Router Class Initialized
INFO - 2016-05-07 17:22:55 --> Output Class Initialized
INFO - 2016-05-07 17:22:55 --> Security Class Initialized
DEBUG - 2016-05-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:22:55 --> Input Class Initialized
INFO - 2016-05-07 17:22:55 --> Language Class Initialized
INFO - 2016-05-07 17:22:55 --> Loader Class Initialized
INFO - 2016-05-07 17:22:55 --> Helper loaded: url_helper
INFO - 2016-05-07 17:22:55 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:22:55 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:22:55 --> Helper loaded: form_helper
INFO - 2016-05-07 17:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:22:55 --> Form Validation Class Initialized
INFO - 2016-05-07 17:22:55 --> Controller Class Initialized
INFO - 2016-05-07 17:22:55 --> Model Class Initialized
INFO - 2016-05-07 17:22:55 --> Database Driver Class Initialized
INFO - 2016-05-07 17:22:55 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:22:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:22:55 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:22:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:22:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:22:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:22:55 --> Final output sent to browser
DEBUG - 2016-05-07 17:22:55 --> Total execution time: 0.1001
INFO - 2016-05-07 17:23:27 --> Config Class Initialized
INFO - 2016-05-07 17:23:27 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:23:27 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:23:27 --> Utf8 Class Initialized
INFO - 2016-05-07 17:23:27 --> URI Class Initialized
INFO - 2016-05-07 17:23:27 --> Router Class Initialized
INFO - 2016-05-07 17:23:27 --> Output Class Initialized
INFO - 2016-05-07 17:23:27 --> Security Class Initialized
DEBUG - 2016-05-07 17:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:23:27 --> Input Class Initialized
INFO - 2016-05-07 17:23:27 --> Language Class Initialized
INFO - 2016-05-07 17:23:27 --> Loader Class Initialized
INFO - 2016-05-07 17:23:27 --> Helper loaded: url_helper
INFO - 2016-05-07 17:23:27 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:23:27 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:23:27 --> Helper loaded: form_helper
INFO - 2016-05-07 17:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:23:27 --> Form Validation Class Initialized
INFO - 2016-05-07 17:23:27 --> Controller Class Initialized
INFO - 2016-05-07 17:23:27 --> Model Class Initialized
INFO - 2016-05-07 17:23:27 --> Database Driver Class Initialized
INFO - 2016-05-07 17:23:27 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:23:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:23:27 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:23:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:23:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:23:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:23:27 --> Final output sent to browser
DEBUG - 2016-05-07 17:23:27 --> Total execution time: 0.1358
INFO - 2016-05-07 17:23:30 --> Config Class Initialized
INFO - 2016-05-07 17:23:30 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:23:30 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:23:30 --> Utf8 Class Initialized
INFO - 2016-05-07 17:23:30 --> URI Class Initialized
INFO - 2016-05-07 17:23:30 --> Router Class Initialized
INFO - 2016-05-07 17:23:30 --> Output Class Initialized
INFO - 2016-05-07 17:23:30 --> Security Class Initialized
DEBUG - 2016-05-07 17:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:23:30 --> Input Class Initialized
INFO - 2016-05-07 17:23:30 --> Language Class Initialized
INFO - 2016-05-07 17:23:30 --> Loader Class Initialized
INFO - 2016-05-07 17:23:30 --> Helper loaded: url_helper
INFO - 2016-05-07 17:23:30 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:23:30 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:23:30 --> Helper loaded: form_helper
INFO - 2016-05-07 17:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:23:30 --> Form Validation Class Initialized
INFO - 2016-05-07 17:23:30 --> Controller Class Initialized
INFO - 2016-05-07 17:23:30 --> Model Class Initialized
INFO - 2016-05-07 17:23:30 --> Database Driver Class Initialized
INFO - 2016-05-07 17:23:30 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:23:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:23:30 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:23:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:23:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 17:23:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:23:30 --> Final output sent to browser
DEBUG - 2016-05-07 17:23:30 --> Total execution time: 0.1314
INFO - 2016-05-07 17:23:34 --> Config Class Initialized
INFO - 2016-05-07 17:23:34 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:23:34 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:23:34 --> Utf8 Class Initialized
INFO - 2016-05-07 17:23:34 --> URI Class Initialized
INFO - 2016-05-07 17:23:34 --> Router Class Initialized
INFO - 2016-05-07 17:23:34 --> Output Class Initialized
INFO - 2016-05-07 17:23:34 --> Security Class Initialized
DEBUG - 2016-05-07 17:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:23:34 --> Input Class Initialized
INFO - 2016-05-07 17:23:34 --> Language Class Initialized
INFO - 2016-05-07 17:23:34 --> Loader Class Initialized
INFO - 2016-05-07 17:23:34 --> Helper loaded: url_helper
INFO - 2016-05-07 17:23:34 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:23:34 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:23:34 --> Helper loaded: form_helper
INFO - 2016-05-07 17:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:23:34 --> Form Validation Class Initialized
INFO - 2016-05-07 17:23:34 --> Controller Class Initialized
INFO - 2016-05-07 17:23:34 --> Model Class Initialized
INFO - 2016-05-07 17:23:34 --> Database Driver Class Initialized
INFO - 2016-05-07 17:23:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:23:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:23:34 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:23:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:23:34 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 17:23:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:23:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:23:35 --> Final output sent to browser
DEBUG - 2016-05-07 17:23:35 --> Total execution time: 0.1127
INFO - 2016-05-07 17:23:37 --> Config Class Initialized
INFO - 2016-05-07 17:23:37 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:23:37 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:23:37 --> Utf8 Class Initialized
INFO - 2016-05-07 17:23:37 --> URI Class Initialized
INFO - 2016-05-07 17:23:37 --> Router Class Initialized
INFO - 2016-05-07 17:23:37 --> Output Class Initialized
INFO - 2016-05-07 17:23:37 --> Security Class Initialized
DEBUG - 2016-05-07 17:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:23:37 --> Input Class Initialized
INFO - 2016-05-07 17:23:37 --> Language Class Initialized
INFO - 2016-05-07 17:23:37 --> Loader Class Initialized
INFO - 2016-05-07 17:23:37 --> Helper loaded: url_helper
INFO - 2016-05-07 17:23:37 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:23:37 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:23:37 --> Helper loaded: form_helper
INFO - 2016-05-07 17:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:23:37 --> Form Validation Class Initialized
INFO - 2016-05-07 17:23:37 --> Controller Class Initialized
INFO - 2016-05-07 17:23:37 --> Model Class Initialized
INFO - 2016-05-07 17:23:37 --> Database Driver Class Initialized
INFO - 2016-05-07 17:23:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:23:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:23:37 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:23:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:23:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:23:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:23:38 --> Final output sent to browser
DEBUG - 2016-05-07 17:23:38 --> Total execution time: 0.4140
INFO - 2016-05-07 17:23:41 --> Config Class Initialized
INFO - 2016-05-07 17:23:41 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:23:41 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:23:41 --> Utf8 Class Initialized
INFO - 2016-05-07 17:23:41 --> URI Class Initialized
INFO - 2016-05-07 17:23:41 --> Router Class Initialized
INFO - 2016-05-07 17:23:41 --> Output Class Initialized
INFO - 2016-05-07 17:23:41 --> Security Class Initialized
DEBUG - 2016-05-07 17:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:23:41 --> Input Class Initialized
INFO - 2016-05-07 17:23:41 --> Language Class Initialized
INFO - 2016-05-07 17:23:41 --> Loader Class Initialized
INFO - 2016-05-07 17:23:41 --> Helper loaded: url_helper
INFO - 2016-05-07 17:23:41 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:23:41 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:23:41 --> Helper loaded: form_helper
INFO - 2016-05-07 17:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:23:41 --> Form Validation Class Initialized
INFO - 2016-05-07 17:23:41 --> Controller Class Initialized
INFO - 2016-05-07 17:23:41 --> Model Class Initialized
INFO - 2016-05-07 17:23:41 --> Database Driver Class Initialized
INFO - 2016-05-07 17:23:41 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:23:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:23:41 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:23:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:23:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:23:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:23:41 --> Final output sent to browser
DEBUG - 2016-05-07 17:23:41 --> Total execution time: 0.2153
INFO - 2016-05-07 17:23:49 --> Config Class Initialized
INFO - 2016-05-07 17:23:49 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:23:49 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:23:49 --> Utf8 Class Initialized
INFO - 2016-05-07 17:23:49 --> URI Class Initialized
INFO - 2016-05-07 17:23:49 --> Router Class Initialized
INFO - 2016-05-07 17:23:49 --> Output Class Initialized
INFO - 2016-05-07 17:23:49 --> Security Class Initialized
DEBUG - 2016-05-07 17:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:23:49 --> Input Class Initialized
INFO - 2016-05-07 17:23:49 --> Language Class Initialized
INFO - 2016-05-07 17:23:49 --> Loader Class Initialized
INFO - 2016-05-07 17:23:49 --> Helper loaded: url_helper
INFO - 2016-05-07 17:23:49 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:23:49 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:23:49 --> Helper loaded: form_helper
INFO - 2016-05-07 17:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:23:49 --> Form Validation Class Initialized
INFO - 2016-05-07 17:23:49 --> Controller Class Initialized
INFO - 2016-05-07 17:23:49 --> Model Class Initialized
INFO - 2016-05-07 17:23:49 --> Database Driver Class Initialized
INFO - 2016-05-07 17:23:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:23:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:23:49 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:23:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:23:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:23:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:23:49 --> Final output sent to browser
DEBUG - 2016-05-07 17:23:49 --> Total execution time: 0.1018
INFO - 2016-05-07 17:24:23 --> Config Class Initialized
INFO - 2016-05-07 17:24:23 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:24:23 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:24:23 --> Utf8 Class Initialized
INFO - 2016-05-07 17:24:23 --> URI Class Initialized
INFO - 2016-05-07 17:24:23 --> Router Class Initialized
INFO - 2016-05-07 17:24:23 --> Output Class Initialized
INFO - 2016-05-07 17:24:23 --> Security Class Initialized
DEBUG - 2016-05-07 17:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:24:23 --> Input Class Initialized
INFO - 2016-05-07 17:24:23 --> Language Class Initialized
INFO - 2016-05-07 17:24:23 --> Loader Class Initialized
INFO - 2016-05-07 17:24:23 --> Helper loaded: url_helper
INFO - 2016-05-07 17:24:23 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:24:23 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:24:23 --> Helper loaded: form_helper
INFO - 2016-05-07 17:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:24:23 --> Form Validation Class Initialized
INFO - 2016-05-07 17:24:23 --> Controller Class Initialized
INFO - 2016-05-07 17:24:23 --> Model Class Initialized
INFO - 2016-05-07 17:24:23 --> Database Driver Class Initialized
INFO - 2016-05-07 17:24:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:24:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:24:23 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:24:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:24:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:24:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:24:23 --> Final output sent to browser
DEBUG - 2016-05-07 17:24:23 --> Total execution time: 0.1033
INFO - 2016-05-07 17:26:05 --> Config Class Initialized
INFO - 2016-05-07 17:26:05 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:26:05 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:26:05 --> Utf8 Class Initialized
INFO - 2016-05-07 17:26:05 --> URI Class Initialized
INFO - 2016-05-07 17:26:05 --> Router Class Initialized
INFO - 2016-05-07 17:26:05 --> Output Class Initialized
INFO - 2016-05-07 17:26:05 --> Security Class Initialized
DEBUG - 2016-05-07 17:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:26:05 --> Input Class Initialized
INFO - 2016-05-07 17:26:05 --> Language Class Initialized
INFO - 2016-05-07 17:26:05 --> Loader Class Initialized
INFO - 2016-05-07 17:26:05 --> Helper loaded: url_helper
INFO - 2016-05-07 17:26:05 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:26:05 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:26:05 --> Helper loaded: form_helper
INFO - 2016-05-07 17:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:26:05 --> Form Validation Class Initialized
INFO - 2016-05-07 17:26:05 --> Controller Class Initialized
INFO - 2016-05-07 17:26:05 --> Model Class Initialized
INFO - 2016-05-07 17:26:05 --> Database Driver Class Initialized
INFO - 2016-05-07 17:26:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:26:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:26:05 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:26:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:26:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:26:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:26:05 --> Final output sent to browser
DEBUG - 2016-05-07 17:26:05 --> Total execution time: 0.0799
INFO - 2016-05-07 17:26:09 --> Config Class Initialized
INFO - 2016-05-07 17:26:09 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:26:09 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:26:09 --> Utf8 Class Initialized
INFO - 2016-05-07 17:26:09 --> URI Class Initialized
INFO - 2016-05-07 17:26:09 --> Router Class Initialized
INFO - 2016-05-07 17:26:09 --> Output Class Initialized
INFO - 2016-05-07 17:26:09 --> Security Class Initialized
DEBUG - 2016-05-07 17:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:26:09 --> Input Class Initialized
INFO - 2016-05-07 17:26:09 --> Language Class Initialized
INFO - 2016-05-07 17:26:09 --> Loader Class Initialized
INFO - 2016-05-07 17:26:09 --> Helper loaded: url_helper
INFO - 2016-05-07 17:26:09 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:26:09 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:26:09 --> Helper loaded: form_helper
INFO - 2016-05-07 17:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:26:09 --> Form Validation Class Initialized
INFO - 2016-05-07 17:26:09 --> Controller Class Initialized
INFO - 2016-05-07 17:26:09 --> Model Class Initialized
INFO - 2016-05-07 17:26:09 --> Database Driver Class Initialized
INFO - 2016-05-07 17:26:09 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:26:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:26:09 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:26:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:26:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:26:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:26:09 --> Final output sent to browser
DEBUG - 2016-05-07 17:26:09 --> Total execution time: 0.1101
INFO - 2016-05-07 17:26:11 --> Config Class Initialized
INFO - 2016-05-07 17:26:11 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:26:11 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:26:11 --> Utf8 Class Initialized
INFO - 2016-05-07 17:26:11 --> URI Class Initialized
INFO - 2016-05-07 17:26:11 --> Router Class Initialized
INFO - 2016-05-07 17:26:11 --> Output Class Initialized
INFO - 2016-05-07 17:26:11 --> Security Class Initialized
DEBUG - 2016-05-07 17:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:26:11 --> Input Class Initialized
INFO - 2016-05-07 17:26:11 --> Language Class Initialized
INFO - 2016-05-07 17:26:11 --> Loader Class Initialized
INFO - 2016-05-07 17:26:11 --> Helper loaded: url_helper
INFO - 2016-05-07 17:26:11 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:26:11 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:26:11 --> Helper loaded: form_helper
INFO - 2016-05-07 17:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:26:11 --> Form Validation Class Initialized
INFO - 2016-05-07 17:26:11 --> Controller Class Initialized
INFO - 2016-05-07 17:26:11 --> Model Class Initialized
INFO - 2016-05-07 17:26:11 --> Database Driver Class Initialized
INFO - 2016-05-07 17:26:11 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:26:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:26:11 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:26:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:26:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 17:26:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:26:11 --> Final output sent to browser
DEBUG - 2016-05-07 17:26:11 --> Total execution time: 0.1328
INFO - 2016-05-07 17:26:14 --> Config Class Initialized
INFO - 2016-05-07 17:26:14 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:26:14 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:26:14 --> Utf8 Class Initialized
INFO - 2016-05-07 17:26:14 --> URI Class Initialized
INFO - 2016-05-07 17:26:14 --> Router Class Initialized
INFO - 2016-05-07 17:26:14 --> Output Class Initialized
INFO - 2016-05-07 17:26:14 --> Security Class Initialized
DEBUG - 2016-05-07 17:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:26:14 --> Input Class Initialized
INFO - 2016-05-07 17:26:14 --> Language Class Initialized
INFO - 2016-05-07 17:26:14 --> Loader Class Initialized
INFO - 2016-05-07 17:26:14 --> Helper loaded: url_helper
INFO - 2016-05-07 17:26:14 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:26:14 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:26:14 --> Helper loaded: form_helper
INFO - 2016-05-07 17:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:26:14 --> Form Validation Class Initialized
INFO - 2016-05-07 17:26:14 --> Controller Class Initialized
INFO - 2016-05-07 17:26:14 --> Model Class Initialized
INFO - 2016-05-07 17:26:14 --> Database Driver Class Initialized
INFO - 2016-05-07 17:26:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:26:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:26:14 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:26:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:26:14 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 17:26:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:26:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:26:14 --> Final output sent to browser
DEBUG - 2016-05-07 17:26:14 --> Total execution time: 0.1216
INFO - 2016-05-07 17:26:23 --> Config Class Initialized
INFO - 2016-05-07 17:26:23 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:26:23 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:26:23 --> Utf8 Class Initialized
INFO - 2016-05-07 17:26:23 --> URI Class Initialized
INFO - 2016-05-07 17:26:23 --> Router Class Initialized
INFO - 2016-05-07 17:26:23 --> Output Class Initialized
INFO - 2016-05-07 17:26:23 --> Security Class Initialized
DEBUG - 2016-05-07 17:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:26:23 --> Input Class Initialized
INFO - 2016-05-07 17:26:23 --> Language Class Initialized
INFO - 2016-05-07 17:26:23 --> Loader Class Initialized
INFO - 2016-05-07 17:26:23 --> Helper loaded: url_helper
INFO - 2016-05-07 17:26:23 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:26:23 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:26:23 --> Helper loaded: form_helper
INFO - 2016-05-07 17:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:26:23 --> Form Validation Class Initialized
INFO - 2016-05-07 17:26:23 --> Controller Class Initialized
INFO - 2016-05-07 17:26:23 --> Model Class Initialized
INFO - 2016-05-07 17:26:23 --> Database Driver Class Initialized
INFO - 2016-05-07 17:26:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:26:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:26:23 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:26:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:26:23 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 17:26:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:26:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:26:23 --> Final output sent to browser
DEBUG - 2016-05-07 17:26:23 --> Total execution time: 0.0984
INFO - 2016-05-07 17:26:47 --> Config Class Initialized
INFO - 2016-05-07 17:26:47 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:26:47 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:26:47 --> Utf8 Class Initialized
INFO - 2016-05-07 17:26:47 --> URI Class Initialized
INFO - 2016-05-07 17:26:47 --> Router Class Initialized
INFO - 2016-05-07 17:26:47 --> Output Class Initialized
INFO - 2016-05-07 17:26:47 --> Security Class Initialized
DEBUG - 2016-05-07 17:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:26:47 --> Input Class Initialized
INFO - 2016-05-07 17:26:47 --> Language Class Initialized
INFO - 2016-05-07 17:26:47 --> Loader Class Initialized
INFO - 2016-05-07 17:26:47 --> Helper loaded: url_helper
INFO - 2016-05-07 17:26:47 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:26:47 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:26:47 --> Helper loaded: form_helper
INFO - 2016-05-07 17:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:26:47 --> Form Validation Class Initialized
INFO - 2016-05-07 17:26:47 --> Controller Class Initialized
INFO - 2016-05-07 17:26:47 --> Model Class Initialized
INFO - 2016-05-07 17:26:47 --> Database Driver Class Initialized
INFO - 2016-05-07 17:26:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:26:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:26:47 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:26:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:26:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:26:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:26:47 --> Final output sent to browser
DEBUG - 2016-05-07 17:26:47 --> Total execution time: 0.1346
INFO - 2016-05-07 17:26:54 --> Config Class Initialized
INFO - 2016-05-07 17:26:54 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:26:54 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:26:54 --> Utf8 Class Initialized
INFO - 2016-05-07 17:26:54 --> URI Class Initialized
INFO - 2016-05-07 17:26:54 --> Router Class Initialized
INFO - 2016-05-07 17:26:54 --> Output Class Initialized
INFO - 2016-05-07 17:26:54 --> Security Class Initialized
DEBUG - 2016-05-07 17:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:26:54 --> Input Class Initialized
INFO - 2016-05-07 17:26:54 --> Language Class Initialized
INFO - 2016-05-07 17:26:54 --> Loader Class Initialized
INFO - 2016-05-07 17:26:54 --> Helper loaded: url_helper
INFO - 2016-05-07 17:26:54 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:26:54 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:26:54 --> Helper loaded: form_helper
INFO - 2016-05-07 17:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:26:54 --> Form Validation Class Initialized
INFO - 2016-05-07 17:26:54 --> Controller Class Initialized
INFO - 2016-05-07 17:26:54 --> Model Class Initialized
INFO - 2016-05-07 17:26:54 --> Database Driver Class Initialized
INFO - 2016-05-07 17:26:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:26:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:26:54 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:26:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:26:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:26:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:26:54 --> Final output sent to browser
DEBUG - 2016-05-07 17:26:54 --> Total execution time: 0.1963
INFO - 2016-05-07 17:27:19 --> Config Class Initialized
INFO - 2016-05-07 17:27:19 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:27:19 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:27:19 --> Utf8 Class Initialized
INFO - 2016-05-07 17:27:19 --> URI Class Initialized
INFO - 2016-05-07 17:27:19 --> Router Class Initialized
INFO - 2016-05-07 17:27:19 --> Output Class Initialized
INFO - 2016-05-07 17:27:19 --> Security Class Initialized
DEBUG - 2016-05-07 17:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:27:19 --> Input Class Initialized
INFO - 2016-05-07 17:27:19 --> Language Class Initialized
INFO - 2016-05-07 17:27:19 --> Loader Class Initialized
INFO - 2016-05-07 17:27:19 --> Helper loaded: url_helper
INFO - 2016-05-07 17:27:19 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:27:19 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:27:19 --> Helper loaded: form_helper
INFO - 2016-05-07 17:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:27:19 --> Form Validation Class Initialized
INFO - 2016-05-07 17:27:19 --> Controller Class Initialized
INFO - 2016-05-07 17:27:19 --> Model Class Initialized
INFO - 2016-05-07 17:27:19 --> Database Driver Class Initialized
INFO - 2016-05-07 17:27:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:27:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:27:19 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:27:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:27:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 17:27:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:27:19 --> Final output sent to browser
DEBUG - 2016-05-07 17:27:19 --> Total execution time: 0.1652
INFO - 2016-05-07 17:27:21 --> Config Class Initialized
INFO - 2016-05-07 17:27:21 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:27:21 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:27:21 --> Utf8 Class Initialized
INFO - 2016-05-07 17:27:21 --> URI Class Initialized
INFO - 2016-05-07 17:27:21 --> Router Class Initialized
INFO - 2016-05-07 17:27:21 --> Output Class Initialized
INFO - 2016-05-07 17:27:21 --> Security Class Initialized
DEBUG - 2016-05-07 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:27:21 --> Input Class Initialized
INFO - 2016-05-07 17:27:21 --> Language Class Initialized
INFO - 2016-05-07 17:27:21 --> Loader Class Initialized
INFO - 2016-05-07 17:27:21 --> Helper loaded: url_helper
INFO - 2016-05-07 17:27:21 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:27:21 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:27:21 --> Helper loaded: form_helper
INFO - 2016-05-07 17:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:27:21 --> Form Validation Class Initialized
INFO - 2016-05-07 17:27:21 --> Controller Class Initialized
INFO - 2016-05-07 17:27:21 --> Model Class Initialized
INFO - 2016-05-07 17:27:21 --> Database Driver Class Initialized
INFO - 2016-05-07 17:27:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:27:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:27:21 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:27:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:27:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 17:27:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:27:21 --> Final output sent to browser
DEBUG - 2016-05-07 17:27:21 --> Total execution time: 0.0870
INFO - 2016-05-07 17:27:22 --> Config Class Initialized
INFO - 2016-05-07 17:27:22 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:27:22 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:27:22 --> Utf8 Class Initialized
INFO - 2016-05-07 17:27:22 --> URI Class Initialized
INFO - 2016-05-07 17:27:22 --> Router Class Initialized
INFO - 2016-05-07 17:27:22 --> Output Class Initialized
INFO - 2016-05-07 17:27:22 --> Security Class Initialized
DEBUG - 2016-05-07 17:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:27:22 --> Input Class Initialized
INFO - 2016-05-07 17:27:22 --> Language Class Initialized
INFO - 2016-05-07 17:27:22 --> Loader Class Initialized
INFO - 2016-05-07 17:27:22 --> Helper loaded: url_helper
INFO - 2016-05-07 17:27:22 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:27:22 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:27:22 --> Helper loaded: form_helper
INFO - 2016-05-07 17:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:27:22 --> Form Validation Class Initialized
INFO - 2016-05-07 17:27:22 --> Controller Class Initialized
INFO - 2016-05-07 17:27:22 --> Model Class Initialized
INFO - 2016-05-07 17:27:22 --> Database Driver Class Initialized
INFO - 2016-05-07 17:27:22 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:27:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:27:22 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:27:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:27:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 17:27:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:27:22 --> Final output sent to browser
DEBUG - 2016-05-07 17:27:22 --> Total execution time: 0.1719
INFO - 2016-05-07 17:27:22 --> Config Class Initialized
INFO - 2016-05-07 17:27:22 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:27:22 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:27:22 --> Utf8 Class Initialized
INFO - 2016-05-07 17:27:22 --> URI Class Initialized
INFO - 2016-05-07 17:27:22 --> Router Class Initialized
INFO - 2016-05-07 17:27:22 --> Output Class Initialized
INFO - 2016-05-07 17:27:22 --> Security Class Initialized
DEBUG - 2016-05-07 17:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:27:22 --> Input Class Initialized
INFO - 2016-05-07 17:27:22 --> Language Class Initialized
INFO - 2016-05-07 17:27:22 --> Loader Class Initialized
INFO - 2016-05-07 17:27:22 --> Helper loaded: url_helper
INFO - 2016-05-07 17:27:22 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:27:22 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:27:22 --> Helper loaded: form_helper
INFO - 2016-05-07 17:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:27:22 --> Form Validation Class Initialized
INFO - 2016-05-07 17:27:22 --> Controller Class Initialized
INFO - 2016-05-07 17:27:22 --> Model Class Initialized
INFO - 2016-05-07 17:27:22 --> Database Driver Class Initialized
INFO - 2016-05-07 17:27:22 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:27:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:27:22 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:27:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:27:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:27:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:27:22 --> Final output sent to browser
DEBUG - 2016-05-07 17:27:22 --> Total execution time: 0.0992
INFO - 2016-05-07 17:29:00 --> Config Class Initialized
INFO - 2016-05-07 17:29:00 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:29:00 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:29:00 --> Utf8 Class Initialized
INFO - 2016-05-07 17:29:00 --> URI Class Initialized
INFO - 2016-05-07 17:29:00 --> Router Class Initialized
INFO - 2016-05-07 17:29:00 --> Output Class Initialized
INFO - 2016-05-07 17:29:00 --> Security Class Initialized
DEBUG - 2016-05-07 17:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:29:00 --> Input Class Initialized
INFO - 2016-05-07 17:29:00 --> Language Class Initialized
INFO - 2016-05-07 17:29:00 --> Loader Class Initialized
INFO - 2016-05-07 17:29:00 --> Helper loaded: url_helper
INFO - 2016-05-07 17:29:00 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:29:00 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:29:00 --> Helper loaded: form_helper
INFO - 2016-05-07 17:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:29:00 --> Form Validation Class Initialized
INFO - 2016-05-07 17:29:00 --> Controller Class Initialized
INFO - 2016-05-07 17:29:00 --> Model Class Initialized
INFO - 2016-05-07 17:29:00 --> Database Driver Class Initialized
INFO - 2016-05-07 17:29:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:29:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:29:00 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:29:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:29:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:29:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:29:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:29:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:29:00 --> Final output sent to browser
DEBUG - 2016-05-07 17:29:00 --> Total execution time: 0.2090
INFO - 2016-05-07 17:30:38 --> Config Class Initialized
INFO - 2016-05-07 17:30:38 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:30:38 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:30:38 --> Utf8 Class Initialized
INFO - 2016-05-07 17:30:38 --> URI Class Initialized
INFO - 2016-05-07 17:30:38 --> Router Class Initialized
INFO - 2016-05-07 17:30:38 --> Output Class Initialized
INFO - 2016-05-07 17:30:38 --> Security Class Initialized
DEBUG - 2016-05-07 17:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:30:38 --> Input Class Initialized
INFO - 2016-05-07 17:30:38 --> Language Class Initialized
INFO - 2016-05-07 17:30:38 --> Loader Class Initialized
INFO - 2016-05-07 17:30:38 --> Helper loaded: url_helper
INFO - 2016-05-07 17:30:38 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:30:38 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:30:38 --> Helper loaded: form_helper
INFO - 2016-05-07 17:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:30:38 --> Form Validation Class Initialized
INFO - 2016-05-07 17:30:38 --> Controller Class Initialized
INFO - 2016-05-07 17:30:38 --> Model Class Initialized
INFO - 2016-05-07 17:30:38 --> Database Driver Class Initialized
INFO - 2016-05-07 17:30:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:30:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:30:38 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:30:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:30:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:30:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:30:39 --> Final output sent to browser
DEBUG - 2016-05-07 17:30:39 --> Total execution time: 0.1419
INFO - 2016-05-07 17:30:45 --> Config Class Initialized
INFO - 2016-05-07 17:30:45 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:30:45 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:30:45 --> Utf8 Class Initialized
INFO - 2016-05-07 17:30:45 --> URI Class Initialized
INFO - 2016-05-07 17:30:45 --> Router Class Initialized
INFO - 2016-05-07 17:30:45 --> Output Class Initialized
INFO - 2016-05-07 17:30:45 --> Security Class Initialized
DEBUG - 2016-05-07 17:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:30:45 --> Input Class Initialized
INFO - 2016-05-07 17:30:45 --> Language Class Initialized
INFO - 2016-05-07 17:30:45 --> Loader Class Initialized
INFO - 2016-05-07 17:30:45 --> Helper loaded: url_helper
INFO - 2016-05-07 17:30:45 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:30:45 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:30:45 --> Helper loaded: form_helper
INFO - 2016-05-07 17:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:30:45 --> Form Validation Class Initialized
INFO - 2016-05-07 17:30:45 --> Controller Class Initialized
INFO - 2016-05-07 17:30:45 --> Model Class Initialized
INFO - 2016-05-07 17:30:45 --> Database Driver Class Initialized
INFO - 2016-05-07 17:30:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:30:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:30:45 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:30:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:30:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:30:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:30:45 --> Final output sent to browser
DEBUG - 2016-05-07 17:30:45 --> Total execution time: 0.1470
INFO - 2016-05-07 17:30:49 --> Config Class Initialized
INFO - 2016-05-07 17:30:49 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:30:49 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:30:49 --> Utf8 Class Initialized
INFO - 2016-05-07 17:30:49 --> URI Class Initialized
INFO - 2016-05-07 17:30:49 --> Router Class Initialized
INFO - 2016-05-07 17:30:49 --> Output Class Initialized
INFO - 2016-05-07 17:30:49 --> Security Class Initialized
DEBUG - 2016-05-07 17:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:30:49 --> Input Class Initialized
INFO - 2016-05-07 17:30:49 --> Language Class Initialized
INFO - 2016-05-07 17:30:49 --> Loader Class Initialized
INFO - 2016-05-07 17:30:49 --> Helper loaded: url_helper
INFO - 2016-05-07 17:30:49 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:30:49 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:30:49 --> Helper loaded: form_helper
INFO - 2016-05-07 17:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:30:49 --> Form Validation Class Initialized
INFO - 2016-05-07 17:30:49 --> Controller Class Initialized
INFO - 2016-05-07 17:30:49 --> Model Class Initialized
INFO - 2016-05-07 17:30:49 --> Database Driver Class Initialized
INFO - 2016-05-07 17:30:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:30:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:30:49 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:30:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:30:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 17:30:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:30:49 --> Final output sent to browser
DEBUG - 2016-05-07 17:30:49 --> Total execution time: 0.1191
INFO - 2016-05-07 17:30:51 --> Config Class Initialized
INFO - 2016-05-07 17:30:51 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:30:51 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:30:51 --> Utf8 Class Initialized
INFO - 2016-05-07 17:30:51 --> URI Class Initialized
INFO - 2016-05-07 17:30:51 --> Router Class Initialized
INFO - 2016-05-07 17:30:51 --> Output Class Initialized
INFO - 2016-05-07 17:30:51 --> Security Class Initialized
DEBUG - 2016-05-07 17:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:30:51 --> Input Class Initialized
INFO - 2016-05-07 17:30:51 --> Language Class Initialized
INFO - 2016-05-07 17:30:51 --> Loader Class Initialized
INFO - 2016-05-07 17:30:51 --> Helper loaded: url_helper
INFO - 2016-05-07 17:30:51 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:30:51 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:30:51 --> Helper loaded: form_helper
INFO - 2016-05-07 17:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:30:51 --> Form Validation Class Initialized
INFO - 2016-05-07 17:30:51 --> Controller Class Initialized
INFO - 2016-05-07 17:30:51 --> Model Class Initialized
INFO - 2016-05-07 17:30:51 --> Database Driver Class Initialized
INFO - 2016-05-07 17:30:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:30:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:30:51 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:30:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:30:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:30:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:30:51 --> Final output sent to browser
DEBUG - 2016-05-07 17:30:51 --> Total execution time: 0.1067
INFO - 2016-05-07 17:30:52 --> Config Class Initialized
INFO - 2016-05-07 17:30:52 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:30:52 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:30:52 --> Utf8 Class Initialized
INFO - 2016-05-07 17:30:52 --> URI Class Initialized
INFO - 2016-05-07 17:30:52 --> Router Class Initialized
INFO - 2016-05-07 17:30:52 --> Output Class Initialized
INFO - 2016-05-07 17:30:52 --> Security Class Initialized
DEBUG - 2016-05-07 17:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:30:52 --> Input Class Initialized
INFO - 2016-05-07 17:30:52 --> Language Class Initialized
INFO - 2016-05-07 17:30:52 --> Loader Class Initialized
INFO - 2016-05-07 17:30:52 --> Helper loaded: url_helper
INFO - 2016-05-07 17:30:52 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:30:52 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:30:52 --> Helper loaded: form_helper
INFO - 2016-05-07 17:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:30:52 --> Form Validation Class Initialized
INFO - 2016-05-07 17:30:52 --> Controller Class Initialized
INFO - 2016-05-07 17:30:52 --> Model Class Initialized
INFO - 2016-05-07 17:30:52 --> Database Driver Class Initialized
INFO - 2016-05-07 17:30:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:30:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:30:52 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:30:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:30:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 17:30:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:30:52 --> Final output sent to browser
DEBUG - 2016-05-07 17:30:52 --> Total execution time: 0.1355
INFO - 2016-05-07 17:34:09 --> Config Class Initialized
INFO - 2016-05-07 17:34:09 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:09 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:09 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:09 --> URI Class Initialized
INFO - 2016-05-07 17:34:09 --> Router Class Initialized
INFO - 2016-05-07 17:34:09 --> Output Class Initialized
INFO - 2016-05-07 17:34:09 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:09 --> Input Class Initialized
INFO - 2016-05-07 17:34:09 --> Language Class Initialized
INFO - 2016-05-07 17:34:09 --> Loader Class Initialized
INFO - 2016-05-07 17:34:09 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:09 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:09 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:09 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:09 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:09 --> Controller Class Initialized
INFO - 2016-05-07 17:34:09 --> Model Class Initialized
INFO - 2016-05-07 17:34:09 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:09 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:09 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:34:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:10 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:10 --> Total execution time: 0.2400
INFO - 2016-05-07 17:34:31 --> Config Class Initialized
INFO - 2016-05-07 17:34:31 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:31 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:31 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:31 --> URI Class Initialized
INFO - 2016-05-07 17:34:31 --> Router Class Initialized
INFO - 2016-05-07 17:34:31 --> Output Class Initialized
INFO - 2016-05-07 17:34:31 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:31 --> Input Class Initialized
INFO - 2016-05-07 17:34:31 --> Language Class Initialized
INFO - 2016-05-07 17:34:31 --> Loader Class Initialized
INFO - 2016-05-07 17:34:31 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:31 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:31 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:31 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:31 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:31 --> Controller Class Initialized
INFO - 2016-05-07 17:34:31 --> Model Class Initialized
INFO - 2016-05-07 17:34:32 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:32 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:32 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:34:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:32 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:32 --> Total execution time: 0.1024
INFO - 2016-05-07 17:34:34 --> Config Class Initialized
INFO - 2016-05-07 17:34:34 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:34 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:34 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:34 --> URI Class Initialized
INFO - 2016-05-07 17:34:34 --> Router Class Initialized
INFO - 2016-05-07 17:34:34 --> Output Class Initialized
INFO - 2016-05-07 17:34:34 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:34 --> Input Class Initialized
INFO - 2016-05-07 17:34:34 --> Language Class Initialized
INFO - 2016-05-07 17:34:34 --> Loader Class Initialized
INFO - 2016-05-07 17:34:34 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:34 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:34 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:34 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:34 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:34 --> Controller Class Initialized
INFO - 2016-05-07 17:34:34 --> Model Class Initialized
INFO - 2016-05-07 17:34:34 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:34 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 17:34:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:34 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:34 --> Total execution time: 0.1015
INFO - 2016-05-07 17:34:36 --> Config Class Initialized
INFO - 2016-05-07 17:34:36 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:36 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:36 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:36 --> URI Class Initialized
INFO - 2016-05-07 17:34:36 --> Router Class Initialized
INFO - 2016-05-07 17:34:36 --> Output Class Initialized
INFO - 2016-05-07 17:34:36 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:36 --> Input Class Initialized
INFO - 2016-05-07 17:34:36 --> Language Class Initialized
INFO - 2016-05-07 17:34:36 --> Loader Class Initialized
INFO - 2016-05-07 17:34:36 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:36 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:36 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:36 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:36 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:36 --> Controller Class Initialized
INFO - 2016-05-07 17:34:36 --> Model Class Initialized
INFO - 2016-05-07 17:34:36 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:36 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:34:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:36 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:36 --> Total execution time: 0.0995
INFO - 2016-05-07 17:34:37 --> Config Class Initialized
INFO - 2016-05-07 17:34:37 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:37 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:37 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:37 --> URI Class Initialized
INFO - 2016-05-07 17:34:37 --> Router Class Initialized
INFO - 2016-05-07 17:34:37 --> Output Class Initialized
INFO - 2016-05-07 17:34:37 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:37 --> Input Class Initialized
INFO - 2016-05-07 17:34:37 --> Language Class Initialized
INFO - 2016-05-07 17:34:37 --> Loader Class Initialized
INFO - 2016-05-07 17:34:37 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:37 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:37 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:37 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:37 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:37 --> Controller Class Initialized
INFO - 2016-05-07 17:34:37 --> Model Class Initialized
INFO - 2016-05-07 17:34:38 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:38 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 17:34:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:38 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:38 --> Total execution time: 0.1259
INFO - 2016-05-07 17:34:38 --> Config Class Initialized
INFO - 2016-05-07 17:34:38 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:38 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:38 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:38 --> URI Class Initialized
INFO - 2016-05-07 17:34:38 --> Router Class Initialized
INFO - 2016-05-07 17:34:38 --> Output Class Initialized
INFO - 2016-05-07 17:34:38 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:38 --> Input Class Initialized
INFO - 2016-05-07 17:34:38 --> Language Class Initialized
INFO - 2016-05-07 17:34:38 --> Loader Class Initialized
INFO - 2016-05-07 17:34:38 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:38 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:38 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:38 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:38 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:38 --> Controller Class Initialized
INFO - 2016-05-07 17:34:38 --> Model Class Initialized
INFO - 2016-05-07 17:34:38 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:38 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:34:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:38 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:38 --> Total execution time: 0.0904
INFO - 2016-05-07 17:34:40 --> Config Class Initialized
INFO - 2016-05-07 17:34:40 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:40 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:40 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:40 --> URI Class Initialized
INFO - 2016-05-07 17:34:40 --> Router Class Initialized
INFO - 2016-05-07 17:34:40 --> Output Class Initialized
INFO - 2016-05-07 17:34:40 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:40 --> Input Class Initialized
INFO - 2016-05-07 17:34:40 --> Language Class Initialized
INFO - 2016-05-07 17:34:40 --> Loader Class Initialized
INFO - 2016-05-07 17:34:40 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:40 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:40 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:40 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:40 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:40 --> Controller Class Initialized
INFO - 2016-05-07 17:34:40 --> Model Class Initialized
INFO - 2016-05-07 17:34:40 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:40 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 17:34:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:40 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:40 --> Total execution time: 0.1182
INFO - 2016-05-07 17:34:42 --> Config Class Initialized
INFO - 2016-05-07 17:34:42 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:42 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:42 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:42 --> URI Class Initialized
INFO - 2016-05-07 17:34:42 --> Router Class Initialized
INFO - 2016-05-07 17:34:42 --> Output Class Initialized
INFO - 2016-05-07 17:34:42 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:42 --> Input Class Initialized
INFO - 2016-05-07 17:34:42 --> Language Class Initialized
INFO - 2016-05-07 17:34:42 --> Loader Class Initialized
INFO - 2016-05-07 17:34:42 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:42 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:42 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:42 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:42 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:42 --> Controller Class Initialized
INFO - 2016-05-07 17:34:42 --> Model Class Initialized
INFO - 2016-05-07 17:34:42 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:42 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:42 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:34:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:42 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:42 --> Total execution time: 0.0812
INFO - 2016-05-07 17:34:43 --> Config Class Initialized
INFO - 2016-05-07 17:34:43 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:43 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:43 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:43 --> URI Class Initialized
INFO - 2016-05-07 17:34:43 --> Router Class Initialized
INFO - 2016-05-07 17:34:43 --> Output Class Initialized
INFO - 2016-05-07 17:34:43 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:43 --> Input Class Initialized
INFO - 2016-05-07 17:34:43 --> Language Class Initialized
INFO - 2016-05-07 17:34:43 --> Loader Class Initialized
INFO - 2016-05-07 17:34:43 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:43 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:43 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:43 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:43 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:43 --> Controller Class Initialized
INFO - 2016-05-07 17:34:43 --> Model Class Initialized
INFO - 2016-05-07 17:34:43 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:43 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 17:34:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:43 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:43 --> Total execution time: 0.1287
INFO - 2016-05-07 17:34:44 --> Config Class Initialized
INFO - 2016-05-07 17:34:44 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:44 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:44 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:44 --> URI Class Initialized
INFO - 2016-05-07 17:34:44 --> Router Class Initialized
INFO - 2016-05-07 17:34:44 --> Output Class Initialized
INFO - 2016-05-07 17:34:44 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:44 --> Input Class Initialized
INFO - 2016-05-07 17:34:44 --> Language Class Initialized
INFO - 2016-05-07 17:34:44 --> Loader Class Initialized
INFO - 2016-05-07 17:34:44 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:44 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:44 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:44 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:44 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:44 --> Controller Class Initialized
INFO - 2016-05-07 17:34:44 --> Model Class Initialized
INFO - 2016-05-07 17:34:44 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:44 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:44 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:34:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:44 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:44 --> Total execution time: 0.1092
INFO - 2016-05-07 17:34:45 --> Config Class Initialized
INFO - 2016-05-07 17:34:45 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:45 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:45 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:45 --> URI Class Initialized
INFO - 2016-05-07 17:34:45 --> Router Class Initialized
INFO - 2016-05-07 17:34:45 --> Output Class Initialized
INFO - 2016-05-07 17:34:45 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:45 --> Input Class Initialized
INFO - 2016-05-07 17:34:45 --> Language Class Initialized
INFO - 2016-05-07 17:34:45 --> Loader Class Initialized
INFO - 2016-05-07 17:34:45 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:45 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:45 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:45 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:45 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:45 --> Controller Class Initialized
INFO - 2016-05-07 17:34:45 --> Model Class Initialized
INFO - 2016-05-07 17:34:45 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:45 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 17:34:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:45 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:45 --> Total execution time: 0.1103
INFO - 2016-05-07 17:34:46 --> Config Class Initialized
INFO - 2016-05-07 17:34:46 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:46 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:46 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:46 --> URI Class Initialized
INFO - 2016-05-07 17:34:46 --> Router Class Initialized
INFO - 2016-05-07 17:34:46 --> Output Class Initialized
INFO - 2016-05-07 17:34:46 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:46 --> Input Class Initialized
INFO - 2016-05-07 17:34:46 --> Language Class Initialized
INFO - 2016-05-07 17:34:46 --> Loader Class Initialized
INFO - 2016-05-07 17:34:46 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:46 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:46 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:46 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:46 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:46 --> Controller Class Initialized
INFO - 2016-05-07 17:34:46 --> Model Class Initialized
INFO - 2016-05-07 17:34:46 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:46 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:34:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:46 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:46 --> Total execution time: 0.0914
INFO - 2016-05-07 17:34:48 --> Config Class Initialized
INFO - 2016-05-07 17:34:48 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:48 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:48 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:48 --> URI Class Initialized
INFO - 2016-05-07 17:34:48 --> Router Class Initialized
INFO - 2016-05-07 17:34:48 --> Output Class Initialized
INFO - 2016-05-07 17:34:48 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:48 --> Input Class Initialized
INFO - 2016-05-07 17:34:48 --> Language Class Initialized
INFO - 2016-05-07 17:34:48 --> Loader Class Initialized
INFO - 2016-05-07 17:34:48 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:48 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:48 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:48 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:48 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:48 --> Controller Class Initialized
INFO - 2016-05-07 17:34:48 --> Model Class Initialized
INFO - 2016-05-07 17:34:48 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:48 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:48 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 17:34:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:48 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:48 --> Total execution time: 0.1454
INFO - 2016-05-07 17:34:49 --> Config Class Initialized
INFO - 2016-05-07 17:34:49 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:49 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:49 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:49 --> URI Class Initialized
INFO - 2016-05-07 17:34:49 --> Router Class Initialized
INFO - 2016-05-07 17:34:49 --> Output Class Initialized
INFO - 2016-05-07 17:34:49 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:49 --> Input Class Initialized
INFO - 2016-05-07 17:34:49 --> Language Class Initialized
INFO - 2016-05-07 17:34:49 --> Loader Class Initialized
INFO - 2016-05-07 17:34:49 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:49 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:49 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:49 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:49 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:49 --> Controller Class Initialized
INFO - 2016-05-07 17:34:49 --> Model Class Initialized
INFO - 2016-05-07 17:34:49 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:49 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:34:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:49 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:49 --> Total execution time: 0.0965
INFO - 2016-05-07 17:34:50 --> Config Class Initialized
INFO - 2016-05-07 17:34:50 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:50 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:50 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:50 --> URI Class Initialized
INFO - 2016-05-07 17:34:50 --> Router Class Initialized
INFO - 2016-05-07 17:34:50 --> Output Class Initialized
INFO - 2016-05-07 17:34:50 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:50 --> Input Class Initialized
INFO - 2016-05-07 17:34:50 --> Language Class Initialized
INFO - 2016-05-07 17:34:50 --> Loader Class Initialized
INFO - 2016-05-07 17:34:50 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:50 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:50 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:50 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:50 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:50 --> Controller Class Initialized
INFO - 2016-05-07 17:34:50 --> Model Class Initialized
INFO - 2016-05-07 17:34:50 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:50 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:50 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:34:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:50 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:50 --> Total execution time: 0.1089
INFO - 2016-05-07 17:34:52 --> Config Class Initialized
INFO - 2016-05-07 17:34:52 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:52 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:52 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:52 --> URI Class Initialized
INFO - 2016-05-07 17:34:52 --> Router Class Initialized
INFO - 2016-05-07 17:34:52 --> Output Class Initialized
INFO - 2016-05-07 17:34:52 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:52 --> Input Class Initialized
INFO - 2016-05-07 17:34:52 --> Language Class Initialized
INFO - 2016-05-07 17:34:52 --> Loader Class Initialized
INFO - 2016-05-07 17:34:52 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:52 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:52 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:52 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:52 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:52 --> Controller Class Initialized
INFO - 2016-05-07 17:34:52 --> Model Class Initialized
INFO - 2016-05-07 17:34:52 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:52 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 17:34:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:52 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:52 --> Total execution time: 0.1192
INFO - 2016-05-07 17:34:53 --> Config Class Initialized
INFO - 2016-05-07 17:34:53 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:53 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:53 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:53 --> URI Class Initialized
INFO - 2016-05-07 17:34:53 --> Router Class Initialized
INFO - 2016-05-07 17:34:53 --> Output Class Initialized
INFO - 2016-05-07 17:34:53 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:53 --> Input Class Initialized
INFO - 2016-05-07 17:34:53 --> Language Class Initialized
INFO - 2016-05-07 17:34:53 --> Loader Class Initialized
INFO - 2016-05-07 17:34:53 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:53 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:53 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:53 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:53 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:53 --> Controller Class Initialized
INFO - 2016-05-07 17:34:53 --> Model Class Initialized
INFO - 2016-05-07 17:34:53 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:53 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:34:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:53 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:53 --> Total execution time: 0.1181
INFO - 2016-05-07 17:34:54 --> Config Class Initialized
INFO - 2016-05-07 17:34:54 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:54 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:54 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:54 --> URI Class Initialized
INFO - 2016-05-07 17:34:54 --> Router Class Initialized
INFO - 2016-05-07 17:34:54 --> Output Class Initialized
INFO - 2016-05-07 17:34:54 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:54 --> Input Class Initialized
INFO - 2016-05-07 17:34:54 --> Language Class Initialized
INFO - 2016-05-07 17:34:54 --> Loader Class Initialized
INFO - 2016-05-07 17:34:54 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:54 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:54 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:54 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:54 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:54 --> Controller Class Initialized
INFO - 2016-05-07 17:34:54 --> Model Class Initialized
INFO - 2016-05-07 17:34:54 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:54 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 17:34:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:54 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:54 --> Total execution time: 0.1206
INFO - 2016-05-07 17:34:58 --> Config Class Initialized
INFO - 2016-05-07 17:34:58 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:34:58 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:34:58 --> Utf8 Class Initialized
INFO - 2016-05-07 17:34:58 --> URI Class Initialized
INFO - 2016-05-07 17:34:58 --> Router Class Initialized
INFO - 2016-05-07 17:34:58 --> Output Class Initialized
INFO - 2016-05-07 17:34:58 --> Security Class Initialized
DEBUG - 2016-05-07 17:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:34:58 --> Input Class Initialized
INFO - 2016-05-07 17:34:58 --> Language Class Initialized
INFO - 2016-05-07 17:34:58 --> Loader Class Initialized
INFO - 2016-05-07 17:34:58 --> Helper loaded: url_helper
INFO - 2016-05-07 17:34:58 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:34:58 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:34:58 --> Helper loaded: form_helper
INFO - 2016-05-07 17:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:34:58 --> Form Validation Class Initialized
INFO - 2016-05-07 17:34:58 --> Controller Class Initialized
INFO - 2016-05-07 17:34:58 --> Model Class Initialized
INFO - 2016-05-07 17:34:58 --> Database Driver Class Initialized
INFO - 2016-05-07 17:34:58 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:34:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:34:58 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:34:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:34:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 17:34:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:34:58 --> Final output sent to browser
DEBUG - 2016-05-07 17:34:58 --> Total execution time: 0.1109
INFO - 2016-05-07 17:35:01 --> Config Class Initialized
INFO - 2016-05-07 17:35:01 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:35:01 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:35:01 --> Utf8 Class Initialized
INFO - 2016-05-07 17:35:01 --> URI Class Initialized
INFO - 2016-05-07 17:35:01 --> Router Class Initialized
INFO - 2016-05-07 17:35:01 --> Output Class Initialized
INFO - 2016-05-07 17:35:01 --> Security Class Initialized
DEBUG - 2016-05-07 17:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:35:01 --> Input Class Initialized
INFO - 2016-05-07 17:35:01 --> Language Class Initialized
INFO - 2016-05-07 17:35:01 --> Loader Class Initialized
INFO - 2016-05-07 17:35:01 --> Helper loaded: url_helper
INFO - 2016-05-07 17:35:01 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:35:01 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:35:01 --> Helper loaded: form_helper
INFO - 2016-05-07 17:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:35:01 --> Form Validation Class Initialized
INFO - 2016-05-07 17:35:01 --> Controller Class Initialized
INFO - 2016-05-07 17:35:01 --> Model Class Initialized
INFO - 2016-05-07 17:35:01 --> Database Driver Class Initialized
INFO - 2016-05-07 17:35:01 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:35:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:35:01 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:35:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:35:01 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 17:35:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:35:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:35:01 --> Final output sent to browser
DEBUG - 2016-05-07 17:35:01 --> Total execution time: 0.1224
INFO - 2016-05-07 17:35:08 --> Config Class Initialized
INFO - 2016-05-07 17:35:08 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:35:08 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:35:08 --> Utf8 Class Initialized
INFO - 2016-05-07 17:35:08 --> URI Class Initialized
INFO - 2016-05-07 17:35:08 --> Router Class Initialized
INFO - 2016-05-07 17:35:08 --> Output Class Initialized
INFO - 2016-05-07 17:35:08 --> Security Class Initialized
DEBUG - 2016-05-07 17:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:35:08 --> Input Class Initialized
INFO - 2016-05-07 17:35:08 --> Language Class Initialized
INFO - 2016-05-07 17:35:08 --> Loader Class Initialized
INFO - 2016-05-07 17:35:08 --> Helper loaded: url_helper
INFO - 2016-05-07 17:35:08 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:35:08 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:35:08 --> Helper loaded: form_helper
INFO - 2016-05-07 17:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:35:08 --> Form Validation Class Initialized
INFO - 2016-05-07 17:35:08 --> Controller Class Initialized
INFO - 2016-05-07 17:35:08 --> Model Class Initialized
INFO - 2016-05-07 17:35:08 --> Database Driver Class Initialized
INFO - 2016-05-07 17:35:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:35:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:35:08 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:35:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:35:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 17:35:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:35:08 --> Final output sent to browser
DEBUG - 2016-05-07 17:35:08 --> Total execution time: 0.1576
INFO - 2016-05-07 17:35:15 --> Config Class Initialized
INFO - 2016-05-07 17:35:15 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:35:15 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:35:15 --> Utf8 Class Initialized
INFO - 2016-05-07 17:35:15 --> URI Class Initialized
INFO - 2016-05-07 17:35:15 --> Router Class Initialized
INFO - 2016-05-07 17:35:15 --> Output Class Initialized
INFO - 2016-05-07 17:35:15 --> Security Class Initialized
DEBUG - 2016-05-07 17:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:35:15 --> Input Class Initialized
INFO - 2016-05-07 17:35:15 --> Language Class Initialized
INFO - 2016-05-07 17:35:15 --> Loader Class Initialized
INFO - 2016-05-07 17:35:15 --> Helper loaded: url_helper
INFO - 2016-05-07 17:35:15 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:35:15 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:35:15 --> Helper loaded: form_helper
INFO - 2016-05-07 17:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:35:15 --> Form Validation Class Initialized
INFO - 2016-05-07 17:35:15 --> Controller Class Initialized
INFO - 2016-05-07 17:35:15 --> Model Class Initialized
INFO - 2016-05-07 17:35:15 --> Database Driver Class Initialized
INFO - 2016-05-07 17:35:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:35:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:35:15 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:35:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:35:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:35:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:35:15 --> Final output sent to browser
DEBUG - 2016-05-07 17:35:15 --> Total execution time: 0.1013
INFO - 2016-05-07 17:35:17 --> Config Class Initialized
INFO - 2016-05-07 17:35:17 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:35:17 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:35:17 --> Utf8 Class Initialized
INFO - 2016-05-07 17:35:17 --> URI Class Initialized
INFO - 2016-05-07 17:35:17 --> Router Class Initialized
INFO - 2016-05-07 17:35:17 --> Output Class Initialized
INFO - 2016-05-07 17:35:17 --> Security Class Initialized
DEBUG - 2016-05-07 17:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:35:17 --> Input Class Initialized
INFO - 2016-05-07 17:35:17 --> Language Class Initialized
INFO - 2016-05-07 17:35:17 --> Loader Class Initialized
INFO - 2016-05-07 17:35:17 --> Helper loaded: url_helper
INFO - 2016-05-07 17:35:17 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:35:17 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:35:17 --> Helper loaded: form_helper
INFO - 2016-05-07 17:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:35:17 --> Form Validation Class Initialized
INFO - 2016-05-07 17:35:17 --> Controller Class Initialized
INFO - 2016-05-07 17:35:17 --> Model Class Initialized
INFO - 2016-05-07 17:35:17 --> Database Driver Class Initialized
INFO - 2016-05-07 17:35:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:35:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:35:17 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:35:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:35:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:35:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:35:18 --> Final output sent to browser
DEBUG - 2016-05-07 17:35:18 --> Total execution time: 0.1084
INFO - 2016-05-07 17:35:18 --> Config Class Initialized
INFO - 2016-05-07 17:35:18 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:35:18 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:35:18 --> Utf8 Class Initialized
INFO - 2016-05-07 17:35:18 --> URI Class Initialized
INFO - 2016-05-07 17:35:18 --> Router Class Initialized
INFO - 2016-05-07 17:35:18 --> Output Class Initialized
INFO - 2016-05-07 17:35:19 --> Security Class Initialized
DEBUG - 2016-05-07 17:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:35:19 --> Input Class Initialized
INFO - 2016-05-07 17:35:19 --> Language Class Initialized
INFO - 2016-05-07 17:35:19 --> Loader Class Initialized
INFO - 2016-05-07 17:35:19 --> Helper loaded: url_helper
INFO - 2016-05-07 17:35:19 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:35:19 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:35:19 --> Helper loaded: form_helper
INFO - 2016-05-07 17:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:35:19 --> Form Validation Class Initialized
INFO - 2016-05-07 17:35:19 --> Controller Class Initialized
INFO - 2016-05-07 17:35:19 --> Model Class Initialized
INFO - 2016-05-07 17:35:19 --> Database Driver Class Initialized
INFO - 2016-05-07 17:35:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:35:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:35:19 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:35:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:35:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 17:35:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:35:19 --> Final output sent to browser
DEBUG - 2016-05-07 17:35:19 --> Total execution time: 0.0937
INFO - 2016-05-07 17:35:20 --> Config Class Initialized
INFO - 2016-05-07 17:35:20 --> Hooks Class Initialized
DEBUG - 2016-05-07 17:35:20 --> UTF-8 Support Enabled
INFO - 2016-05-07 17:35:20 --> Utf8 Class Initialized
INFO - 2016-05-07 17:35:20 --> URI Class Initialized
INFO - 2016-05-07 17:35:20 --> Router Class Initialized
INFO - 2016-05-07 17:35:20 --> Output Class Initialized
INFO - 2016-05-07 17:35:20 --> Security Class Initialized
DEBUG - 2016-05-07 17:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 17:35:20 --> Input Class Initialized
INFO - 2016-05-07 17:35:20 --> Language Class Initialized
INFO - 2016-05-07 17:35:20 --> Loader Class Initialized
INFO - 2016-05-07 17:35:20 --> Helper loaded: url_helper
INFO - 2016-05-07 17:35:20 --> Helper loaded: sesion_helper
INFO - 2016-05-07 17:35:20 --> Helper loaded: templates_helper
INFO - 2016-05-07 17:35:20 --> Helper loaded: form_helper
INFO - 2016-05-07 17:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 17:35:20 --> Form Validation Class Initialized
INFO - 2016-05-07 17:35:20 --> Controller Class Initialized
INFO - 2016-05-07 17:35:20 --> Model Class Initialized
INFO - 2016-05-07 17:35:20 --> Database Driver Class Initialized
INFO - 2016-05-07 17:35:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 17:35:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 17:35:20 --> Pagination Class Initialized
DEBUG - 2016-05-07 17:35:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 17:35:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 17:35:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 17:35:20 --> Final output sent to browser
DEBUG - 2016-05-07 17:35:20 --> Total execution time: 0.1368
INFO - 2016-05-07 21:26:05 --> Config Class Initialized
INFO - 2016-05-07 21:26:05 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:26:06 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:26:06 --> Utf8 Class Initialized
INFO - 2016-05-07 21:26:06 --> URI Class Initialized
INFO - 2016-05-07 21:26:06 --> Router Class Initialized
INFO - 2016-05-07 21:26:06 --> Output Class Initialized
INFO - 2016-05-07 21:26:06 --> Security Class Initialized
DEBUG - 2016-05-07 21:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:26:06 --> Input Class Initialized
INFO - 2016-05-07 21:26:06 --> Language Class Initialized
INFO - 2016-05-07 21:26:06 --> Loader Class Initialized
INFO - 2016-05-07 21:26:06 --> Helper loaded: url_helper
INFO - 2016-05-07 21:26:06 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:26:06 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:26:06 --> Helper loaded: form_helper
INFO - 2016-05-07 21:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:26:06 --> Form Validation Class Initialized
INFO - 2016-05-07 21:26:06 --> Controller Class Initialized
INFO - 2016-05-07 21:26:06 --> Config Class Initialized
INFO - 2016-05-07 21:26:06 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:26:06 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:26:06 --> Utf8 Class Initialized
INFO - 2016-05-07 21:26:06 --> URI Class Initialized
INFO - 2016-05-07 21:26:06 --> Router Class Initialized
INFO - 2016-05-07 21:26:06 --> Output Class Initialized
INFO - 2016-05-07 21:26:06 --> Security Class Initialized
DEBUG - 2016-05-07 21:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:26:06 --> Input Class Initialized
INFO - 2016-05-07 21:26:06 --> Language Class Initialized
INFO - 2016-05-07 21:26:06 --> Loader Class Initialized
INFO - 2016-05-07 21:26:06 --> Helper loaded: url_helper
INFO - 2016-05-07 21:26:06 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:26:06 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:26:06 --> Helper loaded: form_helper
INFO - 2016-05-07 21:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:26:06 --> Form Validation Class Initialized
INFO - 2016-05-07 21:26:06 --> Controller Class Initialized
INFO - 2016-05-07 21:26:06 --> Model Class Initialized
INFO - 2016-05-07 21:26:06 --> Database Driver Class Initialized
INFO - 2016-05-07 21:26:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-07 21:26:06 --> Final output sent to browser
DEBUG - 2016-05-07 21:26:06 --> Total execution time: 0.1295
INFO - 2016-05-07 21:27:30 --> Config Class Initialized
INFO - 2016-05-07 21:27:30 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:27:30 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:27:30 --> Utf8 Class Initialized
INFO - 2016-05-07 21:27:30 --> URI Class Initialized
INFO - 2016-05-07 21:27:30 --> Router Class Initialized
INFO - 2016-05-07 21:27:30 --> Output Class Initialized
INFO - 2016-05-07 21:27:30 --> Security Class Initialized
DEBUG - 2016-05-07 21:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:27:30 --> Input Class Initialized
INFO - 2016-05-07 21:27:30 --> Language Class Initialized
INFO - 2016-05-07 21:27:30 --> Loader Class Initialized
INFO - 2016-05-07 21:27:30 --> Helper loaded: url_helper
INFO - 2016-05-07 21:27:30 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:27:30 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:27:30 --> Helper loaded: form_helper
INFO - 2016-05-07 21:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:27:30 --> Form Validation Class Initialized
INFO - 2016-05-07 21:27:30 --> Controller Class Initialized
INFO - 2016-05-07 21:27:30 --> Config Class Initialized
INFO - 2016-05-07 21:27:30 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:27:30 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:27:30 --> Utf8 Class Initialized
INFO - 2016-05-07 21:27:30 --> URI Class Initialized
INFO - 2016-05-07 21:27:30 --> Router Class Initialized
INFO - 2016-05-07 21:27:30 --> Output Class Initialized
INFO - 2016-05-07 21:27:30 --> Security Class Initialized
DEBUG - 2016-05-07 21:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:27:30 --> Input Class Initialized
INFO - 2016-05-07 21:27:30 --> Language Class Initialized
INFO - 2016-05-07 21:27:30 --> Loader Class Initialized
INFO - 2016-05-07 21:27:30 --> Helper loaded: url_helper
INFO - 2016-05-07 21:27:30 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:27:30 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:27:30 --> Helper loaded: form_helper
INFO - 2016-05-07 21:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:27:30 --> Form Validation Class Initialized
INFO - 2016-05-07 21:27:30 --> Controller Class Initialized
INFO - 2016-05-07 21:27:30 --> Model Class Initialized
INFO - 2016-05-07 21:27:30 --> Database Driver Class Initialized
INFO - 2016-05-07 21:27:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-07 21:27:30 --> Final output sent to browser
DEBUG - 2016-05-07 21:27:30 --> Total execution time: 0.0629
INFO - 2016-05-07 21:27:37 --> Config Class Initialized
INFO - 2016-05-07 21:27:37 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:27:37 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:27:37 --> Utf8 Class Initialized
INFO - 2016-05-07 21:27:37 --> URI Class Initialized
INFO - 2016-05-07 21:27:37 --> Router Class Initialized
INFO - 2016-05-07 21:27:37 --> Output Class Initialized
INFO - 2016-05-07 21:27:37 --> Security Class Initialized
DEBUG - 2016-05-07 21:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:27:37 --> Input Class Initialized
INFO - 2016-05-07 21:27:37 --> Language Class Initialized
INFO - 2016-05-07 21:27:37 --> Loader Class Initialized
INFO - 2016-05-07 21:27:37 --> Helper loaded: url_helper
INFO - 2016-05-07 21:27:37 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:27:37 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:27:37 --> Helper loaded: form_helper
INFO - 2016-05-07 21:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:27:37 --> Form Validation Class Initialized
INFO - 2016-05-07 21:27:37 --> Controller Class Initialized
INFO - 2016-05-07 21:27:37 --> Model Class Initialized
INFO - 2016-05-07 21:27:37 --> Database Driver Class Initialized
INFO - 2016-05-07 21:27:37 --> Config Class Initialized
INFO - 2016-05-07 21:27:37 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:27:37 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:27:37 --> Utf8 Class Initialized
INFO - 2016-05-07 21:27:37 --> URI Class Initialized
INFO - 2016-05-07 21:27:37 --> Router Class Initialized
INFO - 2016-05-07 21:27:37 --> Output Class Initialized
INFO - 2016-05-07 21:27:37 --> Security Class Initialized
DEBUG - 2016-05-07 21:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:27:37 --> Input Class Initialized
INFO - 2016-05-07 21:27:37 --> Language Class Initialized
INFO - 2016-05-07 21:27:37 --> Loader Class Initialized
INFO - 2016-05-07 21:27:37 --> Helper loaded: url_helper
INFO - 2016-05-07 21:27:37 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:27:37 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:27:37 --> Helper loaded: form_helper
INFO - 2016-05-07 21:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:27:37 --> Form Validation Class Initialized
INFO - 2016-05-07 21:27:37 --> Controller Class Initialized
INFO - 2016-05-07 21:27:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-07 21:27:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 21:27:37 --> Final output sent to browser
DEBUG - 2016-05-07 21:27:37 --> Total execution time: 0.0478
INFO - 2016-05-07 21:27:44 --> Config Class Initialized
INFO - 2016-05-07 21:27:44 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:27:44 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:27:44 --> Utf8 Class Initialized
INFO - 2016-05-07 21:27:44 --> URI Class Initialized
INFO - 2016-05-07 21:27:44 --> Router Class Initialized
INFO - 2016-05-07 21:27:44 --> Output Class Initialized
INFO - 2016-05-07 21:27:44 --> Security Class Initialized
DEBUG - 2016-05-07 21:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:27:44 --> Input Class Initialized
INFO - 2016-05-07 21:27:44 --> Language Class Initialized
INFO - 2016-05-07 21:27:44 --> Loader Class Initialized
INFO - 2016-05-07 21:27:44 --> Helper loaded: url_helper
INFO - 2016-05-07 21:27:44 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:27:44 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:27:44 --> Helper loaded: form_helper
INFO - 2016-05-07 21:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:27:44 --> Form Validation Class Initialized
INFO - 2016-05-07 21:27:44 --> Controller Class Initialized
INFO - 2016-05-07 21:27:44 --> Model Class Initialized
INFO - 2016-05-07 21:27:44 --> Database Driver Class Initialized
INFO - 2016-05-07 21:27:44 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:27:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:27:44 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:27:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:27:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 21:27:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 21:27:44 --> Final output sent to browser
DEBUG - 2016-05-07 21:27:44 --> Total execution time: 0.1644
INFO - 2016-05-07 21:27:47 --> Config Class Initialized
INFO - 2016-05-07 21:27:47 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:27:47 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:27:47 --> Utf8 Class Initialized
INFO - 2016-05-07 21:27:47 --> URI Class Initialized
INFO - 2016-05-07 21:27:47 --> Router Class Initialized
INFO - 2016-05-07 21:27:47 --> Output Class Initialized
INFO - 2016-05-07 21:27:47 --> Security Class Initialized
DEBUG - 2016-05-07 21:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:27:47 --> Input Class Initialized
INFO - 2016-05-07 21:27:47 --> Language Class Initialized
INFO - 2016-05-07 21:27:47 --> Loader Class Initialized
INFO - 2016-05-07 21:27:47 --> Helper loaded: url_helper
INFO - 2016-05-07 21:27:47 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:27:47 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:27:47 --> Helper loaded: form_helper
INFO - 2016-05-07 21:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:27:47 --> Form Validation Class Initialized
INFO - 2016-05-07 21:27:47 --> Controller Class Initialized
INFO - 2016-05-07 21:27:47 --> Model Class Initialized
INFO - 2016-05-07 21:27:47 --> Database Driver Class Initialized
INFO - 2016-05-07 21:27:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:27:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:27:47 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:27:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:27:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 21:27:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 21:27:47 --> Final output sent to browser
DEBUG - 2016-05-07 21:27:47 --> Total execution time: 0.1763
INFO - 2016-05-07 21:27:52 --> Config Class Initialized
INFO - 2016-05-07 21:27:52 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:27:52 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:27:52 --> Utf8 Class Initialized
INFO - 2016-05-07 21:27:52 --> URI Class Initialized
INFO - 2016-05-07 21:27:52 --> Router Class Initialized
INFO - 2016-05-07 21:27:52 --> Output Class Initialized
INFO - 2016-05-07 21:27:52 --> Security Class Initialized
DEBUG - 2016-05-07 21:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:27:52 --> Input Class Initialized
INFO - 2016-05-07 21:27:52 --> Language Class Initialized
INFO - 2016-05-07 21:27:52 --> Loader Class Initialized
INFO - 2016-05-07 21:27:52 --> Helper loaded: url_helper
INFO - 2016-05-07 21:27:52 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:27:52 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:27:52 --> Helper loaded: form_helper
INFO - 2016-05-07 21:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:27:52 --> Form Validation Class Initialized
INFO - 2016-05-07 21:27:52 --> Controller Class Initialized
INFO - 2016-05-07 21:27:52 --> Model Class Initialized
INFO - 2016-05-07 21:27:52 --> Database Driver Class Initialized
INFO - 2016-05-07 21:27:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:27:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:27:52 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:27:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:27:52 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 21:27:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:27:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 21:27:52 --> Final output sent to browser
DEBUG - 2016-05-07 21:27:52 --> Total execution time: 0.1421
INFO - 2016-05-07 21:28:35 --> Config Class Initialized
INFO - 2016-05-07 21:28:35 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:28:35 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:28:35 --> Utf8 Class Initialized
INFO - 2016-05-07 21:28:35 --> URI Class Initialized
INFO - 2016-05-07 21:28:35 --> Router Class Initialized
INFO - 2016-05-07 21:28:35 --> Output Class Initialized
INFO - 2016-05-07 21:28:35 --> Security Class Initialized
DEBUG - 2016-05-07 21:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:28:35 --> Input Class Initialized
INFO - 2016-05-07 21:28:35 --> Language Class Initialized
INFO - 2016-05-07 21:28:35 --> Loader Class Initialized
INFO - 2016-05-07 21:28:35 --> Helper loaded: url_helper
INFO - 2016-05-07 21:28:35 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:28:35 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:28:35 --> Helper loaded: form_helper
INFO - 2016-05-07 21:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:28:35 --> Form Validation Class Initialized
INFO - 2016-05-07 21:28:35 --> Controller Class Initialized
INFO - 2016-05-07 21:28:35 --> Model Class Initialized
INFO - 2016-05-07 21:28:35 --> Database Driver Class Initialized
INFO - 2016-05-07 21:28:35 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:28:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:28:35 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:28:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:28:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:28:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 21:28:35 --> Final output sent to browser
DEBUG - 2016-05-07 21:28:35 --> Total execution time: 0.1241
INFO - 2016-05-07 21:28:50 --> Config Class Initialized
INFO - 2016-05-07 21:28:50 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:28:50 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:28:50 --> Utf8 Class Initialized
INFO - 2016-05-07 21:28:50 --> URI Class Initialized
INFO - 2016-05-07 21:28:50 --> Router Class Initialized
INFO - 2016-05-07 21:28:50 --> Output Class Initialized
INFO - 2016-05-07 21:28:50 --> Security Class Initialized
DEBUG - 2016-05-07 21:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:28:50 --> Input Class Initialized
INFO - 2016-05-07 21:28:50 --> Language Class Initialized
INFO - 2016-05-07 21:28:50 --> Loader Class Initialized
INFO - 2016-05-07 21:28:50 --> Helper loaded: url_helper
INFO - 2016-05-07 21:28:50 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:28:50 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:28:50 --> Helper loaded: form_helper
INFO - 2016-05-07 21:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:28:50 --> Form Validation Class Initialized
INFO - 2016-05-07 21:28:50 --> Controller Class Initialized
INFO - 2016-05-07 21:28:50 --> Model Class Initialized
INFO - 2016-05-07 21:28:50 --> Database Driver Class Initialized
INFO - 2016-05-07 21:28:50 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:28:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:28:50 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:28:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:28:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 21:28:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 21:28:50 --> Final output sent to browser
DEBUG - 2016-05-07 21:28:50 --> Total execution time: 0.0766
INFO - 2016-05-07 21:28:54 --> Config Class Initialized
INFO - 2016-05-07 21:28:54 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:28:54 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:28:54 --> Utf8 Class Initialized
INFO - 2016-05-07 21:28:54 --> URI Class Initialized
INFO - 2016-05-07 21:28:54 --> Router Class Initialized
INFO - 2016-05-07 21:28:54 --> Output Class Initialized
INFO - 2016-05-07 21:28:54 --> Security Class Initialized
DEBUG - 2016-05-07 21:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:28:54 --> Input Class Initialized
INFO - 2016-05-07 21:28:54 --> Language Class Initialized
INFO - 2016-05-07 21:28:54 --> Loader Class Initialized
INFO - 2016-05-07 21:28:54 --> Helper loaded: url_helper
INFO - 2016-05-07 21:28:54 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:28:54 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:28:54 --> Helper loaded: form_helper
INFO - 2016-05-07 21:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:28:54 --> Form Validation Class Initialized
INFO - 2016-05-07 21:28:54 --> Controller Class Initialized
INFO - 2016-05-07 21:28:54 --> Model Class Initialized
INFO - 2016-05-07 21:28:54 --> Database Driver Class Initialized
INFO - 2016-05-07 21:28:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:28:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:28:54 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:28:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:28:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 21:28:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 21:28:54 --> Final output sent to browser
DEBUG - 2016-05-07 21:28:54 --> Total execution time: 0.0757
INFO - 2016-05-07 21:28:59 --> Config Class Initialized
INFO - 2016-05-07 21:28:59 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:28:59 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:28:59 --> Utf8 Class Initialized
INFO - 2016-05-07 21:28:59 --> URI Class Initialized
INFO - 2016-05-07 21:28:59 --> Router Class Initialized
INFO - 2016-05-07 21:28:59 --> Output Class Initialized
INFO - 2016-05-07 21:28:59 --> Security Class Initialized
DEBUG - 2016-05-07 21:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:28:59 --> Input Class Initialized
INFO - 2016-05-07 21:28:59 --> Language Class Initialized
INFO - 2016-05-07 21:28:59 --> Loader Class Initialized
INFO - 2016-05-07 21:28:59 --> Helper loaded: url_helper
INFO - 2016-05-07 21:28:59 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:28:59 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:28:59 --> Helper loaded: form_helper
INFO - 2016-05-07 21:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:28:59 --> Form Validation Class Initialized
INFO - 2016-05-07 21:28:59 --> Controller Class Initialized
INFO - 2016-05-07 21:28:59 --> Model Class Initialized
INFO - 2016-05-07 21:28:59 --> Database Driver Class Initialized
INFO - 2016-05-07 21:28:59 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:28:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:28:59 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:28:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:28:59 --> Config Class Initialized
INFO - 2016-05-07 21:28:59 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:28:59 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:28:59 --> Utf8 Class Initialized
INFO - 2016-05-07 21:28:59 --> URI Class Initialized
INFO - 2016-05-07 21:28:59 --> Router Class Initialized
INFO - 2016-05-07 21:28:59 --> Output Class Initialized
INFO - 2016-05-07 21:28:59 --> Security Class Initialized
DEBUG - 2016-05-07 21:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:28:59 --> Input Class Initialized
INFO - 2016-05-07 21:28:59 --> Language Class Initialized
INFO - 2016-05-07 21:28:59 --> Loader Class Initialized
INFO - 2016-05-07 21:28:59 --> Helper loaded: url_helper
INFO - 2016-05-07 21:28:59 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:28:59 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:28:59 --> Helper loaded: form_helper
INFO - 2016-05-07 21:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:28:59 --> Form Validation Class Initialized
INFO - 2016-05-07 21:28:59 --> Controller Class Initialized
INFO - 2016-05-07 21:28:59 --> Model Class Initialized
INFO - 2016-05-07 21:28:59 --> Database Driver Class Initialized
INFO - 2016-05-07 21:28:59 --> Config Class Initialized
INFO - 2016-05-07 21:28:59 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:28:59 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:28:59 --> Utf8 Class Initialized
INFO - 2016-05-07 21:28:59 --> URI Class Initialized
INFO - 2016-05-07 21:28:59 --> Router Class Initialized
INFO - 2016-05-07 21:28:59 --> Output Class Initialized
INFO - 2016-05-07 21:28:59 --> Security Class Initialized
DEBUG - 2016-05-07 21:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:28:59 --> Input Class Initialized
INFO - 2016-05-07 21:28:59 --> Language Class Initialized
INFO - 2016-05-07 21:28:59 --> Loader Class Initialized
INFO - 2016-05-07 21:28:59 --> Helper loaded: url_helper
INFO - 2016-05-07 21:28:59 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:28:59 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:28:59 --> Helper loaded: form_helper
INFO - 2016-05-07 21:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:28:59 --> Form Validation Class Initialized
INFO - 2016-05-07 21:28:59 --> Controller Class Initialized
INFO - 2016-05-07 21:28:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-07 21:28:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 21:28:59 --> Final output sent to browser
DEBUG - 2016-05-07 21:28:59 --> Total execution time: 0.0485
INFO - 2016-05-07 21:29:00 --> Config Class Initialized
INFO - 2016-05-07 21:29:00 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:29:00 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:29:00 --> Utf8 Class Initialized
INFO - 2016-05-07 21:29:00 --> URI Class Initialized
INFO - 2016-05-07 21:29:00 --> Router Class Initialized
INFO - 2016-05-07 21:29:00 --> Output Class Initialized
INFO - 2016-05-07 21:29:00 --> Security Class Initialized
DEBUG - 2016-05-07 21:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:29:00 --> Input Class Initialized
INFO - 2016-05-07 21:29:00 --> Language Class Initialized
INFO - 2016-05-07 21:29:00 --> Loader Class Initialized
INFO - 2016-05-07 21:29:00 --> Helper loaded: url_helper
INFO - 2016-05-07 21:29:00 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:29:00 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:29:00 --> Helper loaded: form_helper
INFO - 2016-05-07 21:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:29:00 --> Form Validation Class Initialized
INFO - 2016-05-07 21:29:00 --> Controller Class Initialized
INFO - 2016-05-07 21:29:00 --> Model Class Initialized
INFO - 2016-05-07 21:29:00 --> Database Driver Class Initialized
INFO - 2016-05-07 21:29:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:29:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:29:00 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:29:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:29:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 21:29:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 21:29:00 --> Final output sent to browser
DEBUG - 2016-05-07 21:29:00 --> Total execution time: 0.0951
INFO - 2016-05-07 21:29:02 --> Config Class Initialized
INFO - 2016-05-07 21:29:02 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:29:02 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:29:02 --> Utf8 Class Initialized
INFO - 2016-05-07 21:29:02 --> URI Class Initialized
INFO - 2016-05-07 21:29:02 --> Router Class Initialized
INFO - 2016-05-07 21:29:02 --> Output Class Initialized
INFO - 2016-05-07 21:29:02 --> Security Class Initialized
DEBUG - 2016-05-07 21:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:29:02 --> Input Class Initialized
INFO - 2016-05-07 21:29:02 --> Language Class Initialized
INFO - 2016-05-07 21:29:02 --> Loader Class Initialized
INFO - 2016-05-07 21:29:02 --> Helper loaded: url_helper
INFO - 2016-05-07 21:29:02 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:29:02 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:29:02 --> Helper loaded: form_helper
INFO - 2016-05-07 21:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:29:02 --> Form Validation Class Initialized
INFO - 2016-05-07 21:29:02 --> Controller Class Initialized
INFO - 2016-05-07 21:29:02 --> Model Class Initialized
INFO - 2016-05-07 21:29:02 --> Database Driver Class Initialized
INFO - 2016-05-07 21:29:02 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:29:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:29:02 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:29:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:29:02 --> Config Class Initialized
INFO - 2016-05-07 21:29:02 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:29:02 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:29:02 --> Utf8 Class Initialized
INFO - 2016-05-07 21:29:02 --> URI Class Initialized
INFO - 2016-05-07 21:29:02 --> Router Class Initialized
INFO - 2016-05-07 21:29:02 --> Output Class Initialized
INFO - 2016-05-07 21:29:02 --> Security Class Initialized
DEBUG - 2016-05-07 21:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:29:02 --> Input Class Initialized
INFO - 2016-05-07 21:29:02 --> Language Class Initialized
INFO - 2016-05-07 21:29:02 --> Loader Class Initialized
INFO - 2016-05-07 21:29:02 --> Helper loaded: url_helper
INFO - 2016-05-07 21:29:02 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:29:02 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:29:02 --> Helper loaded: form_helper
INFO - 2016-05-07 21:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:29:02 --> Form Validation Class Initialized
INFO - 2016-05-07 21:29:02 --> Controller Class Initialized
INFO - 2016-05-07 21:29:02 --> Model Class Initialized
INFO - 2016-05-07 21:29:02 --> Database Driver Class Initialized
INFO - 2016-05-07 21:29:02 --> Config Class Initialized
INFO - 2016-05-07 21:29:02 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:29:02 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:29:02 --> Utf8 Class Initialized
INFO - 2016-05-07 21:29:02 --> URI Class Initialized
INFO - 2016-05-07 21:29:02 --> Router Class Initialized
INFO - 2016-05-07 21:29:02 --> Output Class Initialized
INFO - 2016-05-07 21:29:02 --> Security Class Initialized
DEBUG - 2016-05-07 21:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:29:02 --> Input Class Initialized
INFO - 2016-05-07 21:29:02 --> Language Class Initialized
INFO - 2016-05-07 21:29:02 --> Loader Class Initialized
INFO - 2016-05-07 21:29:02 --> Helper loaded: url_helper
INFO - 2016-05-07 21:29:02 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:29:02 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:29:02 --> Helper loaded: form_helper
INFO - 2016-05-07 21:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:29:02 --> Form Validation Class Initialized
INFO - 2016-05-07 21:29:02 --> Controller Class Initialized
INFO - 2016-05-07 21:29:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-07 21:29:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 21:29:02 --> Final output sent to browser
DEBUG - 2016-05-07 21:29:02 --> Total execution time: 0.0748
INFO - 2016-05-07 21:29:03 --> Config Class Initialized
INFO - 2016-05-07 21:29:03 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:29:03 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:29:03 --> Utf8 Class Initialized
INFO - 2016-05-07 21:29:03 --> URI Class Initialized
INFO - 2016-05-07 21:29:03 --> Router Class Initialized
INFO - 2016-05-07 21:29:03 --> Output Class Initialized
INFO - 2016-05-07 21:29:03 --> Security Class Initialized
DEBUG - 2016-05-07 21:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:29:03 --> Input Class Initialized
INFO - 2016-05-07 21:29:03 --> Language Class Initialized
INFO - 2016-05-07 21:29:03 --> Loader Class Initialized
INFO - 2016-05-07 21:29:03 --> Helper loaded: url_helper
INFO - 2016-05-07 21:29:03 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:29:03 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:29:03 --> Helper loaded: form_helper
INFO - 2016-05-07 21:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:29:03 --> Form Validation Class Initialized
INFO - 2016-05-07 21:29:03 --> Controller Class Initialized
INFO - 2016-05-07 21:29:03 --> Model Class Initialized
INFO - 2016-05-07 21:29:03 --> Database Driver Class Initialized
INFO - 2016-05-07 21:29:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:29:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:29:03 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:29:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:29:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 21:29:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 21:29:03 --> Final output sent to browser
DEBUG - 2016-05-07 21:29:03 --> Total execution time: 0.0906
INFO - 2016-05-07 21:29:56 --> Config Class Initialized
INFO - 2016-05-07 21:29:56 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:29:56 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:29:56 --> Utf8 Class Initialized
INFO - 2016-05-07 21:29:56 --> URI Class Initialized
INFO - 2016-05-07 21:29:56 --> Router Class Initialized
INFO - 2016-05-07 21:29:56 --> Output Class Initialized
INFO - 2016-05-07 21:29:56 --> Security Class Initialized
DEBUG - 2016-05-07 21:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:29:56 --> Input Class Initialized
INFO - 2016-05-07 21:29:56 --> Language Class Initialized
INFO - 2016-05-07 21:29:56 --> Loader Class Initialized
INFO - 2016-05-07 21:29:56 --> Helper loaded: url_helper
INFO - 2016-05-07 21:29:56 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:29:56 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:29:56 --> Helper loaded: form_helper
INFO - 2016-05-07 21:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:29:56 --> Form Validation Class Initialized
INFO - 2016-05-07 21:29:56 --> Controller Class Initialized
INFO - 2016-05-07 21:29:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-07 21:29:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-07 21:29:56 --> Final output sent to browser
DEBUG - 2016-05-07 21:29:56 --> Total execution time: 0.0970
INFO - 2016-05-07 21:29:58 --> Config Class Initialized
INFO - 2016-05-07 21:29:58 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:29:58 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:29:58 --> Utf8 Class Initialized
INFO - 2016-05-07 21:29:58 --> URI Class Initialized
INFO - 2016-05-07 21:29:58 --> Router Class Initialized
INFO - 2016-05-07 21:29:58 --> Output Class Initialized
INFO - 2016-05-07 21:29:58 --> Security Class Initialized
DEBUG - 2016-05-07 21:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:29:58 --> Input Class Initialized
INFO - 2016-05-07 21:29:58 --> Language Class Initialized
INFO - 2016-05-07 21:29:58 --> Loader Class Initialized
INFO - 2016-05-07 21:29:58 --> Helper loaded: url_helper
INFO - 2016-05-07 21:29:58 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:29:58 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:29:58 --> Helper loaded: form_helper
INFO - 2016-05-07 21:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:29:58 --> Form Validation Class Initialized
INFO - 2016-05-07 21:29:58 --> Controller Class Initialized
INFO - 2016-05-07 21:29:58 --> Config Class Initialized
INFO - 2016-05-07 21:29:58 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:29:58 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:29:58 --> Utf8 Class Initialized
INFO - 2016-05-07 21:29:58 --> URI Class Initialized
INFO - 2016-05-07 21:29:58 --> Router Class Initialized
INFO - 2016-05-07 21:29:58 --> Output Class Initialized
INFO - 2016-05-07 21:29:58 --> Security Class Initialized
DEBUG - 2016-05-07 21:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:29:58 --> Input Class Initialized
INFO - 2016-05-07 21:29:58 --> Language Class Initialized
INFO - 2016-05-07 21:29:58 --> Loader Class Initialized
INFO - 2016-05-07 21:29:58 --> Helper loaded: url_helper
INFO - 2016-05-07 21:29:58 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:29:58 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:29:58 --> Helper loaded: form_helper
INFO - 2016-05-07 21:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:29:58 --> Form Validation Class Initialized
INFO - 2016-05-07 21:29:58 --> Controller Class Initialized
INFO - 2016-05-07 21:29:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-07 21:29:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:29:58 --> Final output sent to browser
DEBUG - 2016-05-07 21:29:58 --> Total execution time: 0.0651
INFO - 2016-05-07 21:30:03 --> Config Class Initialized
INFO - 2016-05-07 21:30:03 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:30:03 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:30:03 --> Utf8 Class Initialized
INFO - 2016-05-07 21:30:03 --> URI Class Initialized
INFO - 2016-05-07 21:30:03 --> Router Class Initialized
INFO - 2016-05-07 21:30:03 --> Output Class Initialized
INFO - 2016-05-07 21:30:03 --> Security Class Initialized
DEBUG - 2016-05-07 21:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:30:03 --> Input Class Initialized
INFO - 2016-05-07 21:30:03 --> Language Class Initialized
INFO - 2016-05-07 21:30:03 --> Loader Class Initialized
INFO - 2016-05-07 21:30:03 --> Helper loaded: url_helper
INFO - 2016-05-07 21:30:03 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:30:03 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:30:03 --> Helper loaded: form_helper
INFO - 2016-05-07 21:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:30:03 --> Form Validation Class Initialized
INFO - 2016-05-07 21:30:03 --> Controller Class Initialized
INFO - 2016-05-07 21:30:03 --> Model Class Initialized
INFO - 2016-05-07 21:30:03 --> Database Driver Class Initialized
INFO - 2016-05-07 21:30:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:30:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:30:03 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:30:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:30:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 21:30:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:30:03 --> Final output sent to browser
DEBUG - 2016-05-07 21:30:03 --> Total execution time: 0.1003
INFO - 2016-05-07 21:30:04 --> Config Class Initialized
INFO - 2016-05-07 21:30:04 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:30:04 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:30:04 --> Utf8 Class Initialized
INFO - 2016-05-07 21:30:04 --> URI Class Initialized
INFO - 2016-05-07 21:30:04 --> Router Class Initialized
INFO - 2016-05-07 21:30:04 --> Output Class Initialized
INFO - 2016-05-07 21:30:04 --> Security Class Initialized
DEBUG - 2016-05-07 21:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:30:04 --> Input Class Initialized
INFO - 2016-05-07 21:30:04 --> Language Class Initialized
INFO - 2016-05-07 21:30:04 --> Loader Class Initialized
INFO - 2016-05-07 21:30:04 --> Helper loaded: url_helper
INFO - 2016-05-07 21:30:04 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:30:04 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:30:04 --> Helper loaded: form_helper
INFO - 2016-05-07 21:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:30:04 --> Form Validation Class Initialized
INFO - 2016-05-07 21:30:04 --> Controller Class Initialized
INFO - 2016-05-07 21:30:04 --> Model Class Initialized
INFO - 2016-05-07 21:30:04 --> Database Driver Class Initialized
INFO - 2016-05-07 21:30:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:30:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:30:04 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:30:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:30:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 21:30:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:30:04 --> Final output sent to browser
DEBUG - 2016-05-07 21:30:04 --> Total execution time: 0.1411
INFO - 2016-05-07 21:30:08 --> Config Class Initialized
INFO - 2016-05-07 21:30:08 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:30:08 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:30:08 --> Utf8 Class Initialized
INFO - 2016-05-07 21:30:08 --> URI Class Initialized
INFO - 2016-05-07 21:30:08 --> Router Class Initialized
INFO - 2016-05-07 21:30:08 --> Output Class Initialized
INFO - 2016-05-07 21:30:08 --> Security Class Initialized
DEBUG - 2016-05-07 21:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:30:08 --> Input Class Initialized
INFO - 2016-05-07 21:30:08 --> Language Class Initialized
INFO - 2016-05-07 21:30:08 --> Loader Class Initialized
INFO - 2016-05-07 21:30:08 --> Helper loaded: url_helper
INFO - 2016-05-07 21:30:08 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:30:08 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:30:08 --> Helper loaded: form_helper
INFO - 2016-05-07 21:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:30:08 --> Form Validation Class Initialized
INFO - 2016-05-07 21:30:08 --> Controller Class Initialized
INFO - 2016-05-07 21:30:08 --> Model Class Initialized
INFO - 2016-05-07 21:30:08 --> Database Driver Class Initialized
INFO - 2016-05-07 21:30:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:30:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:30:08 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:30:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:30:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 21:30:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:30:08 --> Final output sent to browser
DEBUG - 2016-05-07 21:30:08 --> Total execution time: 0.0768
INFO - 2016-05-07 21:30:10 --> Config Class Initialized
INFO - 2016-05-07 21:30:10 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:30:10 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:30:10 --> Utf8 Class Initialized
INFO - 2016-05-07 21:30:10 --> URI Class Initialized
INFO - 2016-05-07 21:30:10 --> Router Class Initialized
INFO - 2016-05-07 21:30:10 --> Output Class Initialized
INFO - 2016-05-07 21:30:10 --> Security Class Initialized
DEBUG - 2016-05-07 21:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:30:10 --> Input Class Initialized
INFO - 2016-05-07 21:30:10 --> Language Class Initialized
INFO - 2016-05-07 21:30:10 --> Loader Class Initialized
INFO - 2016-05-07 21:30:10 --> Helper loaded: url_helper
INFO - 2016-05-07 21:30:10 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:30:10 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:30:10 --> Helper loaded: form_helper
INFO - 2016-05-07 21:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:30:10 --> Form Validation Class Initialized
INFO - 2016-05-07 21:30:10 --> Controller Class Initialized
INFO - 2016-05-07 21:30:10 --> Model Class Initialized
INFO - 2016-05-07 21:30:10 --> Database Driver Class Initialized
INFO - 2016-05-07 21:30:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:30:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:30:10 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:30:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:30:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 21:30:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:30:10 --> Final output sent to browser
DEBUG - 2016-05-07 21:30:10 --> Total execution time: 0.1380
INFO - 2016-05-07 21:30:15 --> Config Class Initialized
INFO - 2016-05-07 21:30:15 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:30:15 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:30:15 --> Utf8 Class Initialized
INFO - 2016-05-07 21:30:15 --> URI Class Initialized
INFO - 2016-05-07 21:30:15 --> Router Class Initialized
INFO - 2016-05-07 21:30:15 --> Output Class Initialized
INFO - 2016-05-07 21:30:15 --> Security Class Initialized
DEBUG - 2016-05-07 21:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:30:15 --> Input Class Initialized
INFO - 2016-05-07 21:30:15 --> Language Class Initialized
INFO - 2016-05-07 21:30:15 --> Loader Class Initialized
INFO - 2016-05-07 21:30:15 --> Helper loaded: url_helper
INFO - 2016-05-07 21:30:15 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:30:15 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:30:15 --> Helper loaded: form_helper
INFO - 2016-05-07 21:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:30:15 --> Form Validation Class Initialized
INFO - 2016-05-07 21:30:15 --> Controller Class Initialized
INFO - 2016-05-07 21:30:15 --> Model Class Initialized
INFO - 2016-05-07 21:30:15 --> Database Driver Class Initialized
INFO - 2016-05-07 21:30:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:30:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:30:15 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:30:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:30:15 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 21:30:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:30:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:30:15 --> Final output sent to browser
DEBUG - 2016-05-07 21:30:15 --> Total execution time: 0.1286
INFO - 2016-05-07 21:30:29 --> Config Class Initialized
INFO - 2016-05-07 21:30:29 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:30:29 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:30:29 --> Utf8 Class Initialized
INFO - 2016-05-07 21:30:29 --> URI Class Initialized
INFO - 2016-05-07 21:30:29 --> Router Class Initialized
INFO - 2016-05-07 21:30:29 --> Output Class Initialized
INFO - 2016-05-07 21:30:29 --> Security Class Initialized
DEBUG - 2016-05-07 21:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:30:29 --> Input Class Initialized
INFO - 2016-05-07 21:30:29 --> Language Class Initialized
INFO - 2016-05-07 21:30:29 --> Loader Class Initialized
INFO - 2016-05-07 21:30:29 --> Helper loaded: url_helper
INFO - 2016-05-07 21:30:29 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:30:29 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:30:29 --> Helper loaded: form_helper
INFO - 2016-05-07 21:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:30:29 --> Form Validation Class Initialized
INFO - 2016-05-07 21:30:29 --> Controller Class Initialized
INFO - 2016-05-07 21:30:29 --> Model Class Initialized
INFO - 2016-05-07 21:30:29 --> Database Driver Class Initialized
INFO - 2016-05-07 21:30:29 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:30:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:30:29 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:30:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:30:29 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 21:30:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:30:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:30:29 --> Final output sent to browser
DEBUG - 2016-05-07 21:30:29 --> Total execution time: 0.1003
INFO - 2016-05-07 21:31:06 --> Config Class Initialized
INFO - 2016-05-07 21:31:06 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:31:06 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:31:06 --> Utf8 Class Initialized
INFO - 2016-05-07 21:31:06 --> URI Class Initialized
INFO - 2016-05-07 21:31:06 --> Router Class Initialized
INFO - 2016-05-07 21:31:06 --> Output Class Initialized
INFO - 2016-05-07 21:31:06 --> Security Class Initialized
DEBUG - 2016-05-07 21:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:31:06 --> Input Class Initialized
INFO - 2016-05-07 21:31:06 --> Language Class Initialized
INFO - 2016-05-07 21:31:06 --> Loader Class Initialized
INFO - 2016-05-07 21:31:07 --> Helper loaded: url_helper
INFO - 2016-05-07 21:31:07 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:31:07 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:31:07 --> Helper loaded: form_helper
INFO - 2016-05-07 21:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:31:07 --> Form Validation Class Initialized
INFO - 2016-05-07 21:31:07 --> Controller Class Initialized
INFO - 2016-05-07 21:31:07 --> Model Class Initialized
INFO - 2016-05-07 21:31:07 --> Database Driver Class Initialized
INFO - 2016-05-07 21:31:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:31:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:31:07 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:31:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:31:07 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 21:31:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:31:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:31:07 --> Final output sent to browser
DEBUG - 2016-05-07 21:31:07 --> Total execution time: 0.1070
INFO - 2016-05-07 21:36:29 --> Config Class Initialized
INFO - 2016-05-07 21:36:29 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:36:29 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:36:29 --> Utf8 Class Initialized
INFO - 2016-05-07 21:36:29 --> URI Class Initialized
INFO - 2016-05-07 21:36:29 --> Router Class Initialized
INFO - 2016-05-07 21:36:29 --> Output Class Initialized
INFO - 2016-05-07 21:36:29 --> Security Class Initialized
DEBUG - 2016-05-07 21:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:36:29 --> Input Class Initialized
INFO - 2016-05-07 21:36:29 --> Language Class Initialized
INFO - 2016-05-07 21:36:29 --> Loader Class Initialized
INFO - 2016-05-07 21:36:29 --> Helper loaded: url_helper
INFO - 2016-05-07 21:36:29 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:36:29 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:36:29 --> Helper loaded: form_helper
INFO - 2016-05-07 21:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:36:29 --> Form Validation Class Initialized
INFO - 2016-05-07 21:36:29 --> Controller Class Initialized
INFO - 2016-05-07 21:36:29 --> Model Class Initialized
INFO - 2016-05-07 21:36:29 --> Database Driver Class Initialized
INFO - 2016-05-07 21:36:29 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:36:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:36:29 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:36:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:36:30 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 21:36:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:36:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:36:30 --> Final output sent to browser
DEBUG - 2016-05-07 21:36:30 --> Total execution time: 0.6891
INFO - 2016-05-07 21:37:05 --> Config Class Initialized
INFO - 2016-05-07 21:37:05 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:37:05 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:37:05 --> Utf8 Class Initialized
INFO - 2016-05-07 21:37:05 --> URI Class Initialized
INFO - 2016-05-07 21:37:05 --> Router Class Initialized
INFO - 2016-05-07 21:37:05 --> Output Class Initialized
INFO - 2016-05-07 21:37:05 --> Security Class Initialized
DEBUG - 2016-05-07 21:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:37:05 --> Input Class Initialized
INFO - 2016-05-07 21:37:05 --> Language Class Initialized
INFO - 2016-05-07 21:37:05 --> Loader Class Initialized
INFO - 2016-05-07 21:37:05 --> Helper loaded: url_helper
INFO - 2016-05-07 21:37:05 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:37:05 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:37:05 --> Helper loaded: form_helper
INFO - 2016-05-07 21:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:37:05 --> Form Validation Class Initialized
INFO - 2016-05-07 21:37:05 --> Controller Class Initialized
INFO - 2016-05-07 21:37:05 --> Model Class Initialized
INFO - 2016-05-07 21:37:05 --> Database Driver Class Initialized
INFO - 2016-05-07 21:37:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:37:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:37:05 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:37:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:37:05 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 21:37:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:37:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:37:05 --> Final output sent to browser
DEBUG - 2016-05-07 21:37:05 --> Total execution time: 0.0857
INFO - 2016-05-07 21:37:12 --> Config Class Initialized
INFO - 2016-05-07 21:37:12 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:37:12 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:37:12 --> Utf8 Class Initialized
INFO - 2016-05-07 21:37:12 --> URI Class Initialized
INFO - 2016-05-07 21:37:12 --> Router Class Initialized
INFO - 2016-05-07 21:37:12 --> Output Class Initialized
INFO - 2016-05-07 21:37:12 --> Security Class Initialized
DEBUG - 2016-05-07 21:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:37:12 --> Input Class Initialized
INFO - 2016-05-07 21:37:12 --> Language Class Initialized
INFO - 2016-05-07 21:37:12 --> Loader Class Initialized
INFO - 2016-05-07 21:37:12 --> Helper loaded: url_helper
INFO - 2016-05-07 21:37:12 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:37:12 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:37:12 --> Helper loaded: form_helper
INFO - 2016-05-07 21:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:37:12 --> Form Validation Class Initialized
INFO - 2016-05-07 21:37:12 --> Controller Class Initialized
INFO - 2016-05-07 21:37:12 --> Model Class Initialized
INFO - 2016-05-07 21:37:12 --> Database Driver Class Initialized
INFO - 2016-05-07 21:37:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:37:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:37:12 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:37:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:37:12 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 21:37:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:37:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:37:12 --> Final output sent to browser
DEBUG - 2016-05-07 21:37:12 --> Total execution time: 0.0815
INFO - 2016-05-07 21:37:15 --> Config Class Initialized
INFO - 2016-05-07 21:37:15 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:37:15 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:37:15 --> Utf8 Class Initialized
INFO - 2016-05-07 21:37:15 --> URI Class Initialized
INFO - 2016-05-07 21:37:15 --> Router Class Initialized
INFO - 2016-05-07 21:37:15 --> Output Class Initialized
INFO - 2016-05-07 21:37:15 --> Security Class Initialized
DEBUG - 2016-05-07 21:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:37:15 --> Input Class Initialized
INFO - 2016-05-07 21:37:15 --> Language Class Initialized
INFO - 2016-05-07 21:37:15 --> Loader Class Initialized
INFO - 2016-05-07 21:37:15 --> Helper loaded: url_helper
INFO - 2016-05-07 21:37:15 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:37:15 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:37:15 --> Helper loaded: form_helper
INFO - 2016-05-07 21:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:37:15 --> Form Validation Class Initialized
INFO - 2016-05-07 21:37:15 --> Controller Class Initialized
INFO - 2016-05-07 21:37:15 --> Model Class Initialized
INFO - 2016-05-07 21:37:15 --> Database Driver Class Initialized
INFO - 2016-05-07 21:37:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:37:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:37:15 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:37:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:37:15 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 21:37:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:37:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:37:15 --> Final output sent to browser
DEBUG - 2016-05-07 21:37:15 --> Total execution time: 0.0876
INFO - 2016-05-07 21:37:25 --> Config Class Initialized
INFO - 2016-05-07 21:37:25 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:37:25 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:37:25 --> Utf8 Class Initialized
INFO - 2016-05-07 21:37:25 --> URI Class Initialized
INFO - 2016-05-07 21:37:25 --> Router Class Initialized
INFO - 2016-05-07 21:37:25 --> Output Class Initialized
INFO - 2016-05-07 21:37:25 --> Security Class Initialized
DEBUG - 2016-05-07 21:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:37:25 --> Input Class Initialized
INFO - 2016-05-07 21:37:25 --> Language Class Initialized
INFO - 2016-05-07 21:37:25 --> Loader Class Initialized
INFO - 2016-05-07 21:37:25 --> Helper loaded: url_helper
INFO - 2016-05-07 21:37:25 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:37:25 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:37:25 --> Helper loaded: form_helper
INFO - 2016-05-07 21:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:37:25 --> Form Validation Class Initialized
INFO - 2016-05-07 21:37:25 --> Controller Class Initialized
INFO - 2016-05-07 21:37:25 --> Model Class Initialized
INFO - 2016-05-07 21:37:25 --> Database Driver Class Initialized
INFO - 2016-05-07 21:37:25 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:37:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:37:25 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:37:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 21:37:25 --> Severity: Notice --> Undefined variable: resultado C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 278
INFO - 2016-05-07 21:37:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:37:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:37:25 --> Final output sent to browser
DEBUG - 2016-05-07 21:37:25 --> Total execution time: 0.1719
INFO - 2016-05-07 21:38:23 --> Config Class Initialized
INFO - 2016-05-07 21:38:23 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:38:23 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:38:23 --> Utf8 Class Initialized
INFO - 2016-05-07 21:38:23 --> URI Class Initialized
INFO - 2016-05-07 21:38:23 --> Router Class Initialized
INFO - 2016-05-07 21:38:23 --> Output Class Initialized
INFO - 2016-05-07 21:38:23 --> Security Class Initialized
DEBUG - 2016-05-07 21:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:38:23 --> Input Class Initialized
INFO - 2016-05-07 21:38:23 --> Language Class Initialized
INFO - 2016-05-07 21:38:23 --> Loader Class Initialized
INFO - 2016-05-07 21:38:23 --> Helper loaded: url_helper
INFO - 2016-05-07 21:38:23 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:38:23 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:38:23 --> Helper loaded: form_helper
INFO - 2016-05-07 21:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:38:23 --> Form Validation Class Initialized
INFO - 2016-05-07 21:38:23 --> Controller Class Initialized
INFO - 2016-05-07 21:38:23 --> Model Class Initialized
INFO - 2016-05-07 21:38:23 --> Database Driver Class Initialized
INFO - 2016-05-07 21:38:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:38:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:38:23 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:38:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:38:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:38:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:38:23 --> Final output sent to browser
DEBUG - 2016-05-07 21:38:23 --> Total execution time: 0.0797
INFO - 2016-05-07 21:38:46 --> Config Class Initialized
INFO - 2016-05-07 21:38:46 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:38:46 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:38:46 --> Utf8 Class Initialized
INFO - 2016-05-07 21:38:46 --> URI Class Initialized
INFO - 2016-05-07 21:38:46 --> Router Class Initialized
INFO - 2016-05-07 21:38:46 --> Output Class Initialized
INFO - 2016-05-07 21:38:46 --> Security Class Initialized
DEBUG - 2016-05-07 21:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:38:46 --> Input Class Initialized
INFO - 2016-05-07 21:38:46 --> Language Class Initialized
INFO - 2016-05-07 21:38:46 --> Loader Class Initialized
INFO - 2016-05-07 21:38:46 --> Helper loaded: url_helper
INFO - 2016-05-07 21:38:46 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:38:46 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:38:46 --> Helper loaded: form_helper
INFO - 2016-05-07 21:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:38:46 --> Form Validation Class Initialized
INFO - 2016-05-07 21:38:46 --> Controller Class Initialized
INFO - 2016-05-07 21:38:46 --> Model Class Initialized
INFO - 2016-05-07 21:38:46 --> Database Driver Class Initialized
INFO - 2016-05-07 21:38:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:38:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:38:46 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:38:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:38:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:38:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:38:46 --> Final output sent to browser
DEBUG - 2016-05-07 21:38:46 --> Total execution time: 0.0723
INFO - 2016-05-07 21:39:20 --> Config Class Initialized
INFO - 2016-05-07 21:39:20 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:39:20 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:39:20 --> Utf8 Class Initialized
INFO - 2016-05-07 21:39:20 --> URI Class Initialized
INFO - 2016-05-07 21:39:20 --> Router Class Initialized
INFO - 2016-05-07 21:39:20 --> Output Class Initialized
INFO - 2016-05-07 21:39:20 --> Security Class Initialized
DEBUG - 2016-05-07 21:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:39:20 --> Input Class Initialized
INFO - 2016-05-07 21:39:20 --> Language Class Initialized
INFO - 2016-05-07 21:39:20 --> Loader Class Initialized
INFO - 2016-05-07 21:39:20 --> Helper loaded: url_helper
INFO - 2016-05-07 21:39:20 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:39:20 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:39:20 --> Helper loaded: form_helper
INFO - 2016-05-07 21:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:39:20 --> Form Validation Class Initialized
INFO - 2016-05-07 21:39:20 --> Controller Class Initialized
INFO - 2016-05-07 21:39:20 --> Model Class Initialized
INFO - 2016-05-07 21:39:20 --> Database Driver Class Initialized
INFO - 2016-05-07 21:39:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:39:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:39:20 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:39:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:39:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:39:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:39:20 --> Final output sent to browser
DEBUG - 2016-05-07 21:39:20 --> Total execution time: 0.0749
INFO - 2016-05-07 21:39:29 --> Config Class Initialized
INFO - 2016-05-07 21:39:29 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:39:29 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:39:29 --> Utf8 Class Initialized
INFO - 2016-05-07 21:39:29 --> URI Class Initialized
INFO - 2016-05-07 21:39:29 --> Router Class Initialized
INFO - 2016-05-07 21:39:29 --> Output Class Initialized
INFO - 2016-05-07 21:39:29 --> Security Class Initialized
DEBUG - 2016-05-07 21:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:39:29 --> Input Class Initialized
INFO - 2016-05-07 21:39:29 --> Language Class Initialized
INFO - 2016-05-07 21:39:29 --> Loader Class Initialized
INFO - 2016-05-07 21:39:29 --> Helper loaded: url_helper
INFO - 2016-05-07 21:39:29 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:39:29 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:39:29 --> Helper loaded: form_helper
INFO - 2016-05-07 21:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:39:29 --> Form Validation Class Initialized
INFO - 2016-05-07 21:39:29 --> Controller Class Initialized
INFO - 2016-05-07 21:39:29 --> Model Class Initialized
INFO - 2016-05-07 21:39:29 --> Database Driver Class Initialized
INFO - 2016-05-07 21:39:29 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:39:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:39:29 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:39:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:39:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:39:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:39:29 --> Final output sent to browser
DEBUG - 2016-05-07 21:39:29 --> Total execution time: 0.1822
INFO - 2016-05-07 21:39:33 --> Config Class Initialized
INFO - 2016-05-07 21:39:33 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:39:33 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:39:33 --> Utf8 Class Initialized
INFO - 2016-05-07 21:39:33 --> URI Class Initialized
INFO - 2016-05-07 21:39:33 --> Router Class Initialized
INFO - 2016-05-07 21:39:33 --> Output Class Initialized
INFO - 2016-05-07 21:39:33 --> Security Class Initialized
DEBUG - 2016-05-07 21:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:39:33 --> Input Class Initialized
INFO - 2016-05-07 21:39:33 --> Language Class Initialized
INFO - 2016-05-07 21:39:33 --> Loader Class Initialized
INFO - 2016-05-07 21:39:33 --> Helper loaded: url_helper
INFO - 2016-05-07 21:39:33 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:39:33 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:39:33 --> Helper loaded: form_helper
INFO - 2016-05-07 21:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:39:33 --> Form Validation Class Initialized
INFO - 2016-05-07 21:39:33 --> Controller Class Initialized
INFO - 2016-05-07 21:39:33 --> Model Class Initialized
INFO - 2016-05-07 21:39:33 --> Database Driver Class Initialized
INFO - 2016-05-07 21:39:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:39:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:39:33 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:39:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:39:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 21:39:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:39:33 --> Final output sent to browser
DEBUG - 2016-05-07 21:39:33 --> Total execution time: 0.0857
INFO - 2016-05-07 21:39:37 --> Config Class Initialized
INFO - 2016-05-07 21:39:37 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:39:37 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:39:37 --> Utf8 Class Initialized
INFO - 2016-05-07 21:39:37 --> URI Class Initialized
INFO - 2016-05-07 21:39:37 --> Router Class Initialized
INFO - 2016-05-07 21:39:37 --> Output Class Initialized
INFO - 2016-05-07 21:39:37 --> Security Class Initialized
DEBUG - 2016-05-07 21:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:39:37 --> Input Class Initialized
INFO - 2016-05-07 21:39:37 --> Language Class Initialized
INFO - 2016-05-07 21:39:37 --> Loader Class Initialized
INFO - 2016-05-07 21:39:37 --> Helper loaded: url_helper
INFO - 2016-05-07 21:39:37 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:39:37 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:39:37 --> Helper loaded: form_helper
INFO - 2016-05-07 21:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:39:37 --> Form Validation Class Initialized
INFO - 2016-05-07 21:39:37 --> Controller Class Initialized
INFO - 2016-05-07 21:39:37 --> Model Class Initialized
INFO - 2016-05-07 21:39:37 --> Database Driver Class Initialized
INFO - 2016-05-07 21:39:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:39:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:39:37 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:39:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:39:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 21:39:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:39:37 --> Final output sent to browser
DEBUG - 2016-05-07 21:39:37 --> Total execution time: 0.1280
INFO - 2016-05-07 21:39:41 --> Config Class Initialized
INFO - 2016-05-07 21:39:41 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:39:41 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:39:41 --> Utf8 Class Initialized
INFO - 2016-05-07 21:39:41 --> URI Class Initialized
INFO - 2016-05-07 21:39:41 --> Router Class Initialized
INFO - 2016-05-07 21:39:41 --> Output Class Initialized
INFO - 2016-05-07 21:39:41 --> Security Class Initialized
DEBUG - 2016-05-07 21:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:39:41 --> Input Class Initialized
INFO - 2016-05-07 21:39:41 --> Language Class Initialized
INFO - 2016-05-07 21:39:41 --> Loader Class Initialized
INFO - 2016-05-07 21:39:41 --> Helper loaded: url_helper
INFO - 2016-05-07 21:39:41 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:39:41 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:39:41 --> Helper loaded: form_helper
INFO - 2016-05-07 21:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:39:41 --> Form Validation Class Initialized
INFO - 2016-05-07 21:39:41 --> Controller Class Initialized
INFO - 2016-05-07 21:39:41 --> Model Class Initialized
INFO - 2016-05-07 21:39:41 --> Database Driver Class Initialized
INFO - 2016-05-07 21:39:41 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:39:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:39:41 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:39:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:39:41 --> Config Class Initialized
INFO - 2016-05-07 21:39:41 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:39:41 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:39:41 --> Utf8 Class Initialized
INFO - 2016-05-07 21:39:41 --> URI Class Initialized
INFO - 2016-05-07 21:39:41 --> Router Class Initialized
INFO - 2016-05-07 21:39:41 --> Output Class Initialized
INFO - 2016-05-07 21:39:41 --> Security Class Initialized
DEBUG - 2016-05-07 21:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:39:41 --> Input Class Initialized
INFO - 2016-05-07 21:39:41 --> Language Class Initialized
INFO - 2016-05-07 21:39:41 --> Loader Class Initialized
INFO - 2016-05-07 21:39:41 --> Helper loaded: url_helper
INFO - 2016-05-07 21:39:41 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:39:41 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:39:41 --> Helper loaded: form_helper
INFO - 2016-05-07 21:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:39:41 --> Form Validation Class Initialized
INFO - 2016-05-07 21:39:41 --> Controller Class Initialized
INFO - 2016-05-07 21:39:41 --> Model Class Initialized
INFO - 2016-05-07 21:39:41 --> Database Driver Class Initialized
INFO - 2016-05-07 21:39:41 --> Config Class Initialized
INFO - 2016-05-07 21:39:41 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:39:41 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:39:41 --> Utf8 Class Initialized
INFO - 2016-05-07 21:39:41 --> URI Class Initialized
INFO - 2016-05-07 21:39:41 --> Router Class Initialized
INFO - 2016-05-07 21:39:41 --> Output Class Initialized
INFO - 2016-05-07 21:39:41 --> Security Class Initialized
DEBUG - 2016-05-07 21:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:39:41 --> Input Class Initialized
INFO - 2016-05-07 21:39:41 --> Language Class Initialized
INFO - 2016-05-07 21:39:41 --> Loader Class Initialized
INFO - 2016-05-07 21:39:41 --> Helper loaded: url_helper
INFO - 2016-05-07 21:39:41 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:39:41 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:39:41 --> Helper loaded: form_helper
INFO - 2016-05-07 21:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:39:41 --> Form Validation Class Initialized
INFO - 2016-05-07 21:39:41 --> Controller Class Initialized
INFO - 2016-05-07 21:39:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-07 21:39:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:39:41 --> Final output sent to browser
DEBUG - 2016-05-07 21:39:41 --> Total execution time: 0.0662
INFO - 2016-05-07 21:39:43 --> Config Class Initialized
INFO - 2016-05-07 21:39:43 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:39:43 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:39:43 --> Utf8 Class Initialized
INFO - 2016-05-07 21:39:43 --> URI Class Initialized
INFO - 2016-05-07 21:39:43 --> Router Class Initialized
INFO - 2016-05-07 21:39:43 --> Output Class Initialized
INFO - 2016-05-07 21:39:43 --> Security Class Initialized
DEBUG - 2016-05-07 21:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:39:43 --> Input Class Initialized
INFO - 2016-05-07 21:39:43 --> Language Class Initialized
INFO - 2016-05-07 21:39:43 --> Loader Class Initialized
INFO - 2016-05-07 21:39:43 --> Helper loaded: url_helper
INFO - 2016-05-07 21:39:43 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:39:43 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:39:43 --> Helper loaded: form_helper
INFO - 2016-05-07 21:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:39:43 --> Form Validation Class Initialized
INFO - 2016-05-07 21:39:43 --> Controller Class Initialized
INFO - 2016-05-07 21:39:43 --> Model Class Initialized
INFO - 2016-05-07 21:39:43 --> Database Driver Class Initialized
INFO - 2016-05-07 21:39:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:39:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:39:43 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:39:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:39:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 21:39:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:39:43 --> Final output sent to browser
DEBUG - 2016-05-07 21:39:43 --> Total execution time: 0.0784
INFO - 2016-05-07 21:40:36 --> Config Class Initialized
INFO - 2016-05-07 21:40:36 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:40:36 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:40:36 --> Utf8 Class Initialized
INFO - 2016-05-07 21:40:36 --> URI Class Initialized
INFO - 2016-05-07 21:40:36 --> Router Class Initialized
INFO - 2016-05-07 21:40:36 --> Output Class Initialized
INFO - 2016-05-07 21:40:36 --> Security Class Initialized
DEBUG - 2016-05-07 21:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:40:36 --> Input Class Initialized
INFO - 2016-05-07 21:40:36 --> Language Class Initialized
INFO - 2016-05-07 21:40:36 --> Loader Class Initialized
INFO - 2016-05-07 21:40:36 --> Helper loaded: url_helper
INFO - 2016-05-07 21:40:36 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:40:36 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:40:36 --> Helper loaded: form_helper
INFO - 2016-05-07 21:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:40:36 --> Form Validation Class Initialized
INFO - 2016-05-07 21:40:36 --> Controller Class Initialized
INFO - 2016-05-07 21:40:36 --> Model Class Initialized
INFO - 2016-05-07 21:40:36 --> Database Driver Class Initialized
INFO - 2016-05-07 21:40:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:40:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:40:36 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:40:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:40:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 21:40:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:40:36 --> Final output sent to browser
DEBUG - 2016-05-07 21:40:36 --> Total execution time: 0.0830
INFO - 2016-05-07 21:40:41 --> Config Class Initialized
INFO - 2016-05-07 21:40:41 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:40:41 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:40:41 --> Utf8 Class Initialized
INFO - 2016-05-07 21:40:41 --> URI Class Initialized
INFO - 2016-05-07 21:40:41 --> Router Class Initialized
INFO - 2016-05-07 21:40:41 --> Output Class Initialized
INFO - 2016-05-07 21:40:41 --> Security Class Initialized
DEBUG - 2016-05-07 21:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:40:41 --> Input Class Initialized
INFO - 2016-05-07 21:40:41 --> Language Class Initialized
INFO - 2016-05-07 21:40:41 --> Loader Class Initialized
INFO - 2016-05-07 21:40:41 --> Helper loaded: url_helper
INFO - 2016-05-07 21:40:41 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:40:41 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:40:41 --> Helper loaded: form_helper
INFO - 2016-05-07 21:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:40:41 --> Form Validation Class Initialized
INFO - 2016-05-07 21:40:41 --> Controller Class Initialized
INFO - 2016-05-07 21:40:41 --> Model Class Initialized
INFO - 2016-05-07 21:40:41 --> Database Driver Class Initialized
INFO - 2016-05-07 21:40:41 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:40:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:40:41 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:40:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:40:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 21:40:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:40:41 --> Final output sent to browser
DEBUG - 2016-05-07 21:40:41 --> Total execution time: 0.1615
INFO - 2016-05-07 21:40:43 --> Config Class Initialized
INFO - 2016-05-07 21:40:43 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:40:43 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:40:43 --> Utf8 Class Initialized
INFO - 2016-05-07 21:40:43 --> URI Class Initialized
INFO - 2016-05-07 21:40:43 --> Router Class Initialized
INFO - 2016-05-07 21:40:43 --> Output Class Initialized
INFO - 2016-05-07 21:40:43 --> Security Class Initialized
DEBUG - 2016-05-07 21:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:40:43 --> Input Class Initialized
INFO - 2016-05-07 21:40:43 --> Language Class Initialized
INFO - 2016-05-07 21:40:43 --> Loader Class Initialized
INFO - 2016-05-07 21:40:43 --> Helper loaded: url_helper
INFO - 2016-05-07 21:40:43 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:40:43 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:40:43 --> Helper loaded: form_helper
INFO - 2016-05-07 21:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:40:43 --> Form Validation Class Initialized
INFO - 2016-05-07 21:40:43 --> Controller Class Initialized
INFO - 2016-05-07 21:40:43 --> Model Class Initialized
INFO - 2016-05-07 21:40:43 --> Database Driver Class Initialized
INFO - 2016-05-07 21:40:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:40:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:40:43 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:40:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:40:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 21:40:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:40:43 --> Final output sent to browser
DEBUG - 2016-05-07 21:40:43 --> Total execution time: 0.0879
INFO - 2016-05-07 21:40:46 --> Config Class Initialized
INFO - 2016-05-07 21:40:46 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:40:46 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:40:46 --> Utf8 Class Initialized
INFO - 2016-05-07 21:40:46 --> URI Class Initialized
INFO - 2016-05-07 21:40:46 --> Router Class Initialized
INFO - 2016-05-07 21:40:46 --> Output Class Initialized
INFO - 2016-05-07 21:40:46 --> Security Class Initialized
DEBUG - 2016-05-07 21:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:40:46 --> Input Class Initialized
INFO - 2016-05-07 21:40:46 --> Language Class Initialized
INFO - 2016-05-07 21:40:46 --> Loader Class Initialized
INFO - 2016-05-07 21:40:46 --> Helper loaded: url_helper
INFO - 2016-05-07 21:40:46 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:40:46 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:40:46 --> Helper loaded: form_helper
INFO - 2016-05-07 21:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:40:46 --> Form Validation Class Initialized
INFO - 2016-05-07 21:40:46 --> Controller Class Initialized
INFO - 2016-05-07 21:40:46 --> Model Class Initialized
INFO - 2016-05-07 21:40:46 --> Database Driver Class Initialized
INFO - 2016-05-07 21:40:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:40:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:40:46 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:40:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:40:46 --> Config Class Initialized
INFO - 2016-05-07 21:40:46 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:40:46 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:40:46 --> Utf8 Class Initialized
INFO - 2016-05-07 21:40:46 --> URI Class Initialized
INFO - 2016-05-07 21:40:46 --> Router Class Initialized
INFO - 2016-05-07 21:40:46 --> Output Class Initialized
INFO - 2016-05-07 21:40:46 --> Security Class Initialized
DEBUG - 2016-05-07 21:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:40:46 --> Input Class Initialized
INFO - 2016-05-07 21:40:46 --> Language Class Initialized
INFO - 2016-05-07 21:40:46 --> Loader Class Initialized
INFO - 2016-05-07 21:40:46 --> Helper loaded: url_helper
INFO - 2016-05-07 21:40:46 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:40:46 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:40:46 --> Helper loaded: form_helper
INFO - 2016-05-07 21:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:40:46 --> Form Validation Class Initialized
INFO - 2016-05-07 21:40:46 --> Controller Class Initialized
INFO - 2016-05-07 21:40:46 --> Model Class Initialized
INFO - 2016-05-07 21:40:46 --> Database Driver Class Initialized
INFO - 2016-05-07 21:40:46 --> Config Class Initialized
INFO - 2016-05-07 21:40:46 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:40:46 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:40:46 --> Utf8 Class Initialized
INFO - 2016-05-07 21:40:46 --> URI Class Initialized
INFO - 2016-05-07 21:40:46 --> Router Class Initialized
INFO - 2016-05-07 21:40:46 --> Output Class Initialized
INFO - 2016-05-07 21:40:46 --> Security Class Initialized
DEBUG - 2016-05-07 21:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:40:46 --> Input Class Initialized
INFO - 2016-05-07 21:40:46 --> Language Class Initialized
INFO - 2016-05-07 21:40:46 --> Loader Class Initialized
INFO - 2016-05-07 21:40:46 --> Helper loaded: url_helper
INFO - 2016-05-07 21:40:46 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:40:46 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:40:46 --> Helper loaded: form_helper
INFO - 2016-05-07 21:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:40:46 --> Form Validation Class Initialized
INFO - 2016-05-07 21:40:46 --> Controller Class Initialized
INFO - 2016-05-07 21:40:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-07 21:40:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:40:46 --> Final output sent to browser
DEBUG - 2016-05-07 21:40:46 --> Total execution time: 0.0518
INFO - 2016-05-07 21:40:47 --> Config Class Initialized
INFO - 2016-05-07 21:40:47 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:40:47 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:40:47 --> Utf8 Class Initialized
INFO - 2016-05-07 21:40:47 --> URI Class Initialized
INFO - 2016-05-07 21:40:47 --> Router Class Initialized
INFO - 2016-05-07 21:40:47 --> Output Class Initialized
INFO - 2016-05-07 21:40:47 --> Security Class Initialized
DEBUG - 2016-05-07 21:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:40:47 --> Input Class Initialized
INFO - 2016-05-07 21:40:47 --> Language Class Initialized
INFO - 2016-05-07 21:40:47 --> Loader Class Initialized
INFO - 2016-05-07 21:40:47 --> Helper loaded: url_helper
INFO - 2016-05-07 21:40:47 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:40:47 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:40:47 --> Helper loaded: form_helper
INFO - 2016-05-07 21:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:40:47 --> Form Validation Class Initialized
INFO - 2016-05-07 21:40:47 --> Controller Class Initialized
INFO - 2016-05-07 21:40:47 --> Model Class Initialized
INFO - 2016-05-07 21:40:47 --> Database Driver Class Initialized
INFO - 2016-05-07 21:40:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:40:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:40:47 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:40:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:40:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 21:40:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:40:47 --> Final output sent to browser
DEBUG - 2016-05-07 21:40:47 --> Total execution time: 0.1341
INFO - 2016-05-07 21:40:49 --> Config Class Initialized
INFO - 2016-05-07 21:40:49 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:40:49 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:40:49 --> Utf8 Class Initialized
INFO - 2016-05-07 21:40:49 --> URI Class Initialized
INFO - 2016-05-07 21:40:49 --> Router Class Initialized
INFO - 2016-05-07 21:40:49 --> Output Class Initialized
INFO - 2016-05-07 21:40:49 --> Security Class Initialized
DEBUG - 2016-05-07 21:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:40:49 --> Input Class Initialized
INFO - 2016-05-07 21:40:49 --> Language Class Initialized
INFO - 2016-05-07 21:40:49 --> Loader Class Initialized
INFO - 2016-05-07 21:40:49 --> Helper loaded: url_helper
INFO - 2016-05-07 21:40:49 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:40:49 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:40:49 --> Helper loaded: form_helper
INFO - 2016-05-07 21:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:40:49 --> Form Validation Class Initialized
INFO - 2016-05-07 21:40:49 --> Controller Class Initialized
INFO - 2016-05-07 21:40:49 --> Model Class Initialized
INFO - 2016-05-07 21:40:50 --> Database Driver Class Initialized
INFO - 2016-05-07 21:40:50 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:40:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:40:50 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:40:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:40:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 21:40:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:40:50 --> Final output sent to browser
DEBUG - 2016-05-07 21:40:50 --> Total execution time: 0.1827
INFO - 2016-05-07 21:40:52 --> Config Class Initialized
INFO - 2016-05-07 21:40:52 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:40:52 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:40:52 --> Utf8 Class Initialized
INFO - 2016-05-07 21:40:52 --> URI Class Initialized
INFO - 2016-05-07 21:40:52 --> Router Class Initialized
INFO - 2016-05-07 21:40:52 --> Output Class Initialized
INFO - 2016-05-07 21:40:52 --> Security Class Initialized
DEBUG - 2016-05-07 21:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:40:52 --> Input Class Initialized
INFO - 2016-05-07 21:40:52 --> Language Class Initialized
INFO - 2016-05-07 21:40:52 --> Loader Class Initialized
INFO - 2016-05-07 21:40:52 --> Helper loaded: url_helper
INFO - 2016-05-07 21:40:52 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:40:52 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:40:52 --> Helper loaded: form_helper
INFO - 2016-05-07 21:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:40:52 --> Form Validation Class Initialized
INFO - 2016-05-07 21:40:52 --> Controller Class Initialized
INFO - 2016-05-07 21:40:52 --> Model Class Initialized
INFO - 2016-05-07 21:40:52 --> Database Driver Class Initialized
INFO - 2016-05-07 21:40:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:40:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:40:52 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:40:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:40:52 --> Config Class Initialized
INFO - 2016-05-07 21:40:52 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:40:52 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:40:52 --> Utf8 Class Initialized
INFO - 2016-05-07 21:40:52 --> URI Class Initialized
INFO - 2016-05-07 21:40:52 --> Router Class Initialized
INFO - 2016-05-07 21:40:52 --> Output Class Initialized
INFO - 2016-05-07 21:40:52 --> Security Class Initialized
DEBUG - 2016-05-07 21:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:40:52 --> Input Class Initialized
INFO - 2016-05-07 21:40:52 --> Language Class Initialized
INFO - 2016-05-07 21:40:52 --> Loader Class Initialized
INFO - 2016-05-07 21:40:52 --> Helper loaded: url_helper
INFO - 2016-05-07 21:40:52 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:40:52 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:40:52 --> Helper loaded: form_helper
INFO - 2016-05-07 21:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:40:52 --> Form Validation Class Initialized
INFO - 2016-05-07 21:40:52 --> Controller Class Initialized
INFO - 2016-05-07 21:40:52 --> Model Class Initialized
INFO - 2016-05-07 21:40:52 --> Database Driver Class Initialized
INFO - 2016-05-07 21:40:52 --> Config Class Initialized
INFO - 2016-05-07 21:40:52 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:40:52 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:40:52 --> Utf8 Class Initialized
INFO - 2016-05-07 21:40:52 --> URI Class Initialized
INFO - 2016-05-07 21:40:52 --> Router Class Initialized
INFO - 2016-05-07 21:40:52 --> Output Class Initialized
INFO - 2016-05-07 21:40:52 --> Security Class Initialized
DEBUG - 2016-05-07 21:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:40:52 --> Input Class Initialized
INFO - 2016-05-07 21:40:52 --> Language Class Initialized
INFO - 2016-05-07 21:40:52 --> Loader Class Initialized
INFO - 2016-05-07 21:40:52 --> Helper loaded: url_helper
INFO - 2016-05-07 21:40:52 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:40:52 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:40:52 --> Helper loaded: form_helper
INFO - 2016-05-07 21:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:40:53 --> Form Validation Class Initialized
INFO - 2016-05-07 21:40:53 --> Controller Class Initialized
INFO - 2016-05-07 21:40:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-07 21:40:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:40:53 --> Final output sent to browser
DEBUG - 2016-05-07 21:40:53 --> Total execution time: 0.0579
INFO - 2016-05-07 21:40:54 --> Config Class Initialized
INFO - 2016-05-07 21:40:54 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:40:54 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:40:54 --> Utf8 Class Initialized
INFO - 2016-05-07 21:40:54 --> URI Class Initialized
INFO - 2016-05-07 21:40:54 --> Router Class Initialized
INFO - 2016-05-07 21:40:54 --> Output Class Initialized
INFO - 2016-05-07 21:40:54 --> Security Class Initialized
DEBUG - 2016-05-07 21:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:40:54 --> Input Class Initialized
INFO - 2016-05-07 21:40:54 --> Language Class Initialized
INFO - 2016-05-07 21:40:54 --> Loader Class Initialized
INFO - 2016-05-07 21:40:54 --> Helper loaded: url_helper
INFO - 2016-05-07 21:40:54 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:40:54 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:40:54 --> Helper loaded: form_helper
INFO - 2016-05-07 21:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:40:54 --> Form Validation Class Initialized
INFO - 2016-05-07 21:40:54 --> Controller Class Initialized
INFO - 2016-05-07 21:40:54 --> Model Class Initialized
INFO - 2016-05-07 21:40:54 --> Database Driver Class Initialized
INFO - 2016-05-07 21:40:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:40:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:40:54 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:40:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:40:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 21:40:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:40:54 --> Final output sent to browser
DEBUG - 2016-05-07 21:40:54 --> Total execution time: 0.0801
INFO - 2016-05-07 21:41:02 --> Config Class Initialized
INFO - 2016-05-07 21:41:02 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:41:02 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:41:02 --> Utf8 Class Initialized
INFO - 2016-05-07 21:41:02 --> URI Class Initialized
INFO - 2016-05-07 21:41:02 --> Router Class Initialized
INFO - 2016-05-07 21:41:02 --> Output Class Initialized
INFO - 2016-05-07 21:41:02 --> Security Class Initialized
DEBUG - 2016-05-07 21:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:41:02 --> Input Class Initialized
INFO - 2016-05-07 21:41:02 --> Language Class Initialized
INFO - 2016-05-07 21:41:02 --> Loader Class Initialized
INFO - 2016-05-07 21:41:02 --> Helper loaded: url_helper
INFO - 2016-05-07 21:41:02 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:41:02 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:41:02 --> Helper loaded: form_helper
INFO - 2016-05-07 21:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:41:02 --> Form Validation Class Initialized
INFO - 2016-05-07 21:41:02 --> Controller Class Initialized
INFO - 2016-05-07 21:41:02 --> Model Class Initialized
INFO - 2016-05-07 21:41:02 --> Database Driver Class Initialized
INFO - 2016-05-07 21:41:02 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:41:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:41:02 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:41:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:41:02 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 21:41:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:41:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:41:02 --> Final output sent to browser
DEBUG - 2016-05-07 21:41:02 --> Total execution time: 0.1210
INFO - 2016-05-07 21:41:08 --> Config Class Initialized
INFO - 2016-05-07 21:41:08 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:41:08 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:41:08 --> Utf8 Class Initialized
INFO - 2016-05-07 21:41:08 --> URI Class Initialized
INFO - 2016-05-07 21:41:08 --> Router Class Initialized
INFO - 2016-05-07 21:41:08 --> Output Class Initialized
INFO - 2016-05-07 21:41:08 --> Security Class Initialized
DEBUG - 2016-05-07 21:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:41:08 --> Input Class Initialized
INFO - 2016-05-07 21:41:08 --> Language Class Initialized
INFO - 2016-05-07 21:41:08 --> Loader Class Initialized
INFO - 2016-05-07 21:41:08 --> Helper loaded: url_helper
INFO - 2016-05-07 21:41:08 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:41:08 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:41:08 --> Helper loaded: form_helper
INFO - 2016-05-07 21:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:41:08 --> Form Validation Class Initialized
INFO - 2016-05-07 21:41:08 --> Controller Class Initialized
INFO - 2016-05-07 21:41:08 --> Model Class Initialized
INFO - 2016-05-07 21:41:08 --> Database Driver Class Initialized
INFO - 2016-05-07 21:41:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:41:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:41:08 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:41:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:41:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:41:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:41:09 --> Final output sent to browser
DEBUG - 2016-05-07 21:41:09 --> Total execution time: 0.1459
INFO - 2016-05-07 21:41:10 --> Config Class Initialized
INFO - 2016-05-07 21:41:10 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:41:10 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:41:10 --> Utf8 Class Initialized
INFO - 2016-05-07 21:41:10 --> URI Class Initialized
INFO - 2016-05-07 21:41:10 --> Router Class Initialized
INFO - 2016-05-07 21:41:10 --> Output Class Initialized
INFO - 2016-05-07 21:41:10 --> Security Class Initialized
DEBUG - 2016-05-07 21:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:41:10 --> Input Class Initialized
INFO - 2016-05-07 21:41:10 --> Language Class Initialized
INFO - 2016-05-07 21:41:10 --> Loader Class Initialized
INFO - 2016-05-07 21:41:10 --> Helper loaded: url_helper
INFO - 2016-05-07 21:41:10 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:41:10 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:41:10 --> Helper loaded: form_helper
INFO - 2016-05-07 21:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:41:10 --> Form Validation Class Initialized
INFO - 2016-05-07 21:41:10 --> Controller Class Initialized
INFO - 2016-05-07 21:41:10 --> Model Class Initialized
INFO - 2016-05-07 21:41:10 --> Database Driver Class Initialized
INFO - 2016-05-07 21:41:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:41:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:41:10 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:41:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:41:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 21:41:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:41:10 --> Final output sent to browser
DEBUG - 2016-05-07 21:41:10 --> Total execution time: 0.0905
INFO - 2016-05-07 21:41:17 --> Config Class Initialized
INFO - 2016-05-07 21:41:17 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:41:17 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:41:17 --> Utf8 Class Initialized
INFO - 2016-05-07 21:41:17 --> URI Class Initialized
INFO - 2016-05-07 21:41:17 --> Router Class Initialized
INFO - 2016-05-07 21:41:17 --> Output Class Initialized
INFO - 2016-05-07 21:41:17 --> Security Class Initialized
DEBUG - 2016-05-07 21:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:41:17 --> Input Class Initialized
INFO - 2016-05-07 21:41:17 --> Language Class Initialized
INFO - 2016-05-07 21:41:17 --> Loader Class Initialized
INFO - 2016-05-07 21:41:17 --> Helper loaded: url_helper
INFO - 2016-05-07 21:41:17 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:41:17 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:41:17 --> Helper loaded: form_helper
INFO - 2016-05-07 21:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:41:17 --> Form Validation Class Initialized
INFO - 2016-05-07 21:41:17 --> Controller Class Initialized
INFO - 2016-05-07 21:41:17 --> Model Class Initialized
INFO - 2016-05-07 21:41:17 --> Database Driver Class Initialized
INFO - 2016-05-07 21:41:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:41:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:41:17 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:41:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:41:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 21:41:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:41:17 --> Final output sent to browser
DEBUG - 2016-05-07 21:41:17 --> Total execution time: 0.1068
INFO - 2016-05-07 21:41:20 --> Config Class Initialized
INFO - 2016-05-07 21:41:20 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:41:20 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:41:20 --> Utf8 Class Initialized
INFO - 2016-05-07 21:41:20 --> URI Class Initialized
INFO - 2016-05-07 21:41:20 --> Router Class Initialized
INFO - 2016-05-07 21:41:20 --> Output Class Initialized
INFO - 2016-05-07 21:41:20 --> Security Class Initialized
DEBUG - 2016-05-07 21:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:41:20 --> Input Class Initialized
INFO - 2016-05-07 21:41:20 --> Language Class Initialized
INFO - 2016-05-07 21:41:20 --> Loader Class Initialized
INFO - 2016-05-07 21:41:20 --> Helper loaded: url_helper
INFO - 2016-05-07 21:41:20 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:41:20 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:41:20 --> Helper loaded: form_helper
INFO - 2016-05-07 21:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:41:20 --> Form Validation Class Initialized
INFO - 2016-05-07 21:41:20 --> Controller Class Initialized
INFO - 2016-05-07 21:41:20 --> Model Class Initialized
INFO - 2016-05-07 21:41:20 --> Database Driver Class Initialized
INFO - 2016-05-07 21:41:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:41:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:41:20 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:41:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:41:20 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 21:41:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:41:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:41:20 --> Final output sent to browser
DEBUG - 2016-05-07 21:41:20 --> Total execution time: 0.1342
INFO - 2016-05-07 21:41:38 --> Config Class Initialized
INFO - 2016-05-07 21:41:38 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:41:38 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:41:38 --> Utf8 Class Initialized
INFO - 2016-05-07 21:41:38 --> URI Class Initialized
INFO - 2016-05-07 21:41:38 --> Router Class Initialized
INFO - 2016-05-07 21:41:38 --> Output Class Initialized
INFO - 2016-05-07 21:41:38 --> Security Class Initialized
DEBUG - 2016-05-07 21:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:41:38 --> Input Class Initialized
INFO - 2016-05-07 21:41:38 --> Language Class Initialized
INFO - 2016-05-07 21:41:38 --> Loader Class Initialized
INFO - 2016-05-07 21:41:38 --> Helper loaded: url_helper
INFO - 2016-05-07 21:41:38 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:41:38 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:41:38 --> Helper loaded: form_helper
INFO - 2016-05-07 21:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:41:38 --> Form Validation Class Initialized
INFO - 2016-05-07 21:41:38 --> Controller Class Initialized
INFO - 2016-05-07 21:41:38 --> Model Class Initialized
INFO - 2016-05-07 21:41:38 --> Database Driver Class Initialized
INFO - 2016-05-07 21:41:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:41:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:41:38 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:41:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:41:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:41:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:41:38 --> Final output sent to browser
DEBUG - 2016-05-07 21:41:38 --> Total execution time: 0.2282
INFO - 2016-05-07 21:41:43 --> Config Class Initialized
INFO - 2016-05-07 21:41:43 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:41:43 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:41:43 --> Utf8 Class Initialized
INFO - 2016-05-07 21:41:43 --> URI Class Initialized
INFO - 2016-05-07 21:41:43 --> Router Class Initialized
INFO - 2016-05-07 21:41:43 --> Output Class Initialized
INFO - 2016-05-07 21:41:43 --> Security Class Initialized
DEBUG - 2016-05-07 21:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:41:43 --> Input Class Initialized
INFO - 2016-05-07 21:41:43 --> Language Class Initialized
INFO - 2016-05-07 21:41:43 --> Loader Class Initialized
INFO - 2016-05-07 21:41:43 --> Helper loaded: url_helper
INFO - 2016-05-07 21:41:43 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:41:43 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:41:43 --> Helper loaded: form_helper
INFO - 2016-05-07 21:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:41:43 --> Form Validation Class Initialized
INFO - 2016-05-07 21:41:43 --> Controller Class Initialized
INFO - 2016-05-07 21:41:43 --> Model Class Initialized
INFO - 2016-05-07 21:41:43 --> Database Driver Class Initialized
INFO - 2016-05-07 21:41:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:41:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:41:43 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:41:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:41:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 21:41:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:41:43 --> Final output sent to browser
DEBUG - 2016-05-07 21:41:43 --> Total execution time: 0.0868
INFO - 2016-05-07 21:41:46 --> Config Class Initialized
INFO - 2016-05-07 21:41:46 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:41:46 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:41:46 --> Utf8 Class Initialized
INFO - 2016-05-07 21:41:46 --> URI Class Initialized
INFO - 2016-05-07 21:41:46 --> Router Class Initialized
INFO - 2016-05-07 21:41:46 --> Output Class Initialized
INFO - 2016-05-07 21:41:46 --> Security Class Initialized
DEBUG - 2016-05-07 21:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:41:46 --> Input Class Initialized
INFO - 2016-05-07 21:41:46 --> Language Class Initialized
INFO - 2016-05-07 21:41:46 --> Loader Class Initialized
INFO - 2016-05-07 21:41:46 --> Helper loaded: url_helper
INFO - 2016-05-07 21:41:46 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:41:46 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:41:46 --> Helper loaded: form_helper
INFO - 2016-05-07 21:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:41:46 --> Form Validation Class Initialized
INFO - 2016-05-07 21:41:46 --> Controller Class Initialized
INFO - 2016-05-07 21:41:46 --> Model Class Initialized
INFO - 2016-05-07 21:41:46 --> Database Driver Class Initialized
INFO - 2016-05-07 21:41:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:41:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:41:46 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:41:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:41:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 21:41:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:41:46 --> Final output sent to browser
DEBUG - 2016-05-07 21:41:46 --> Total execution time: 0.1416
INFO - 2016-05-07 21:41:47 --> Config Class Initialized
INFO - 2016-05-07 21:41:47 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:41:47 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:41:47 --> Utf8 Class Initialized
INFO - 2016-05-07 21:41:47 --> URI Class Initialized
INFO - 2016-05-07 21:41:47 --> Router Class Initialized
INFO - 2016-05-07 21:41:47 --> Output Class Initialized
INFO - 2016-05-07 21:41:47 --> Security Class Initialized
DEBUG - 2016-05-07 21:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:41:47 --> Input Class Initialized
INFO - 2016-05-07 21:41:47 --> Language Class Initialized
INFO - 2016-05-07 21:41:47 --> Loader Class Initialized
INFO - 2016-05-07 21:41:47 --> Helper loaded: url_helper
INFO - 2016-05-07 21:41:47 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:41:47 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:41:47 --> Helper loaded: form_helper
INFO - 2016-05-07 21:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:41:47 --> Form Validation Class Initialized
INFO - 2016-05-07 21:41:47 --> Controller Class Initialized
INFO - 2016-05-07 21:41:47 --> Model Class Initialized
INFO - 2016-05-07 21:41:47 --> Database Driver Class Initialized
INFO - 2016-05-07 21:41:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:41:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:41:47 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:41:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:41:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 21:41:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:41:47 --> Final output sent to browser
DEBUG - 2016-05-07 21:41:47 --> Total execution time: 0.0725
INFO - 2016-05-07 21:42:23 --> Config Class Initialized
INFO - 2016-05-07 21:42:23 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:42:23 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:42:23 --> Utf8 Class Initialized
INFO - 2016-05-07 21:42:23 --> URI Class Initialized
INFO - 2016-05-07 21:42:23 --> Router Class Initialized
INFO - 2016-05-07 21:42:23 --> Output Class Initialized
INFO - 2016-05-07 21:42:23 --> Security Class Initialized
DEBUG - 2016-05-07 21:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:42:23 --> Input Class Initialized
INFO - 2016-05-07 21:42:23 --> Language Class Initialized
INFO - 2016-05-07 21:42:23 --> Loader Class Initialized
INFO - 2016-05-07 21:42:23 --> Helper loaded: url_helper
INFO - 2016-05-07 21:42:23 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:42:23 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:42:23 --> Helper loaded: form_helper
INFO - 2016-05-07 21:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:42:23 --> Form Validation Class Initialized
INFO - 2016-05-07 21:42:23 --> Controller Class Initialized
INFO - 2016-05-07 21:42:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-07 21:42:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:42:23 --> Final output sent to browser
DEBUG - 2016-05-07 21:42:23 --> Total execution time: 0.1070
INFO - 2016-05-07 21:42:28 --> Config Class Initialized
INFO - 2016-05-07 21:42:28 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:42:28 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:42:28 --> Utf8 Class Initialized
INFO - 2016-05-07 21:42:28 --> URI Class Initialized
INFO - 2016-05-07 21:42:28 --> Router Class Initialized
INFO - 2016-05-07 21:42:28 --> Output Class Initialized
INFO - 2016-05-07 21:42:28 --> Security Class Initialized
DEBUG - 2016-05-07 21:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:42:28 --> Input Class Initialized
INFO - 2016-05-07 21:42:28 --> Language Class Initialized
INFO - 2016-05-07 21:42:28 --> Loader Class Initialized
INFO - 2016-05-07 21:42:28 --> Helper loaded: url_helper
INFO - 2016-05-07 21:42:28 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:42:28 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:42:28 --> Helper loaded: form_helper
INFO - 2016-05-07 21:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:42:28 --> Form Validation Class Initialized
INFO - 2016-05-07 21:42:28 --> Controller Class Initialized
INFO - 2016-05-07 21:42:28 --> Model Class Initialized
INFO - 2016-05-07 21:42:28 --> Database Driver Class Initialized
INFO - 2016-05-07 21:42:28 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:42:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:42:28 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:42:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:42:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 21:42:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:42:28 --> Final output sent to browser
DEBUG - 2016-05-07 21:42:28 --> Total execution time: 0.0965
INFO - 2016-05-07 21:56:53 --> Config Class Initialized
INFO - 2016-05-07 21:56:53 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:56:53 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:56:53 --> Utf8 Class Initialized
INFO - 2016-05-07 21:56:53 --> URI Class Initialized
INFO - 2016-05-07 21:56:53 --> Router Class Initialized
INFO - 2016-05-07 21:56:53 --> Output Class Initialized
INFO - 2016-05-07 21:56:53 --> Security Class Initialized
DEBUG - 2016-05-07 21:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:56:53 --> Input Class Initialized
INFO - 2016-05-07 21:56:53 --> Language Class Initialized
INFO - 2016-05-07 21:56:53 --> Loader Class Initialized
INFO - 2016-05-07 21:56:53 --> Helper loaded: url_helper
INFO - 2016-05-07 21:56:53 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:56:53 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:56:53 --> Helper loaded: form_helper
INFO - 2016-05-07 21:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:56:53 --> Form Validation Class Initialized
INFO - 2016-05-07 21:56:53 --> Controller Class Initialized
INFO - 2016-05-07 21:56:53 --> Model Class Initialized
INFO - 2016-05-07 21:56:53 --> Database Driver Class Initialized
INFO - 2016-05-07 21:56:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:56:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:56:53 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:56:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:56:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 21:56:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:56:53 --> Final output sent to browser
DEBUG - 2016-05-07 21:56:53 --> Total execution time: 0.0854
INFO - 2016-05-07 21:56:56 --> Config Class Initialized
INFO - 2016-05-07 21:56:56 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:56:56 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:56:56 --> Utf8 Class Initialized
INFO - 2016-05-07 21:56:56 --> URI Class Initialized
INFO - 2016-05-07 21:56:56 --> Router Class Initialized
INFO - 2016-05-07 21:56:56 --> Output Class Initialized
INFO - 2016-05-07 21:56:57 --> Security Class Initialized
DEBUG - 2016-05-07 21:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:56:57 --> Input Class Initialized
INFO - 2016-05-07 21:56:57 --> Language Class Initialized
INFO - 2016-05-07 21:56:57 --> Loader Class Initialized
INFO - 2016-05-07 21:56:57 --> Helper loaded: url_helper
INFO - 2016-05-07 21:56:57 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:56:57 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:56:57 --> Helper loaded: form_helper
INFO - 2016-05-07 21:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:56:57 --> Form Validation Class Initialized
INFO - 2016-05-07 21:56:57 --> Controller Class Initialized
INFO - 2016-05-07 21:56:57 --> Model Class Initialized
INFO - 2016-05-07 21:56:57 --> Database Driver Class Initialized
INFO - 2016-05-07 21:56:57 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:56:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:56:57 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:56:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:56:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 21:56:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:56:57 --> Final output sent to browser
DEBUG - 2016-05-07 21:56:57 --> Total execution time: 0.1822
INFO - 2016-05-07 21:57:01 --> Config Class Initialized
INFO - 2016-05-07 21:57:01 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:57:01 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:57:01 --> Utf8 Class Initialized
INFO - 2016-05-07 21:57:01 --> URI Class Initialized
INFO - 2016-05-07 21:57:01 --> Router Class Initialized
INFO - 2016-05-07 21:57:01 --> Output Class Initialized
INFO - 2016-05-07 21:57:01 --> Security Class Initialized
DEBUG - 2016-05-07 21:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:57:01 --> Input Class Initialized
INFO - 2016-05-07 21:57:01 --> Language Class Initialized
INFO - 2016-05-07 21:57:01 --> Loader Class Initialized
INFO - 2016-05-07 21:57:01 --> Helper loaded: url_helper
INFO - 2016-05-07 21:57:01 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:57:01 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:57:01 --> Helper loaded: form_helper
INFO - 2016-05-07 21:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:57:01 --> Form Validation Class Initialized
INFO - 2016-05-07 21:57:01 --> Controller Class Initialized
INFO - 2016-05-07 21:57:02 --> Model Class Initialized
INFO - 2016-05-07 21:57:02 --> Database Driver Class Initialized
INFO - 2016-05-07 21:57:02 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:57:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:57:02 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:57:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:57:02 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 21:57:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:57:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:57:02 --> Final output sent to browser
DEBUG - 2016-05-07 21:57:02 --> Total execution time: 0.1241
INFO - 2016-05-07 21:57:11 --> Config Class Initialized
INFO - 2016-05-07 21:57:11 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:57:11 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:57:11 --> Utf8 Class Initialized
INFO - 2016-05-07 21:57:11 --> URI Class Initialized
INFO - 2016-05-07 21:57:11 --> Router Class Initialized
INFO - 2016-05-07 21:57:11 --> Output Class Initialized
INFO - 2016-05-07 21:57:11 --> Security Class Initialized
DEBUG - 2016-05-07 21:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:57:11 --> Input Class Initialized
INFO - 2016-05-07 21:57:11 --> Language Class Initialized
INFO - 2016-05-07 21:57:11 --> Loader Class Initialized
INFO - 2016-05-07 21:57:11 --> Helper loaded: url_helper
INFO - 2016-05-07 21:57:11 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:57:11 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:57:11 --> Helper loaded: form_helper
INFO - 2016-05-07 21:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:57:11 --> Form Validation Class Initialized
INFO - 2016-05-07 21:57:11 --> Controller Class Initialized
INFO - 2016-05-07 21:57:11 --> Model Class Initialized
INFO - 2016-05-07 21:57:11 --> Database Driver Class Initialized
INFO - 2016-05-07 21:57:11 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:57:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:57:11 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:57:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:57:11 --> Image Lib Class Initialized
INFO - 2016-05-07 21:57:11 --> Language file loaded: language/spanish/imglib_lang.php
ERROR - 2016-05-07 21:57:11 --> The path to the image is not correct.
ERROR - 2016-05-07 21:57:11 --> Your server does not support the GD function required to process this type of image.
INFO - 2016-05-07 21:57:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:57:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:57:11 --> Final output sent to browser
DEBUG - 2016-05-07 21:57:11 --> Total execution time: 0.2083
INFO - 2016-05-07 21:59:13 --> Config Class Initialized
INFO - 2016-05-07 21:59:13 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:59:13 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:59:13 --> Utf8 Class Initialized
INFO - 2016-05-07 21:59:13 --> URI Class Initialized
INFO - 2016-05-07 21:59:13 --> Router Class Initialized
INFO - 2016-05-07 21:59:13 --> Output Class Initialized
INFO - 2016-05-07 21:59:13 --> Security Class Initialized
DEBUG - 2016-05-07 21:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:59:13 --> Input Class Initialized
INFO - 2016-05-07 21:59:13 --> Language Class Initialized
INFO - 2016-05-07 21:59:13 --> Loader Class Initialized
INFO - 2016-05-07 21:59:13 --> Helper loaded: url_helper
INFO - 2016-05-07 21:59:13 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:59:13 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:59:13 --> Helper loaded: form_helper
INFO - 2016-05-07 21:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:59:13 --> Form Validation Class Initialized
INFO - 2016-05-07 21:59:13 --> Controller Class Initialized
INFO - 2016-05-07 21:59:13 --> Model Class Initialized
INFO - 2016-05-07 21:59:13 --> Database Driver Class Initialized
INFO - 2016-05-07 21:59:13 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:59:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:59:13 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:59:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:59:13 --> Image Lib Class Initialized
INFO - 2016-05-07 21:59:13 --> Language file loaded: language/spanish/imglib_lang.php
ERROR - 2016-05-07 21:59:13 --> The path to the image is not correct.
ERROR - 2016-05-07 21:59:13 --> Your server does not support the GD function required to process this type of image.
INFO - 2016-05-07 21:59:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 21:59:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:59:13 --> Final output sent to browser
DEBUG - 2016-05-07 21:59:13 --> Total execution time: 0.2469
INFO - 2016-05-07 21:59:15 --> Config Class Initialized
INFO - 2016-05-07 21:59:15 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:59:15 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:59:15 --> Utf8 Class Initialized
INFO - 2016-05-07 21:59:15 --> URI Class Initialized
INFO - 2016-05-07 21:59:15 --> Router Class Initialized
INFO - 2016-05-07 21:59:15 --> Output Class Initialized
INFO - 2016-05-07 21:59:15 --> Security Class Initialized
DEBUG - 2016-05-07 21:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:59:15 --> Input Class Initialized
INFO - 2016-05-07 21:59:15 --> Language Class Initialized
INFO - 2016-05-07 21:59:15 --> Loader Class Initialized
INFO - 2016-05-07 21:59:15 --> Helper loaded: url_helper
INFO - 2016-05-07 21:59:15 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:59:15 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:59:15 --> Helper loaded: form_helper
INFO - 2016-05-07 21:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:59:15 --> Form Validation Class Initialized
INFO - 2016-05-07 21:59:15 --> Controller Class Initialized
INFO - 2016-05-07 21:59:15 --> Model Class Initialized
INFO - 2016-05-07 21:59:15 --> Database Driver Class Initialized
INFO - 2016-05-07 21:59:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:59:15 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:59:15 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:59:15 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:59:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 21:59:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:59:15 --> Final output sent to browser
DEBUG - 2016-05-07 21:59:15 --> Total execution time: 0.1079
INFO - 2016-05-07 21:59:17 --> Config Class Initialized
INFO - 2016-05-07 21:59:17 --> Hooks Class Initialized
DEBUG - 2016-05-07 21:59:17 --> UTF-8 Support Enabled
INFO - 2016-05-07 21:59:17 --> Utf8 Class Initialized
INFO - 2016-05-07 21:59:17 --> URI Class Initialized
INFO - 2016-05-07 21:59:17 --> Router Class Initialized
INFO - 2016-05-07 21:59:17 --> Output Class Initialized
INFO - 2016-05-07 21:59:17 --> Security Class Initialized
DEBUG - 2016-05-07 21:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 21:59:17 --> Input Class Initialized
INFO - 2016-05-07 21:59:17 --> Language Class Initialized
INFO - 2016-05-07 21:59:17 --> Loader Class Initialized
INFO - 2016-05-07 21:59:17 --> Helper loaded: url_helper
INFO - 2016-05-07 21:59:17 --> Helper loaded: sesion_helper
INFO - 2016-05-07 21:59:17 --> Helper loaded: templates_helper
INFO - 2016-05-07 21:59:17 --> Helper loaded: form_helper
INFO - 2016-05-07 21:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 21:59:17 --> Form Validation Class Initialized
INFO - 2016-05-07 21:59:17 --> Controller Class Initialized
INFO - 2016-05-07 21:59:17 --> Model Class Initialized
INFO - 2016-05-07 21:59:17 --> Database Driver Class Initialized
INFO - 2016-05-07 21:59:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 21:59:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 21:59:17 --> Pagination Class Initialized
DEBUG - 2016-05-07 21:59:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 21:59:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 21:59:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 21:59:17 --> Final output sent to browser
DEBUG - 2016-05-07 21:59:17 --> Total execution time: 0.1543
INFO - 2016-05-07 22:00:37 --> Config Class Initialized
INFO - 2016-05-07 22:00:37 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:00:37 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:00:37 --> Utf8 Class Initialized
INFO - 2016-05-07 22:00:37 --> URI Class Initialized
INFO - 2016-05-07 22:00:37 --> Router Class Initialized
INFO - 2016-05-07 22:00:37 --> Output Class Initialized
INFO - 2016-05-07 22:00:37 --> Security Class Initialized
DEBUG - 2016-05-07 22:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:00:37 --> Input Class Initialized
INFO - 2016-05-07 22:00:37 --> Language Class Initialized
INFO - 2016-05-07 22:00:37 --> Loader Class Initialized
INFO - 2016-05-07 22:00:37 --> Helper loaded: url_helper
INFO - 2016-05-07 22:00:37 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:00:37 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:00:37 --> Helper loaded: form_helper
INFO - 2016-05-07 22:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:00:37 --> Form Validation Class Initialized
INFO - 2016-05-07 22:00:37 --> Controller Class Initialized
INFO - 2016-05-07 22:00:37 --> Model Class Initialized
INFO - 2016-05-07 22:00:37 --> Database Driver Class Initialized
INFO - 2016-05-07 22:00:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:00:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:00:37 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:00:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:00:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 22:00:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:00:37 --> Final output sent to browser
DEBUG - 2016-05-07 22:00:37 --> Total execution time: 0.1557
INFO - 2016-05-07 22:00:39 --> Config Class Initialized
INFO - 2016-05-07 22:00:39 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:00:39 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:00:39 --> Utf8 Class Initialized
INFO - 2016-05-07 22:00:39 --> URI Class Initialized
INFO - 2016-05-07 22:00:39 --> Router Class Initialized
INFO - 2016-05-07 22:00:39 --> Output Class Initialized
INFO - 2016-05-07 22:00:39 --> Security Class Initialized
DEBUG - 2016-05-07 22:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:00:39 --> Input Class Initialized
INFO - 2016-05-07 22:00:39 --> Language Class Initialized
INFO - 2016-05-07 22:00:39 --> Loader Class Initialized
INFO - 2016-05-07 22:00:39 --> Helper loaded: url_helper
INFO - 2016-05-07 22:00:39 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:00:39 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:00:39 --> Helper loaded: form_helper
INFO - 2016-05-07 22:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:00:39 --> Form Validation Class Initialized
INFO - 2016-05-07 22:00:39 --> Controller Class Initialized
INFO - 2016-05-07 22:00:39 --> Model Class Initialized
INFO - 2016-05-07 22:00:40 --> Database Driver Class Initialized
INFO - 2016-05-07 22:00:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:00:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:00:40 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:00:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:00:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-07 22:00:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:00:40 --> Final output sent to browser
DEBUG - 2016-05-07 22:00:40 --> Total execution time: 0.1193
INFO - 2016-05-07 22:00:43 --> Config Class Initialized
INFO - 2016-05-07 22:00:43 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:00:43 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:00:43 --> Utf8 Class Initialized
INFO - 2016-05-07 22:00:43 --> URI Class Initialized
INFO - 2016-05-07 22:00:43 --> Router Class Initialized
INFO - 2016-05-07 22:00:43 --> Output Class Initialized
INFO - 2016-05-07 22:00:43 --> Security Class Initialized
DEBUG - 2016-05-07 22:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:00:43 --> Input Class Initialized
INFO - 2016-05-07 22:00:43 --> Language Class Initialized
INFO - 2016-05-07 22:00:43 --> Loader Class Initialized
INFO - 2016-05-07 22:00:43 --> Helper loaded: url_helper
INFO - 2016-05-07 22:00:43 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:00:43 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:00:43 --> Helper loaded: form_helper
INFO - 2016-05-07 22:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:00:43 --> Form Validation Class Initialized
INFO - 2016-05-07 22:00:43 --> Controller Class Initialized
INFO - 2016-05-07 22:00:43 --> Model Class Initialized
INFO - 2016-05-07 22:00:43 --> Database Driver Class Initialized
INFO - 2016-05-07 22:00:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:00:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:00:43 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:00:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:00:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 22:00:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:00:43 --> Final output sent to browser
DEBUG - 2016-05-07 22:00:43 --> Total execution time: 0.0967
INFO - 2016-05-07 22:00:51 --> Config Class Initialized
INFO - 2016-05-07 22:00:51 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:00:51 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:00:51 --> Utf8 Class Initialized
INFO - 2016-05-07 22:00:51 --> URI Class Initialized
INFO - 2016-05-07 22:00:51 --> Router Class Initialized
INFO - 2016-05-07 22:00:51 --> Output Class Initialized
INFO - 2016-05-07 22:00:51 --> Security Class Initialized
DEBUG - 2016-05-07 22:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:00:51 --> Input Class Initialized
INFO - 2016-05-07 22:00:51 --> Language Class Initialized
INFO - 2016-05-07 22:00:51 --> Loader Class Initialized
INFO - 2016-05-07 22:00:51 --> Helper loaded: url_helper
INFO - 2016-05-07 22:00:51 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:00:51 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:00:51 --> Helper loaded: form_helper
INFO - 2016-05-07 22:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:00:51 --> Form Validation Class Initialized
INFO - 2016-05-07 22:00:51 --> Controller Class Initialized
INFO - 2016-05-07 22:00:51 --> Model Class Initialized
INFO - 2016-05-07 22:00:51 --> Database Driver Class Initialized
INFO - 2016-05-07 22:00:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:00:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:00:51 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:00:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:00:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-07 22:00:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:00:51 --> Final output sent to browser
DEBUG - 2016-05-07 22:00:51 --> Total execution time: 0.1213
INFO - 2016-05-07 22:00:53 --> Config Class Initialized
INFO - 2016-05-07 22:00:53 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:00:53 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:00:53 --> Utf8 Class Initialized
INFO - 2016-05-07 22:00:53 --> URI Class Initialized
INFO - 2016-05-07 22:00:53 --> Router Class Initialized
INFO - 2016-05-07 22:00:53 --> Output Class Initialized
INFO - 2016-05-07 22:00:53 --> Security Class Initialized
DEBUG - 2016-05-07 22:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:00:53 --> Input Class Initialized
INFO - 2016-05-07 22:00:53 --> Language Class Initialized
INFO - 2016-05-07 22:00:53 --> Loader Class Initialized
INFO - 2016-05-07 22:00:53 --> Helper loaded: url_helper
INFO - 2016-05-07 22:00:53 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:00:53 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:00:53 --> Helper loaded: form_helper
INFO - 2016-05-07 22:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:00:53 --> Form Validation Class Initialized
INFO - 2016-05-07 22:00:53 --> Controller Class Initialized
INFO - 2016-05-07 22:00:53 --> Model Class Initialized
INFO - 2016-05-07 22:00:53 --> Database Driver Class Initialized
INFO - 2016-05-07 22:00:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:00:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:00:53 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:00:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:00:53 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-07 22:00:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 22:00:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:00:53 --> Final output sent to browser
DEBUG - 2016-05-07 22:00:53 --> Total execution time: 0.1510
INFO - 2016-05-07 22:01:10 --> Config Class Initialized
INFO - 2016-05-07 22:01:10 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:01:10 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:01:10 --> Utf8 Class Initialized
INFO - 2016-05-07 22:01:10 --> URI Class Initialized
INFO - 2016-05-07 22:01:10 --> Router Class Initialized
INFO - 2016-05-07 22:01:10 --> Output Class Initialized
INFO - 2016-05-07 22:01:10 --> Security Class Initialized
DEBUG - 2016-05-07 22:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:01:10 --> Input Class Initialized
INFO - 2016-05-07 22:01:10 --> Language Class Initialized
INFO - 2016-05-07 22:01:10 --> Loader Class Initialized
INFO - 2016-05-07 22:01:10 --> Helper loaded: url_helper
INFO - 2016-05-07 22:01:10 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:01:10 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:01:10 --> Helper loaded: form_helper
INFO - 2016-05-07 22:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:01:10 --> Form Validation Class Initialized
INFO - 2016-05-07 22:01:10 --> Controller Class Initialized
INFO - 2016-05-07 22:01:10 --> Model Class Initialized
INFO - 2016-05-07 22:01:10 --> Database Driver Class Initialized
INFO - 2016-05-07 22:01:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:01:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:01:10 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:01:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:01:10 --> Image Lib Class Initialized
INFO - 2016-05-07 22:01:10 --> Language file loaded: language/spanish/imglib_lang.php
ERROR - 2016-05-07 22:01:10 --> The path to the image is not correct.
ERROR - 2016-05-07 22:01:10 --> Your server does not support the GD function required to process this type of image.
INFO - 2016-05-07 22:01:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 22:01:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:01:10 --> Final output sent to browser
DEBUG - 2016-05-07 22:01:10 --> Total execution time: 0.1935
INFO - 2016-05-07 22:04:49 --> Config Class Initialized
INFO - 2016-05-07 22:04:49 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:04:49 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:04:49 --> Utf8 Class Initialized
INFO - 2016-05-07 22:04:49 --> URI Class Initialized
INFO - 2016-05-07 22:04:49 --> Router Class Initialized
INFO - 2016-05-07 22:04:49 --> Output Class Initialized
INFO - 2016-05-07 22:04:49 --> Security Class Initialized
DEBUG - 2016-05-07 22:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:04:49 --> Input Class Initialized
INFO - 2016-05-07 22:04:49 --> Language Class Initialized
INFO - 2016-05-07 22:04:49 --> Loader Class Initialized
INFO - 2016-05-07 22:04:49 --> Helper loaded: url_helper
INFO - 2016-05-07 22:04:49 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:04:49 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:04:49 --> Helper loaded: form_helper
INFO - 2016-05-07 22:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:04:49 --> Form Validation Class Initialized
INFO - 2016-05-07 22:04:49 --> Controller Class Initialized
INFO - 2016-05-07 22:04:49 --> Model Class Initialized
INFO - 2016-05-07 22:04:49 --> Database Driver Class Initialized
INFO - 2016-05-07 22:04:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:04:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:04:49 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:04:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:04:49 --> Image Lib Class Initialized
INFO - 2016-05-07 22:04:49 --> Language file loaded: language/spanish/imglib_lang.php
ERROR - 2016-05-07 22:04:49 --> The path to the image is not correct.
ERROR - 2016-05-07 22:04:49 --> Your server does not support the GD function required to process this type of image.
INFO - 2016-05-07 22:04:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 22:04:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:04:49 --> Final output sent to browser
DEBUG - 2016-05-07 22:04:49 --> Total execution time: 0.1833
INFO - 2016-05-07 22:05:09 --> Config Class Initialized
INFO - 2016-05-07 22:05:09 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:05:09 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:05:09 --> Utf8 Class Initialized
INFO - 2016-05-07 22:05:09 --> URI Class Initialized
INFO - 2016-05-07 22:05:09 --> Router Class Initialized
INFO - 2016-05-07 22:05:09 --> Output Class Initialized
INFO - 2016-05-07 22:05:09 --> Security Class Initialized
DEBUG - 2016-05-07 22:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:05:09 --> Input Class Initialized
INFO - 2016-05-07 22:05:09 --> Language Class Initialized
INFO - 2016-05-07 22:05:09 --> Loader Class Initialized
INFO - 2016-05-07 22:05:09 --> Helper loaded: url_helper
INFO - 2016-05-07 22:05:09 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:05:09 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:05:09 --> Helper loaded: form_helper
INFO - 2016-05-07 22:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:05:09 --> Form Validation Class Initialized
INFO - 2016-05-07 22:05:09 --> Controller Class Initialized
INFO - 2016-05-07 22:05:09 --> Model Class Initialized
INFO - 2016-05-07 22:05:09 --> Database Driver Class Initialized
INFO - 2016-05-07 22:05:09 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:05:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:05:09 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:05:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:05:09 --> Image Lib Class Initialized
INFO - 2016-05-07 22:05:09 --> Language file loaded: language/spanish/imglib_lang.php
ERROR - 2016-05-07 22:05:09 --> The path to the image is not correct.
ERROR - 2016-05-07 22:05:09 --> Your server does not support the GD function required to process this type of image.
INFO - 2016-05-07 22:05:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 22:05:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:05:09 --> Final output sent to browser
DEBUG - 2016-05-07 22:05:09 --> Total execution time: 0.2490
INFO - 2016-05-07 22:06:16 --> Config Class Initialized
INFO - 2016-05-07 22:06:16 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:06:16 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:06:16 --> Utf8 Class Initialized
INFO - 2016-05-07 22:06:16 --> URI Class Initialized
INFO - 2016-05-07 22:06:16 --> Router Class Initialized
INFO - 2016-05-07 22:06:16 --> Output Class Initialized
INFO - 2016-05-07 22:06:16 --> Security Class Initialized
DEBUG - 2016-05-07 22:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:06:16 --> Input Class Initialized
INFO - 2016-05-07 22:06:16 --> Language Class Initialized
INFO - 2016-05-07 22:06:16 --> Loader Class Initialized
INFO - 2016-05-07 22:06:16 --> Helper loaded: url_helper
INFO - 2016-05-07 22:06:16 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:06:16 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:06:16 --> Helper loaded: form_helper
INFO - 2016-05-07 22:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:06:16 --> Form Validation Class Initialized
INFO - 2016-05-07 22:06:16 --> Controller Class Initialized
INFO - 2016-05-07 22:06:16 --> Model Class Initialized
INFO - 2016-05-07 22:06:16 --> Database Driver Class Initialized
INFO - 2016-05-07 22:06:16 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:06:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:06:16 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:06:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:06:16 --> Image Lib Class Initialized
INFO - 2016-05-07 22:06:16 --> Language file loaded: language/spanish/imglib_lang.php
ERROR - 2016-05-07 22:06:16 --> The path to the image is not correct.
ERROR - 2016-05-07 22:06:16 --> Your server does not support the GD function required to process this type of image.
INFO - 2016-05-07 22:06:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 22:06:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:06:16 --> Final output sent to browser
DEBUG - 2016-05-07 22:06:16 --> Total execution time: 0.1813
INFO - 2016-05-07 22:06:27 --> Config Class Initialized
INFO - 2016-05-07 22:06:27 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:06:27 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:06:27 --> Utf8 Class Initialized
INFO - 2016-05-07 22:06:27 --> URI Class Initialized
INFO - 2016-05-07 22:06:27 --> Router Class Initialized
INFO - 2016-05-07 22:06:27 --> Output Class Initialized
INFO - 2016-05-07 22:06:27 --> Security Class Initialized
DEBUG - 2016-05-07 22:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:06:27 --> Input Class Initialized
INFO - 2016-05-07 22:06:27 --> Language Class Initialized
INFO - 2016-05-07 22:06:27 --> Loader Class Initialized
INFO - 2016-05-07 22:06:27 --> Helper loaded: url_helper
INFO - 2016-05-07 22:06:27 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:06:27 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:06:27 --> Helper loaded: form_helper
INFO - 2016-05-07 22:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:06:27 --> Form Validation Class Initialized
INFO - 2016-05-07 22:06:27 --> Controller Class Initialized
INFO - 2016-05-07 22:06:27 --> Model Class Initialized
INFO - 2016-05-07 22:06:27 --> Database Driver Class Initialized
INFO - 2016-05-07 22:06:27 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:06:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:06:27 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:06:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:06:27 --> Image Lib Class Initialized
INFO - 2016-05-07 22:06:27 --> Language file loaded: language/spanish/imglib_lang.php
ERROR - 2016-05-07 22:06:27 --> The path to the image is not correct.
ERROR - 2016-05-07 22:06:27 --> Your server does not support the GD function required to process this type of image.
INFO - 2016-05-07 22:06:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 22:06:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:06:27 --> Final output sent to browser
DEBUG - 2016-05-07 22:06:27 --> Total execution time: 0.1854
INFO - 2016-05-07 22:06:46 --> Config Class Initialized
INFO - 2016-05-07 22:06:46 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:06:46 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:06:46 --> Utf8 Class Initialized
INFO - 2016-05-07 22:06:46 --> URI Class Initialized
INFO - 2016-05-07 22:06:46 --> Router Class Initialized
INFO - 2016-05-07 22:06:46 --> Output Class Initialized
INFO - 2016-05-07 22:06:46 --> Security Class Initialized
DEBUG - 2016-05-07 22:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:06:46 --> Input Class Initialized
INFO - 2016-05-07 22:06:46 --> Language Class Initialized
INFO - 2016-05-07 22:06:46 --> Loader Class Initialized
INFO - 2016-05-07 22:06:46 --> Helper loaded: url_helper
INFO - 2016-05-07 22:06:46 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:06:46 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:06:46 --> Helper loaded: form_helper
INFO - 2016-05-07 22:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:06:46 --> Form Validation Class Initialized
INFO - 2016-05-07 22:06:46 --> Controller Class Initialized
INFO - 2016-05-07 22:06:46 --> Model Class Initialized
INFO - 2016-05-07 22:06:46 --> Database Driver Class Initialized
INFO - 2016-05-07 22:06:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:06:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:06:46 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:06:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 22:06:46 --> Severity: Notice --> Undefined property: Productos::$image_lib C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 324
ERROR - 2016-05-07 22:06:46 --> Severity: Error --> Call to a member function initialize() on a non-object C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 324
INFO - 2016-05-07 22:07:00 --> Config Class Initialized
INFO - 2016-05-07 22:07:00 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:07:00 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:07:00 --> Utf8 Class Initialized
INFO - 2016-05-07 22:07:00 --> URI Class Initialized
INFO - 2016-05-07 22:07:00 --> Router Class Initialized
INFO - 2016-05-07 22:07:00 --> Output Class Initialized
INFO - 2016-05-07 22:07:00 --> Security Class Initialized
DEBUG - 2016-05-07 22:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:07:00 --> Input Class Initialized
INFO - 2016-05-07 22:07:00 --> Language Class Initialized
INFO - 2016-05-07 22:07:00 --> Loader Class Initialized
INFO - 2016-05-07 22:07:00 --> Helper loaded: url_helper
INFO - 2016-05-07 22:07:00 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:07:00 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:07:00 --> Helper loaded: form_helper
INFO - 2016-05-07 22:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:07:00 --> Form Validation Class Initialized
INFO - 2016-05-07 22:07:00 --> Controller Class Initialized
INFO - 2016-05-07 22:07:00 --> Model Class Initialized
INFO - 2016-05-07 22:07:00 --> Database Driver Class Initialized
INFO - 2016-05-07 22:07:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:07:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:07:00 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:07:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:07:00 --> Image Lib Class Initialized
INFO - 2016-05-07 22:07:00 --> Language file loaded: language/spanish/imglib_lang.php
ERROR - 2016-05-07 22:07:00 --> The path to the image is not correct.
ERROR - 2016-05-07 22:07:00 --> Your server does not support the GD function required to process this type of image.
INFO - 2016-05-07 22:07:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 22:07:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:07:00 --> Final output sent to browser
DEBUG - 2016-05-07 22:07:00 --> Total execution time: 0.2528
INFO - 2016-05-07 22:07:21 --> Config Class Initialized
INFO - 2016-05-07 22:07:21 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:07:21 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:07:21 --> Utf8 Class Initialized
INFO - 2016-05-07 22:07:21 --> URI Class Initialized
INFO - 2016-05-07 22:07:21 --> Router Class Initialized
INFO - 2016-05-07 22:07:21 --> Output Class Initialized
INFO - 2016-05-07 22:07:21 --> Security Class Initialized
DEBUG - 2016-05-07 22:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:07:21 --> Input Class Initialized
INFO - 2016-05-07 22:07:21 --> Language Class Initialized
INFO - 2016-05-07 22:07:21 --> Loader Class Initialized
INFO - 2016-05-07 22:07:21 --> Helper loaded: url_helper
INFO - 2016-05-07 22:07:21 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:07:21 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:07:21 --> Helper loaded: form_helper
INFO - 2016-05-07 22:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:07:21 --> Form Validation Class Initialized
INFO - 2016-05-07 22:07:21 --> Controller Class Initialized
INFO - 2016-05-07 22:07:21 --> Model Class Initialized
INFO - 2016-05-07 22:07:21 --> Database Driver Class Initialized
INFO - 2016-05-07 22:07:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:07:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:07:21 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:07:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:07:21 --> Image Lib Class Initialized
INFO - 2016-05-07 22:07:21 --> Language file loaded: language/spanish/imglib_lang.php
ERROR - 2016-05-07 22:07:21 --> The path to the image is not correct.
ERROR - 2016-05-07 22:07:21 --> Your server does not support the GD function required to process this type of image.
INFO - 2016-05-07 22:07:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 22:07:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:07:21 --> Final output sent to browser
DEBUG - 2016-05-07 22:07:21 --> Total execution time: 0.2154
INFO - 2016-05-07 22:07:55 --> Config Class Initialized
INFO - 2016-05-07 22:07:55 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:07:55 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:07:55 --> Utf8 Class Initialized
INFO - 2016-05-07 22:07:55 --> URI Class Initialized
INFO - 2016-05-07 22:07:55 --> Router Class Initialized
INFO - 2016-05-07 22:07:55 --> Output Class Initialized
INFO - 2016-05-07 22:07:55 --> Security Class Initialized
DEBUG - 2016-05-07 22:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:07:55 --> Input Class Initialized
INFO - 2016-05-07 22:07:55 --> Language Class Initialized
INFO - 2016-05-07 22:07:55 --> Loader Class Initialized
INFO - 2016-05-07 22:07:55 --> Helper loaded: url_helper
INFO - 2016-05-07 22:07:55 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:07:55 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:07:55 --> Helper loaded: form_helper
INFO - 2016-05-07 22:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:07:55 --> Form Validation Class Initialized
INFO - 2016-05-07 22:07:55 --> Controller Class Initialized
INFO - 2016-05-07 22:07:55 --> Model Class Initialized
INFO - 2016-05-07 22:07:55 --> Database Driver Class Initialized
INFO - 2016-05-07 22:07:55 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:07:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:07:55 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:07:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:07:55 --> Image Lib Class Initialized
INFO - 2016-05-07 22:07:55 --> Language file loaded: language/spanish/imglib_lang.php
ERROR - 2016-05-07 22:07:55 --> The path to the image is not correct.
ERROR - 2016-05-07 22:07:55 --> Your server does not support the GD function required to process this type of image.
INFO - 2016-05-07 22:07:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 22:07:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:07:55 --> Final output sent to browser
DEBUG - 2016-05-07 22:07:55 --> Total execution time: 0.1841
INFO - 2016-05-07 22:08:32 --> Config Class Initialized
INFO - 2016-05-07 22:08:32 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:08:32 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:08:32 --> Utf8 Class Initialized
INFO - 2016-05-07 22:08:32 --> URI Class Initialized
INFO - 2016-05-07 22:08:32 --> Router Class Initialized
INFO - 2016-05-07 22:08:32 --> Output Class Initialized
INFO - 2016-05-07 22:08:32 --> Security Class Initialized
DEBUG - 2016-05-07 22:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:08:32 --> Input Class Initialized
INFO - 2016-05-07 22:08:32 --> Language Class Initialized
INFO - 2016-05-07 22:08:32 --> Loader Class Initialized
INFO - 2016-05-07 22:08:32 --> Helper loaded: url_helper
INFO - 2016-05-07 22:08:32 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:08:32 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:08:32 --> Helper loaded: form_helper
INFO - 2016-05-07 22:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:08:32 --> Form Validation Class Initialized
INFO - 2016-05-07 22:08:32 --> Controller Class Initialized
INFO - 2016-05-07 22:08:32 --> Model Class Initialized
INFO - 2016-05-07 22:08:32 --> Database Driver Class Initialized
INFO - 2016-05-07 22:08:32 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:08:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:08:32 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:08:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:08:32 --> Image Lib Class Initialized
INFO - 2016-05-07 22:08:32 --> Language file loaded: language/spanish/imglib_lang.php
ERROR - 2016-05-07 22:08:32 --> The path to the image is not correct.
ERROR - 2016-05-07 22:08:32 --> Your server does not support the GD function required to process this type of image.
INFO - 2016-05-07 22:08:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modImagenProducto.php
INFO - 2016-05-07 22:08:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:08:32 --> Final output sent to browser
DEBUG - 2016-05-07 22:08:32 --> Total execution time: 0.1980
INFO - 2016-05-07 22:10:13 --> Config Class Initialized
INFO - 2016-05-07 22:10:13 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:10:13 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:10:13 --> Utf8 Class Initialized
INFO - 2016-05-07 22:10:13 --> URI Class Initialized
INFO - 2016-05-07 22:10:13 --> Router Class Initialized
INFO - 2016-05-07 22:10:13 --> Output Class Initialized
INFO - 2016-05-07 22:10:13 --> Security Class Initialized
DEBUG - 2016-05-07 22:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:10:13 --> Input Class Initialized
INFO - 2016-05-07 22:10:13 --> Language Class Initialized
INFO - 2016-05-07 22:10:13 --> Loader Class Initialized
INFO - 2016-05-07 22:10:13 --> Helper loaded: url_helper
INFO - 2016-05-07 22:10:13 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:10:13 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:10:13 --> Helper loaded: form_helper
INFO - 2016-05-07 22:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:10:13 --> Form Validation Class Initialized
INFO - 2016-05-07 22:10:13 --> Controller Class Initialized
INFO - 2016-05-07 22:10:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-07 22:10:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:10:13 --> Final output sent to browser
DEBUG - 2016-05-07 22:10:13 --> Total execution time: 0.0507
INFO - 2016-05-07 22:16:10 --> Config Class Initialized
INFO - 2016-05-07 22:16:10 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:16:10 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:16:10 --> Utf8 Class Initialized
INFO - 2016-05-07 22:16:10 --> URI Class Initialized
INFO - 2016-05-07 22:16:10 --> Router Class Initialized
INFO - 2016-05-07 22:16:10 --> Output Class Initialized
INFO - 2016-05-07 22:16:10 --> Security Class Initialized
DEBUG - 2016-05-07 22:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:16:10 --> Input Class Initialized
INFO - 2016-05-07 22:16:10 --> Language Class Initialized
INFO - 2016-05-07 22:16:10 --> Loader Class Initialized
INFO - 2016-05-07 22:16:10 --> Helper loaded: url_helper
INFO - 2016-05-07 22:16:10 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:16:10 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:16:10 --> Helper loaded: form_helper
INFO - 2016-05-07 22:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:16:10 --> Form Validation Class Initialized
INFO - 2016-05-07 22:16:10 --> Controller Class Initialized
INFO - 2016-05-07 22:16:10 --> Model Class Initialized
INFO - 2016-05-07 22:16:10 --> Database Driver Class Initialized
INFO - 2016-05-07 22:16:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:16:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:16:10 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:16:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:16:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 22:16:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:16:10 --> Final output sent to browser
DEBUG - 2016-05-07 22:16:10 --> Total execution time: 0.1251
INFO - 2016-05-07 22:23:27 --> Config Class Initialized
INFO - 2016-05-07 22:23:27 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:23:27 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:23:27 --> Utf8 Class Initialized
INFO - 2016-05-07 22:23:27 --> URI Class Initialized
INFO - 2016-05-07 22:23:27 --> Router Class Initialized
INFO - 2016-05-07 22:23:27 --> Output Class Initialized
INFO - 2016-05-07 22:23:27 --> Security Class Initialized
DEBUG - 2016-05-07 22:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:23:27 --> Input Class Initialized
INFO - 2016-05-07 22:23:27 --> Language Class Initialized
INFO - 2016-05-07 22:23:27 --> Loader Class Initialized
INFO - 2016-05-07 22:23:27 --> Helper loaded: url_helper
INFO - 2016-05-07 22:23:27 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:23:27 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:23:27 --> Helper loaded: form_helper
INFO - 2016-05-07 22:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:23:27 --> Form Validation Class Initialized
INFO - 2016-05-07 22:23:27 --> Controller Class Initialized
INFO - 2016-05-07 22:23:27 --> Model Class Initialized
INFO - 2016-05-07 22:23:27 --> Database Driver Class Initialized
INFO - 2016-05-07 22:23:27 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:23:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:23:27 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:23:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:23:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 22:23:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:23:27 --> Final output sent to browser
DEBUG - 2016-05-07 22:23:27 --> Total execution time: 0.0814
INFO - 2016-05-07 22:23:36 --> Config Class Initialized
INFO - 2016-05-07 22:23:36 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:23:36 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:23:36 --> Utf8 Class Initialized
INFO - 2016-05-07 22:23:36 --> URI Class Initialized
INFO - 2016-05-07 22:23:36 --> Router Class Initialized
INFO - 2016-05-07 22:23:36 --> Output Class Initialized
INFO - 2016-05-07 22:23:36 --> Security Class Initialized
DEBUG - 2016-05-07 22:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:23:36 --> Input Class Initialized
INFO - 2016-05-07 22:23:36 --> Language Class Initialized
INFO - 2016-05-07 22:23:36 --> Loader Class Initialized
INFO - 2016-05-07 22:23:36 --> Helper loaded: url_helper
INFO - 2016-05-07 22:23:36 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:23:36 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:23:36 --> Helper loaded: form_helper
INFO - 2016-05-07 22:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:23:36 --> Form Validation Class Initialized
INFO - 2016-05-07 22:23:36 --> Controller Class Initialized
INFO - 2016-05-07 22:23:36 --> Model Class Initialized
INFO - 2016-05-07 22:23:36 --> Database Driver Class Initialized
INFO - 2016-05-07 22:23:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:23:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:23:36 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:23:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 22:23:36 --> Query error: Unknown column 'referencia' in 'where clause' - Invalid query: SELECT count(*) 'cont' FROM proveedor WHERE referencia LIKE '%smartphones%' OR nombre LIKE '%smartphones%' OR marca LIKE '%smartphones%' OR precio LIKE '%smartphones%' OR precio_venta LIKE '%smartphones%' OR iva LIKE '%smartphones%' OR stock LIKE '%smartphones%' OR descripcion LIKE '%smartphones%' OR estado LIKE '%smartphones%' OR idProveedor = (select idProveedor from proveedor where nombre LIKE 'smartphones') OR idCategoria = (select idCategoria from categoria where nombre LIKE 'smartphones')
INFO - 2016-05-07 22:23:36 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 22:23:50 --> Config Class Initialized
INFO - 2016-05-07 22:23:50 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:23:50 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:23:50 --> Utf8 Class Initialized
INFO - 2016-05-07 22:23:50 --> URI Class Initialized
INFO - 2016-05-07 22:23:50 --> Router Class Initialized
INFO - 2016-05-07 22:23:50 --> Output Class Initialized
INFO - 2016-05-07 22:23:50 --> Security Class Initialized
DEBUG - 2016-05-07 22:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:23:50 --> Input Class Initialized
INFO - 2016-05-07 22:23:50 --> Language Class Initialized
INFO - 2016-05-07 22:23:50 --> Loader Class Initialized
INFO - 2016-05-07 22:23:50 --> Helper loaded: url_helper
INFO - 2016-05-07 22:23:50 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:23:50 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:23:50 --> Helper loaded: form_helper
INFO - 2016-05-07 22:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:23:50 --> Form Validation Class Initialized
INFO - 2016-05-07 22:23:50 --> Controller Class Initialized
INFO - 2016-05-07 22:23:50 --> Model Class Initialized
INFO - 2016-05-07 22:23:50 --> Database Driver Class Initialized
INFO - 2016-05-07 22:23:50 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:23:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:23:50 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:23:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 22:23:50 --> Query error: Unknown column 'referencia' in 'where clause' - Invalid query: SELECT * FROM proveedor WHERE referencia LIKE '%smartphones%' OR nombre LIKE '%smartphones%' OR marca LIKE '%smartphones%' OR precio LIKE '%smartphones%' OR precio_venta LIKE '%smartphones%' OR iva LIKE '%smartphones%' OR stock LIKE '%smartphones%' OR descripcion LIKE '%smartphones%' OR estado LIKE '%smartphones%' OR idProveedor = (select idProveedor from proveedor where nombre LIKE 'smartphones') OR idCategoria = (select idCategoria from categoria where nombre LIKE 'smartphones')LIMIT 0, 5; 
INFO - 2016-05-07 22:23:50 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 22:23:52 --> Config Class Initialized
INFO - 2016-05-07 22:23:52 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:23:52 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:23:52 --> Utf8 Class Initialized
INFO - 2016-05-07 22:23:52 --> URI Class Initialized
INFO - 2016-05-07 22:23:52 --> Router Class Initialized
INFO - 2016-05-07 22:23:52 --> Output Class Initialized
INFO - 2016-05-07 22:23:52 --> Security Class Initialized
DEBUG - 2016-05-07 22:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:23:52 --> Input Class Initialized
INFO - 2016-05-07 22:23:52 --> Language Class Initialized
INFO - 2016-05-07 22:23:52 --> Loader Class Initialized
INFO - 2016-05-07 22:23:52 --> Helper loaded: url_helper
INFO - 2016-05-07 22:23:52 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:23:52 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:23:52 --> Helper loaded: form_helper
INFO - 2016-05-07 22:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:23:52 --> Form Validation Class Initialized
INFO - 2016-05-07 22:23:52 --> Controller Class Initialized
INFO - 2016-05-07 22:23:52 --> Model Class Initialized
INFO - 2016-05-07 22:23:52 --> Database Driver Class Initialized
INFO - 2016-05-07 22:23:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:23:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:23:52 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:23:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 22:23:52 --> Query error: Unknown column 'referencia' in 'where clause' - Invalid query: SELECT * FROM proveedor WHERE referencia LIKE '%smartphones%' OR nombre LIKE '%smartphones%' OR marca LIKE '%smartphones%' OR precio LIKE '%smartphones%' OR precio_venta LIKE '%smartphones%' OR iva LIKE '%smartphones%' OR stock LIKE '%smartphones%' OR descripcion LIKE '%smartphones%' OR estado LIKE '%smartphones%' OR idProveedor = (select idProveedor from proveedor where nombre LIKE 'smartphones') OR idCategoria = (select idCategoria from categoria where nombre LIKE 'smartphones')LIMIT 0, 5; 
INFO - 2016-05-07 22:23:52 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 22:23:54 --> Config Class Initialized
INFO - 2016-05-07 22:23:54 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:23:54 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:23:54 --> Utf8 Class Initialized
INFO - 2016-05-07 22:23:54 --> URI Class Initialized
INFO - 2016-05-07 22:23:54 --> Router Class Initialized
INFO - 2016-05-07 22:23:54 --> Output Class Initialized
INFO - 2016-05-07 22:23:54 --> Security Class Initialized
DEBUG - 2016-05-07 22:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:23:54 --> Input Class Initialized
INFO - 2016-05-07 22:23:54 --> Language Class Initialized
INFO - 2016-05-07 22:23:54 --> Loader Class Initialized
INFO - 2016-05-07 22:23:54 --> Helper loaded: url_helper
INFO - 2016-05-07 22:23:54 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:23:54 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:23:54 --> Helper loaded: form_helper
INFO - 2016-05-07 22:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:23:54 --> Form Validation Class Initialized
INFO - 2016-05-07 22:23:54 --> Controller Class Initialized
INFO - 2016-05-07 22:23:54 --> Model Class Initialized
INFO - 2016-05-07 22:23:54 --> Database Driver Class Initialized
INFO - 2016-05-07 22:23:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:23:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:23:54 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:23:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:23:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 22:23:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:23:54 --> Final output sent to browser
DEBUG - 2016-05-07 22:23:54 --> Total execution time: 0.0910
INFO - 2016-05-07 22:23:55 --> Config Class Initialized
INFO - 2016-05-07 22:23:55 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:23:55 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:23:55 --> Utf8 Class Initialized
INFO - 2016-05-07 22:23:55 --> URI Class Initialized
INFO - 2016-05-07 22:23:55 --> Router Class Initialized
INFO - 2016-05-07 22:23:55 --> Output Class Initialized
INFO - 2016-05-07 22:23:55 --> Security Class Initialized
DEBUG - 2016-05-07 22:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:23:55 --> Input Class Initialized
INFO - 2016-05-07 22:23:55 --> Language Class Initialized
INFO - 2016-05-07 22:23:55 --> Loader Class Initialized
INFO - 2016-05-07 22:23:55 --> Helper loaded: url_helper
INFO - 2016-05-07 22:23:55 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:23:55 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:23:55 --> Helper loaded: form_helper
INFO - 2016-05-07 22:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:23:55 --> Form Validation Class Initialized
INFO - 2016-05-07 22:23:55 --> Controller Class Initialized
INFO - 2016-05-07 22:23:55 --> Model Class Initialized
INFO - 2016-05-07 22:23:55 --> Database Driver Class Initialized
INFO - 2016-05-07 22:23:55 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:23:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:23:55 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:23:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:23:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 22:23:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:23:55 --> Final output sent to browser
DEBUG - 2016-05-07 22:23:55 --> Total execution time: 0.0991
INFO - 2016-05-07 22:23:59 --> Config Class Initialized
INFO - 2016-05-07 22:23:59 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:23:59 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:23:59 --> Utf8 Class Initialized
INFO - 2016-05-07 22:23:59 --> URI Class Initialized
INFO - 2016-05-07 22:23:59 --> Router Class Initialized
INFO - 2016-05-07 22:23:59 --> Output Class Initialized
INFO - 2016-05-07 22:23:59 --> Security Class Initialized
DEBUG - 2016-05-07 22:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:23:59 --> Input Class Initialized
INFO - 2016-05-07 22:23:59 --> Language Class Initialized
INFO - 2016-05-07 22:23:59 --> Loader Class Initialized
INFO - 2016-05-07 22:23:59 --> Helper loaded: url_helper
INFO - 2016-05-07 22:23:59 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:23:59 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:23:59 --> Helper loaded: form_helper
INFO - 2016-05-07 22:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:23:59 --> Form Validation Class Initialized
INFO - 2016-05-07 22:23:59 --> Controller Class Initialized
INFO - 2016-05-07 22:23:59 --> Model Class Initialized
INFO - 2016-05-07 22:23:59 --> Database Driver Class Initialized
INFO - 2016-05-07 22:23:59 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:23:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:23:59 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:23:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 22:23:59 --> Query error: Unknown column 'referencia' in 'where clause' - Invalid query: SELECT * FROM proveedor WHERE referencia LIKE '%smartphones%' OR nombre LIKE '%smartphones%' OR marca LIKE '%smartphones%' OR precio LIKE '%smartphones%' OR precio_venta LIKE '%smartphones%' OR iva LIKE '%smartphones%' OR stock LIKE '%smartphones%' OR descripcion LIKE '%smartphones%' OR estado LIKE '%smartphones%' OR idProveedor = (select idProveedor from proveedor where nombre LIKE 'smartphones') OR idCategoria = (select idCategoria from categoria where nombre LIKE 'smartphones')LIMIT 0, 5; 
INFO - 2016-05-07 22:23:59 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-07 22:24:12 --> Config Class Initialized
INFO - 2016-05-07 22:24:12 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:24:12 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:24:12 --> Utf8 Class Initialized
INFO - 2016-05-07 22:24:12 --> URI Class Initialized
INFO - 2016-05-07 22:24:12 --> Router Class Initialized
INFO - 2016-05-07 22:24:12 --> Output Class Initialized
INFO - 2016-05-07 22:24:12 --> Security Class Initialized
DEBUG - 2016-05-07 22:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:24:12 --> Input Class Initialized
INFO - 2016-05-07 22:24:12 --> Language Class Initialized
INFO - 2016-05-07 22:24:12 --> Loader Class Initialized
INFO - 2016-05-07 22:24:12 --> Helper loaded: url_helper
INFO - 2016-05-07 22:24:12 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:24:12 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:24:12 --> Helper loaded: form_helper
INFO - 2016-05-07 22:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:24:12 --> Form Validation Class Initialized
INFO - 2016-05-07 22:24:12 --> Controller Class Initialized
INFO - 2016-05-07 22:24:12 --> Model Class Initialized
INFO - 2016-05-07 22:24:12 --> Database Driver Class Initialized
INFO - 2016-05-07 22:24:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:24:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:24:12 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:24:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:24:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-07 22:24:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:24:12 --> Final output sent to browser
DEBUG - 2016-05-07 22:24:12 --> Total execution time: 0.2458
INFO - 2016-05-07 22:24:21 --> Config Class Initialized
INFO - 2016-05-07 22:24:21 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:24:21 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:24:21 --> Utf8 Class Initialized
INFO - 2016-05-07 22:24:21 --> URI Class Initialized
INFO - 2016-05-07 22:24:21 --> Router Class Initialized
INFO - 2016-05-07 22:24:21 --> Output Class Initialized
INFO - 2016-05-07 22:24:21 --> Security Class Initialized
DEBUG - 2016-05-07 22:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:24:21 --> Input Class Initialized
INFO - 2016-05-07 22:24:21 --> Language Class Initialized
INFO - 2016-05-07 22:24:21 --> Loader Class Initialized
INFO - 2016-05-07 22:24:21 --> Helper loaded: url_helper
INFO - 2016-05-07 22:24:21 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:24:21 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:24:21 --> Helper loaded: form_helper
INFO - 2016-05-07 22:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:24:21 --> Form Validation Class Initialized
INFO - 2016-05-07 22:24:21 --> Controller Class Initialized
INFO - 2016-05-07 22:24:21 --> Model Class Initialized
INFO - 2016-05-07 22:24:21 --> Database Driver Class Initialized
INFO - 2016-05-07 22:24:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:24:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:24:21 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:24:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:24:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 22:24:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:24:21 --> Final output sent to browser
DEBUG - 2016-05-07 22:24:21 --> Total execution time: 0.0901
INFO - 2016-05-07 22:24:28 --> Config Class Initialized
INFO - 2016-05-07 22:24:28 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:24:28 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:24:28 --> Utf8 Class Initialized
INFO - 2016-05-07 22:24:28 --> URI Class Initialized
INFO - 2016-05-07 22:24:28 --> Router Class Initialized
INFO - 2016-05-07 22:24:28 --> Output Class Initialized
INFO - 2016-05-07 22:24:28 --> Security Class Initialized
DEBUG - 2016-05-07 22:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:24:28 --> Input Class Initialized
INFO - 2016-05-07 22:24:28 --> Language Class Initialized
INFO - 2016-05-07 22:24:28 --> Loader Class Initialized
INFO - 2016-05-07 22:24:28 --> Helper loaded: url_helper
INFO - 2016-05-07 22:24:28 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:24:28 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:24:28 --> Helper loaded: form_helper
INFO - 2016-05-07 22:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:24:28 --> Form Validation Class Initialized
INFO - 2016-05-07 22:24:28 --> Controller Class Initialized
INFO - 2016-05-07 22:24:28 --> Model Class Initialized
INFO - 2016-05-07 22:24:28 --> Database Driver Class Initialized
INFO - 2016-05-07 22:24:28 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:24:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:24:28 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:24:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:24:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-07 22:24:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:24:28 --> Final output sent to browser
DEBUG - 2016-05-07 22:24:28 --> Total execution time: 0.0775
INFO - 2016-05-07 22:24:31 --> Config Class Initialized
INFO - 2016-05-07 22:24:31 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:24:31 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:24:31 --> Utf8 Class Initialized
INFO - 2016-05-07 22:24:31 --> URI Class Initialized
INFO - 2016-05-07 22:24:31 --> Router Class Initialized
INFO - 2016-05-07 22:24:31 --> Output Class Initialized
INFO - 2016-05-07 22:24:31 --> Security Class Initialized
DEBUG - 2016-05-07 22:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:24:31 --> Input Class Initialized
INFO - 2016-05-07 22:24:31 --> Language Class Initialized
INFO - 2016-05-07 22:24:31 --> Loader Class Initialized
INFO - 2016-05-07 22:24:31 --> Helper loaded: url_helper
INFO - 2016-05-07 22:24:31 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:24:31 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:24:31 --> Helper loaded: form_helper
INFO - 2016-05-07 22:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:24:31 --> Form Validation Class Initialized
INFO - 2016-05-07 22:24:31 --> Controller Class Initialized
INFO - 2016-05-07 22:24:31 --> Model Class Initialized
INFO - 2016-05-07 22:24:31 --> Database Driver Class Initialized
INFO - 2016-05-07 22:24:31 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:24:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:24:31 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:24:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:24:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 22:24:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:24:31 --> Final output sent to browser
DEBUG - 2016-05-07 22:24:31 --> Total execution time: 0.0926
INFO - 2016-05-07 22:24:36 --> Config Class Initialized
INFO - 2016-05-07 22:24:36 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:24:36 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:24:36 --> Utf8 Class Initialized
INFO - 2016-05-07 22:24:36 --> URI Class Initialized
INFO - 2016-05-07 22:24:36 --> Router Class Initialized
INFO - 2016-05-07 22:24:36 --> Output Class Initialized
INFO - 2016-05-07 22:24:36 --> Security Class Initialized
DEBUG - 2016-05-07 22:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:24:36 --> Input Class Initialized
INFO - 2016-05-07 22:24:36 --> Language Class Initialized
INFO - 2016-05-07 22:24:36 --> Loader Class Initialized
INFO - 2016-05-07 22:24:36 --> Helper loaded: url_helper
INFO - 2016-05-07 22:24:36 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:24:36 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:24:36 --> Helper loaded: form_helper
INFO - 2016-05-07 22:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:24:36 --> Form Validation Class Initialized
INFO - 2016-05-07 22:24:36 --> Controller Class Initialized
INFO - 2016-05-07 22:24:36 --> Model Class Initialized
INFO - 2016-05-07 22:24:36 --> Database Driver Class Initialized
INFO - 2016-05-07 22:24:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:24:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:24:36 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:24:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:24:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-07 22:24:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:24:36 --> Final output sent to browser
DEBUG - 2016-05-07 22:24:36 --> Total execution time: 0.0739
INFO - 2016-05-07 22:24:40 --> Config Class Initialized
INFO - 2016-05-07 22:24:40 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:24:40 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:24:40 --> Utf8 Class Initialized
INFO - 2016-05-07 22:24:40 --> URI Class Initialized
INFO - 2016-05-07 22:24:40 --> Router Class Initialized
INFO - 2016-05-07 22:24:40 --> Output Class Initialized
INFO - 2016-05-07 22:24:40 --> Security Class Initialized
DEBUG - 2016-05-07 22:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:24:40 --> Input Class Initialized
INFO - 2016-05-07 22:24:40 --> Language Class Initialized
INFO - 2016-05-07 22:24:40 --> Loader Class Initialized
INFO - 2016-05-07 22:24:40 --> Helper loaded: url_helper
INFO - 2016-05-07 22:24:40 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:24:40 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:24:40 --> Helper loaded: form_helper
INFO - 2016-05-07 22:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:24:40 --> Form Validation Class Initialized
INFO - 2016-05-07 22:24:40 --> Controller Class Initialized
INFO - 2016-05-07 22:24:40 --> Model Class Initialized
INFO - 2016-05-07 22:24:40 --> Database Driver Class Initialized
INFO - 2016-05-07 22:24:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:24:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:24:40 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:24:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:24:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 22:24:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:24:40 --> Final output sent to browser
DEBUG - 2016-05-07 22:24:40 --> Total execution time: 0.1511
INFO - 2016-05-07 22:25:37 --> Config Class Initialized
INFO - 2016-05-07 22:25:37 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:25:37 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:25:37 --> Utf8 Class Initialized
INFO - 2016-05-07 22:25:37 --> URI Class Initialized
INFO - 2016-05-07 22:25:37 --> Router Class Initialized
INFO - 2016-05-07 22:25:37 --> Output Class Initialized
INFO - 2016-05-07 22:25:37 --> Security Class Initialized
DEBUG - 2016-05-07 22:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:25:37 --> Input Class Initialized
INFO - 2016-05-07 22:25:37 --> Language Class Initialized
INFO - 2016-05-07 22:25:37 --> Loader Class Initialized
INFO - 2016-05-07 22:25:37 --> Helper loaded: url_helper
INFO - 2016-05-07 22:25:37 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:25:37 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:25:37 --> Helper loaded: form_helper
INFO - 2016-05-07 22:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:25:37 --> Form Validation Class Initialized
INFO - 2016-05-07 22:25:37 --> Controller Class Initialized
INFO - 2016-05-07 22:25:37 --> Model Class Initialized
INFO - 2016-05-07 22:25:37 --> Database Driver Class Initialized
INFO - 2016-05-07 22:25:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:25:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:25:37 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:25:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:25:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-07 22:25:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:25:37 --> Final output sent to browser
DEBUG - 2016-05-07 22:25:37 --> Total execution time: 0.0799
INFO - 2016-05-07 22:25:44 --> Config Class Initialized
INFO - 2016-05-07 22:25:44 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:25:44 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:25:44 --> Utf8 Class Initialized
INFO - 2016-05-07 22:25:44 --> URI Class Initialized
INFO - 2016-05-07 22:25:44 --> Router Class Initialized
INFO - 2016-05-07 22:25:44 --> Output Class Initialized
INFO - 2016-05-07 22:25:44 --> Security Class Initialized
DEBUG - 2016-05-07 22:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:25:44 --> Input Class Initialized
INFO - 2016-05-07 22:25:44 --> Language Class Initialized
INFO - 2016-05-07 22:25:44 --> Loader Class Initialized
INFO - 2016-05-07 22:25:44 --> Helper loaded: url_helper
INFO - 2016-05-07 22:25:44 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:25:44 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:25:44 --> Helper loaded: form_helper
INFO - 2016-05-07 22:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:25:44 --> Form Validation Class Initialized
INFO - 2016-05-07 22:25:44 --> Controller Class Initialized
INFO - 2016-05-07 22:25:44 --> Model Class Initialized
INFO - 2016-05-07 22:25:44 --> Database Driver Class Initialized
INFO - 2016-05-07 22:25:44 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:25:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:25:44 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:25:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-07 22:25:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-07 22:25:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-07 22:25:44 --> Final output sent to browser
DEBUG - 2016-05-07 22:25:44 --> Total execution time: 0.1149
INFO - 2016-05-07 22:27:08 --> Config Class Initialized
INFO - 2016-05-07 22:27:08 --> Hooks Class Initialized
DEBUG - 2016-05-07 22:27:08 --> UTF-8 Support Enabled
INFO - 2016-05-07 22:27:08 --> Utf8 Class Initialized
INFO - 2016-05-07 22:27:08 --> URI Class Initialized
INFO - 2016-05-07 22:27:08 --> Router Class Initialized
INFO - 2016-05-07 22:27:08 --> Output Class Initialized
INFO - 2016-05-07 22:27:08 --> Security Class Initialized
DEBUG - 2016-05-07 22:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-07 22:27:08 --> Input Class Initialized
INFO - 2016-05-07 22:27:08 --> Language Class Initialized
INFO - 2016-05-07 22:27:08 --> Loader Class Initialized
INFO - 2016-05-07 22:27:08 --> Helper loaded: url_helper
INFO - 2016-05-07 22:27:08 --> Helper loaded: sesion_helper
INFO - 2016-05-07 22:27:08 --> Helper loaded: templates_helper
INFO - 2016-05-07 22:27:08 --> Helper loaded: form_helper
INFO - 2016-05-07 22:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-07 22:27:08 --> Form Validation Class Initialized
INFO - 2016-05-07 22:27:08 --> Controller Class Initialized
INFO - 2016-05-07 22:27:08 --> Model Class Initialized
INFO - 2016-05-07 22:27:08 --> Database Driver Class Initialized
INFO - 2016-05-07 22:27:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-07 22:27:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-07 22:27:08 --> Pagination Class Initialized
DEBUG - 2016-05-07 22:27:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-07 22:27:08 --> Severity: Warning --> mysqli::query(): (21000/1242): Subquery returns more than 1 row C:\xampp\htdocs\Proyecto\Alumno\Fuentes\system\database\drivers\mysqli\mysqli_driver.php 264
ERROR - 2016-05-07 22:27:08 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT * FROM producto WHERE referencia LIKE '%ordenadores%' OR nombre LIKE '%ordenadores%' OR marca LIKE '%ordenadores%' OR precio LIKE '%ordenadores%' OR precio_venta LIKE '%ordenadores%' OR iva LIKE '%ordenadores%' OR stock LIKE '%ordenadores%' OR descripcion LIKE '%ordenadores%' OR estado LIKE '%ordenadores%' OR idProveedor = (select idProveedor from proveedor where nombre LIKE '%ordenadores%') OR idCategoria = (select idCategoria from categoria where nombre LIKE '%ordenadores%')LIMIT 0, 5; 
INFO - 2016-05-07 22:27:08 --> Language file loaded: language/spanish/db_lang.php
