<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-04 18:33:15 --> Config Class Initialized
INFO - 2016-05-04 18:33:15 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:33:15 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:33:15 --> Utf8 Class Initialized
INFO - 2016-05-04 18:33:15 --> URI Class Initialized
INFO - 2016-05-04 18:33:15 --> Router Class Initialized
INFO - 2016-05-04 18:33:15 --> Output Class Initialized
INFO - 2016-05-04 18:33:15 --> Security Class Initialized
DEBUG - 2016-05-04 18:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:33:15 --> Input Class Initialized
INFO - 2016-05-04 18:33:15 --> Language Class Initialized
INFO - 2016-05-04 18:33:15 --> Loader Class Initialized
INFO - 2016-05-04 18:33:15 --> Helper loaded: url_helper
INFO - 2016-05-04 18:33:15 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:33:15 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:33:15 --> Helper loaded: form_helper
INFO - 2016-05-04 18:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:33:15 --> Form Validation Class Initialized
INFO - 2016-05-04 18:33:15 --> Controller Class Initialized
INFO - 2016-05-04 18:33:15 --> Config Class Initialized
INFO - 2016-05-04 18:33:15 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:33:15 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:33:15 --> Utf8 Class Initialized
INFO - 2016-05-04 18:33:15 --> URI Class Initialized
INFO - 2016-05-04 18:33:15 --> Router Class Initialized
INFO - 2016-05-04 18:33:15 --> Output Class Initialized
INFO - 2016-05-04 18:33:15 --> Security Class Initialized
DEBUG - 2016-05-04 18:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:33:15 --> Input Class Initialized
INFO - 2016-05-04 18:33:15 --> Language Class Initialized
INFO - 2016-05-04 18:33:15 --> Loader Class Initialized
INFO - 2016-05-04 18:33:15 --> Helper loaded: url_helper
INFO - 2016-05-04 18:33:15 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:33:15 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:33:15 --> Helper loaded: form_helper
INFO - 2016-05-04 18:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:33:15 --> Form Validation Class Initialized
INFO - 2016-05-04 18:33:15 --> Controller Class Initialized
INFO - 2016-05-04 18:33:15 --> Model Class Initialized
INFO - 2016-05-04 18:33:15 --> Database Driver Class Initialized
INFO - 2016-05-04 18:33:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-04 18:33:15 --> Final output sent to browser
DEBUG - 2016-05-04 18:33:15 --> Total execution time: 0.0671
INFO - 2016-05-04 18:33:37 --> Config Class Initialized
INFO - 2016-05-04 18:33:37 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:33:37 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:33:37 --> Utf8 Class Initialized
INFO - 2016-05-04 18:33:37 --> URI Class Initialized
INFO - 2016-05-04 18:33:37 --> Router Class Initialized
INFO - 2016-05-04 18:33:37 --> Output Class Initialized
INFO - 2016-05-04 18:33:37 --> Security Class Initialized
DEBUG - 2016-05-04 18:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:33:37 --> Input Class Initialized
INFO - 2016-05-04 18:33:37 --> Language Class Initialized
INFO - 2016-05-04 18:33:37 --> Loader Class Initialized
INFO - 2016-05-04 18:33:37 --> Helper loaded: url_helper
INFO - 2016-05-04 18:33:37 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:33:37 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:33:37 --> Helper loaded: form_helper
INFO - 2016-05-04 18:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:33:37 --> Form Validation Class Initialized
INFO - 2016-05-04 18:33:37 --> Controller Class Initialized
INFO - 2016-05-04 18:33:37 --> Model Class Initialized
INFO - 2016-05-04 18:33:37 --> Database Driver Class Initialized
INFO - 2016-05-04 18:33:37 --> Config Class Initialized
INFO - 2016-05-04 18:33:37 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:33:37 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:33:37 --> Utf8 Class Initialized
INFO - 2016-05-04 18:33:37 --> URI Class Initialized
INFO - 2016-05-04 18:33:37 --> Router Class Initialized
INFO - 2016-05-04 18:33:37 --> Output Class Initialized
INFO - 2016-05-04 18:33:37 --> Security Class Initialized
DEBUG - 2016-05-04 18:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:33:37 --> Input Class Initialized
INFO - 2016-05-04 18:33:37 --> Language Class Initialized
INFO - 2016-05-04 18:33:37 --> Loader Class Initialized
INFO - 2016-05-04 18:33:37 --> Helper loaded: url_helper
INFO - 2016-05-04 18:33:37 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:33:37 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:33:37 --> Helper loaded: form_helper
INFO - 2016-05-04 18:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:33:37 --> Form Validation Class Initialized
INFO - 2016-05-04 18:33:37 --> Controller Class Initialized
INFO - 2016-05-04 18:33:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-04 18:33:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:33:37 --> Final output sent to browser
DEBUG - 2016-05-04 18:33:37 --> Total execution time: 0.0523
INFO - 2016-05-04 18:33:47 --> Config Class Initialized
INFO - 2016-05-04 18:33:47 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:33:47 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:33:47 --> Utf8 Class Initialized
INFO - 2016-05-04 18:33:47 --> URI Class Initialized
INFO - 2016-05-04 18:33:47 --> Router Class Initialized
INFO - 2016-05-04 18:33:47 --> Output Class Initialized
INFO - 2016-05-04 18:33:47 --> Security Class Initialized
DEBUG - 2016-05-04 18:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:33:47 --> Input Class Initialized
INFO - 2016-05-04 18:33:47 --> Language Class Initialized
INFO - 2016-05-04 18:33:47 --> Loader Class Initialized
INFO - 2016-05-04 18:33:47 --> Helper loaded: url_helper
INFO - 2016-05-04 18:33:47 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:33:47 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:33:47 --> Helper loaded: form_helper
INFO - 2016-05-04 18:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:33:47 --> Form Validation Class Initialized
INFO - 2016-05-04 18:33:47 --> Controller Class Initialized
INFO - 2016-05-04 18:33:47 --> Model Class Initialized
INFO - 2016-05-04 18:33:47 --> Database Driver Class Initialized
INFO - 2016-05-04 18:33:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:33:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:33:47 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:33:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:33:47 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:33:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:33:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:33:47 --> Final output sent to browser
DEBUG - 2016-05-04 18:33:47 --> Total execution time: 0.1711
INFO - 2016-05-04 18:33:56 --> Config Class Initialized
INFO - 2016-05-04 18:33:56 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:33:56 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:33:56 --> Utf8 Class Initialized
INFO - 2016-05-04 18:33:56 --> URI Class Initialized
INFO - 2016-05-04 18:33:56 --> Router Class Initialized
INFO - 2016-05-04 18:33:56 --> Output Class Initialized
INFO - 2016-05-04 18:33:56 --> Security Class Initialized
DEBUG - 2016-05-04 18:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:33:56 --> Input Class Initialized
INFO - 2016-05-04 18:33:56 --> Language Class Initialized
INFO - 2016-05-04 18:33:56 --> Loader Class Initialized
INFO - 2016-05-04 18:33:56 --> Helper loaded: url_helper
INFO - 2016-05-04 18:33:56 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:33:56 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:33:56 --> Helper loaded: form_helper
INFO - 2016-05-04 18:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:33:56 --> Form Validation Class Initialized
INFO - 2016-05-04 18:33:56 --> Controller Class Initialized
INFO - 2016-05-04 18:33:56 --> Model Class Initialized
INFO - 2016-05-04 18:33:56 --> Database Driver Class Initialized
INFO - 2016-05-04 18:33:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:33:56 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:33:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:33:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-04 18:33:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:33:56 --> Final output sent to browser
DEBUG - 2016-05-04 18:33:56 --> Total execution time: 0.1532
INFO - 2016-05-04 18:34:00 --> Config Class Initialized
INFO - 2016-05-04 18:34:00 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:34:00 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:34:00 --> Utf8 Class Initialized
INFO - 2016-05-04 18:34:00 --> URI Class Initialized
INFO - 2016-05-04 18:34:00 --> Router Class Initialized
INFO - 2016-05-04 18:34:00 --> Output Class Initialized
INFO - 2016-05-04 18:34:00 --> Security Class Initialized
DEBUG - 2016-05-04 18:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:34:00 --> Input Class Initialized
INFO - 2016-05-04 18:34:00 --> Language Class Initialized
INFO - 2016-05-04 18:34:00 --> Loader Class Initialized
INFO - 2016-05-04 18:34:00 --> Helper loaded: url_helper
INFO - 2016-05-04 18:34:00 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:34:00 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:34:00 --> Helper loaded: form_helper
INFO - 2016-05-04 18:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:34:00 --> Form Validation Class Initialized
INFO - 2016-05-04 18:34:00 --> Controller Class Initialized
INFO - 2016-05-04 18:34:00 --> Model Class Initialized
INFO - 2016-05-04 18:34:00 --> Database Driver Class Initialized
INFO - 2016-05-04 18:34:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:34:00 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:34:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:34:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-04 18:34:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:34:00 --> Final output sent to browser
DEBUG - 2016-05-04 18:34:00 --> Total execution time: 0.0754
INFO - 2016-05-04 18:34:11 --> Config Class Initialized
INFO - 2016-05-04 18:34:11 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:34:11 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:34:11 --> Utf8 Class Initialized
INFO - 2016-05-04 18:34:11 --> URI Class Initialized
INFO - 2016-05-04 18:34:11 --> Router Class Initialized
INFO - 2016-05-04 18:34:11 --> Output Class Initialized
INFO - 2016-05-04 18:34:11 --> Security Class Initialized
DEBUG - 2016-05-04 18:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:34:11 --> Input Class Initialized
INFO - 2016-05-04 18:34:11 --> Language Class Initialized
INFO - 2016-05-04 18:34:11 --> Loader Class Initialized
INFO - 2016-05-04 18:34:11 --> Helper loaded: url_helper
INFO - 2016-05-04 18:34:11 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:34:11 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:34:11 --> Helper loaded: form_helper
INFO - 2016-05-04 18:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:34:11 --> Form Validation Class Initialized
INFO - 2016-05-04 18:34:11 --> Controller Class Initialized
INFO - 2016-05-04 18:34:11 --> Model Class Initialized
INFO - 2016-05-04 18:34:11 --> Database Driver Class Initialized
INFO - 2016-05-04 18:34:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:34:11 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:34:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:34:11 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 18:34:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-04 18:34:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:34:11 --> Final output sent to browser
DEBUG - 2016-05-04 18:34:11 --> Total execution time: 0.1291
INFO - 2016-05-04 18:34:13 --> Config Class Initialized
INFO - 2016-05-04 18:34:13 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:34:13 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:34:13 --> Utf8 Class Initialized
INFO - 2016-05-04 18:34:13 --> URI Class Initialized
INFO - 2016-05-04 18:34:13 --> Router Class Initialized
INFO - 2016-05-04 18:34:13 --> Output Class Initialized
INFO - 2016-05-04 18:34:13 --> Security Class Initialized
DEBUG - 2016-05-04 18:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:34:13 --> Input Class Initialized
INFO - 2016-05-04 18:34:13 --> Language Class Initialized
INFO - 2016-05-04 18:34:13 --> Loader Class Initialized
INFO - 2016-05-04 18:34:13 --> Helper loaded: url_helper
INFO - 2016-05-04 18:34:13 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:34:13 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:34:13 --> Helper loaded: form_helper
INFO - 2016-05-04 18:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:34:13 --> Form Validation Class Initialized
INFO - 2016-05-04 18:34:13 --> Controller Class Initialized
INFO - 2016-05-04 18:34:13 --> Model Class Initialized
INFO - 2016-05-04 18:34:13 --> Database Driver Class Initialized
INFO - 2016-05-04 18:34:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:34:13 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:34:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:34:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-04 18:34:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:34:13 --> Final output sent to browser
DEBUG - 2016-05-04 18:34:13 --> Total execution time: 0.0806
INFO - 2016-05-04 18:34:15 --> Config Class Initialized
INFO - 2016-05-04 18:34:15 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:34:16 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:34:16 --> Utf8 Class Initialized
INFO - 2016-05-04 18:34:16 --> URI Class Initialized
INFO - 2016-05-04 18:34:16 --> Router Class Initialized
INFO - 2016-05-04 18:34:16 --> Output Class Initialized
INFO - 2016-05-04 18:34:16 --> Security Class Initialized
DEBUG - 2016-05-04 18:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:34:16 --> Input Class Initialized
INFO - 2016-05-04 18:34:16 --> Language Class Initialized
INFO - 2016-05-04 18:34:16 --> Loader Class Initialized
INFO - 2016-05-04 18:34:16 --> Helper loaded: url_helper
INFO - 2016-05-04 18:34:16 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:34:16 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:34:16 --> Helper loaded: form_helper
INFO - 2016-05-04 18:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:34:16 --> Form Validation Class Initialized
INFO - 2016-05-04 18:34:16 --> Controller Class Initialized
INFO - 2016-05-04 18:34:16 --> Model Class Initialized
INFO - 2016-05-04 18:34:16 --> Database Driver Class Initialized
INFO - 2016-05-04 18:34:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:34:16 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:34:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:34:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-04 18:34:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:34:16 --> Final output sent to browser
DEBUG - 2016-05-04 18:34:16 --> Total execution time: 0.0740
INFO - 2016-05-04 18:34:20 --> Config Class Initialized
INFO - 2016-05-04 18:34:20 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:34:20 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:34:20 --> Utf8 Class Initialized
INFO - 2016-05-04 18:34:20 --> URI Class Initialized
INFO - 2016-05-04 18:34:20 --> Router Class Initialized
INFO - 2016-05-04 18:34:20 --> Output Class Initialized
INFO - 2016-05-04 18:34:20 --> Security Class Initialized
DEBUG - 2016-05-04 18:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:34:20 --> Input Class Initialized
INFO - 2016-05-04 18:34:20 --> Language Class Initialized
INFO - 2016-05-04 18:34:20 --> Loader Class Initialized
INFO - 2016-05-04 18:34:20 --> Helper loaded: url_helper
INFO - 2016-05-04 18:34:20 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:34:20 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:34:20 --> Helper loaded: form_helper
INFO - 2016-05-04 18:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:34:20 --> Form Validation Class Initialized
INFO - 2016-05-04 18:34:20 --> Controller Class Initialized
INFO - 2016-05-04 18:34:20 --> Model Class Initialized
INFO - 2016-05-04 18:34:20 --> Database Driver Class Initialized
INFO - 2016-05-04 18:34:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:34:20 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:34:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:34:20 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 18:34:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-04 18:34:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:34:20 --> Final output sent to browser
DEBUG - 2016-05-04 18:34:20 --> Total execution time: 0.0731
INFO - 2016-05-04 18:34:28 --> Config Class Initialized
INFO - 2016-05-04 18:34:28 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:34:28 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:34:28 --> Utf8 Class Initialized
INFO - 2016-05-04 18:34:28 --> URI Class Initialized
INFO - 2016-05-04 18:34:28 --> Router Class Initialized
INFO - 2016-05-04 18:34:28 --> Output Class Initialized
INFO - 2016-05-04 18:34:28 --> Security Class Initialized
DEBUG - 2016-05-04 18:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:34:28 --> Input Class Initialized
INFO - 2016-05-04 18:34:28 --> Language Class Initialized
INFO - 2016-05-04 18:34:28 --> Loader Class Initialized
INFO - 2016-05-04 18:34:28 --> Helper loaded: url_helper
INFO - 2016-05-04 18:34:28 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:34:28 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:34:28 --> Helper loaded: form_helper
INFO - 2016-05-04 18:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:34:28 --> Form Validation Class Initialized
INFO - 2016-05-04 18:34:28 --> Controller Class Initialized
INFO - 2016-05-04 18:34:28 --> Model Class Initialized
INFO - 2016-05-04 18:34:28 --> Database Driver Class Initialized
INFO - 2016-05-04 18:34:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:34:28 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:34:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:34:28 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 18:34:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-04 18:34:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:34:28 --> Final output sent to browser
DEBUG - 2016-05-04 18:34:28 --> Total execution time: 0.2091
INFO - 2016-05-04 18:34:30 --> Config Class Initialized
INFO - 2016-05-04 18:34:30 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:34:30 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:34:30 --> Utf8 Class Initialized
INFO - 2016-05-04 18:34:30 --> URI Class Initialized
INFO - 2016-05-04 18:34:30 --> Router Class Initialized
INFO - 2016-05-04 18:34:30 --> Output Class Initialized
INFO - 2016-05-04 18:34:30 --> Security Class Initialized
DEBUG - 2016-05-04 18:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:34:30 --> Input Class Initialized
INFO - 2016-05-04 18:34:30 --> Language Class Initialized
INFO - 2016-05-04 18:34:30 --> Loader Class Initialized
INFO - 2016-05-04 18:34:30 --> Helper loaded: url_helper
INFO - 2016-05-04 18:34:30 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:34:30 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:34:30 --> Helper loaded: form_helper
INFO - 2016-05-04 18:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:34:30 --> Form Validation Class Initialized
INFO - 2016-05-04 18:34:30 --> Controller Class Initialized
INFO - 2016-05-04 18:34:30 --> Model Class Initialized
INFO - 2016-05-04 18:34:30 --> Database Driver Class Initialized
INFO - 2016-05-04 18:34:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:34:30 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:34:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:34:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-04 18:34:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:34:30 --> Final output sent to browser
DEBUG - 2016-05-04 18:34:30 --> Total execution time: 0.0883
INFO - 2016-05-04 18:34:35 --> Config Class Initialized
INFO - 2016-05-04 18:34:35 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:34:35 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:34:35 --> Utf8 Class Initialized
INFO - 2016-05-04 18:34:35 --> URI Class Initialized
INFO - 2016-05-04 18:34:35 --> Router Class Initialized
INFO - 2016-05-04 18:34:35 --> Output Class Initialized
INFO - 2016-05-04 18:34:35 --> Security Class Initialized
DEBUG - 2016-05-04 18:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:34:35 --> Input Class Initialized
INFO - 2016-05-04 18:34:35 --> Language Class Initialized
INFO - 2016-05-04 18:34:35 --> Loader Class Initialized
INFO - 2016-05-04 18:34:35 --> Helper loaded: url_helper
INFO - 2016-05-04 18:34:35 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:34:35 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:34:35 --> Helper loaded: form_helper
INFO - 2016-05-04 18:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:34:35 --> Form Validation Class Initialized
INFO - 2016-05-04 18:34:35 --> Controller Class Initialized
INFO - 2016-05-04 18:34:35 --> Model Class Initialized
INFO - 2016-05-04 18:34:35 --> Database Driver Class Initialized
INFO - 2016-05-04 18:34:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:34:35 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:34:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:34:35 --> Config Class Initialized
INFO - 2016-05-04 18:34:35 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:34:35 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:34:35 --> Utf8 Class Initialized
INFO - 2016-05-04 18:34:35 --> URI Class Initialized
INFO - 2016-05-04 18:34:35 --> Router Class Initialized
INFO - 2016-05-04 18:34:35 --> Output Class Initialized
INFO - 2016-05-04 18:34:35 --> Security Class Initialized
DEBUG - 2016-05-04 18:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:34:35 --> Input Class Initialized
INFO - 2016-05-04 18:34:35 --> Language Class Initialized
INFO - 2016-05-04 18:34:35 --> Loader Class Initialized
INFO - 2016-05-04 18:34:35 --> Helper loaded: url_helper
INFO - 2016-05-04 18:34:35 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:34:35 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:34:35 --> Helper loaded: form_helper
INFO - 2016-05-04 18:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:34:35 --> Form Validation Class Initialized
INFO - 2016-05-04 18:34:35 --> Controller Class Initialized
INFO - 2016-05-04 18:34:35 --> Model Class Initialized
INFO - 2016-05-04 18:34:35 --> Database Driver Class Initialized
INFO - 2016-05-04 18:34:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:34:35 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:34:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:34:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-04 18:34:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:34:35 --> Final output sent to browser
DEBUG - 2016-05-04 18:34:35 --> Total execution time: 0.1526
INFO - 2016-05-04 18:34:38 --> Config Class Initialized
INFO - 2016-05-04 18:34:38 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:34:38 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:34:38 --> Utf8 Class Initialized
INFO - 2016-05-04 18:34:38 --> URI Class Initialized
INFO - 2016-05-04 18:34:38 --> Router Class Initialized
INFO - 2016-05-04 18:34:38 --> Output Class Initialized
INFO - 2016-05-04 18:34:38 --> Security Class Initialized
DEBUG - 2016-05-04 18:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:34:38 --> Input Class Initialized
INFO - 2016-05-04 18:34:38 --> Language Class Initialized
INFO - 2016-05-04 18:34:38 --> Loader Class Initialized
INFO - 2016-05-04 18:34:38 --> Helper loaded: url_helper
INFO - 2016-05-04 18:34:38 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:34:38 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:34:38 --> Helper loaded: form_helper
INFO - 2016-05-04 18:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:34:38 --> Form Validation Class Initialized
INFO - 2016-05-04 18:34:38 --> Controller Class Initialized
INFO - 2016-05-04 18:34:38 --> Model Class Initialized
INFO - 2016-05-04 18:34:38 --> Database Driver Class Initialized
INFO - 2016-05-04 18:34:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:34:38 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:34:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:34:38 --> Config Class Initialized
INFO - 2016-05-04 18:34:38 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:34:38 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:34:38 --> Utf8 Class Initialized
INFO - 2016-05-04 18:34:38 --> URI Class Initialized
INFO - 2016-05-04 18:34:38 --> Router Class Initialized
INFO - 2016-05-04 18:34:38 --> Output Class Initialized
INFO - 2016-05-04 18:34:38 --> Security Class Initialized
DEBUG - 2016-05-04 18:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:34:38 --> Input Class Initialized
INFO - 2016-05-04 18:34:38 --> Language Class Initialized
INFO - 2016-05-04 18:34:38 --> Loader Class Initialized
INFO - 2016-05-04 18:34:38 --> Helper loaded: url_helper
INFO - 2016-05-04 18:34:38 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:34:38 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:34:38 --> Helper loaded: form_helper
INFO - 2016-05-04 18:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:34:38 --> Form Validation Class Initialized
INFO - 2016-05-04 18:34:38 --> Controller Class Initialized
INFO - 2016-05-04 18:34:38 --> Model Class Initialized
INFO - 2016-05-04 18:34:38 --> Database Driver Class Initialized
INFO - 2016-05-04 18:34:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:34:38 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:34:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:34:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-04 18:34:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:34:38 --> Final output sent to browser
DEBUG - 2016-05-04 18:34:38 --> Total execution time: 0.0725
INFO - 2016-05-04 18:36:04 --> Config Class Initialized
INFO - 2016-05-04 18:36:04 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:36:04 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:36:04 --> Utf8 Class Initialized
INFO - 2016-05-04 18:36:04 --> URI Class Initialized
INFO - 2016-05-04 18:36:04 --> Router Class Initialized
INFO - 2016-05-04 18:36:04 --> Output Class Initialized
INFO - 2016-05-04 18:36:04 --> Security Class Initialized
DEBUG - 2016-05-04 18:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:36:04 --> Input Class Initialized
INFO - 2016-05-04 18:36:04 --> Language Class Initialized
INFO - 2016-05-04 18:36:04 --> Loader Class Initialized
INFO - 2016-05-04 18:36:04 --> Helper loaded: url_helper
INFO - 2016-05-04 18:36:04 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:36:04 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:36:04 --> Helper loaded: form_helper
INFO - 2016-05-04 18:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:36:04 --> Form Validation Class Initialized
INFO - 2016-05-04 18:36:04 --> Controller Class Initialized
INFO - 2016-05-04 18:36:04 --> Model Class Initialized
INFO - 2016-05-04 18:36:04 --> Database Driver Class Initialized
INFO - 2016-05-04 18:36:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:36:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:36:04 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:36:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:36:04 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:36:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:36:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:36:04 --> Final output sent to browser
DEBUG - 2016-05-04 18:36:04 --> Total execution time: 0.0843
INFO - 2016-05-04 18:36:11 --> Config Class Initialized
INFO - 2016-05-04 18:36:11 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:36:11 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:36:11 --> Utf8 Class Initialized
INFO - 2016-05-04 18:36:11 --> URI Class Initialized
INFO - 2016-05-04 18:36:11 --> Router Class Initialized
INFO - 2016-05-04 18:36:11 --> Output Class Initialized
INFO - 2016-05-04 18:36:11 --> Security Class Initialized
DEBUG - 2016-05-04 18:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:36:11 --> Input Class Initialized
INFO - 2016-05-04 18:36:11 --> Language Class Initialized
INFO - 2016-05-04 18:36:11 --> Loader Class Initialized
INFO - 2016-05-04 18:36:11 --> Helper loaded: url_helper
INFO - 2016-05-04 18:36:11 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:36:11 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:36:11 --> Helper loaded: form_helper
INFO - 2016-05-04 18:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:36:11 --> Form Validation Class Initialized
INFO - 2016-05-04 18:36:11 --> Controller Class Initialized
INFO - 2016-05-04 18:36:11 --> Model Class Initialized
INFO - 2016-05-04 18:36:11 --> Database Driver Class Initialized
INFO - 2016-05-04 18:36:11 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:36:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:36:11 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:36:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:36:11 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:36:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:36:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:36:11 --> Final output sent to browser
DEBUG - 2016-05-04 18:36:11 --> Total execution time: 0.1024
INFO - 2016-05-04 18:36:18 --> Config Class Initialized
INFO - 2016-05-04 18:36:18 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:36:18 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:36:18 --> Utf8 Class Initialized
INFO - 2016-05-04 18:36:18 --> URI Class Initialized
INFO - 2016-05-04 18:36:18 --> Router Class Initialized
INFO - 2016-05-04 18:36:18 --> Output Class Initialized
INFO - 2016-05-04 18:36:18 --> Security Class Initialized
DEBUG - 2016-05-04 18:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:36:18 --> Input Class Initialized
INFO - 2016-05-04 18:36:18 --> Language Class Initialized
INFO - 2016-05-04 18:36:18 --> Loader Class Initialized
INFO - 2016-05-04 18:36:18 --> Helper loaded: url_helper
INFO - 2016-05-04 18:36:18 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:36:18 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:36:18 --> Helper loaded: form_helper
INFO - 2016-05-04 18:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:36:18 --> Form Validation Class Initialized
INFO - 2016-05-04 18:36:18 --> Controller Class Initialized
INFO - 2016-05-04 18:36:18 --> Model Class Initialized
INFO - 2016-05-04 18:36:18 --> Database Driver Class Initialized
INFO - 2016-05-04 18:36:18 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:36:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:36:18 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:36:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:36:18 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:36:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:36:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:36:18 --> Final output sent to browser
DEBUG - 2016-05-04 18:36:18 --> Total execution time: 0.0763
INFO - 2016-05-04 18:36:21 --> Config Class Initialized
INFO - 2016-05-04 18:36:21 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:36:21 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:36:21 --> Utf8 Class Initialized
INFO - 2016-05-04 18:36:21 --> URI Class Initialized
INFO - 2016-05-04 18:36:21 --> Router Class Initialized
INFO - 2016-05-04 18:36:21 --> Output Class Initialized
INFO - 2016-05-04 18:36:21 --> Security Class Initialized
DEBUG - 2016-05-04 18:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:36:21 --> Input Class Initialized
INFO - 2016-05-04 18:36:21 --> Language Class Initialized
INFO - 2016-05-04 18:36:21 --> Loader Class Initialized
INFO - 2016-05-04 18:36:21 --> Helper loaded: url_helper
INFO - 2016-05-04 18:36:21 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:36:21 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:36:21 --> Helper loaded: form_helper
INFO - 2016-05-04 18:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:36:22 --> Form Validation Class Initialized
INFO - 2016-05-04 18:36:22 --> Controller Class Initialized
INFO - 2016-05-04 18:36:22 --> Model Class Initialized
INFO - 2016-05-04 18:36:22 --> Database Driver Class Initialized
INFO - 2016-05-04 18:36:22 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:36:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:36:22 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:36:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:36:22 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:36:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProveedor.php
INFO - 2016-05-04 18:36:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:36:22 --> Final output sent to browser
DEBUG - 2016-05-04 18:36:22 --> Total execution time: 0.1069
INFO - 2016-05-04 18:36:26 --> Config Class Initialized
INFO - 2016-05-04 18:36:26 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:36:26 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:36:26 --> Utf8 Class Initialized
INFO - 2016-05-04 18:36:26 --> URI Class Initialized
INFO - 2016-05-04 18:36:26 --> Router Class Initialized
INFO - 2016-05-04 18:36:26 --> Output Class Initialized
INFO - 2016-05-04 18:36:26 --> Security Class Initialized
DEBUG - 2016-05-04 18:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:36:26 --> Input Class Initialized
INFO - 2016-05-04 18:36:26 --> Language Class Initialized
INFO - 2016-05-04 18:36:26 --> Loader Class Initialized
INFO - 2016-05-04 18:36:26 --> Helper loaded: url_helper
INFO - 2016-05-04 18:36:26 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:36:27 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:36:27 --> Helper loaded: form_helper
INFO - 2016-05-04 18:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:36:27 --> Form Validation Class Initialized
INFO - 2016-05-04 18:36:27 --> Controller Class Initialized
INFO - 2016-05-04 18:36:27 --> Model Class Initialized
INFO - 2016-05-04 18:36:27 --> Database Driver Class Initialized
INFO - 2016-05-04 18:36:27 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:36:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:36:27 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:36:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:36:27 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:36:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:36:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:36:27 --> Final output sent to browser
DEBUG - 2016-05-04 18:36:27 --> Total execution time: 0.0903
INFO - 2016-05-04 18:36:31 --> Config Class Initialized
INFO - 2016-05-04 18:36:31 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:36:31 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:36:31 --> Utf8 Class Initialized
INFO - 2016-05-04 18:36:31 --> URI Class Initialized
INFO - 2016-05-04 18:36:31 --> Router Class Initialized
INFO - 2016-05-04 18:36:31 --> Output Class Initialized
INFO - 2016-05-04 18:36:31 --> Security Class Initialized
DEBUG - 2016-05-04 18:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:36:31 --> Input Class Initialized
INFO - 2016-05-04 18:36:31 --> Language Class Initialized
INFO - 2016-05-04 18:36:31 --> Loader Class Initialized
INFO - 2016-05-04 18:36:31 --> Helper loaded: url_helper
INFO - 2016-05-04 18:36:31 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:36:31 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:36:31 --> Helper loaded: form_helper
INFO - 2016-05-04 18:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:36:31 --> Form Validation Class Initialized
INFO - 2016-05-04 18:36:31 --> Controller Class Initialized
INFO - 2016-05-04 18:36:31 --> Model Class Initialized
INFO - 2016-05-04 18:36:31 --> Database Driver Class Initialized
INFO - 2016-05-04 18:36:31 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:36:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:36:32 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:36:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:36:32 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:36:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:36:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:36:32 --> Final output sent to browser
DEBUG - 2016-05-04 18:36:32 --> Total execution time: 0.0772
INFO - 2016-05-04 18:36:36 --> Config Class Initialized
INFO - 2016-05-04 18:36:36 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:36:36 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:36:36 --> Utf8 Class Initialized
INFO - 2016-05-04 18:36:36 --> URI Class Initialized
INFO - 2016-05-04 18:36:36 --> Router Class Initialized
INFO - 2016-05-04 18:36:36 --> Output Class Initialized
INFO - 2016-05-04 18:36:36 --> Security Class Initialized
DEBUG - 2016-05-04 18:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:36:36 --> Input Class Initialized
INFO - 2016-05-04 18:36:36 --> Language Class Initialized
INFO - 2016-05-04 18:36:36 --> Loader Class Initialized
INFO - 2016-05-04 18:36:36 --> Helper loaded: url_helper
INFO - 2016-05-04 18:36:36 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:36:36 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:36:36 --> Helper loaded: form_helper
INFO - 2016-05-04 18:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:36:36 --> Form Validation Class Initialized
INFO - 2016-05-04 18:36:36 --> Controller Class Initialized
INFO - 2016-05-04 18:36:36 --> Model Class Initialized
INFO - 2016-05-04 18:36:36 --> Database Driver Class Initialized
INFO - 2016-05-04 18:36:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:36:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:36:36 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:36:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:36:36 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:36:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProveedor.php
INFO - 2016-05-04 18:36:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:36:36 --> Final output sent to browser
DEBUG - 2016-05-04 18:36:36 --> Total execution time: 0.0794
INFO - 2016-05-04 18:36:39 --> Config Class Initialized
INFO - 2016-05-04 18:36:39 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:36:39 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:36:39 --> Utf8 Class Initialized
INFO - 2016-05-04 18:36:39 --> URI Class Initialized
INFO - 2016-05-04 18:36:39 --> Router Class Initialized
INFO - 2016-05-04 18:36:39 --> Output Class Initialized
INFO - 2016-05-04 18:36:39 --> Security Class Initialized
DEBUG - 2016-05-04 18:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:36:39 --> Input Class Initialized
INFO - 2016-05-04 18:36:39 --> Language Class Initialized
INFO - 2016-05-04 18:36:39 --> Loader Class Initialized
INFO - 2016-05-04 18:36:39 --> Helper loaded: url_helper
INFO - 2016-05-04 18:36:39 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:36:39 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:36:39 --> Helper loaded: form_helper
INFO - 2016-05-04 18:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:36:39 --> Form Validation Class Initialized
INFO - 2016-05-04 18:36:39 --> Controller Class Initialized
INFO - 2016-05-04 18:36:39 --> Model Class Initialized
INFO - 2016-05-04 18:36:39 --> Database Driver Class Initialized
INFO - 2016-05-04 18:36:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:36:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:36:39 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:36:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:36:39 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:36:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProveedor.php
INFO - 2016-05-04 18:36:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:36:39 --> Final output sent to browser
DEBUG - 2016-05-04 18:36:39 --> Total execution time: 0.0813
INFO - 2016-05-04 18:36:41 --> Config Class Initialized
INFO - 2016-05-04 18:36:41 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:36:41 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:36:41 --> Utf8 Class Initialized
INFO - 2016-05-04 18:36:41 --> URI Class Initialized
INFO - 2016-05-04 18:36:41 --> Router Class Initialized
INFO - 2016-05-04 18:36:41 --> Output Class Initialized
INFO - 2016-05-04 18:36:41 --> Security Class Initialized
DEBUG - 2016-05-04 18:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:36:41 --> Input Class Initialized
INFO - 2016-05-04 18:36:41 --> Language Class Initialized
INFO - 2016-05-04 18:36:41 --> Loader Class Initialized
INFO - 2016-05-04 18:36:41 --> Helper loaded: url_helper
INFO - 2016-05-04 18:36:41 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:36:41 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:36:41 --> Helper loaded: form_helper
INFO - 2016-05-04 18:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:36:41 --> Form Validation Class Initialized
INFO - 2016-05-04 18:36:41 --> Controller Class Initialized
INFO - 2016-05-04 18:36:41 --> Model Class Initialized
INFO - 2016-05-04 18:36:41 --> Database Driver Class Initialized
INFO - 2016-05-04 18:36:41 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:36:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:36:41 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:36:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:36:41 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:36:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProveedor.php
INFO - 2016-05-04 18:36:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:36:41 --> Final output sent to browser
DEBUG - 2016-05-04 18:36:41 --> Total execution time: 0.0928
INFO - 2016-05-04 18:36:42 --> Config Class Initialized
INFO - 2016-05-04 18:36:42 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:36:42 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:36:42 --> Utf8 Class Initialized
INFO - 2016-05-04 18:36:42 --> URI Class Initialized
INFO - 2016-05-04 18:36:42 --> Router Class Initialized
INFO - 2016-05-04 18:36:42 --> Output Class Initialized
INFO - 2016-05-04 18:36:42 --> Security Class Initialized
DEBUG - 2016-05-04 18:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:36:42 --> Input Class Initialized
INFO - 2016-05-04 18:36:42 --> Language Class Initialized
INFO - 2016-05-04 18:36:42 --> Loader Class Initialized
INFO - 2016-05-04 18:36:42 --> Helper loaded: url_helper
INFO - 2016-05-04 18:36:42 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:36:42 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:36:42 --> Helper loaded: form_helper
INFO - 2016-05-04 18:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:36:42 --> Form Validation Class Initialized
INFO - 2016-05-04 18:36:42 --> Controller Class Initialized
INFO - 2016-05-04 18:36:42 --> Model Class Initialized
INFO - 2016-05-04 18:36:42 --> Database Driver Class Initialized
INFO - 2016-05-04 18:36:42 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:36:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:36:42 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:36:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:36:42 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:36:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:36:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:36:42 --> Final output sent to browser
DEBUG - 2016-05-04 18:36:42 --> Total execution time: 0.1025
INFO - 2016-05-04 18:36:49 --> Config Class Initialized
INFO - 2016-05-04 18:36:49 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:36:49 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:36:49 --> Utf8 Class Initialized
INFO - 2016-05-04 18:36:49 --> URI Class Initialized
INFO - 2016-05-04 18:36:49 --> Router Class Initialized
INFO - 2016-05-04 18:36:49 --> Output Class Initialized
INFO - 2016-05-04 18:36:49 --> Security Class Initialized
DEBUG - 2016-05-04 18:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:36:49 --> Input Class Initialized
INFO - 2016-05-04 18:36:49 --> Language Class Initialized
INFO - 2016-05-04 18:36:49 --> Loader Class Initialized
INFO - 2016-05-04 18:36:49 --> Helper loaded: url_helper
INFO - 2016-05-04 18:36:49 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:36:49 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:36:49 --> Helper loaded: form_helper
INFO - 2016-05-04 18:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:36:49 --> Form Validation Class Initialized
INFO - 2016-05-04 18:36:49 --> Controller Class Initialized
INFO - 2016-05-04 18:36:49 --> Model Class Initialized
INFO - 2016-05-04 18:36:49 --> Database Driver Class Initialized
INFO - 2016-05-04 18:36:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:36:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:36:49 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:36:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:36:49 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:36:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:36:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:36:49 --> Final output sent to browser
DEBUG - 2016-05-04 18:36:49 --> Total execution time: 0.0777
INFO - 2016-05-04 18:36:52 --> Config Class Initialized
INFO - 2016-05-04 18:36:52 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:36:52 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:36:52 --> Utf8 Class Initialized
INFO - 2016-05-04 18:36:52 --> URI Class Initialized
INFO - 2016-05-04 18:36:52 --> Router Class Initialized
INFO - 2016-05-04 18:36:52 --> Output Class Initialized
INFO - 2016-05-04 18:36:52 --> Security Class Initialized
DEBUG - 2016-05-04 18:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:36:52 --> Input Class Initialized
INFO - 2016-05-04 18:36:52 --> Language Class Initialized
INFO - 2016-05-04 18:36:52 --> Loader Class Initialized
INFO - 2016-05-04 18:36:52 --> Helper loaded: url_helper
INFO - 2016-05-04 18:36:52 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:36:52 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:36:52 --> Helper loaded: form_helper
INFO - 2016-05-04 18:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:36:52 --> Form Validation Class Initialized
INFO - 2016-05-04 18:36:52 --> Controller Class Initialized
INFO - 2016-05-04 18:36:52 --> Model Class Initialized
INFO - 2016-05-04 18:36:52 --> Database Driver Class Initialized
INFO - 2016-05-04 18:36:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:36:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:36:52 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:36:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:36:52 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:36:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:36:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:36:52 --> Final output sent to browser
DEBUG - 2016-05-04 18:36:52 --> Total execution time: 0.0820
INFO - 2016-05-04 18:36:56 --> Config Class Initialized
INFO - 2016-05-04 18:36:56 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:36:56 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:36:56 --> Utf8 Class Initialized
INFO - 2016-05-04 18:36:56 --> URI Class Initialized
INFO - 2016-05-04 18:36:56 --> Router Class Initialized
INFO - 2016-05-04 18:36:56 --> Output Class Initialized
INFO - 2016-05-04 18:36:56 --> Security Class Initialized
DEBUG - 2016-05-04 18:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:36:56 --> Input Class Initialized
INFO - 2016-05-04 18:36:56 --> Language Class Initialized
INFO - 2016-05-04 18:36:56 --> Loader Class Initialized
INFO - 2016-05-04 18:36:56 --> Helper loaded: url_helper
INFO - 2016-05-04 18:36:56 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:36:56 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:36:56 --> Helper loaded: form_helper
INFO - 2016-05-04 18:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:36:56 --> Form Validation Class Initialized
INFO - 2016-05-04 18:36:56 --> Controller Class Initialized
INFO - 2016-05-04 18:36:56 --> Model Class Initialized
INFO - 2016-05-04 18:36:56 --> Database Driver Class Initialized
INFO - 2016-05-04 18:36:56 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:36:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:36:56 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:36:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:36:56 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:36:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:36:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:36:56 --> Final output sent to browser
DEBUG - 2016-05-04 18:36:56 --> Total execution time: 0.0799
INFO - 2016-05-04 18:37:04 --> Config Class Initialized
INFO - 2016-05-04 18:37:04 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:37:04 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:37:04 --> Utf8 Class Initialized
INFO - 2016-05-04 18:37:04 --> URI Class Initialized
INFO - 2016-05-04 18:37:04 --> Router Class Initialized
INFO - 2016-05-04 18:37:04 --> Output Class Initialized
INFO - 2016-05-04 18:37:04 --> Security Class Initialized
DEBUG - 2016-05-04 18:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:37:04 --> Input Class Initialized
INFO - 2016-05-04 18:37:04 --> Language Class Initialized
INFO - 2016-05-04 18:37:04 --> Loader Class Initialized
INFO - 2016-05-04 18:37:04 --> Helper loaded: url_helper
INFO - 2016-05-04 18:37:04 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:37:04 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:37:04 --> Helper loaded: form_helper
INFO - 2016-05-04 18:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:37:04 --> Form Validation Class Initialized
INFO - 2016-05-04 18:37:04 --> Controller Class Initialized
INFO - 2016-05-04 18:37:04 --> Model Class Initialized
INFO - 2016-05-04 18:37:04 --> Database Driver Class Initialized
INFO - 2016-05-04 18:37:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:37:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:37:04 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:37:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:37:04 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:37:05 --> Config Class Initialized
INFO - 2016-05-04 18:37:05 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:37:05 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:37:05 --> Utf8 Class Initialized
INFO - 2016-05-04 18:37:05 --> URI Class Initialized
INFO - 2016-05-04 18:37:05 --> Router Class Initialized
INFO - 2016-05-04 18:37:05 --> Output Class Initialized
INFO - 2016-05-04 18:37:05 --> Security Class Initialized
DEBUG - 2016-05-04 18:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:37:05 --> Input Class Initialized
INFO - 2016-05-04 18:37:05 --> Language Class Initialized
INFO - 2016-05-04 18:37:05 --> Loader Class Initialized
INFO - 2016-05-04 18:37:05 --> Helper loaded: url_helper
INFO - 2016-05-04 18:37:05 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:37:05 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:37:05 --> Helper loaded: form_helper
INFO - 2016-05-04 18:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:37:05 --> Form Validation Class Initialized
INFO - 2016-05-04 18:37:05 --> Controller Class Initialized
INFO - 2016-05-04 18:37:05 --> Model Class Initialized
INFO - 2016-05-04 18:37:05 --> Database Driver Class Initialized
INFO - 2016-05-04 18:37:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:37:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:37:05 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:37:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:37:05 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:37:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:37:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:37:05 --> Final output sent to browser
DEBUG - 2016-05-04 18:37:05 --> Total execution time: 0.0906
INFO - 2016-05-04 18:37:12 --> Config Class Initialized
INFO - 2016-05-04 18:37:12 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:37:12 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:37:12 --> Utf8 Class Initialized
INFO - 2016-05-04 18:37:12 --> URI Class Initialized
INFO - 2016-05-04 18:37:12 --> Router Class Initialized
INFO - 2016-05-04 18:37:12 --> Output Class Initialized
INFO - 2016-05-04 18:37:12 --> Security Class Initialized
DEBUG - 2016-05-04 18:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:37:12 --> Input Class Initialized
INFO - 2016-05-04 18:37:12 --> Language Class Initialized
INFO - 2016-05-04 18:37:12 --> Loader Class Initialized
INFO - 2016-05-04 18:37:12 --> Helper loaded: url_helper
INFO - 2016-05-04 18:37:12 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:37:12 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:37:12 --> Helper loaded: form_helper
INFO - 2016-05-04 18:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:37:12 --> Form Validation Class Initialized
INFO - 2016-05-04 18:37:12 --> Controller Class Initialized
INFO - 2016-05-04 18:37:12 --> Model Class Initialized
INFO - 2016-05-04 18:37:12 --> Database Driver Class Initialized
INFO - 2016-05-04 18:37:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:37:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:37:12 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:37:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:37:12 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:37:12 --> Config Class Initialized
INFO - 2016-05-04 18:37:12 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:37:12 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:37:12 --> Utf8 Class Initialized
INFO - 2016-05-04 18:37:12 --> URI Class Initialized
INFO - 2016-05-04 18:37:12 --> Router Class Initialized
INFO - 2016-05-04 18:37:12 --> Output Class Initialized
INFO - 2016-05-04 18:37:12 --> Security Class Initialized
DEBUG - 2016-05-04 18:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:37:12 --> Input Class Initialized
INFO - 2016-05-04 18:37:13 --> Language Class Initialized
INFO - 2016-05-04 18:37:13 --> Loader Class Initialized
INFO - 2016-05-04 18:37:13 --> Helper loaded: url_helper
INFO - 2016-05-04 18:37:13 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:37:13 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:37:13 --> Helper loaded: form_helper
INFO - 2016-05-04 18:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:37:13 --> Form Validation Class Initialized
INFO - 2016-05-04 18:37:13 --> Controller Class Initialized
INFO - 2016-05-04 18:37:13 --> Model Class Initialized
INFO - 2016-05-04 18:37:13 --> Database Driver Class Initialized
INFO - 2016-05-04 18:37:13 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:37:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:37:13 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:37:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:37:13 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:37:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:37:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:37:13 --> Final output sent to browser
DEBUG - 2016-05-04 18:37:13 --> Total execution time: 0.0756
INFO - 2016-05-04 18:39:27 --> Config Class Initialized
INFO - 2016-05-04 18:39:27 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:39:27 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:39:27 --> Utf8 Class Initialized
INFO - 2016-05-04 18:39:27 --> URI Class Initialized
INFO - 2016-05-04 18:39:27 --> Router Class Initialized
INFO - 2016-05-04 18:39:27 --> Output Class Initialized
INFO - 2016-05-04 18:39:27 --> Security Class Initialized
DEBUG - 2016-05-04 18:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:39:27 --> Input Class Initialized
INFO - 2016-05-04 18:39:27 --> Language Class Initialized
INFO - 2016-05-04 18:39:27 --> Loader Class Initialized
INFO - 2016-05-04 18:39:27 --> Helper loaded: url_helper
INFO - 2016-05-04 18:39:27 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:39:27 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:39:27 --> Helper loaded: form_helper
INFO - 2016-05-04 18:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:39:27 --> Form Validation Class Initialized
INFO - 2016-05-04 18:39:27 --> Controller Class Initialized
INFO - 2016-05-04 18:39:27 --> Model Class Initialized
INFO - 2016-05-04 18:39:27 --> Database Driver Class Initialized
INFO - 2016-05-04 18:39:27 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:39:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:39:27 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:39:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:39:27 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:39:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:39:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:39:27 --> Final output sent to browser
DEBUG - 2016-05-04 18:39:27 --> Total execution time: 0.0979
INFO - 2016-05-04 18:39:33 --> Config Class Initialized
INFO - 2016-05-04 18:39:33 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:39:33 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:39:33 --> Utf8 Class Initialized
INFO - 2016-05-04 18:39:33 --> URI Class Initialized
INFO - 2016-05-04 18:39:33 --> Router Class Initialized
INFO - 2016-05-04 18:39:33 --> Output Class Initialized
INFO - 2016-05-04 18:39:33 --> Security Class Initialized
DEBUG - 2016-05-04 18:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:39:33 --> Input Class Initialized
INFO - 2016-05-04 18:39:33 --> Language Class Initialized
INFO - 2016-05-04 18:39:33 --> Loader Class Initialized
INFO - 2016-05-04 18:39:33 --> Helper loaded: url_helper
INFO - 2016-05-04 18:39:33 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:39:33 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:39:33 --> Helper loaded: form_helper
INFO - 2016-05-04 18:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:39:33 --> Form Validation Class Initialized
INFO - 2016-05-04 18:39:33 --> Controller Class Initialized
INFO - 2016-05-04 18:39:33 --> Model Class Initialized
INFO - 2016-05-04 18:39:33 --> Database Driver Class Initialized
INFO - 2016-05-04 18:39:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:39:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:39:33 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:39:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:39:33 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:39:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:39:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:39:33 --> Final output sent to browser
DEBUG - 2016-05-04 18:39:33 --> Total execution time: 0.0784
INFO - 2016-05-04 18:40:34 --> Config Class Initialized
INFO - 2016-05-04 18:40:34 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:40:34 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:40:34 --> Utf8 Class Initialized
INFO - 2016-05-04 18:40:34 --> URI Class Initialized
INFO - 2016-05-04 18:40:34 --> Router Class Initialized
INFO - 2016-05-04 18:40:34 --> Output Class Initialized
INFO - 2016-05-04 18:40:34 --> Security Class Initialized
DEBUG - 2016-05-04 18:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:40:34 --> Input Class Initialized
INFO - 2016-05-04 18:40:34 --> Language Class Initialized
INFO - 2016-05-04 18:40:34 --> Loader Class Initialized
INFO - 2016-05-04 18:40:34 --> Helper loaded: url_helper
INFO - 2016-05-04 18:40:34 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:40:34 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:40:34 --> Helper loaded: form_helper
INFO - 2016-05-04 18:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:40:34 --> Form Validation Class Initialized
INFO - 2016-05-04 18:40:34 --> Controller Class Initialized
INFO - 2016-05-04 18:40:34 --> Model Class Initialized
INFO - 2016-05-04 18:40:34 --> Database Driver Class Initialized
INFO - 2016-05-04 18:40:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:40:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:40:34 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:40:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:40:34 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:40:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:40:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:40:34 --> Final output sent to browser
DEBUG - 2016-05-04 18:40:34 --> Total execution time: 0.1462
INFO - 2016-05-04 18:40:39 --> Config Class Initialized
INFO - 2016-05-04 18:40:39 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:40:39 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:40:39 --> Utf8 Class Initialized
INFO - 2016-05-04 18:40:39 --> URI Class Initialized
INFO - 2016-05-04 18:40:39 --> Router Class Initialized
INFO - 2016-05-04 18:40:39 --> Output Class Initialized
INFO - 2016-05-04 18:40:39 --> Security Class Initialized
DEBUG - 2016-05-04 18:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:40:39 --> Input Class Initialized
INFO - 2016-05-04 18:40:39 --> Language Class Initialized
INFO - 2016-05-04 18:40:39 --> Loader Class Initialized
INFO - 2016-05-04 18:40:39 --> Helper loaded: url_helper
INFO - 2016-05-04 18:40:39 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:40:39 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:40:39 --> Helper loaded: form_helper
INFO - 2016-05-04 18:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:40:39 --> Form Validation Class Initialized
INFO - 2016-05-04 18:40:39 --> Controller Class Initialized
INFO - 2016-05-04 18:40:39 --> Model Class Initialized
INFO - 2016-05-04 18:40:39 --> Database Driver Class Initialized
INFO - 2016-05-04 18:40:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:40:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:40:39 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:40:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:40:39 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:40:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:40:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:40:39 --> Final output sent to browser
DEBUG - 2016-05-04 18:40:39 --> Total execution time: 0.0853
INFO - 2016-05-04 18:41:03 --> Config Class Initialized
INFO - 2016-05-04 18:41:03 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:41:03 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:41:03 --> Utf8 Class Initialized
INFO - 2016-05-04 18:41:03 --> URI Class Initialized
INFO - 2016-05-04 18:41:03 --> Router Class Initialized
INFO - 2016-05-04 18:41:03 --> Output Class Initialized
INFO - 2016-05-04 18:41:03 --> Security Class Initialized
DEBUG - 2016-05-04 18:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:41:03 --> Input Class Initialized
INFO - 2016-05-04 18:41:03 --> Language Class Initialized
INFO - 2016-05-04 18:41:03 --> Loader Class Initialized
INFO - 2016-05-04 18:41:03 --> Helper loaded: url_helper
INFO - 2016-05-04 18:41:03 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:41:03 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:41:03 --> Helper loaded: form_helper
INFO - 2016-05-04 18:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:41:03 --> Form Validation Class Initialized
INFO - 2016-05-04 18:41:03 --> Controller Class Initialized
INFO - 2016-05-04 18:41:03 --> Model Class Initialized
INFO - 2016-05-04 18:41:03 --> Database Driver Class Initialized
INFO - 2016-05-04 18:41:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:41:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:41:03 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:41:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:41:03 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:41:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProveedor.php
INFO - 2016-05-04 18:41:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:41:03 --> Final output sent to browser
DEBUG - 2016-05-04 18:41:03 --> Total execution time: 0.0842
INFO - 2016-05-04 18:41:04 --> Config Class Initialized
INFO - 2016-05-04 18:41:04 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:41:04 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:41:04 --> Utf8 Class Initialized
INFO - 2016-05-04 18:41:04 --> URI Class Initialized
INFO - 2016-05-04 18:41:04 --> Router Class Initialized
INFO - 2016-05-04 18:41:04 --> Output Class Initialized
INFO - 2016-05-04 18:41:04 --> Security Class Initialized
DEBUG - 2016-05-04 18:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:41:04 --> Input Class Initialized
INFO - 2016-05-04 18:41:04 --> Language Class Initialized
INFO - 2016-05-04 18:41:04 --> Loader Class Initialized
INFO - 2016-05-04 18:41:05 --> Helper loaded: url_helper
INFO - 2016-05-04 18:41:05 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:41:05 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:41:05 --> Helper loaded: form_helper
INFO - 2016-05-04 18:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:41:05 --> Form Validation Class Initialized
INFO - 2016-05-04 18:41:05 --> Controller Class Initialized
INFO - 2016-05-04 18:41:05 --> Model Class Initialized
INFO - 2016-05-04 18:41:05 --> Database Driver Class Initialized
INFO - 2016-05-04 18:41:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:41:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:41:05 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:41:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:41:05 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:41:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:41:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:41:05 --> Final output sent to browser
DEBUG - 2016-05-04 18:41:05 --> Total execution time: 0.1320
INFO - 2016-05-04 18:41:06 --> Config Class Initialized
INFO - 2016-05-04 18:41:06 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:41:06 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:41:06 --> Utf8 Class Initialized
INFO - 2016-05-04 18:41:06 --> URI Class Initialized
INFO - 2016-05-04 18:41:06 --> Router Class Initialized
INFO - 2016-05-04 18:41:06 --> Output Class Initialized
INFO - 2016-05-04 18:41:06 --> Security Class Initialized
DEBUG - 2016-05-04 18:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:41:06 --> Input Class Initialized
INFO - 2016-05-04 18:41:06 --> Language Class Initialized
INFO - 2016-05-04 18:41:06 --> Loader Class Initialized
INFO - 2016-05-04 18:41:06 --> Helper loaded: url_helper
INFO - 2016-05-04 18:41:06 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:41:06 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:41:06 --> Helper loaded: form_helper
INFO - 2016-05-04 18:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:41:06 --> Form Validation Class Initialized
INFO - 2016-05-04 18:41:06 --> Controller Class Initialized
INFO - 2016-05-04 18:41:06 --> Model Class Initialized
INFO - 2016-05-04 18:41:06 --> Database Driver Class Initialized
INFO - 2016-05-04 18:41:06 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:41:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:41:06 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:41:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:41:06 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:41:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProveedor.php
INFO - 2016-05-04 18:41:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:41:06 --> Final output sent to browser
DEBUG - 2016-05-04 18:41:06 --> Total execution time: 0.1272
INFO - 2016-05-04 18:41:07 --> Config Class Initialized
INFO - 2016-05-04 18:41:07 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:41:07 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:41:07 --> Utf8 Class Initialized
INFO - 2016-05-04 18:41:07 --> URI Class Initialized
INFO - 2016-05-04 18:41:07 --> Router Class Initialized
INFO - 2016-05-04 18:41:07 --> Output Class Initialized
INFO - 2016-05-04 18:41:07 --> Security Class Initialized
DEBUG - 2016-05-04 18:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:41:07 --> Input Class Initialized
INFO - 2016-05-04 18:41:07 --> Language Class Initialized
INFO - 2016-05-04 18:41:07 --> Loader Class Initialized
INFO - 2016-05-04 18:41:07 --> Helper loaded: url_helper
INFO - 2016-05-04 18:41:07 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:41:07 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:41:07 --> Helper loaded: form_helper
INFO - 2016-05-04 18:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:41:07 --> Form Validation Class Initialized
INFO - 2016-05-04 18:41:07 --> Controller Class Initialized
INFO - 2016-05-04 18:41:07 --> Model Class Initialized
INFO - 2016-05-04 18:41:07 --> Database Driver Class Initialized
INFO - 2016-05-04 18:41:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:41:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:41:07 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:41:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:41:07 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:41:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:41:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:41:08 --> Final output sent to browser
DEBUG - 2016-05-04 18:41:08 --> Total execution time: 0.1290
INFO - 2016-05-04 18:41:13 --> Config Class Initialized
INFO - 2016-05-04 18:41:13 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:41:13 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:41:13 --> Utf8 Class Initialized
INFO - 2016-05-04 18:41:13 --> URI Class Initialized
INFO - 2016-05-04 18:41:13 --> Router Class Initialized
INFO - 2016-05-04 18:41:13 --> Output Class Initialized
INFO - 2016-05-04 18:41:13 --> Security Class Initialized
DEBUG - 2016-05-04 18:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:41:13 --> Input Class Initialized
INFO - 2016-05-04 18:41:13 --> Language Class Initialized
INFO - 2016-05-04 18:41:13 --> Loader Class Initialized
INFO - 2016-05-04 18:41:13 --> Helper loaded: url_helper
INFO - 2016-05-04 18:41:13 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:41:13 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:41:13 --> Helper loaded: form_helper
INFO - 2016-05-04 18:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:41:13 --> Form Validation Class Initialized
INFO - 2016-05-04 18:41:13 --> Controller Class Initialized
INFO - 2016-05-04 18:41:13 --> Model Class Initialized
INFO - 2016-05-04 18:41:14 --> Database Driver Class Initialized
INFO - 2016-05-04 18:41:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:41:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:41:14 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:41:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:41:14 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:41:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:41:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:41:14 --> Final output sent to browser
DEBUG - 2016-05-04 18:41:14 --> Total execution time: 0.0845
INFO - 2016-05-04 18:42:23 --> Config Class Initialized
INFO - 2016-05-04 18:42:23 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:42:23 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:42:23 --> Utf8 Class Initialized
INFO - 2016-05-04 18:42:23 --> URI Class Initialized
INFO - 2016-05-04 18:42:23 --> Router Class Initialized
INFO - 2016-05-04 18:42:23 --> Output Class Initialized
INFO - 2016-05-04 18:42:23 --> Security Class Initialized
DEBUG - 2016-05-04 18:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:42:23 --> Input Class Initialized
INFO - 2016-05-04 18:42:23 --> Language Class Initialized
INFO - 2016-05-04 18:42:23 --> Loader Class Initialized
INFO - 2016-05-04 18:42:23 --> Helper loaded: url_helper
INFO - 2016-05-04 18:42:23 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:42:23 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:42:23 --> Helper loaded: form_helper
INFO - 2016-05-04 18:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:42:23 --> Form Validation Class Initialized
INFO - 2016-05-04 18:42:23 --> Controller Class Initialized
INFO - 2016-05-04 18:42:23 --> Model Class Initialized
INFO - 2016-05-04 18:42:23 --> Database Driver Class Initialized
INFO - 2016-05-04 18:42:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:42:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:42:23 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:42:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:42:23 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:42:23 --> Config Class Initialized
INFO - 2016-05-04 18:42:23 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:42:23 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:42:23 --> Utf8 Class Initialized
INFO - 2016-05-04 18:42:23 --> URI Class Initialized
INFO - 2016-05-04 18:42:23 --> Router Class Initialized
INFO - 2016-05-04 18:42:23 --> Output Class Initialized
INFO - 2016-05-04 18:42:23 --> Security Class Initialized
DEBUG - 2016-05-04 18:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:42:23 --> Input Class Initialized
INFO - 2016-05-04 18:42:23 --> Language Class Initialized
INFO - 2016-05-04 18:42:23 --> Loader Class Initialized
INFO - 2016-05-04 18:42:23 --> Helper loaded: url_helper
INFO - 2016-05-04 18:42:23 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:42:23 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:42:23 --> Helper loaded: form_helper
INFO - 2016-05-04 18:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:42:23 --> Form Validation Class Initialized
INFO - 2016-05-04 18:42:23 --> Controller Class Initialized
INFO - 2016-05-04 18:42:23 --> Model Class Initialized
INFO - 2016-05-04 18:42:23 --> Database Driver Class Initialized
INFO - 2016-05-04 18:42:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:42:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:42:23 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:42:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:42:23 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:42:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:42:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:42:23 --> Final output sent to browser
DEBUG - 2016-05-04 18:42:23 --> Total execution time: 0.1818
INFO - 2016-05-04 18:42:27 --> Config Class Initialized
INFO - 2016-05-04 18:42:27 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:42:27 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:42:27 --> Utf8 Class Initialized
INFO - 2016-05-04 18:42:27 --> URI Class Initialized
INFO - 2016-05-04 18:42:27 --> Router Class Initialized
INFO - 2016-05-04 18:42:27 --> Output Class Initialized
INFO - 2016-05-04 18:42:27 --> Security Class Initialized
DEBUG - 2016-05-04 18:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:42:27 --> Input Class Initialized
INFO - 2016-05-04 18:42:27 --> Language Class Initialized
INFO - 2016-05-04 18:42:27 --> Loader Class Initialized
INFO - 2016-05-04 18:42:27 --> Helper loaded: url_helper
INFO - 2016-05-04 18:42:27 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:42:27 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:42:27 --> Helper loaded: form_helper
INFO - 2016-05-04 18:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:42:27 --> Form Validation Class Initialized
INFO - 2016-05-04 18:42:27 --> Controller Class Initialized
INFO - 2016-05-04 18:42:27 --> Model Class Initialized
INFO - 2016-05-04 18:42:27 --> Database Driver Class Initialized
INFO - 2016-05-04 18:42:27 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:42:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:42:27 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:42:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:42:27 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:42:28 --> Config Class Initialized
INFO - 2016-05-04 18:42:28 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:42:28 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:42:28 --> Utf8 Class Initialized
INFO - 2016-05-04 18:42:28 --> URI Class Initialized
INFO - 2016-05-04 18:42:28 --> Router Class Initialized
INFO - 2016-05-04 18:42:28 --> Output Class Initialized
INFO - 2016-05-04 18:42:28 --> Security Class Initialized
DEBUG - 2016-05-04 18:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:42:28 --> Input Class Initialized
INFO - 2016-05-04 18:42:28 --> Language Class Initialized
INFO - 2016-05-04 18:42:28 --> Loader Class Initialized
INFO - 2016-05-04 18:42:28 --> Helper loaded: url_helper
INFO - 2016-05-04 18:42:28 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:42:28 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:42:28 --> Helper loaded: form_helper
INFO - 2016-05-04 18:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:42:28 --> Form Validation Class Initialized
INFO - 2016-05-04 18:42:28 --> Controller Class Initialized
INFO - 2016-05-04 18:42:28 --> Model Class Initialized
INFO - 2016-05-04 18:42:28 --> Database Driver Class Initialized
INFO - 2016-05-04 18:42:28 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:42:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:42:28 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:42:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:42:28 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:42:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:42:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:42:28 --> Final output sent to browser
DEBUG - 2016-05-04 18:42:28 --> Total execution time: 0.1260
INFO - 2016-05-04 18:43:33 --> Config Class Initialized
INFO - 2016-05-04 18:43:33 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:43:33 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:43:33 --> Utf8 Class Initialized
INFO - 2016-05-04 18:43:33 --> URI Class Initialized
INFO - 2016-05-04 18:43:33 --> Router Class Initialized
INFO - 2016-05-04 18:43:33 --> Output Class Initialized
INFO - 2016-05-04 18:43:33 --> Security Class Initialized
DEBUG - 2016-05-04 18:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:43:33 --> Input Class Initialized
INFO - 2016-05-04 18:43:33 --> Language Class Initialized
INFO - 2016-05-04 18:43:33 --> Loader Class Initialized
INFO - 2016-05-04 18:43:33 --> Helper loaded: url_helper
INFO - 2016-05-04 18:43:33 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:43:33 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:43:33 --> Helper loaded: form_helper
INFO - 2016-05-04 18:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:43:33 --> Form Validation Class Initialized
INFO - 2016-05-04 18:43:33 --> Controller Class Initialized
INFO - 2016-05-04 18:43:33 --> Model Class Initialized
INFO - 2016-05-04 18:43:33 --> Database Driver Class Initialized
INFO - 2016-05-04 18:43:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:43:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:43:33 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:43:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:43:33 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:43:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:43:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:43:33 --> Final output sent to browser
DEBUG - 2016-05-04 18:43:33 --> Total execution time: 0.0935
INFO - 2016-05-04 18:44:41 --> Config Class Initialized
INFO - 2016-05-04 18:44:41 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:44:41 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:44:41 --> Utf8 Class Initialized
INFO - 2016-05-04 18:44:41 --> URI Class Initialized
INFO - 2016-05-04 18:44:41 --> Router Class Initialized
INFO - 2016-05-04 18:44:41 --> Output Class Initialized
INFO - 2016-05-04 18:44:41 --> Security Class Initialized
DEBUG - 2016-05-04 18:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:44:41 --> Input Class Initialized
INFO - 2016-05-04 18:44:41 --> Language Class Initialized
INFO - 2016-05-04 18:44:41 --> Loader Class Initialized
INFO - 2016-05-04 18:44:41 --> Helper loaded: url_helper
INFO - 2016-05-04 18:44:41 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:44:41 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:44:41 --> Helper loaded: form_helper
INFO - 2016-05-04 18:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:44:41 --> Form Validation Class Initialized
INFO - 2016-05-04 18:44:41 --> Controller Class Initialized
INFO - 2016-05-04 18:44:41 --> Model Class Initialized
INFO - 2016-05-04 18:44:41 --> Database Driver Class Initialized
INFO - 2016-05-04 18:44:41 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:44:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:44:41 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:44:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:44:41 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:44:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:44:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:44:41 --> Final output sent to browser
DEBUG - 2016-05-04 18:44:41 --> Total execution time: 0.0940
INFO - 2016-05-04 18:46:16 --> Config Class Initialized
INFO - 2016-05-04 18:46:16 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:46:16 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:46:16 --> Utf8 Class Initialized
INFO - 2016-05-04 18:46:16 --> URI Class Initialized
INFO - 2016-05-04 18:46:16 --> Router Class Initialized
INFO - 2016-05-04 18:46:16 --> Output Class Initialized
INFO - 2016-05-04 18:46:16 --> Security Class Initialized
DEBUG - 2016-05-04 18:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:46:16 --> Input Class Initialized
INFO - 2016-05-04 18:46:16 --> Language Class Initialized
INFO - 2016-05-04 18:46:16 --> Loader Class Initialized
INFO - 2016-05-04 18:46:16 --> Helper loaded: url_helper
INFO - 2016-05-04 18:46:16 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:46:16 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:46:16 --> Helper loaded: form_helper
INFO - 2016-05-04 18:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:46:16 --> Form Validation Class Initialized
INFO - 2016-05-04 18:46:16 --> Controller Class Initialized
INFO - 2016-05-04 18:46:16 --> Model Class Initialized
INFO - 2016-05-04 18:46:16 --> Database Driver Class Initialized
INFO - 2016-05-04 18:46:16 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:46:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:46:16 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:46:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:46:16 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:46:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:46:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:46:16 --> Final output sent to browser
DEBUG - 2016-05-04 18:46:16 --> Total execution time: 0.1944
INFO - 2016-05-04 18:46:40 --> Config Class Initialized
INFO - 2016-05-04 18:46:40 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:46:40 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:46:40 --> Utf8 Class Initialized
INFO - 2016-05-04 18:46:40 --> URI Class Initialized
INFO - 2016-05-04 18:46:40 --> Router Class Initialized
INFO - 2016-05-04 18:46:40 --> Output Class Initialized
INFO - 2016-05-04 18:46:40 --> Security Class Initialized
DEBUG - 2016-05-04 18:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:46:40 --> Input Class Initialized
INFO - 2016-05-04 18:46:40 --> Language Class Initialized
INFO - 2016-05-04 18:46:40 --> Loader Class Initialized
INFO - 2016-05-04 18:46:40 --> Helper loaded: url_helper
INFO - 2016-05-04 18:46:40 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:46:40 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:46:40 --> Helper loaded: form_helper
INFO - 2016-05-04 18:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:46:40 --> Form Validation Class Initialized
INFO - 2016-05-04 18:46:40 --> Controller Class Initialized
INFO - 2016-05-04 18:46:40 --> Model Class Initialized
INFO - 2016-05-04 18:46:40 --> Database Driver Class Initialized
INFO - 2016-05-04 18:46:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:46:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:46:40 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:46:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:46:40 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:46:40 --> Config Class Initialized
INFO - 2016-05-04 18:46:40 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:46:40 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:46:40 --> Utf8 Class Initialized
INFO - 2016-05-04 18:46:40 --> URI Class Initialized
INFO - 2016-05-04 18:46:40 --> Router Class Initialized
INFO - 2016-05-04 18:46:40 --> Output Class Initialized
INFO - 2016-05-04 18:46:40 --> Security Class Initialized
DEBUG - 2016-05-04 18:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:46:40 --> Input Class Initialized
INFO - 2016-05-04 18:46:40 --> Language Class Initialized
INFO - 2016-05-04 18:46:40 --> Loader Class Initialized
INFO - 2016-05-04 18:46:40 --> Helper loaded: url_helper
INFO - 2016-05-04 18:46:40 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:46:40 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:46:40 --> Helper loaded: form_helper
INFO - 2016-05-04 18:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:46:40 --> Form Validation Class Initialized
INFO - 2016-05-04 18:46:40 --> Controller Class Initialized
INFO - 2016-05-04 18:46:40 --> Model Class Initialized
INFO - 2016-05-04 18:46:40 --> Database Driver Class Initialized
INFO - 2016-05-04 18:46:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:46:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:46:40 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:46:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:46:40 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:46:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:46:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:46:40 --> Final output sent to browser
DEBUG - 2016-05-04 18:46:40 --> Total execution time: 0.1155
INFO - 2016-05-04 18:46:53 --> Config Class Initialized
INFO - 2016-05-04 18:46:53 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:46:53 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:46:53 --> Utf8 Class Initialized
INFO - 2016-05-04 18:46:53 --> URI Class Initialized
INFO - 2016-05-04 18:46:53 --> Router Class Initialized
INFO - 2016-05-04 18:46:53 --> Output Class Initialized
INFO - 2016-05-04 18:46:53 --> Security Class Initialized
DEBUG - 2016-05-04 18:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:46:53 --> Input Class Initialized
INFO - 2016-05-04 18:46:53 --> Language Class Initialized
INFO - 2016-05-04 18:46:53 --> Loader Class Initialized
INFO - 2016-05-04 18:46:53 --> Helper loaded: url_helper
INFO - 2016-05-04 18:46:53 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:46:53 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:46:53 --> Helper loaded: form_helper
INFO - 2016-05-04 18:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:46:53 --> Form Validation Class Initialized
INFO - 2016-05-04 18:46:53 --> Controller Class Initialized
INFO - 2016-05-04 18:46:53 --> Model Class Initialized
INFO - 2016-05-04 18:46:53 --> Database Driver Class Initialized
INFO - 2016-05-04 18:46:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:46:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:46:53 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:46:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:46:53 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:46:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:46:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:46:53 --> Final output sent to browser
DEBUG - 2016-05-04 18:46:53 --> Total execution time: 0.1502
INFO - 2016-05-04 18:46:58 --> Config Class Initialized
INFO - 2016-05-04 18:46:58 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:46:58 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:46:58 --> Utf8 Class Initialized
INFO - 2016-05-04 18:46:58 --> URI Class Initialized
INFO - 2016-05-04 18:46:58 --> Router Class Initialized
INFO - 2016-05-04 18:46:58 --> Output Class Initialized
INFO - 2016-05-04 18:46:58 --> Security Class Initialized
DEBUG - 2016-05-04 18:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:46:58 --> Input Class Initialized
INFO - 2016-05-04 18:46:58 --> Language Class Initialized
INFO - 2016-05-04 18:46:58 --> Loader Class Initialized
INFO - 2016-05-04 18:46:58 --> Helper loaded: url_helper
INFO - 2016-05-04 18:46:58 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:46:58 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:46:58 --> Helper loaded: form_helper
INFO - 2016-05-04 18:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:46:58 --> Form Validation Class Initialized
INFO - 2016-05-04 18:46:58 --> Controller Class Initialized
INFO - 2016-05-04 18:46:58 --> Model Class Initialized
INFO - 2016-05-04 18:46:58 --> Database Driver Class Initialized
INFO - 2016-05-04 18:46:58 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:46:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:46:58 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:46:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:46:58 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:46:58 --> Config Class Initialized
INFO - 2016-05-04 18:46:58 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:46:58 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:46:58 --> Utf8 Class Initialized
INFO - 2016-05-04 18:46:58 --> URI Class Initialized
INFO - 2016-05-04 18:46:58 --> Router Class Initialized
INFO - 2016-05-04 18:46:58 --> Output Class Initialized
INFO - 2016-05-04 18:46:58 --> Security Class Initialized
DEBUG - 2016-05-04 18:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:46:58 --> Input Class Initialized
INFO - 2016-05-04 18:46:58 --> Language Class Initialized
INFO - 2016-05-04 18:46:58 --> Loader Class Initialized
INFO - 2016-05-04 18:46:58 --> Helper loaded: url_helper
INFO - 2016-05-04 18:46:58 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:46:58 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:46:58 --> Helper loaded: form_helper
INFO - 2016-05-04 18:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:46:58 --> Form Validation Class Initialized
INFO - 2016-05-04 18:46:58 --> Controller Class Initialized
INFO - 2016-05-04 18:46:58 --> Model Class Initialized
INFO - 2016-05-04 18:46:58 --> Database Driver Class Initialized
INFO - 2016-05-04 18:46:58 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:46:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:46:58 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:46:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:46:58 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:46:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:46:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:46:58 --> Final output sent to browser
DEBUG - 2016-05-04 18:46:58 --> Total execution time: 0.0758
INFO - 2016-05-04 18:47:39 --> Config Class Initialized
INFO - 2016-05-04 18:47:39 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:47:39 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:47:39 --> Utf8 Class Initialized
INFO - 2016-05-04 18:47:39 --> URI Class Initialized
INFO - 2016-05-04 18:47:39 --> Router Class Initialized
INFO - 2016-05-04 18:47:39 --> Output Class Initialized
INFO - 2016-05-04 18:47:39 --> Security Class Initialized
DEBUG - 2016-05-04 18:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:47:39 --> Input Class Initialized
INFO - 2016-05-04 18:47:39 --> Language Class Initialized
INFO - 2016-05-04 18:47:39 --> Loader Class Initialized
INFO - 2016-05-04 18:47:39 --> Helper loaded: url_helper
INFO - 2016-05-04 18:47:39 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:47:39 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:47:39 --> Helper loaded: form_helper
INFO - 2016-05-04 18:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:47:39 --> Form Validation Class Initialized
INFO - 2016-05-04 18:47:39 --> Controller Class Initialized
INFO - 2016-05-04 18:47:39 --> Model Class Initialized
INFO - 2016-05-04 18:47:40 --> Database Driver Class Initialized
INFO - 2016-05-04 18:47:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:47:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:47:40 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:47:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:47:40 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:47:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:47:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:47:40 --> Final output sent to browser
DEBUG - 2016-05-04 18:47:40 --> Total execution time: 0.0927
INFO - 2016-05-04 18:48:03 --> Config Class Initialized
INFO - 2016-05-04 18:48:03 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:48:03 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:48:03 --> Utf8 Class Initialized
INFO - 2016-05-04 18:48:03 --> URI Class Initialized
INFO - 2016-05-04 18:48:03 --> Router Class Initialized
INFO - 2016-05-04 18:48:03 --> Output Class Initialized
INFO - 2016-05-04 18:48:03 --> Security Class Initialized
DEBUG - 2016-05-04 18:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:48:03 --> Input Class Initialized
INFO - 2016-05-04 18:48:03 --> Language Class Initialized
INFO - 2016-05-04 18:48:03 --> Loader Class Initialized
INFO - 2016-05-04 18:48:03 --> Helper loaded: url_helper
INFO - 2016-05-04 18:48:03 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:48:03 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:48:03 --> Helper loaded: form_helper
INFO - 2016-05-04 18:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:48:03 --> Form Validation Class Initialized
INFO - 2016-05-04 18:48:03 --> Controller Class Initialized
INFO - 2016-05-04 18:48:03 --> Model Class Initialized
INFO - 2016-05-04 18:48:03 --> Database Driver Class Initialized
INFO - 2016-05-04 18:48:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:48:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:48:03 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:48:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:48:03 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:48:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:48:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:48:03 --> Final output sent to browser
DEBUG - 2016-05-04 18:48:03 --> Total execution time: 0.2027
INFO - 2016-05-04 18:48:22 --> Config Class Initialized
INFO - 2016-05-04 18:48:22 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:48:22 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:48:22 --> Utf8 Class Initialized
INFO - 2016-05-04 18:48:22 --> URI Class Initialized
INFO - 2016-05-04 18:48:22 --> Router Class Initialized
INFO - 2016-05-04 18:48:22 --> Output Class Initialized
INFO - 2016-05-04 18:48:22 --> Security Class Initialized
DEBUG - 2016-05-04 18:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:48:22 --> Input Class Initialized
INFO - 2016-05-04 18:48:22 --> Language Class Initialized
INFO - 2016-05-04 18:48:22 --> Loader Class Initialized
INFO - 2016-05-04 18:48:22 --> Helper loaded: url_helper
INFO - 2016-05-04 18:48:22 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:48:22 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:48:22 --> Helper loaded: form_helper
INFO - 2016-05-04 18:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:48:22 --> Form Validation Class Initialized
INFO - 2016-05-04 18:48:22 --> Controller Class Initialized
INFO - 2016-05-04 18:48:22 --> Model Class Initialized
INFO - 2016-05-04 18:48:22 --> Database Driver Class Initialized
INFO - 2016-05-04 18:48:22 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:48:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:48:22 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:48:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:48:22 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:48:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:48:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:48:22 --> Final output sent to browser
DEBUG - 2016-05-04 18:48:22 --> Total execution time: 0.1609
INFO - 2016-05-04 18:48:59 --> Config Class Initialized
INFO - 2016-05-04 18:48:59 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:48:59 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:48:59 --> Utf8 Class Initialized
INFO - 2016-05-04 18:48:59 --> URI Class Initialized
INFO - 2016-05-04 18:48:59 --> Router Class Initialized
INFO - 2016-05-04 18:48:59 --> Output Class Initialized
INFO - 2016-05-04 18:48:59 --> Security Class Initialized
DEBUG - 2016-05-04 18:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:48:59 --> Input Class Initialized
INFO - 2016-05-04 18:48:59 --> Language Class Initialized
INFO - 2016-05-04 18:48:59 --> Loader Class Initialized
INFO - 2016-05-04 18:48:59 --> Helper loaded: url_helper
INFO - 2016-05-04 18:48:59 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:48:59 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:48:59 --> Helper loaded: form_helper
INFO - 2016-05-04 18:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:48:59 --> Form Validation Class Initialized
INFO - 2016-05-04 18:48:59 --> Controller Class Initialized
INFO - 2016-05-04 18:48:59 --> Model Class Initialized
INFO - 2016-05-04 18:48:59 --> Database Driver Class Initialized
INFO - 2016-05-04 18:48:59 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:49:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:49:00 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:49:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:49:00 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:49:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:49:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:49:00 --> Final output sent to browser
DEBUG - 2016-05-04 18:49:00 --> Total execution time: 0.1370
INFO - 2016-05-04 18:49:20 --> Config Class Initialized
INFO - 2016-05-04 18:49:20 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:49:20 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:49:20 --> Utf8 Class Initialized
INFO - 2016-05-04 18:49:20 --> URI Class Initialized
INFO - 2016-05-04 18:49:20 --> Router Class Initialized
INFO - 2016-05-04 18:49:20 --> Output Class Initialized
INFO - 2016-05-04 18:49:20 --> Security Class Initialized
DEBUG - 2016-05-04 18:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:49:20 --> Input Class Initialized
INFO - 2016-05-04 18:49:20 --> Language Class Initialized
INFO - 2016-05-04 18:49:20 --> Loader Class Initialized
INFO - 2016-05-04 18:49:20 --> Helper loaded: url_helper
INFO - 2016-05-04 18:49:20 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:49:20 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:49:20 --> Helper loaded: form_helper
INFO - 2016-05-04 18:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:49:20 --> Form Validation Class Initialized
INFO - 2016-05-04 18:49:20 --> Controller Class Initialized
INFO - 2016-05-04 18:49:20 --> Model Class Initialized
INFO - 2016-05-04 18:49:20 --> Database Driver Class Initialized
INFO - 2016-05-04 18:49:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:49:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:49:20 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:49:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:49:20 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:49:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:49:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:49:20 --> Final output sent to browser
DEBUG - 2016-05-04 18:49:20 --> Total execution time: 0.1194
INFO - 2016-05-04 18:50:32 --> Config Class Initialized
INFO - 2016-05-04 18:50:32 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:50:32 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:50:32 --> Utf8 Class Initialized
INFO - 2016-05-04 18:50:32 --> URI Class Initialized
INFO - 2016-05-04 18:50:32 --> Router Class Initialized
INFO - 2016-05-04 18:50:32 --> Output Class Initialized
INFO - 2016-05-04 18:50:32 --> Security Class Initialized
DEBUG - 2016-05-04 18:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:50:32 --> Input Class Initialized
INFO - 2016-05-04 18:50:32 --> Language Class Initialized
INFO - 2016-05-04 18:50:32 --> Loader Class Initialized
INFO - 2016-05-04 18:50:32 --> Helper loaded: url_helper
INFO - 2016-05-04 18:50:32 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:50:32 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:50:32 --> Helper loaded: form_helper
INFO - 2016-05-04 18:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:50:32 --> Form Validation Class Initialized
INFO - 2016-05-04 18:50:32 --> Controller Class Initialized
INFO - 2016-05-04 18:50:32 --> Model Class Initialized
INFO - 2016-05-04 18:50:32 --> Database Driver Class Initialized
INFO - 2016-05-04 18:50:32 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:50:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:50:32 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:50:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:50:32 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:50:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:50:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:50:32 --> Final output sent to browser
DEBUG - 2016-05-04 18:50:32 --> Total execution time: 0.2503
INFO - 2016-05-04 18:52:53 --> Config Class Initialized
INFO - 2016-05-04 18:52:53 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:52:53 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:52:53 --> Utf8 Class Initialized
INFO - 2016-05-04 18:52:53 --> URI Class Initialized
INFO - 2016-05-04 18:52:54 --> Router Class Initialized
INFO - 2016-05-04 18:52:54 --> Output Class Initialized
INFO - 2016-05-04 18:52:54 --> Security Class Initialized
DEBUG - 2016-05-04 18:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:52:54 --> Input Class Initialized
INFO - 2016-05-04 18:52:54 --> Language Class Initialized
INFO - 2016-05-04 18:52:54 --> Loader Class Initialized
INFO - 2016-05-04 18:52:54 --> Helper loaded: url_helper
INFO - 2016-05-04 18:52:54 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:52:54 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:52:54 --> Helper loaded: form_helper
INFO - 2016-05-04 18:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:52:54 --> Form Validation Class Initialized
INFO - 2016-05-04 18:52:54 --> Controller Class Initialized
INFO - 2016-05-04 18:52:54 --> Model Class Initialized
INFO - 2016-05-04 18:52:54 --> Database Driver Class Initialized
INFO - 2016-05-04 18:52:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:52:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:52:54 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:52:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:52:54 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:52:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:52:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:52:54 --> Final output sent to browser
DEBUG - 2016-05-04 18:52:54 --> Total execution time: 0.1269
INFO - 2016-05-04 18:56:44 --> Config Class Initialized
INFO - 2016-05-04 18:56:44 --> Hooks Class Initialized
DEBUG - 2016-05-04 18:56:44 --> UTF-8 Support Enabled
INFO - 2016-05-04 18:56:44 --> Utf8 Class Initialized
INFO - 2016-05-04 18:56:44 --> URI Class Initialized
INFO - 2016-05-04 18:56:44 --> Router Class Initialized
INFO - 2016-05-04 18:56:44 --> Output Class Initialized
INFO - 2016-05-04 18:56:44 --> Security Class Initialized
DEBUG - 2016-05-04 18:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 18:56:44 --> Input Class Initialized
INFO - 2016-05-04 18:56:44 --> Language Class Initialized
INFO - 2016-05-04 18:56:44 --> Loader Class Initialized
INFO - 2016-05-04 18:56:44 --> Helper loaded: url_helper
INFO - 2016-05-04 18:56:44 --> Helper loaded: sesion_helper
INFO - 2016-05-04 18:56:44 --> Helper loaded: templates_helper
INFO - 2016-05-04 18:56:44 --> Helper loaded: form_helper
INFO - 2016-05-04 18:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 18:56:44 --> Form Validation Class Initialized
INFO - 2016-05-04 18:56:44 --> Controller Class Initialized
INFO - 2016-05-04 18:56:44 --> Model Class Initialized
INFO - 2016-05-04 18:56:44 --> Database Driver Class Initialized
INFO - 2016-05-04 18:56:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 18:56:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 18:56:45 --> Pagination Class Initialized
DEBUG - 2016-05-04 18:56:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 18:56:45 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 18:56:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 18:56:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 18:56:45 --> Final output sent to browser
DEBUG - 2016-05-04 18:56:45 --> Total execution time: 0.0828
INFO - 2016-05-04 19:06:08 --> Config Class Initialized
INFO - 2016-05-04 19:06:08 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:06:08 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:06:08 --> Utf8 Class Initialized
INFO - 2016-05-04 19:06:08 --> URI Class Initialized
INFO - 2016-05-04 19:06:08 --> Router Class Initialized
INFO - 2016-05-04 19:06:08 --> Output Class Initialized
INFO - 2016-05-04 19:06:08 --> Security Class Initialized
DEBUG - 2016-05-04 19:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:06:08 --> Input Class Initialized
INFO - 2016-05-04 19:06:08 --> Language Class Initialized
INFO - 2016-05-04 19:06:08 --> Loader Class Initialized
INFO - 2016-05-04 19:06:08 --> Helper loaded: url_helper
INFO - 2016-05-04 19:06:08 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:06:08 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:06:08 --> Helper loaded: form_helper
INFO - 2016-05-04 19:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:06:08 --> Form Validation Class Initialized
INFO - 2016-05-04 19:06:08 --> Controller Class Initialized
INFO - 2016-05-04 19:06:08 --> Model Class Initialized
INFO - 2016-05-04 19:06:08 --> Database Driver Class Initialized
INFO - 2016-05-04 19:06:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:06:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 19:06:08 --> Pagination Class Initialized
DEBUG - 2016-05-04 19:06:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 19:06:08 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:06:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 19:06:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:06:08 --> Final output sent to browser
DEBUG - 2016-05-04 19:06:08 --> Total execution time: 0.0822
INFO - 2016-05-04 19:06:14 --> Config Class Initialized
INFO - 2016-05-04 19:06:14 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:06:14 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:06:14 --> Utf8 Class Initialized
INFO - 2016-05-04 19:06:14 --> URI Class Initialized
INFO - 2016-05-04 19:06:14 --> Router Class Initialized
INFO - 2016-05-04 19:06:14 --> Output Class Initialized
INFO - 2016-05-04 19:06:14 --> Security Class Initialized
DEBUG - 2016-05-04 19:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:06:14 --> Input Class Initialized
INFO - 2016-05-04 19:06:14 --> Language Class Initialized
INFO - 2016-05-04 19:06:14 --> Loader Class Initialized
INFO - 2016-05-04 19:06:14 --> Helper loaded: url_helper
INFO - 2016-05-04 19:06:14 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:06:14 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:06:14 --> Helper loaded: form_helper
INFO - 2016-05-04 19:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:06:14 --> Form Validation Class Initialized
INFO - 2016-05-04 19:06:14 --> Controller Class Initialized
INFO - 2016-05-04 19:06:14 --> Model Class Initialized
INFO - 2016-05-04 19:06:14 --> Database Driver Class Initialized
INFO - 2016-05-04 19:06:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:06:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 19:06:14 --> Pagination Class Initialized
DEBUG - 2016-05-04 19:06:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 19:06:14 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:06:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 19:06:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:06:14 --> Final output sent to browser
DEBUG - 2016-05-04 19:06:14 --> Total execution time: 0.0814
INFO - 2016-05-04 19:06:45 --> Config Class Initialized
INFO - 2016-05-04 19:06:45 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:06:45 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:06:45 --> Utf8 Class Initialized
INFO - 2016-05-04 19:06:45 --> URI Class Initialized
INFO - 2016-05-04 19:06:45 --> Router Class Initialized
INFO - 2016-05-04 19:06:45 --> Output Class Initialized
INFO - 2016-05-04 19:06:45 --> Security Class Initialized
DEBUG - 2016-05-04 19:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:06:45 --> Input Class Initialized
INFO - 2016-05-04 19:06:45 --> Language Class Initialized
INFO - 2016-05-04 19:06:45 --> Loader Class Initialized
INFO - 2016-05-04 19:06:45 --> Helper loaded: url_helper
INFO - 2016-05-04 19:06:45 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:06:45 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:06:45 --> Helper loaded: form_helper
INFO - 2016-05-04 19:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:06:45 --> Form Validation Class Initialized
INFO - 2016-05-04 19:06:45 --> Controller Class Initialized
INFO - 2016-05-04 19:06:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-04 19:06:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:06:45 --> Final output sent to browser
DEBUG - 2016-05-04 19:06:45 --> Total execution time: 0.0502
INFO - 2016-05-04 19:06:47 --> Config Class Initialized
INFO - 2016-05-04 19:06:47 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:06:47 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:06:47 --> Utf8 Class Initialized
INFO - 2016-05-04 19:06:47 --> URI Class Initialized
INFO - 2016-05-04 19:06:47 --> Router Class Initialized
INFO - 2016-05-04 19:06:47 --> Output Class Initialized
INFO - 2016-05-04 19:06:47 --> Security Class Initialized
DEBUG - 2016-05-04 19:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:06:47 --> Input Class Initialized
INFO - 2016-05-04 19:06:47 --> Language Class Initialized
INFO - 2016-05-04 19:06:47 --> Loader Class Initialized
INFO - 2016-05-04 19:06:47 --> Helper loaded: url_helper
INFO - 2016-05-04 19:06:47 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:06:47 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:06:47 --> Helper loaded: form_helper
INFO - 2016-05-04 19:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:06:47 --> Form Validation Class Initialized
INFO - 2016-05-04 19:06:47 --> Controller Class Initialized
INFO - 2016-05-04 19:06:47 --> Model Class Initialized
INFO - 2016-05-04 19:06:47 --> Database Driver Class Initialized
INFO - 2016-05-04 19:06:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 19:06:47 --> Pagination Class Initialized
DEBUG - 2016-05-04 19:06:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 19:06:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-04 19:06:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:06:47 --> Final output sent to browser
DEBUG - 2016-05-04 19:06:47 --> Total execution time: 0.0889
INFO - 2016-05-04 19:06:53 --> Config Class Initialized
INFO - 2016-05-04 19:06:53 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:06:53 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:06:53 --> Utf8 Class Initialized
INFO - 2016-05-04 19:06:53 --> URI Class Initialized
INFO - 2016-05-04 19:06:53 --> Router Class Initialized
INFO - 2016-05-04 19:06:53 --> Output Class Initialized
INFO - 2016-05-04 19:06:53 --> Security Class Initialized
DEBUG - 2016-05-04 19:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:06:53 --> Input Class Initialized
INFO - 2016-05-04 19:06:53 --> Language Class Initialized
INFO - 2016-05-04 19:06:53 --> Loader Class Initialized
INFO - 2016-05-04 19:06:53 --> Helper loaded: url_helper
INFO - 2016-05-04 19:06:53 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:06:53 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:06:53 --> Helper loaded: form_helper
INFO - 2016-05-04 19:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:06:53 --> Form Validation Class Initialized
INFO - 2016-05-04 19:06:53 --> Controller Class Initialized
INFO - 2016-05-04 19:06:53 --> Model Class Initialized
INFO - 2016-05-04 19:06:53 --> Database Driver Class Initialized
INFO - 2016-05-04 19:06:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 19:06:53 --> Pagination Class Initialized
DEBUG - 2016-05-04 19:06:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 19:06:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-04 19:06:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:06:53 --> Final output sent to browser
DEBUG - 2016-05-04 19:06:53 --> Total execution time: 0.0724
INFO - 2016-05-04 19:06:58 --> Config Class Initialized
INFO - 2016-05-04 19:06:58 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:06:58 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:06:58 --> Utf8 Class Initialized
INFO - 2016-05-04 19:06:58 --> URI Class Initialized
INFO - 2016-05-04 19:06:58 --> Router Class Initialized
INFO - 2016-05-04 19:06:58 --> Output Class Initialized
INFO - 2016-05-04 19:06:58 --> Security Class Initialized
DEBUG - 2016-05-04 19:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:06:58 --> Input Class Initialized
INFO - 2016-05-04 19:06:58 --> Language Class Initialized
INFO - 2016-05-04 19:06:58 --> Loader Class Initialized
INFO - 2016-05-04 19:06:58 --> Helper loaded: url_helper
INFO - 2016-05-04 19:06:58 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:06:58 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:06:58 --> Helper loaded: form_helper
INFO - 2016-05-04 19:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:06:58 --> Form Validation Class Initialized
INFO - 2016-05-04 19:06:58 --> Controller Class Initialized
INFO - 2016-05-04 19:06:58 --> Model Class Initialized
INFO - 2016-05-04 19:06:58 --> Database Driver Class Initialized
INFO - 2016-05-04 19:06:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 19:06:58 --> Pagination Class Initialized
DEBUG - 2016-05-04 19:06:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 19:06:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-04 19:06:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:06:58 --> Final output sent to browser
DEBUG - 2016-05-04 19:06:58 --> Total execution time: 0.0730
INFO - 2016-05-04 19:08:21 --> Config Class Initialized
INFO - 2016-05-04 19:08:21 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:08:21 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:08:21 --> Utf8 Class Initialized
INFO - 2016-05-04 19:08:21 --> URI Class Initialized
INFO - 2016-05-04 19:08:21 --> Router Class Initialized
INFO - 2016-05-04 19:08:21 --> Output Class Initialized
INFO - 2016-05-04 19:08:21 --> Security Class Initialized
DEBUG - 2016-05-04 19:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:08:21 --> Input Class Initialized
INFO - 2016-05-04 19:08:21 --> Language Class Initialized
INFO - 2016-05-04 19:08:21 --> Loader Class Initialized
INFO - 2016-05-04 19:08:21 --> Helper loaded: url_helper
INFO - 2016-05-04 19:08:21 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:08:21 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:08:21 --> Helper loaded: form_helper
INFO - 2016-05-04 19:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:08:21 --> Form Validation Class Initialized
INFO - 2016-05-04 19:08:21 --> Controller Class Initialized
INFO - 2016-05-04 19:08:21 --> Model Class Initialized
INFO - 2016-05-04 19:08:21 --> Database Driver Class Initialized
INFO - 2016-05-04 19:08:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 19:08:21 --> Pagination Class Initialized
DEBUG - 2016-05-04 19:08:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 19:08:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-04 19:08:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:08:21 --> Final output sent to browser
DEBUG - 2016-05-04 19:08:21 --> Total execution time: 0.0861
INFO - 2016-05-04 19:08:32 --> Config Class Initialized
INFO - 2016-05-04 19:08:32 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:08:32 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:08:32 --> Utf8 Class Initialized
INFO - 2016-05-04 19:08:32 --> URI Class Initialized
INFO - 2016-05-04 19:08:32 --> Router Class Initialized
INFO - 2016-05-04 19:08:32 --> Output Class Initialized
INFO - 2016-05-04 19:08:32 --> Security Class Initialized
DEBUG - 2016-05-04 19:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:08:32 --> Input Class Initialized
INFO - 2016-05-04 19:08:32 --> Language Class Initialized
INFO - 2016-05-04 19:08:32 --> Loader Class Initialized
INFO - 2016-05-04 19:08:32 --> Helper loaded: url_helper
INFO - 2016-05-04 19:08:32 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:08:32 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:08:32 --> Helper loaded: form_helper
INFO - 2016-05-04 19:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:08:32 --> Form Validation Class Initialized
INFO - 2016-05-04 19:08:32 --> Controller Class Initialized
INFO - 2016-05-04 19:08:32 --> Model Class Initialized
INFO - 2016-05-04 19:08:32 --> Database Driver Class Initialized
INFO - 2016-05-04 19:08:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 19:08:32 --> Pagination Class Initialized
DEBUG - 2016-05-04 19:08:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 19:08:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-04 19:08:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:08:32 --> Final output sent to browser
DEBUG - 2016-05-04 19:08:32 --> Total execution time: 0.0740
INFO - 2016-05-04 19:13:18 --> Config Class Initialized
INFO - 2016-05-04 19:13:18 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:13:18 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:13:18 --> Utf8 Class Initialized
INFO - 2016-05-04 19:13:18 --> URI Class Initialized
INFO - 2016-05-04 19:13:18 --> Router Class Initialized
INFO - 2016-05-04 19:13:18 --> Output Class Initialized
INFO - 2016-05-04 19:13:18 --> Security Class Initialized
DEBUG - 2016-05-04 19:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:13:18 --> Input Class Initialized
INFO - 2016-05-04 19:13:18 --> Language Class Initialized
INFO - 2016-05-04 19:13:18 --> Loader Class Initialized
INFO - 2016-05-04 19:13:18 --> Helper loaded: url_helper
INFO - 2016-05-04 19:13:18 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:13:18 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:13:18 --> Helper loaded: form_helper
INFO - 2016-05-04 19:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:13:18 --> Form Validation Class Initialized
INFO - 2016-05-04 19:13:18 --> Controller Class Initialized
INFO - 2016-05-04 19:13:18 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:13:18 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:13:18 --> Model Class Initialized
INFO - 2016-05-04 19:13:18 --> Database Driver Class Initialized
INFO - 2016-05-04 19:13:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-04 19:13:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:13:18 --> Final output sent to browser
DEBUG - 2016-05-04 19:13:18 --> Total execution time: 0.0904
INFO - 2016-05-04 19:13:20 --> Config Class Initialized
INFO - 2016-05-04 19:13:20 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:13:20 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:13:20 --> Utf8 Class Initialized
INFO - 2016-05-04 19:13:20 --> URI Class Initialized
INFO - 2016-05-04 19:13:20 --> Router Class Initialized
INFO - 2016-05-04 19:13:20 --> Output Class Initialized
INFO - 2016-05-04 19:13:20 --> Security Class Initialized
DEBUG - 2016-05-04 19:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:13:20 --> Input Class Initialized
INFO - 2016-05-04 19:13:20 --> Language Class Initialized
INFO - 2016-05-04 19:13:20 --> Loader Class Initialized
INFO - 2016-05-04 19:13:20 --> Helper loaded: url_helper
INFO - 2016-05-04 19:13:20 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:13:20 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:13:20 --> Helper loaded: form_helper
INFO - 2016-05-04 19:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:13:20 --> Form Validation Class Initialized
INFO - 2016-05-04 19:13:20 --> Controller Class Initialized
INFO - 2016-05-04 19:13:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:13:20 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:13:20 --> Model Class Initialized
INFO - 2016-05-04 19:13:20 --> Database Driver Class Initialized
INFO - 2016-05-04 19:13:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:13:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:13:20 --> Final output sent to browser
DEBUG - 2016-05-04 19:13:20 --> Total execution time: 0.0904
INFO - 2016-05-04 19:13:39 --> Config Class Initialized
INFO - 2016-05-04 19:13:39 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:13:39 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:13:39 --> Utf8 Class Initialized
INFO - 2016-05-04 19:13:39 --> URI Class Initialized
INFO - 2016-05-04 19:13:39 --> Router Class Initialized
INFO - 2016-05-04 19:13:39 --> Output Class Initialized
INFO - 2016-05-04 19:13:39 --> Security Class Initialized
DEBUG - 2016-05-04 19:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:13:39 --> Input Class Initialized
INFO - 2016-05-04 19:13:39 --> Language Class Initialized
INFO - 2016-05-04 19:13:39 --> Loader Class Initialized
INFO - 2016-05-04 19:13:39 --> Helper loaded: url_helper
INFO - 2016-05-04 19:13:39 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:13:39 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:13:39 --> Helper loaded: form_helper
INFO - 2016-05-04 19:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:13:39 --> Form Validation Class Initialized
INFO - 2016-05-04 19:13:39 --> Controller Class Initialized
INFO - 2016-05-04 19:13:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-04 19:13:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:13:39 --> Final output sent to browser
DEBUG - 2016-05-04 19:13:39 --> Total execution time: 0.0561
INFO - 2016-05-04 19:13:41 --> Config Class Initialized
INFO - 2016-05-04 19:13:41 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:13:41 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:13:41 --> Utf8 Class Initialized
INFO - 2016-05-04 19:13:41 --> URI Class Initialized
INFO - 2016-05-04 19:13:41 --> Router Class Initialized
INFO - 2016-05-04 19:13:41 --> Output Class Initialized
INFO - 2016-05-04 19:13:41 --> Security Class Initialized
DEBUG - 2016-05-04 19:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:13:41 --> Input Class Initialized
INFO - 2016-05-04 19:13:41 --> Language Class Initialized
INFO - 2016-05-04 19:13:41 --> Loader Class Initialized
INFO - 2016-05-04 19:13:41 --> Helper loaded: url_helper
INFO - 2016-05-04 19:13:41 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:13:41 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:13:41 --> Helper loaded: form_helper
INFO - 2016-05-04 19:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:13:41 --> Form Validation Class Initialized
INFO - 2016-05-04 19:13:41 --> Controller Class Initialized
INFO - 2016-05-04 19:13:41 --> Model Class Initialized
INFO - 2016-05-04 19:13:41 --> Database Driver Class Initialized
INFO - 2016-05-04 19:13:41 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:13:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 19:13:41 --> Pagination Class Initialized
DEBUG - 2016-05-04 19:13:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 19:13:41 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:13:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-04 19:13:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:13:41 --> Final output sent to browser
DEBUG - 2016-05-04 19:13:41 --> Total execution time: 0.0960
INFO - 2016-05-04 19:13:46 --> Config Class Initialized
INFO - 2016-05-04 19:13:46 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:13:46 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:13:46 --> Utf8 Class Initialized
INFO - 2016-05-04 19:13:46 --> URI Class Initialized
INFO - 2016-05-04 19:13:46 --> Router Class Initialized
INFO - 2016-05-04 19:13:46 --> Output Class Initialized
INFO - 2016-05-04 19:13:46 --> Security Class Initialized
DEBUG - 2016-05-04 19:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:13:46 --> Input Class Initialized
INFO - 2016-05-04 19:13:46 --> Language Class Initialized
INFO - 2016-05-04 19:13:46 --> Loader Class Initialized
INFO - 2016-05-04 19:13:46 --> Helper loaded: url_helper
INFO - 2016-05-04 19:13:46 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:13:46 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:13:46 --> Helper loaded: form_helper
INFO - 2016-05-04 19:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:13:46 --> Form Validation Class Initialized
INFO - 2016-05-04 19:13:46 --> Controller Class Initialized
INFO - 2016-05-04 19:13:46 --> Model Class Initialized
INFO - 2016-05-04 19:13:46 --> Database Driver Class Initialized
INFO - 2016-05-04 19:13:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 19:13:46 --> Pagination Class Initialized
DEBUG - 2016-05-04 19:13:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 19:13:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-04 19:13:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:13:46 --> Final output sent to browser
DEBUG - 2016-05-04 19:13:46 --> Total execution time: 0.0768
INFO - 2016-05-04 19:13:50 --> Config Class Initialized
INFO - 2016-05-04 19:13:50 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:13:50 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:13:50 --> Utf8 Class Initialized
INFO - 2016-05-04 19:13:50 --> URI Class Initialized
INFO - 2016-05-04 19:13:50 --> Router Class Initialized
INFO - 2016-05-04 19:13:50 --> Output Class Initialized
INFO - 2016-05-04 19:13:50 --> Security Class Initialized
DEBUG - 2016-05-04 19:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:13:50 --> Input Class Initialized
INFO - 2016-05-04 19:13:50 --> Language Class Initialized
INFO - 2016-05-04 19:13:50 --> Loader Class Initialized
INFO - 2016-05-04 19:13:50 --> Helper loaded: url_helper
INFO - 2016-05-04 19:13:50 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:13:50 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:13:50 --> Helper loaded: form_helper
INFO - 2016-05-04 19:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:13:50 --> Form Validation Class Initialized
INFO - 2016-05-04 19:13:50 --> Controller Class Initialized
INFO - 2016-05-04 19:13:50 --> Model Class Initialized
INFO - 2016-05-04 19:13:50 --> Database Driver Class Initialized
INFO - 2016-05-04 19:13:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 19:13:50 --> Pagination Class Initialized
DEBUG - 2016-05-04 19:13:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 19:13:50 --> Config Class Initialized
INFO - 2016-05-04 19:13:50 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:13:50 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:13:50 --> Utf8 Class Initialized
INFO - 2016-05-04 19:13:50 --> URI Class Initialized
INFO - 2016-05-04 19:13:50 --> Router Class Initialized
INFO - 2016-05-04 19:13:50 --> Output Class Initialized
INFO - 2016-05-04 19:13:50 --> Security Class Initialized
DEBUG - 2016-05-04 19:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:13:50 --> Input Class Initialized
INFO - 2016-05-04 19:13:50 --> Language Class Initialized
INFO - 2016-05-04 19:13:50 --> Loader Class Initialized
INFO - 2016-05-04 19:13:50 --> Helper loaded: url_helper
INFO - 2016-05-04 19:13:50 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:13:50 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:13:50 --> Helper loaded: form_helper
INFO - 2016-05-04 19:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:13:50 --> Form Validation Class Initialized
INFO - 2016-05-04 19:13:50 --> Controller Class Initialized
INFO - 2016-05-04 19:13:50 --> Model Class Initialized
INFO - 2016-05-04 19:13:50 --> Database Driver Class Initialized
INFO - 2016-05-04 19:13:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 19:13:50 --> Pagination Class Initialized
DEBUG - 2016-05-04 19:13:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 19:13:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-04 19:13:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:13:50 --> Final output sent to browser
DEBUG - 2016-05-04 19:13:50 --> Total execution time: 0.0743
INFO - 2016-05-04 19:13:56 --> Config Class Initialized
INFO - 2016-05-04 19:13:56 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:13:56 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:13:56 --> Utf8 Class Initialized
INFO - 2016-05-04 19:13:56 --> URI Class Initialized
INFO - 2016-05-04 19:13:56 --> Router Class Initialized
INFO - 2016-05-04 19:13:56 --> Output Class Initialized
INFO - 2016-05-04 19:13:56 --> Security Class Initialized
DEBUG - 2016-05-04 19:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:13:56 --> Input Class Initialized
INFO - 2016-05-04 19:13:56 --> Language Class Initialized
INFO - 2016-05-04 19:13:56 --> Loader Class Initialized
INFO - 2016-05-04 19:13:56 --> Helper loaded: url_helper
INFO - 2016-05-04 19:13:56 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:13:56 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:13:56 --> Helper loaded: form_helper
INFO - 2016-05-04 19:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:13:56 --> Form Validation Class Initialized
INFO - 2016-05-04 19:13:56 --> Controller Class Initialized
INFO - 2016-05-04 19:13:56 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:13:56 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:13:56 --> Model Class Initialized
INFO - 2016-05-04 19:13:56 --> Database Driver Class Initialized
INFO - 2016-05-04 19:13:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:13:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:13:56 --> Final output sent to browser
DEBUG - 2016-05-04 19:13:56 --> Total execution time: 0.0881
INFO - 2016-05-04 19:17:54 --> Config Class Initialized
INFO - 2016-05-04 19:17:54 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:17:54 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:17:54 --> Utf8 Class Initialized
INFO - 2016-05-04 19:17:54 --> URI Class Initialized
INFO - 2016-05-04 19:17:54 --> Router Class Initialized
INFO - 2016-05-04 19:17:54 --> Output Class Initialized
INFO - 2016-05-04 19:17:54 --> Security Class Initialized
DEBUG - 2016-05-04 19:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:17:54 --> Input Class Initialized
INFO - 2016-05-04 19:17:54 --> Language Class Initialized
INFO - 2016-05-04 19:17:54 --> Loader Class Initialized
INFO - 2016-05-04 19:17:54 --> Helper loaded: url_helper
INFO - 2016-05-04 19:17:54 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:17:54 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:17:54 --> Helper loaded: form_helper
INFO - 2016-05-04 19:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:17:54 --> Form Validation Class Initialized
INFO - 2016-05-04 19:17:54 --> Controller Class Initialized
INFO - 2016-05-04 19:17:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:17:54 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:17:54 --> Model Class Initialized
INFO - 2016-05-04 19:17:54 --> Database Driver Class Initialized
INFO - 2016-05-04 19:17:54 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 19:17:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 19:17:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:17:54 --> Final output sent to browser
DEBUG - 2016-05-04 19:17:54 --> Total execution time: 0.1071
INFO - 2016-05-04 19:18:34 --> Config Class Initialized
INFO - 2016-05-04 19:18:34 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:18:34 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:18:34 --> Utf8 Class Initialized
INFO - 2016-05-04 19:18:34 --> URI Class Initialized
INFO - 2016-05-04 19:18:34 --> Router Class Initialized
INFO - 2016-05-04 19:18:34 --> Output Class Initialized
INFO - 2016-05-04 19:18:34 --> Security Class Initialized
DEBUG - 2016-05-04 19:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:18:34 --> Input Class Initialized
INFO - 2016-05-04 19:18:34 --> Language Class Initialized
INFO - 2016-05-04 19:18:34 --> Loader Class Initialized
INFO - 2016-05-04 19:18:34 --> Helper loaded: url_helper
INFO - 2016-05-04 19:18:34 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:18:34 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:18:34 --> Helper loaded: form_helper
INFO - 2016-05-04 19:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:18:34 --> Form Validation Class Initialized
INFO - 2016-05-04 19:18:34 --> Controller Class Initialized
INFO - 2016-05-04 19:18:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:18:34 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:18:34 --> Model Class Initialized
INFO - 2016-05-04 19:18:34 --> Database Driver Class Initialized
INFO - 2016-05-04 19:18:34 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 19:18:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 19:18:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:18:34 --> Final output sent to browser
DEBUG - 2016-05-04 19:18:34 --> Total execution time: 0.1267
INFO - 2016-05-04 19:18:47 --> Config Class Initialized
INFO - 2016-05-04 19:18:47 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:18:47 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:18:47 --> Utf8 Class Initialized
INFO - 2016-05-04 19:18:47 --> URI Class Initialized
INFO - 2016-05-04 19:18:47 --> Router Class Initialized
INFO - 2016-05-04 19:18:47 --> Output Class Initialized
INFO - 2016-05-04 19:18:47 --> Security Class Initialized
DEBUG - 2016-05-04 19:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:18:47 --> Input Class Initialized
INFO - 2016-05-04 19:18:47 --> Language Class Initialized
INFO - 2016-05-04 19:18:47 --> Loader Class Initialized
INFO - 2016-05-04 19:18:47 --> Helper loaded: url_helper
INFO - 2016-05-04 19:18:47 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:18:47 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:18:47 --> Helper loaded: form_helper
INFO - 2016-05-04 19:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:18:47 --> Form Validation Class Initialized
INFO - 2016-05-04 19:18:47 --> Controller Class Initialized
INFO - 2016-05-04 19:18:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-04 19:18:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:18:47 --> Final output sent to browser
DEBUG - 2016-05-04 19:18:47 --> Total execution time: 0.0493
INFO - 2016-05-04 19:18:51 --> Config Class Initialized
INFO - 2016-05-04 19:18:51 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:18:51 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:18:51 --> Utf8 Class Initialized
INFO - 2016-05-04 19:18:51 --> URI Class Initialized
INFO - 2016-05-04 19:18:51 --> Router Class Initialized
INFO - 2016-05-04 19:18:51 --> Output Class Initialized
INFO - 2016-05-04 19:18:51 --> Security Class Initialized
DEBUG - 2016-05-04 19:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:18:51 --> Input Class Initialized
INFO - 2016-05-04 19:18:51 --> Language Class Initialized
INFO - 2016-05-04 19:18:51 --> Loader Class Initialized
INFO - 2016-05-04 19:18:51 --> Helper loaded: url_helper
INFO - 2016-05-04 19:18:51 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:18:51 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:18:51 --> Helper loaded: form_helper
INFO - 2016-05-04 19:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:18:51 --> Form Validation Class Initialized
INFO - 2016-05-04 19:18:51 --> Controller Class Initialized
INFO - 2016-05-04 19:18:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-04 19:18:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-04 19:18:51 --> Final output sent to browser
DEBUG - 2016-05-04 19:18:51 --> Total execution time: 0.0516
INFO - 2016-05-04 19:18:53 --> Config Class Initialized
INFO - 2016-05-04 19:18:53 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:18:53 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:18:53 --> Utf8 Class Initialized
INFO - 2016-05-04 19:18:53 --> URI Class Initialized
INFO - 2016-05-04 19:18:53 --> Router Class Initialized
INFO - 2016-05-04 19:18:53 --> Output Class Initialized
INFO - 2016-05-04 19:18:53 --> Security Class Initialized
DEBUG - 2016-05-04 19:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:18:53 --> Input Class Initialized
INFO - 2016-05-04 19:18:53 --> Language Class Initialized
INFO - 2016-05-04 19:18:53 --> Loader Class Initialized
INFO - 2016-05-04 19:18:53 --> Helper loaded: url_helper
INFO - 2016-05-04 19:18:53 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:18:53 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:18:53 --> Helper loaded: form_helper
INFO - 2016-05-04 19:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:18:53 --> Form Validation Class Initialized
INFO - 2016-05-04 19:18:53 --> Controller Class Initialized
INFO - 2016-05-04 19:18:53 --> Config Class Initialized
INFO - 2016-05-04 19:18:53 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:18:53 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:18:53 --> Utf8 Class Initialized
INFO - 2016-05-04 19:18:53 --> URI Class Initialized
INFO - 2016-05-04 19:18:53 --> Router Class Initialized
INFO - 2016-05-04 19:18:53 --> Output Class Initialized
INFO - 2016-05-04 19:18:53 --> Security Class Initialized
DEBUG - 2016-05-04 19:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:18:53 --> Input Class Initialized
INFO - 2016-05-04 19:18:53 --> Language Class Initialized
INFO - 2016-05-04 19:18:53 --> Loader Class Initialized
INFO - 2016-05-04 19:18:53 --> Helper loaded: url_helper
INFO - 2016-05-04 19:18:53 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:18:53 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:18:53 --> Helper loaded: form_helper
INFO - 2016-05-04 19:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:18:53 --> Form Validation Class Initialized
INFO - 2016-05-04 19:18:53 --> Controller Class Initialized
INFO - 2016-05-04 19:18:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-04 19:18:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:18:53 --> Final output sent to browser
DEBUG - 2016-05-04 19:18:53 --> Total execution time: 0.0812
INFO - 2016-05-04 19:18:57 --> Config Class Initialized
INFO - 2016-05-04 19:18:57 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:18:57 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:18:57 --> Utf8 Class Initialized
INFO - 2016-05-04 19:18:57 --> URI Class Initialized
INFO - 2016-05-04 19:18:57 --> Router Class Initialized
INFO - 2016-05-04 19:18:57 --> Output Class Initialized
INFO - 2016-05-04 19:18:57 --> Security Class Initialized
DEBUG - 2016-05-04 19:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:18:57 --> Input Class Initialized
INFO - 2016-05-04 19:18:57 --> Language Class Initialized
INFO - 2016-05-04 19:18:57 --> Loader Class Initialized
INFO - 2016-05-04 19:18:57 --> Helper loaded: url_helper
INFO - 2016-05-04 19:18:57 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:18:57 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:18:57 --> Helper loaded: form_helper
INFO - 2016-05-04 19:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:18:57 --> Form Validation Class Initialized
INFO - 2016-05-04 19:18:57 --> Controller Class Initialized
INFO - 2016-05-04 19:18:57 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:18:57 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:18:57 --> Model Class Initialized
INFO - 2016-05-04 19:18:57 --> Database Driver Class Initialized
INFO - 2016-05-04 19:18:57 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 19:18:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 19:18:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:18:57 --> Final output sent to browser
DEBUG - 2016-05-04 19:18:57 --> Total execution time: 0.0805
INFO - 2016-05-04 19:19:05 --> Config Class Initialized
INFO - 2016-05-04 19:19:05 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:19:05 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:19:05 --> Utf8 Class Initialized
INFO - 2016-05-04 19:19:05 --> URI Class Initialized
INFO - 2016-05-04 19:19:05 --> Router Class Initialized
INFO - 2016-05-04 19:19:05 --> Output Class Initialized
INFO - 2016-05-04 19:19:05 --> Security Class Initialized
DEBUG - 2016-05-04 19:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:19:05 --> Input Class Initialized
INFO - 2016-05-04 19:19:05 --> Language Class Initialized
INFO - 2016-05-04 19:19:05 --> Loader Class Initialized
INFO - 2016-05-04 19:19:05 --> Helper loaded: url_helper
INFO - 2016-05-04 19:19:05 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:19:05 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:19:05 --> Helper loaded: form_helper
INFO - 2016-05-04 19:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:19:05 --> Form Validation Class Initialized
INFO - 2016-05-04 19:19:05 --> Controller Class Initialized
INFO - 2016-05-04 19:19:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:19:05 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:19:05 --> Model Class Initialized
INFO - 2016-05-04 19:19:05 --> Database Driver Class Initialized
INFO - 2016-05-04 19:19:05 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 19:19:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 19:19:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:19:05 --> Final output sent to browser
DEBUG - 2016-05-04 19:19:05 --> Total execution time: 0.0816
INFO - 2016-05-04 19:20:32 --> Config Class Initialized
INFO - 2016-05-04 19:20:32 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:20:32 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:20:32 --> Utf8 Class Initialized
INFO - 2016-05-04 19:20:32 --> URI Class Initialized
INFO - 2016-05-04 19:20:32 --> Router Class Initialized
INFO - 2016-05-04 19:20:32 --> Output Class Initialized
INFO - 2016-05-04 19:20:32 --> Security Class Initialized
DEBUG - 2016-05-04 19:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:20:32 --> Input Class Initialized
INFO - 2016-05-04 19:20:32 --> Language Class Initialized
INFO - 2016-05-04 19:20:32 --> Loader Class Initialized
INFO - 2016-05-04 19:20:32 --> Helper loaded: url_helper
INFO - 2016-05-04 19:20:32 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:20:32 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:20:32 --> Helper loaded: form_helper
INFO - 2016-05-04 19:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:20:32 --> Form Validation Class Initialized
INFO - 2016-05-04 19:20:32 --> Controller Class Initialized
INFO - 2016-05-04 19:20:32 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:20:32 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:20:32 --> Model Class Initialized
INFO - 2016-05-04 19:20:32 --> Database Driver Class Initialized
INFO - 2016-05-04 19:20:32 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 19:20:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 19:20:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:20:32 --> Final output sent to browser
DEBUG - 2016-05-04 19:20:32 --> Total execution time: 0.1011
INFO - 2016-05-04 19:20:49 --> Config Class Initialized
INFO - 2016-05-04 19:20:49 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:20:49 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:20:49 --> Utf8 Class Initialized
INFO - 2016-05-04 19:20:49 --> URI Class Initialized
INFO - 2016-05-04 19:20:49 --> Router Class Initialized
INFO - 2016-05-04 19:20:49 --> Output Class Initialized
INFO - 2016-05-04 19:20:49 --> Security Class Initialized
DEBUG - 2016-05-04 19:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:20:49 --> Input Class Initialized
INFO - 2016-05-04 19:20:49 --> Language Class Initialized
INFO - 2016-05-04 19:20:49 --> Loader Class Initialized
INFO - 2016-05-04 19:20:49 --> Helper loaded: url_helper
INFO - 2016-05-04 19:20:49 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:20:49 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:20:49 --> Helper loaded: form_helper
INFO - 2016-05-04 19:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:20:49 --> Form Validation Class Initialized
INFO - 2016-05-04 19:20:49 --> Controller Class Initialized
INFO - 2016-05-04 19:20:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:20:49 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:20:49 --> Model Class Initialized
INFO - 2016-05-04 19:20:49 --> Database Driver Class Initialized
INFO - 2016-05-04 19:20:49 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 19:20:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 19:20:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:20:49 --> Final output sent to browser
DEBUG - 2016-05-04 19:20:49 --> Total execution time: 0.0915
INFO - 2016-05-04 19:21:03 --> Config Class Initialized
INFO - 2016-05-04 19:21:03 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:21:03 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:21:03 --> Utf8 Class Initialized
INFO - 2016-05-04 19:21:03 --> URI Class Initialized
INFO - 2016-05-04 19:21:03 --> Router Class Initialized
INFO - 2016-05-04 19:21:03 --> Output Class Initialized
INFO - 2016-05-04 19:21:03 --> Security Class Initialized
DEBUG - 2016-05-04 19:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:21:03 --> Input Class Initialized
INFO - 2016-05-04 19:21:03 --> Language Class Initialized
INFO - 2016-05-04 19:21:03 --> Loader Class Initialized
INFO - 2016-05-04 19:21:03 --> Helper loaded: url_helper
INFO - 2016-05-04 19:21:03 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:21:03 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:21:03 --> Helper loaded: form_helper
INFO - 2016-05-04 19:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:21:03 --> Form Validation Class Initialized
INFO - 2016-05-04 19:21:03 --> Controller Class Initialized
INFO - 2016-05-04 19:21:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:21:03 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:21:03 --> Model Class Initialized
INFO - 2016-05-04 19:21:03 --> Database Driver Class Initialized
INFO - 2016-05-04 19:21:03 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 19:21:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 19:21:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:21:03 --> Final output sent to browser
DEBUG - 2016-05-04 19:21:03 --> Total execution time: 0.0818
INFO - 2016-05-04 19:21:14 --> Config Class Initialized
INFO - 2016-05-04 19:21:14 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:21:14 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:21:14 --> Utf8 Class Initialized
INFO - 2016-05-04 19:21:14 --> URI Class Initialized
INFO - 2016-05-04 19:21:14 --> Router Class Initialized
INFO - 2016-05-04 19:21:14 --> Output Class Initialized
INFO - 2016-05-04 19:21:14 --> Security Class Initialized
DEBUG - 2016-05-04 19:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:21:14 --> Input Class Initialized
INFO - 2016-05-04 19:21:14 --> Language Class Initialized
INFO - 2016-05-04 19:21:14 --> Loader Class Initialized
INFO - 2016-05-04 19:21:14 --> Helper loaded: url_helper
INFO - 2016-05-04 19:21:14 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:21:14 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:21:14 --> Helper loaded: form_helper
INFO - 2016-05-04 19:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:21:14 --> Form Validation Class Initialized
INFO - 2016-05-04 19:21:14 --> Controller Class Initialized
INFO - 2016-05-04 19:21:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:21:14 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:21:14 --> Model Class Initialized
INFO - 2016-05-04 19:21:14 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:21:14 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `categoria`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Ordenadores Portátiles', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', 'lenovog7035.jpg1462382474')
INFO - 2016-05-04 19:21:14 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:23:31 --> Config Class Initialized
INFO - 2016-05-04 19:23:31 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:23:31 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:23:31 --> Utf8 Class Initialized
INFO - 2016-05-04 19:23:31 --> URI Class Initialized
INFO - 2016-05-04 19:23:31 --> Router Class Initialized
INFO - 2016-05-04 19:23:31 --> Output Class Initialized
INFO - 2016-05-04 19:23:31 --> Security Class Initialized
DEBUG - 2016-05-04 19:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:23:31 --> Input Class Initialized
INFO - 2016-05-04 19:23:31 --> Language Class Initialized
INFO - 2016-05-04 19:23:31 --> Loader Class Initialized
INFO - 2016-05-04 19:23:31 --> Helper loaded: url_helper
INFO - 2016-05-04 19:23:31 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:23:31 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:23:31 --> Helper loaded: form_helper
INFO - 2016-05-04 19:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:23:31 --> Form Validation Class Initialized
INFO - 2016-05-04 19:23:31 --> Controller Class Initialized
INFO - 2016-05-04 19:23:31 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:23:31 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:23:31 --> Model Class Initialized
INFO - 2016-05-04 19:23:31 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:23:31 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `categoria`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Ordenadores Portátiles', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', 'lenovog7035.jpg1462382611')
INFO - 2016-05-04 19:23:31 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:23:34 --> Config Class Initialized
INFO - 2016-05-04 19:23:34 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:23:34 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:23:34 --> Utf8 Class Initialized
INFO - 2016-05-04 19:23:34 --> URI Class Initialized
INFO - 2016-05-04 19:23:34 --> Router Class Initialized
INFO - 2016-05-04 19:23:34 --> Output Class Initialized
INFO - 2016-05-04 19:23:34 --> Security Class Initialized
DEBUG - 2016-05-04 19:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:23:34 --> Input Class Initialized
INFO - 2016-05-04 19:23:34 --> Language Class Initialized
INFO - 2016-05-04 19:23:34 --> Loader Class Initialized
INFO - 2016-05-04 19:23:34 --> Helper loaded: url_helper
INFO - 2016-05-04 19:23:34 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:23:34 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:23:34 --> Helper loaded: form_helper
INFO - 2016-05-04 19:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:23:34 --> Form Validation Class Initialized
INFO - 2016-05-04 19:23:34 --> Controller Class Initialized
INFO - 2016-05-04 19:23:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:23:34 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:23:34 --> Model Class Initialized
INFO - 2016-05-04 19:23:34 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:23:34 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `categoria`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Ordenadores Portátiles', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', 'lenovog7035.jpg1462382614')
INFO - 2016-05-04 19:23:34 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:23:39 --> Config Class Initialized
INFO - 2016-05-04 19:23:39 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:23:39 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:23:39 --> Utf8 Class Initialized
INFO - 2016-05-04 19:23:39 --> URI Class Initialized
INFO - 2016-05-04 19:23:39 --> Router Class Initialized
INFO - 2016-05-04 19:23:39 --> Output Class Initialized
INFO - 2016-05-04 19:23:39 --> Security Class Initialized
DEBUG - 2016-05-04 19:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:23:39 --> Input Class Initialized
INFO - 2016-05-04 19:23:39 --> Language Class Initialized
INFO - 2016-05-04 19:23:39 --> Loader Class Initialized
INFO - 2016-05-04 19:23:39 --> Helper loaded: url_helper
INFO - 2016-05-04 19:23:39 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:23:39 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:23:39 --> Helper loaded: form_helper
INFO - 2016-05-04 19:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:23:39 --> Form Validation Class Initialized
INFO - 2016-05-04 19:23:39 --> Controller Class Initialized
INFO - 2016-05-04 19:23:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:23:39 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:23:39 --> Model Class Initialized
INFO - 2016-05-04 19:23:39 --> Database Driver Class Initialized
INFO - 2016-05-04 19:23:39 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 19:23:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 19:23:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:23:39 --> Final output sent to browser
DEBUG - 2016-05-04 19:23:39 --> Total execution time: 0.0834
INFO - 2016-05-04 19:23:45 --> Config Class Initialized
INFO - 2016-05-04 19:23:45 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:23:45 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:23:45 --> Utf8 Class Initialized
INFO - 2016-05-04 19:23:45 --> URI Class Initialized
INFO - 2016-05-04 19:23:45 --> Router Class Initialized
INFO - 2016-05-04 19:23:45 --> Output Class Initialized
INFO - 2016-05-04 19:23:45 --> Security Class Initialized
DEBUG - 2016-05-04 19:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:23:45 --> Input Class Initialized
INFO - 2016-05-04 19:23:45 --> Language Class Initialized
INFO - 2016-05-04 19:23:45 --> Loader Class Initialized
INFO - 2016-05-04 19:23:45 --> Helper loaded: url_helper
INFO - 2016-05-04 19:23:45 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:23:45 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:23:45 --> Helper loaded: form_helper
INFO - 2016-05-04 19:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:23:45 --> Form Validation Class Initialized
INFO - 2016-05-04 19:23:45 --> Controller Class Initialized
INFO - 2016-05-04 19:23:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:23:45 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:23:45 --> Model Class Initialized
INFO - 2016-05-04 19:23:45 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:23:45 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `categoria`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Ordenadores Portátiles', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', 'lenovog7035.jpg1462382625')
INFO - 2016-05-04 19:23:45 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:24:15 --> Config Class Initialized
INFO - 2016-05-04 19:24:15 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:24:15 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:24:15 --> Utf8 Class Initialized
INFO - 2016-05-04 19:24:15 --> URI Class Initialized
INFO - 2016-05-04 19:24:15 --> Router Class Initialized
INFO - 2016-05-04 19:24:15 --> Output Class Initialized
INFO - 2016-05-04 19:24:15 --> Security Class Initialized
DEBUG - 2016-05-04 19:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:24:15 --> Input Class Initialized
INFO - 2016-05-04 19:24:15 --> Language Class Initialized
INFO - 2016-05-04 19:24:15 --> Loader Class Initialized
INFO - 2016-05-04 19:24:15 --> Helper loaded: url_helper
INFO - 2016-05-04 19:24:15 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:24:15 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:24:15 --> Helper loaded: form_helper
INFO - 2016-05-04 19:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:24:15 --> Form Validation Class Initialized
INFO - 2016-05-04 19:24:15 --> Controller Class Initialized
INFO - 2016-05-04 19:24:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:24:15 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:24:15 --> Model Class Initialized
INFO - 2016-05-04 19:24:15 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:24:15 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `categoria`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Ordenadores Portátiles', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', 'lenovog7035.jpg1462382655')
INFO - 2016-05-04 19:24:15 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:24:42 --> Config Class Initialized
INFO - 2016-05-04 19:24:42 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:24:42 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:24:42 --> Utf8 Class Initialized
INFO - 2016-05-04 19:24:42 --> URI Class Initialized
INFO - 2016-05-04 19:24:42 --> Router Class Initialized
INFO - 2016-05-04 19:24:42 --> Output Class Initialized
INFO - 2016-05-04 19:24:42 --> Security Class Initialized
DEBUG - 2016-05-04 19:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:24:42 --> Input Class Initialized
INFO - 2016-05-04 19:24:42 --> Language Class Initialized
INFO - 2016-05-04 19:24:42 --> Loader Class Initialized
INFO - 2016-05-04 19:24:42 --> Helper loaded: url_helper
INFO - 2016-05-04 19:24:42 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:24:42 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:24:42 --> Helper loaded: form_helper
INFO - 2016-05-04 19:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:24:42 --> Form Validation Class Initialized
INFO - 2016-05-04 19:24:42 --> Controller Class Initialized
INFO - 2016-05-04 19:24:42 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:24:42 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:24:42 --> Model Class Initialized
INFO - 2016-05-04 19:24:42 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:24:42 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `categoria`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Ordenadores Portátiles', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', 'lenovog7035.jpg1462382682')
INFO - 2016-05-04 19:24:42 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:25:15 --> Config Class Initialized
INFO - 2016-05-04 19:25:15 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:25:15 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:25:15 --> Utf8 Class Initialized
INFO - 2016-05-04 19:25:15 --> URI Class Initialized
INFO - 2016-05-04 19:25:15 --> Router Class Initialized
INFO - 2016-05-04 19:25:15 --> Output Class Initialized
INFO - 2016-05-04 19:25:15 --> Security Class Initialized
DEBUG - 2016-05-04 19:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:25:15 --> Input Class Initialized
INFO - 2016-05-04 19:25:15 --> Language Class Initialized
INFO - 2016-05-04 19:25:15 --> Loader Class Initialized
INFO - 2016-05-04 19:25:15 --> Helper loaded: url_helper
INFO - 2016-05-04 19:25:15 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:25:15 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:25:15 --> Helper loaded: form_helper
INFO - 2016-05-04 19:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:25:15 --> Form Validation Class Initialized
INFO - 2016-05-04 19:25:15 --> Controller Class Initialized
INFO - 2016-05-04 19:25:15 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:25:15 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:25:15 --> Model Class Initialized
INFO - 2016-05-04 19:25:15 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:25:15 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `categoria`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Ordenadores Portátiles', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', 'lenovog7035.jpg1462382715')
INFO - 2016-05-04 19:25:15 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:25:45 --> Config Class Initialized
INFO - 2016-05-04 19:25:45 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:25:45 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:25:45 --> Utf8 Class Initialized
INFO - 2016-05-04 19:25:45 --> URI Class Initialized
INFO - 2016-05-04 19:25:45 --> Router Class Initialized
INFO - 2016-05-04 19:25:45 --> Output Class Initialized
INFO - 2016-05-04 19:25:45 --> Security Class Initialized
DEBUG - 2016-05-04 19:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:25:45 --> Input Class Initialized
INFO - 2016-05-04 19:25:45 --> Language Class Initialized
INFO - 2016-05-04 19:25:45 --> Loader Class Initialized
INFO - 2016-05-04 19:25:45 --> Helper loaded: url_helper
INFO - 2016-05-04 19:25:45 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:25:45 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:25:45 --> Helper loaded: form_helper
INFO - 2016-05-04 19:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:25:45 --> Form Validation Class Initialized
INFO - 2016-05-04 19:25:45 --> Controller Class Initialized
INFO - 2016-05-04 19:25:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:25:45 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:25:45 --> Model Class Initialized
INFO - 2016-05-04 19:25:45 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:25:45 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `categoria`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Ordenadores Portátiles', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', 'lenovog7035.jpg1462382745')
INFO - 2016-05-04 19:25:45 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:26:11 --> Config Class Initialized
INFO - 2016-05-04 19:26:11 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:26:11 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:26:11 --> Utf8 Class Initialized
INFO - 2016-05-04 19:26:11 --> URI Class Initialized
INFO - 2016-05-04 19:26:11 --> Router Class Initialized
INFO - 2016-05-04 19:26:11 --> Output Class Initialized
INFO - 2016-05-04 19:26:11 --> Security Class Initialized
DEBUG - 2016-05-04 19:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:26:11 --> Input Class Initialized
INFO - 2016-05-04 19:26:11 --> Language Class Initialized
INFO - 2016-05-04 19:26:11 --> Loader Class Initialized
INFO - 2016-05-04 19:26:11 --> Helper loaded: url_helper
INFO - 2016-05-04 19:26:11 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:26:11 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:26:11 --> Helper loaded: form_helper
INFO - 2016-05-04 19:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:26:11 --> Form Validation Class Initialized
INFO - 2016-05-04 19:26:11 --> Controller Class Initialized
INFO - 2016-05-04 19:26:11 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:26:11 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:26:11 --> Model Class Initialized
INFO - 2016-05-04 19:26:11 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:26:11 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `categoria`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Ordenadores Portátiles', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', 'lenovog7035.jpg1462382771')
INFO - 2016-05-04 19:26:11 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:26:30 --> Config Class Initialized
INFO - 2016-05-04 19:26:30 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:26:30 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:26:30 --> Utf8 Class Initialized
INFO - 2016-05-04 19:26:30 --> URI Class Initialized
INFO - 2016-05-04 19:26:30 --> Router Class Initialized
INFO - 2016-05-04 19:26:30 --> Output Class Initialized
INFO - 2016-05-04 19:26:30 --> Security Class Initialized
DEBUG - 2016-05-04 19:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:26:30 --> Input Class Initialized
INFO - 2016-05-04 19:26:30 --> Language Class Initialized
INFO - 2016-05-04 19:26:30 --> Loader Class Initialized
INFO - 2016-05-04 19:26:30 --> Helper loaded: url_helper
INFO - 2016-05-04 19:26:30 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:26:30 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:26:30 --> Helper loaded: form_helper
INFO - 2016-05-04 19:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:26:30 --> Form Validation Class Initialized
INFO - 2016-05-04 19:26:30 --> Controller Class Initialized
INFO - 2016-05-04 19:26:30 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:26:30 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:26:30 --> Model Class Initialized
INFO - 2016-05-04 19:26:30 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:26:30 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `categoria`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Ordenadores Portátiles', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', 'lenovog7035.jpg1462382790')
INFO - 2016-05-04 19:26:30 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:26:46 --> Config Class Initialized
INFO - 2016-05-04 19:26:46 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:26:46 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:26:46 --> Utf8 Class Initialized
INFO - 2016-05-04 19:26:46 --> URI Class Initialized
INFO - 2016-05-04 19:26:46 --> Router Class Initialized
INFO - 2016-05-04 19:26:46 --> Output Class Initialized
INFO - 2016-05-04 19:26:46 --> Security Class Initialized
DEBUG - 2016-05-04 19:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:26:46 --> Input Class Initialized
INFO - 2016-05-04 19:26:46 --> Language Class Initialized
INFO - 2016-05-04 19:26:46 --> Loader Class Initialized
INFO - 2016-05-04 19:26:46 --> Helper loaded: url_helper
INFO - 2016-05-04 19:26:46 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:26:46 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:26:46 --> Helper loaded: form_helper
INFO - 2016-05-04 19:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:26:46 --> Form Validation Class Initialized
INFO - 2016-05-04 19:26:46 --> Controller Class Initialized
INFO - 2016-05-04 19:26:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:26:46 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:26:46 --> Model Class Initialized
INFO - 2016-05-04 19:26:46 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:26:46 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `categoria`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Ordenadores Portátiles', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', 'lenovog7035.jpg1462382806')
INFO - 2016-05-04 19:26:46 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:27:26 --> Config Class Initialized
INFO - 2016-05-04 19:27:26 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:27:26 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:27:26 --> Utf8 Class Initialized
INFO - 2016-05-04 19:27:26 --> URI Class Initialized
INFO - 2016-05-04 19:27:26 --> Router Class Initialized
INFO - 2016-05-04 19:27:26 --> Output Class Initialized
INFO - 2016-05-04 19:27:26 --> Security Class Initialized
DEBUG - 2016-05-04 19:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:27:26 --> Input Class Initialized
INFO - 2016-05-04 19:27:26 --> Language Class Initialized
INFO - 2016-05-04 19:27:26 --> Loader Class Initialized
INFO - 2016-05-04 19:27:26 --> Helper loaded: url_helper
INFO - 2016-05-04 19:27:26 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:27:26 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:27:26 --> Helper loaded: form_helper
INFO - 2016-05-04 19:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:27:27 --> Form Validation Class Initialized
INFO - 2016-05-04 19:27:27 --> Controller Class Initialized
INFO - 2016-05-04 19:27:27 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:27:27 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:27:27 --> Model Class Initialized
INFO - 2016-05-04 19:27:27 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:27:27 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `categoria`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Ordenadores Portátiles', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', 'lenovog7035.jpg1462382847')
INFO - 2016-05-04 19:27:27 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:28:09 --> Config Class Initialized
INFO - 2016-05-04 19:28:09 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:28:09 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:28:09 --> Utf8 Class Initialized
INFO - 2016-05-04 19:28:09 --> URI Class Initialized
INFO - 2016-05-04 19:28:09 --> Router Class Initialized
INFO - 2016-05-04 19:28:09 --> Output Class Initialized
INFO - 2016-05-04 19:28:09 --> Security Class Initialized
DEBUG - 2016-05-04 19:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:28:09 --> Input Class Initialized
INFO - 2016-05-04 19:28:09 --> Language Class Initialized
INFO - 2016-05-04 19:28:09 --> Loader Class Initialized
INFO - 2016-05-04 19:28:09 --> Helper loaded: url_helper
INFO - 2016-05-04 19:28:09 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:28:09 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:28:09 --> Helper loaded: form_helper
INFO - 2016-05-04 19:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:28:09 --> Form Validation Class Initialized
INFO - 2016-05-04 19:28:09 --> Controller Class Initialized
INFO - 2016-05-04 19:28:09 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:28:09 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:28:09 --> Model Class Initialized
INFO - 2016-05-04 19:28:09 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:28:09 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `categoria`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Ordenadores Portátiles', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', '1462382889lenovog7035.jpg')
INFO - 2016-05-04 19:28:09 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:28:22 --> Config Class Initialized
INFO - 2016-05-04 19:28:22 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:28:22 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:28:22 --> Utf8 Class Initialized
INFO - 2016-05-04 19:28:22 --> URI Class Initialized
INFO - 2016-05-04 19:28:22 --> Router Class Initialized
INFO - 2016-05-04 19:28:22 --> Output Class Initialized
INFO - 2016-05-04 19:28:22 --> Security Class Initialized
DEBUG - 2016-05-04 19:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:28:22 --> Input Class Initialized
INFO - 2016-05-04 19:28:22 --> Language Class Initialized
INFO - 2016-05-04 19:28:22 --> Loader Class Initialized
INFO - 2016-05-04 19:28:22 --> Helper loaded: url_helper
INFO - 2016-05-04 19:28:22 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:28:22 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:28:22 --> Helper loaded: form_helper
INFO - 2016-05-04 19:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:28:22 --> Form Validation Class Initialized
INFO - 2016-05-04 19:28:22 --> Controller Class Initialized
INFO - 2016-05-04 19:28:22 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:28:22 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:28:22 --> Model Class Initialized
INFO - 2016-05-04 19:28:22 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:28:22 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `categoria`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Ordenadores Portátiles', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', '1462382902_lenovog7035.jpg')
INFO - 2016-05-04 19:28:22 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:28:57 --> Config Class Initialized
INFO - 2016-05-04 19:28:57 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:28:57 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:28:57 --> Utf8 Class Initialized
INFO - 2016-05-04 19:28:57 --> URI Class Initialized
INFO - 2016-05-04 19:28:57 --> Router Class Initialized
INFO - 2016-05-04 19:28:57 --> Output Class Initialized
INFO - 2016-05-04 19:28:57 --> Security Class Initialized
DEBUG - 2016-05-04 19:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:28:57 --> Input Class Initialized
INFO - 2016-05-04 19:28:57 --> Language Class Initialized
INFO - 2016-05-04 19:28:57 --> Loader Class Initialized
INFO - 2016-05-04 19:28:57 --> Helper loaded: url_helper
INFO - 2016-05-04 19:28:57 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:28:57 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:28:57 --> Helper loaded: form_helper
INFO - 2016-05-04 19:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:28:57 --> Form Validation Class Initialized
INFO - 2016-05-04 19:28:57 --> Controller Class Initialized
INFO - 2016-05-04 19:28:57 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:28:57 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:28:57 --> Model Class Initialized
INFO - 2016-05-04 19:28:57 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:28:57 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`categoria`, `proveedor`, `imagen`) VALUES ('Ordenadores Portátiles', 'Telephone SA', '1462382937_lenovog7035.jpg')
INFO - 2016-05-04 19:28:57 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:29:14 --> Config Class Initialized
INFO - 2016-05-04 19:29:14 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:29:14 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:29:14 --> Utf8 Class Initialized
INFO - 2016-05-04 19:29:14 --> URI Class Initialized
INFO - 2016-05-04 19:29:14 --> Router Class Initialized
INFO - 2016-05-04 19:29:14 --> Output Class Initialized
INFO - 2016-05-04 19:29:14 --> Security Class Initialized
DEBUG - 2016-05-04 19:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:29:14 --> Input Class Initialized
INFO - 2016-05-04 19:29:14 --> Language Class Initialized
INFO - 2016-05-04 19:29:14 --> Loader Class Initialized
INFO - 2016-05-04 19:29:14 --> Helper loaded: url_helper
INFO - 2016-05-04 19:29:14 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:29:14 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:29:14 --> Helper loaded: form_helper
INFO - 2016-05-04 19:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:29:14 --> Form Validation Class Initialized
INFO - 2016-05-04 19:29:14 --> Controller Class Initialized
INFO - 2016-05-04 19:29:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:29:14 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:29:14 --> Model Class Initialized
INFO - 2016-05-04 19:29:14 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:29:14 --> Query error: Unknown column 'proveedor' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', '1462382954_lenovog7035.jpg')
INFO - 2016-05-04 19:29:14 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:29:24 --> Config Class Initialized
INFO - 2016-05-04 19:29:25 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:29:25 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:29:25 --> Utf8 Class Initialized
INFO - 2016-05-04 19:29:25 --> URI Class Initialized
INFO - 2016-05-04 19:29:25 --> Router Class Initialized
INFO - 2016-05-04 19:29:25 --> Output Class Initialized
INFO - 2016-05-04 19:29:25 --> Security Class Initialized
DEBUG - 2016-05-04 19:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:29:25 --> Input Class Initialized
INFO - 2016-05-04 19:29:25 --> Language Class Initialized
INFO - 2016-05-04 19:29:25 --> Loader Class Initialized
INFO - 2016-05-04 19:29:25 --> Helper loaded: url_helper
INFO - 2016-05-04 19:29:25 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:29:25 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:29:25 --> Helper loaded: form_helper
INFO - 2016-05-04 19:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:29:25 --> Form Validation Class Initialized
INFO - 2016-05-04 19:29:25 --> Controller Class Initialized
INFO - 2016-05-04 19:29:25 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:29:25 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:29:25 --> Model Class Initialized
INFO - 2016-05-04 19:29:25 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:29:25 --> Query error: Unknown column 'categoria' in 'field list' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `categoria`, `proveedor`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', 'Ordenadores Portátiles', 'Telephone SA', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', '1462382965_lenovog7035.jpg')
INFO - 2016-05-04 19:29:25 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:29:36 --> Config Class Initialized
INFO - 2016-05-04 19:29:36 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:29:36 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:29:36 --> Utf8 Class Initialized
INFO - 2016-05-04 19:29:36 --> URI Class Initialized
INFO - 2016-05-04 19:29:36 --> Router Class Initialized
INFO - 2016-05-04 19:29:36 --> Output Class Initialized
INFO - 2016-05-04 19:29:36 --> Security Class Initialized
DEBUG - 2016-05-04 19:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:29:36 --> Input Class Initialized
INFO - 2016-05-04 19:29:36 --> Language Class Initialized
INFO - 2016-05-04 19:29:36 --> Loader Class Initialized
INFO - 2016-05-04 19:29:36 --> Helper loaded: url_helper
INFO - 2016-05-04 19:29:36 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:29:36 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:29:36 --> Helper loaded: form_helper
INFO - 2016-05-04 19:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:29:36 --> Form Validation Class Initialized
INFO - 2016-05-04 19:29:36 --> Controller Class Initialized
INFO - 2016-05-04 19:29:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:29:36 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:29:36 --> Model Class Initialized
INFO - 2016-05-04 19:29:36 --> Database Driver Class Initialized
INFO - 2016-05-04 19:29:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 19:29:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:29:36 --> Final output sent to browser
DEBUG - 2016-05-04 19:29:36 --> Total execution time: 0.1769
INFO - 2016-05-04 19:30:20 --> Config Class Initialized
INFO - 2016-05-04 19:30:20 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:30:20 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:30:20 --> Utf8 Class Initialized
INFO - 2016-05-04 19:30:20 --> URI Class Initialized
INFO - 2016-05-04 19:30:20 --> Router Class Initialized
INFO - 2016-05-04 19:30:20 --> Output Class Initialized
INFO - 2016-05-04 19:30:20 --> Security Class Initialized
DEBUG - 2016-05-04 19:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:30:20 --> Input Class Initialized
INFO - 2016-05-04 19:30:20 --> Language Class Initialized
INFO - 2016-05-04 19:30:20 --> Loader Class Initialized
INFO - 2016-05-04 19:30:20 --> Helper loaded: url_helper
INFO - 2016-05-04 19:30:20 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:30:20 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:30:20 --> Helper loaded: form_helper
INFO - 2016-05-04 19:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:30:20 --> Form Validation Class Initialized
INFO - 2016-05-04 19:30:20 --> Controller Class Initialized
INFO - 2016-05-04 19:30:20 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:30:20 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:30:20 --> Model Class Initialized
INFO - 2016-05-04 19:30:20 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:30:20 --> Query error: Duplicate entry 'Lenovo G70-35' for key 'nombre_UNIQUE' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', '1462383020_lenovog7035.jpg')
INFO - 2016-05-04 19:30:20 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:31:14 --> Config Class Initialized
INFO - 2016-05-04 19:31:14 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:31:14 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:31:14 --> Utf8 Class Initialized
INFO - 2016-05-04 19:31:14 --> URI Class Initialized
INFO - 2016-05-04 19:31:14 --> Router Class Initialized
INFO - 2016-05-04 19:31:14 --> Output Class Initialized
INFO - 2016-05-04 19:31:14 --> Security Class Initialized
DEBUG - 2016-05-04 19:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:31:14 --> Input Class Initialized
INFO - 2016-05-04 19:31:14 --> Language Class Initialized
INFO - 2016-05-04 19:31:14 --> Loader Class Initialized
INFO - 2016-05-04 19:31:14 --> Helper loaded: url_helper
INFO - 2016-05-04 19:31:14 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:31:14 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:31:14 --> Helper loaded: form_helper
INFO - 2016-05-04 19:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:31:14 --> Form Validation Class Initialized
INFO - 2016-05-04 19:31:14 --> Controller Class Initialized
INFO - 2016-05-04 19:31:14 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:31:14 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:31:14 --> Model Class Initialized
INFO - 2016-05-04 19:31:14 --> Database Driver Class Initialized
INFO - 2016-05-04 19:31:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 19:31:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:31:14 --> Final output sent to browser
DEBUG - 2016-05-04 19:31:14 --> Total execution time: 0.2195
INFO - 2016-05-04 19:31:58 --> Config Class Initialized
INFO - 2016-05-04 19:31:58 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:31:58 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:31:58 --> Utf8 Class Initialized
INFO - 2016-05-04 19:31:58 --> URI Class Initialized
INFO - 2016-05-04 19:31:58 --> Router Class Initialized
INFO - 2016-05-04 19:31:58 --> Output Class Initialized
INFO - 2016-05-04 19:31:58 --> Security Class Initialized
DEBUG - 2016-05-04 19:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:31:58 --> Input Class Initialized
INFO - 2016-05-04 19:31:58 --> Language Class Initialized
INFO - 2016-05-04 19:31:58 --> Loader Class Initialized
INFO - 2016-05-04 19:31:58 --> Helper loaded: url_helper
INFO - 2016-05-04 19:31:58 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:31:58 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:31:58 --> Helper loaded: form_helper
INFO - 2016-05-04 19:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:31:58 --> Form Validation Class Initialized
INFO - 2016-05-04 19:31:58 --> Controller Class Initialized
INFO - 2016-05-04 19:31:58 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:31:58 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:31:58 --> Model Class Initialized
INFO - 2016-05-04 19:31:58 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:31:58 --> Query error: Duplicate entry 'Lenovo G70-35' for key 'nombre_UNIQUE' - Invalid query: INSERT INTO `producto` (`nombre`, `marca`, `precio`, `precio_venta`, `iva`, `stock`, `idCategoria`, `idProveedor`, `descripcion`, `imagen`) VALUES ('Lenovo G70-35', 'Lenovo', '200', 326.7, '21', '45', '4', '15', 'Peso del producto	2,9 Kg\r\nDimensiones del producto	57,4 x 33,6 x 7,6 cm\r\nNúmero de modelo del producto	80Q50018GE\r\nDimensión de la pantalla	17.3 pulgadas\r\nFabricante del procesador	AMD®\r\nVelocidad del procesador	1800 MHz', '1462383118_lenovog7035.jpg')
INFO - 2016-05-04 19:31:58 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-04 19:33:18 --> Config Class Initialized
INFO - 2016-05-04 19:33:18 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:33:18 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:33:18 --> Utf8 Class Initialized
INFO - 2016-05-04 19:33:18 --> URI Class Initialized
INFO - 2016-05-04 19:33:18 --> Router Class Initialized
INFO - 2016-05-04 19:33:18 --> Output Class Initialized
INFO - 2016-05-04 19:33:18 --> Security Class Initialized
DEBUG - 2016-05-04 19:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:33:18 --> Input Class Initialized
INFO - 2016-05-04 19:33:18 --> Language Class Initialized
INFO - 2016-05-04 19:33:18 --> Loader Class Initialized
INFO - 2016-05-04 19:33:18 --> Helper loaded: url_helper
INFO - 2016-05-04 19:33:18 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:33:18 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:33:18 --> Helper loaded: form_helper
INFO - 2016-05-04 19:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:33:18 --> Form Validation Class Initialized
INFO - 2016-05-04 19:33:18 --> Controller Class Initialized
INFO - 2016-05-04 19:33:18 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:33:18 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:33:18 --> Model Class Initialized
INFO - 2016-05-04 19:33:18 --> Database Driver Class Initialized
INFO - 2016-05-04 19:33:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 19:33:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:33:19 --> Final output sent to browser
DEBUG - 2016-05-04 19:33:19 --> Total execution time: 0.2746
INFO - 2016-05-04 19:34:08 --> Config Class Initialized
INFO - 2016-05-04 19:34:08 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:34:08 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:34:08 --> Utf8 Class Initialized
INFO - 2016-05-04 19:34:08 --> URI Class Initialized
INFO - 2016-05-04 19:34:08 --> Router Class Initialized
INFO - 2016-05-04 19:34:08 --> Output Class Initialized
INFO - 2016-05-04 19:34:08 --> Security Class Initialized
DEBUG - 2016-05-04 19:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:34:08 --> Input Class Initialized
INFO - 2016-05-04 19:34:08 --> Language Class Initialized
INFO - 2016-05-04 19:34:08 --> Loader Class Initialized
INFO - 2016-05-04 19:34:08 --> Helper loaded: url_helper
INFO - 2016-05-04 19:34:08 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:34:08 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:34:08 --> Helper loaded: form_helper
INFO - 2016-05-04 19:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:34:08 --> Form Validation Class Initialized
INFO - 2016-05-04 19:34:08 --> Controller Class Initialized
INFO - 2016-05-04 19:34:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:34:08 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:34:08 --> Model Class Initialized
INFO - 2016-05-04 19:34:08 --> Database Driver Class Initialized
INFO - 2016-05-04 19:34:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 19:34:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:34:08 --> Final output sent to browser
DEBUG - 2016-05-04 19:34:08 --> Total execution time: 0.1543
INFO - 2016-05-04 19:36:43 --> Config Class Initialized
INFO - 2016-05-04 19:36:43 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:36:43 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:36:43 --> Utf8 Class Initialized
INFO - 2016-05-04 19:36:43 --> URI Class Initialized
INFO - 2016-05-04 19:36:43 --> Router Class Initialized
INFO - 2016-05-04 19:36:43 --> Output Class Initialized
INFO - 2016-05-04 19:36:43 --> Security Class Initialized
DEBUG - 2016-05-04 19:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:36:43 --> Input Class Initialized
INFO - 2016-05-04 19:36:43 --> Language Class Initialized
INFO - 2016-05-04 19:36:43 --> Loader Class Initialized
INFO - 2016-05-04 19:36:43 --> Helper loaded: url_helper
INFO - 2016-05-04 19:36:43 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:36:43 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:36:43 --> Helper loaded: form_helper
INFO - 2016-05-04 19:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:36:44 --> Form Validation Class Initialized
INFO - 2016-05-04 19:36:44 --> Controller Class Initialized
INFO - 2016-05-04 19:36:44 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:36:44 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:36:44 --> Model Class Initialized
INFO - 2016-05-04 19:36:44 --> Database Driver Class Initialized
INFO - 2016-05-04 19:36:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 19:36:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:36:44 --> Final output sent to browser
DEBUG - 2016-05-04 19:36:44 --> Total execution time: 0.1598
INFO - 2016-05-04 19:38:52 --> Config Class Initialized
INFO - 2016-05-04 19:38:52 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:38:52 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:38:52 --> Utf8 Class Initialized
INFO - 2016-05-04 19:38:52 --> URI Class Initialized
INFO - 2016-05-04 19:38:52 --> Router Class Initialized
INFO - 2016-05-04 19:38:52 --> Output Class Initialized
INFO - 2016-05-04 19:38:52 --> Security Class Initialized
DEBUG - 2016-05-04 19:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:38:52 --> Input Class Initialized
INFO - 2016-05-04 19:38:52 --> Language Class Initialized
INFO - 2016-05-04 19:38:52 --> Loader Class Initialized
INFO - 2016-05-04 19:38:52 --> Helper loaded: url_helper
INFO - 2016-05-04 19:38:52 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:38:52 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:38:52 --> Helper loaded: form_helper
INFO - 2016-05-04 19:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:38:52 --> Form Validation Class Initialized
INFO - 2016-05-04 19:38:52 --> Controller Class Initialized
INFO - 2016-05-04 19:38:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:38:52 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:38:52 --> Model Class Initialized
INFO - 2016-05-04 19:38:52 --> Database Driver Class Initialized
INFO - 2016-05-04 19:38:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 19:38:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:38:52 --> Final output sent to browser
DEBUG - 2016-05-04 19:38:52 --> Total execution time: 0.1556
INFO - 2016-05-04 19:38:56 --> Config Class Initialized
INFO - 2016-05-04 19:38:56 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:38:56 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:38:56 --> Utf8 Class Initialized
INFO - 2016-05-04 19:38:56 --> URI Class Initialized
INFO - 2016-05-04 19:38:56 --> Router Class Initialized
INFO - 2016-05-04 19:38:56 --> Output Class Initialized
INFO - 2016-05-04 19:38:56 --> Security Class Initialized
DEBUG - 2016-05-04 19:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:38:56 --> Input Class Initialized
INFO - 2016-05-04 19:38:56 --> Language Class Initialized
INFO - 2016-05-04 19:38:56 --> Loader Class Initialized
INFO - 2016-05-04 19:38:56 --> Helper loaded: url_helper
INFO - 2016-05-04 19:38:56 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:38:56 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:38:56 --> Helper loaded: form_helper
INFO - 2016-05-04 19:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:38:56 --> Form Validation Class Initialized
INFO - 2016-05-04 19:38:56 --> Controller Class Initialized
INFO - 2016-05-04 19:38:56 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:38:56 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:38:56 --> Model Class Initialized
INFO - 2016-05-04 19:38:56 --> Database Driver Class Initialized
INFO - 2016-05-04 19:38:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:38:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:38:56 --> Final output sent to browser
DEBUG - 2016-05-04 19:38:56 --> Total execution time: 0.1063
INFO - 2016-05-04 19:42:24 --> Config Class Initialized
INFO - 2016-05-04 19:42:24 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:42:24 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:42:24 --> Utf8 Class Initialized
INFO - 2016-05-04 19:42:24 --> URI Class Initialized
INFO - 2016-05-04 19:42:24 --> Router Class Initialized
INFO - 2016-05-04 19:42:24 --> Output Class Initialized
INFO - 2016-05-04 19:42:24 --> Security Class Initialized
DEBUG - 2016-05-04 19:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:42:24 --> Input Class Initialized
INFO - 2016-05-04 19:42:24 --> Language Class Initialized
INFO - 2016-05-04 19:42:24 --> Loader Class Initialized
INFO - 2016-05-04 19:42:24 --> Helper loaded: url_helper
INFO - 2016-05-04 19:42:24 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:42:24 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:42:24 --> Helper loaded: form_helper
INFO - 2016-05-04 19:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:42:24 --> Form Validation Class Initialized
INFO - 2016-05-04 19:42:24 --> Controller Class Initialized
INFO - 2016-05-04 19:42:24 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:42:24 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:42:24 --> Model Class Initialized
INFO - 2016-05-04 19:42:24 --> Database Driver Class Initialized
ERROR - 2016-05-04 19:42:24 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php 6
INFO - 2016-05-04 19:43:01 --> Config Class Initialized
INFO - 2016-05-04 19:43:01 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:43:01 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:43:01 --> Utf8 Class Initialized
INFO - 2016-05-04 19:43:01 --> URI Class Initialized
INFO - 2016-05-04 19:43:01 --> Router Class Initialized
INFO - 2016-05-04 19:43:01 --> Output Class Initialized
INFO - 2016-05-04 19:43:01 --> Security Class Initialized
DEBUG - 2016-05-04 19:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:43:01 --> Input Class Initialized
INFO - 2016-05-04 19:43:01 --> Language Class Initialized
INFO - 2016-05-04 19:43:01 --> Loader Class Initialized
INFO - 2016-05-04 19:43:01 --> Helper loaded: url_helper
INFO - 2016-05-04 19:43:01 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:43:01 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:43:01 --> Helper loaded: form_helper
INFO - 2016-05-04 19:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:43:01 --> Form Validation Class Initialized
INFO - 2016-05-04 19:43:01 --> Controller Class Initialized
INFO - 2016-05-04 19:43:01 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:43:01 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:43:01 --> Model Class Initialized
INFO - 2016-05-04 19:43:01 --> Database Driver Class Initialized
INFO - 2016-05-04 19:43:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:43:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:43:01 --> Final output sent to browser
DEBUG - 2016-05-04 19:43:01 --> Total execution time: 0.0757
INFO - 2016-05-04 19:43:18 --> Config Class Initialized
INFO - 2016-05-04 19:43:18 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:43:18 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:43:18 --> Utf8 Class Initialized
INFO - 2016-05-04 19:43:18 --> URI Class Initialized
INFO - 2016-05-04 19:43:18 --> Router Class Initialized
INFO - 2016-05-04 19:43:18 --> Output Class Initialized
INFO - 2016-05-04 19:43:18 --> Security Class Initialized
DEBUG - 2016-05-04 19:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:43:18 --> Input Class Initialized
INFO - 2016-05-04 19:43:18 --> Language Class Initialized
INFO - 2016-05-04 19:43:18 --> Loader Class Initialized
INFO - 2016-05-04 19:43:18 --> Helper loaded: url_helper
INFO - 2016-05-04 19:43:18 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:43:18 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:43:18 --> Helper loaded: form_helper
INFO - 2016-05-04 19:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:43:18 --> Form Validation Class Initialized
INFO - 2016-05-04 19:43:18 --> Controller Class Initialized
INFO - 2016-05-04 19:43:18 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:43:18 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:43:18 --> Model Class Initialized
INFO - 2016-05-04 19:43:18 --> Database Driver Class Initialized
INFO - 2016-05-04 19:43:18 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 19:43:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:43:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:43:18 --> Final output sent to browser
DEBUG - 2016-05-04 19:43:18 --> Total execution time: 0.1169
INFO - 2016-05-04 19:44:04 --> Config Class Initialized
INFO - 2016-05-04 19:44:04 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:44:04 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:44:04 --> Utf8 Class Initialized
INFO - 2016-05-04 19:44:04 --> URI Class Initialized
INFO - 2016-05-04 19:44:04 --> Router Class Initialized
INFO - 2016-05-04 19:44:04 --> Output Class Initialized
INFO - 2016-05-04 19:44:04 --> Security Class Initialized
DEBUG - 2016-05-04 19:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:44:04 --> Input Class Initialized
INFO - 2016-05-04 19:44:04 --> Language Class Initialized
INFO - 2016-05-04 19:44:04 --> Loader Class Initialized
INFO - 2016-05-04 19:44:04 --> Helper loaded: url_helper
INFO - 2016-05-04 19:44:04 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:44:04 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:44:04 --> Helper loaded: form_helper
INFO - 2016-05-04 19:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:44:04 --> Form Validation Class Initialized
INFO - 2016-05-04 19:44:04 --> Controller Class Initialized
INFO - 2016-05-04 19:44:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:44:04 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:44:04 --> Model Class Initialized
INFO - 2016-05-04 19:44:04 --> Database Driver Class Initialized
INFO - 2016-05-04 19:44:04 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 19:44:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:44:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:44:04 --> Final output sent to browser
DEBUG - 2016-05-04 19:44:04 --> Total execution time: 0.1400
INFO - 2016-05-04 19:44:43 --> Config Class Initialized
INFO - 2016-05-04 19:44:43 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:44:43 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:44:43 --> Utf8 Class Initialized
INFO - 2016-05-04 19:44:43 --> URI Class Initialized
INFO - 2016-05-04 19:44:43 --> Router Class Initialized
INFO - 2016-05-04 19:44:43 --> Output Class Initialized
INFO - 2016-05-04 19:44:43 --> Security Class Initialized
DEBUG - 2016-05-04 19:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:44:43 --> Input Class Initialized
INFO - 2016-05-04 19:44:43 --> Language Class Initialized
INFO - 2016-05-04 19:44:43 --> Loader Class Initialized
INFO - 2016-05-04 19:44:43 --> Helper loaded: url_helper
INFO - 2016-05-04 19:44:43 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:44:43 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:44:43 --> Helper loaded: form_helper
INFO - 2016-05-04 19:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:44:43 --> Form Validation Class Initialized
INFO - 2016-05-04 19:44:43 --> Controller Class Initialized
INFO - 2016-05-04 19:44:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:44:43 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:44:43 --> Model Class Initialized
INFO - 2016-05-04 19:44:43 --> Database Driver Class Initialized
INFO - 2016-05-04 19:44:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-04 19:44:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:44:43 --> Final output sent to browser
DEBUG - 2016-05-04 19:44:43 --> Total execution time: 0.1779
INFO - 2016-05-04 19:44:47 --> Config Class Initialized
INFO - 2016-05-04 19:44:47 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:44:47 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:44:47 --> Utf8 Class Initialized
INFO - 2016-05-04 19:44:47 --> URI Class Initialized
INFO - 2016-05-04 19:44:47 --> Router Class Initialized
INFO - 2016-05-04 19:44:47 --> Output Class Initialized
INFO - 2016-05-04 19:44:47 --> Security Class Initialized
DEBUG - 2016-05-04 19:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:44:47 --> Input Class Initialized
INFO - 2016-05-04 19:44:47 --> Language Class Initialized
INFO - 2016-05-04 19:44:47 --> Loader Class Initialized
INFO - 2016-05-04 19:44:47 --> Helper loaded: url_helper
INFO - 2016-05-04 19:44:48 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:44:48 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:44:48 --> Helper loaded: form_helper
INFO - 2016-05-04 19:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:44:48 --> Form Validation Class Initialized
INFO - 2016-05-04 19:44:48 --> Controller Class Initialized
INFO - 2016-05-04 19:44:48 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:44:48 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:44:48 --> Model Class Initialized
INFO - 2016-05-04 19:44:48 --> Database Driver Class Initialized
INFO - 2016-05-04 19:44:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:44:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:44:48 --> Final output sent to browser
DEBUG - 2016-05-04 19:44:48 --> Total execution time: 0.1222
INFO - 2016-05-04 19:45:21 --> Config Class Initialized
INFO - 2016-05-04 19:45:21 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:45:21 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:45:21 --> Utf8 Class Initialized
INFO - 2016-05-04 19:45:21 --> URI Class Initialized
INFO - 2016-05-04 19:45:21 --> Router Class Initialized
INFO - 2016-05-04 19:45:21 --> Output Class Initialized
INFO - 2016-05-04 19:45:21 --> Security Class Initialized
DEBUG - 2016-05-04 19:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:45:21 --> Input Class Initialized
INFO - 2016-05-04 19:45:21 --> Language Class Initialized
INFO - 2016-05-04 19:45:21 --> Loader Class Initialized
INFO - 2016-05-04 19:45:21 --> Helper loaded: url_helper
INFO - 2016-05-04 19:45:21 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:45:21 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:45:21 --> Helper loaded: form_helper
INFO - 2016-05-04 19:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:45:21 --> Form Validation Class Initialized
INFO - 2016-05-04 19:45:21 --> Controller Class Initialized
INFO - 2016-05-04 19:45:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:45:21 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:45:21 --> Model Class Initialized
INFO - 2016-05-04 19:45:21 --> Database Driver Class Initialized
INFO - 2016-05-04 19:45:21 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 19:45:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 19:45:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:45:21 --> Final output sent to browser
DEBUG - 2016-05-04 19:45:21 --> Total execution time: 0.1526
INFO - 2016-05-04 19:45:24 --> Config Class Initialized
INFO - 2016-05-04 19:45:24 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:45:24 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:45:24 --> Utf8 Class Initialized
INFO - 2016-05-04 19:45:24 --> URI Class Initialized
INFO - 2016-05-04 19:45:24 --> Router Class Initialized
INFO - 2016-05-04 19:45:24 --> Output Class Initialized
INFO - 2016-05-04 19:45:24 --> Security Class Initialized
DEBUG - 2016-05-04 19:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:45:24 --> Input Class Initialized
INFO - 2016-05-04 19:45:24 --> Language Class Initialized
INFO - 2016-05-04 19:45:24 --> Loader Class Initialized
INFO - 2016-05-04 19:45:24 --> Helper loaded: url_helper
INFO - 2016-05-04 19:45:24 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:45:24 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:45:24 --> Helper loaded: form_helper
INFO - 2016-05-04 19:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:45:24 --> Form Validation Class Initialized
INFO - 2016-05-04 19:45:24 --> Controller Class Initialized
INFO - 2016-05-04 19:45:24 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:45:24 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:45:24 --> Model Class Initialized
INFO - 2016-05-04 19:45:24 --> Database Driver Class Initialized
INFO - 2016-05-04 19:45:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:45:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:45:24 --> Final output sent to browser
DEBUG - 2016-05-04 19:45:24 --> Total execution time: 0.0966
INFO - 2016-05-04 19:49:19 --> Config Class Initialized
INFO - 2016-05-04 19:49:19 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:49:19 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:49:19 --> Utf8 Class Initialized
INFO - 2016-05-04 19:49:19 --> URI Class Initialized
INFO - 2016-05-04 19:49:19 --> Router Class Initialized
INFO - 2016-05-04 19:49:19 --> Output Class Initialized
INFO - 2016-05-04 19:49:19 --> Security Class Initialized
DEBUG - 2016-05-04 19:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:49:19 --> Input Class Initialized
INFO - 2016-05-04 19:49:19 --> Language Class Initialized
INFO - 2016-05-04 19:49:19 --> Loader Class Initialized
INFO - 2016-05-04 19:49:19 --> Helper loaded: url_helper
INFO - 2016-05-04 19:49:19 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:49:19 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:49:19 --> Helper loaded: form_helper
INFO - 2016-05-04 19:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:49:19 --> Form Validation Class Initialized
INFO - 2016-05-04 19:49:19 --> Controller Class Initialized
INFO - 2016-05-04 19:49:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:49:19 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:49:19 --> Model Class Initialized
INFO - 2016-05-04 19:49:19 --> Database Driver Class Initialized
INFO - 2016-05-04 19:49:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:49:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:49:19 --> Final output sent to browser
DEBUG - 2016-05-04 19:49:19 --> Total execution time: 0.1003
INFO - 2016-05-04 19:49:33 --> Config Class Initialized
INFO - 2016-05-04 19:49:33 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:49:33 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:49:33 --> Utf8 Class Initialized
INFO - 2016-05-04 19:49:33 --> URI Class Initialized
INFO - 2016-05-04 19:49:33 --> Router Class Initialized
INFO - 2016-05-04 19:49:33 --> Output Class Initialized
INFO - 2016-05-04 19:49:33 --> Security Class Initialized
DEBUG - 2016-05-04 19:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:49:33 --> Input Class Initialized
INFO - 2016-05-04 19:49:33 --> Language Class Initialized
INFO - 2016-05-04 19:49:33 --> Loader Class Initialized
INFO - 2016-05-04 19:49:33 --> Helper loaded: url_helper
INFO - 2016-05-04 19:49:33 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:49:33 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:49:33 --> Helper loaded: form_helper
INFO - 2016-05-04 19:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:49:33 --> Form Validation Class Initialized
INFO - 2016-05-04 19:49:33 --> Controller Class Initialized
INFO - 2016-05-04 19:49:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:49:33 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:49:33 --> Model Class Initialized
INFO - 2016-05-04 19:49:33 --> Database Driver Class Initialized
INFO - 2016-05-04 19:49:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:49:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:49:33 --> Final output sent to browser
DEBUG - 2016-05-04 19:49:33 --> Total execution time: 0.0783
INFO - 2016-05-04 19:51:39 --> Config Class Initialized
INFO - 2016-05-04 19:51:39 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:51:39 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:51:39 --> Utf8 Class Initialized
INFO - 2016-05-04 19:51:39 --> URI Class Initialized
INFO - 2016-05-04 19:51:39 --> Router Class Initialized
INFO - 2016-05-04 19:51:39 --> Output Class Initialized
INFO - 2016-05-04 19:51:39 --> Security Class Initialized
DEBUG - 2016-05-04 19:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:51:39 --> Input Class Initialized
INFO - 2016-05-04 19:51:39 --> Language Class Initialized
INFO - 2016-05-04 19:51:39 --> Loader Class Initialized
INFO - 2016-05-04 19:51:39 --> Helper loaded: url_helper
INFO - 2016-05-04 19:51:39 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:51:39 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:51:39 --> Helper loaded: form_helper
INFO - 2016-05-04 19:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:51:39 --> Form Validation Class Initialized
INFO - 2016-05-04 19:51:39 --> Controller Class Initialized
INFO - 2016-05-04 19:51:39 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:51:39 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:51:39 --> Model Class Initialized
INFO - 2016-05-04 19:51:39 --> Database Driver Class Initialized
INFO - 2016-05-04 19:51:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:51:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:51:39 --> Final output sent to browser
DEBUG - 2016-05-04 19:51:39 --> Total execution time: 0.0921
INFO - 2016-05-04 19:52:19 --> Config Class Initialized
INFO - 2016-05-04 19:52:19 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:52:19 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:52:19 --> Utf8 Class Initialized
INFO - 2016-05-04 19:52:19 --> URI Class Initialized
INFO - 2016-05-04 19:52:19 --> Router Class Initialized
INFO - 2016-05-04 19:52:19 --> Output Class Initialized
INFO - 2016-05-04 19:52:19 --> Security Class Initialized
DEBUG - 2016-05-04 19:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:52:19 --> Input Class Initialized
INFO - 2016-05-04 19:52:19 --> Language Class Initialized
INFO - 2016-05-04 19:52:19 --> Loader Class Initialized
INFO - 2016-05-04 19:52:19 --> Helper loaded: url_helper
INFO - 2016-05-04 19:52:19 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:52:19 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:52:19 --> Helper loaded: form_helper
INFO - 2016-05-04 19:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:52:19 --> Form Validation Class Initialized
INFO - 2016-05-04 19:52:19 --> Controller Class Initialized
INFO - 2016-05-04 19:52:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:52:19 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:52:19 --> Model Class Initialized
INFO - 2016-05-04 19:52:19 --> Database Driver Class Initialized
INFO - 2016-05-04 19:52:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:52:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:52:19 --> Final output sent to browser
DEBUG - 2016-05-04 19:52:19 --> Total execution time: 0.0805
INFO - 2016-05-04 19:54:18 --> Config Class Initialized
INFO - 2016-05-04 19:54:18 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:54:18 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:54:18 --> Utf8 Class Initialized
INFO - 2016-05-04 19:54:18 --> URI Class Initialized
INFO - 2016-05-04 19:54:18 --> Router Class Initialized
INFO - 2016-05-04 19:54:18 --> Output Class Initialized
INFO - 2016-05-04 19:54:18 --> Security Class Initialized
DEBUG - 2016-05-04 19:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:54:18 --> Input Class Initialized
INFO - 2016-05-04 19:54:18 --> Language Class Initialized
INFO - 2016-05-04 19:54:19 --> Loader Class Initialized
INFO - 2016-05-04 19:54:19 --> Helper loaded: url_helper
INFO - 2016-05-04 19:54:19 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:54:19 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:54:19 --> Helper loaded: form_helper
INFO - 2016-05-04 19:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:54:19 --> Form Validation Class Initialized
INFO - 2016-05-04 19:54:19 --> Controller Class Initialized
INFO - 2016-05-04 19:54:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:54:19 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:54:19 --> Model Class Initialized
INFO - 2016-05-04 19:54:19 --> Database Driver Class Initialized
INFO - 2016-05-04 19:54:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:54:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:54:19 --> Final output sent to browser
DEBUG - 2016-05-04 19:54:19 --> Total execution time: 0.1145
INFO - 2016-05-04 19:55:04 --> Config Class Initialized
INFO - 2016-05-04 19:55:04 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:55:04 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:55:04 --> Utf8 Class Initialized
INFO - 2016-05-04 19:55:04 --> URI Class Initialized
INFO - 2016-05-04 19:55:04 --> Router Class Initialized
INFO - 2016-05-04 19:55:04 --> Output Class Initialized
INFO - 2016-05-04 19:55:04 --> Security Class Initialized
DEBUG - 2016-05-04 19:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:55:04 --> Input Class Initialized
INFO - 2016-05-04 19:55:04 --> Language Class Initialized
INFO - 2016-05-04 19:55:04 --> Loader Class Initialized
INFO - 2016-05-04 19:55:04 --> Helper loaded: url_helper
INFO - 2016-05-04 19:55:04 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:55:04 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:55:04 --> Helper loaded: form_helper
INFO - 2016-05-04 19:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:55:04 --> Form Validation Class Initialized
INFO - 2016-05-04 19:55:04 --> Controller Class Initialized
INFO - 2016-05-04 19:55:04 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:55:04 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:55:04 --> Model Class Initialized
INFO - 2016-05-04 19:55:04 --> Database Driver Class Initialized
INFO - 2016-05-04 19:55:04 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 19:55:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:55:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:55:04 --> Final output sent to browser
DEBUG - 2016-05-04 19:55:04 --> Total execution time: 0.1564
INFO - 2016-05-04 19:55:37 --> Config Class Initialized
INFO - 2016-05-04 19:55:37 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:55:37 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:55:37 --> Utf8 Class Initialized
INFO - 2016-05-04 19:55:37 --> URI Class Initialized
INFO - 2016-05-04 19:55:37 --> Router Class Initialized
INFO - 2016-05-04 19:55:37 --> Output Class Initialized
INFO - 2016-05-04 19:55:37 --> Security Class Initialized
DEBUG - 2016-05-04 19:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:55:37 --> Input Class Initialized
INFO - 2016-05-04 19:55:37 --> Language Class Initialized
INFO - 2016-05-04 19:55:37 --> Loader Class Initialized
INFO - 2016-05-04 19:55:37 --> Helper loaded: url_helper
INFO - 2016-05-04 19:55:37 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:55:37 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:55:37 --> Helper loaded: form_helper
INFO - 2016-05-04 19:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:55:37 --> Form Validation Class Initialized
INFO - 2016-05-04 19:55:37 --> Controller Class Initialized
INFO - 2016-05-04 19:55:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:55:37 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:55:37 --> Model Class Initialized
INFO - 2016-05-04 19:55:37 --> Database Driver Class Initialized
INFO - 2016-05-04 19:55:37 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 19:55:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:55:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:55:37 --> Final output sent to browser
DEBUG - 2016-05-04 19:55:37 --> Total execution time: 0.1369
INFO - 2016-05-04 19:55:48 --> Config Class Initialized
INFO - 2016-05-04 19:55:48 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:55:48 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:55:48 --> Utf8 Class Initialized
INFO - 2016-05-04 19:55:48 --> URI Class Initialized
INFO - 2016-05-04 19:55:48 --> Router Class Initialized
INFO - 2016-05-04 19:55:48 --> Output Class Initialized
INFO - 2016-05-04 19:55:48 --> Security Class Initialized
DEBUG - 2016-05-04 19:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:55:48 --> Input Class Initialized
INFO - 2016-05-04 19:55:48 --> Language Class Initialized
INFO - 2016-05-04 19:55:48 --> Loader Class Initialized
INFO - 2016-05-04 19:55:48 --> Helper loaded: url_helper
INFO - 2016-05-04 19:55:48 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:55:48 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:55:48 --> Helper loaded: form_helper
INFO - 2016-05-04 19:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:55:48 --> Form Validation Class Initialized
INFO - 2016-05-04 19:55:48 --> Controller Class Initialized
INFO - 2016-05-04 19:55:48 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:55:48 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:55:48 --> Model Class Initialized
INFO - 2016-05-04 19:55:48 --> Database Driver Class Initialized
INFO - 2016-05-04 19:55:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:55:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:55:48 --> Final output sent to browser
DEBUG - 2016-05-04 19:55:48 --> Total execution time: 0.1005
INFO - 2016-05-04 19:57:53 --> Config Class Initialized
INFO - 2016-05-04 19:57:53 --> Hooks Class Initialized
DEBUG - 2016-05-04 19:57:53 --> UTF-8 Support Enabled
INFO - 2016-05-04 19:57:53 --> Utf8 Class Initialized
INFO - 2016-05-04 19:57:53 --> URI Class Initialized
INFO - 2016-05-04 19:57:53 --> Router Class Initialized
INFO - 2016-05-04 19:57:53 --> Output Class Initialized
INFO - 2016-05-04 19:57:53 --> Security Class Initialized
DEBUG - 2016-05-04 19:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 19:57:53 --> Input Class Initialized
INFO - 2016-05-04 19:57:53 --> Language Class Initialized
INFO - 2016-05-04 19:57:53 --> Loader Class Initialized
INFO - 2016-05-04 19:57:53 --> Helper loaded: url_helper
INFO - 2016-05-04 19:57:53 --> Helper loaded: sesion_helper
INFO - 2016-05-04 19:57:53 --> Helper loaded: templates_helper
INFO - 2016-05-04 19:57:53 --> Helper loaded: form_helper
INFO - 2016-05-04 19:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 19:57:53 --> Form Validation Class Initialized
INFO - 2016-05-04 19:57:53 --> Controller Class Initialized
INFO - 2016-05-04 19:57:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 19:57:53 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 19:57:53 --> Model Class Initialized
INFO - 2016-05-04 19:57:53 --> Database Driver Class Initialized
INFO - 2016-05-04 19:57:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 19:57:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 19:57:53 --> Final output sent to browser
DEBUG - 2016-05-04 19:57:53 --> Total execution time: 0.0910
INFO - 2016-05-04 20:00:45 --> Config Class Initialized
INFO - 2016-05-04 20:00:45 --> Hooks Class Initialized
DEBUG - 2016-05-04 20:00:45 --> UTF-8 Support Enabled
INFO - 2016-05-04 20:00:45 --> Utf8 Class Initialized
INFO - 2016-05-04 20:00:45 --> URI Class Initialized
INFO - 2016-05-04 20:00:45 --> Router Class Initialized
INFO - 2016-05-04 20:00:45 --> Output Class Initialized
INFO - 2016-05-04 20:00:45 --> Security Class Initialized
DEBUG - 2016-05-04 20:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 20:00:45 --> Input Class Initialized
INFO - 2016-05-04 20:00:45 --> Language Class Initialized
INFO - 2016-05-04 20:00:45 --> Loader Class Initialized
INFO - 2016-05-04 20:00:45 --> Helper loaded: url_helper
INFO - 2016-05-04 20:00:45 --> Helper loaded: sesion_helper
INFO - 2016-05-04 20:00:45 --> Helper loaded: templates_helper
INFO - 2016-05-04 20:00:45 --> Helper loaded: form_helper
INFO - 2016-05-04 20:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 20:00:45 --> Form Validation Class Initialized
INFO - 2016-05-04 20:00:45 --> Controller Class Initialized
INFO - 2016-05-04 20:00:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 20:00:45 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 20:00:45 --> Model Class Initialized
INFO - 2016-05-04 20:00:45 --> Database Driver Class Initialized
INFO - 2016-05-04 20:00:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 20:00:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 20:00:45 --> Final output sent to browser
DEBUG - 2016-05-04 20:00:45 --> Total execution time: 0.0946
INFO - 2016-05-04 20:03:01 --> Config Class Initialized
INFO - 2016-05-04 20:03:01 --> Hooks Class Initialized
DEBUG - 2016-05-04 20:03:01 --> UTF-8 Support Enabled
INFO - 2016-05-04 20:03:01 --> Utf8 Class Initialized
INFO - 2016-05-04 20:03:01 --> URI Class Initialized
INFO - 2016-05-04 20:03:01 --> Router Class Initialized
INFO - 2016-05-04 20:03:01 --> Output Class Initialized
INFO - 2016-05-04 20:03:01 --> Security Class Initialized
DEBUG - 2016-05-04 20:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 20:03:01 --> Input Class Initialized
INFO - 2016-05-04 20:03:01 --> Language Class Initialized
INFO - 2016-05-04 20:03:01 --> Loader Class Initialized
INFO - 2016-05-04 20:03:01 --> Helper loaded: url_helper
INFO - 2016-05-04 20:03:01 --> Helper loaded: sesion_helper
INFO - 2016-05-04 20:03:01 --> Helper loaded: templates_helper
INFO - 2016-05-04 20:03:01 --> Helper loaded: form_helper
INFO - 2016-05-04 20:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 20:03:01 --> Form Validation Class Initialized
INFO - 2016-05-04 20:03:01 --> Controller Class Initialized
INFO - 2016-05-04 20:03:01 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 20:03:01 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 20:03:01 --> Model Class Initialized
INFO - 2016-05-04 20:03:01 --> Database Driver Class Initialized
INFO - 2016-05-04 20:03:01 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-04 20:03:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 20:03:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 20:03:01 --> Final output sent to browser
DEBUG - 2016-05-04 20:03:01 --> Total execution time: 0.1864
INFO - 2016-05-04 20:03:08 --> Config Class Initialized
INFO - 2016-05-04 20:03:08 --> Hooks Class Initialized
DEBUG - 2016-05-04 20:03:08 --> UTF-8 Support Enabled
INFO - 2016-05-04 20:03:08 --> Utf8 Class Initialized
INFO - 2016-05-04 20:03:08 --> URI Class Initialized
INFO - 2016-05-04 20:03:08 --> Router Class Initialized
INFO - 2016-05-04 20:03:08 --> Output Class Initialized
INFO - 2016-05-04 20:03:08 --> Security Class Initialized
DEBUG - 2016-05-04 20:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 20:03:08 --> Input Class Initialized
INFO - 2016-05-04 20:03:08 --> Language Class Initialized
INFO - 2016-05-04 20:03:08 --> Loader Class Initialized
INFO - 2016-05-04 20:03:08 --> Helper loaded: url_helper
INFO - 2016-05-04 20:03:08 --> Helper loaded: sesion_helper
INFO - 2016-05-04 20:03:08 --> Helper loaded: templates_helper
INFO - 2016-05-04 20:03:08 --> Helper loaded: form_helper
INFO - 2016-05-04 20:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 20:03:08 --> Form Validation Class Initialized
INFO - 2016-05-04 20:03:08 --> Controller Class Initialized
INFO - 2016-05-04 20:03:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 20:03:08 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 20:03:08 --> Model Class Initialized
INFO - 2016-05-04 20:03:08 --> Database Driver Class Initialized
INFO - 2016-05-04 20:03:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-04 20:03:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 20:03:09 --> Final output sent to browser
DEBUG - 2016-05-04 20:03:09 --> Total execution time: 0.2068
INFO - 2016-05-04 20:07:34 --> Config Class Initialized
INFO - 2016-05-04 20:07:34 --> Hooks Class Initialized
DEBUG - 2016-05-04 20:07:34 --> UTF-8 Support Enabled
INFO - 2016-05-04 20:07:34 --> Utf8 Class Initialized
INFO - 2016-05-04 20:07:34 --> URI Class Initialized
INFO - 2016-05-04 20:07:34 --> Router Class Initialized
INFO - 2016-05-04 20:07:34 --> Output Class Initialized
INFO - 2016-05-04 20:07:34 --> Security Class Initialized
DEBUG - 2016-05-04 20:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 20:07:34 --> Input Class Initialized
INFO - 2016-05-04 20:07:34 --> Language Class Initialized
INFO - 2016-05-04 20:07:34 --> Loader Class Initialized
INFO - 2016-05-04 20:07:34 --> Helper loaded: url_helper
INFO - 2016-05-04 20:07:34 --> Helper loaded: sesion_helper
INFO - 2016-05-04 20:07:34 --> Helper loaded: templates_helper
INFO - 2016-05-04 20:07:34 --> Helper loaded: form_helper
INFO - 2016-05-04 20:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 20:07:34 --> Form Validation Class Initialized
INFO - 2016-05-04 20:07:34 --> Controller Class Initialized
INFO - 2016-05-04 20:07:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 20:07:34 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 20:07:34 --> Model Class Initialized
INFO - 2016-05-04 20:07:34 --> Database Driver Class Initialized
INFO - 2016-05-04 20:07:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 20:07:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 20:07:34 --> Final output sent to browser
DEBUG - 2016-05-04 20:07:34 --> Total execution time: 0.1640
INFO - 2016-05-04 20:07:38 --> Config Class Initialized
INFO - 2016-05-04 20:07:38 --> Hooks Class Initialized
DEBUG - 2016-05-04 20:07:38 --> UTF-8 Support Enabled
INFO - 2016-05-04 20:07:38 --> Utf8 Class Initialized
INFO - 2016-05-04 20:07:38 --> URI Class Initialized
INFO - 2016-05-04 20:07:38 --> Router Class Initialized
INFO - 2016-05-04 20:07:38 --> Output Class Initialized
INFO - 2016-05-04 20:07:38 --> Security Class Initialized
DEBUG - 2016-05-04 20:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 20:07:38 --> Input Class Initialized
INFO - 2016-05-04 20:07:38 --> Language Class Initialized
INFO - 2016-05-04 20:07:38 --> Loader Class Initialized
INFO - 2016-05-04 20:07:38 --> Helper loaded: url_helper
INFO - 2016-05-04 20:07:38 --> Helper loaded: sesion_helper
INFO - 2016-05-04 20:07:38 --> Helper loaded: templates_helper
INFO - 2016-05-04 20:07:38 --> Helper loaded: form_helper
INFO - 2016-05-04 20:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 20:07:38 --> Form Validation Class Initialized
INFO - 2016-05-04 20:07:38 --> Controller Class Initialized
INFO - 2016-05-04 20:07:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-04 20:07:38 --> Helper loaded: nif_validate_helper
INFO - 2016-05-04 20:07:38 --> Model Class Initialized
INFO - 2016-05-04 20:07:38 --> Database Driver Class Initialized
INFO - 2016-05-04 20:07:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-04 20:07:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 20:07:38 --> Final output sent to browser
DEBUG - 2016-05-04 20:07:38 --> Total execution time: 0.0796
INFO - 2016-05-04 20:07:41 --> Config Class Initialized
INFO - 2016-05-04 20:07:41 --> Hooks Class Initialized
DEBUG - 2016-05-04 20:07:41 --> UTF-8 Support Enabled
INFO - 2016-05-04 20:07:41 --> Utf8 Class Initialized
INFO - 2016-05-04 20:07:41 --> URI Class Initialized
INFO - 2016-05-04 20:07:41 --> Router Class Initialized
INFO - 2016-05-04 20:07:41 --> Output Class Initialized
INFO - 2016-05-04 20:07:41 --> Security Class Initialized
DEBUG - 2016-05-04 20:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 20:07:41 --> Input Class Initialized
INFO - 2016-05-04 20:07:41 --> Language Class Initialized
INFO - 2016-05-04 20:07:41 --> Loader Class Initialized
INFO - 2016-05-04 20:07:41 --> Helper loaded: url_helper
INFO - 2016-05-04 20:07:41 --> Helper loaded: sesion_helper
INFO - 2016-05-04 20:07:41 --> Helper loaded: templates_helper
INFO - 2016-05-04 20:07:41 --> Helper loaded: form_helper
INFO - 2016-05-04 20:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 20:07:41 --> Form Validation Class Initialized
INFO - 2016-05-04 20:07:41 --> Controller Class Initialized
INFO - 2016-05-04 20:07:41 --> Model Class Initialized
INFO - 2016-05-04 20:07:41 --> Database Driver Class Initialized
INFO - 2016-05-04 20:07:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 20:07:41 --> Pagination Class Initialized
DEBUG - 2016-05-04 20:07:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-04 20:07:41 --> Severity: Notice --> Undefined variable: proveedores C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 41
ERROR - 2016-05-04 20:07:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 41
INFO - 2016-05-04 20:07:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-04 20:07:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 20:07:41 --> Final output sent to browser
DEBUG - 2016-05-04 20:07:41 --> Total execution time: 0.1401
INFO - 2016-05-04 20:08:05 --> Config Class Initialized
INFO - 2016-05-04 20:08:05 --> Hooks Class Initialized
DEBUG - 2016-05-04 20:08:05 --> UTF-8 Support Enabled
INFO - 2016-05-04 20:08:05 --> Utf8 Class Initialized
INFO - 2016-05-04 20:08:05 --> URI Class Initialized
INFO - 2016-05-04 20:08:05 --> Router Class Initialized
INFO - 2016-05-04 20:08:05 --> Output Class Initialized
INFO - 2016-05-04 20:08:05 --> Security Class Initialized
DEBUG - 2016-05-04 20:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 20:08:05 --> Input Class Initialized
INFO - 2016-05-04 20:08:05 --> Language Class Initialized
INFO - 2016-05-04 20:08:05 --> Loader Class Initialized
INFO - 2016-05-04 20:08:05 --> Helper loaded: url_helper
INFO - 2016-05-04 20:08:05 --> Helper loaded: sesion_helper
INFO - 2016-05-04 20:08:05 --> Helper loaded: templates_helper
INFO - 2016-05-04 20:08:05 --> Helper loaded: form_helper
INFO - 2016-05-04 20:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 20:08:05 --> Form Validation Class Initialized
INFO - 2016-05-04 20:08:05 --> Controller Class Initialized
INFO - 2016-05-04 20:08:05 --> Model Class Initialized
INFO - 2016-05-04 20:08:05 --> Database Driver Class Initialized
INFO - 2016-05-04 20:08:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 20:08:05 --> Pagination Class Initialized
DEBUG - 2016-05-04 20:08:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-04 20:08:05 --> Severity: Notice --> Undefined index: nif C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 44
ERROR - 2016-05-04 20:08:05 --> Severity: Notice --> Undefined index: correo C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 45
ERROR - 2016-05-04 20:08:05 --> Severity: Notice --> Undefined index: telefono C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 46
ERROR - 2016-05-04 20:08:05 --> Severity: Notice --> Undefined index: nif C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 44
ERROR - 2016-05-04 20:08:05 --> Severity: Notice --> Undefined index: correo C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 45
ERROR - 2016-05-04 20:08:05 --> Severity: Notice --> Undefined index: telefono C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 46
ERROR - 2016-05-04 20:08:05 --> Severity: Notice --> Undefined index: nif C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 44
ERROR - 2016-05-04 20:08:05 --> Severity: Notice --> Undefined index: correo C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 45
ERROR - 2016-05-04 20:08:05 --> Severity: Notice --> Undefined index: telefono C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 46
ERROR - 2016-05-04 20:08:05 --> Severity: Notice --> Undefined index: nif C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 44
ERROR - 2016-05-04 20:08:05 --> Severity: Notice --> Undefined index: correo C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 45
ERROR - 2016-05-04 20:08:05 --> Severity: Notice --> Undefined index: telefono C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 46
INFO - 2016-05-04 20:08:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-04 20:08:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 20:08:05 --> Final output sent to browser
DEBUG - 2016-05-04 20:08:05 --> Total execution time: 0.1374
INFO - 2016-05-04 20:08:45 --> Config Class Initialized
INFO - 2016-05-04 20:08:45 --> Hooks Class Initialized
DEBUG - 2016-05-04 20:08:45 --> UTF-8 Support Enabled
INFO - 2016-05-04 20:08:45 --> Utf8 Class Initialized
INFO - 2016-05-04 20:08:45 --> URI Class Initialized
INFO - 2016-05-04 20:08:45 --> Router Class Initialized
INFO - 2016-05-04 20:08:45 --> Output Class Initialized
INFO - 2016-05-04 20:08:45 --> Security Class Initialized
DEBUG - 2016-05-04 20:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 20:08:45 --> Input Class Initialized
INFO - 2016-05-04 20:08:45 --> Language Class Initialized
INFO - 2016-05-04 20:08:45 --> Loader Class Initialized
INFO - 2016-05-04 20:08:45 --> Helper loaded: url_helper
INFO - 2016-05-04 20:08:45 --> Helper loaded: sesion_helper
INFO - 2016-05-04 20:08:46 --> Helper loaded: templates_helper
INFO - 2016-05-04 20:08:46 --> Helper loaded: form_helper
INFO - 2016-05-04 20:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 20:08:46 --> Form Validation Class Initialized
INFO - 2016-05-04 20:08:46 --> Controller Class Initialized
INFO - 2016-05-04 20:08:46 --> Model Class Initialized
INFO - 2016-05-04 20:08:46 --> Database Driver Class Initialized
INFO - 2016-05-04 20:08:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 20:08:46 --> Pagination Class Initialized
DEBUG - 2016-05-04 20:08:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-04 20:08:46 --> Severity: Notice --> Undefined index: nif C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 44
ERROR - 2016-05-04 20:08:46 --> Severity: Notice --> Undefined index: correo C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 45
ERROR - 2016-05-04 20:08:46 --> Severity: Notice --> Undefined index: telefono C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 46
ERROR - 2016-05-04 20:08:46 --> Severity: Notice --> Undefined index: nif C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 44
ERROR - 2016-05-04 20:08:46 --> Severity: Notice --> Undefined index: correo C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 45
ERROR - 2016-05-04 20:08:46 --> Severity: Notice --> Undefined index: telefono C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 46
ERROR - 2016-05-04 20:08:46 --> Severity: Notice --> Undefined index: nif C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 44
ERROR - 2016-05-04 20:08:46 --> Severity: Notice --> Undefined index: correo C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 45
ERROR - 2016-05-04 20:08:46 --> Severity: Notice --> Undefined index: telefono C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 46
ERROR - 2016-05-04 20:08:46 --> Severity: Notice --> Undefined index: nif C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 44
ERROR - 2016-05-04 20:08:46 --> Severity: Notice --> Undefined index: correo C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 45
ERROR - 2016-05-04 20:08:46 --> Severity: Notice --> Undefined index: telefono C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 46
INFO - 2016-05-04 20:08:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-04 20:08:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 20:08:46 --> Final output sent to browser
DEBUG - 2016-05-04 20:08:46 --> Total execution time: 0.1182
INFO - 2016-05-04 20:12:12 --> Config Class Initialized
INFO - 2016-05-04 20:12:12 --> Hooks Class Initialized
DEBUG - 2016-05-04 20:12:12 --> UTF-8 Support Enabled
INFO - 2016-05-04 20:12:12 --> Utf8 Class Initialized
INFO - 2016-05-04 20:12:12 --> URI Class Initialized
INFO - 2016-05-04 20:12:12 --> Router Class Initialized
INFO - 2016-05-04 20:12:12 --> Output Class Initialized
INFO - 2016-05-04 20:12:12 --> Security Class Initialized
DEBUG - 2016-05-04 20:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 20:12:12 --> Input Class Initialized
INFO - 2016-05-04 20:12:12 --> Language Class Initialized
INFO - 2016-05-04 20:12:12 --> Loader Class Initialized
INFO - 2016-05-04 20:12:12 --> Helper loaded: url_helper
INFO - 2016-05-04 20:12:12 --> Helper loaded: sesion_helper
INFO - 2016-05-04 20:12:12 --> Helper loaded: templates_helper
INFO - 2016-05-04 20:12:12 --> Helper loaded: form_helper
INFO - 2016-05-04 20:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 20:12:12 --> Form Validation Class Initialized
INFO - 2016-05-04 20:12:12 --> Controller Class Initialized
INFO - 2016-05-04 20:12:12 --> Model Class Initialized
INFO - 2016-05-04 20:12:13 --> Database Driver Class Initialized
INFO - 2016-05-04 20:12:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 20:12:13 --> Pagination Class Initialized
DEBUG - 2016-05-04 20:12:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 20:12:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-04 20:12:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 20:12:13 --> Final output sent to browser
DEBUG - 2016-05-04 20:12:13 --> Total execution time: 0.0926
INFO - 2016-05-04 20:13:33 --> Config Class Initialized
INFO - 2016-05-04 20:13:33 --> Hooks Class Initialized
DEBUG - 2016-05-04 20:13:33 --> UTF-8 Support Enabled
INFO - 2016-05-04 20:13:33 --> Utf8 Class Initialized
INFO - 2016-05-04 20:13:33 --> URI Class Initialized
INFO - 2016-05-04 20:13:33 --> Router Class Initialized
INFO - 2016-05-04 20:13:33 --> Output Class Initialized
INFO - 2016-05-04 20:13:33 --> Security Class Initialized
DEBUG - 2016-05-04 20:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 20:13:33 --> Input Class Initialized
INFO - 2016-05-04 20:13:33 --> Language Class Initialized
INFO - 2016-05-04 20:13:33 --> Loader Class Initialized
INFO - 2016-05-04 20:13:33 --> Helper loaded: url_helper
INFO - 2016-05-04 20:13:33 --> Helper loaded: sesion_helper
INFO - 2016-05-04 20:13:33 --> Helper loaded: templates_helper
INFO - 2016-05-04 20:13:33 --> Helper loaded: form_helper
INFO - 2016-05-04 20:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 20:13:33 --> Form Validation Class Initialized
INFO - 2016-05-04 20:13:33 --> Controller Class Initialized
INFO - 2016-05-04 20:13:33 --> Model Class Initialized
INFO - 2016-05-04 20:13:33 --> Database Driver Class Initialized
INFO - 2016-05-04 20:13:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 20:13:33 --> Pagination Class Initialized
DEBUG - 2016-05-04 20:13:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 20:13:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-04 20:13:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 20:13:33 --> Final output sent to browser
DEBUG - 2016-05-04 20:13:33 --> Total execution time: 0.0949
INFO - 2016-05-04 20:13:54 --> Config Class Initialized
INFO - 2016-05-04 20:13:54 --> Hooks Class Initialized
DEBUG - 2016-05-04 20:13:54 --> UTF-8 Support Enabled
INFO - 2016-05-04 20:13:54 --> Utf8 Class Initialized
INFO - 2016-05-04 20:13:54 --> URI Class Initialized
INFO - 2016-05-04 20:13:54 --> Router Class Initialized
INFO - 2016-05-04 20:13:54 --> Output Class Initialized
INFO - 2016-05-04 20:13:54 --> Security Class Initialized
DEBUG - 2016-05-04 20:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-04 20:13:54 --> Input Class Initialized
INFO - 2016-05-04 20:13:54 --> Language Class Initialized
INFO - 2016-05-04 20:13:54 --> Loader Class Initialized
INFO - 2016-05-04 20:13:54 --> Helper loaded: url_helper
INFO - 2016-05-04 20:13:54 --> Helper loaded: sesion_helper
INFO - 2016-05-04 20:13:54 --> Helper loaded: templates_helper
INFO - 2016-05-04 20:13:54 --> Helper loaded: form_helper
INFO - 2016-05-04 20:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-04 20:13:54 --> Form Validation Class Initialized
INFO - 2016-05-04 20:13:54 --> Controller Class Initialized
INFO - 2016-05-04 20:13:54 --> Model Class Initialized
INFO - 2016-05-04 20:13:54 --> Database Driver Class Initialized
INFO - 2016-05-04 20:13:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-04 20:13:54 --> Pagination Class Initialized
DEBUG - 2016-05-04 20:13:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-04 20:13:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-04 20:13:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-04 20:13:54 --> Final output sent to browser
DEBUG - 2016-05-04 20:13:54 --> Total execution time: 0.0990
