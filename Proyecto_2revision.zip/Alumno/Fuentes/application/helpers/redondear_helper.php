<?php

function getPrecio($precio){
    return round($precio, 2). ' €';
}

function getIva($iva){
    return round($iva, 2). ' %';
}
