<?php

$config['protocol'] = 'sendmail';
//$config['protocol'] = 'smtp';
$config['smtp_host'] = 'mail.iessansebastian.com';
$config['smtp_user'] = 'aula4@iessansebastian.com';
$config['smtp_pass'] = 'daw2alumno';
$config['mailtype'] = 'html';

