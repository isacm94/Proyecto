<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-04-30 18:36:38 --> Config Class Initialized
INFO - 2016-04-30 18:36:38 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:36:38 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:36:38 --> Utf8 Class Initialized
INFO - 2016-04-30 18:36:38 --> URI Class Initialized
INFO - 2016-04-30 18:36:38 --> Router Class Initialized
INFO - 2016-04-30 18:36:38 --> Output Class Initialized
INFO - 2016-04-30 18:36:38 --> Security Class Initialized
DEBUG - 2016-04-30 18:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:36:38 --> Input Class Initialized
INFO - 2016-04-30 18:36:38 --> Language Class Initialized
INFO - 2016-04-30 18:36:38 --> Loader Class Initialized
INFO - 2016-04-30 18:36:38 --> Helper loaded: url_helper
INFO - 2016-04-30 18:36:38 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:36:38 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:36:38 --> Helper loaded: form_helper
INFO - 2016-04-30 18:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:36:38 --> Form Validation Class Initialized
INFO - 2016-04-30 18:36:38 --> Controller Class Initialized
INFO - 2016-04-30 18:36:38 --> Config Class Initialized
INFO - 2016-04-30 18:36:38 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:36:38 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:36:38 --> Utf8 Class Initialized
INFO - 2016-04-30 18:36:38 --> URI Class Initialized
INFO - 2016-04-30 18:36:38 --> Router Class Initialized
INFO - 2016-04-30 18:36:38 --> Output Class Initialized
INFO - 2016-04-30 18:36:38 --> Security Class Initialized
DEBUG - 2016-04-30 18:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:36:38 --> Input Class Initialized
INFO - 2016-04-30 18:36:38 --> Language Class Initialized
INFO - 2016-04-30 18:36:38 --> Loader Class Initialized
INFO - 2016-04-30 18:36:38 --> Helper loaded: url_helper
INFO - 2016-04-30 18:36:38 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:36:38 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:36:38 --> Helper loaded: form_helper
INFO - 2016-04-30 18:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:36:38 --> Form Validation Class Initialized
INFO - 2016-04-30 18:36:38 --> Controller Class Initialized
INFO - 2016-04-30 18:36:38 --> Model Class Initialized
INFO - 2016-04-30 18:36:38 --> Database Driver Class Initialized
INFO - 2016-04-30 18:36:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-04-30 18:36:39 --> Final output sent to browser
DEBUG - 2016-04-30 18:36:39 --> Total execution time: 1.2616
INFO - 2016-04-30 18:36:51 --> Config Class Initialized
INFO - 2016-04-30 18:36:51 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:36:51 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:36:51 --> Utf8 Class Initialized
INFO - 2016-04-30 18:36:51 --> URI Class Initialized
INFO - 2016-04-30 18:36:51 --> Router Class Initialized
INFO - 2016-04-30 18:36:51 --> Output Class Initialized
INFO - 2016-04-30 18:36:51 --> Security Class Initialized
DEBUG - 2016-04-30 18:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:36:51 --> Input Class Initialized
INFO - 2016-04-30 18:36:51 --> Language Class Initialized
INFO - 2016-04-30 18:36:51 --> Loader Class Initialized
INFO - 2016-04-30 18:36:51 --> Helper loaded: url_helper
INFO - 2016-04-30 18:36:51 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:36:51 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:36:51 --> Helper loaded: form_helper
INFO - 2016-04-30 18:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:36:51 --> Form Validation Class Initialized
INFO - 2016-04-30 18:36:51 --> Controller Class Initialized
INFO - 2016-04-30 18:36:51 --> Model Class Initialized
INFO - 2016-04-30 18:36:51 --> Database Driver Class Initialized
INFO - 2016-04-30 18:36:51 --> Config Class Initialized
INFO - 2016-04-30 18:36:51 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:36:51 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:36:51 --> Utf8 Class Initialized
INFO - 2016-04-30 18:36:51 --> URI Class Initialized
INFO - 2016-04-30 18:36:51 --> Router Class Initialized
INFO - 2016-04-30 18:36:51 --> Output Class Initialized
INFO - 2016-04-30 18:36:51 --> Security Class Initialized
DEBUG - 2016-04-30 18:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:36:51 --> Input Class Initialized
INFO - 2016-04-30 18:36:51 --> Language Class Initialized
INFO - 2016-04-30 18:36:51 --> Loader Class Initialized
INFO - 2016-04-30 18:36:51 --> Helper loaded: url_helper
INFO - 2016-04-30 18:36:51 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:36:51 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:36:51 --> Helper loaded: form_helper
INFO - 2016-04-30 18:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:36:51 --> Form Validation Class Initialized
INFO - 2016-04-30 18:36:51 --> Controller Class Initialized
INFO - 2016-04-30 18:36:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-04-30 18:36:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-04-30 18:36:51 --> Final output sent to browser
DEBUG - 2016-04-30 18:36:51 --> Total execution time: 0.0492
INFO - 2016-04-30 18:36:56 --> Config Class Initialized
INFO - 2016-04-30 18:36:56 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:36:56 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:36:56 --> Utf8 Class Initialized
INFO - 2016-04-30 18:36:56 --> URI Class Initialized
INFO - 2016-04-30 18:36:56 --> Router Class Initialized
INFO - 2016-04-30 18:36:56 --> Output Class Initialized
INFO - 2016-04-30 18:36:56 --> Security Class Initialized
DEBUG - 2016-04-30 18:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:36:56 --> Input Class Initialized
INFO - 2016-04-30 18:36:56 --> Language Class Initialized
INFO - 2016-04-30 18:36:56 --> Loader Class Initialized
INFO - 2016-04-30 18:36:56 --> Helper loaded: url_helper
INFO - 2016-04-30 18:36:56 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:36:56 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:36:56 --> Helper loaded: form_helper
INFO - 2016-04-30 18:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:36:56 --> Form Validation Class Initialized
INFO - 2016-04-30 18:36:56 --> Controller Class Initialized
INFO - 2016-04-30 18:36:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-04-30 18:36:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-04-30 18:36:56 --> Final output sent to browser
DEBUG - 2016-04-30 18:36:56 --> Total execution time: 0.0560
INFO - 2016-04-30 18:36:58 --> Config Class Initialized
INFO - 2016-04-30 18:36:58 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:36:58 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:36:58 --> Utf8 Class Initialized
INFO - 2016-04-30 18:36:58 --> URI Class Initialized
INFO - 2016-04-30 18:36:58 --> Router Class Initialized
INFO - 2016-04-30 18:36:58 --> Output Class Initialized
INFO - 2016-04-30 18:36:58 --> Security Class Initialized
DEBUG - 2016-04-30 18:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:36:58 --> Input Class Initialized
INFO - 2016-04-30 18:36:58 --> Language Class Initialized
INFO - 2016-04-30 18:36:58 --> Loader Class Initialized
INFO - 2016-04-30 18:36:58 --> Helper loaded: url_helper
INFO - 2016-04-30 18:36:58 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:36:58 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:36:58 --> Helper loaded: form_helper
INFO - 2016-04-30 18:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:36:58 --> Form Validation Class Initialized
INFO - 2016-04-30 18:36:58 --> Controller Class Initialized
INFO - 2016-04-30 18:36:58 --> Config Class Initialized
INFO - 2016-04-30 18:36:58 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:36:58 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:36:58 --> Utf8 Class Initialized
INFO - 2016-04-30 18:36:58 --> URI Class Initialized
INFO - 2016-04-30 18:36:58 --> Router Class Initialized
INFO - 2016-04-30 18:36:58 --> Output Class Initialized
INFO - 2016-04-30 18:36:58 --> Security Class Initialized
DEBUG - 2016-04-30 18:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:36:58 --> Input Class Initialized
INFO - 2016-04-30 18:36:58 --> Language Class Initialized
INFO - 2016-04-30 18:36:58 --> Loader Class Initialized
INFO - 2016-04-30 18:36:58 --> Helper loaded: url_helper
INFO - 2016-04-30 18:36:58 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:36:58 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:36:58 --> Helper loaded: form_helper
INFO - 2016-04-30 18:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:36:58 --> Form Validation Class Initialized
INFO - 2016-04-30 18:36:58 --> Controller Class Initialized
INFO - 2016-04-30 18:36:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-04-30 18:36:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:36:58 --> Final output sent to browser
DEBUG - 2016-04-30 18:36:58 --> Total execution time: 0.0833
INFO - 2016-04-30 18:37:05 --> Config Class Initialized
INFO - 2016-04-30 18:37:05 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:37:05 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:37:05 --> Utf8 Class Initialized
INFO - 2016-04-30 18:37:05 --> URI Class Initialized
INFO - 2016-04-30 18:37:05 --> Router Class Initialized
INFO - 2016-04-30 18:37:05 --> Output Class Initialized
INFO - 2016-04-30 18:37:05 --> Security Class Initialized
DEBUG - 2016-04-30 18:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:37:05 --> Input Class Initialized
INFO - 2016-04-30 18:37:05 --> Language Class Initialized
INFO - 2016-04-30 18:37:05 --> Loader Class Initialized
INFO - 2016-04-30 18:37:05 --> Helper loaded: url_helper
INFO - 2016-04-30 18:37:05 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:37:05 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:37:05 --> Helper loaded: form_helper
INFO - 2016-04-30 18:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:37:05 --> Form Validation Class Initialized
INFO - 2016-04-30 18:37:05 --> Controller Class Initialized
INFO - 2016-04-30 18:37:05 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:37:05 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:37:05 --> Model Class Initialized
INFO - 2016-04-30 18:37:05 --> Database Driver Class Initialized
INFO - 2016-04-30 18:37:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:37:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:37:05 --> Final output sent to browser
DEBUG - 2016-04-30 18:37:05 --> Total execution time: 0.1219
INFO - 2016-04-30 18:37:39 --> Config Class Initialized
INFO - 2016-04-30 18:37:39 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:37:39 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:37:39 --> Utf8 Class Initialized
INFO - 2016-04-30 18:37:39 --> URI Class Initialized
INFO - 2016-04-30 18:37:39 --> Router Class Initialized
INFO - 2016-04-30 18:37:39 --> Output Class Initialized
INFO - 2016-04-30 18:37:39 --> Security Class Initialized
DEBUG - 2016-04-30 18:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:37:39 --> Input Class Initialized
INFO - 2016-04-30 18:37:39 --> Language Class Initialized
INFO - 2016-04-30 18:37:39 --> Loader Class Initialized
INFO - 2016-04-30 18:37:39 --> Helper loaded: url_helper
INFO - 2016-04-30 18:37:39 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:37:39 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:37:39 --> Helper loaded: form_helper
INFO - 2016-04-30 18:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:37:39 --> Form Validation Class Initialized
INFO - 2016-04-30 18:37:39 --> Controller Class Initialized
INFO - 2016-04-30 18:37:39 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:37:39 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:37:39 --> Model Class Initialized
INFO - 2016-04-30 18:37:39 --> Database Driver Class Initialized
INFO - 2016-04-30 18:37:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:37:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:37:39 --> Final output sent to browser
DEBUG - 2016-04-30 18:37:39 --> Total execution time: 0.1351
INFO - 2016-04-30 18:37:43 --> Config Class Initialized
INFO - 2016-04-30 18:37:43 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:37:43 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:37:43 --> Utf8 Class Initialized
INFO - 2016-04-30 18:37:43 --> URI Class Initialized
INFO - 2016-04-30 18:37:43 --> Router Class Initialized
INFO - 2016-04-30 18:37:43 --> Output Class Initialized
INFO - 2016-04-30 18:37:43 --> Security Class Initialized
DEBUG - 2016-04-30 18:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:37:43 --> Input Class Initialized
INFO - 2016-04-30 18:37:43 --> Language Class Initialized
INFO - 2016-04-30 18:37:43 --> Loader Class Initialized
INFO - 2016-04-30 18:37:43 --> Helper loaded: url_helper
INFO - 2016-04-30 18:37:43 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:37:43 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:37:43 --> Helper loaded: form_helper
INFO - 2016-04-30 18:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:37:43 --> Form Validation Class Initialized
INFO - 2016-04-30 18:37:43 --> Controller Class Initialized
INFO - 2016-04-30 18:37:43 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:37:43 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:37:43 --> Model Class Initialized
INFO - 2016-04-30 18:37:43 --> Database Driver Class Initialized
INFO - 2016-04-30 18:37:43 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:37:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:37:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:37:43 --> Final output sent to browser
DEBUG - 2016-04-30 18:37:43 --> Total execution time: 0.1314
INFO - 2016-04-30 18:38:32 --> Config Class Initialized
INFO - 2016-04-30 18:38:32 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:38:32 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:38:32 --> Utf8 Class Initialized
INFO - 2016-04-30 18:38:32 --> URI Class Initialized
INFO - 2016-04-30 18:38:32 --> Router Class Initialized
INFO - 2016-04-30 18:38:32 --> Output Class Initialized
INFO - 2016-04-30 18:38:32 --> Security Class Initialized
DEBUG - 2016-04-30 18:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:38:32 --> Input Class Initialized
INFO - 2016-04-30 18:38:32 --> Language Class Initialized
INFO - 2016-04-30 18:38:32 --> Loader Class Initialized
INFO - 2016-04-30 18:38:32 --> Helper loaded: url_helper
INFO - 2016-04-30 18:38:32 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:38:32 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:38:32 --> Helper loaded: form_helper
INFO - 2016-04-30 18:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:38:32 --> Form Validation Class Initialized
INFO - 2016-04-30 18:38:32 --> Controller Class Initialized
INFO - 2016-04-30 18:38:32 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:38:32 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:38:32 --> Model Class Initialized
INFO - 2016-04-30 18:38:32 --> Database Driver Class Initialized
INFO - 2016-04-30 18:38:32 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:38:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:38:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:38:32 --> Final output sent to browser
DEBUG - 2016-04-30 18:38:32 --> Total execution time: 0.1691
INFO - 2016-04-30 18:40:57 --> Config Class Initialized
INFO - 2016-04-30 18:40:57 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:40:57 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:40:57 --> Utf8 Class Initialized
INFO - 2016-04-30 18:40:57 --> URI Class Initialized
INFO - 2016-04-30 18:40:57 --> Router Class Initialized
INFO - 2016-04-30 18:40:57 --> Output Class Initialized
INFO - 2016-04-30 18:40:57 --> Security Class Initialized
DEBUG - 2016-04-30 18:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:40:57 --> Input Class Initialized
INFO - 2016-04-30 18:40:57 --> Language Class Initialized
INFO - 2016-04-30 18:40:57 --> Loader Class Initialized
INFO - 2016-04-30 18:40:57 --> Helper loaded: url_helper
INFO - 2016-04-30 18:40:57 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:40:57 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:40:57 --> Helper loaded: form_helper
INFO - 2016-04-30 18:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:40:57 --> Form Validation Class Initialized
INFO - 2016-04-30 18:40:57 --> Controller Class Initialized
INFO - 2016-04-30 18:40:57 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:40:57 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:40:57 --> Model Class Initialized
INFO - 2016-04-30 18:40:57 --> Database Driver Class Initialized
INFO - 2016-04-30 18:40:57 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-04-30 18:40:57 --> Query error: Unknown column 'cuentacorriente' in 'field list' - Invalid query: INSERT INTO `cliente` (`nombre`, `nif`, `correo`, `telefono`, `tipo`, `cuentacorriente`, `direccion`, `localidad`, `cp`, `provincia`, `anotaciones`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
INFO - 2016-04-30 18:40:57 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-04-30 18:41:29 --> Config Class Initialized
INFO - 2016-04-30 18:41:29 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:41:29 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:41:29 --> Utf8 Class Initialized
INFO - 2016-04-30 18:41:29 --> URI Class Initialized
INFO - 2016-04-30 18:41:29 --> Router Class Initialized
INFO - 2016-04-30 18:41:29 --> Output Class Initialized
INFO - 2016-04-30 18:41:29 --> Security Class Initialized
DEBUG - 2016-04-30 18:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:41:29 --> Input Class Initialized
INFO - 2016-04-30 18:41:29 --> Language Class Initialized
INFO - 2016-04-30 18:41:29 --> Loader Class Initialized
INFO - 2016-04-30 18:41:29 --> Helper loaded: url_helper
INFO - 2016-04-30 18:41:29 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:41:29 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:41:29 --> Helper loaded: form_helper
INFO - 2016-04-30 18:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:41:29 --> Form Validation Class Initialized
INFO - 2016-04-30 18:41:29 --> Controller Class Initialized
INFO - 2016-04-30 18:41:29 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:41:29 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:41:29 --> Model Class Initialized
INFO - 2016-04-30 18:41:29 --> Database Driver Class Initialized
INFO - 2016-04-30 18:41:29 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-04-30 18:41:29 --> Query error: Unknown column 'cuentacorriente' in 'field list' - Invalid query: INSERT INTO `cliente` (`nombre`, `nif`, `correo`, `telefono`, `tipo`, `cuentacorriente`, `direccion`, `localidad`, `cp`, `provincia`, `anotaciones`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
INFO - 2016-04-30 18:41:29 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-04-30 18:41:32 --> Config Class Initialized
INFO - 2016-04-30 18:41:32 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:41:32 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:41:32 --> Utf8 Class Initialized
INFO - 2016-04-30 18:41:32 --> URI Class Initialized
INFO - 2016-04-30 18:41:32 --> Router Class Initialized
INFO - 2016-04-30 18:41:32 --> Output Class Initialized
INFO - 2016-04-30 18:41:32 --> Security Class Initialized
DEBUG - 2016-04-30 18:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:41:32 --> Input Class Initialized
INFO - 2016-04-30 18:41:32 --> Language Class Initialized
INFO - 2016-04-30 18:41:32 --> Loader Class Initialized
INFO - 2016-04-30 18:41:32 --> Helper loaded: url_helper
INFO - 2016-04-30 18:41:32 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:41:32 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:41:32 --> Helper loaded: form_helper
INFO - 2016-04-30 18:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:41:32 --> Form Validation Class Initialized
INFO - 2016-04-30 18:41:32 --> Controller Class Initialized
INFO - 2016-04-30 18:41:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-04-30 18:41:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:41:32 --> Final output sent to browser
DEBUG - 2016-04-30 18:41:32 --> Total execution time: 0.0656
INFO - 2016-04-30 18:41:35 --> Config Class Initialized
INFO - 2016-04-30 18:41:35 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:41:35 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:41:35 --> Utf8 Class Initialized
INFO - 2016-04-30 18:41:35 --> URI Class Initialized
INFO - 2016-04-30 18:41:35 --> Router Class Initialized
INFO - 2016-04-30 18:41:35 --> Output Class Initialized
INFO - 2016-04-30 18:41:35 --> Security Class Initialized
DEBUG - 2016-04-30 18:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:41:35 --> Input Class Initialized
INFO - 2016-04-30 18:41:35 --> Language Class Initialized
INFO - 2016-04-30 18:41:35 --> Loader Class Initialized
INFO - 2016-04-30 18:41:35 --> Helper loaded: url_helper
INFO - 2016-04-30 18:41:35 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:41:35 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:41:35 --> Helper loaded: form_helper
INFO - 2016-04-30 18:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:41:35 --> Form Validation Class Initialized
INFO - 2016-04-30 18:41:35 --> Controller Class Initialized
INFO - 2016-04-30 18:41:35 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:41:35 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:41:35 --> Model Class Initialized
INFO - 2016-04-30 18:41:35 --> Database Driver Class Initialized
INFO - 2016-04-30 18:41:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:41:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:41:35 --> Final output sent to browser
DEBUG - 2016-04-30 18:41:35 --> Total execution time: 0.1403
INFO - 2016-04-30 18:42:24 --> Config Class Initialized
INFO - 2016-04-30 18:42:24 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:42:24 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:42:24 --> Utf8 Class Initialized
INFO - 2016-04-30 18:42:24 --> URI Class Initialized
INFO - 2016-04-30 18:42:24 --> Router Class Initialized
INFO - 2016-04-30 18:42:24 --> Output Class Initialized
INFO - 2016-04-30 18:42:24 --> Security Class Initialized
DEBUG - 2016-04-30 18:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:42:24 --> Input Class Initialized
INFO - 2016-04-30 18:42:24 --> Language Class Initialized
INFO - 2016-04-30 18:42:24 --> Loader Class Initialized
INFO - 2016-04-30 18:42:24 --> Helper loaded: url_helper
INFO - 2016-04-30 18:42:24 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:42:24 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:42:24 --> Helper loaded: form_helper
INFO - 2016-04-30 18:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:42:24 --> Form Validation Class Initialized
INFO - 2016-04-30 18:42:24 --> Controller Class Initialized
INFO - 2016-04-30 18:42:24 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:42:24 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:42:24 --> Model Class Initialized
INFO - 2016-04-30 18:42:24 --> Database Driver Class Initialized
INFO - 2016-04-30 18:42:24 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:42:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:42:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:42:24 --> Final output sent to browser
DEBUG - 2016-04-30 18:42:24 --> Total execution time: 0.1274
INFO - 2016-04-30 18:43:37 --> Config Class Initialized
INFO - 2016-04-30 18:43:37 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:43:37 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:43:37 --> Utf8 Class Initialized
INFO - 2016-04-30 18:43:37 --> URI Class Initialized
INFO - 2016-04-30 18:43:37 --> Router Class Initialized
INFO - 2016-04-30 18:43:37 --> Output Class Initialized
INFO - 2016-04-30 18:43:37 --> Security Class Initialized
DEBUG - 2016-04-30 18:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:43:37 --> Input Class Initialized
INFO - 2016-04-30 18:43:37 --> Language Class Initialized
INFO - 2016-04-30 18:43:37 --> Loader Class Initialized
INFO - 2016-04-30 18:43:37 --> Helper loaded: url_helper
INFO - 2016-04-30 18:43:37 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:43:37 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:43:37 --> Helper loaded: form_helper
INFO - 2016-04-30 18:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:43:37 --> Form Validation Class Initialized
INFO - 2016-04-30 18:43:37 --> Controller Class Initialized
INFO - 2016-04-30 18:43:37 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:43:37 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:43:37 --> Model Class Initialized
INFO - 2016-04-30 18:43:37 --> Database Driver Class Initialized
INFO - 2016-04-30 18:43:37 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:43:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:43:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:43:38 --> Final output sent to browser
DEBUG - 2016-04-30 18:43:38 --> Total execution time: 0.0839
INFO - 2016-04-30 18:44:00 --> Config Class Initialized
INFO - 2016-04-30 18:44:00 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:44:00 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:44:00 --> Utf8 Class Initialized
INFO - 2016-04-30 18:44:00 --> URI Class Initialized
INFO - 2016-04-30 18:44:00 --> Router Class Initialized
INFO - 2016-04-30 18:44:00 --> Output Class Initialized
INFO - 2016-04-30 18:44:00 --> Security Class Initialized
DEBUG - 2016-04-30 18:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:44:00 --> Input Class Initialized
INFO - 2016-04-30 18:44:00 --> Language Class Initialized
INFO - 2016-04-30 18:44:00 --> Loader Class Initialized
INFO - 2016-04-30 18:44:00 --> Helper loaded: url_helper
INFO - 2016-04-30 18:44:00 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:44:00 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:44:00 --> Helper loaded: form_helper
INFO - 2016-04-30 18:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:44:00 --> Form Validation Class Initialized
INFO - 2016-04-30 18:44:00 --> Controller Class Initialized
INFO - 2016-04-30 18:44:00 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:44:00 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:44:00 --> Model Class Initialized
INFO - 2016-04-30 18:44:00 --> Database Driver Class Initialized
INFO - 2016-04-30 18:44:00 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:44:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:44:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:44:00 --> Final output sent to browser
DEBUG - 2016-04-30 18:44:00 --> Total execution time: 0.0798
INFO - 2016-04-30 18:44:05 --> Config Class Initialized
INFO - 2016-04-30 18:44:05 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:44:05 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:44:05 --> Utf8 Class Initialized
INFO - 2016-04-30 18:44:05 --> URI Class Initialized
INFO - 2016-04-30 18:44:05 --> Router Class Initialized
INFO - 2016-04-30 18:44:05 --> Output Class Initialized
INFO - 2016-04-30 18:44:05 --> Security Class Initialized
DEBUG - 2016-04-30 18:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:44:05 --> Input Class Initialized
INFO - 2016-04-30 18:44:05 --> Language Class Initialized
INFO - 2016-04-30 18:44:05 --> Loader Class Initialized
INFO - 2016-04-30 18:44:05 --> Helper loaded: url_helper
INFO - 2016-04-30 18:44:05 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:44:05 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:44:05 --> Helper loaded: form_helper
INFO - 2016-04-30 18:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:44:05 --> Form Validation Class Initialized
INFO - 2016-04-30 18:44:05 --> Controller Class Initialized
INFO - 2016-04-30 18:44:05 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:44:05 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:44:05 --> Model Class Initialized
INFO - 2016-04-30 18:44:05 --> Database Driver Class Initialized
INFO - 2016-04-30 18:44:05 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:44:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:44:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:44:05 --> Final output sent to browser
DEBUG - 2016-04-30 18:44:05 --> Total execution time: 0.1751
INFO - 2016-04-30 18:44:45 --> Config Class Initialized
INFO - 2016-04-30 18:44:45 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:44:45 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:44:45 --> Utf8 Class Initialized
INFO - 2016-04-30 18:44:45 --> URI Class Initialized
INFO - 2016-04-30 18:44:45 --> Router Class Initialized
INFO - 2016-04-30 18:44:45 --> Output Class Initialized
INFO - 2016-04-30 18:44:45 --> Security Class Initialized
DEBUG - 2016-04-30 18:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:44:45 --> Input Class Initialized
INFO - 2016-04-30 18:44:45 --> Language Class Initialized
INFO - 2016-04-30 18:44:45 --> Loader Class Initialized
INFO - 2016-04-30 18:44:45 --> Helper loaded: url_helper
INFO - 2016-04-30 18:44:45 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:44:45 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:44:45 --> Helper loaded: form_helper
INFO - 2016-04-30 18:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:44:45 --> Form Validation Class Initialized
INFO - 2016-04-30 18:44:45 --> Controller Class Initialized
INFO - 2016-04-30 18:44:45 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:44:45 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:44:45 --> Model Class Initialized
INFO - 2016-04-30 18:44:45 --> Database Driver Class Initialized
INFO - 2016-04-30 18:44:45 --> Language file loaded: language/spanish/form_validation_lang.php
ERROR - 2016-04-30 18:44:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Agregar\Cliente.php 48
INFO - 2016-04-30 18:44:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:44:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:44:45 --> Final output sent to browser
DEBUG - 2016-04-30 18:44:45 --> Total execution time: 0.0910
INFO - 2016-04-30 18:45:17 --> Config Class Initialized
INFO - 2016-04-30 18:45:17 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:45:17 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:45:17 --> Utf8 Class Initialized
INFO - 2016-04-30 18:45:17 --> URI Class Initialized
INFO - 2016-04-30 18:45:17 --> Router Class Initialized
INFO - 2016-04-30 18:45:17 --> Output Class Initialized
INFO - 2016-04-30 18:45:17 --> Security Class Initialized
DEBUG - 2016-04-30 18:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:45:17 --> Input Class Initialized
INFO - 2016-04-30 18:45:17 --> Language Class Initialized
INFO - 2016-04-30 18:45:17 --> Loader Class Initialized
INFO - 2016-04-30 18:45:17 --> Helper loaded: url_helper
INFO - 2016-04-30 18:45:17 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:45:17 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:45:17 --> Helper loaded: form_helper
INFO - 2016-04-30 18:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:45:17 --> Form Validation Class Initialized
INFO - 2016-04-30 18:45:17 --> Controller Class Initialized
INFO - 2016-04-30 18:45:17 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:45:17 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:45:17 --> Model Class Initialized
INFO - 2016-04-30 18:45:17 --> Database Driver Class Initialized
INFO - 2016-04-30 18:45:17 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:45:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:45:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:45:17 --> Final output sent to browser
DEBUG - 2016-04-30 18:45:17 --> Total execution time: 0.0819
INFO - 2016-04-30 18:45:22 --> Config Class Initialized
INFO - 2016-04-30 18:45:22 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:45:22 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:45:22 --> Utf8 Class Initialized
INFO - 2016-04-30 18:45:22 --> URI Class Initialized
INFO - 2016-04-30 18:45:22 --> Router Class Initialized
INFO - 2016-04-30 18:45:22 --> Output Class Initialized
INFO - 2016-04-30 18:45:22 --> Security Class Initialized
DEBUG - 2016-04-30 18:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:45:22 --> Input Class Initialized
INFO - 2016-04-30 18:45:22 --> Language Class Initialized
INFO - 2016-04-30 18:45:22 --> Loader Class Initialized
INFO - 2016-04-30 18:45:22 --> Helper loaded: url_helper
INFO - 2016-04-30 18:45:22 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:45:22 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:45:22 --> Helper loaded: form_helper
INFO - 2016-04-30 18:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:45:22 --> Form Validation Class Initialized
INFO - 2016-04-30 18:45:22 --> Controller Class Initialized
INFO - 2016-04-30 18:45:22 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:45:22 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:45:22 --> Model Class Initialized
INFO - 2016-04-30 18:45:22 --> Database Driver Class Initialized
INFO - 2016-04-30 18:45:22 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:45:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:45:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:45:22 --> Final output sent to browser
DEBUG - 2016-04-30 18:45:22 --> Total execution time: 0.1722
INFO - 2016-04-30 18:45:59 --> Config Class Initialized
INFO - 2016-04-30 18:45:59 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:45:59 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:45:59 --> Utf8 Class Initialized
INFO - 2016-04-30 18:45:59 --> URI Class Initialized
INFO - 2016-04-30 18:45:59 --> Router Class Initialized
INFO - 2016-04-30 18:45:59 --> Output Class Initialized
INFO - 2016-04-30 18:45:59 --> Security Class Initialized
DEBUG - 2016-04-30 18:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:45:59 --> Input Class Initialized
INFO - 2016-04-30 18:45:59 --> Language Class Initialized
INFO - 2016-04-30 18:45:59 --> Loader Class Initialized
INFO - 2016-04-30 18:45:59 --> Helper loaded: url_helper
INFO - 2016-04-30 18:45:59 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:45:59 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:45:59 --> Helper loaded: form_helper
INFO - 2016-04-30 18:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:45:59 --> Form Validation Class Initialized
INFO - 2016-04-30 18:45:59 --> Controller Class Initialized
INFO - 2016-04-30 18:45:59 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:45:59 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:45:59 --> Model Class Initialized
INFO - 2016-04-30 18:45:59 --> Database Driver Class Initialized
INFO - 2016-04-30 18:45:59 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:45:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:45:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:45:59 --> Final output sent to browser
DEBUG - 2016-04-30 18:45:59 --> Total execution time: 0.0777
INFO - 2016-04-30 18:47:02 --> Config Class Initialized
INFO - 2016-04-30 18:47:02 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:47:02 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:47:02 --> Utf8 Class Initialized
INFO - 2016-04-30 18:47:02 --> URI Class Initialized
INFO - 2016-04-30 18:47:02 --> Router Class Initialized
INFO - 2016-04-30 18:47:02 --> Output Class Initialized
INFO - 2016-04-30 18:47:02 --> Security Class Initialized
DEBUG - 2016-04-30 18:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:47:02 --> Input Class Initialized
INFO - 2016-04-30 18:47:02 --> Language Class Initialized
INFO - 2016-04-30 18:47:02 --> Loader Class Initialized
INFO - 2016-04-30 18:47:02 --> Helper loaded: url_helper
INFO - 2016-04-30 18:47:02 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:47:02 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:47:02 --> Helper loaded: form_helper
INFO - 2016-04-30 18:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:47:02 --> Form Validation Class Initialized
INFO - 2016-04-30 18:47:02 --> Controller Class Initialized
INFO - 2016-04-30 18:47:02 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:47:02 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:47:02 --> Model Class Initialized
INFO - 2016-04-30 18:47:02 --> Database Driver Class Initialized
INFO - 2016-04-30 18:47:02 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:47:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:47:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:47:02 --> Final output sent to browser
DEBUG - 2016-04-30 18:47:02 --> Total execution time: 0.1244
INFO - 2016-04-30 18:47:50 --> Config Class Initialized
INFO - 2016-04-30 18:47:50 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:47:50 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:47:50 --> Utf8 Class Initialized
INFO - 2016-04-30 18:47:50 --> URI Class Initialized
INFO - 2016-04-30 18:47:50 --> Router Class Initialized
INFO - 2016-04-30 18:47:50 --> Output Class Initialized
INFO - 2016-04-30 18:47:50 --> Security Class Initialized
DEBUG - 2016-04-30 18:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:47:50 --> Input Class Initialized
INFO - 2016-04-30 18:47:50 --> Language Class Initialized
INFO - 2016-04-30 18:47:50 --> Loader Class Initialized
INFO - 2016-04-30 18:47:50 --> Helper loaded: url_helper
INFO - 2016-04-30 18:47:50 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:47:50 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:47:50 --> Helper loaded: form_helper
INFO - 2016-04-30 18:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:47:50 --> Form Validation Class Initialized
INFO - 2016-04-30 18:47:50 --> Controller Class Initialized
INFO - 2016-04-30 18:47:50 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:47:50 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:47:50 --> Model Class Initialized
INFO - 2016-04-30 18:47:50 --> Database Driver Class Initialized
INFO - 2016-04-30 18:47:50 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:47:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:47:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:47:50 --> Final output sent to browser
DEBUG - 2016-04-30 18:47:50 --> Total execution time: 0.1276
INFO - 2016-04-30 18:48:44 --> Config Class Initialized
INFO - 2016-04-30 18:48:44 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:48:44 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:48:44 --> Utf8 Class Initialized
INFO - 2016-04-30 18:48:44 --> URI Class Initialized
INFO - 2016-04-30 18:48:44 --> Router Class Initialized
INFO - 2016-04-30 18:48:44 --> Output Class Initialized
INFO - 2016-04-30 18:48:44 --> Security Class Initialized
DEBUG - 2016-04-30 18:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:48:44 --> Input Class Initialized
INFO - 2016-04-30 18:48:44 --> Language Class Initialized
INFO - 2016-04-30 18:48:44 --> Loader Class Initialized
INFO - 2016-04-30 18:48:44 --> Helper loaded: url_helper
INFO - 2016-04-30 18:48:44 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:48:44 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:48:44 --> Helper loaded: form_helper
INFO - 2016-04-30 18:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:48:44 --> Form Validation Class Initialized
INFO - 2016-04-30 18:48:44 --> Controller Class Initialized
INFO - 2016-04-30 18:48:44 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:48:44 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:48:44 --> Model Class Initialized
INFO - 2016-04-30 18:48:44 --> Database Driver Class Initialized
INFO - 2016-04-30 18:48:44 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:48:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:48:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:48:44 --> Final output sent to browser
DEBUG - 2016-04-30 18:48:44 --> Total execution time: 0.0807
INFO - 2016-04-30 18:49:34 --> Config Class Initialized
INFO - 2016-04-30 18:49:34 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:49:34 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:49:34 --> Utf8 Class Initialized
INFO - 2016-04-30 18:49:34 --> URI Class Initialized
INFO - 2016-04-30 18:49:34 --> Router Class Initialized
INFO - 2016-04-30 18:49:34 --> Output Class Initialized
INFO - 2016-04-30 18:49:34 --> Security Class Initialized
DEBUG - 2016-04-30 18:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:49:34 --> Input Class Initialized
INFO - 2016-04-30 18:49:34 --> Language Class Initialized
INFO - 2016-04-30 18:49:34 --> Loader Class Initialized
INFO - 2016-04-30 18:49:34 --> Helper loaded: url_helper
INFO - 2016-04-30 18:49:34 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:49:34 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:49:34 --> Helper loaded: form_helper
INFO - 2016-04-30 18:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:49:34 --> Form Validation Class Initialized
INFO - 2016-04-30 18:49:34 --> Controller Class Initialized
INFO - 2016-04-30 18:49:34 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:49:34 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:49:34 --> Model Class Initialized
INFO - 2016-04-30 18:49:34 --> Database Driver Class Initialized
INFO - 2016-04-30 18:49:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:49:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:49:34 --> Final output sent to browser
DEBUG - 2016-04-30 18:49:34 --> Total execution time: 0.0946
INFO - 2016-04-30 18:49:48 --> Config Class Initialized
INFO - 2016-04-30 18:49:48 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:49:48 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:49:48 --> Utf8 Class Initialized
INFO - 2016-04-30 18:49:48 --> URI Class Initialized
INFO - 2016-04-30 18:49:48 --> Router Class Initialized
INFO - 2016-04-30 18:49:48 --> Output Class Initialized
INFO - 2016-04-30 18:49:48 --> Security Class Initialized
DEBUG - 2016-04-30 18:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:49:48 --> Input Class Initialized
INFO - 2016-04-30 18:49:48 --> Language Class Initialized
INFO - 2016-04-30 18:49:48 --> Loader Class Initialized
INFO - 2016-04-30 18:49:48 --> Helper loaded: url_helper
INFO - 2016-04-30 18:49:48 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:49:48 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:49:48 --> Helper loaded: form_helper
INFO - 2016-04-30 18:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:49:48 --> Form Validation Class Initialized
INFO - 2016-04-30 18:49:48 --> Controller Class Initialized
INFO - 2016-04-30 18:49:48 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:49:48 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:49:48 --> Model Class Initialized
INFO - 2016-04-30 18:49:48 --> Database Driver Class Initialized
INFO - 2016-04-30 18:49:48 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:49:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:49:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:49:48 --> Final output sent to browser
DEBUG - 2016-04-30 18:49:48 --> Total execution time: 0.1145
INFO - 2016-04-30 18:50:16 --> Config Class Initialized
INFO - 2016-04-30 18:50:16 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:50:16 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:50:16 --> Utf8 Class Initialized
INFO - 2016-04-30 18:50:16 --> URI Class Initialized
INFO - 2016-04-30 18:50:16 --> Router Class Initialized
INFO - 2016-04-30 18:50:16 --> Output Class Initialized
INFO - 2016-04-30 18:50:16 --> Security Class Initialized
DEBUG - 2016-04-30 18:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:50:16 --> Input Class Initialized
INFO - 2016-04-30 18:50:16 --> Language Class Initialized
INFO - 2016-04-30 18:50:16 --> Loader Class Initialized
INFO - 2016-04-30 18:50:16 --> Helper loaded: url_helper
INFO - 2016-04-30 18:50:16 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:50:16 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:50:16 --> Helper loaded: form_helper
INFO - 2016-04-30 18:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:50:16 --> Form Validation Class Initialized
INFO - 2016-04-30 18:50:16 --> Controller Class Initialized
INFO - 2016-04-30 18:50:16 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:50:16 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:50:16 --> Model Class Initialized
INFO - 2016-04-30 18:50:16 --> Database Driver Class Initialized
INFO - 2016-04-30 18:50:16 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:50:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:50:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:50:16 --> Final output sent to browser
DEBUG - 2016-04-30 18:50:16 --> Total execution time: 0.0771
INFO - 2016-04-30 18:51:05 --> Config Class Initialized
INFO - 2016-04-30 18:51:05 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:51:05 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:51:05 --> Utf8 Class Initialized
INFO - 2016-04-30 18:51:05 --> URI Class Initialized
INFO - 2016-04-30 18:51:05 --> Router Class Initialized
INFO - 2016-04-30 18:51:05 --> Output Class Initialized
INFO - 2016-04-30 18:51:05 --> Security Class Initialized
DEBUG - 2016-04-30 18:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:51:05 --> Input Class Initialized
INFO - 2016-04-30 18:51:05 --> Language Class Initialized
INFO - 2016-04-30 18:51:05 --> Loader Class Initialized
INFO - 2016-04-30 18:51:05 --> Helper loaded: url_helper
INFO - 2016-04-30 18:51:05 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:51:05 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:51:05 --> Helper loaded: form_helper
INFO - 2016-04-30 18:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:51:05 --> Form Validation Class Initialized
INFO - 2016-04-30 18:51:05 --> Controller Class Initialized
INFO - 2016-04-30 18:51:05 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:51:05 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:51:05 --> Model Class Initialized
INFO - 2016-04-30 18:51:05 --> Database Driver Class Initialized
INFO - 2016-04-30 18:51:05 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:51:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:51:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:51:05 --> Final output sent to browser
DEBUG - 2016-04-30 18:51:05 --> Total execution time: 0.0835
INFO - 2016-04-30 18:51:19 --> Config Class Initialized
INFO - 2016-04-30 18:51:19 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:51:19 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:51:19 --> Utf8 Class Initialized
INFO - 2016-04-30 18:51:19 --> URI Class Initialized
INFO - 2016-04-30 18:51:19 --> Router Class Initialized
INFO - 2016-04-30 18:51:19 --> Output Class Initialized
INFO - 2016-04-30 18:51:19 --> Security Class Initialized
DEBUG - 2016-04-30 18:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:51:19 --> Input Class Initialized
INFO - 2016-04-30 18:51:19 --> Language Class Initialized
INFO - 2016-04-30 18:51:19 --> Loader Class Initialized
INFO - 2016-04-30 18:51:19 --> Helper loaded: url_helper
INFO - 2016-04-30 18:51:19 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:51:19 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:51:19 --> Helper loaded: form_helper
INFO - 2016-04-30 18:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:51:19 --> Form Validation Class Initialized
INFO - 2016-04-30 18:51:19 --> Controller Class Initialized
INFO - 2016-04-30 18:51:19 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:51:19 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:51:19 --> Model Class Initialized
INFO - 2016-04-30 18:51:19 --> Database Driver Class Initialized
INFO - 2016-04-30 18:51:19 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:51:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:51:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:51:19 --> Final output sent to browser
DEBUG - 2016-04-30 18:51:19 --> Total execution time: 0.1087
INFO - 2016-04-30 18:52:44 --> Config Class Initialized
INFO - 2016-04-30 18:52:44 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:52:44 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:52:44 --> Utf8 Class Initialized
INFO - 2016-04-30 18:52:44 --> URI Class Initialized
INFO - 2016-04-30 18:52:44 --> Router Class Initialized
INFO - 2016-04-30 18:52:44 --> Output Class Initialized
INFO - 2016-04-30 18:52:44 --> Security Class Initialized
DEBUG - 2016-04-30 18:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:52:44 --> Input Class Initialized
INFO - 2016-04-30 18:52:44 --> Language Class Initialized
INFO - 2016-04-30 18:52:44 --> Loader Class Initialized
INFO - 2016-04-30 18:52:44 --> Helper loaded: url_helper
INFO - 2016-04-30 18:52:44 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:52:44 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:52:44 --> Helper loaded: form_helper
INFO - 2016-04-30 18:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:52:44 --> Form Validation Class Initialized
INFO - 2016-04-30 18:52:44 --> Controller Class Initialized
INFO - 2016-04-30 18:52:44 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:52:44 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:52:44 --> Model Class Initialized
INFO - 2016-04-30 18:52:44 --> Database Driver Class Initialized
INFO - 2016-04-30 18:52:44 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:52:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:52:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:52:44 --> Final output sent to browser
DEBUG - 2016-04-30 18:52:44 --> Total execution time: 0.0772
INFO - 2016-04-30 18:54:38 --> Config Class Initialized
INFO - 2016-04-30 18:54:38 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:54:38 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:54:38 --> Utf8 Class Initialized
INFO - 2016-04-30 18:54:38 --> URI Class Initialized
INFO - 2016-04-30 18:54:38 --> Router Class Initialized
INFO - 2016-04-30 18:54:38 --> Output Class Initialized
INFO - 2016-04-30 18:54:38 --> Security Class Initialized
DEBUG - 2016-04-30 18:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:54:38 --> Input Class Initialized
INFO - 2016-04-30 18:54:38 --> Language Class Initialized
INFO - 2016-04-30 18:54:38 --> Loader Class Initialized
INFO - 2016-04-30 18:54:38 --> Helper loaded: url_helper
INFO - 2016-04-30 18:54:38 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:54:38 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:54:38 --> Helper loaded: form_helper
INFO - 2016-04-30 18:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:54:38 --> Form Validation Class Initialized
INFO - 2016-04-30 18:54:38 --> Controller Class Initialized
INFO - 2016-04-30 18:54:38 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:54:38 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:54:38 --> Model Class Initialized
INFO - 2016-04-30 18:54:38 --> Database Driver Class Initialized
INFO - 2016-04-30 18:54:38 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:54:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:54:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:54:38 --> Final output sent to browser
DEBUG - 2016-04-30 18:54:38 --> Total execution time: 0.0811
INFO - 2016-04-30 18:54:57 --> Config Class Initialized
INFO - 2016-04-30 18:54:57 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:54:57 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:54:57 --> Utf8 Class Initialized
INFO - 2016-04-30 18:54:57 --> URI Class Initialized
INFO - 2016-04-30 18:54:57 --> Router Class Initialized
INFO - 2016-04-30 18:54:57 --> Output Class Initialized
INFO - 2016-04-30 18:54:57 --> Security Class Initialized
DEBUG - 2016-04-30 18:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:54:57 --> Input Class Initialized
INFO - 2016-04-30 18:54:57 --> Language Class Initialized
INFO - 2016-04-30 18:54:57 --> Loader Class Initialized
INFO - 2016-04-30 18:54:57 --> Helper loaded: url_helper
INFO - 2016-04-30 18:54:57 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:54:57 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:54:57 --> Helper loaded: form_helper
INFO - 2016-04-30 18:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:54:57 --> Form Validation Class Initialized
INFO - 2016-04-30 18:54:57 --> Controller Class Initialized
INFO - 2016-04-30 18:54:57 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:54:57 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:54:57 --> Model Class Initialized
INFO - 2016-04-30 18:54:57 --> Database Driver Class Initialized
INFO - 2016-04-30 18:54:57 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:54:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:54:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:54:57 --> Final output sent to browser
DEBUG - 2016-04-30 18:54:57 --> Total execution time: 0.1249
INFO - 2016-04-30 18:56:15 --> Config Class Initialized
INFO - 2016-04-30 18:56:15 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:56:15 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:56:15 --> Utf8 Class Initialized
INFO - 2016-04-30 18:56:15 --> URI Class Initialized
INFO - 2016-04-30 18:56:15 --> Router Class Initialized
INFO - 2016-04-30 18:56:15 --> Output Class Initialized
INFO - 2016-04-30 18:56:15 --> Security Class Initialized
DEBUG - 2016-04-30 18:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:56:15 --> Input Class Initialized
INFO - 2016-04-30 18:56:15 --> Language Class Initialized
INFO - 2016-04-30 18:56:15 --> Loader Class Initialized
INFO - 2016-04-30 18:56:15 --> Helper loaded: url_helper
INFO - 2016-04-30 18:56:15 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:56:15 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:56:15 --> Helper loaded: form_helper
INFO - 2016-04-30 18:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:56:15 --> Form Validation Class Initialized
INFO - 2016-04-30 18:56:15 --> Controller Class Initialized
INFO - 2016-04-30 18:56:15 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:56:15 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:56:15 --> Model Class Initialized
INFO - 2016-04-30 18:56:15 --> Database Driver Class Initialized
INFO - 2016-04-30 18:56:15 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:56:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:56:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:56:15 --> Final output sent to browser
DEBUG - 2016-04-30 18:56:15 --> Total execution time: 0.1255
INFO - 2016-04-30 18:56:25 --> Config Class Initialized
INFO - 2016-04-30 18:56:25 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:56:25 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:56:25 --> Utf8 Class Initialized
INFO - 2016-04-30 18:56:25 --> URI Class Initialized
INFO - 2016-04-30 18:56:25 --> Router Class Initialized
INFO - 2016-04-30 18:56:25 --> Output Class Initialized
INFO - 2016-04-30 18:56:25 --> Security Class Initialized
DEBUG - 2016-04-30 18:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:56:25 --> Input Class Initialized
INFO - 2016-04-30 18:56:25 --> Language Class Initialized
INFO - 2016-04-30 18:56:25 --> Loader Class Initialized
INFO - 2016-04-30 18:56:25 --> Helper loaded: url_helper
INFO - 2016-04-30 18:56:25 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:56:25 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:56:25 --> Helper loaded: form_helper
INFO - 2016-04-30 18:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:56:25 --> Form Validation Class Initialized
INFO - 2016-04-30 18:56:25 --> Controller Class Initialized
INFO - 2016-04-30 18:56:25 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:56:25 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:56:25 --> Model Class Initialized
INFO - 2016-04-30 18:56:25 --> Database Driver Class Initialized
INFO - 2016-04-30 18:56:25 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:56:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:56:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:56:25 --> Final output sent to browser
DEBUG - 2016-04-30 18:56:25 --> Total execution time: 0.0758
INFO - 2016-04-30 18:57:16 --> Config Class Initialized
INFO - 2016-04-30 18:57:16 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:57:16 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:57:16 --> Utf8 Class Initialized
INFO - 2016-04-30 18:57:16 --> URI Class Initialized
INFO - 2016-04-30 18:57:16 --> Router Class Initialized
INFO - 2016-04-30 18:57:16 --> Output Class Initialized
INFO - 2016-04-30 18:57:16 --> Security Class Initialized
DEBUG - 2016-04-30 18:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:57:16 --> Input Class Initialized
INFO - 2016-04-30 18:57:16 --> Language Class Initialized
INFO - 2016-04-30 18:57:16 --> Loader Class Initialized
INFO - 2016-04-30 18:57:16 --> Helper loaded: url_helper
INFO - 2016-04-30 18:57:16 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:57:16 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:57:16 --> Helper loaded: form_helper
INFO - 2016-04-30 18:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:57:16 --> Form Validation Class Initialized
INFO - 2016-04-30 18:57:16 --> Controller Class Initialized
INFO - 2016-04-30 18:57:16 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:57:16 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:57:16 --> Model Class Initialized
INFO - 2016-04-30 18:57:16 --> Database Driver Class Initialized
INFO - 2016-04-30 18:57:16 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:57:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:57:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:57:16 --> Final output sent to browser
DEBUG - 2016-04-30 18:57:16 --> Total execution time: 0.0797
INFO - 2016-04-30 18:58:19 --> Config Class Initialized
INFO - 2016-04-30 18:58:19 --> Hooks Class Initialized
DEBUG - 2016-04-30 18:58:19 --> UTF-8 Support Enabled
INFO - 2016-04-30 18:58:19 --> Utf8 Class Initialized
INFO - 2016-04-30 18:58:19 --> URI Class Initialized
INFO - 2016-04-30 18:58:19 --> Router Class Initialized
INFO - 2016-04-30 18:58:19 --> Output Class Initialized
INFO - 2016-04-30 18:58:19 --> Security Class Initialized
DEBUG - 2016-04-30 18:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 18:58:19 --> Input Class Initialized
INFO - 2016-04-30 18:58:19 --> Language Class Initialized
INFO - 2016-04-30 18:58:19 --> Loader Class Initialized
INFO - 2016-04-30 18:58:19 --> Helper loaded: url_helper
INFO - 2016-04-30 18:58:19 --> Helper loaded: sesion_helper
INFO - 2016-04-30 18:58:19 --> Helper loaded: templates_helper
INFO - 2016-04-30 18:58:19 --> Helper loaded: form_helper
INFO - 2016-04-30 18:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 18:58:19 --> Form Validation Class Initialized
INFO - 2016-04-30 18:58:19 --> Controller Class Initialized
INFO - 2016-04-30 18:58:19 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 18:58:19 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 18:58:19 --> Model Class Initialized
INFO - 2016-04-30 18:58:19 --> Database Driver Class Initialized
INFO - 2016-04-30 18:58:19 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 18:58:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 18:58:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 18:58:19 --> Final output sent to browser
DEBUG - 2016-04-30 18:58:19 --> Total execution time: 0.1952
INFO - 2016-04-30 19:05:50 --> Config Class Initialized
INFO - 2016-04-30 19:05:50 --> Hooks Class Initialized
DEBUG - 2016-04-30 19:05:50 --> UTF-8 Support Enabled
INFO - 2016-04-30 19:05:50 --> Utf8 Class Initialized
INFO - 2016-04-30 19:05:50 --> URI Class Initialized
INFO - 2016-04-30 19:05:50 --> Router Class Initialized
INFO - 2016-04-30 19:05:50 --> Output Class Initialized
INFO - 2016-04-30 19:05:50 --> Security Class Initialized
DEBUG - 2016-04-30 19:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 19:05:50 --> Input Class Initialized
INFO - 2016-04-30 19:05:50 --> Language Class Initialized
INFO - 2016-04-30 19:05:50 --> Loader Class Initialized
INFO - 2016-04-30 19:05:50 --> Helper loaded: url_helper
INFO - 2016-04-30 19:05:50 --> Helper loaded: sesion_helper
INFO - 2016-04-30 19:05:50 --> Helper loaded: templates_helper
INFO - 2016-04-30 19:05:50 --> Helper loaded: form_helper
INFO - 2016-04-30 19:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 19:05:50 --> Form Validation Class Initialized
INFO - 2016-04-30 19:05:50 --> Controller Class Initialized
INFO - 2016-04-30 19:05:50 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 19:05:50 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 19:05:50 --> Model Class Initialized
INFO - 2016-04-30 19:05:50 --> Database Driver Class Initialized
INFO - 2016-04-30 19:05:50 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 19:05:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 19:05:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 19:05:50 --> Final output sent to browser
DEBUG - 2016-04-30 19:05:50 --> Total execution time: 0.1592
INFO - 2016-04-30 19:06:19 --> Config Class Initialized
INFO - 2016-04-30 19:06:19 --> Hooks Class Initialized
DEBUG - 2016-04-30 19:06:19 --> UTF-8 Support Enabled
INFO - 2016-04-30 19:06:19 --> Utf8 Class Initialized
INFO - 2016-04-30 19:06:19 --> URI Class Initialized
INFO - 2016-04-30 19:06:19 --> Router Class Initialized
INFO - 2016-04-30 19:06:19 --> Output Class Initialized
INFO - 2016-04-30 19:06:19 --> Security Class Initialized
DEBUG - 2016-04-30 19:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-30 19:06:19 --> Input Class Initialized
INFO - 2016-04-30 19:06:19 --> Language Class Initialized
INFO - 2016-04-30 19:06:19 --> Loader Class Initialized
INFO - 2016-04-30 19:06:19 --> Helper loaded: url_helper
INFO - 2016-04-30 19:06:19 --> Helper loaded: sesion_helper
INFO - 2016-04-30 19:06:19 --> Helper loaded: templates_helper
INFO - 2016-04-30 19:06:19 --> Helper loaded: form_helper
INFO - 2016-04-30 19:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-30 19:06:19 --> Form Validation Class Initialized
INFO - 2016-04-30 19:06:19 --> Controller Class Initialized
INFO - 2016-04-30 19:06:19 --> Helper loaded: creaselect_helper
INFO - 2016-04-30 19:06:19 --> Helper loaded: nif_validate_helper
INFO - 2016-04-30 19:06:19 --> Model Class Initialized
INFO - 2016-04-30 19:06:19 --> Database Driver Class Initialized
INFO - 2016-04-30 19:06:19 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-04-30 19:06:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addCliente.php
INFO - 2016-04-30 19:06:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-04-30 19:06:19 --> Final output sent to browser
DEBUG - 2016-04-30 19:06:19 --> Total execution time: 0.1324
