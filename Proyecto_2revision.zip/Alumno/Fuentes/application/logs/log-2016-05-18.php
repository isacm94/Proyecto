<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-18 18:19:40 --> Config Class Initialized
INFO - 2016-05-18 18:19:40 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:19:40 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:19:40 --> Utf8 Class Initialized
INFO - 2016-05-18 18:19:40 --> URI Class Initialized
INFO - 2016-05-18 18:19:40 --> Router Class Initialized
INFO - 2016-05-18 18:19:40 --> Output Class Initialized
INFO - 2016-05-18 18:19:40 --> Security Class Initialized
DEBUG - 2016-05-18 18:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:19:40 --> Input Class Initialized
INFO - 2016-05-18 18:19:40 --> Language Class Initialized
INFO - 2016-05-18 18:19:40 --> Loader Class Initialized
INFO - 2016-05-18 18:19:40 --> Helper loaded: url_helper
INFO - 2016-05-18 18:19:40 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:19:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:19:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:19:40 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:19:40 --> Helper loaded: form_helper
INFO - 2016-05-18 18:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:19:40 --> Form Validation Class Initialized
INFO - 2016-05-18 18:19:40 --> Controller Class Initialized
INFO - 2016-05-18 18:19:40 --> Config Class Initialized
INFO - 2016-05-18 18:19:40 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:19:40 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:19:40 --> Utf8 Class Initialized
INFO - 2016-05-18 18:19:40 --> URI Class Initialized
INFO - 2016-05-18 18:19:40 --> Router Class Initialized
INFO - 2016-05-18 18:19:40 --> Output Class Initialized
INFO - 2016-05-18 18:19:40 --> Security Class Initialized
DEBUG - 2016-05-18 18:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:19:40 --> Input Class Initialized
INFO - 2016-05-18 18:19:40 --> Language Class Initialized
INFO - 2016-05-18 18:19:40 --> Loader Class Initialized
INFO - 2016-05-18 18:19:40 --> Helper loaded: url_helper
INFO - 2016-05-18 18:19:40 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:19:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:19:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:19:40 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:19:40 --> Helper loaded: form_helper
INFO - 2016-05-18 18:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:19:40 --> Form Validation Class Initialized
INFO - 2016-05-18 18:19:40 --> Controller Class Initialized
INFO - 2016-05-18 18:19:40 --> Model Class Initialized
INFO - 2016-05-18 18:19:40 --> Database Driver Class Initialized
INFO - 2016-05-18 18:19:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-18 18:19:40 --> Final output sent to browser
DEBUG - 2016-05-18 18:19:40 --> Total execution time: 0.0957
INFO - 2016-05-18 18:21:10 --> Config Class Initialized
INFO - 2016-05-18 18:21:10 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:21:10 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:21:10 --> Utf8 Class Initialized
INFO - 2016-05-18 18:21:10 --> URI Class Initialized
INFO - 2016-05-18 18:21:10 --> Router Class Initialized
INFO - 2016-05-18 18:21:10 --> Output Class Initialized
INFO - 2016-05-18 18:21:10 --> Security Class Initialized
DEBUG - 2016-05-18 18:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:21:10 --> Input Class Initialized
INFO - 2016-05-18 18:21:10 --> Language Class Initialized
INFO - 2016-05-18 18:21:10 --> Loader Class Initialized
INFO - 2016-05-18 18:21:10 --> Helper loaded: url_helper
INFO - 2016-05-18 18:21:10 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:21:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:21:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:21:10 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:21:10 --> Helper loaded: form_helper
INFO - 2016-05-18 18:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:21:10 --> Form Validation Class Initialized
INFO - 2016-05-18 18:21:10 --> Controller Class Initialized
INFO - 2016-05-18 18:21:10 --> Model Class Initialized
INFO - 2016-05-18 18:21:10 --> Database Driver Class Initialized
INFO - 2016-05-18 18:21:10 --> Config Class Initialized
INFO - 2016-05-18 18:21:10 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:21:10 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:21:10 --> Utf8 Class Initialized
INFO - 2016-05-18 18:21:10 --> URI Class Initialized
INFO - 2016-05-18 18:21:10 --> Router Class Initialized
INFO - 2016-05-18 18:21:10 --> Output Class Initialized
INFO - 2016-05-18 18:21:10 --> Security Class Initialized
DEBUG - 2016-05-18 18:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:21:10 --> Input Class Initialized
INFO - 2016-05-18 18:21:10 --> Language Class Initialized
INFO - 2016-05-18 18:21:10 --> Loader Class Initialized
INFO - 2016-05-18 18:21:10 --> Helper loaded: url_helper
INFO - 2016-05-18 18:21:10 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:21:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:21:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:21:10 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:21:10 --> Helper loaded: form_helper
INFO - 2016-05-18 18:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:21:10 --> Form Validation Class Initialized
INFO - 2016-05-18 18:21:10 --> Controller Class Initialized
INFO - 2016-05-18 18:21:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-18 18:21:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:21:10 --> Final output sent to browser
DEBUG - 2016-05-18 18:21:10 --> Total execution time: 0.0548
INFO - 2016-05-18 18:21:11 --> Config Class Initialized
INFO - 2016-05-18 18:21:11 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:21:11 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:21:11 --> Utf8 Class Initialized
INFO - 2016-05-18 18:21:11 --> URI Class Initialized
INFO - 2016-05-18 18:21:11 --> Router Class Initialized
INFO - 2016-05-18 18:21:11 --> Output Class Initialized
INFO - 2016-05-18 18:21:11 --> Security Class Initialized
DEBUG - 2016-05-18 18:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:21:11 --> Input Class Initialized
INFO - 2016-05-18 18:21:11 --> Language Class Initialized
INFO - 2016-05-18 18:21:11 --> Loader Class Initialized
INFO - 2016-05-18 18:21:11 --> Helper loaded: url_helper
INFO - 2016-05-18 18:21:11 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:21:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:21:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:21:11 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:21:11 --> Helper loaded: form_helper
INFO - 2016-05-18 18:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:21:11 --> Form Validation Class Initialized
INFO - 2016-05-18 18:21:11 --> Controller Class Initialized
INFO - 2016-05-18 18:21:11 --> Model Class Initialized
INFO - 2016-05-18 18:21:11 --> Database Driver Class Initialized
INFO - 2016-05-18 18:21:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:21:11 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:21:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:21:12 --> Final output sent to browser
DEBUG - 2016-05-18 18:21:12 --> Total execution time: 0.2118
INFO - 2016-05-18 18:22:12 --> Config Class Initialized
INFO - 2016-05-18 18:22:12 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:22:12 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:22:12 --> Utf8 Class Initialized
INFO - 2016-05-18 18:22:12 --> URI Class Initialized
INFO - 2016-05-18 18:22:12 --> Router Class Initialized
INFO - 2016-05-18 18:22:12 --> Output Class Initialized
INFO - 2016-05-18 18:22:12 --> Security Class Initialized
DEBUG - 2016-05-18 18:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:22:12 --> Input Class Initialized
INFO - 2016-05-18 18:22:12 --> Language Class Initialized
INFO - 2016-05-18 18:22:12 --> Loader Class Initialized
INFO - 2016-05-18 18:22:12 --> Helper loaded: url_helper
INFO - 2016-05-18 18:22:12 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:22:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:22:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:22:12 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:22:12 --> Helper loaded: form_helper
INFO - 2016-05-18 18:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:22:12 --> Form Validation Class Initialized
INFO - 2016-05-18 18:22:12 --> Controller Class Initialized
INFO - 2016-05-18 18:22:12 --> Model Class Initialized
INFO - 2016-05-18 18:22:12 --> Database Driver Class Initialized
INFO - 2016-05-18 18:22:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:22:12 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:22:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:22:12 --> Final output sent to browser
DEBUG - 2016-05-18 18:22:12 --> Total execution time: 0.0934
INFO - 2016-05-18 18:22:52 --> Config Class Initialized
INFO - 2016-05-18 18:22:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:22:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:22:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:22:52 --> URI Class Initialized
INFO - 2016-05-18 18:22:52 --> Router Class Initialized
INFO - 2016-05-18 18:22:52 --> Output Class Initialized
INFO - 2016-05-18 18:22:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:22:52 --> Input Class Initialized
INFO - 2016-05-18 18:22:52 --> Language Class Initialized
INFO - 2016-05-18 18:22:52 --> Loader Class Initialized
INFO - 2016-05-18 18:22:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:22:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:22:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:22:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:22:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:22:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:22:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:22:52 --> Controller Class Initialized
INFO - 2016-05-18 18:22:52 --> Model Class Initialized
INFO - 2016-05-18 18:22:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:22:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:22:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:22:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:22:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturas.php
INFO - 2016-05-18 18:22:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:22:52 --> Final output sent to browser
DEBUG - 2016-05-18 18:22:52 --> Total execution time: 0.0835
INFO - 2016-05-18 18:22:52 --> Config Class Initialized
INFO - 2016-05-18 18:22:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:22:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:22:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:22:52 --> URI Class Initialized
INFO - 2016-05-18 18:22:52 --> Router Class Initialized
INFO - 2016-05-18 18:22:52 --> Output Class Initialized
INFO - 2016-05-18 18:22:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:22:52 --> Input Class Initialized
INFO - 2016-05-18 18:22:52 --> Language Class Initialized
INFO - 2016-05-18 18:22:52 --> Loader Class Initialized
INFO - 2016-05-18 18:22:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:22:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:22:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:22:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:22:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:22:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:22:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:22:52 --> Controller Class Initialized
INFO - 2016-05-18 18:22:52 --> Model Class Initialized
INFO - 2016-05-18 18:22:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:22:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:22:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:22:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:22:52 --> Final output sent to browser
DEBUG - 2016-05-18 18:22:52 --> Total execution time: 0.1086
INFO - 2016-05-18 18:23:52 --> Config Class Initialized
INFO - 2016-05-18 18:23:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:23:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:23:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:23:52 --> URI Class Initialized
INFO - 2016-05-18 18:23:52 --> Router Class Initialized
INFO - 2016-05-18 18:23:52 --> Output Class Initialized
INFO - 2016-05-18 18:23:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:23:52 --> Input Class Initialized
INFO - 2016-05-18 18:23:52 --> Language Class Initialized
INFO - 2016-05-18 18:23:52 --> Loader Class Initialized
INFO - 2016-05-18 18:23:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:23:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:23:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:23:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:23:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:23:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:23:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:23:52 --> Controller Class Initialized
INFO - 2016-05-18 18:23:52 --> Model Class Initialized
INFO - 2016-05-18 18:23:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:23:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:23:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:23:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:23:52 --> Final output sent to browser
DEBUG - 2016-05-18 18:23:52 --> Total execution time: 0.1243
INFO - 2016-05-18 18:24:52 --> Config Class Initialized
INFO - 2016-05-18 18:24:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:24:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:24:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:24:52 --> URI Class Initialized
INFO - 2016-05-18 18:24:52 --> Router Class Initialized
INFO - 2016-05-18 18:24:52 --> Output Class Initialized
INFO - 2016-05-18 18:24:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:24:52 --> Input Class Initialized
INFO - 2016-05-18 18:24:52 --> Language Class Initialized
INFO - 2016-05-18 18:24:52 --> Loader Class Initialized
INFO - 2016-05-18 18:24:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:24:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:24:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:24:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:24:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:24:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:24:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:24:52 --> Controller Class Initialized
INFO - 2016-05-18 18:24:52 --> Model Class Initialized
INFO - 2016-05-18 18:24:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:24:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:24:53 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:24:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:24:53 --> Final output sent to browser
DEBUG - 2016-05-18 18:24:53 --> Total execution time: 0.2594
INFO - 2016-05-18 18:25:52 --> Config Class Initialized
INFO - 2016-05-18 18:25:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:25:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:25:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:25:52 --> URI Class Initialized
INFO - 2016-05-18 18:25:52 --> Router Class Initialized
INFO - 2016-05-18 18:25:52 --> Output Class Initialized
INFO - 2016-05-18 18:25:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:25:52 --> Input Class Initialized
INFO - 2016-05-18 18:25:52 --> Language Class Initialized
INFO - 2016-05-18 18:25:52 --> Loader Class Initialized
INFO - 2016-05-18 18:25:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:25:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:25:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:25:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:25:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:25:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:25:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:25:52 --> Controller Class Initialized
INFO - 2016-05-18 18:25:52 --> Model Class Initialized
INFO - 2016-05-18 18:25:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:25:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:25:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:25:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:25:52 --> Final output sent to browser
DEBUG - 2016-05-18 18:25:52 --> Total execution time: 0.0875
INFO - 2016-05-18 18:26:52 --> Config Class Initialized
INFO - 2016-05-18 18:26:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:26:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:26:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:26:52 --> URI Class Initialized
INFO - 2016-05-18 18:26:52 --> Router Class Initialized
INFO - 2016-05-18 18:26:52 --> Output Class Initialized
INFO - 2016-05-18 18:26:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:26:52 --> Input Class Initialized
INFO - 2016-05-18 18:26:52 --> Language Class Initialized
INFO - 2016-05-18 18:26:52 --> Loader Class Initialized
INFO - 2016-05-18 18:26:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:26:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:26:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:26:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:26:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:26:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:26:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:26:52 --> Controller Class Initialized
INFO - 2016-05-18 18:26:52 --> Model Class Initialized
INFO - 2016-05-18 18:26:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:26:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:26:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:26:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:26:52 --> Final output sent to browser
DEBUG - 2016-05-18 18:26:52 --> Total execution time: 0.1000
INFO - 2016-05-18 18:27:52 --> Config Class Initialized
INFO - 2016-05-18 18:27:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:27:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:27:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:27:52 --> URI Class Initialized
INFO - 2016-05-18 18:27:52 --> Router Class Initialized
INFO - 2016-05-18 18:27:52 --> Output Class Initialized
INFO - 2016-05-18 18:27:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:27:52 --> Input Class Initialized
INFO - 2016-05-18 18:27:52 --> Language Class Initialized
INFO - 2016-05-18 18:27:52 --> Loader Class Initialized
INFO - 2016-05-18 18:27:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:27:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:27:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:27:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:27:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:27:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:27:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:27:52 --> Controller Class Initialized
INFO - 2016-05-18 18:27:52 --> Model Class Initialized
INFO - 2016-05-18 18:27:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:27:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:27:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:27:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:27:52 --> Final output sent to browser
DEBUG - 2016-05-18 18:27:52 --> Total execution time: 0.1084
INFO - 2016-05-18 18:28:52 --> Config Class Initialized
INFO - 2016-05-18 18:28:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:28:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:28:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:28:52 --> URI Class Initialized
INFO - 2016-05-18 18:28:52 --> Router Class Initialized
INFO - 2016-05-18 18:28:52 --> Output Class Initialized
INFO - 2016-05-18 18:28:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:28:52 --> Input Class Initialized
INFO - 2016-05-18 18:28:52 --> Language Class Initialized
INFO - 2016-05-18 18:28:52 --> Loader Class Initialized
INFO - 2016-05-18 18:28:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:28:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:28:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:28:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:28:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:28:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:28:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:28:52 --> Controller Class Initialized
INFO - 2016-05-18 18:28:52 --> Model Class Initialized
INFO - 2016-05-18 18:28:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:28:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:28:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:28:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:28:52 --> Final output sent to browser
DEBUG - 2016-05-18 18:28:52 --> Total execution time: 0.0780
INFO - 2016-05-18 18:29:52 --> Config Class Initialized
INFO - 2016-05-18 18:29:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:29:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:29:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:29:52 --> URI Class Initialized
INFO - 2016-05-18 18:29:52 --> Router Class Initialized
INFO - 2016-05-18 18:29:52 --> Output Class Initialized
INFO - 2016-05-18 18:29:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:29:52 --> Input Class Initialized
INFO - 2016-05-18 18:29:52 --> Language Class Initialized
INFO - 2016-05-18 18:29:52 --> Loader Class Initialized
INFO - 2016-05-18 18:29:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:29:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:29:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:29:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:29:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:29:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:29:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:29:52 --> Controller Class Initialized
INFO - 2016-05-18 18:29:52 --> Model Class Initialized
INFO - 2016-05-18 18:29:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:29:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:29:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:29:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:29:52 --> Final output sent to browser
DEBUG - 2016-05-18 18:29:52 --> Total execution time: 0.0817
INFO - 2016-05-18 18:30:52 --> Config Class Initialized
INFO - 2016-05-18 18:30:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:30:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:30:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:30:52 --> URI Class Initialized
INFO - 2016-05-18 18:30:52 --> Router Class Initialized
INFO - 2016-05-18 18:30:52 --> Output Class Initialized
INFO - 2016-05-18 18:30:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:30:52 --> Input Class Initialized
INFO - 2016-05-18 18:30:52 --> Language Class Initialized
INFO - 2016-05-18 18:30:52 --> Loader Class Initialized
INFO - 2016-05-18 18:30:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:30:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:30:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:30:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:30:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:30:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:30:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:30:52 --> Controller Class Initialized
INFO - 2016-05-18 18:30:52 --> Model Class Initialized
INFO - 2016-05-18 18:30:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:30:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:30:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:30:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:30:52 --> Final output sent to browser
DEBUG - 2016-05-18 18:30:52 --> Total execution time: 0.1241
INFO - 2016-05-18 18:31:52 --> Config Class Initialized
INFO - 2016-05-18 18:31:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:31:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:31:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:31:52 --> URI Class Initialized
INFO - 2016-05-18 18:31:52 --> Router Class Initialized
INFO - 2016-05-18 18:31:52 --> Output Class Initialized
INFO - 2016-05-18 18:31:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:31:52 --> Input Class Initialized
INFO - 2016-05-18 18:31:52 --> Language Class Initialized
INFO - 2016-05-18 18:31:52 --> Loader Class Initialized
INFO - 2016-05-18 18:31:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:31:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:31:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:31:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:31:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:31:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:31:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:31:52 --> Controller Class Initialized
INFO - 2016-05-18 18:31:52 --> Model Class Initialized
INFO - 2016-05-18 18:31:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:31:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:31:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:31:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:31:52 --> Final output sent to browser
DEBUG - 2016-05-18 18:31:52 --> Total execution time: 0.1167
INFO - 2016-05-18 18:32:52 --> Config Class Initialized
INFO - 2016-05-18 18:32:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:32:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:32:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:32:52 --> URI Class Initialized
INFO - 2016-05-18 18:32:52 --> Router Class Initialized
INFO - 2016-05-18 18:32:52 --> Output Class Initialized
INFO - 2016-05-18 18:32:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:32:52 --> Input Class Initialized
INFO - 2016-05-18 18:32:52 --> Language Class Initialized
INFO - 2016-05-18 18:32:52 --> Loader Class Initialized
INFO - 2016-05-18 18:32:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:32:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:32:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:32:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:32:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:32:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:32:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:32:52 --> Controller Class Initialized
INFO - 2016-05-18 18:32:52 --> Model Class Initialized
INFO - 2016-05-18 18:32:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:32:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:32:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:32:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:32:52 --> Final output sent to browser
DEBUG - 2016-05-18 18:32:52 --> Total execution time: 0.0779
INFO - 2016-05-18 18:32:53 --> Config Class Initialized
INFO - 2016-05-18 18:32:53 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:32:53 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:32:53 --> Utf8 Class Initialized
INFO - 2016-05-18 18:32:53 --> URI Class Initialized
INFO - 2016-05-18 18:32:53 --> Router Class Initialized
INFO - 2016-05-18 18:32:53 --> Output Class Initialized
INFO - 2016-05-18 18:32:53 --> Security Class Initialized
DEBUG - 2016-05-18 18:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:32:53 --> Input Class Initialized
INFO - 2016-05-18 18:32:53 --> Language Class Initialized
INFO - 2016-05-18 18:32:53 --> Loader Class Initialized
INFO - 2016-05-18 18:32:53 --> Helper loaded: url_helper
INFO - 2016-05-18 18:32:53 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:32:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:32:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:32:53 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:32:53 --> Helper loaded: form_helper
INFO - 2016-05-18 18:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:32:53 --> Form Validation Class Initialized
INFO - 2016-05-18 18:32:53 --> Controller Class Initialized
INFO - 2016-05-18 18:32:53 --> Model Class Initialized
INFO - 2016-05-18 18:32:53 --> Database Driver Class Initialized
INFO - 2016-05-18 18:32:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:32:53 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:32:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:32:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-18 18:32:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:32:53 --> Final output sent to browser
DEBUG - 2016-05-18 18:32:53 --> Total execution time: 0.0781
INFO - 2016-05-18 18:32:54 --> Config Class Initialized
INFO - 2016-05-18 18:32:54 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:32:54 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:32:54 --> Utf8 Class Initialized
INFO - 2016-05-18 18:32:54 --> URI Class Initialized
INFO - 2016-05-18 18:32:54 --> Router Class Initialized
INFO - 2016-05-18 18:32:54 --> Output Class Initialized
INFO - 2016-05-18 18:32:54 --> Security Class Initialized
DEBUG - 2016-05-18 18:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:32:54 --> Input Class Initialized
INFO - 2016-05-18 18:32:54 --> Language Class Initialized
INFO - 2016-05-18 18:32:54 --> Loader Class Initialized
INFO - 2016-05-18 18:32:54 --> Helper loaded: url_helper
INFO - 2016-05-18 18:32:54 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:32:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:32:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:32:54 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:32:54 --> Helper loaded: form_helper
INFO - 2016-05-18 18:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:32:54 --> Form Validation Class Initialized
INFO - 2016-05-18 18:32:54 --> Controller Class Initialized
INFO - 2016-05-18 18:32:54 --> Model Class Initialized
INFO - 2016-05-18 18:32:54 --> Database Driver Class Initialized
INFO - 2016-05-18 18:32:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:32:54 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:32:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:32:54 --> Final output sent to browser
DEBUG - 2016-05-18 18:32:54 --> Total execution time: 0.0966
INFO - 2016-05-18 18:32:59 --> Config Class Initialized
INFO - 2016-05-18 18:32:59 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:32:59 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:32:59 --> Utf8 Class Initialized
INFO - 2016-05-18 18:32:59 --> URI Class Initialized
INFO - 2016-05-18 18:32:59 --> Router Class Initialized
INFO - 2016-05-18 18:32:59 --> Output Class Initialized
INFO - 2016-05-18 18:32:59 --> Security Class Initialized
DEBUG - 2016-05-18 18:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:32:59 --> Input Class Initialized
INFO - 2016-05-18 18:32:59 --> Language Class Initialized
INFO - 2016-05-18 18:32:59 --> Loader Class Initialized
INFO - 2016-05-18 18:32:59 --> Helper loaded: url_helper
INFO - 2016-05-18 18:32:59 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:32:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:32:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:32:59 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:32:59 --> Helper loaded: form_helper
INFO - 2016-05-18 18:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:32:59 --> Form Validation Class Initialized
INFO - 2016-05-18 18:32:59 --> Controller Class Initialized
INFO - 2016-05-18 18:32:59 --> Model Class Initialized
INFO - 2016-05-18 18:32:59 --> Database Driver Class Initialized
INFO - 2016-05-18 18:32:59 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:32:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:32:59 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:32:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:32:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-18 18:32:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:32:59 --> Final output sent to browser
DEBUG - 2016-05-18 18:32:59 --> Total execution time: 0.0977
INFO - 2016-05-18 18:33:00 --> Config Class Initialized
INFO - 2016-05-18 18:33:00 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:33:00 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:33:00 --> Utf8 Class Initialized
INFO - 2016-05-18 18:33:00 --> URI Class Initialized
INFO - 2016-05-18 18:33:00 --> Router Class Initialized
INFO - 2016-05-18 18:33:00 --> Output Class Initialized
INFO - 2016-05-18 18:33:00 --> Security Class Initialized
DEBUG - 2016-05-18 18:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:33:00 --> Input Class Initialized
INFO - 2016-05-18 18:33:00 --> Language Class Initialized
INFO - 2016-05-18 18:33:00 --> Loader Class Initialized
INFO - 2016-05-18 18:33:00 --> Helper loaded: url_helper
INFO - 2016-05-18 18:33:00 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:33:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:33:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:33:00 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:33:00 --> Helper loaded: form_helper
INFO - 2016-05-18 18:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:33:00 --> Form Validation Class Initialized
INFO - 2016-05-18 18:33:00 --> Controller Class Initialized
INFO - 2016-05-18 18:33:00 --> Model Class Initialized
INFO - 2016-05-18 18:33:00 --> Database Driver Class Initialized
INFO - 2016-05-18 18:33:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:33:00 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:33:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:33:00 --> Final output sent to browser
DEBUG - 2016-05-18 18:33:00 --> Total execution time: 0.0794
INFO - 2016-05-18 18:33:05 --> Config Class Initialized
INFO - 2016-05-18 18:33:05 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:33:05 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:33:05 --> Utf8 Class Initialized
INFO - 2016-05-18 18:33:05 --> URI Class Initialized
INFO - 2016-05-18 18:33:05 --> Router Class Initialized
INFO - 2016-05-18 18:33:05 --> Output Class Initialized
INFO - 2016-05-18 18:33:05 --> Security Class Initialized
DEBUG - 2016-05-18 18:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:33:05 --> Input Class Initialized
INFO - 2016-05-18 18:33:05 --> Language Class Initialized
INFO - 2016-05-18 18:33:05 --> Loader Class Initialized
INFO - 2016-05-18 18:33:05 --> Helper loaded: url_helper
INFO - 2016-05-18 18:33:05 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:33:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:33:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:33:05 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:33:05 --> Helper loaded: form_helper
INFO - 2016-05-18 18:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:33:05 --> Form Validation Class Initialized
INFO - 2016-05-18 18:33:05 --> Controller Class Initialized
INFO - 2016-05-18 18:33:05 --> Model Class Initialized
INFO - 2016-05-18 18:33:05 --> Database Driver Class Initialized
INFO - 2016-05-18 18:33:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:33:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:33:05 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:33:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:33:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-18 18:33:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:33:05 --> Final output sent to browser
DEBUG - 2016-05-18 18:33:05 --> Total execution time: 0.0832
INFO - 2016-05-18 18:33:05 --> Config Class Initialized
INFO - 2016-05-18 18:33:05 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:33:05 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:33:05 --> Utf8 Class Initialized
INFO - 2016-05-18 18:33:05 --> URI Class Initialized
INFO - 2016-05-18 18:33:05 --> Router Class Initialized
INFO - 2016-05-18 18:33:05 --> Output Class Initialized
INFO - 2016-05-18 18:33:05 --> Security Class Initialized
DEBUG - 2016-05-18 18:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:33:05 --> Input Class Initialized
INFO - 2016-05-18 18:33:05 --> Language Class Initialized
INFO - 2016-05-18 18:33:05 --> Loader Class Initialized
INFO - 2016-05-18 18:33:05 --> Helper loaded: url_helper
INFO - 2016-05-18 18:33:05 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:33:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:33:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:33:05 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:33:05 --> Helper loaded: form_helper
INFO - 2016-05-18 18:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:33:05 --> Form Validation Class Initialized
INFO - 2016-05-18 18:33:05 --> Controller Class Initialized
INFO - 2016-05-18 18:33:05 --> Model Class Initialized
INFO - 2016-05-18 18:33:05 --> Database Driver Class Initialized
INFO - 2016-05-18 18:33:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:33:05 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:33:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:33:05 --> Final output sent to browser
DEBUG - 2016-05-18 18:33:05 --> Total execution time: 0.1015
INFO - 2016-05-18 18:33:21 --> Config Class Initialized
INFO - 2016-05-18 18:33:21 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:33:21 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:33:21 --> Utf8 Class Initialized
INFO - 2016-05-18 18:33:21 --> URI Class Initialized
INFO - 2016-05-18 18:33:21 --> Router Class Initialized
INFO - 2016-05-18 18:33:21 --> Output Class Initialized
INFO - 2016-05-18 18:33:21 --> Security Class Initialized
DEBUG - 2016-05-18 18:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:33:21 --> Input Class Initialized
INFO - 2016-05-18 18:33:21 --> Language Class Initialized
INFO - 2016-05-18 18:33:21 --> Loader Class Initialized
INFO - 2016-05-18 18:33:21 --> Helper loaded: url_helper
INFO - 2016-05-18 18:33:21 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:33:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:33:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:33:21 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:33:21 --> Helper loaded: form_helper
INFO - 2016-05-18 18:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:33:21 --> Form Validation Class Initialized
INFO - 2016-05-18 18:33:21 --> Controller Class Initialized
INFO - 2016-05-18 18:33:21 --> Model Class Initialized
INFO - 2016-05-18 18:33:21 --> Database Driver Class Initialized
INFO - 2016-05-18 18:33:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:33:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:33:21 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:33:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:33:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-18 18:33:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:33:21 --> Final output sent to browser
DEBUG - 2016-05-18 18:33:21 --> Total execution time: 0.0853
INFO - 2016-05-18 18:33:22 --> Config Class Initialized
INFO - 2016-05-18 18:33:22 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:33:22 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:33:22 --> Utf8 Class Initialized
INFO - 2016-05-18 18:33:22 --> URI Class Initialized
INFO - 2016-05-18 18:33:22 --> Router Class Initialized
INFO - 2016-05-18 18:33:22 --> Output Class Initialized
INFO - 2016-05-18 18:33:22 --> Security Class Initialized
DEBUG - 2016-05-18 18:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:33:22 --> Input Class Initialized
INFO - 2016-05-18 18:33:22 --> Language Class Initialized
INFO - 2016-05-18 18:33:22 --> Loader Class Initialized
INFO - 2016-05-18 18:33:22 --> Helper loaded: url_helper
INFO - 2016-05-18 18:33:22 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:33:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:33:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:33:22 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:33:22 --> Helper loaded: form_helper
INFO - 2016-05-18 18:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:33:22 --> Form Validation Class Initialized
INFO - 2016-05-18 18:33:22 --> Controller Class Initialized
INFO - 2016-05-18 18:33:22 --> Model Class Initialized
INFO - 2016-05-18 18:33:22 --> Database Driver Class Initialized
INFO - 2016-05-18 18:33:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:33:22 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:33:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:33:22 --> Final output sent to browser
DEBUG - 2016-05-18 18:33:22 --> Total execution time: 0.1086
INFO - 2016-05-18 18:34:22 --> Config Class Initialized
INFO - 2016-05-18 18:34:22 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:34:22 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:34:22 --> Utf8 Class Initialized
INFO - 2016-05-18 18:34:22 --> URI Class Initialized
INFO - 2016-05-18 18:34:22 --> Router Class Initialized
INFO - 2016-05-18 18:34:22 --> Output Class Initialized
INFO - 2016-05-18 18:34:22 --> Security Class Initialized
DEBUG - 2016-05-18 18:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:34:22 --> Input Class Initialized
INFO - 2016-05-18 18:34:22 --> Language Class Initialized
INFO - 2016-05-18 18:34:22 --> Loader Class Initialized
INFO - 2016-05-18 18:34:22 --> Helper loaded: url_helper
INFO - 2016-05-18 18:34:22 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:34:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:34:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:34:22 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:34:22 --> Helper loaded: form_helper
INFO - 2016-05-18 18:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:34:22 --> Form Validation Class Initialized
INFO - 2016-05-18 18:34:22 --> Controller Class Initialized
INFO - 2016-05-18 18:34:22 --> Model Class Initialized
INFO - 2016-05-18 18:34:22 --> Database Driver Class Initialized
INFO - 2016-05-18 18:34:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:34:22 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:34:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:34:22 --> Final output sent to browser
DEBUG - 2016-05-18 18:34:22 --> Total execution time: 0.1083
INFO - 2016-05-18 18:34:47 --> Config Class Initialized
INFO - 2016-05-18 18:34:47 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:34:47 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:34:47 --> Utf8 Class Initialized
INFO - 2016-05-18 18:34:47 --> URI Class Initialized
INFO - 2016-05-18 18:34:47 --> Router Class Initialized
INFO - 2016-05-18 18:34:47 --> Output Class Initialized
INFO - 2016-05-18 18:34:47 --> Security Class Initialized
DEBUG - 2016-05-18 18:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:34:47 --> Input Class Initialized
INFO - 2016-05-18 18:34:47 --> Language Class Initialized
INFO - 2016-05-18 18:34:47 --> Loader Class Initialized
INFO - 2016-05-18 18:34:47 --> Helper loaded: url_helper
INFO - 2016-05-18 18:34:47 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:34:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:34:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:34:47 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:34:47 --> Helper loaded: form_helper
INFO - 2016-05-18 18:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:34:47 --> Form Validation Class Initialized
INFO - 2016-05-18 18:34:47 --> Controller Class Initialized
INFO - 2016-05-18 18:34:47 --> Model Class Initialized
INFO - 2016-05-18 18:34:47 --> Database Driver Class Initialized
INFO - 2016-05-18 18:34:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:34:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:34:47 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:34:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:34:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-18 18:34:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:34:47 --> Final output sent to browser
DEBUG - 2016-05-18 18:34:47 --> Total execution time: 0.0862
INFO - 2016-05-18 18:34:48 --> Config Class Initialized
INFO - 2016-05-18 18:34:48 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:34:48 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:34:48 --> Utf8 Class Initialized
INFO - 2016-05-18 18:34:48 --> URI Class Initialized
INFO - 2016-05-18 18:34:48 --> Router Class Initialized
INFO - 2016-05-18 18:34:48 --> Output Class Initialized
INFO - 2016-05-18 18:34:48 --> Security Class Initialized
DEBUG - 2016-05-18 18:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:34:48 --> Input Class Initialized
INFO - 2016-05-18 18:34:48 --> Language Class Initialized
INFO - 2016-05-18 18:34:48 --> Loader Class Initialized
INFO - 2016-05-18 18:34:48 --> Helper loaded: url_helper
INFO - 2016-05-18 18:34:48 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:34:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:34:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:34:48 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:34:48 --> Helper loaded: form_helper
INFO - 2016-05-18 18:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:34:48 --> Form Validation Class Initialized
INFO - 2016-05-18 18:34:48 --> Controller Class Initialized
INFO - 2016-05-18 18:34:48 --> Model Class Initialized
INFO - 2016-05-18 18:34:48 --> Database Driver Class Initialized
INFO - 2016-05-18 18:34:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:34:48 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:34:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:34:48 --> Final output sent to browser
DEBUG - 2016-05-18 18:34:48 --> Total execution time: 0.0961
INFO - 2016-05-18 18:34:48 --> Config Class Initialized
INFO - 2016-05-18 18:34:48 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:34:48 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:34:48 --> Utf8 Class Initialized
INFO - 2016-05-18 18:34:48 --> URI Class Initialized
INFO - 2016-05-18 18:34:48 --> Router Class Initialized
INFO - 2016-05-18 18:34:48 --> Output Class Initialized
INFO - 2016-05-18 18:34:48 --> Security Class Initialized
DEBUG - 2016-05-18 18:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:34:48 --> Input Class Initialized
INFO - 2016-05-18 18:34:48 --> Language Class Initialized
INFO - 2016-05-18 18:34:48 --> Loader Class Initialized
INFO - 2016-05-18 18:34:48 --> Helper loaded: url_helper
INFO - 2016-05-18 18:34:48 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:34:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:34:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:34:48 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:34:48 --> Helper loaded: form_helper
INFO - 2016-05-18 18:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:34:48 --> Form Validation Class Initialized
INFO - 2016-05-18 18:34:48 --> Controller Class Initialized
INFO - 2016-05-18 18:34:48 --> Model Class Initialized
INFO - 2016-05-18 18:34:48 --> Database Driver Class Initialized
INFO - 2016-05-18 18:34:48 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:34:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:34:48 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:34:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:34:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-18 18:34:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:34:48 --> Final output sent to browser
DEBUG - 2016-05-18 18:34:48 --> Total execution time: 0.1007
INFO - 2016-05-18 18:34:49 --> Config Class Initialized
INFO - 2016-05-18 18:34:49 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:34:49 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:34:49 --> Utf8 Class Initialized
INFO - 2016-05-18 18:34:49 --> URI Class Initialized
INFO - 2016-05-18 18:34:49 --> Router Class Initialized
INFO - 2016-05-18 18:34:49 --> Output Class Initialized
INFO - 2016-05-18 18:34:49 --> Security Class Initialized
DEBUG - 2016-05-18 18:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:34:49 --> Input Class Initialized
INFO - 2016-05-18 18:34:49 --> Language Class Initialized
INFO - 2016-05-18 18:34:49 --> Loader Class Initialized
INFO - 2016-05-18 18:34:49 --> Helper loaded: url_helper
INFO - 2016-05-18 18:34:49 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:34:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:34:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:34:49 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:34:49 --> Helper loaded: form_helper
INFO - 2016-05-18 18:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:34:49 --> Form Validation Class Initialized
INFO - 2016-05-18 18:34:49 --> Controller Class Initialized
INFO - 2016-05-18 18:34:49 --> Model Class Initialized
INFO - 2016-05-18 18:34:49 --> Database Driver Class Initialized
INFO - 2016-05-18 18:34:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:34:49 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:34:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:34:49 --> Final output sent to browser
DEBUG - 2016-05-18 18:34:49 --> Total execution time: 0.0956
INFO - 2016-05-18 18:34:51 --> Config Class Initialized
INFO - 2016-05-18 18:34:51 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:34:51 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:34:51 --> Utf8 Class Initialized
INFO - 2016-05-18 18:34:51 --> URI Class Initialized
INFO - 2016-05-18 18:34:51 --> Router Class Initialized
INFO - 2016-05-18 18:34:51 --> Output Class Initialized
INFO - 2016-05-18 18:34:51 --> Security Class Initialized
DEBUG - 2016-05-18 18:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:34:51 --> Input Class Initialized
INFO - 2016-05-18 18:34:51 --> Language Class Initialized
INFO - 2016-05-18 18:34:51 --> Loader Class Initialized
INFO - 2016-05-18 18:34:51 --> Helper loaded: url_helper
INFO - 2016-05-18 18:34:51 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:34:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:34:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:34:51 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:34:51 --> Helper loaded: form_helper
INFO - 2016-05-18 18:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:34:51 --> Form Validation Class Initialized
INFO - 2016-05-18 18:34:51 --> Controller Class Initialized
INFO - 2016-05-18 18:34:51 --> Model Class Initialized
INFO - 2016-05-18 18:34:51 --> Database Driver Class Initialized
INFO - 2016-05-18 18:34:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:34:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:34:51 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:34:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:34:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-18 18:34:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:34:51 --> Final output sent to browser
DEBUG - 2016-05-18 18:34:51 --> Total execution time: 0.0821
INFO - 2016-05-18 18:34:52 --> Config Class Initialized
INFO - 2016-05-18 18:34:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:34:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:34:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:34:52 --> URI Class Initialized
INFO - 2016-05-18 18:34:52 --> Router Class Initialized
INFO - 2016-05-18 18:34:52 --> Output Class Initialized
INFO - 2016-05-18 18:34:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:34:52 --> Input Class Initialized
INFO - 2016-05-18 18:34:52 --> Language Class Initialized
INFO - 2016-05-18 18:34:52 --> Loader Class Initialized
INFO - 2016-05-18 18:34:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:34:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:34:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:34:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:34:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:34:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:34:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:34:52 --> Controller Class Initialized
INFO - 2016-05-18 18:34:52 --> Model Class Initialized
INFO - 2016-05-18 18:34:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:34:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:34:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:34:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:34:52 --> Final output sent to browser
DEBUG - 2016-05-18 18:34:52 --> Total execution time: 0.1059
INFO - 2016-05-18 18:35:10 --> Config Class Initialized
INFO - 2016-05-18 18:35:10 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:35:10 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:35:10 --> Utf8 Class Initialized
INFO - 2016-05-18 18:35:10 --> URI Class Initialized
INFO - 2016-05-18 18:35:10 --> Router Class Initialized
INFO - 2016-05-18 18:35:10 --> Output Class Initialized
INFO - 2016-05-18 18:35:10 --> Security Class Initialized
DEBUG - 2016-05-18 18:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:35:10 --> Input Class Initialized
INFO - 2016-05-18 18:35:10 --> Language Class Initialized
INFO - 2016-05-18 18:35:10 --> Loader Class Initialized
INFO - 2016-05-18 18:35:10 --> Helper loaded: url_helper
INFO - 2016-05-18 18:35:10 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:35:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:35:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:35:10 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:35:10 --> Helper loaded: form_helper
INFO - 2016-05-18 18:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:35:10 --> Form Validation Class Initialized
INFO - 2016-05-18 18:35:10 --> Controller Class Initialized
INFO - 2016-05-18 18:35:10 --> Model Class Initialized
INFO - 2016-05-18 18:35:10 --> Database Driver Class Initialized
INFO - 2016-05-18 18:35:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:35:10 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:35:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:35:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-18 18:35:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:35:10 --> Final output sent to browser
DEBUG - 2016-05-18 18:35:10 --> Total execution time: 0.0815
INFO - 2016-05-18 18:35:10 --> Config Class Initialized
INFO - 2016-05-18 18:35:10 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:35:10 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:35:10 --> Utf8 Class Initialized
INFO - 2016-05-18 18:35:10 --> URI Class Initialized
INFO - 2016-05-18 18:35:10 --> Router Class Initialized
INFO - 2016-05-18 18:35:10 --> Output Class Initialized
INFO - 2016-05-18 18:35:10 --> Security Class Initialized
DEBUG - 2016-05-18 18:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:35:10 --> Input Class Initialized
INFO - 2016-05-18 18:35:10 --> Language Class Initialized
INFO - 2016-05-18 18:35:10 --> Loader Class Initialized
INFO - 2016-05-18 18:35:10 --> Helper loaded: url_helper
INFO - 2016-05-18 18:35:10 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:35:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:35:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:35:10 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:35:10 --> Helper loaded: form_helper
INFO - 2016-05-18 18:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:35:10 --> Form Validation Class Initialized
INFO - 2016-05-18 18:35:10 --> Controller Class Initialized
INFO - 2016-05-18 18:35:10 --> Model Class Initialized
INFO - 2016-05-18 18:35:10 --> Database Driver Class Initialized
INFO - 2016-05-18 18:35:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:35:10 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:35:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:35:10 --> Final output sent to browser
DEBUG - 2016-05-18 18:35:10 --> Total execution time: 0.1071
INFO - 2016-05-18 18:36:10 --> Config Class Initialized
INFO - 2016-05-18 18:36:10 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:36:10 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:36:10 --> Utf8 Class Initialized
INFO - 2016-05-18 18:36:10 --> URI Class Initialized
INFO - 2016-05-18 18:36:10 --> Router Class Initialized
INFO - 2016-05-18 18:36:10 --> Output Class Initialized
INFO - 2016-05-18 18:36:10 --> Security Class Initialized
DEBUG - 2016-05-18 18:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:36:10 --> Input Class Initialized
INFO - 2016-05-18 18:36:10 --> Language Class Initialized
INFO - 2016-05-18 18:36:10 --> Loader Class Initialized
INFO - 2016-05-18 18:36:10 --> Helper loaded: url_helper
INFO - 2016-05-18 18:36:10 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:36:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:36:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:36:10 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:36:10 --> Helper loaded: form_helper
INFO - 2016-05-18 18:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:36:10 --> Form Validation Class Initialized
INFO - 2016-05-18 18:36:10 --> Controller Class Initialized
INFO - 2016-05-18 18:36:10 --> Model Class Initialized
INFO - 2016-05-18 18:36:10 --> Database Driver Class Initialized
INFO - 2016-05-18 18:36:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:36:10 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:36:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:36:10 --> Final output sent to browser
DEBUG - 2016-05-18 18:36:10 --> Total execution time: 0.0914
INFO - 2016-05-18 18:37:10 --> Config Class Initialized
INFO - 2016-05-18 18:37:10 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:37:10 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:37:10 --> Utf8 Class Initialized
INFO - 2016-05-18 18:37:10 --> URI Class Initialized
INFO - 2016-05-18 18:37:10 --> Router Class Initialized
INFO - 2016-05-18 18:37:10 --> Output Class Initialized
INFO - 2016-05-18 18:37:10 --> Security Class Initialized
DEBUG - 2016-05-18 18:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:37:10 --> Input Class Initialized
INFO - 2016-05-18 18:37:10 --> Language Class Initialized
INFO - 2016-05-18 18:37:10 --> Loader Class Initialized
INFO - 2016-05-18 18:37:10 --> Helper loaded: url_helper
INFO - 2016-05-18 18:37:10 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:37:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:37:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:37:10 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:37:10 --> Helper loaded: form_helper
INFO - 2016-05-18 18:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:37:10 --> Form Validation Class Initialized
INFO - 2016-05-18 18:37:10 --> Controller Class Initialized
INFO - 2016-05-18 18:37:10 --> Model Class Initialized
INFO - 2016-05-18 18:37:10 --> Database Driver Class Initialized
INFO - 2016-05-18 18:37:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:37:10 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:37:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:37:10 --> Final output sent to browser
DEBUG - 2016-05-18 18:37:10 --> Total execution time: 0.1062
INFO - 2016-05-18 18:38:10 --> Config Class Initialized
INFO - 2016-05-18 18:38:10 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:10 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:10 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:10 --> URI Class Initialized
INFO - 2016-05-18 18:38:10 --> Router Class Initialized
INFO - 2016-05-18 18:38:10 --> Output Class Initialized
INFO - 2016-05-18 18:38:10 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:10 --> Input Class Initialized
INFO - 2016-05-18 18:38:10 --> Language Class Initialized
INFO - 2016-05-18 18:38:10 --> Loader Class Initialized
INFO - 2016-05-18 18:38:10 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:10 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:10 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:10 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:10 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:10 --> Controller Class Initialized
INFO - 2016-05-18 18:38:10 --> Model Class Initialized
INFO - 2016-05-18 18:38:10 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:10 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:10 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:10 --> Total execution time: 0.1114
INFO - 2016-05-18 18:38:25 --> Config Class Initialized
INFO - 2016-05-18 18:38:25 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:25 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:25 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:25 --> URI Class Initialized
INFO - 2016-05-18 18:38:25 --> Router Class Initialized
INFO - 2016-05-18 18:38:25 --> Output Class Initialized
INFO - 2016-05-18 18:38:25 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:25 --> Input Class Initialized
INFO - 2016-05-18 18:38:25 --> Language Class Initialized
INFO - 2016-05-18 18:38:25 --> Loader Class Initialized
INFO - 2016-05-18 18:38:25 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:25 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:25 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:25 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:25 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:25 --> Controller Class Initialized
INFO - 2016-05-18 18:38:25 --> Model Class Initialized
INFO - 2016-05-18 18:38:25 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:25 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-18 18:38:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:38:25 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:25 --> Total execution time: 0.0772
INFO - 2016-05-18 18:38:25 --> Config Class Initialized
INFO - 2016-05-18 18:38:25 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:25 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:25 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:25 --> URI Class Initialized
INFO - 2016-05-18 18:38:25 --> Router Class Initialized
INFO - 2016-05-18 18:38:25 --> Output Class Initialized
INFO - 2016-05-18 18:38:25 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:25 --> Input Class Initialized
INFO - 2016-05-18 18:38:25 --> Language Class Initialized
INFO - 2016-05-18 18:38:25 --> Loader Class Initialized
INFO - 2016-05-18 18:38:25 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:25 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:25 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:25 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:25 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:25 --> Controller Class Initialized
INFO - 2016-05-18 18:38:25 --> Model Class Initialized
INFO - 2016-05-18 18:38:25 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:26 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:26 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:26 --> Total execution time: 0.1089
INFO - 2016-05-18 18:38:33 --> Config Class Initialized
INFO - 2016-05-18 18:38:33 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:33 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:33 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:33 --> URI Class Initialized
INFO - 2016-05-18 18:38:33 --> Router Class Initialized
INFO - 2016-05-18 18:38:33 --> Output Class Initialized
INFO - 2016-05-18 18:38:33 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:33 --> Input Class Initialized
INFO - 2016-05-18 18:38:33 --> Language Class Initialized
INFO - 2016-05-18 18:38:33 --> Loader Class Initialized
INFO - 2016-05-18 18:38:33 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:33 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:33 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:33 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:33 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:33 --> Controller Class Initialized
INFO - 2016-05-18 18:38:33 --> Model Class Initialized
INFO - 2016-05-18 18:38:33 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:38:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:33 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:33 --> Helper loaded: nif_validate_helper
INFO - 2016-05-18 18:38:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-18 18:38:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:38:33 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:33 --> Total execution time: 0.0813
INFO - 2016-05-18 18:38:34 --> Config Class Initialized
INFO - 2016-05-18 18:38:34 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:34 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:34 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:34 --> URI Class Initialized
INFO - 2016-05-18 18:38:34 --> Router Class Initialized
INFO - 2016-05-18 18:38:34 --> Output Class Initialized
INFO - 2016-05-18 18:38:34 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:34 --> Input Class Initialized
INFO - 2016-05-18 18:38:34 --> Language Class Initialized
INFO - 2016-05-18 18:38:34 --> Loader Class Initialized
INFO - 2016-05-18 18:38:34 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:34 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:34 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:34 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:34 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:34 --> Controller Class Initialized
INFO - 2016-05-18 18:38:34 --> Model Class Initialized
INFO - 2016-05-18 18:38:34 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:34 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:34 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:34 --> Total execution time: 0.1020
INFO - 2016-05-18 18:38:37 --> Config Class Initialized
INFO - 2016-05-18 18:38:37 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:37 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:37 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:37 --> URI Class Initialized
INFO - 2016-05-18 18:38:37 --> Router Class Initialized
INFO - 2016-05-18 18:38:37 --> Output Class Initialized
INFO - 2016-05-18 18:38:37 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:37 --> Input Class Initialized
INFO - 2016-05-18 18:38:37 --> Language Class Initialized
INFO - 2016-05-18 18:38:37 --> Loader Class Initialized
INFO - 2016-05-18 18:38:37 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:37 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:37 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:37 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:37 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:37 --> Controller Class Initialized
INFO - 2016-05-18 18:38:37 --> Model Class Initialized
INFO - 2016-05-18 18:38:37 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:37 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:38:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:37 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:37 --> Helper loaded: nif_validate_helper
INFO - 2016-05-18 18:38:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-18 18:38:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:38:37 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:37 --> Total execution time: 0.0989
INFO - 2016-05-18 18:38:38 --> Config Class Initialized
INFO - 2016-05-18 18:38:38 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:38 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:38 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:38 --> URI Class Initialized
INFO - 2016-05-18 18:38:38 --> Router Class Initialized
INFO - 2016-05-18 18:38:38 --> Output Class Initialized
INFO - 2016-05-18 18:38:38 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:38 --> Input Class Initialized
INFO - 2016-05-18 18:38:38 --> Language Class Initialized
INFO - 2016-05-18 18:38:38 --> Loader Class Initialized
INFO - 2016-05-18 18:38:38 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:38 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:38 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:38 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:38 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:38 --> Controller Class Initialized
INFO - 2016-05-18 18:38:38 --> Model Class Initialized
INFO - 2016-05-18 18:38:38 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:38 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:38 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:38 --> Total execution time: 0.1041
INFO - 2016-05-18 18:38:47 --> Config Class Initialized
INFO - 2016-05-18 18:38:47 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:47 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:47 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:47 --> URI Class Initialized
INFO - 2016-05-18 18:38:47 --> Router Class Initialized
INFO - 2016-05-18 18:38:47 --> Output Class Initialized
INFO - 2016-05-18 18:38:47 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:47 --> Input Class Initialized
INFO - 2016-05-18 18:38:47 --> Language Class Initialized
INFO - 2016-05-18 18:38:47 --> Loader Class Initialized
INFO - 2016-05-18 18:38:47 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:47 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:47 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:47 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:47 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:47 --> Controller Class Initialized
INFO - 2016-05-18 18:38:47 --> Model Class Initialized
INFO - 2016-05-18 18:38:47 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:47 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:38:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:47 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:47 --> Helper loaded: nif_validate_helper
INFO - 2016-05-18 18:38:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-18 18:38:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:38:47 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:47 --> Total execution time: 0.0892
INFO - 2016-05-18 18:38:48 --> Config Class Initialized
INFO - 2016-05-18 18:38:48 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:48 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:48 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:48 --> URI Class Initialized
INFO - 2016-05-18 18:38:48 --> Router Class Initialized
INFO - 2016-05-18 18:38:48 --> Output Class Initialized
INFO - 2016-05-18 18:38:48 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:48 --> Input Class Initialized
INFO - 2016-05-18 18:38:48 --> Language Class Initialized
INFO - 2016-05-18 18:38:48 --> Loader Class Initialized
INFO - 2016-05-18 18:38:48 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:48 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:48 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:48 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:48 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:48 --> Controller Class Initialized
INFO - 2016-05-18 18:38:48 --> Model Class Initialized
INFO - 2016-05-18 18:38:48 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:48 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:48 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:48 --> Total execution time: 0.1025
INFO - 2016-05-18 18:38:50 --> Config Class Initialized
INFO - 2016-05-18 18:38:50 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:50 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:50 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:50 --> URI Class Initialized
INFO - 2016-05-18 18:38:50 --> Router Class Initialized
INFO - 2016-05-18 18:38:50 --> Output Class Initialized
INFO - 2016-05-18 18:38:50 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:50 --> Input Class Initialized
INFO - 2016-05-18 18:38:50 --> Language Class Initialized
INFO - 2016-05-18 18:38:50 --> Loader Class Initialized
INFO - 2016-05-18 18:38:50 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:50 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:50 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:50 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:50 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:50 --> Controller Class Initialized
INFO - 2016-05-18 18:38:50 --> Model Class Initialized
INFO - 2016-05-18 18:38:50 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:50 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:38:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:50 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:50 --> Helper loaded: nif_validate_helper
INFO - 2016-05-18 18:38:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-18 18:38:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:38:50 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:50 --> Total execution time: 0.0848
INFO - 2016-05-18 18:38:50 --> Config Class Initialized
INFO - 2016-05-18 18:38:50 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:50 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:50 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:50 --> URI Class Initialized
INFO - 2016-05-18 18:38:50 --> Router Class Initialized
INFO - 2016-05-18 18:38:50 --> Output Class Initialized
INFO - 2016-05-18 18:38:50 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:50 --> Input Class Initialized
INFO - 2016-05-18 18:38:50 --> Language Class Initialized
INFO - 2016-05-18 18:38:50 --> Loader Class Initialized
INFO - 2016-05-18 18:38:50 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:50 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:50 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:50 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:50 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:50 --> Controller Class Initialized
INFO - 2016-05-18 18:38:50 --> Model Class Initialized
INFO - 2016-05-18 18:38:50 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:50 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:50 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:50 --> Total execution time: 0.1025
INFO - 2016-05-18 18:38:53 --> Config Class Initialized
INFO - 2016-05-18 18:38:53 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:53 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:53 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:53 --> URI Class Initialized
INFO - 2016-05-18 18:38:53 --> Router Class Initialized
INFO - 2016-05-18 18:38:53 --> Output Class Initialized
INFO - 2016-05-18 18:38:53 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:53 --> Input Class Initialized
INFO - 2016-05-18 18:38:53 --> Language Class Initialized
INFO - 2016-05-18 18:38:53 --> Loader Class Initialized
INFO - 2016-05-18 18:38:53 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:53 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:53 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:53 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:53 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:53 --> Controller Class Initialized
INFO - 2016-05-18 18:38:53 --> Model Class Initialized
INFO - 2016-05-18 18:38:53 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:38:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:53 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:53 --> Helper loaded: nif_validate_helper
INFO - 2016-05-18 18:38:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-18 18:38:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:38:53 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:53 --> Total execution time: 0.1018
INFO - 2016-05-18 18:38:54 --> Config Class Initialized
INFO - 2016-05-18 18:38:54 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:54 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:54 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:54 --> URI Class Initialized
INFO - 2016-05-18 18:38:54 --> Router Class Initialized
INFO - 2016-05-18 18:38:54 --> Output Class Initialized
INFO - 2016-05-18 18:38:54 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:54 --> Input Class Initialized
INFO - 2016-05-18 18:38:54 --> Language Class Initialized
INFO - 2016-05-18 18:38:54 --> Loader Class Initialized
INFO - 2016-05-18 18:38:54 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:54 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:54 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:54 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:54 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:54 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:54 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:54 --> Controller Class Initialized
INFO - 2016-05-18 18:38:54 --> Model Class Initialized
INFO - 2016-05-18 18:38:54 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:54 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:54 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:54 --> Total execution time: 0.1078
INFO - 2016-05-18 18:38:56 --> Config Class Initialized
INFO - 2016-05-18 18:38:56 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:56 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:56 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:56 --> URI Class Initialized
INFO - 2016-05-18 18:38:56 --> Router Class Initialized
INFO - 2016-05-18 18:38:56 --> Output Class Initialized
INFO - 2016-05-18 18:38:56 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:56 --> Input Class Initialized
INFO - 2016-05-18 18:38:56 --> Language Class Initialized
INFO - 2016-05-18 18:38:56 --> Loader Class Initialized
INFO - 2016-05-18 18:38:56 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:56 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:56 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:56 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:56 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:56 --> Controller Class Initialized
INFO - 2016-05-18 18:38:56 --> Model Class Initialized
INFO - 2016-05-18 18:38:56 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:56 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:38:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:56 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:56 --> Helper loaded: nif_validate_helper
INFO - 2016-05-18 18:38:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-18 18:38:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:38:56 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:56 --> Total execution time: 0.0822
INFO - 2016-05-18 18:38:56 --> Config Class Initialized
INFO - 2016-05-18 18:38:56 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:56 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:56 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:56 --> URI Class Initialized
INFO - 2016-05-18 18:38:56 --> Router Class Initialized
INFO - 2016-05-18 18:38:56 --> Output Class Initialized
INFO - 2016-05-18 18:38:56 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:56 --> Input Class Initialized
INFO - 2016-05-18 18:38:56 --> Language Class Initialized
INFO - 2016-05-18 18:38:56 --> Loader Class Initialized
INFO - 2016-05-18 18:38:56 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:56 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:56 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:56 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:56 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:56 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:56 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:56 --> Controller Class Initialized
INFO - 2016-05-18 18:38:56 --> Model Class Initialized
INFO - 2016-05-18 18:38:56 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:56 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:56 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:56 --> Total execution time: 0.1136
INFO - 2016-05-18 18:38:58 --> Config Class Initialized
INFO - 2016-05-18 18:38:58 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:58 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:58 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:58 --> URI Class Initialized
INFO - 2016-05-18 18:38:58 --> Router Class Initialized
INFO - 2016-05-18 18:38:58 --> Output Class Initialized
INFO - 2016-05-18 18:38:58 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:58 --> Input Class Initialized
INFO - 2016-05-18 18:38:58 --> Language Class Initialized
INFO - 2016-05-18 18:38:58 --> Loader Class Initialized
INFO - 2016-05-18 18:38:58 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:58 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:58 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:58 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:58 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:58 --> Controller Class Initialized
INFO - 2016-05-18 18:38:58 --> Model Class Initialized
INFO - 2016-05-18 18:38:58 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:58 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:38:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:58 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:58 --> Helper loaded: nif_validate_helper
INFO - 2016-05-18 18:38:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-18 18:38:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:38:58 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:58 --> Total execution time: 0.1052
INFO - 2016-05-18 18:38:58 --> Config Class Initialized
INFO - 2016-05-18 18:38:58 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:38:58 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:38:58 --> Utf8 Class Initialized
INFO - 2016-05-18 18:38:58 --> URI Class Initialized
INFO - 2016-05-18 18:38:58 --> Router Class Initialized
INFO - 2016-05-18 18:38:58 --> Output Class Initialized
INFO - 2016-05-18 18:38:58 --> Security Class Initialized
DEBUG - 2016-05-18 18:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:38:58 --> Input Class Initialized
INFO - 2016-05-18 18:38:58 --> Language Class Initialized
INFO - 2016-05-18 18:38:58 --> Loader Class Initialized
INFO - 2016-05-18 18:38:58 --> Helper loaded: url_helper
INFO - 2016-05-18 18:38:58 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:38:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:38:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:38:58 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:38:58 --> Helper loaded: form_helper
INFO - 2016-05-18 18:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:38:58 --> Form Validation Class Initialized
INFO - 2016-05-18 18:38:58 --> Controller Class Initialized
INFO - 2016-05-18 18:38:58 --> Model Class Initialized
INFO - 2016-05-18 18:38:59 --> Database Driver Class Initialized
INFO - 2016-05-18 18:38:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:38:59 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:38:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:38:59 --> Final output sent to browser
DEBUG - 2016-05-18 18:38:59 --> Total execution time: 0.1088
INFO - 2016-05-18 18:39:01 --> Config Class Initialized
INFO - 2016-05-18 18:39:01 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:39:01 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:39:01 --> Utf8 Class Initialized
INFO - 2016-05-18 18:39:01 --> URI Class Initialized
INFO - 2016-05-18 18:39:01 --> Router Class Initialized
INFO - 2016-05-18 18:39:01 --> Output Class Initialized
INFO - 2016-05-18 18:39:01 --> Security Class Initialized
DEBUG - 2016-05-18 18:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:39:01 --> Input Class Initialized
INFO - 2016-05-18 18:39:01 --> Language Class Initialized
INFO - 2016-05-18 18:39:01 --> Loader Class Initialized
INFO - 2016-05-18 18:39:01 --> Helper loaded: url_helper
INFO - 2016-05-18 18:39:01 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:39:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:39:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:39:01 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:39:01 --> Helper loaded: form_helper
INFO - 2016-05-18 18:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:39:01 --> Form Validation Class Initialized
INFO - 2016-05-18 18:39:01 --> Controller Class Initialized
INFO - 2016-05-18 18:39:01 --> Model Class Initialized
INFO - 2016-05-18 18:39:01 --> Database Driver Class Initialized
INFO - 2016-05-18 18:39:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:39:01 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:39:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:39:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-18 18:39:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:39:01 --> Final output sent to browser
DEBUG - 2016-05-18 18:39:01 --> Total execution time: 0.1144
INFO - 2016-05-18 18:39:01 --> Config Class Initialized
INFO - 2016-05-18 18:39:01 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:39:01 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:39:01 --> Utf8 Class Initialized
INFO - 2016-05-18 18:39:01 --> URI Class Initialized
INFO - 2016-05-18 18:39:01 --> Router Class Initialized
INFO - 2016-05-18 18:39:01 --> Output Class Initialized
INFO - 2016-05-18 18:39:01 --> Security Class Initialized
DEBUG - 2016-05-18 18:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:39:01 --> Input Class Initialized
INFO - 2016-05-18 18:39:01 --> Language Class Initialized
INFO - 2016-05-18 18:39:01 --> Loader Class Initialized
INFO - 2016-05-18 18:39:01 --> Helper loaded: url_helper
INFO - 2016-05-18 18:39:01 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:39:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:39:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:39:01 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:39:01 --> Helper loaded: form_helper
INFO - 2016-05-18 18:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:39:01 --> Form Validation Class Initialized
INFO - 2016-05-18 18:39:01 --> Controller Class Initialized
INFO - 2016-05-18 18:39:01 --> Model Class Initialized
INFO - 2016-05-18 18:39:01 --> Database Driver Class Initialized
INFO - 2016-05-18 18:39:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:39:01 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:39:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:39:01 --> Final output sent to browser
DEBUG - 2016-05-18 18:39:01 --> Total execution time: 0.1277
INFO - 2016-05-18 18:39:06 --> Config Class Initialized
INFO - 2016-05-18 18:39:06 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:39:06 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:39:06 --> Utf8 Class Initialized
INFO - 2016-05-18 18:39:06 --> URI Class Initialized
INFO - 2016-05-18 18:39:06 --> Router Class Initialized
INFO - 2016-05-18 18:39:06 --> Output Class Initialized
INFO - 2016-05-18 18:39:06 --> Security Class Initialized
DEBUG - 2016-05-18 18:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:39:06 --> Input Class Initialized
INFO - 2016-05-18 18:39:06 --> Language Class Initialized
INFO - 2016-05-18 18:39:06 --> Loader Class Initialized
INFO - 2016-05-18 18:39:06 --> Helper loaded: url_helper
INFO - 2016-05-18 18:39:06 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:39:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:39:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:39:06 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:39:06 --> Helper loaded: form_helper
INFO - 2016-05-18 18:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:39:06 --> Form Validation Class Initialized
INFO - 2016-05-18 18:39:06 --> Controller Class Initialized
INFO - 2016-05-18 18:39:06 --> Model Class Initialized
INFO - 2016-05-18 18:39:06 --> Database Driver Class Initialized
INFO - 2016-05-18 18:39:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:39:06 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:39:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:39:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-18 18:39:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:39:06 --> Final output sent to browser
DEBUG - 2016-05-18 18:39:06 --> Total execution time: 0.0786
INFO - 2016-05-18 18:39:06 --> Config Class Initialized
INFO - 2016-05-18 18:39:06 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:39:06 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:39:06 --> Utf8 Class Initialized
INFO - 2016-05-18 18:39:06 --> URI Class Initialized
INFO - 2016-05-18 18:39:06 --> Router Class Initialized
INFO - 2016-05-18 18:39:06 --> Output Class Initialized
INFO - 2016-05-18 18:39:06 --> Security Class Initialized
DEBUG - 2016-05-18 18:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:39:06 --> Input Class Initialized
INFO - 2016-05-18 18:39:06 --> Language Class Initialized
INFO - 2016-05-18 18:39:06 --> Loader Class Initialized
INFO - 2016-05-18 18:39:06 --> Helper loaded: url_helper
INFO - 2016-05-18 18:39:06 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:39:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:39:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:39:06 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:39:06 --> Helper loaded: form_helper
INFO - 2016-05-18 18:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:39:06 --> Form Validation Class Initialized
INFO - 2016-05-18 18:39:06 --> Controller Class Initialized
INFO - 2016-05-18 18:39:06 --> Model Class Initialized
INFO - 2016-05-18 18:39:06 --> Database Driver Class Initialized
INFO - 2016-05-18 18:39:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:39:06 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:39:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:39:06 --> Final output sent to browser
DEBUG - 2016-05-18 18:39:06 --> Total execution time: 0.1241
INFO - 2016-05-18 18:39:09 --> Config Class Initialized
INFO - 2016-05-18 18:39:09 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:39:09 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:39:09 --> Utf8 Class Initialized
INFO - 2016-05-18 18:39:09 --> URI Class Initialized
INFO - 2016-05-18 18:39:09 --> Router Class Initialized
INFO - 2016-05-18 18:39:09 --> Output Class Initialized
INFO - 2016-05-18 18:39:09 --> Security Class Initialized
DEBUG - 2016-05-18 18:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:39:09 --> Input Class Initialized
INFO - 2016-05-18 18:39:09 --> Language Class Initialized
INFO - 2016-05-18 18:39:09 --> Loader Class Initialized
INFO - 2016-05-18 18:39:09 --> Helper loaded: url_helper
INFO - 2016-05-18 18:39:09 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:39:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:39:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:39:09 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:39:09 --> Helper loaded: form_helper
INFO - 2016-05-18 18:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:39:09 --> Form Validation Class Initialized
INFO - 2016-05-18 18:39:09 --> Controller Class Initialized
INFO - 2016-05-18 18:39:09 --> Model Class Initialized
INFO - 2016-05-18 18:39:09 --> Database Driver Class Initialized
INFO - 2016-05-18 18:39:09 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:39:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:39:09 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:39:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:39:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-18 18:39:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:39:09 --> Final output sent to browser
DEBUG - 2016-05-18 18:39:09 --> Total execution time: 0.0945
INFO - 2016-05-18 18:39:09 --> Config Class Initialized
INFO - 2016-05-18 18:39:09 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:39:09 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:39:09 --> Utf8 Class Initialized
INFO - 2016-05-18 18:39:09 --> URI Class Initialized
INFO - 2016-05-18 18:39:09 --> Router Class Initialized
INFO - 2016-05-18 18:39:09 --> Output Class Initialized
INFO - 2016-05-18 18:39:09 --> Security Class Initialized
DEBUG - 2016-05-18 18:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:39:09 --> Input Class Initialized
INFO - 2016-05-18 18:39:09 --> Language Class Initialized
INFO - 2016-05-18 18:39:09 --> Loader Class Initialized
INFO - 2016-05-18 18:39:09 --> Helper loaded: url_helper
INFO - 2016-05-18 18:39:09 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:39:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:39:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:39:09 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:39:09 --> Helper loaded: form_helper
INFO - 2016-05-18 18:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:39:09 --> Form Validation Class Initialized
INFO - 2016-05-18 18:39:09 --> Controller Class Initialized
INFO - 2016-05-18 18:39:09 --> Model Class Initialized
INFO - 2016-05-18 18:39:09 --> Database Driver Class Initialized
INFO - 2016-05-18 18:39:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:39:09 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:39:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:39:09 --> Final output sent to browser
DEBUG - 2016-05-18 18:39:09 --> Total execution time: 0.1171
INFO - 2016-05-18 18:39:11 --> Config Class Initialized
INFO - 2016-05-18 18:39:11 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:39:11 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:39:11 --> Utf8 Class Initialized
INFO - 2016-05-18 18:39:11 --> URI Class Initialized
INFO - 2016-05-18 18:39:11 --> Router Class Initialized
INFO - 2016-05-18 18:39:11 --> Output Class Initialized
INFO - 2016-05-18 18:39:11 --> Security Class Initialized
DEBUG - 2016-05-18 18:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:39:11 --> Input Class Initialized
INFO - 2016-05-18 18:39:11 --> Language Class Initialized
INFO - 2016-05-18 18:39:11 --> Loader Class Initialized
INFO - 2016-05-18 18:39:11 --> Helper loaded: url_helper
INFO - 2016-05-18 18:39:11 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:39:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:39:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:39:11 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:39:11 --> Helper loaded: form_helper
INFO - 2016-05-18 18:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:39:11 --> Form Validation Class Initialized
INFO - 2016-05-18 18:39:11 --> Controller Class Initialized
INFO - 2016-05-18 18:39:11 --> Model Class Initialized
INFO - 2016-05-18 18:39:11 --> Database Driver Class Initialized
INFO - 2016-05-18 18:39:11 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:39:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:39:11 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:39:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:39:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-18 18:39:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:39:11 --> Final output sent to browser
DEBUG - 2016-05-18 18:39:11 --> Total execution time: 0.0876
INFO - 2016-05-18 18:39:11 --> Config Class Initialized
INFO - 2016-05-18 18:39:11 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:39:11 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:39:11 --> Utf8 Class Initialized
INFO - 2016-05-18 18:39:11 --> URI Class Initialized
INFO - 2016-05-18 18:39:11 --> Router Class Initialized
INFO - 2016-05-18 18:39:11 --> Output Class Initialized
INFO - 2016-05-18 18:39:11 --> Security Class Initialized
DEBUG - 2016-05-18 18:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:39:11 --> Input Class Initialized
INFO - 2016-05-18 18:39:11 --> Language Class Initialized
INFO - 2016-05-18 18:39:11 --> Loader Class Initialized
INFO - 2016-05-18 18:39:11 --> Helper loaded: url_helper
INFO - 2016-05-18 18:39:11 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:39:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:39:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:39:11 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:39:11 --> Helper loaded: form_helper
INFO - 2016-05-18 18:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:39:11 --> Form Validation Class Initialized
INFO - 2016-05-18 18:39:11 --> Controller Class Initialized
INFO - 2016-05-18 18:39:11 --> Model Class Initialized
INFO - 2016-05-18 18:39:11 --> Database Driver Class Initialized
INFO - 2016-05-18 18:39:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:39:11 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:39:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:39:11 --> Final output sent to browser
DEBUG - 2016-05-18 18:39:11 --> Total execution time: 0.1295
INFO - 2016-05-18 18:39:12 --> Config Class Initialized
INFO - 2016-05-18 18:39:12 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:39:12 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:39:12 --> Utf8 Class Initialized
INFO - 2016-05-18 18:39:12 --> URI Class Initialized
INFO - 2016-05-18 18:39:12 --> Router Class Initialized
INFO - 2016-05-18 18:39:12 --> Output Class Initialized
INFO - 2016-05-18 18:39:12 --> Security Class Initialized
DEBUG - 2016-05-18 18:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:39:12 --> Input Class Initialized
INFO - 2016-05-18 18:39:12 --> Language Class Initialized
INFO - 2016-05-18 18:39:12 --> Loader Class Initialized
INFO - 2016-05-18 18:39:12 --> Helper loaded: url_helper
INFO - 2016-05-18 18:39:12 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:39:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:39:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:39:12 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:39:12 --> Helper loaded: form_helper
INFO - 2016-05-18 18:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:39:12 --> Form Validation Class Initialized
INFO - 2016-05-18 18:39:12 --> Controller Class Initialized
INFO - 2016-05-18 18:39:12 --> Model Class Initialized
INFO - 2016-05-18 18:39:12 --> Database Driver Class Initialized
INFO - 2016-05-18 18:39:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:39:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:39:12 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:39:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:39:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-18 18:39:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:39:12 --> Final output sent to browser
DEBUG - 2016-05-18 18:39:12 --> Total execution time: 0.1043
INFO - 2016-05-18 18:39:12 --> Config Class Initialized
INFO - 2016-05-18 18:39:12 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:39:12 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:39:12 --> Utf8 Class Initialized
INFO - 2016-05-18 18:39:12 --> URI Class Initialized
INFO - 2016-05-18 18:39:12 --> Router Class Initialized
INFO - 2016-05-18 18:39:12 --> Output Class Initialized
INFO - 2016-05-18 18:39:12 --> Security Class Initialized
DEBUG - 2016-05-18 18:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:39:12 --> Input Class Initialized
INFO - 2016-05-18 18:39:12 --> Language Class Initialized
INFO - 2016-05-18 18:39:12 --> Loader Class Initialized
INFO - 2016-05-18 18:39:12 --> Helper loaded: url_helper
INFO - 2016-05-18 18:39:12 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:39:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:39:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:39:12 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:39:12 --> Helper loaded: form_helper
INFO - 2016-05-18 18:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:39:12 --> Form Validation Class Initialized
INFO - 2016-05-18 18:39:12 --> Controller Class Initialized
INFO - 2016-05-18 18:39:12 --> Model Class Initialized
INFO - 2016-05-18 18:39:12 --> Database Driver Class Initialized
INFO - 2016-05-18 18:39:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:39:12 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:39:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:39:12 --> Final output sent to browser
DEBUG - 2016-05-18 18:39:12 --> Total execution time: 0.0964
INFO - 2016-05-18 18:39:31 --> Config Class Initialized
INFO - 2016-05-18 18:39:31 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:39:31 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:39:31 --> Utf8 Class Initialized
INFO - 2016-05-18 18:39:31 --> URI Class Initialized
INFO - 2016-05-18 18:39:31 --> Router Class Initialized
INFO - 2016-05-18 18:39:31 --> Output Class Initialized
INFO - 2016-05-18 18:39:31 --> Security Class Initialized
DEBUG - 2016-05-18 18:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:39:31 --> Input Class Initialized
INFO - 2016-05-18 18:39:31 --> Language Class Initialized
INFO - 2016-05-18 18:39:31 --> Loader Class Initialized
INFO - 2016-05-18 18:39:31 --> Helper loaded: url_helper
INFO - 2016-05-18 18:39:31 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:39:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:39:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:39:31 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:39:31 --> Helper loaded: form_helper
INFO - 2016-05-18 18:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:39:31 --> Form Validation Class Initialized
INFO - 2016-05-18 18:39:31 --> Controller Class Initialized
INFO - 2016-05-18 18:39:31 --> Model Class Initialized
INFO - 2016-05-18 18:39:31 --> Database Driver Class Initialized
INFO - 2016-05-18 18:39:31 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:39:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:39:31 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:39:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:39:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-18 18:39:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:39:31 --> Final output sent to browser
DEBUG - 2016-05-18 18:39:31 --> Total execution time: 0.0825
INFO - 2016-05-18 18:39:32 --> Config Class Initialized
INFO - 2016-05-18 18:39:32 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:39:32 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:39:32 --> Utf8 Class Initialized
INFO - 2016-05-18 18:39:32 --> URI Class Initialized
INFO - 2016-05-18 18:39:32 --> Router Class Initialized
INFO - 2016-05-18 18:39:32 --> Output Class Initialized
INFO - 2016-05-18 18:39:32 --> Security Class Initialized
DEBUG - 2016-05-18 18:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:39:32 --> Input Class Initialized
INFO - 2016-05-18 18:39:32 --> Language Class Initialized
INFO - 2016-05-18 18:39:32 --> Loader Class Initialized
INFO - 2016-05-18 18:39:32 --> Helper loaded: url_helper
INFO - 2016-05-18 18:39:32 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:39:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:39:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:39:32 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:39:32 --> Helper loaded: form_helper
INFO - 2016-05-18 18:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:39:32 --> Form Validation Class Initialized
INFO - 2016-05-18 18:39:32 --> Controller Class Initialized
INFO - 2016-05-18 18:39:32 --> Model Class Initialized
INFO - 2016-05-18 18:39:32 --> Database Driver Class Initialized
INFO - 2016-05-18 18:39:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:39:32 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:39:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:39:32 --> Final output sent to browser
DEBUG - 2016-05-18 18:39:32 --> Total execution time: 0.1097
INFO - 2016-05-18 18:39:48 --> Config Class Initialized
INFO - 2016-05-18 18:39:48 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:39:48 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:39:48 --> Utf8 Class Initialized
INFO - 2016-05-18 18:39:48 --> URI Class Initialized
INFO - 2016-05-18 18:39:48 --> Router Class Initialized
INFO - 2016-05-18 18:39:48 --> Output Class Initialized
INFO - 2016-05-18 18:39:48 --> Security Class Initialized
DEBUG - 2016-05-18 18:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:39:48 --> Input Class Initialized
INFO - 2016-05-18 18:39:48 --> Language Class Initialized
INFO - 2016-05-18 18:39:48 --> Loader Class Initialized
INFO - 2016-05-18 18:39:48 --> Helper loaded: url_helper
INFO - 2016-05-18 18:39:48 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:39:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:39:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:39:48 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:39:48 --> Helper loaded: form_helper
INFO - 2016-05-18 18:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:39:48 --> Form Validation Class Initialized
INFO - 2016-05-18 18:39:48 --> Controller Class Initialized
INFO - 2016-05-18 18:39:48 --> Model Class Initialized
INFO - 2016-05-18 18:39:48 --> Database Driver Class Initialized
INFO - 2016-05-18 18:39:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:39:48 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:39:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:39:49 --> Config Class Initialized
INFO - 2016-05-18 18:39:49 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:39:49 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:39:49 --> Utf8 Class Initialized
INFO - 2016-05-18 18:39:49 --> URI Class Initialized
INFO - 2016-05-18 18:39:49 --> Router Class Initialized
INFO - 2016-05-18 18:39:49 --> Output Class Initialized
INFO - 2016-05-18 18:39:49 --> Security Class Initialized
DEBUG - 2016-05-18 18:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:39:49 --> Input Class Initialized
INFO - 2016-05-18 18:39:49 --> Language Class Initialized
INFO - 2016-05-18 18:39:49 --> Loader Class Initialized
INFO - 2016-05-18 18:39:49 --> Helper loaded: url_helper
INFO - 2016-05-18 18:39:49 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:39:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:39:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:39:49 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:39:49 --> Helper loaded: form_helper
INFO - 2016-05-18 18:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:39:49 --> Form Validation Class Initialized
INFO - 2016-05-18 18:39:49 --> Controller Class Initialized
INFO - 2016-05-18 18:39:49 --> Model Class Initialized
INFO - 2016-05-18 18:39:49 --> Database Driver Class Initialized
INFO - 2016-05-18 18:39:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:39:49 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:39:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:39:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-18 18:39:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:39:49 --> Final output sent to browser
DEBUG - 2016-05-18 18:39:49 --> Total execution time: 0.0969
INFO - 2016-05-18 18:39:49 --> Config Class Initialized
INFO - 2016-05-18 18:39:49 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:39:49 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:39:49 --> Utf8 Class Initialized
INFO - 2016-05-18 18:39:49 --> URI Class Initialized
INFO - 2016-05-18 18:39:49 --> Router Class Initialized
INFO - 2016-05-18 18:39:49 --> Output Class Initialized
INFO - 2016-05-18 18:39:49 --> Security Class Initialized
DEBUG - 2016-05-18 18:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:39:49 --> Input Class Initialized
INFO - 2016-05-18 18:39:49 --> Language Class Initialized
INFO - 2016-05-18 18:39:49 --> Loader Class Initialized
INFO - 2016-05-18 18:39:49 --> Helper loaded: url_helper
INFO - 2016-05-18 18:39:49 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:39:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:39:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:39:49 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:39:49 --> Helper loaded: form_helper
INFO - 2016-05-18 18:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:39:49 --> Form Validation Class Initialized
INFO - 2016-05-18 18:39:49 --> Controller Class Initialized
INFO - 2016-05-18 18:39:49 --> Model Class Initialized
INFO - 2016-05-18 18:39:49 --> Database Driver Class Initialized
INFO - 2016-05-18 18:39:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:39:49 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:39:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:39:49 --> Final output sent to browser
DEBUG - 2016-05-18 18:39:49 --> Total execution time: 0.1004
INFO - 2016-05-18 18:40:49 --> Config Class Initialized
INFO - 2016-05-18 18:40:49 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:40:49 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:40:49 --> Utf8 Class Initialized
INFO - 2016-05-18 18:40:49 --> URI Class Initialized
INFO - 2016-05-18 18:40:49 --> Router Class Initialized
INFO - 2016-05-18 18:40:49 --> Output Class Initialized
INFO - 2016-05-18 18:40:49 --> Security Class Initialized
DEBUG - 2016-05-18 18:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:40:49 --> Input Class Initialized
INFO - 2016-05-18 18:40:49 --> Language Class Initialized
INFO - 2016-05-18 18:40:49 --> Loader Class Initialized
INFO - 2016-05-18 18:40:49 --> Helper loaded: url_helper
INFO - 2016-05-18 18:40:49 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:40:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:40:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:40:49 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:40:49 --> Helper loaded: form_helper
INFO - 2016-05-18 18:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:40:49 --> Form Validation Class Initialized
INFO - 2016-05-18 18:40:49 --> Controller Class Initialized
INFO - 2016-05-18 18:40:49 --> Model Class Initialized
INFO - 2016-05-18 18:40:49 --> Database Driver Class Initialized
INFO - 2016-05-18 18:40:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:40:49 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:40:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:40:49 --> Final output sent to browser
DEBUG - 2016-05-18 18:40:49 --> Total execution time: 0.1051
INFO - 2016-05-18 18:41:49 --> Config Class Initialized
INFO - 2016-05-18 18:41:49 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:41:49 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:41:49 --> Utf8 Class Initialized
INFO - 2016-05-18 18:41:49 --> URI Class Initialized
INFO - 2016-05-18 18:41:49 --> Router Class Initialized
INFO - 2016-05-18 18:41:49 --> Output Class Initialized
INFO - 2016-05-18 18:41:49 --> Security Class Initialized
DEBUG - 2016-05-18 18:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:41:49 --> Input Class Initialized
INFO - 2016-05-18 18:41:49 --> Language Class Initialized
INFO - 2016-05-18 18:41:49 --> Loader Class Initialized
INFO - 2016-05-18 18:41:49 --> Helper loaded: url_helper
INFO - 2016-05-18 18:41:49 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:41:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:41:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:41:49 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:41:49 --> Helper loaded: form_helper
INFO - 2016-05-18 18:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:41:49 --> Form Validation Class Initialized
INFO - 2016-05-18 18:41:49 --> Controller Class Initialized
INFO - 2016-05-18 18:41:49 --> Model Class Initialized
INFO - 2016-05-18 18:41:49 --> Database Driver Class Initialized
INFO - 2016-05-18 18:41:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:41:49 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:41:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:41:49 --> Final output sent to browser
DEBUG - 2016-05-18 18:41:49 --> Total execution time: 0.1289
INFO - 2016-05-18 18:41:57 --> Config Class Initialized
INFO - 2016-05-18 18:41:57 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:41:57 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:41:57 --> Utf8 Class Initialized
INFO - 2016-05-18 18:41:57 --> URI Class Initialized
INFO - 2016-05-18 18:41:57 --> Router Class Initialized
INFO - 2016-05-18 18:41:57 --> Output Class Initialized
INFO - 2016-05-18 18:41:57 --> Security Class Initialized
DEBUG - 2016-05-18 18:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:41:57 --> Input Class Initialized
INFO - 2016-05-18 18:41:57 --> Language Class Initialized
INFO - 2016-05-18 18:41:57 --> Loader Class Initialized
INFO - 2016-05-18 18:41:57 --> Helper loaded: url_helper
INFO - 2016-05-18 18:41:57 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:41:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:41:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:41:57 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:41:57 --> Helper loaded: form_helper
INFO - 2016-05-18 18:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:41:57 --> Form Validation Class Initialized
INFO - 2016-05-18 18:41:57 --> Controller Class Initialized
INFO - 2016-05-18 18:41:57 --> Model Class Initialized
INFO - 2016-05-18 18:41:57 --> Database Driver Class Initialized
INFO - 2016-05-18 18:41:57 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:41:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:41:57 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:41:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:41:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-18 18:41:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:41:57 --> Final output sent to browser
DEBUG - 2016-05-18 18:41:57 --> Total execution time: 0.0882
INFO - 2016-05-18 18:41:58 --> Config Class Initialized
INFO - 2016-05-18 18:41:58 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:41:58 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:41:58 --> Utf8 Class Initialized
INFO - 2016-05-18 18:41:58 --> URI Class Initialized
INFO - 2016-05-18 18:41:58 --> Router Class Initialized
INFO - 2016-05-18 18:41:58 --> Output Class Initialized
INFO - 2016-05-18 18:41:58 --> Security Class Initialized
DEBUG - 2016-05-18 18:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:41:58 --> Input Class Initialized
INFO - 2016-05-18 18:41:58 --> Language Class Initialized
INFO - 2016-05-18 18:41:58 --> Loader Class Initialized
INFO - 2016-05-18 18:41:58 --> Helper loaded: url_helper
INFO - 2016-05-18 18:41:58 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:41:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:41:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:41:58 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:41:58 --> Helper loaded: form_helper
INFO - 2016-05-18 18:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:41:58 --> Form Validation Class Initialized
INFO - 2016-05-18 18:41:58 --> Controller Class Initialized
INFO - 2016-05-18 18:41:58 --> Model Class Initialized
INFO - 2016-05-18 18:41:58 --> Database Driver Class Initialized
INFO - 2016-05-18 18:41:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:41:58 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:41:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:41:58 --> Final output sent to browser
DEBUG - 2016-05-18 18:41:58 --> Total execution time: 0.0798
INFO - 2016-05-18 18:42:03 --> Config Class Initialized
INFO - 2016-05-18 18:42:03 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:42:03 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:42:03 --> Utf8 Class Initialized
INFO - 2016-05-18 18:42:03 --> URI Class Initialized
INFO - 2016-05-18 18:42:03 --> Router Class Initialized
INFO - 2016-05-18 18:42:03 --> Output Class Initialized
INFO - 2016-05-18 18:42:03 --> Security Class Initialized
DEBUG - 2016-05-18 18:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:42:03 --> Input Class Initialized
INFO - 2016-05-18 18:42:03 --> Language Class Initialized
INFO - 2016-05-18 18:42:03 --> Loader Class Initialized
INFO - 2016-05-18 18:42:03 --> Helper loaded: url_helper
INFO - 2016-05-18 18:42:03 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:42:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:42:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:42:03 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:42:03 --> Helper loaded: form_helper
INFO - 2016-05-18 18:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:42:03 --> Form Validation Class Initialized
INFO - 2016-05-18 18:42:03 --> Controller Class Initialized
INFO - 2016-05-18 18:42:03 --> Model Class Initialized
INFO - 2016-05-18 18:42:03 --> Database Driver Class Initialized
INFO - 2016-05-18 18:42:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:42:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:42:03 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:42:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-18 18:42:03 --> Severity: Notice --> Undefined index: categoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 47
ERROR - 2016-05-18 18:42:03 --> Severity: Notice --> Undefined index: categoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 47
ERROR - 2016-05-18 18:42:03 --> Severity: Notice --> Undefined index: categoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 47
ERROR - 2016-05-18 18:42:03 --> Severity: Notice --> Undefined index: categoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 47
ERROR - 2016-05-18 18:42:03 --> Severity: Notice --> Undefined index: categoria C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php 47
INFO - 2016-05-18 18:42:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-18 18:42:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:42:03 --> Final output sent to browser
DEBUG - 2016-05-18 18:42:03 --> Total execution time: 0.1097
INFO - 2016-05-18 18:42:03 --> Config Class Initialized
INFO - 2016-05-18 18:42:03 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:42:03 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:42:03 --> Utf8 Class Initialized
INFO - 2016-05-18 18:42:03 --> URI Class Initialized
INFO - 2016-05-18 18:42:03 --> Router Class Initialized
INFO - 2016-05-18 18:42:03 --> Output Class Initialized
INFO - 2016-05-18 18:42:03 --> Security Class Initialized
DEBUG - 2016-05-18 18:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:42:03 --> Input Class Initialized
INFO - 2016-05-18 18:42:03 --> Language Class Initialized
INFO - 2016-05-18 18:42:03 --> Loader Class Initialized
INFO - 2016-05-18 18:42:03 --> Helper loaded: url_helper
INFO - 2016-05-18 18:42:03 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:42:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:42:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:42:03 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:42:03 --> Helper loaded: form_helper
INFO - 2016-05-18 18:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:42:03 --> Form Validation Class Initialized
INFO - 2016-05-18 18:42:03 --> Controller Class Initialized
INFO - 2016-05-18 18:42:03 --> Model Class Initialized
INFO - 2016-05-18 18:42:03 --> Database Driver Class Initialized
INFO - 2016-05-18 18:42:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:42:03 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:42:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:42:03 --> Final output sent to browser
DEBUG - 2016-05-18 18:42:03 --> Total execution time: 0.0867
INFO - 2016-05-18 18:43:03 --> Config Class Initialized
INFO - 2016-05-18 18:43:03 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:43:03 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:43:03 --> Utf8 Class Initialized
INFO - 2016-05-18 18:43:03 --> URI Class Initialized
INFO - 2016-05-18 18:43:03 --> Router Class Initialized
INFO - 2016-05-18 18:43:03 --> Output Class Initialized
INFO - 2016-05-18 18:43:03 --> Security Class Initialized
DEBUG - 2016-05-18 18:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:43:03 --> Input Class Initialized
INFO - 2016-05-18 18:43:03 --> Language Class Initialized
INFO - 2016-05-18 18:43:03 --> Loader Class Initialized
INFO - 2016-05-18 18:43:03 --> Helper loaded: url_helper
INFO - 2016-05-18 18:43:03 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:43:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:43:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:43:03 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:43:03 --> Helper loaded: form_helper
INFO - 2016-05-18 18:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:43:03 --> Form Validation Class Initialized
INFO - 2016-05-18 18:43:03 --> Controller Class Initialized
INFO - 2016-05-18 18:43:03 --> Model Class Initialized
INFO - 2016-05-18 18:43:03 --> Database Driver Class Initialized
INFO - 2016-05-18 18:43:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:43:03 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:43:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:43:03 --> Final output sent to browser
DEBUG - 2016-05-18 18:43:03 --> Total execution time: 0.1033
INFO - 2016-05-18 18:43:33 --> Config Class Initialized
INFO - 2016-05-18 18:43:33 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:43:33 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:43:33 --> Utf8 Class Initialized
INFO - 2016-05-18 18:43:33 --> URI Class Initialized
INFO - 2016-05-18 18:43:33 --> Router Class Initialized
INFO - 2016-05-18 18:43:33 --> Output Class Initialized
INFO - 2016-05-18 18:43:33 --> Security Class Initialized
DEBUG - 2016-05-18 18:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:43:33 --> Input Class Initialized
INFO - 2016-05-18 18:43:33 --> Language Class Initialized
INFO - 2016-05-18 18:43:33 --> Loader Class Initialized
INFO - 2016-05-18 18:43:33 --> Helper loaded: url_helper
INFO - 2016-05-18 18:43:33 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:43:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:43:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:43:33 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:43:33 --> Helper loaded: form_helper
INFO - 2016-05-18 18:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:43:33 --> Form Validation Class Initialized
INFO - 2016-05-18 18:43:33 --> Controller Class Initialized
INFO - 2016-05-18 18:43:33 --> Model Class Initialized
INFO - 2016-05-18 18:43:33 --> Database Driver Class Initialized
INFO - 2016-05-18 18:43:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:43:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:43:33 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:43:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-18 18:43:33 --> Query error: Unknown column 'cat.nomnbre' in 'field list' - Invalid query: SELECT prod.*, cat.nomnbre 'categoria' FROM producto prod INNER JOIN categoria cat ON prod.idCategoria=cat.idCategoria INNER JOIN proveedor prv ON prod.idProveedor=prv.idProveedor WHERE prod.referencia LIKE '%00%' OR prod.nombre LIKE '%00%' OR prod.marca LIKE '%00%' OR prod.precio LIKE '%00%' OR prod.precio_venta LIKE '%00%' OR prod.iva LIKE '%00%' OR prod.stock LIKE '%00%' OR prod.descripcion LIKE '%00%' OR prod.estado LIKE '%00%' OR cat.nombre LIKE '%00%' OR prv.nombre LIKE '%00%' LIMIT 0, 5; 
INFO - 2016-05-18 18:43:33 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-18 18:43:40 --> Config Class Initialized
INFO - 2016-05-18 18:43:40 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:43:40 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:43:40 --> Utf8 Class Initialized
INFO - 2016-05-18 18:43:40 --> URI Class Initialized
INFO - 2016-05-18 18:43:40 --> Router Class Initialized
INFO - 2016-05-18 18:43:40 --> Output Class Initialized
INFO - 2016-05-18 18:43:40 --> Security Class Initialized
DEBUG - 2016-05-18 18:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:43:40 --> Input Class Initialized
INFO - 2016-05-18 18:43:40 --> Language Class Initialized
INFO - 2016-05-18 18:43:40 --> Loader Class Initialized
INFO - 2016-05-18 18:43:40 --> Helper loaded: url_helper
INFO - 2016-05-18 18:43:40 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:43:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:43:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:43:40 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:43:40 --> Helper loaded: form_helper
INFO - 2016-05-18 18:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:43:40 --> Form Validation Class Initialized
INFO - 2016-05-18 18:43:40 --> Controller Class Initialized
INFO - 2016-05-18 18:43:40 --> Model Class Initialized
INFO - 2016-05-18 18:43:40 --> Database Driver Class Initialized
INFO - 2016-05-18 18:43:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:43:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:43:40 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:43:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:43:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-18 18:43:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:43:40 --> Final output sent to browser
DEBUG - 2016-05-18 18:43:40 --> Total execution time: 0.0974
INFO - 2016-05-18 18:43:41 --> Config Class Initialized
INFO - 2016-05-18 18:43:41 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:43:41 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:43:41 --> Utf8 Class Initialized
INFO - 2016-05-18 18:43:41 --> URI Class Initialized
INFO - 2016-05-18 18:43:41 --> Router Class Initialized
INFO - 2016-05-18 18:43:41 --> Output Class Initialized
INFO - 2016-05-18 18:43:41 --> Security Class Initialized
DEBUG - 2016-05-18 18:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:43:41 --> Input Class Initialized
INFO - 2016-05-18 18:43:41 --> Language Class Initialized
INFO - 2016-05-18 18:43:41 --> Loader Class Initialized
INFO - 2016-05-18 18:43:41 --> Helper loaded: url_helper
INFO - 2016-05-18 18:43:41 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:43:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:43:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:43:41 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:43:41 --> Helper loaded: form_helper
INFO - 2016-05-18 18:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:43:41 --> Form Validation Class Initialized
INFO - 2016-05-18 18:43:41 --> Controller Class Initialized
INFO - 2016-05-18 18:43:41 --> Model Class Initialized
INFO - 2016-05-18 18:43:41 --> Database Driver Class Initialized
INFO - 2016-05-18 18:43:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:43:41 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:43:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:43:41 --> Final output sent to browser
DEBUG - 2016-05-18 18:43:41 --> Total execution time: 0.0999
INFO - 2016-05-18 18:43:53 --> Config Class Initialized
INFO - 2016-05-18 18:43:53 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:43:53 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:43:53 --> Utf8 Class Initialized
INFO - 2016-05-18 18:43:53 --> URI Class Initialized
INFO - 2016-05-18 18:43:53 --> Router Class Initialized
INFO - 2016-05-18 18:43:53 --> Output Class Initialized
INFO - 2016-05-18 18:43:53 --> Security Class Initialized
DEBUG - 2016-05-18 18:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:43:53 --> Input Class Initialized
INFO - 2016-05-18 18:43:53 --> Language Class Initialized
INFO - 2016-05-18 18:43:53 --> Loader Class Initialized
INFO - 2016-05-18 18:43:53 --> Helper loaded: url_helper
INFO - 2016-05-18 18:43:53 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:43:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:43:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:43:53 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:43:53 --> Helper loaded: form_helper
INFO - 2016-05-18 18:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:43:53 --> Form Validation Class Initialized
INFO - 2016-05-18 18:43:53 --> Controller Class Initialized
INFO - 2016-05-18 18:43:53 --> Model Class Initialized
INFO - 2016-05-18 18:43:53 --> Database Driver Class Initialized
INFO - 2016-05-18 18:43:53 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:43:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:43:53 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:43:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:43:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-18 18:43:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:43:53 --> Final output sent to browser
DEBUG - 2016-05-18 18:43:53 --> Total execution time: 0.0899
INFO - 2016-05-18 18:43:53 --> Config Class Initialized
INFO - 2016-05-18 18:43:53 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:43:53 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:43:53 --> Utf8 Class Initialized
INFO - 2016-05-18 18:43:53 --> URI Class Initialized
INFO - 2016-05-18 18:43:53 --> Router Class Initialized
INFO - 2016-05-18 18:43:53 --> Output Class Initialized
INFO - 2016-05-18 18:43:53 --> Security Class Initialized
DEBUG - 2016-05-18 18:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:43:53 --> Input Class Initialized
INFO - 2016-05-18 18:43:53 --> Language Class Initialized
INFO - 2016-05-18 18:43:53 --> Loader Class Initialized
INFO - 2016-05-18 18:43:53 --> Helper loaded: url_helper
INFO - 2016-05-18 18:43:53 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:43:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:43:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:43:53 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:43:53 --> Helper loaded: form_helper
INFO - 2016-05-18 18:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:43:53 --> Form Validation Class Initialized
INFO - 2016-05-18 18:43:53 --> Controller Class Initialized
INFO - 2016-05-18 18:43:53 --> Model Class Initialized
INFO - 2016-05-18 18:43:53 --> Database Driver Class Initialized
INFO - 2016-05-18 18:43:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:43:53 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:43:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:43:53 --> Final output sent to browser
DEBUG - 2016-05-18 18:43:53 --> Total execution time: 0.1061
INFO - 2016-05-18 18:43:59 --> Config Class Initialized
INFO - 2016-05-18 18:43:59 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:00 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:00 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:00 --> URI Class Initialized
INFO - 2016-05-18 18:44:00 --> Router Class Initialized
INFO - 2016-05-18 18:44:00 --> Output Class Initialized
INFO - 2016-05-18 18:44:00 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:00 --> Input Class Initialized
INFO - 2016-05-18 18:44:00 --> Language Class Initialized
INFO - 2016-05-18 18:44:00 --> Loader Class Initialized
INFO - 2016-05-18 18:44:00 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:00 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:00 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:00 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:00 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:00 --> Controller Class Initialized
INFO - 2016-05-18 18:44:00 --> Model Class Initialized
INFO - 2016-05-18 18:44:00 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:00 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:44:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:00 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-18 18:44:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:44:00 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:00 --> Total execution time: 0.0835
INFO - 2016-05-18 18:44:00 --> Config Class Initialized
INFO - 2016-05-18 18:44:00 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:00 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:00 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:00 --> URI Class Initialized
INFO - 2016-05-18 18:44:00 --> Router Class Initialized
INFO - 2016-05-18 18:44:00 --> Output Class Initialized
INFO - 2016-05-18 18:44:00 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:00 --> Input Class Initialized
INFO - 2016-05-18 18:44:00 --> Language Class Initialized
INFO - 2016-05-18 18:44:00 --> Loader Class Initialized
INFO - 2016-05-18 18:44:00 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:00 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:00 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:00 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:00 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:00 --> Controller Class Initialized
INFO - 2016-05-18 18:44:00 --> Model Class Initialized
INFO - 2016-05-18 18:44:00 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:00 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:00 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:00 --> Total execution time: 0.1095
INFO - 2016-05-18 18:44:07 --> Config Class Initialized
INFO - 2016-05-18 18:44:07 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:08 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:08 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:08 --> URI Class Initialized
INFO - 2016-05-18 18:44:08 --> Router Class Initialized
INFO - 2016-05-18 18:44:08 --> Output Class Initialized
INFO - 2016-05-18 18:44:08 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:08 --> Input Class Initialized
INFO - 2016-05-18 18:44:08 --> Language Class Initialized
INFO - 2016-05-18 18:44:08 --> Loader Class Initialized
INFO - 2016-05-18 18:44:08 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:08 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:08 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:08 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:08 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:08 --> Controller Class Initialized
INFO - 2016-05-18 18:44:08 --> Model Class Initialized
INFO - 2016-05-18 18:44:08 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:08 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:44:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:08 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:08 --> Helper loaded: nif_validate_helper
INFO - 2016-05-18 18:44:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-18 18:44:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:44:08 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:08 --> Total execution time: 0.0817
INFO - 2016-05-18 18:44:08 --> Config Class Initialized
INFO - 2016-05-18 18:44:08 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:08 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:08 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:08 --> URI Class Initialized
INFO - 2016-05-18 18:44:08 --> Router Class Initialized
INFO - 2016-05-18 18:44:08 --> Output Class Initialized
INFO - 2016-05-18 18:44:08 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:08 --> Input Class Initialized
INFO - 2016-05-18 18:44:08 --> Language Class Initialized
INFO - 2016-05-18 18:44:08 --> Loader Class Initialized
INFO - 2016-05-18 18:44:08 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:08 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:08 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:08 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:08 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:08 --> Controller Class Initialized
INFO - 2016-05-18 18:44:08 --> Model Class Initialized
INFO - 2016-05-18 18:44:08 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:08 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:08 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:08 --> Total execution time: 0.1154
INFO - 2016-05-18 18:44:10 --> Config Class Initialized
INFO - 2016-05-18 18:44:10 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:10 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:10 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:10 --> URI Class Initialized
INFO - 2016-05-18 18:44:10 --> Router Class Initialized
INFO - 2016-05-18 18:44:10 --> Output Class Initialized
INFO - 2016-05-18 18:44:10 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:10 --> Input Class Initialized
INFO - 2016-05-18 18:44:10 --> Language Class Initialized
INFO - 2016-05-18 18:44:10 --> Loader Class Initialized
INFO - 2016-05-18 18:44:10 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:10 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:10 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:10 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:10 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:10 --> Controller Class Initialized
INFO - 2016-05-18 18:44:10 --> Model Class Initialized
INFO - 2016-05-18 18:44:10 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:10 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:44:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:10 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:10 --> Helper loaded: nif_validate_helper
INFO - 2016-05-18 18:44:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-18 18:44:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:44:10 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:10 --> Total execution time: 0.0839
INFO - 2016-05-18 18:44:11 --> Config Class Initialized
INFO - 2016-05-18 18:44:11 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:11 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:11 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:11 --> URI Class Initialized
INFO - 2016-05-18 18:44:11 --> Router Class Initialized
INFO - 2016-05-18 18:44:11 --> Output Class Initialized
INFO - 2016-05-18 18:44:11 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:11 --> Input Class Initialized
INFO - 2016-05-18 18:44:11 --> Language Class Initialized
INFO - 2016-05-18 18:44:11 --> Loader Class Initialized
INFO - 2016-05-18 18:44:11 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:11 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:11 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:11 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:11 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:11 --> Controller Class Initialized
INFO - 2016-05-18 18:44:11 --> Model Class Initialized
INFO - 2016-05-18 18:44:11 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:11 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:11 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:11 --> Total execution time: 0.0907
INFO - 2016-05-18 18:44:12 --> Config Class Initialized
INFO - 2016-05-18 18:44:12 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:12 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:12 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:12 --> URI Class Initialized
INFO - 2016-05-18 18:44:12 --> Router Class Initialized
INFO - 2016-05-18 18:44:12 --> Output Class Initialized
INFO - 2016-05-18 18:44:12 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:12 --> Input Class Initialized
INFO - 2016-05-18 18:44:12 --> Language Class Initialized
INFO - 2016-05-18 18:44:12 --> Loader Class Initialized
INFO - 2016-05-18 18:44:12 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:12 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:12 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:12 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:12 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:12 --> Controller Class Initialized
INFO - 2016-05-18 18:44:12 --> Model Class Initialized
INFO - 2016-05-18 18:44:12 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:12 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:44:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:12 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:12 --> Helper loaded: nif_validate_helper
INFO - 2016-05-18 18:44:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-18 18:44:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:44:12 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:12 --> Total execution time: 0.0874
INFO - 2016-05-18 18:44:12 --> Config Class Initialized
INFO - 2016-05-18 18:44:12 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:12 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:12 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:12 --> URI Class Initialized
INFO - 2016-05-18 18:44:12 --> Router Class Initialized
INFO - 2016-05-18 18:44:12 --> Output Class Initialized
INFO - 2016-05-18 18:44:12 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:12 --> Input Class Initialized
INFO - 2016-05-18 18:44:12 --> Language Class Initialized
INFO - 2016-05-18 18:44:12 --> Loader Class Initialized
INFO - 2016-05-18 18:44:12 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:12 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:12 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:12 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:12 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:12 --> Controller Class Initialized
INFO - 2016-05-18 18:44:12 --> Model Class Initialized
INFO - 2016-05-18 18:44:12 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:12 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:12 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:12 --> Total execution time: 0.1137
INFO - 2016-05-18 18:44:16 --> Config Class Initialized
INFO - 2016-05-18 18:44:16 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:16 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:16 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:16 --> URI Class Initialized
INFO - 2016-05-18 18:44:16 --> Router Class Initialized
INFO - 2016-05-18 18:44:16 --> Output Class Initialized
INFO - 2016-05-18 18:44:16 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:16 --> Input Class Initialized
INFO - 2016-05-18 18:44:16 --> Language Class Initialized
INFO - 2016-05-18 18:44:16 --> Loader Class Initialized
INFO - 2016-05-18 18:44:16 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:16 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:16 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:16 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:16 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:16 --> Controller Class Initialized
INFO - 2016-05-18 18:44:16 --> Model Class Initialized
INFO - 2016-05-18 18:44:16 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:16 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:44:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:16 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:16 --> Helper loaded: nif_validate_helper
INFO - 2016-05-18 18:44:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-18 18:44:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:44:16 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:16 --> Total execution time: 0.0835
INFO - 2016-05-18 18:44:16 --> Config Class Initialized
INFO - 2016-05-18 18:44:16 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:16 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:16 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:16 --> URI Class Initialized
INFO - 2016-05-18 18:44:16 --> Router Class Initialized
INFO - 2016-05-18 18:44:16 --> Output Class Initialized
INFO - 2016-05-18 18:44:16 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:16 --> Input Class Initialized
INFO - 2016-05-18 18:44:16 --> Language Class Initialized
INFO - 2016-05-18 18:44:16 --> Loader Class Initialized
INFO - 2016-05-18 18:44:16 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:16 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:16 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:16 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:16 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:16 --> Controller Class Initialized
INFO - 2016-05-18 18:44:16 --> Model Class Initialized
INFO - 2016-05-18 18:44:16 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:16 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:16 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:16 --> Total execution time: 0.1225
INFO - 2016-05-18 18:44:23 --> Config Class Initialized
INFO - 2016-05-18 18:44:23 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:23 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:23 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:23 --> URI Class Initialized
INFO - 2016-05-18 18:44:23 --> Router Class Initialized
INFO - 2016-05-18 18:44:23 --> Output Class Initialized
INFO - 2016-05-18 18:44:23 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:23 --> Input Class Initialized
INFO - 2016-05-18 18:44:23 --> Language Class Initialized
INFO - 2016-05-18 18:44:23 --> Loader Class Initialized
INFO - 2016-05-18 18:44:23 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:23 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:23 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:23 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:23 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:23 --> Controller Class Initialized
INFO - 2016-05-18 18:44:23 --> Model Class Initialized
INFO - 2016-05-18 18:44:23 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:23 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-18 18:44:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:44:23 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:23 --> Total execution time: 0.0786
INFO - 2016-05-18 18:44:23 --> Config Class Initialized
INFO - 2016-05-18 18:44:23 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:23 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:23 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:23 --> URI Class Initialized
INFO - 2016-05-18 18:44:23 --> Router Class Initialized
INFO - 2016-05-18 18:44:23 --> Output Class Initialized
INFO - 2016-05-18 18:44:23 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:23 --> Input Class Initialized
INFO - 2016-05-18 18:44:23 --> Language Class Initialized
INFO - 2016-05-18 18:44:23 --> Loader Class Initialized
INFO - 2016-05-18 18:44:23 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:23 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:23 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:23 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:23 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:23 --> Controller Class Initialized
INFO - 2016-05-18 18:44:23 --> Model Class Initialized
INFO - 2016-05-18 18:44:23 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:23 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:23 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:23 --> Total execution time: 0.1255
INFO - 2016-05-18 18:44:31 --> Config Class Initialized
INFO - 2016-05-18 18:44:31 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:31 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:31 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:31 --> URI Class Initialized
INFO - 2016-05-18 18:44:31 --> Router Class Initialized
INFO - 2016-05-18 18:44:31 --> Output Class Initialized
INFO - 2016-05-18 18:44:31 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:31 --> Input Class Initialized
INFO - 2016-05-18 18:44:31 --> Language Class Initialized
INFO - 2016-05-18 18:44:31 --> Loader Class Initialized
INFO - 2016-05-18 18:44:31 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:31 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:31 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:31 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:31 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:31 --> Controller Class Initialized
INFO - 2016-05-18 18:44:31 --> Model Class Initialized
INFO - 2016-05-18 18:44:31 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:31 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-18 18:44:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:44:31 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:31 --> Total execution time: 0.0790
INFO - 2016-05-18 18:44:31 --> Config Class Initialized
INFO - 2016-05-18 18:44:31 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:31 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:31 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:31 --> URI Class Initialized
INFO - 2016-05-18 18:44:31 --> Router Class Initialized
INFO - 2016-05-18 18:44:31 --> Output Class Initialized
INFO - 2016-05-18 18:44:31 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:31 --> Input Class Initialized
INFO - 2016-05-18 18:44:31 --> Language Class Initialized
INFO - 2016-05-18 18:44:31 --> Loader Class Initialized
INFO - 2016-05-18 18:44:31 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:31 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:31 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:31 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:31 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:31 --> Controller Class Initialized
INFO - 2016-05-18 18:44:31 --> Model Class Initialized
INFO - 2016-05-18 18:44:31 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:31 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:31 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:31 --> Total execution time: 0.1080
INFO - 2016-05-18 18:44:32 --> Config Class Initialized
INFO - 2016-05-18 18:44:32 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:32 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:32 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:32 --> URI Class Initialized
INFO - 2016-05-18 18:44:32 --> Router Class Initialized
INFO - 2016-05-18 18:44:32 --> Output Class Initialized
INFO - 2016-05-18 18:44:32 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:32 --> Input Class Initialized
INFO - 2016-05-18 18:44:32 --> Language Class Initialized
INFO - 2016-05-18 18:44:32 --> Loader Class Initialized
INFO - 2016-05-18 18:44:32 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:32 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:32 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:32 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:32 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:32 --> Controller Class Initialized
INFO - 2016-05-18 18:44:32 --> Model Class Initialized
INFO - 2016-05-18 18:44:32 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:32 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaUsuarios.php
INFO - 2016-05-18 18:44:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:44:32 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:32 --> Total execution time: 0.1402
INFO - 2016-05-18 18:44:33 --> Config Class Initialized
INFO - 2016-05-18 18:44:33 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:33 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:33 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:33 --> URI Class Initialized
INFO - 2016-05-18 18:44:33 --> Router Class Initialized
INFO - 2016-05-18 18:44:33 --> Output Class Initialized
INFO - 2016-05-18 18:44:33 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:33 --> Input Class Initialized
INFO - 2016-05-18 18:44:33 --> Language Class Initialized
INFO - 2016-05-18 18:44:33 --> Loader Class Initialized
INFO - 2016-05-18 18:44:33 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:33 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:33 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:33 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:33 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:33 --> Controller Class Initialized
INFO - 2016-05-18 18:44:33 --> Model Class Initialized
INFO - 2016-05-18 18:44:33 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:33 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:44:33 --> Final output sent to browser
DEBUG - 2016-05-18 18:44:33 --> Total execution time: 0.1051
INFO - 2016-05-18 18:44:35 --> Config Class Initialized
INFO - 2016-05-18 18:44:35 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:44:35 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:44:35 --> Utf8 Class Initialized
INFO - 2016-05-18 18:44:36 --> URI Class Initialized
INFO - 2016-05-18 18:44:36 --> Router Class Initialized
INFO - 2016-05-18 18:44:36 --> Output Class Initialized
INFO - 2016-05-18 18:44:36 --> Security Class Initialized
DEBUG - 2016-05-18 18:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:44:36 --> Input Class Initialized
INFO - 2016-05-18 18:44:36 --> Language Class Initialized
INFO - 2016-05-18 18:44:36 --> Loader Class Initialized
INFO - 2016-05-18 18:44:36 --> Helper loaded: url_helper
INFO - 2016-05-18 18:44:36 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:44:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:44:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:44:36 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:44:36 --> Helper loaded: form_helper
INFO - 2016-05-18 18:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:44:36 --> Form Validation Class Initialized
INFO - 2016-05-18 18:44:36 --> Controller Class Initialized
INFO - 2016-05-18 18:44:36 --> Model Class Initialized
INFO - 2016-05-18 18:44:36 --> Database Driver Class Initialized
INFO - 2016-05-18 18:44:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:44:36 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:44:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:49:10 --> Config Class Initialized
INFO - 2016-05-18 18:49:10 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:49:10 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:49:10 --> Utf8 Class Initialized
INFO - 2016-05-18 18:49:10 --> URI Class Initialized
INFO - 2016-05-18 18:49:10 --> Router Class Initialized
INFO - 2016-05-18 18:49:10 --> Output Class Initialized
INFO - 2016-05-18 18:49:10 --> Security Class Initialized
DEBUG - 2016-05-18 18:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:49:10 --> Input Class Initialized
INFO - 2016-05-18 18:49:10 --> Language Class Initialized
INFO - 2016-05-18 18:49:10 --> Loader Class Initialized
INFO - 2016-05-18 18:49:10 --> Helper loaded: url_helper
INFO - 2016-05-18 18:49:10 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:49:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:49:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:49:10 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:49:10 --> Helper loaded: form_helper
INFO - 2016-05-18 18:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:49:10 --> Form Validation Class Initialized
INFO - 2016-05-18 18:49:10 --> Controller Class Initialized
INFO - 2016-05-18 18:49:10 --> Model Class Initialized
INFO - 2016-05-18 18:49:10 --> Database Driver Class Initialized
INFO - 2016-05-18 18:49:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:49:10 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:49:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-18 18:49:10 --> Query error: Table 'bdproyecto.facturas' doesn't exist - Invalid query: SELECT numfactura, fecha_factura, nombrecliente, importe_total, cantidad_total, descuento FROM facturas WHERE pendiente_pago LIKE 'Sí' LIMIT 0, 5; 
INFO - 2016-05-18 18:49:10 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-18 18:49:18 --> Config Class Initialized
INFO - 2016-05-18 18:49:18 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:49:18 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:49:18 --> Utf8 Class Initialized
INFO - 2016-05-18 18:49:18 --> URI Class Initialized
INFO - 2016-05-18 18:49:18 --> Router Class Initialized
INFO - 2016-05-18 18:49:18 --> Output Class Initialized
INFO - 2016-05-18 18:49:18 --> Security Class Initialized
DEBUG - 2016-05-18 18:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:49:18 --> Input Class Initialized
INFO - 2016-05-18 18:49:18 --> Language Class Initialized
INFO - 2016-05-18 18:49:18 --> Loader Class Initialized
INFO - 2016-05-18 18:49:18 --> Helper loaded: url_helper
INFO - 2016-05-18 18:49:18 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:49:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:49:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:49:18 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:49:18 --> Helper loaded: form_helper
INFO - 2016-05-18 18:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:49:18 --> Form Validation Class Initialized
INFO - 2016-05-18 18:49:18 --> Controller Class Initialized
INFO - 2016-05-18 18:49:18 --> Model Class Initialized
INFO - 2016-05-18 18:49:18 --> Database Driver Class Initialized
INFO - 2016-05-18 18:49:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:49:18 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:49:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-18 18:49:18 --> Query error: Unknown column 'nombrecliente' in 'field list' - Invalid query: SELECT numfactura, fecha_factura, nombrecliente, importe_total, cantidad_total, descuento FROM factura WHERE pendiente_pago LIKE 'Sí' LIMIT 0, 5; 
INFO - 2016-05-18 18:49:18 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-18 18:49:28 --> Config Class Initialized
INFO - 2016-05-18 18:49:28 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:49:28 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:49:28 --> Utf8 Class Initialized
INFO - 2016-05-18 18:49:28 --> URI Class Initialized
INFO - 2016-05-18 18:49:28 --> Router Class Initialized
INFO - 2016-05-18 18:49:29 --> Output Class Initialized
INFO - 2016-05-18 18:49:29 --> Security Class Initialized
DEBUG - 2016-05-18 18:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:49:29 --> Input Class Initialized
INFO - 2016-05-18 18:49:29 --> Language Class Initialized
INFO - 2016-05-18 18:49:29 --> Loader Class Initialized
INFO - 2016-05-18 18:49:29 --> Helper loaded: url_helper
INFO - 2016-05-18 18:49:29 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:49:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:49:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:49:29 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:49:29 --> Helper loaded: form_helper
INFO - 2016-05-18 18:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:49:29 --> Form Validation Class Initialized
INFO - 2016-05-18 18:49:29 --> Controller Class Initialized
INFO - 2016-05-18 18:49:29 --> Model Class Initialized
INFO - 2016-05-18 18:49:29 --> Database Driver Class Initialized
INFO - 2016-05-18 18:49:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:49:29 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:49:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-18 18:49:29 --> Severity: Notice --> Undefined index: nombrecliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php 31
ERROR - 2016-05-18 18:49:29 --> Severity: Notice --> Undefined index: estado C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php 37
ERROR - 2016-05-18 18:49:29 --> Severity: Notice --> Undefined index: estado C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php 64
ERROR - 2016-05-18 18:49:29 --> Severity: Notice --> Undefined index: nombrecliente C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php 31
ERROR - 2016-05-18 18:49:29 --> Severity: Notice --> Undefined index: estado C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php 37
ERROR - 2016-05-18 18:49:29 --> Severity: Notice --> Undefined index: estado C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php 64
INFO - 2016-05-18 18:49:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 18:49:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:49:29 --> Final output sent to browser
DEBUG - 2016-05-18 18:49:29 --> Total execution time: 0.0976
INFO - 2016-05-18 18:49:32 --> Config Class Initialized
INFO - 2016-05-18 18:49:32 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:49:32 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:49:32 --> Utf8 Class Initialized
INFO - 2016-05-18 18:49:32 --> URI Class Initialized
INFO - 2016-05-18 18:49:32 --> Router Class Initialized
INFO - 2016-05-18 18:49:32 --> Output Class Initialized
INFO - 2016-05-18 18:49:32 --> Security Class Initialized
DEBUG - 2016-05-18 18:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:49:32 --> Input Class Initialized
INFO - 2016-05-18 18:49:32 --> Language Class Initialized
INFO - 2016-05-18 18:49:32 --> Loader Class Initialized
INFO - 2016-05-18 18:49:32 --> Helper loaded: url_helper
INFO - 2016-05-18 18:49:32 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:49:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:49:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:49:32 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:49:32 --> Helper loaded: form_helper
INFO - 2016-05-18 18:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:49:32 --> Form Validation Class Initialized
INFO - 2016-05-18 18:49:32 --> Controller Class Initialized
INFO - 2016-05-18 18:49:32 --> Model Class Initialized
INFO - 2016-05-18 18:49:32 --> Database Driver Class Initialized
INFO - 2016-05-18 18:49:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:49:32 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:49:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:49:32 --> Final output sent to browser
DEBUG - 2016-05-18 18:49:32 --> Total execution time: 0.1057
INFO - 2016-05-18 18:49:45 --> Config Class Initialized
INFO - 2016-05-18 18:49:45 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:49:45 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:49:45 --> Utf8 Class Initialized
INFO - 2016-05-18 18:49:45 --> URI Class Initialized
INFO - 2016-05-18 18:49:45 --> Router Class Initialized
INFO - 2016-05-18 18:49:45 --> Output Class Initialized
INFO - 2016-05-18 18:49:45 --> Security Class Initialized
DEBUG - 2016-05-18 18:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:49:45 --> Input Class Initialized
INFO - 2016-05-18 18:49:45 --> Language Class Initialized
INFO - 2016-05-18 18:49:45 --> Loader Class Initialized
INFO - 2016-05-18 18:49:45 --> Helper loaded: url_helper
INFO - 2016-05-18 18:49:45 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:49:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:49:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:49:45 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:49:45 --> Helper loaded: form_helper
INFO - 2016-05-18 18:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:49:45 --> Form Validation Class Initialized
INFO - 2016-05-18 18:49:45 --> Controller Class Initialized
INFO - 2016-05-18 18:49:45 --> Model Class Initialized
INFO - 2016-05-18 18:49:45 --> Database Driver Class Initialized
INFO - 2016-05-18 18:49:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:49:45 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:49:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-18 18:49:45 --> Severity: Notice --> Undefined index: estado C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php 37
ERROR - 2016-05-18 18:49:45 --> Severity: Notice --> Undefined index: estado C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php 64
ERROR - 2016-05-18 18:49:45 --> Severity: Notice --> Undefined index: estado C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php 37
ERROR - 2016-05-18 18:49:45 --> Severity: Notice --> Undefined index: estado C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php 64
INFO - 2016-05-18 18:49:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 18:49:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:49:45 --> Final output sent to browser
DEBUG - 2016-05-18 18:49:45 --> Total execution time: 0.0902
INFO - 2016-05-18 18:49:46 --> Config Class Initialized
INFO - 2016-05-18 18:49:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:49:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:49:46 --> Utf8 Class Initialized
INFO - 2016-05-18 18:49:46 --> URI Class Initialized
INFO - 2016-05-18 18:49:46 --> Router Class Initialized
INFO - 2016-05-18 18:49:46 --> Output Class Initialized
INFO - 2016-05-18 18:49:46 --> Security Class Initialized
DEBUG - 2016-05-18 18:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:49:46 --> Input Class Initialized
INFO - 2016-05-18 18:49:46 --> Language Class Initialized
INFO - 2016-05-18 18:49:46 --> Loader Class Initialized
INFO - 2016-05-18 18:49:46 --> Helper loaded: url_helper
INFO - 2016-05-18 18:49:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:49:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:49:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:49:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:49:46 --> Helper loaded: form_helper
INFO - 2016-05-18 18:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:49:46 --> Form Validation Class Initialized
INFO - 2016-05-18 18:49:46 --> Controller Class Initialized
INFO - 2016-05-18 18:49:46 --> Model Class Initialized
INFO - 2016-05-18 18:49:46 --> Database Driver Class Initialized
INFO - 2016-05-18 18:49:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:49:46 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:49:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:49:46 --> Final output sent to browser
DEBUG - 2016-05-18 18:49:46 --> Total execution time: 0.1006
INFO - 2016-05-18 18:50:00 --> Config Class Initialized
INFO - 2016-05-18 18:50:00 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:50:00 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:50:00 --> Utf8 Class Initialized
INFO - 2016-05-18 18:50:00 --> URI Class Initialized
INFO - 2016-05-18 18:50:00 --> Router Class Initialized
INFO - 2016-05-18 18:50:00 --> Output Class Initialized
INFO - 2016-05-18 18:50:00 --> Security Class Initialized
DEBUG - 2016-05-18 18:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:50:00 --> Input Class Initialized
INFO - 2016-05-18 18:50:00 --> Language Class Initialized
INFO - 2016-05-18 18:50:00 --> Loader Class Initialized
INFO - 2016-05-18 18:50:00 --> Helper loaded: url_helper
INFO - 2016-05-18 18:50:00 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:50:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:50:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:50:00 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:50:00 --> Helper loaded: form_helper
INFO - 2016-05-18 18:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:50:00 --> Form Validation Class Initialized
INFO - 2016-05-18 18:50:00 --> Controller Class Initialized
INFO - 2016-05-18 18:50:00 --> Model Class Initialized
INFO - 2016-05-18 18:50:00 --> Database Driver Class Initialized
INFO - 2016-05-18 18:50:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:50:00 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:50:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:50:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 18:50:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:50:00 --> Final output sent to browser
DEBUG - 2016-05-18 18:50:00 --> Total execution time: 0.0945
INFO - 2016-05-18 18:50:00 --> Config Class Initialized
INFO - 2016-05-18 18:50:00 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:50:00 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:50:00 --> Utf8 Class Initialized
INFO - 2016-05-18 18:50:00 --> URI Class Initialized
INFO - 2016-05-18 18:50:00 --> Router Class Initialized
INFO - 2016-05-18 18:50:00 --> Output Class Initialized
INFO - 2016-05-18 18:50:00 --> Security Class Initialized
DEBUG - 2016-05-18 18:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:50:00 --> Input Class Initialized
INFO - 2016-05-18 18:50:00 --> Language Class Initialized
INFO - 2016-05-18 18:50:00 --> Loader Class Initialized
INFO - 2016-05-18 18:50:00 --> Helper loaded: url_helper
INFO - 2016-05-18 18:50:00 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:50:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:50:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:50:00 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:50:00 --> Helper loaded: form_helper
INFO - 2016-05-18 18:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:50:00 --> Form Validation Class Initialized
INFO - 2016-05-18 18:50:00 --> Controller Class Initialized
INFO - 2016-05-18 18:50:00 --> Model Class Initialized
INFO - 2016-05-18 18:50:00 --> Database Driver Class Initialized
INFO - 2016-05-18 18:50:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:50:00 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:50:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:50:00 --> Final output sent to browser
DEBUG - 2016-05-18 18:50:00 --> Total execution time: 0.1155
INFO - 2016-05-18 18:50:20 --> Config Class Initialized
INFO - 2016-05-18 18:50:20 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:50:20 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:50:20 --> Utf8 Class Initialized
INFO - 2016-05-18 18:50:20 --> URI Class Initialized
INFO - 2016-05-18 18:50:20 --> Router Class Initialized
INFO - 2016-05-18 18:50:20 --> Output Class Initialized
INFO - 2016-05-18 18:50:20 --> Security Class Initialized
DEBUG - 2016-05-18 18:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:50:20 --> Input Class Initialized
INFO - 2016-05-18 18:50:20 --> Language Class Initialized
INFO - 2016-05-18 18:50:20 --> Loader Class Initialized
INFO - 2016-05-18 18:50:20 --> Helper loaded: url_helper
INFO - 2016-05-18 18:50:20 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:50:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:50:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:50:20 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:50:20 --> Helper loaded: form_helper
INFO - 2016-05-18 18:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:50:20 --> Form Validation Class Initialized
INFO - 2016-05-18 18:50:20 --> Controller Class Initialized
INFO - 2016-05-18 18:50:20 --> Model Class Initialized
INFO - 2016-05-18 18:50:20 --> Database Driver Class Initialized
INFO - 2016-05-18 18:50:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:50:20 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:50:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-18 18:50:20 --> Severity: Notice --> Undefined index: descuento C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php 34
ERROR - 2016-05-18 18:50:20 --> Severity: Notice --> Undefined index: descuento C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php 34
INFO - 2016-05-18 18:50:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 18:50:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:50:20 --> Final output sent to browser
DEBUG - 2016-05-18 18:50:20 --> Total execution time: 0.0891
INFO - 2016-05-18 18:50:20 --> Config Class Initialized
INFO - 2016-05-18 18:50:20 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:50:20 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:50:20 --> Utf8 Class Initialized
INFO - 2016-05-18 18:50:20 --> URI Class Initialized
INFO - 2016-05-18 18:50:20 --> Router Class Initialized
INFO - 2016-05-18 18:50:20 --> Output Class Initialized
INFO - 2016-05-18 18:50:20 --> Security Class Initialized
DEBUG - 2016-05-18 18:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:50:20 --> Input Class Initialized
INFO - 2016-05-18 18:50:20 --> Language Class Initialized
INFO - 2016-05-18 18:50:20 --> Loader Class Initialized
INFO - 2016-05-18 18:50:20 --> Helper loaded: url_helper
INFO - 2016-05-18 18:50:20 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:50:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:50:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:50:20 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:50:20 --> Helper loaded: form_helper
INFO - 2016-05-18 18:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:50:20 --> Form Validation Class Initialized
INFO - 2016-05-18 18:50:20 --> Controller Class Initialized
INFO - 2016-05-18 18:50:20 --> Model Class Initialized
INFO - 2016-05-18 18:50:20 --> Database Driver Class Initialized
INFO - 2016-05-18 18:50:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:50:20 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:50:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:50:20 --> Final output sent to browser
DEBUG - 2016-05-18 18:50:20 --> Total execution time: 0.1115
INFO - 2016-05-18 18:50:32 --> Config Class Initialized
INFO - 2016-05-18 18:50:32 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:50:32 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:50:32 --> Utf8 Class Initialized
INFO - 2016-05-18 18:50:32 --> URI Class Initialized
INFO - 2016-05-18 18:50:32 --> Router Class Initialized
INFO - 2016-05-18 18:50:32 --> Output Class Initialized
INFO - 2016-05-18 18:50:32 --> Security Class Initialized
DEBUG - 2016-05-18 18:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:50:32 --> Input Class Initialized
INFO - 2016-05-18 18:50:32 --> Language Class Initialized
INFO - 2016-05-18 18:50:32 --> Loader Class Initialized
INFO - 2016-05-18 18:50:32 --> Helper loaded: url_helper
INFO - 2016-05-18 18:50:32 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:50:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:50:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:50:32 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:50:32 --> Helper loaded: form_helper
INFO - 2016-05-18 18:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:50:32 --> Form Validation Class Initialized
INFO - 2016-05-18 18:50:32 --> Controller Class Initialized
INFO - 2016-05-18 18:50:32 --> Model Class Initialized
INFO - 2016-05-18 18:50:32 --> Database Driver Class Initialized
INFO - 2016-05-18 18:50:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:50:32 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:50:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:50:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 18:50:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:50:32 --> Final output sent to browser
DEBUG - 2016-05-18 18:50:32 --> Total execution time: 0.0825
INFO - 2016-05-18 18:50:32 --> Config Class Initialized
INFO - 2016-05-18 18:50:32 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:50:32 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:50:32 --> Utf8 Class Initialized
INFO - 2016-05-18 18:50:32 --> URI Class Initialized
INFO - 2016-05-18 18:50:32 --> Router Class Initialized
INFO - 2016-05-18 18:50:32 --> Output Class Initialized
INFO - 2016-05-18 18:50:32 --> Security Class Initialized
DEBUG - 2016-05-18 18:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:50:32 --> Input Class Initialized
INFO - 2016-05-18 18:50:32 --> Language Class Initialized
INFO - 2016-05-18 18:50:32 --> Loader Class Initialized
INFO - 2016-05-18 18:50:32 --> Helper loaded: url_helper
INFO - 2016-05-18 18:50:32 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:50:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:50:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:50:33 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:50:33 --> Helper loaded: form_helper
INFO - 2016-05-18 18:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:50:33 --> Form Validation Class Initialized
INFO - 2016-05-18 18:50:33 --> Controller Class Initialized
INFO - 2016-05-18 18:50:33 --> Model Class Initialized
INFO - 2016-05-18 18:50:33 --> Database Driver Class Initialized
INFO - 2016-05-18 18:50:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:50:33 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:50:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:50:33 --> Final output sent to browser
DEBUG - 2016-05-18 18:50:33 --> Total execution time: 0.1212
INFO - 2016-05-18 18:51:06 --> Config Class Initialized
INFO - 2016-05-18 18:51:06 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:51:06 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:51:06 --> Utf8 Class Initialized
INFO - 2016-05-18 18:51:06 --> URI Class Initialized
INFO - 2016-05-18 18:51:06 --> Router Class Initialized
INFO - 2016-05-18 18:51:06 --> Output Class Initialized
INFO - 2016-05-18 18:51:06 --> Security Class Initialized
DEBUG - 2016-05-18 18:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:51:06 --> Input Class Initialized
INFO - 2016-05-18 18:51:06 --> Language Class Initialized
INFO - 2016-05-18 18:51:06 --> Loader Class Initialized
INFO - 2016-05-18 18:51:06 --> Helper loaded: url_helper
INFO - 2016-05-18 18:51:06 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:51:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:51:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:51:06 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:51:06 --> Helper loaded: form_helper
INFO - 2016-05-18 18:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:51:06 --> Form Validation Class Initialized
INFO - 2016-05-18 18:51:06 --> Controller Class Initialized
INFO - 2016-05-18 18:51:06 --> Model Class Initialized
INFO - 2016-05-18 18:51:06 --> Database Driver Class Initialized
INFO - 2016-05-18 18:51:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:51:06 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:51:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:51:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 18:51:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:51:06 --> Final output sent to browser
DEBUG - 2016-05-18 18:51:06 --> Total execution time: 0.1167
INFO - 2016-05-18 18:51:06 --> Config Class Initialized
INFO - 2016-05-18 18:51:06 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:51:06 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:51:06 --> Utf8 Class Initialized
INFO - 2016-05-18 18:51:06 --> URI Class Initialized
INFO - 2016-05-18 18:51:06 --> Router Class Initialized
INFO - 2016-05-18 18:51:06 --> Output Class Initialized
INFO - 2016-05-18 18:51:06 --> Security Class Initialized
DEBUG - 2016-05-18 18:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:51:06 --> Input Class Initialized
INFO - 2016-05-18 18:51:06 --> Language Class Initialized
INFO - 2016-05-18 18:51:06 --> Loader Class Initialized
INFO - 2016-05-18 18:51:06 --> Helper loaded: url_helper
INFO - 2016-05-18 18:51:06 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:51:06 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:51:06 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:51:06 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:51:06 --> Helper loaded: form_helper
INFO - 2016-05-18 18:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:51:06 --> Form Validation Class Initialized
INFO - 2016-05-18 18:51:06 --> Controller Class Initialized
INFO - 2016-05-18 18:51:06 --> Model Class Initialized
INFO - 2016-05-18 18:51:06 --> Database Driver Class Initialized
INFO - 2016-05-18 18:51:06 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:51:06 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:51:06 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:51:06 --> Final output sent to browser
DEBUG - 2016-05-18 18:51:06 --> Total execution time: 0.1111
INFO - 2016-05-18 18:52:07 --> Config Class Initialized
INFO - 2016-05-18 18:52:07 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:52:07 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:52:07 --> Utf8 Class Initialized
INFO - 2016-05-18 18:52:07 --> URI Class Initialized
INFO - 2016-05-18 18:52:07 --> Router Class Initialized
INFO - 2016-05-18 18:52:07 --> Output Class Initialized
INFO - 2016-05-18 18:52:07 --> Security Class Initialized
DEBUG - 2016-05-18 18:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:52:07 --> Input Class Initialized
INFO - 2016-05-18 18:52:07 --> Language Class Initialized
INFO - 2016-05-18 18:52:07 --> Loader Class Initialized
INFO - 2016-05-18 18:52:07 --> Helper loaded: url_helper
INFO - 2016-05-18 18:52:07 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:52:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:52:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:52:07 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:52:07 --> Helper loaded: form_helper
INFO - 2016-05-18 18:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:52:07 --> Form Validation Class Initialized
INFO - 2016-05-18 18:52:07 --> Controller Class Initialized
INFO - 2016-05-18 18:52:07 --> Model Class Initialized
INFO - 2016-05-18 18:52:07 --> Database Driver Class Initialized
INFO - 2016-05-18 18:52:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:52:07 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:52:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:52:07 --> Final output sent to browser
DEBUG - 2016-05-18 18:52:07 --> Total execution time: 0.0756
INFO - 2016-05-18 18:53:07 --> Config Class Initialized
INFO - 2016-05-18 18:53:07 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:53:07 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:53:07 --> Utf8 Class Initialized
INFO - 2016-05-18 18:53:07 --> URI Class Initialized
INFO - 2016-05-18 18:53:07 --> Router Class Initialized
INFO - 2016-05-18 18:53:07 --> Output Class Initialized
INFO - 2016-05-18 18:53:07 --> Security Class Initialized
DEBUG - 2016-05-18 18:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:53:07 --> Input Class Initialized
INFO - 2016-05-18 18:53:07 --> Language Class Initialized
INFO - 2016-05-18 18:53:07 --> Loader Class Initialized
INFO - 2016-05-18 18:53:07 --> Helper loaded: url_helper
INFO - 2016-05-18 18:53:07 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:53:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:53:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:53:07 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:53:07 --> Helper loaded: form_helper
INFO - 2016-05-18 18:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:53:07 --> Form Validation Class Initialized
INFO - 2016-05-18 18:53:07 --> Controller Class Initialized
INFO - 2016-05-18 18:53:07 --> Model Class Initialized
INFO - 2016-05-18 18:53:07 --> Database Driver Class Initialized
INFO - 2016-05-18 18:53:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:53:07 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:53:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:53:07 --> Final output sent to browser
DEBUG - 2016-05-18 18:53:07 --> Total execution time: 0.0757
INFO - 2016-05-18 18:54:07 --> Config Class Initialized
INFO - 2016-05-18 18:54:07 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:54:07 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:54:07 --> Utf8 Class Initialized
INFO - 2016-05-18 18:54:07 --> URI Class Initialized
INFO - 2016-05-18 18:54:07 --> Router Class Initialized
INFO - 2016-05-18 18:54:07 --> Output Class Initialized
INFO - 2016-05-18 18:54:07 --> Security Class Initialized
DEBUG - 2016-05-18 18:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:54:07 --> Input Class Initialized
INFO - 2016-05-18 18:54:07 --> Language Class Initialized
INFO - 2016-05-18 18:54:07 --> Loader Class Initialized
INFO - 2016-05-18 18:54:07 --> Helper loaded: url_helper
INFO - 2016-05-18 18:54:07 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:54:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:54:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:54:07 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:54:07 --> Helper loaded: form_helper
INFO - 2016-05-18 18:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:54:07 --> Form Validation Class Initialized
INFO - 2016-05-18 18:54:07 --> Controller Class Initialized
INFO - 2016-05-18 18:54:07 --> Model Class Initialized
INFO - 2016-05-18 18:54:07 --> Database Driver Class Initialized
INFO - 2016-05-18 18:54:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:54:07 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:54:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:54:07 --> Final output sent to browser
DEBUG - 2016-05-18 18:54:07 --> Total execution time: 0.0711
INFO - 2016-05-18 18:54:23 --> Config Class Initialized
INFO - 2016-05-18 18:54:23 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:54:23 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:54:23 --> Utf8 Class Initialized
INFO - 2016-05-18 18:54:23 --> URI Class Initialized
INFO - 2016-05-18 18:54:23 --> Router Class Initialized
INFO - 2016-05-18 18:54:23 --> Output Class Initialized
INFO - 2016-05-18 18:54:23 --> Security Class Initialized
DEBUG - 2016-05-18 18:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:54:23 --> Input Class Initialized
INFO - 2016-05-18 18:54:23 --> Language Class Initialized
INFO - 2016-05-18 18:54:23 --> Loader Class Initialized
INFO - 2016-05-18 18:54:23 --> Helper loaded: url_helper
INFO - 2016-05-18 18:54:23 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:54:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:54:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:54:23 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:54:23 --> Helper loaded: form_helper
INFO - 2016-05-18 18:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:54:23 --> Form Validation Class Initialized
INFO - 2016-05-18 18:54:23 --> Controller Class Initialized
INFO - 2016-05-18 18:54:23 --> Model Class Initialized
INFO - 2016-05-18 18:54:23 --> Database Driver Class Initialized
INFO - 2016-05-18 18:54:23 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:54:23 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:54:23 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-18 18:54:23 --> Query error: Incorrect parameter count in the call to native function 'ifnull' - Invalid query: SELECT numfactura, fecha_factura, nombre_cliente, importe_total, cantidad_total, ifnull(concat(descuento + ' %', 0)) 'descuento' FROM factura WHERE pendiente_pago LIKE 'Sí' LIMIT 0, 5; 
INFO - 2016-05-18 18:54:23 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-18 18:54:40 --> Config Class Initialized
INFO - 2016-05-18 18:54:40 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:54:40 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:54:40 --> Utf8 Class Initialized
INFO - 2016-05-18 18:54:40 --> URI Class Initialized
INFO - 2016-05-18 18:54:40 --> Router Class Initialized
INFO - 2016-05-18 18:54:40 --> Output Class Initialized
INFO - 2016-05-18 18:54:40 --> Security Class Initialized
DEBUG - 2016-05-18 18:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:54:40 --> Input Class Initialized
INFO - 2016-05-18 18:54:40 --> Language Class Initialized
INFO - 2016-05-18 18:54:40 --> Loader Class Initialized
INFO - 2016-05-18 18:54:40 --> Helper loaded: url_helper
INFO - 2016-05-18 18:54:40 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:54:40 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:54:40 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:54:40 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:54:41 --> Helper loaded: form_helper
INFO - 2016-05-18 18:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:54:41 --> Form Validation Class Initialized
INFO - 2016-05-18 18:54:41 --> Controller Class Initialized
INFO - 2016-05-18 18:54:41 --> Model Class Initialized
INFO - 2016-05-18 18:54:41 --> Database Driver Class Initialized
INFO - 2016-05-18 18:54:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:54:41 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:54:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:54:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 18:54:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:54:41 --> Final output sent to browser
DEBUG - 2016-05-18 18:54:41 --> Total execution time: 0.0809
INFO - 2016-05-18 18:54:41 --> Config Class Initialized
INFO - 2016-05-18 18:54:41 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:54:41 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:54:41 --> Utf8 Class Initialized
INFO - 2016-05-18 18:54:41 --> URI Class Initialized
INFO - 2016-05-18 18:54:41 --> Router Class Initialized
INFO - 2016-05-18 18:54:41 --> Output Class Initialized
INFO - 2016-05-18 18:54:41 --> Security Class Initialized
DEBUG - 2016-05-18 18:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:54:41 --> Input Class Initialized
INFO - 2016-05-18 18:54:41 --> Language Class Initialized
INFO - 2016-05-18 18:54:41 --> Loader Class Initialized
INFO - 2016-05-18 18:54:41 --> Helper loaded: url_helper
INFO - 2016-05-18 18:54:41 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:54:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:54:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:54:41 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:54:41 --> Helper loaded: form_helper
INFO - 2016-05-18 18:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:54:41 --> Form Validation Class Initialized
INFO - 2016-05-18 18:54:41 --> Controller Class Initialized
INFO - 2016-05-18 18:54:41 --> Model Class Initialized
INFO - 2016-05-18 18:54:41 --> Database Driver Class Initialized
INFO - 2016-05-18 18:54:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:54:41 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:54:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:54:41 --> Final output sent to browser
DEBUG - 2016-05-18 18:54:41 --> Total execution time: 0.1018
INFO - 2016-05-18 18:55:41 --> Config Class Initialized
INFO - 2016-05-18 18:55:41 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:55:41 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:55:41 --> Utf8 Class Initialized
INFO - 2016-05-18 18:55:41 --> URI Class Initialized
INFO - 2016-05-18 18:55:41 --> Router Class Initialized
INFO - 2016-05-18 18:55:41 --> Output Class Initialized
INFO - 2016-05-18 18:55:41 --> Security Class Initialized
DEBUG - 2016-05-18 18:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:55:41 --> Input Class Initialized
INFO - 2016-05-18 18:55:41 --> Language Class Initialized
INFO - 2016-05-18 18:55:41 --> Loader Class Initialized
INFO - 2016-05-18 18:55:41 --> Helper loaded: url_helper
INFO - 2016-05-18 18:55:41 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:55:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:55:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:55:41 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:55:41 --> Helper loaded: form_helper
INFO - 2016-05-18 18:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:55:41 --> Form Validation Class Initialized
INFO - 2016-05-18 18:55:41 --> Controller Class Initialized
INFO - 2016-05-18 18:55:41 --> Model Class Initialized
INFO - 2016-05-18 18:55:41 --> Database Driver Class Initialized
INFO - 2016-05-18 18:55:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:55:41 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:55:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:55:41 --> Final output sent to browser
DEBUG - 2016-05-18 18:55:41 --> Total execution time: 0.0777
INFO - 2016-05-18 18:56:18 --> Config Class Initialized
INFO - 2016-05-18 18:56:18 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:56:18 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:56:18 --> Utf8 Class Initialized
INFO - 2016-05-18 18:56:18 --> URI Class Initialized
INFO - 2016-05-18 18:56:18 --> Router Class Initialized
INFO - 2016-05-18 18:56:18 --> Output Class Initialized
INFO - 2016-05-18 18:56:18 --> Security Class Initialized
DEBUG - 2016-05-18 18:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:56:18 --> Input Class Initialized
INFO - 2016-05-18 18:56:18 --> Language Class Initialized
INFO - 2016-05-18 18:56:18 --> Loader Class Initialized
INFO - 2016-05-18 18:56:18 --> Helper loaded: url_helper
INFO - 2016-05-18 18:56:18 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:56:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:56:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:56:18 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:56:18 --> Helper loaded: form_helper
INFO - 2016-05-18 18:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:56:18 --> Form Validation Class Initialized
INFO - 2016-05-18 18:56:18 --> Controller Class Initialized
INFO - 2016-05-18 18:56:18 --> Model Class Initialized
INFO - 2016-05-18 18:56:18 --> Database Driver Class Initialized
INFO - 2016-05-18 18:56:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:56:18 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:56:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:56:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 18:56:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:56:18 --> Final output sent to browser
DEBUG - 2016-05-18 18:56:18 --> Total execution time: 0.1042
INFO - 2016-05-18 18:56:18 --> Config Class Initialized
INFO - 2016-05-18 18:56:18 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:56:18 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:56:18 --> Utf8 Class Initialized
INFO - 2016-05-18 18:56:18 --> URI Class Initialized
INFO - 2016-05-18 18:56:18 --> Router Class Initialized
INFO - 2016-05-18 18:56:18 --> Output Class Initialized
INFO - 2016-05-18 18:56:18 --> Security Class Initialized
DEBUG - 2016-05-18 18:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:56:18 --> Input Class Initialized
INFO - 2016-05-18 18:56:18 --> Language Class Initialized
INFO - 2016-05-18 18:56:19 --> Loader Class Initialized
INFO - 2016-05-18 18:56:19 --> Helper loaded: url_helper
INFO - 2016-05-18 18:56:19 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:56:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:56:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:56:19 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:56:19 --> Helper loaded: form_helper
INFO - 2016-05-18 18:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:56:19 --> Form Validation Class Initialized
INFO - 2016-05-18 18:56:19 --> Controller Class Initialized
INFO - 2016-05-18 18:56:19 --> Model Class Initialized
INFO - 2016-05-18 18:56:19 --> Database Driver Class Initialized
INFO - 2016-05-18 18:56:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:56:19 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:56:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:56:19 --> Final output sent to browser
DEBUG - 2016-05-18 18:56:19 --> Total execution time: 0.1164
INFO - 2016-05-18 18:56:35 --> Config Class Initialized
INFO - 2016-05-18 18:56:35 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:56:35 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:56:35 --> Utf8 Class Initialized
INFO - 2016-05-18 18:56:35 --> URI Class Initialized
INFO - 2016-05-18 18:56:35 --> Router Class Initialized
INFO - 2016-05-18 18:56:35 --> Output Class Initialized
INFO - 2016-05-18 18:56:35 --> Security Class Initialized
DEBUG - 2016-05-18 18:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:56:35 --> Input Class Initialized
INFO - 2016-05-18 18:56:35 --> Language Class Initialized
INFO - 2016-05-18 18:56:35 --> Loader Class Initialized
INFO - 2016-05-18 18:56:35 --> Helper loaded: url_helper
INFO - 2016-05-18 18:56:35 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:56:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:56:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:56:35 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:56:35 --> Helper loaded: form_helper
INFO - 2016-05-18 18:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:56:35 --> Form Validation Class Initialized
INFO - 2016-05-18 18:56:35 --> Controller Class Initialized
INFO - 2016-05-18 18:56:35 --> Model Class Initialized
INFO - 2016-05-18 18:56:35 --> Database Driver Class Initialized
INFO - 2016-05-18 18:56:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:56:35 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:56:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:56:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 18:56:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:56:35 --> Final output sent to browser
DEBUG - 2016-05-18 18:56:35 --> Total execution time: 0.0850
INFO - 2016-05-18 18:56:36 --> Config Class Initialized
INFO - 2016-05-18 18:56:36 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:56:36 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:56:36 --> Utf8 Class Initialized
INFO - 2016-05-18 18:56:36 --> URI Class Initialized
INFO - 2016-05-18 18:56:36 --> Router Class Initialized
INFO - 2016-05-18 18:56:36 --> Output Class Initialized
INFO - 2016-05-18 18:56:36 --> Security Class Initialized
DEBUG - 2016-05-18 18:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:56:36 --> Input Class Initialized
INFO - 2016-05-18 18:56:36 --> Language Class Initialized
INFO - 2016-05-18 18:56:36 --> Loader Class Initialized
INFO - 2016-05-18 18:56:36 --> Helper loaded: url_helper
INFO - 2016-05-18 18:56:36 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:56:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:56:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:56:36 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:56:36 --> Helper loaded: form_helper
INFO - 2016-05-18 18:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:56:36 --> Form Validation Class Initialized
INFO - 2016-05-18 18:56:36 --> Controller Class Initialized
INFO - 2016-05-18 18:56:36 --> Model Class Initialized
INFO - 2016-05-18 18:56:36 --> Database Driver Class Initialized
INFO - 2016-05-18 18:56:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:56:36 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:56:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:56:36 --> Final output sent to browser
DEBUG - 2016-05-18 18:56:36 --> Total execution time: 0.1118
INFO - 2016-05-18 18:56:46 --> Config Class Initialized
INFO - 2016-05-18 18:56:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:56:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:56:46 --> Utf8 Class Initialized
INFO - 2016-05-18 18:56:46 --> URI Class Initialized
INFO - 2016-05-18 18:56:46 --> Router Class Initialized
INFO - 2016-05-18 18:56:46 --> Output Class Initialized
INFO - 2016-05-18 18:56:46 --> Security Class Initialized
DEBUG - 2016-05-18 18:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:56:46 --> Input Class Initialized
INFO - 2016-05-18 18:56:46 --> Language Class Initialized
INFO - 2016-05-18 18:56:46 --> Loader Class Initialized
INFO - 2016-05-18 18:56:46 --> Helper loaded: url_helper
INFO - 2016-05-18 18:56:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:56:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:56:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:56:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:56:46 --> Helper loaded: form_helper
INFO - 2016-05-18 18:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:56:46 --> Form Validation Class Initialized
INFO - 2016-05-18 18:56:46 --> Controller Class Initialized
INFO - 2016-05-18 18:56:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-18 18:56:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:56:46 --> Final output sent to browser
DEBUG - 2016-05-18 18:56:46 --> Total execution time: 0.0567
INFO - 2016-05-18 18:56:46 --> Config Class Initialized
INFO - 2016-05-18 18:56:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:56:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:56:46 --> Utf8 Class Initialized
INFO - 2016-05-18 18:56:46 --> URI Class Initialized
INFO - 2016-05-18 18:56:46 --> Router Class Initialized
INFO - 2016-05-18 18:56:46 --> Output Class Initialized
INFO - 2016-05-18 18:56:46 --> Security Class Initialized
DEBUG - 2016-05-18 18:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:56:46 --> Input Class Initialized
INFO - 2016-05-18 18:56:46 --> Language Class Initialized
INFO - 2016-05-18 18:56:46 --> Loader Class Initialized
INFO - 2016-05-18 18:56:46 --> Helper loaded: url_helper
INFO - 2016-05-18 18:56:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:56:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:56:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:56:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:56:46 --> Helper loaded: form_helper
INFO - 2016-05-18 18:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:56:46 --> Form Validation Class Initialized
INFO - 2016-05-18 18:56:46 --> Controller Class Initialized
INFO - 2016-05-18 18:56:46 --> Model Class Initialized
INFO - 2016-05-18 18:56:46 --> Database Driver Class Initialized
INFO - 2016-05-18 18:56:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:56:46 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:56:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:56:46 --> Final output sent to browser
DEBUG - 2016-05-18 18:56:46 --> Total execution time: 0.0804
INFO - 2016-05-18 18:56:51 --> Config Class Initialized
INFO - 2016-05-18 18:56:51 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:56:51 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:56:51 --> Utf8 Class Initialized
INFO - 2016-05-18 18:56:51 --> URI Class Initialized
INFO - 2016-05-18 18:56:51 --> Router Class Initialized
INFO - 2016-05-18 18:56:51 --> Output Class Initialized
INFO - 2016-05-18 18:56:51 --> Security Class Initialized
DEBUG - 2016-05-18 18:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:56:51 --> Input Class Initialized
INFO - 2016-05-18 18:56:51 --> Language Class Initialized
INFO - 2016-05-18 18:56:51 --> Loader Class Initialized
INFO - 2016-05-18 18:56:51 --> Helper loaded: url_helper
INFO - 2016-05-18 18:56:51 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:56:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:56:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:56:51 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:56:51 --> Helper loaded: form_helper
INFO - 2016-05-18 18:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:56:51 --> Form Validation Class Initialized
INFO - 2016-05-18 18:56:51 --> Controller Class Initialized
INFO - 2016-05-18 18:56:51 --> Model Class Initialized
INFO - 2016-05-18 18:56:51 --> Database Driver Class Initialized
INFO - 2016-05-18 18:56:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:56:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:56:51 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:56:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:56:51 --> Helper loaded: nif_validate_helper
INFO - 2016-05-18 18:56:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-18 18:56:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:56:51 --> Final output sent to browser
DEBUG - 2016-05-18 18:56:51 --> Total execution time: 0.0856
INFO - 2016-05-18 18:56:52 --> Config Class Initialized
INFO - 2016-05-18 18:56:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:56:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:56:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:56:52 --> URI Class Initialized
INFO - 2016-05-18 18:56:52 --> Router Class Initialized
INFO - 2016-05-18 18:56:52 --> Output Class Initialized
INFO - 2016-05-18 18:56:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:56:52 --> Input Class Initialized
INFO - 2016-05-18 18:56:52 --> Language Class Initialized
INFO - 2016-05-18 18:56:52 --> Loader Class Initialized
INFO - 2016-05-18 18:56:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:56:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:56:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:56:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:56:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:56:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:56:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:56:52 --> Controller Class Initialized
INFO - 2016-05-18 18:56:52 --> Model Class Initialized
INFO - 2016-05-18 18:56:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:56:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:56:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:56:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:56:52 --> Final output sent to browser
DEBUG - 2016-05-18 18:56:52 --> Total execution time: 0.0988
INFO - 2016-05-18 18:57:36 --> Config Class Initialized
INFO - 2016-05-18 18:57:36 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:57:36 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:57:36 --> Utf8 Class Initialized
INFO - 2016-05-18 18:57:36 --> URI Class Initialized
INFO - 2016-05-18 18:57:36 --> Router Class Initialized
INFO - 2016-05-18 18:57:36 --> Output Class Initialized
INFO - 2016-05-18 18:57:36 --> Security Class Initialized
DEBUG - 2016-05-18 18:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:57:36 --> Input Class Initialized
INFO - 2016-05-18 18:57:36 --> Language Class Initialized
INFO - 2016-05-18 18:57:36 --> Loader Class Initialized
INFO - 2016-05-18 18:57:36 --> Helper loaded: url_helper
INFO - 2016-05-18 18:57:36 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:57:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:57:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:57:36 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:57:36 --> Helper loaded: form_helper
INFO - 2016-05-18 18:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:57:36 --> Form Validation Class Initialized
INFO - 2016-05-18 18:57:36 --> Controller Class Initialized
INFO - 2016-05-18 18:57:36 --> Model Class Initialized
INFO - 2016-05-18 18:57:36 --> Database Driver Class Initialized
INFO - 2016-05-18 18:57:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:57:36 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:57:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:57:36 --> Final output sent to browser
DEBUG - 2016-05-18 18:57:36 --> Total execution time: 0.0912
INFO - 2016-05-18 18:57:52 --> Config Class Initialized
INFO - 2016-05-18 18:57:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:57:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:57:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:57:52 --> URI Class Initialized
INFO - 2016-05-18 18:57:52 --> Router Class Initialized
INFO - 2016-05-18 18:57:52 --> Output Class Initialized
INFO - 2016-05-18 18:57:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:57:52 --> Input Class Initialized
INFO - 2016-05-18 18:57:52 --> Language Class Initialized
INFO - 2016-05-18 18:57:52 --> Loader Class Initialized
INFO - 2016-05-18 18:57:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:57:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:57:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:57:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:57:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:57:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:57:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:57:52 --> Controller Class Initialized
INFO - 2016-05-18 18:57:52 --> Model Class Initialized
INFO - 2016-05-18 18:57:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:57:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:57:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:57:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:57:52 --> Final output sent to browser
DEBUG - 2016-05-18 18:57:52 --> Total execution time: 0.0716
INFO - 2016-05-18 18:58:36 --> Config Class Initialized
INFO - 2016-05-18 18:58:36 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:58:36 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:58:36 --> Utf8 Class Initialized
INFO - 2016-05-18 18:58:36 --> URI Class Initialized
INFO - 2016-05-18 18:58:36 --> Router Class Initialized
INFO - 2016-05-18 18:58:36 --> Output Class Initialized
INFO - 2016-05-18 18:58:36 --> Security Class Initialized
DEBUG - 2016-05-18 18:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:58:36 --> Input Class Initialized
INFO - 2016-05-18 18:58:36 --> Language Class Initialized
INFO - 2016-05-18 18:58:36 --> Loader Class Initialized
INFO - 2016-05-18 18:58:36 --> Helper loaded: url_helper
INFO - 2016-05-18 18:58:36 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:58:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:58:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:58:36 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:58:36 --> Helper loaded: form_helper
INFO - 2016-05-18 18:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:58:36 --> Form Validation Class Initialized
INFO - 2016-05-18 18:58:36 --> Controller Class Initialized
INFO - 2016-05-18 18:58:36 --> Model Class Initialized
INFO - 2016-05-18 18:58:36 --> Database Driver Class Initialized
INFO - 2016-05-18 18:58:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:58:36 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:58:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:58:36 --> Final output sent to browser
DEBUG - 2016-05-18 18:58:36 --> Total execution time: 0.0736
INFO - 2016-05-18 18:58:52 --> Config Class Initialized
INFO - 2016-05-18 18:58:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:58:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:58:52 --> Utf8 Class Initialized
INFO - 2016-05-18 18:58:52 --> URI Class Initialized
INFO - 2016-05-18 18:58:52 --> Router Class Initialized
INFO - 2016-05-18 18:58:52 --> Output Class Initialized
INFO - 2016-05-18 18:58:52 --> Security Class Initialized
DEBUG - 2016-05-18 18:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:58:52 --> Input Class Initialized
INFO - 2016-05-18 18:58:52 --> Language Class Initialized
INFO - 2016-05-18 18:58:52 --> Loader Class Initialized
INFO - 2016-05-18 18:58:52 --> Helper loaded: url_helper
INFO - 2016-05-18 18:58:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:58:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:58:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:58:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:58:52 --> Helper loaded: form_helper
INFO - 2016-05-18 18:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:58:52 --> Form Validation Class Initialized
INFO - 2016-05-18 18:58:52 --> Controller Class Initialized
INFO - 2016-05-18 18:58:52 --> Model Class Initialized
INFO - 2016-05-18 18:58:52 --> Database Driver Class Initialized
INFO - 2016-05-18 18:58:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:58:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:58:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:58:52 --> Final output sent to browser
DEBUG - 2016-05-18 18:58:52 --> Total execution time: 0.0697
INFO - 2016-05-18 18:59:03 --> Config Class Initialized
INFO - 2016-05-18 18:59:03 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:59:03 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:59:03 --> Utf8 Class Initialized
INFO - 2016-05-18 18:59:03 --> URI Class Initialized
INFO - 2016-05-18 18:59:03 --> Router Class Initialized
INFO - 2016-05-18 18:59:03 --> Output Class Initialized
INFO - 2016-05-18 18:59:03 --> Security Class Initialized
DEBUG - 2016-05-18 18:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:59:03 --> Input Class Initialized
INFO - 2016-05-18 18:59:03 --> Language Class Initialized
INFO - 2016-05-18 18:59:03 --> Loader Class Initialized
INFO - 2016-05-18 18:59:03 --> Helper loaded: url_helper
INFO - 2016-05-18 18:59:03 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:59:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:59:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:59:03 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:59:03 --> Helper loaded: form_helper
INFO - 2016-05-18 18:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:59:03 --> Form Validation Class Initialized
INFO - 2016-05-18 18:59:03 --> Controller Class Initialized
INFO - 2016-05-18 18:59:03 --> Model Class Initialized
INFO - 2016-05-18 18:59:03 --> Database Driver Class Initialized
INFO - 2016-05-18 18:59:03 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:59:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:59:03 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:59:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:59:03 --> Helper loaded: nif_validate_helper
INFO - 2016-05-18 18:59:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaClientes.php
INFO - 2016-05-18 18:59:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:59:03 --> Final output sent to browser
DEBUG - 2016-05-18 18:59:03 --> Total execution time: 0.0882
INFO - 2016-05-18 18:59:03 --> Config Class Initialized
INFO - 2016-05-18 18:59:03 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:59:03 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:59:03 --> Utf8 Class Initialized
INFO - 2016-05-18 18:59:03 --> URI Class Initialized
INFO - 2016-05-18 18:59:03 --> Router Class Initialized
INFO - 2016-05-18 18:59:03 --> Output Class Initialized
INFO - 2016-05-18 18:59:03 --> Security Class Initialized
DEBUG - 2016-05-18 18:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:59:03 --> Input Class Initialized
INFO - 2016-05-18 18:59:03 --> Language Class Initialized
INFO - 2016-05-18 18:59:03 --> Loader Class Initialized
INFO - 2016-05-18 18:59:03 --> Helper loaded: url_helper
INFO - 2016-05-18 18:59:03 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:59:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:59:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:59:03 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:59:03 --> Helper loaded: form_helper
INFO - 2016-05-18 18:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:59:03 --> Form Validation Class Initialized
INFO - 2016-05-18 18:59:03 --> Controller Class Initialized
INFO - 2016-05-18 18:59:03 --> Model Class Initialized
INFO - 2016-05-18 18:59:03 --> Database Driver Class Initialized
INFO - 2016-05-18 18:59:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:59:03 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:59:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:59:03 --> Final output sent to browser
DEBUG - 2016-05-18 18:59:03 --> Total execution time: 0.1229
INFO - 2016-05-18 18:59:08 --> Config Class Initialized
INFO - 2016-05-18 18:59:08 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:59:08 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:59:08 --> Utf8 Class Initialized
INFO - 2016-05-18 18:59:08 --> URI Class Initialized
INFO - 2016-05-18 18:59:08 --> Router Class Initialized
INFO - 2016-05-18 18:59:08 --> Output Class Initialized
INFO - 2016-05-18 18:59:08 --> Security Class Initialized
DEBUG - 2016-05-18 18:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:59:08 --> Input Class Initialized
INFO - 2016-05-18 18:59:08 --> Language Class Initialized
INFO - 2016-05-18 18:59:08 --> Loader Class Initialized
INFO - 2016-05-18 18:59:08 --> Helper loaded: url_helper
INFO - 2016-05-18 18:59:08 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:59:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:59:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:59:08 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:59:08 --> Helper loaded: form_helper
INFO - 2016-05-18 18:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:59:08 --> Form Validation Class Initialized
INFO - 2016-05-18 18:59:08 --> Controller Class Initialized
INFO - 2016-05-18 18:59:08 --> Model Class Initialized
INFO - 2016-05-18 18:59:08 --> Database Driver Class Initialized
INFO - 2016-05-18 18:59:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:59:08 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:59:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:59:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 18:59:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:59:08 --> Final output sent to browser
DEBUG - 2016-05-18 18:59:08 --> Total execution time: 0.0797
INFO - 2016-05-18 18:59:08 --> Config Class Initialized
INFO - 2016-05-18 18:59:08 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:59:08 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:59:08 --> Utf8 Class Initialized
INFO - 2016-05-18 18:59:08 --> URI Class Initialized
INFO - 2016-05-18 18:59:08 --> Router Class Initialized
INFO - 2016-05-18 18:59:08 --> Output Class Initialized
INFO - 2016-05-18 18:59:08 --> Security Class Initialized
DEBUG - 2016-05-18 18:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:59:08 --> Input Class Initialized
INFO - 2016-05-18 18:59:08 --> Language Class Initialized
INFO - 2016-05-18 18:59:08 --> Loader Class Initialized
INFO - 2016-05-18 18:59:08 --> Helper loaded: url_helper
INFO - 2016-05-18 18:59:08 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:59:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:59:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:59:08 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:59:08 --> Helper loaded: form_helper
INFO - 2016-05-18 18:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:59:08 --> Form Validation Class Initialized
INFO - 2016-05-18 18:59:08 --> Controller Class Initialized
INFO - 2016-05-18 18:59:08 --> Model Class Initialized
INFO - 2016-05-18 18:59:08 --> Database Driver Class Initialized
INFO - 2016-05-18 18:59:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:59:08 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:59:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:59:08 --> Final output sent to browser
DEBUG - 2016-05-18 18:59:08 --> Total execution time: 0.1218
INFO - 2016-05-18 18:59:21 --> Config Class Initialized
INFO - 2016-05-18 18:59:21 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:59:21 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:59:21 --> Utf8 Class Initialized
INFO - 2016-05-18 18:59:21 --> URI Class Initialized
INFO - 2016-05-18 18:59:21 --> Router Class Initialized
INFO - 2016-05-18 18:59:21 --> Output Class Initialized
INFO - 2016-05-18 18:59:21 --> Security Class Initialized
DEBUG - 2016-05-18 18:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:59:21 --> Input Class Initialized
INFO - 2016-05-18 18:59:21 --> Language Class Initialized
INFO - 2016-05-18 18:59:21 --> Loader Class Initialized
INFO - 2016-05-18 18:59:21 --> Helper loaded: url_helper
INFO - 2016-05-18 18:59:21 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:59:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:59:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:59:21 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:59:21 --> Helper loaded: form_helper
INFO - 2016-05-18 18:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:59:21 --> Form Validation Class Initialized
INFO - 2016-05-18 18:59:21 --> Controller Class Initialized
INFO - 2016-05-18 18:59:21 --> Model Class Initialized
INFO - 2016-05-18 18:59:21 --> Database Driver Class Initialized
INFO - 2016-05-18 18:59:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:59:21 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:59:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:59:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 18:59:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:59:21 --> Final output sent to browser
DEBUG - 2016-05-18 18:59:21 --> Total execution time: 0.0814
INFO - 2016-05-18 18:59:21 --> Config Class Initialized
INFO - 2016-05-18 18:59:21 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:59:21 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:59:21 --> Utf8 Class Initialized
INFO - 2016-05-18 18:59:21 --> URI Class Initialized
INFO - 2016-05-18 18:59:21 --> Router Class Initialized
INFO - 2016-05-18 18:59:21 --> Output Class Initialized
INFO - 2016-05-18 18:59:21 --> Security Class Initialized
DEBUG - 2016-05-18 18:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:59:21 --> Input Class Initialized
INFO - 2016-05-18 18:59:21 --> Language Class Initialized
INFO - 2016-05-18 18:59:21 --> Loader Class Initialized
INFO - 2016-05-18 18:59:21 --> Helper loaded: url_helper
INFO - 2016-05-18 18:59:21 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:59:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:59:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:59:21 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:59:21 --> Helper loaded: form_helper
INFO - 2016-05-18 18:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:59:21 --> Form Validation Class Initialized
INFO - 2016-05-18 18:59:21 --> Controller Class Initialized
INFO - 2016-05-18 18:59:21 --> Model Class Initialized
INFO - 2016-05-18 18:59:21 --> Database Driver Class Initialized
INFO - 2016-05-18 18:59:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:59:21 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:59:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:59:21 --> Final output sent to browser
DEBUG - 2016-05-18 18:59:21 --> Total execution time: 0.0984
INFO - 2016-05-18 18:59:26 --> Config Class Initialized
INFO - 2016-05-18 18:59:26 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:59:26 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:59:26 --> Utf8 Class Initialized
INFO - 2016-05-18 18:59:26 --> URI Class Initialized
INFO - 2016-05-18 18:59:26 --> Router Class Initialized
INFO - 2016-05-18 18:59:26 --> Output Class Initialized
INFO - 2016-05-18 18:59:26 --> Security Class Initialized
DEBUG - 2016-05-18 18:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:59:26 --> Input Class Initialized
INFO - 2016-05-18 18:59:26 --> Language Class Initialized
INFO - 2016-05-18 18:59:26 --> Loader Class Initialized
INFO - 2016-05-18 18:59:26 --> Helper loaded: url_helper
INFO - 2016-05-18 18:59:26 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:59:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:59:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:59:26 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:59:26 --> Helper loaded: form_helper
INFO - 2016-05-18 18:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:59:26 --> Form Validation Class Initialized
INFO - 2016-05-18 18:59:26 --> Controller Class Initialized
INFO - 2016-05-18 18:59:26 --> Model Class Initialized
INFO - 2016-05-18 18:59:26 --> Database Driver Class Initialized
INFO - 2016-05-18 18:59:26 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:59:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:59:26 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:59:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:59:26 --> Helper loaded: nif_validate_helper
INFO - 2016-05-18 18:59:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-18 18:59:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:59:26 --> Final output sent to browser
DEBUG - 2016-05-18 18:59:26 --> Total execution time: 0.0815
INFO - 2016-05-18 18:59:26 --> Config Class Initialized
INFO - 2016-05-18 18:59:26 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:59:26 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:59:26 --> Utf8 Class Initialized
INFO - 2016-05-18 18:59:26 --> URI Class Initialized
INFO - 2016-05-18 18:59:26 --> Router Class Initialized
INFO - 2016-05-18 18:59:26 --> Output Class Initialized
INFO - 2016-05-18 18:59:26 --> Security Class Initialized
DEBUG - 2016-05-18 18:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:59:26 --> Input Class Initialized
INFO - 2016-05-18 18:59:26 --> Language Class Initialized
INFO - 2016-05-18 18:59:26 --> Loader Class Initialized
INFO - 2016-05-18 18:59:26 --> Helper loaded: url_helper
INFO - 2016-05-18 18:59:26 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:59:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:59:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:59:26 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:59:26 --> Helper loaded: form_helper
INFO - 2016-05-18 18:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:59:26 --> Form Validation Class Initialized
INFO - 2016-05-18 18:59:26 --> Controller Class Initialized
INFO - 2016-05-18 18:59:26 --> Model Class Initialized
INFO - 2016-05-18 18:59:26 --> Database Driver Class Initialized
INFO - 2016-05-18 18:59:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:59:26 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:59:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:59:26 --> Final output sent to browser
DEBUG - 2016-05-18 18:59:26 --> Total execution time: 0.1117
INFO - 2016-05-18 18:59:33 --> Config Class Initialized
INFO - 2016-05-18 18:59:33 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:59:33 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:59:33 --> Utf8 Class Initialized
INFO - 2016-05-18 18:59:33 --> URI Class Initialized
INFO - 2016-05-18 18:59:33 --> Router Class Initialized
INFO - 2016-05-18 18:59:33 --> Output Class Initialized
INFO - 2016-05-18 18:59:33 --> Security Class Initialized
DEBUG - 2016-05-18 18:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:59:33 --> Input Class Initialized
INFO - 2016-05-18 18:59:33 --> Language Class Initialized
INFO - 2016-05-18 18:59:33 --> Loader Class Initialized
INFO - 2016-05-18 18:59:33 --> Helper loaded: url_helper
INFO - 2016-05-18 18:59:33 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:59:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:59:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:59:33 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:59:33 --> Helper loaded: form_helper
INFO - 2016-05-18 18:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:59:33 --> Form Validation Class Initialized
INFO - 2016-05-18 18:59:33 --> Controller Class Initialized
INFO - 2016-05-18 18:59:33 --> Model Class Initialized
INFO - 2016-05-18 18:59:33 --> Database Driver Class Initialized
INFO - 2016-05-18 18:59:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:59:33 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:59:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:59:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 18:59:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:59:33 --> Final output sent to browser
DEBUG - 2016-05-18 18:59:33 --> Total execution time: 0.0913
INFO - 2016-05-18 18:59:33 --> Config Class Initialized
INFO - 2016-05-18 18:59:33 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:59:33 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:59:33 --> Utf8 Class Initialized
INFO - 2016-05-18 18:59:33 --> URI Class Initialized
INFO - 2016-05-18 18:59:33 --> Router Class Initialized
INFO - 2016-05-18 18:59:33 --> Output Class Initialized
INFO - 2016-05-18 18:59:33 --> Security Class Initialized
DEBUG - 2016-05-18 18:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:59:33 --> Input Class Initialized
INFO - 2016-05-18 18:59:33 --> Language Class Initialized
INFO - 2016-05-18 18:59:33 --> Loader Class Initialized
INFO - 2016-05-18 18:59:33 --> Helper loaded: url_helper
INFO - 2016-05-18 18:59:33 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:59:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:59:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:59:33 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:59:33 --> Helper loaded: form_helper
INFO - 2016-05-18 18:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:59:33 --> Form Validation Class Initialized
INFO - 2016-05-18 18:59:33 --> Controller Class Initialized
INFO - 2016-05-18 18:59:33 --> Model Class Initialized
INFO - 2016-05-18 18:59:33 --> Database Driver Class Initialized
INFO - 2016-05-18 18:59:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:59:33 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:59:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:59:33 --> Final output sent to browser
DEBUG - 2016-05-18 18:59:33 --> Total execution time: 0.0919
INFO - 2016-05-18 18:59:35 --> Config Class Initialized
INFO - 2016-05-18 18:59:35 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:59:35 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:59:35 --> Utf8 Class Initialized
INFO - 2016-05-18 18:59:35 --> URI Class Initialized
INFO - 2016-05-18 18:59:35 --> Router Class Initialized
INFO - 2016-05-18 18:59:35 --> Output Class Initialized
INFO - 2016-05-18 18:59:35 --> Security Class Initialized
DEBUG - 2016-05-18 18:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:59:35 --> Input Class Initialized
INFO - 2016-05-18 18:59:35 --> Language Class Initialized
INFO - 2016-05-18 18:59:35 --> Loader Class Initialized
INFO - 2016-05-18 18:59:35 --> Helper loaded: url_helper
INFO - 2016-05-18 18:59:35 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:59:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:59:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:59:35 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:59:35 --> Helper loaded: form_helper
INFO - 2016-05-18 18:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:59:35 --> Form Validation Class Initialized
INFO - 2016-05-18 18:59:35 --> Controller Class Initialized
INFO - 2016-05-18 18:59:35 --> Model Class Initialized
INFO - 2016-05-18 18:59:35 --> Database Driver Class Initialized
INFO - 2016-05-18 18:59:35 --> Helper loaded: creaselect_helper
INFO - 2016-05-18 18:59:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:59:35 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:59:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:59:35 --> Helper loaded: nif_validate_helper
INFO - 2016-05-18 18:59:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleCliente.php
INFO - 2016-05-18 18:59:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:59:35 --> Final output sent to browser
DEBUG - 2016-05-18 18:59:35 --> Total execution time: 0.0979
INFO - 2016-05-18 18:59:35 --> Config Class Initialized
INFO - 2016-05-18 18:59:35 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:59:35 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:59:35 --> Utf8 Class Initialized
INFO - 2016-05-18 18:59:35 --> URI Class Initialized
INFO - 2016-05-18 18:59:35 --> Router Class Initialized
INFO - 2016-05-18 18:59:35 --> Output Class Initialized
INFO - 2016-05-18 18:59:35 --> Security Class Initialized
DEBUG - 2016-05-18 18:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:59:35 --> Input Class Initialized
INFO - 2016-05-18 18:59:35 --> Language Class Initialized
INFO - 2016-05-18 18:59:35 --> Loader Class Initialized
INFO - 2016-05-18 18:59:35 --> Helper loaded: url_helper
INFO - 2016-05-18 18:59:35 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:59:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:59:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:59:35 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:59:35 --> Helper loaded: form_helper
INFO - 2016-05-18 18:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:59:35 --> Form Validation Class Initialized
INFO - 2016-05-18 18:59:35 --> Controller Class Initialized
INFO - 2016-05-18 18:59:35 --> Model Class Initialized
INFO - 2016-05-18 18:59:35 --> Database Driver Class Initialized
INFO - 2016-05-18 18:59:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:59:35 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:59:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:59:35 --> Final output sent to browser
DEBUG - 2016-05-18 18:59:35 --> Total execution time: 0.1207
INFO - 2016-05-18 18:59:37 --> Config Class Initialized
INFO - 2016-05-18 18:59:37 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:59:37 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:59:37 --> Utf8 Class Initialized
INFO - 2016-05-18 18:59:37 --> URI Class Initialized
INFO - 2016-05-18 18:59:37 --> Router Class Initialized
INFO - 2016-05-18 18:59:37 --> Output Class Initialized
INFO - 2016-05-18 18:59:37 --> Security Class Initialized
DEBUG - 2016-05-18 18:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:59:37 --> Input Class Initialized
INFO - 2016-05-18 18:59:37 --> Language Class Initialized
INFO - 2016-05-18 18:59:37 --> Loader Class Initialized
INFO - 2016-05-18 18:59:37 --> Helper loaded: url_helper
INFO - 2016-05-18 18:59:37 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:59:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:59:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:59:37 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:59:37 --> Helper loaded: form_helper
INFO - 2016-05-18 18:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:59:37 --> Form Validation Class Initialized
INFO - 2016-05-18 18:59:37 --> Controller Class Initialized
INFO - 2016-05-18 18:59:37 --> Model Class Initialized
INFO - 2016-05-18 18:59:37 --> Database Driver Class Initialized
INFO - 2016-05-18 18:59:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:59:37 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:59:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:59:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 18:59:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 18:59:37 --> Final output sent to browser
DEBUG - 2016-05-18 18:59:37 --> Total execution time: 0.0874
INFO - 2016-05-18 18:59:37 --> Config Class Initialized
INFO - 2016-05-18 18:59:37 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:59:37 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:59:37 --> Utf8 Class Initialized
INFO - 2016-05-18 18:59:37 --> URI Class Initialized
INFO - 2016-05-18 18:59:37 --> Router Class Initialized
INFO - 2016-05-18 18:59:37 --> Output Class Initialized
INFO - 2016-05-18 18:59:37 --> Security Class Initialized
DEBUG - 2016-05-18 18:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:59:37 --> Input Class Initialized
INFO - 2016-05-18 18:59:37 --> Language Class Initialized
INFO - 2016-05-18 18:59:37 --> Loader Class Initialized
INFO - 2016-05-18 18:59:37 --> Helper loaded: url_helper
INFO - 2016-05-18 18:59:37 --> Helper loaded: sesion_helper
INFO - 2016-05-18 18:59:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 18:59:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 18:59:37 --> Helper loaded: redondear_helper
INFO - 2016-05-18 18:59:37 --> Helper loaded: form_helper
INFO - 2016-05-18 18:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 18:59:37 --> Form Validation Class Initialized
INFO - 2016-05-18 18:59:37 --> Controller Class Initialized
INFO - 2016-05-18 18:59:37 --> Model Class Initialized
INFO - 2016-05-18 18:59:37 --> Database Driver Class Initialized
INFO - 2016-05-18 18:59:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 18:59:37 --> Pagination Class Initialized
DEBUG - 2016-05-18 18:59:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 18:59:37 --> Final output sent to browser
DEBUG - 2016-05-18 18:59:37 --> Total execution time: 0.1009
INFO - 2016-05-18 19:00:37 --> Config Class Initialized
INFO - 2016-05-18 19:00:37 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:00:37 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:00:37 --> Utf8 Class Initialized
INFO - 2016-05-18 19:00:37 --> URI Class Initialized
INFO - 2016-05-18 19:00:37 --> Router Class Initialized
INFO - 2016-05-18 19:00:37 --> Output Class Initialized
INFO - 2016-05-18 19:00:37 --> Security Class Initialized
DEBUG - 2016-05-18 19:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:00:37 --> Input Class Initialized
INFO - 2016-05-18 19:00:37 --> Language Class Initialized
INFO - 2016-05-18 19:00:37 --> Loader Class Initialized
INFO - 2016-05-18 19:00:37 --> Helper loaded: url_helper
INFO - 2016-05-18 19:00:37 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:00:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:00:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:00:37 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:00:37 --> Helper loaded: form_helper
INFO - 2016-05-18 19:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:00:37 --> Form Validation Class Initialized
INFO - 2016-05-18 19:00:37 --> Controller Class Initialized
INFO - 2016-05-18 19:00:37 --> Model Class Initialized
INFO - 2016-05-18 19:00:37 --> Database Driver Class Initialized
INFO - 2016-05-18 19:00:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:00:37 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:00:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:00:37 --> Final output sent to browser
DEBUG - 2016-05-18 19:00:37 --> Total execution time: 0.0740
INFO - 2016-05-18 19:01:37 --> Config Class Initialized
INFO - 2016-05-18 19:01:37 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:01:37 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:01:37 --> Utf8 Class Initialized
INFO - 2016-05-18 19:01:37 --> URI Class Initialized
INFO - 2016-05-18 19:01:37 --> Router Class Initialized
INFO - 2016-05-18 19:01:37 --> Output Class Initialized
INFO - 2016-05-18 19:01:37 --> Security Class Initialized
DEBUG - 2016-05-18 19:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:01:37 --> Input Class Initialized
INFO - 2016-05-18 19:01:37 --> Language Class Initialized
INFO - 2016-05-18 19:01:37 --> Loader Class Initialized
INFO - 2016-05-18 19:01:37 --> Helper loaded: url_helper
INFO - 2016-05-18 19:01:37 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:01:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:01:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:01:37 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:01:37 --> Helper loaded: form_helper
INFO - 2016-05-18 19:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:01:37 --> Form Validation Class Initialized
INFO - 2016-05-18 19:01:37 --> Controller Class Initialized
INFO - 2016-05-18 19:01:37 --> Model Class Initialized
INFO - 2016-05-18 19:01:37 --> Database Driver Class Initialized
INFO - 2016-05-18 19:01:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:01:37 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:01:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:01:37 --> Final output sent to browser
DEBUG - 2016-05-18 19:01:37 --> Total execution time: 0.0662
INFO - 2016-05-18 19:02:37 --> Config Class Initialized
INFO - 2016-05-18 19:02:37 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:02:37 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:02:37 --> Utf8 Class Initialized
INFO - 2016-05-18 19:02:37 --> URI Class Initialized
INFO - 2016-05-18 19:02:37 --> Router Class Initialized
INFO - 2016-05-18 19:02:37 --> Output Class Initialized
INFO - 2016-05-18 19:02:37 --> Security Class Initialized
DEBUG - 2016-05-18 19:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:02:37 --> Input Class Initialized
INFO - 2016-05-18 19:02:37 --> Language Class Initialized
INFO - 2016-05-18 19:02:37 --> Loader Class Initialized
INFO - 2016-05-18 19:02:37 --> Helper loaded: url_helper
INFO - 2016-05-18 19:02:37 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:02:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:02:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:02:37 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:02:37 --> Helper loaded: form_helper
INFO - 2016-05-18 19:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:02:37 --> Form Validation Class Initialized
INFO - 2016-05-18 19:02:37 --> Controller Class Initialized
INFO - 2016-05-18 19:02:37 --> Model Class Initialized
INFO - 2016-05-18 19:02:37 --> Database Driver Class Initialized
INFO - 2016-05-18 19:02:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:02:37 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:02:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:02:37 --> Final output sent to browser
DEBUG - 2016-05-18 19:02:37 --> Total execution time: 0.0792
INFO - 2016-05-18 19:03:37 --> Config Class Initialized
INFO - 2016-05-18 19:03:37 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:03:37 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:03:37 --> Utf8 Class Initialized
INFO - 2016-05-18 19:03:37 --> URI Class Initialized
INFO - 2016-05-18 19:03:37 --> Router Class Initialized
INFO - 2016-05-18 19:03:37 --> Output Class Initialized
INFO - 2016-05-18 19:03:37 --> Security Class Initialized
DEBUG - 2016-05-18 19:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:03:37 --> Input Class Initialized
INFO - 2016-05-18 19:03:37 --> Language Class Initialized
INFO - 2016-05-18 19:03:37 --> Loader Class Initialized
INFO - 2016-05-18 19:03:37 --> Helper loaded: url_helper
INFO - 2016-05-18 19:03:37 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:03:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:03:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:03:37 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:03:37 --> Helper loaded: form_helper
INFO - 2016-05-18 19:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:03:37 --> Form Validation Class Initialized
INFO - 2016-05-18 19:03:37 --> Controller Class Initialized
INFO - 2016-05-18 19:03:37 --> Model Class Initialized
INFO - 2016-05-18 19:03:37 --> Database Driver Class Initialized
INFO - 2016-05-18 19:03:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:03:37 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:03:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:03:37 --> Final output sent to browser
DEBUG - 2016-05-18 19:03:37 --> Total execution time: 0.0775
INFO - 2016-05-18 19:04:37 --> Config Class Initialized
INFO - 2016-05-18 19:04:37 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:04:37 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:04:37 --> Utf8 Class Initialized
INFO - 2016-05-18 19:04:37 --> URI Class Initialized
INFO - 2016-05-18 19:04:37 --> Router Class Initialized
INFO - 2016-05-18 19:04:37 --> Output Class Initialized
INFO - 2016-05-18 19:04:37 --> Security Class Initialized
DEBUG - 2016-05-18 19:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:04:37 --> Input Class Initialized
INFO - 2016-05-18 19:04:37 --> Language Class Initialized
INFO - 2016-05-18 19:04:37 --> Loader Class Initialized
INFO - 2016-05-18 19:04:37 --> Helper loaded: url_helper
INFO - 2016-05-18 19:04:37 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:04:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:04:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:04:37 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:04:37 --> Helper loaded: form_helper
INFO - 2016-05-18 19:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:04:37 --> Form Validation Class Initialized
INFO - 2016-05-18 19:04:37 --> Controller Class Initialized
INFO - 2016-05-18 19:04:37 --> Model Class Initialized
INFO - 2016-05-18 19:04:37 --> Database Driver Class Initialized
INFO - 2016-05-18 19:04:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:04:37 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:04:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:04:37 --> Final output sent to browser
DEBUG - 2016-05-18 19:04:37 --> Total execution time: 0.0813
INFO - 2016-05-18 19:05:37 --> Config Class Initialized
INFO - 2016-05-18 19:05:37 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:05:37 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:05:37 --> Utf8 Class Initialized
INFO - 2016-05-18 19:05:37 --> URI Class Initialized
INFO - 2016-05-18 19:05:37 --> Router Class Initialized
INFO - 2016-05-18 19:05:37 --> Output Class Initialized
INFO - 2016-05-18 19:05:37 --> Security Class Initialized
DEBUG - 2016-05-18 19:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:05:37 --> Input Class Initialized
INFO - 2016-05-18 19:05:37 --> Language Class Initialized
INFO - 2016-05-18 19:05:37 --> Loader Class Initialized
INFO - 2016-05-18 19:05:37 --> Helper loaded: url_helper
INFO - 2016-05-18 19:05:37 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:05:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:05:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:05:37 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:05:37 --> Helper loaded: form_helper
INFO - 2016-05-18 19:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:05:37 --> Form Validation Class Initialized
INFO - 2016-05-18 19:05:37 --> Controller Class Initialized
INFO - 2016-05-18 19:05:37 --> Model Class Initialized
INFO - 2016-05-18 19:05:37 --> Database Driver Class Initialized
INFO - 2016-05-18 19:05:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:05:37 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:05:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:05:37 --> Final output sent to browser
DEBUG - 2016-05-18 19:05:37 --> Total execution time: 0.0772
INFO - 2016-05-18 19:06:17 --> Config Class Initialized
INFO - 2016-05-18 19:06:17 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:06:17 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:06:17 --> Utf8 Class Initialized
INFO - 2016-05-18 19:06:17 --> URI Class Initialized
INFO - 2016-05-18 19:06:17 --> Router Class Initialized
INFO - 2016-05-18 19:06:17 --> Output Class Initialized
INFO - 2016-05-18 19:06:17 --> Security Class Initialized
DEBUG - 2016-05-18 19:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:06:17 --> Input Class Initialized
INFO - 2016-05-18 19:06:17 --> Language Class Initialized
INFO - 2016-05-18 19:06:17 --> Loader Class Initialized
INFO - 2016-05-18 19:06:17 --> Helper loaded: url_helper
INFO - 2016-05-18 19:06:17 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:06:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:06:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:06:17 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:06:17 --> Helper loaded: form_helper
INFO - 2016-05-18 19:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:06:17 --> Form Validation Class Initialized
INFO - 2016-05-18 19:06:17 --> Controller Class Initialized
INFO - 2016-05-18 19:06:17 --> Model Class Initialized
INFO - 2016-05-18 19:06:17 --> Database Driver Class Initialized
INFO - 2016-05-18 19:06:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:06:17 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:06:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:06:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:06:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:06:17 --> Final output sent to browser
DEBUG - 2016-05-18 19:06:17 --> Total execution time: 0.0886
INFO - 2016-05-18 19:06:18 --> Config Class Initialized
INFO - 2016-05-18 19:06:18 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:06:18 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:06:18 --> Utf8 Class Initialized
INFO - 2016-05-18 19:06:18 --> URI Class Initialized
INFO - 2016-05-18 19:06:18 --> Router Class Initialized
INFO - 2016-05-18 19:06:18 --> Output Class Initialized
INFO - 2016-05-18 19:06:18 --> Security Class Initialized
DEBUG - 2016-05-18 19:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:06:18 --> Input Class Initialized
INFO - 2016-05-18 19:06:18 --> Language Class Initialized
INFO - 2016-05-18 19:06:18 --> Loader Class Initialized
INFO - 2016-05-18 19:06:18 --> Helper loaded: url_helper
INFO - 2016-05-18 19:06:18 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:06:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:06:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:06:18 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:06:18 --> Helper loaded: form_helper
INFO - 2016-05-18 19:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:06:18 --> Form Validation Class Initialized
INFO - 2016-05-18 19:06:18 --> Controller Class Initialized
INFO - 2016-05-18 19:06:18 --> Model Class Initialized
INFO - 2016-05-18 19:06:18 --> Database Driver Class Initialized
INFO - 2016-05-18 19:06:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:06:18 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:06:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:06:18 --> Final output sent to browser
DEBUG - 2016-05-18 19:06:18 --> Total execution time: 0.1024
INFO - 2016-05-18 19:07:18 --> Config Class Initialized
INFO - 2016-05-18 19:07:18 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:07:18 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:07:18 --> Utf8 Class Initialized
INFO - 2016-05-18 19:07:18 --> URI Class Initialized
INFO - 2016-05-18 19:07:18 --> Router Class Initialized
INFO - 2016-05-18 19:07:18 --> Output Class Initialized
INFO - 2016-05-18 19:07:18 --> Security Class Initialized
DEBUG - 2016-05-18 19:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:07:18 --> Input Class Initialized
INFO - 2016-05-18 19:07:18 --> Language Class Initialized
INFO - 2016-05-18 19:07:18 --> Loader Class Initialized
INFO - 2016-05-18 19:07:18 --> Helper loaded: url_helper
INFO - 2016-05-18 19:07:18 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:07:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:07:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:07:18 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:07:18 --> Helper loaded: form_helper
INFO - 2016-05-18 19:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:07:18 --> Form Validation Class Initialized
INFO - 2016-05-18 19:07:18 --> Controller Class Initialized
INFO - 2016-05-18 19:07:18 --> Model Class Initialized
INFO - 2016-05-18 19:07:18 --> Database Driver Class Initialized
INFO - 2016-05-18 19:07:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:07:18 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:07:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:07:18 --> Final output sent to browser
DEBUG - 2016-05-18 19:07:18 --> Total execution time: 0.0701
INFO - 2016-05-18 19:08:00 --> Config Class Initialized
INFO - 2016-05-18 19:08:00 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:08:00 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:08:00 --> Utf8 Class Initialized
INFO - 2016-05-18 19:08:00 --> URI Class Initialized
INFO - 2016-05-18 19:08:00 --> Router Class Initialized
INFO - 2016-05-18 19:08:00 --> Output Class Initialized
INFO - 2016-05-18 19:08:00 --> Security Class Initialized
DEBUG - 2016-05-18 19:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:08:00 --> Input Class Initialized
INFO - 2016-05-18 19:08:00 --> Language Class Initialized
INFO - 2016-05-18 19:08:00 --> Loader Class Initialized
INFO - 2016-05-18 19:08:00 --> Helper loaded: url_helper
INFO - 2016-05-18 19:08:00 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:08:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:08:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:08:00 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:08:00 --> Helper loaded: form_helper
INFO - 2016-05-18 19:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:08:00 --> Form Validation Class Initialized
INFO - 2016-05-18 19:08:00 --> Controller Class Initialized
INFO - 2016-05-18 19:08:00 --> Model Class Initialized
INFO - 2016-05-18 19:08:00 --> Database Driver Class Initialized
INFO - 2016-05-18 19:08:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:08:00 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:08:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:08:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:08:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:08:00 --> Final output sent to browser
DEBUG - 2016-05-18 19:08:00 --> Total execution time: 0.0997
INFO - 2016-05-18 19:08:01 --> Config Class Initialized
INFO - 2016-05-18 19:08:01 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:08:01 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:08:01 --> Utf8 Class Initialized
INFO - 2016-05-18 19:08:01 --> URI Class Initialized
INFO - 2016-05-18 19:08:01 --> Router Class Initialized
INFO - 2016-05-18 19:08:01 --> Output Class Initialized
INFO - 2016-05-18 19:08:01 --> Security Class Initialized
DEBUG - 2016-05-18 19:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:08:01 --> Input Class Initialized
INFO - 2016-05-18 19:08:01 --> Language Class Initialized
INFO - 2016-05-18 19:08:01 --> Loader Class Initialized
INFO - 2016-05-18 19:08:01 --> Helper loaded: url_helper
INFO - 2016-05-18 19:08:01 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:08:01 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:08:01 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:08:01 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:08:01 --> Helper loaded: form_helper
INFO - 2016-05-18 19:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:08:01 --> Form Validation Class Initialized
INFO - 2016-05-18 19:08:01 --> Controller Class Initialized
INFO - 2016-05-18 19:08:01 --> Model Class Initialized
INFO - 2016-05-18 19:08:01 --> Database Driver Class Initialized
INFO - 2016-05-18 19:08:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:08:01 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:08:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:08:01 --> Final output sent to browser
DEBUG - 2016-05-18 19:08:01 --> Total execution time: 0.1354
INFO - 2016-05-18 19:08:45 --> Config Class Initialized
INFO - 2016-05-18 19:08:45 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:08:45 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:08:45 --> Utf8 Class Initialized
INFO - 2016-05-18 19:08:45 --> URI Class Initialized
INFO - 2016-05-18 19:08:45 --> Router Class Initialized
INFO - 2016-05-18 19:08:45 --> Output Class Initialized
INFO - 2016-05-18 19:08:45 --> Security Class Initialized
DEBUG - 2016-05-18 19:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:08:45 --> Input Class Initialized
INFO - 2016-05-18 19:08:45 --> Language Class Initialized
INFO - 2016-05-18 19:08:45 --> Loader Class Initialized
INFO - 2016-05-18 19:08:46 --> Helper loaded: url_helper
INFO - 2016-05-18 19:08:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:08:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:08:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:08:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:08:46 --> Helper loaded: form_helper
INFO - 2016-05-18 19:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:08:46 --> Form Validation Class Initialized
INFO - 2016-05-18 19:08:46 --> Controller Class Initialized
INFO - 2016-05-18 19:08:46 --> Model Class Initialized
INFO - 2016-05-18 19:08:46 --> Database Driver Class Initialized
INFO - 2016-05-18 19:08:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:08:46 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:08:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:08:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:08:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:08:46 --> Final output sent to browser
DEBUG - 2016-05-18 19:08:46 --> Total execution time: 0.0820
INFO - 2016-05-18 19:08:46 --> Config Class Initialized
INFO - 2016-05-18 19:08:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:08:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:08:46 --> Utf8 Class Initialized
INFO - 2016-05-18 19:08:46 --> URI Class Initialized
INFO - 2016-05-18 19:08:46 --> Router Class Initialized
INFO - 2016-05-18 19:08:46 --> Output Class Initialized
INFO - 2016-05-18 19:08:46 --> Security Class Initialized
DEBUG - 2016-05-18 19:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:08:46 --> Input Class Initialized
INFO - 2016-05-18 19:08:46 --> Language Class Initialized
INFO - 2016-05-18 19:08:46 --> Loader Class Initialized
INFO - 2016-05-18 19:08:46 --> Helper loaded: url_helper
INFO - 2016-05-18 19:08:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:08:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:08:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:08:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:08:46 --> Helper loaded: form_helper
INFO - 2016-05-18 19:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:08:46 --> Form Validation Class Initialized
INFO - 2016-05-18 19:08:46 --> Controller Class Initialized
INFO - 2016-05-18 19:08:46 --> Model Class Initialized
INFO - 2016-05-18 19:08:46 --> Database Driver Class Initialized
INFO - 2016-05-18 19:08:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:08:46 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:08:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:08:46 --> Final output sent to browser
DEBUG - 2016-05-18 19:08:46 --> Total execution time: 0.1182
INFO - 2016-05-18 19:08:48 --> Config Class Initialized
INFO - 2016-05-18 19:08:48 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:08:48 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:08:48 --> Utf8 Class Initialized
INFO - 2016-05-18 19:08:48 --> URI Class Initialized
INFO - 2016-05-18 19:08:48 --> Router Class Initialized
INFO - 2016-05-18 19:08:48 --> Output Class Initialized
INFO - 2016-05-18 19:08:48 --> Security Class Initialized
DEBUG - 2016-05-18 19:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:08:48 --> Input Class Initialized
INFO - 2016-05-18 19:08:48 --> Language Class Initialized
INFO - 2016-05-18 19:08:48 --> Loader Class Initialized
INFO - 2016-05-18 19:08:48 --> Helper loaded: url_helper
INFO - 2016-05-18 19:08:48 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:08:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:08:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:08:48 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:08:48 --> Helper loaded: form_helper
INFO - 2016-05-18 19:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:08:48 --> Form Validation Class Initialized
INFO - 2016-05-18 19:08:48 --> Controller Class Initialized
INFO - 2016-05-18 19:08:48 --> Model Class Initialized
INFO - 2016-05-18 19:08:48 --> Database Driver Class Initialized
INFO - 2016-05-18 19:08:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:08:48 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:08:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:08:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:08:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:08:48 --> Final output sent to browser
DEBUG - 2016-05-18 19:08:48 --> Total execution time: 0.0823
INFO - 2016-05-18 19:08:48 --> Config Class Initialized
INFO - 2016-05-18 19:08:48 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:08:48 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:08:48 --> Utf8 Class Initialized
INFO - 2016-05-18 19:08:48 --> URI Class Initialized
INFO - 2016-05-18 19:08:48 --> Router Class Initialized
INFO - 2016-05-18 19:08:48 --> Output Class Initialized
INFO - 2016-05-18 19:08:48 --> Security Class Initialized
DEBUG - 2016-05-18 19:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:08:48 --> Input Class Initialized
INFO - 2016-05-18 19:08:48 --> Language Class Initialized
INFO - 2016-05-18 19:08:48 --> Loader Class Initialized
INFO - 2016-05-18 19:08:48 --> Helper loaded: url_helper
INFO - 2016-05-18 19:08:48 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:08:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:08:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:08:48 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:08:48 --> Helper loaded: form_helper
INFO - 2016-05-18 19:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:08:48 --> Form Validation Class Initialized
INFO - 2016-05-18 19:08:48 --> Controller Class Initialized
INFO - 2016-05-18 19:08:48 --> Model Class Initialized
INFO - 2016-05-18 19:08:48 --> Database Driver Class Initialized
INFO - 2016-05-18 19:08:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:08:48 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:08:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:08:48 --> Final output sent to browser
DEBUG - 2016-05-18 19:08:48 --> Total execution time: 0.1442
INFO - 2016-05-18 19:08:59 --> Config Class Initialized
INFO - 2016-05-18 19:08:59 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:08:59 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:08:59 --> Utf8 Class Initialized
INFO - 2016-05-18 19:08:59 --> URI Class Initialized
INFO - 2016-05-18 19:08:59 --> Router Class Initialized
INFO - 2016-05-18 19:08:59 --> Output Class Initialized
INFO - 2016-05-18 19:08:59 --> Security Class Initialized
DEBUG - 2016-05-18 19:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:08:59 --> Input Class Initialized
INFO - 2016-05-18 19:08:59 --> Language Class Initialized
INFO - 2016-05-18 19:08:59 --> Loader Class Initialized
INFO - 2016-05-18 19:08:59 --> Helper loaded: url_helper
INFO - 2016-05-18 19:08:59 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:08:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:08:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:08:59 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:08:59 --> Helper loaded: form_helper
INFO - 2016-05-18 19:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:08:59 --> Form Validation Class Initialized
INFO - 2016-05-18 19:08:59 --> Controller Class Initialized
INFO - 2016-05-18 19:08:59 --> Model Class Initialized
INFO - 2016-05-18 19:08:59 --> Database Driver Class Initialized
INFO - 2016-05-18 19:08:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:08:59 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:08:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:08:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:08:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:08:59 --> Final output sent to browser
DEBUG - 2016-05-18 19:08:59 --> Total execution time: 0.0801
INFO - 2016-05-18 19:08:59 --> Config Class Initialized
INFO - 2016-05-18 19:08:59 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:08:59 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:08:59 --> Utf8 Class Initialized
INFO - 2016-05-18 19:08:59 --> URI Class Initialized
INFO - 2016-05-18 19:08:59 --> Router Class Initialized
INFO - 2016-05-18 19:08:59 --> Output Class Initialized
INFO - 2016-05-18 19:08:59 --> Security Class Initialized
DEBUG - 2016-05-18 19:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:08:59 --> Input Class Initialized
INFO - 2016-05-18 19:08:59 --> Language Class Initialized
INFO - 2016-05-18 19:08:59 --> Loader Class Initialized
INFO - 2016-05-18 19:08:59 --> Helper loaded: url_helper
INFO - 2016-05-18 19:08:59 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:08:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:08:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:08:59 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:08:59 --> Helper loaded: form_helper
INFO - 2016-05-18 19:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:08:59 --> Form Validation Class Initialized
INFO - 2016-05-18 19:08:59 --> Controller Class Initialized
INFO - 2016-05-18 19:08:59 --> Model Class Initialized
INFO - 2016-05-18 19:08:59 --> Database Driver Class Initialized
INFO - 2016-05-18 19:08:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:08:59 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:08:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:08:59 --> Final output sent to browser
DEBUG - 2016-05-18 19:08:59 --> Total execution time: 0.1120
INFO - 2016-05-18 19:09:32 --> Config Class Initialized
INFO - 2016-05-18 19:09:32 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:09:32 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:09:32 --> Utf8 Class Initialized
INFO - 2016-05-18 19:09:32 --> URI Class Initialized
INFO - 2016-05-18 19:09:32 --> Router Class Initialized
INFO - 2016-05-18 19:09:32 --> Output Class Initialized
INFO - 2016-05-18 19:09:32 --> Security Class Initialized
DEBUG - 2016-05-18 19:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:09:32 --> Input Class Initialized
INFO - 2016-05-18 19:09:32 --> Language Class Initialized
INFO - 2016-05-18 19:09:32 --> Loader Class Initialized
INFO - 2016-05-18 19:09:32 --> Helper loaded: url_helper
INFO - 2016-05-18 19:09:32 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:09:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:09:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:09:32 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:09:32 --> Helper loaded: form_helper
INFO - 2016-05-18 19:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:09:32 --> Form Validation Class Initialized
INFO - 2016-05-18 19:09:32 --> Controller Class Initialized
INFO - 2016-05-18 19:09:32 --> Model Class Initialized
INFO - 2016-05-18 19:09:32 --> Database Driver Class Initialized
INFO - 2016-05-18 19:09:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:09:32 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:09:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:09:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:09:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:09:32 --> Final output sent to browser
DEBUG - 2016-05-18 19:09:32 --> Total execution time: 0.1111
INFO - 2016-05-18 19:09:33 --> Config Class Initialized
INFO - 2016-05-18 19:09:33 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:09:33 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:09:33 --> Utf8 Class Initialized
INFO - 2016-05-18 19:09:33 --> URI Class Initialized
INFO - 2016-05-18 19:09:33 --> Router Class Initialized
INFO - 2016-05-18 19:09:33 --> Output Class Initialized
INFO - 2016-05-18 19:09:33 --> Security Class Initialized
DEBUG - 2016-05-18 19:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:09:33 --> Input Class Initialized
INFO - 2016-05-18 19:09:33 --> Language Class Initialized
INFO - 2016-05-18 19:09:33 --> Loader Class Initialized
INFO - 2016-05-18 19:09:33 --> Helper loaded: url_helper
INFO - 2016-05-18 19:09:33 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:09:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:09:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:09:33 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:09:33 --> Helper loaded: form_helper
INFO - 2016-05-18 19:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:09:33 --> Form Validation Class Initialized
INFO - 2016-05-18 19:09:33 --> Controller Class Initialized
INFO - 2016-05-18 19:09:33 --> Model Class Initialized
INFO - 2016-05-18 19:09:33 --> Database Driver Class Initialized
INFO - 2016-05-18 19:09:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:09:33 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:09:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:09:33 --> Final output sent to browser
DEBUG - 2016-05-18 19:09:33 --> Total execution time: 0.1314
INFO - 2016-05-18 19:10:08 --> Config Class Initialized
INFO - 2016-05-18 19:10:08 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:10:08 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:10:08 --> Utf8 Class Initialized
INFO - 2016-05-18 19:10:08 --> URI Class Initialized
INFO - 2016-05-18 19:10:08 --> Router Class Initialized
INFO - 2016-05-18 19:10:08 --> Output Class Initialized
INFO - 2016-05-18 19:10:08 --> Security Class Initialized
DEBUG - 2016-05-18 19:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:10:08 --> Input Class Initialized
INFO - 2016-05-18 19:10:08 --> Language Class Initialized
INFO - 2016-05-18 19:10:08 --> Loader Class Initialized
INFO - 2016-05-18 19:10:08 --> Helper loaded: url_helper
INFO - 2016-05-18 19:10:08 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:10:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:10:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:10:08 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:10:08 --> Helper loaded: form_helper
INFO - 2016-05-18 19:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:10:08 --> Form Validation Class Initialized
INFO - 2016-05-18 19:10:08 --> Controller Class Initialized
INFO - 2016-05-18 19:10:08 --> Model Class Initialized
INFO - 2016-05-18 19:10:08 --> Database Driver Class Initialized
INFO - 2016-05-18 19:10:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:10:08 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:10:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:10:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:10:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:10:08 --> Final output sent to browser
DEBUG - 2016-05-18 19:10:08 --> Total execution time: 0.0819
INFO - 2016-05-18 19:10:09 --> Config Class Initialized
INFO - 2016-05-18 19:10:09 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:10:09 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:10:09 --> Utf8 Class Initialized
INFO - 2016-05-18 19:10:09 --> URI Class Initialized
INFO - 2016-05-18 19:10:09 --> Router Class Initialized
INFO - 2016-05-18 19:10:09 --> Output Class Initialized
INFO - 2016-05-18 19:10:09 --> Security Class Initialized
DEBUG - 2016-05-18 19:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:10:09 --> Input Class Initialized
INFO - 2016-05-18 19:10:09 --> Language Class Initialized
INFO - 2016-05-18 19:10:09 --> Loader Class Initialized
INFO - 2016-05-18 19:10:09 --> Helper loaded: url_helper
INFO - 2016-05-18 19:10:09 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:10:09 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:10:09 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:10:09 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:10:09 --> Helper loaded: form_helper
INFO - 2016-05-18 19:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:10:09 --> Form Validation Class Initialized
INFO - 2016-05-18 19:10:09 --> Controller Class Initialized
INFO - 2016-05-18 19:10:09 --> Model Class Initialized
INFO - 2016-05-18 19:10:09 --> Database Driver Class Initialized
INFO - 2016-05-18 19:10:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:10:09 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:10:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:10:09 --> Final output sent to browser
DEBUG - 2016-05-18 19:10:09 --> Total execution time: 0.1112
INFO - 2016-05-18 19:10:33 --> Config Class Initialized
INFO - 2016-05-18 19:10:33 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:10:33 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:10:33 --> Utf8 Class Initialized
INFO - 2016-05-18 19:10:33 --> URI Class Initialized
INFO - 2016-05-18 19:10:33 --> Router Class Initialized
INFO - 2016-05-18 19:10:33 --> Output Class Initialized
INFO - 2016-05-18 19:10:33 --> Security Class Initialized
DEBUG - 2016-05-18 19:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:10:33 --> Input Class Initialized
INFO - 2016-05-18 19:10:33 --> Language Class Initialized
INFO - 2016-05-18 19:10:33 --> Loader Class Initialized
INFO - 2016-05-18 19:10:33 --> Helper loaded: url_helper
INFO - 2016-05-18 19:10:33 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:10:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:10:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:10:33 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:10:33 --> Helper loaded: form_helper
INFO - 2016-05-18 19:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:10:33 --> Form Validation Class Initialized
INFO - 2016-05-18 19:10:33 --> Controller Class Initialized
INFO - 2016-05-18 19:10:33 --> Model Class Initialized
INFO - 2016-05-18 19:10:33 --> Database Driver Class Initialized
INFO - 2016-05-18 19:10:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:10:33 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:10:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:10:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:10:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:10:33 --> Final output sent to browser
DEBUG - 2016-05-18 19:10:33 --> Total execution time: 0.0845
INFO - 2016-05-18 19:10:33 --> Config Class Initialized
INFO - 2016-05-18 19:10:33 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:10:33 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:10:33 --> Utf8 Class Initialized
INFO - 2016-05-18 19:10:33 --> URI Class Initialized
INFO - 2016-05-18 19:10:33 --> Router Class Initialized
INFO - 2016-05-18 19:10:33 --> Output Class Initialized
INFO - 2016-05-18 19:10:33 --> Security Class Initialized
DEBUG - 2016-05-18 19:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:10:33 --> Input Class Initialized
INFO - 2016-05-18 19:10:33 --> Language Class Initialized
INFO - 2016-05-18 19:10:33 --> Loader Class Initialized
INFO - 2016-05-18 19:10:33 --> Helper loaded: url_helper
INFO - 2016-05-18 19:10:33 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:10:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:10:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:10:33 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:10:33 --> Helper loaded: form_helper
INFO - 2016-05-18 19:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:10:33 --> Form Validation Class Initialized
INFO - 2016-05-18 19:10:33 --> Controller Class Initialized
INFO - 2016-05-18 19:10:33 --> Model Class Initialized
INFO - 2016-05-18 19:10:33 --> Database Driver Class Initialized
INFO - 2016-05-18 19:10:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:10:33 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:10:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:10:33 --> Final output sent to browser
DEBUG - 2016-05-18 19:10:33 --> Total execution time: 0.1053
INFO - 2016-05-18 19:10:46 --> Config Class Initialized
INFO - 2016-05-18 19:10:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:10:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:10:46 --> Utf8 Class Initialized
INFO - 2016-05-18 19:10:46 --> URI Class Initialized
INFO - 2016-05-18 19:10:46 --> Router Class Initialized
INFO - 2016-05-18 19:10:46 --> Output Class Initialized
INFO - 2016-05-18 19:10:46 --> Security Class Initialized
DEBUG - 2016-05-18 19:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:10:46 --> Input Class Initialized
INFO - 2016-05-18 19:10:46 --> Language Class Initialized
INFO - 2016-05-18 19:10:46 --> Loader Class Initialized
INFO - 2016-05-18 19:10:46 --> Helper loaded: url_helper
INFO - 2016-05-18 19:10:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:10:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:10:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:10:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:10:46 --> Helper loaded: form_helper
INFO - 2016-05-18 19:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:10:46 --> Form Validation Class Initialized
INFO - 2016-05-18 19:10:46 --> Controller Class Initialized
INFO - 2016-05-18 19:10:46 --> Model Class Initialized
INFO - 2016-05-18 19:10:46 --> Database Driver Class Initialized
INFO - 2016-05-18 19:10:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:10:46 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:10:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:10:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:10:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:10:46 --> Final output sent to browser
DEBUG - 2016-05-18 19:10:46 --> Total execution time: 0.0841
INFO - 2016-05-18 19:10:47 --> Config Class Initialized
INFO - 2016-05-18 19:10:47 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:10:47 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:10:47 --> Utf8 Class Initialized
INFO - 2016-05-18 19:10:47 --> URI Class Initialized
INFO - 2016-05-18 19:10:47 --> Router Class Initialized
INFO - 2016-05-18 19:10:47 --> Output Class Initialized
INFO - 2016-05-18 19:10:47 --> Security Class Initialized
DEBUG - 2016-05-18 19:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:10:47 --> Input Class Initialized
INFO - 2016-05-18 19:10:47 --> Language Class Initialized
INFO - 2016-05-18 19:10:47 --> Loader Class Initialized
INFO - 2016-05-18 19:10:47 --> Helper loaded: url_helper
INFO - 2016-05-18 19:10:47 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:10:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:10:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:10:47 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:10:47 --> Helper loaded: form_helper
INFO - 2016-05-18 19:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:10:47 --> Form Validation Class Initialized
INFO - 2016-05-18 19:10:47 --> Controller Class Initialized
INFO - 2016-05-18 19:10:47 --> Model Class Initialized
INFO - 2016-05-18 19:10:47 --> Database Driver Class Initialized
INFO - 2016-05-18 19:10:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:10:47 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:10:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:10:47 --> Final output sent to browser
DEBUG - 2016-05-18 19:10:47 --> Total execution time: 0.1025
INFO - 2016-05-18 19:10:58 --> Config Class Initialized
INFO - 2016-05-18 19:10:58 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:10:58 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:10:58 --> Utf8 Class Initialized
INFO - 2016-05-18 19:10:58 --> URI Class Initialized
INFO - 2016-05-18 19:10:58 --> Router Class Initialized
INFO - 2016-05-18 19:10:58 --> Output Class Initialized
INFO - 2016-05-18 19:10:58 --> Security Class Initialized
DEBUG - 2016-05-18 19:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:10:58 --> Input Class Initialized
INFO - 2016-05-18 19:10:58 --> Language Class Initialized
INFO - 2016-05-18 19:10:58 --> Loader Class Initialized
INFO - 2016-05-18 19:10:58 --> Helper loaded: url_helper
INFO - 2016-05-18 19:10:58 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:10:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:10:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:10:58 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:10:58 --> Helper loaded: form_helper
INFO - 2016-05-18 19:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:10:58 --> Form Validation Class Initialized
INFO - 2016-05-18 19:10:58 --> Controller Class Initialized
INFO - 2016-05-18 19:10:58 --> Model Class Initialized
INFO - 2016-05-18 19:10:58 --> Database Driver Class Initialized
INFO - 2016-05-18 19:10:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:10:58 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:10:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:10:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:10:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:10:58 --> Final output sent to browser
DEBUG - 2016-05-18 19:10:58 --> Total execution time: 0.0880
INFO - 2016-05-18 19:10:59 --> Config Class Initialized
INFO - 2016-05-18 19:10:59 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:10:59 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:10:59 --> Utf8 Class Initialized
INFO - 2016-05-18 19:10:59 --> URI Class Initialized
INFO - 2016-05-18 19:10:59 --> Router Class Initialized
INFO - 2016-05-18 19:10:59 --> Output Class Initialized
INFO - 2016-05-18 19:10:59 --> Security Class Initialized
DEBUG - 2016-05-18 19:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:10:59 --> Input Class Initialized
INFO - 2016-05-18 19:10:59 --> Language Class Initialized
INFO - 2016-05-18 19:10:59 --> Loader Class Initialized
INFO - 2016-05-18 19:10:59 --> Helper loaded: url_helper
INFO - 2016-05-18 19:10:59 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:10:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:10:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:10:59 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:10:59 --> Helper loaded: form_helper
INFO - 2016-05-18 19:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:10:59 --> Form Validation Class Initialized
INFO - 2016-05-18 19:10:59 --> Controller Class Initialized
INFO - 2016-05-18 19:10:59 --> Model Class Initialized
INFO - 2016-05-18 19:10:59 --> Database Driver Class Initialized
INFO - 2016-05-18 19:10:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:10:59 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:10:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:10:59 --> Final output sent to browser
DEBUG - 2016-05-18 19:10:59 --> Total execution time: 0.1150
INFO - 2016-05-18 19:11:36 --> Config Class Initialized
INFO - 2016-05-18 19:11:36 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:11:36 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:11:36 --> Utf8 Class Initialized
INFO - 2016-05-18 19:11:36 --> URI Class Initialized
INFO - 2016-05-18 19:11:36 --> Router Class Initialized
INFO - 2016-05-18 19:11:36 --> Output Class Initialized
INFO - 2016-05-18 19:11:36 --> Security Class Initialized
DEBUG - 2016-05-18 19:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:11:36 --> Input Class Initialized
INFO - 2016-05-18 19:11:36 --> Language Class Initialized
INFO - 2016-05-18 19:11:36 --> Loader Class Initialized
INFO - 2016-05-18 19:11:36 --> Helper loaded: url_helper
INFO - 2016-05-18 19:11:36 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:11:36 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:11:36 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:11:36 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:11:36 --> Helper loaded: form_helper
INFO - 2016-05-18 19:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:11:36 --> Form Validation Class Initialized
INFO - 2016-05-18 19:11:36 --> Controller Class Initialized
INFO - 2016-05-18 19:11:36 --> Model Class Initialized
INFO - 2016-05-18 19:11:36 --> Database Driver Class Initialized
INFO - 2016-05-18 19:11:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:11:36 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:11:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:11:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:11:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:11:36 --> Final output sent to browser
DEBUG - 2016-05-18 19:11:36 --> Total execution time: 0.0782
INFO - 2016-05-18 19:11:37 --> Config Class Initialized
INFO - 2016-05-18 19:11:37 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:11:37 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:11:37 --> Utf8 Class Initialized
INFO - 2016-05-18 19:11:37 --> URI Class Initialized
INFO - 2016-05-18 19:11:37 --> Router Class Initialized
INFO - 2016-05-18 19:11:37 --> Output Class Initialized
INFO - 2016-05-18 19:11:37 --> Security Class Initialized
DEBUG - 2016-05-18 19:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:11:37 --> Input Class Initialized
INFO - 2016-05-18 19:11:37 --> Language Class Initialized
INFO - 2016-05-18 19:11:37 --> Loader Class Initialized
INFO - 2016-05-18 19:11:37 --> Helper loaded: url_helper
INFO - 2016-05-18 19:11:37 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:11:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:11:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:11:37 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:11:37 --> Helper loaded: form_helper
INFO - 2016-05-18 19:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:11:37 --> Form Validation Class Initialized
INFO - 2016-05-18 19:11:37 --> Controller Class Initialized
INFO - 2016-05-18 19:11:37 --> Model Class Initialized
INFO - 2016-05-18 19:11:37 --> Database Driver Class Initialized
INFO - 2016-05-18 19:11:37 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:11:37 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:11:37 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:11:37 --> Final output sent to browser
DEBUG - 2016-05-18 19:11:37 --> Total execution time: 0.1492
INFO - 2016-05-18 19:12:02 --> Config Class Initialized
INFO - 2016-05-18 19:12:02 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:12:02 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:12:02 --> Utf8 Class Initialized
INFO - 2016-05-18 19:12:02 --> URI Class Initialized
INFO - 2016-05-18 19:12:02 --> Router Class Initialized
INFO - 2016-05-18 19:12:02 --> Output Class Initialized
INFO - 2016-05-18 19:12:02 --> Security Class Initialized
DEBUG - 2016-05-18 19:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:12:02 --> Input Class Initialized
INFO - 2016-05-18 19:12:02 --> Language Class Initialized
INFO - 2016-05-18 19:12:02 --> Loader Class Initialized
INFO - 2016-05-18 19:12:02 --> Helper loaded: url_helper
INFO - 2016-05-18 19:12:02 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:12:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:12:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:12:02 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:12:02 --> Helper loaded: form_helper
INFO - 2016-05-18 19:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:12:02 --> Form Validation Class Initialized
INFO - 2016-05-18 19:12:02 --> Controller Class Initialized
INFO - 2016-05-18 19:12:02 --> Model Class Initialized
INFO - 2016-05-18 19:12:02 --> Database Driver Class Initialized
INFO - 2016-05-18 19:12:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:12:02 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:12:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:12:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:12:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:12:02 --> Final output sent to browser
DEBUG - 2016-05-18 19:12:02 --> Total execution time: 0.0856
INFO - 2016-05-18 19:12:02 --> Config Class Initialized
INFO - 2016-05-18 19:12:02 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:12:02 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:12:02 --> Utf8 Class Initialized
INFO - 2016-05-18 19:12:02 --> URI Class Initialized
INFO - 2016-05-18 19:12:02 --> Router Class Initialized
INFO - 2016-05-18 19:12:02 --> Output Class Initialized
INFO - 2016-05-18 19:12:02 --> Security Class Initialized
DEBUG - 2016-05-18 19:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:12:02 --> Input Class Initialized
INFO - 2016-05-18 19:12:02 --> Language Class Initialized
INFO - 2016-05-18 19:12:03 --> Loader Class Initialized
INFO - 2016-05-18 19:12:03 --> Helper loaded: url_helper
INFO - 2016-05-18 19:12:03 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:12:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:12:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:12:03 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:12:03 --> Helper loaded: form_helper
INFO - 2016-05-18 19:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:12:03 --> Form Validation Class Initialized
INFO - 2016-05-18 19:12:03 --> Controller Class Initialized
INFO - 2016-05-18 19:12:03 --> Model Class Initialized
INFO - 2016-05-18 19:12:03 --> Database Driver Class Initialized
INFO - 2016-05-18 19:12:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:12:03 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:12:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:12:03 --> Final output sent to browser
DEBUG - 2016-05-18 19:12:03 --> Total execution time: 0.1301
INFO - 2016-05-18 19:12:57 --> Config Class Initialized
INFO - 2016-05-18 19:12:57 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:12:57 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:12:57 --> Utf8 Class Initialized
INFO - 2016-05-18 19:12:57 --> URI Class Initialized
INFO - 2016-05-18 19:12:57 --> Router Class Initialized
INFO - 2016-05-18 19:12:57 --> Output Class Initialized
INFO - 2016-05-18 19:12:57 --> Security Class Initialized
DEBUG - 2016-05-18 19:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:12:57 --> Input Class Initialized
INFO - 2016-05-18 19:12:57 --> Language Class Initialized
INFO - 2016-05-18 19:12:58 --> Loader Class Initialized
INFO - 2016-05-18 19:12:58 --> Helper loaded: url_helper
INFO - 2016-05-18 19:12:58 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:12:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:12:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:12:58 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:12:58 --> Helper loaded: form_helper
INFO - 2016-05-18 19:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:12:58 --> Form Validation Class Initialized
INFO - 2016-05-18 19:12:58 --> Controller Class Initialized
INFO - 2016-05-18 19:12:58 --> Model Class Initialized
INFO - 2016-05-18 19:12:58 --> Database Driver Class Initialized
INFO - 2016-05-18 19:12:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:12:58 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:12:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:12:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:12:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:12:58 --> Final output sent to browser
DEBUG - 2016-05-18 19:12:58 --> Total execution time: 0.0887
INFO - 2016-05-18 19:12:58 --> Config Class Initialized
INFO - 2016-05-18 19:12:58 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:12:58 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:12:58 --> Utf8 Class Initialized
INFO - 2016-05-18 19:12:58 --> URI Class Initialized
INFO - 2016-05-18 19:12:58 --> Router Class Initialized
INFO - 2016-05-18 19:12:58 --> Output Class Initialized
INFO - 2016-05-18 19:12:58 --> Security Class Initialized
DEBUG - 2016-05-18 19:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:12:58 --> Input Class Initialized
INFO - 2016-05-18 19:12:58 --> Language Class Initialized
INFO - 2016-05-18 19:12:58 --> Loader Class Initialized
INFO - 2016-05-18 19:12:58 --> Helper loaded: url_helper
INFO - 2016-05-18 19:12:58 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:12:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:12:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:12:58 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:12:58 --> Helper loaded: form_helper
INFO - 2016-05-18 19:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:12:58 --> Form Validation Class Initialized
INFO - 2016-05-18 19:12:58 --> Controller Class Initialized
INFO - 2016-05-18 19:12:58 --> Model Class Initialized
INFO - 2016-05-18 19:12:58 --> Database Driver Class Initialized
INFO - 2016-05-18 19:12:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:12:58 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:12:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:12:58 --> Final output sent to browser
DEBUG - 2016-05-18 19:12:58 --> Total execution time: 0.1479
INFO - 2016-05-18 19:13:16 --> Config Class Initialized
INFO - 2016-05-18 19:13:16 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:13:16 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:13:16 --> Utf8 Class Initialized
INFO - 2016-05-18 19:13:16 --> URI Class Initialized
INFO - 2016-05-18 19:13:16 --> Router Class Initialized
INFO - 2016-05-18 19:13:16 --> Output Class Initialized
INFO - 2016-05-18 19:13:16 --> Security Class Initialized
DEBUG - 2016-05-18 19:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:13:16 --> Input Class Initialized
INFO - 2016-05-18 19:13:16 --> Language Class Initialized
INFO - 2016-05-18 19:13:16 --> Loader Class Initialized
INFO - 2016-05-18 19:13:16 --> Helper loaded: url_helper
INFO - 2016-05-18 19:13:16 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:13:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:13:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:13:16 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:13:16 --> Helper loaded: form_helper
INFO - 2016-05-18 19:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:13:16 --> Form Validation Class Initialized
INFO - 2016-05-18 19:13:16 --> Controller Class Initialized
INFO - 2016-05-18 19:13:16 --> Model Class Initialized
INFO - 2016-05-18 19:13:16 --> Database Driver Class Initialized
INFO - 2016-05-18 19:13:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:13:16 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:13:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:13:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:13:16 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:13:16 --> Final output sent to browser
DEBUG - 2016-05-18 19:13:16 --> Total execution time: 0.0782
INFO - 2016-05-18 19:13:17 --> Config Class Initialized
INFO - 2016-05-18 19:13:17 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:13:17 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:13:17 --> Utf8 Class Initialized
INFO - 2016-05-18 19:13:17 --> URI Class Initialized
INFO - 2016-05-18 19:13:17 --> Router Class Initialized
INFO - 2016-05-18 19:13:17 --> Output Class Initialized
INFO - 2016-05-18 19:13:17 --> Security Class Initialized
DEBUG - 2016-05-18 19:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:13:17 --> Input Class Initialized
INFO - 2016-05-18 19:13:17 --> Language Class Initialized
INFO - 2016-05-18 19:13:17 --> Loader Class Initialized
INFO - 2016-05-18 19:13:17 --> Helper loaded: url_helper
INFO - 2016-05-18 19:13:17 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:13:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:13:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:13:17 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:13:17 --> Helper loaded: form_helper
INFO - 2016-05-18 19:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:13:17 --> Form Validation Class Initialized
INFO - 2016-05-18 19:13:17 --> Controller Class Initialized
INFO - 2016-05-18 19:13:17 --> Model Class Initialized
INFO - 2016-05-18 19:13:17 --> Database Driver Class Initialized
INFO - 2016-05-18 19:13:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:13:17 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:13:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:13:17 --> Final output sent to browser
DEBUG - 2016-05-18 19:13:17 --> Total execution time: 0.1308
INFO - 2016-05-18 19:13:26 --> Config Class Initialized
INFO - 2016-05-18 19:13:26 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:13:26 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:13:26 --> Utf8 Class Initialized
INFO - 2016-05-18 19:13:26 --> URI Class Initialized
INFO - 2016-05-18 19:13:26 --> Router Class Initialized
INFO - 2016-05-18 19:13:26 --> Output Class Initialized
INFO - 2016-05-18 19:13:26 --> Security Class Initialized
DEBUG - 2016-05-18 19:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:13:26 --> Input Class Initialized
INFO - 2016-05-18 19:13:26 --> Language Class Initialized
INFO - 2016-05-18 19:13:26 --> Loader Class Initialized
INFO - 2016-05-18 19:13:26 --> Helper loaded: url_helper
INFO - 2016-05-18 19:13:26 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:13:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:13:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:13:26 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:13:26 --> Helper loaded: form_helper
INFO - 2016-05-18 19:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:13:26 --> Form Validation Class Initialized
INFO - 2016-05-18 19:13:26 --> Controller Class Initialized
INFO - 2016-05-18 19:13:26 --> Model Class Initialized
INFO - 2016-05-18 19:13:26 --> Database Driver Class Initialized
INFO - 2016-05-18 19:13:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:13:26 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:13:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:13:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:13:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:13:26 --> Final output sent to browser
DEBUG - 2016-05-18 19:13:26 --> Total execution time: 0.0977
INFO - 2016-05-18 19:13:27 --> Config Class Initialized
INFO - 2016-05-18 19:13:27 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:13:27 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:13:27 --> Utf8 Class Initialized
INFO - 2016-05-18 19:13:27 --> URI Class Initialized
INFO - 2016-05-18 19:13:27 --> Router Class Initialized
INFO - 2016-05-18 19:13:27 --> Output Class Initialized
INFO - 2016-05-18 19:13:27 --> Security Class Initialized
DEBUG - 2016-05-18 19:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:13:27 --> Input Class Initialized
INFO - 2016-05-18 19:13:27 --> Language Class Initialized
INFO - 2016-05-18 19:13:27 --> Loader Class Initialized
INFO - 2016-05-18 19:13:27 --> Helper loaded: url_helper
INFO - 2016-05-18 19:13:27 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:13:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:13:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:13:27 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:13:27 --> Helper loaded: form_helper
INFO - 2016-05-18 19:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:13:27 --> Form Validation Class Initialized
INFO - 2016-05-18 19:13:27 --> Controller Class Initialized
INFO - 2016-05-18 19:13:27 --> Model Class Initialized
INFO - 2016-05-18 19:13:27 --> Database Driver Class Initialized
INFO - 2016-05-18 19:13:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:13:27 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:13:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:13:27 --> Final output sent to browser
DEBUG - 2016-05-18 19:13:27 --> Total execution time: 0.1426
INFO - 2016-05-18 19:13:45 --> Config Class Initialized
INFO - 2016-05-18 19:13:45 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:13:45 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:13:45 --> Utf8 Class Initialized
INFO - 2016-05-18 19:13:45 --> URI Class Initialized
INFO - 2016-05-18 19:13:45 --> Router Class Initialized
INFO - 2016-05-18 19:13:45 --> Output Class Initialized
INFO - 2016-05-18 19:13:45 --> Security Class Initialized
DEBUG - 2016-05-18 19:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:13:45 --> Input Class Initialized
INFO - 2016-05-18 19:13:45 --> Language Class Initialized
INFO - 2016-05-18 19:13:45 --> Loader Class Initialized
INFO - 2016-05-18 19:13:45 --> Helper loaded: url_helper
INFO - 2016-05-18 19:13:45 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:13:45 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:13:45 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:13:45 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:13:45 --> Helper loaded: form_helper
INFO - 2016-05-18 19:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:13:45 --> Form Validation Class Initialized
INFO - 2016-05-18 19:13:45 --> Controller Class Initialized
INFO - 2016-05-18 19:13:45 --> Model Class Initialized
INFO - 2016-05-18 19:13:45 --> Database Driver Class Initialized
INFO - 2016-05-18 19:13:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:13:45 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:13:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:13:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:13:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:13:45 --> Final output sent to browser
DEBUG - 2016-05-18 19:13:45 --> Total execution time: 0.0874
INFO - 2016-05-18 19:13:46 --> Config Class Initialized
INFO - 2016-05-18 19:13:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:13:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:13:46 --> Utf8 Class Initialized
INFO - 2016-05-18 19:13:46 --> URI Class Initialized
INFO - 2016-05-18 19:13:46 --> Router Class Initialized
INFO - 2016-05-18 19:13:46 --> Output Class Initialized
INFO - 2016-05-18 19:13:46 --> Security Class Initialized
DEBUG - 2016-05-18 19:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:13:46 --> Input Class Initialized
INFO - 2016-05-18 19:13:46 --> Language Class Initialized
INFO - 2016-05-18 19:13:46 --> Loader Class Initialized
INFO - 2016-05-18 19:13:46 --> Helper loaded: url_helper
INFO - 2016-05-18 19:13:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:13:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:13:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:13:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:13:46 --> Helper loaded: form_helper
INFO - 2016-05-18 19:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:13:46 --> Form Validation Class Initialized
INFO - 2016-05-18 19:13:46 --> Controller Class Initialized
INFO - 2016-05-18 19:13:46 --> Model Class Initialized
INFO - 2016-05-18 19:13:46 --> Database Driver Class Initialized
INFO - 2016-05-18 19:13:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:13:46 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:13:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:13:46 --> Final output sent to browser
DEBUG - 2016-05-18 19:13:46 --> Total execution time: 0.1432
INFO - 2016-05-18 19:14:46 --> Config Class Initialized
INFO - 2016-05-18 19:14:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:14:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:14:46 --> Utf8 Class Initialized
INFO - 2016-05-18 19:14:46 --> URI Class Initialized
INFO - 2016-05-18 19:14:46 --> Router Class Initialized
INFO - 2016-05-18 19:14:46 --> Output Class Initialized
INFO - 2016-05-18 19:14:46 --> Security Class Initialized
DEBUG - 2016-05-18 19:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:14:46 --> Input Class Initialized
INFO - 2016-05-18 19:14:46 --> Language Class Initialized
INFO - 2016-05-18 19:14:46 --> Loader Class Initialized
INFO - 2016-05-18 19:14:46 --> Helper loaded: url_helper
INFO - 2016-05-18 19:14:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:14:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:14:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:14:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:14:46 --> Helper loaded: form_helper
INFO - 2016-05-18 19:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:14:46 --> Form Validation Class Initialized
INFO - 2016-05-18 19:14:46 --> Controller Class Initialized
INFO - 2016-05-18 19:14:46 --> Model Class Initialized
INFO - 2016-05-18 19:14:46 --> Database Driver Class Initialized
INFO - 2016-05-18 19:14:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:14:46 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:14:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:14:46 --> Final output sent to browser
DEBUG - 2016-05-18 19:14:46 --> Total execution time: 0.0752
INFO - 2016-05-18 19:15:46 --> Config Class Initialized
INFO - 2016-05-18 19:15:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:15:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:15:46 --> Utf8 Class Initialized
INFO - 2016-05-18 19:15:46 --> URI Class Initialized
INFO - 2016-05-18 19:15:46 --> Router Class Initialized
INFO - 2016-05-18 19:15:46 --> Output Class Initialized
INFO - 2016-05-18 19:15:46 --> Security Class Initialized
DEBUG - 2016-05-18 19:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:15:46 --> Input Class Initialized
INFO - 2016-05-18 19:15:46 --> Language Class Initialized
INFO - 2016-05-18 19:15:46 --> Loader Class Initialized
INFO - 2016-05-18 19:15:46 --> Helper loaded: url_helper
INFO - 2016-05-18 19:15:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:15:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:15:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:15:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:15:46 --> Helper loaded: form_helper
INFO - 2016-05-18 19:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:15:46 --> Form Validation Class Initialized
INFO - 2016-05-18 19:15:46 --> Controller Class Initialized
INFO - 2016-05-18 19:15:46 --> Model Class Initialized
INFO - 2016-05-18 19:15:46 --> Database Driver Class Initialized
INFO - 2016-05-18 19:15:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:15:46 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:15:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:15:46 --> Final output sent to browser
DEBUG - 2016-05-18 19:15:46 --> Total execution time: 0.0759
INFO - 2016-05-18 19:16:46 --> Config Class Initialized
INFO - 2016-05-18 19:16:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:16:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:16:46 --> Utf8 Class Initialized
INFO - 2016-05-18 19:16:46 --> URI Class Initialized
INFO - 2016-05-18 19:16:46 --> Router Class Initialized
INFO - 2016-05-18 19:16:46 --> Output Class Initialized
INFO - 2016-05-18 19:16:46 --> Security Class Initialized
DEBUG - 2016-05-18 19:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:16:46 --> Input Class Initialized
INFO - 2016-05-18 19:16:46 --> Language Class Initialized
INFO - 2016-05-18 19:16:46 --> Loader Class Initialized
INFO - 2016-05-18 19:16:46 --> Helper loaded: url_helper
INFO - 2016-05-18 19:16:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:16:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:16:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:16:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:16:46 --> Helper loaded: form_helper
INFO - 2016-05-18 19:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:16:46 --> Form Validation Class Initialized
INFO - 2016-05-18 19:16:46 --> Controller Class Initialized
INFO - 2016-05-18 19:16:46 --> Model Class Initialized
INFO - 2016-05-18 19:16:46 --> Database Driver Class Initialized
INFO - 2016-05-18 19:16:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:16:46 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:16:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:16:46 --> Final output sent to browser
DEBUG - 2016-05-18 19:16:46 --> Total execution time: 0.0848
INFO - 2016-05-18 19:17:46 --> Config Class Initialized
INFO - 2016-05-18 19:17:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:17:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:17:46 --> Utf8 Class Initialized
INFO - 2016-05-18 19:17:46 --> URI Class Initialized
INFO - 2016-05-18 19:17:46 --> Router Class Initialized
INFO - 2016-05-18 19:17:46 --> Output Class Initialized
INFO - 2016-05-18 19:17:46 --> Security Class Initialized
DEBUG - 2016-05-18 19:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:17:46 --> Input Class Initialized
INFO - 2016-05-18 19:17:46 --> Language Class Initialized
INFO - 2016-05-18 19:17:46 --> Loader Class Initialized
INFO - 2016-05-18 19:17:46 --> Helper loaded: url_helper
INFO - 2016-05-18 19:17:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:17:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:17:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:17:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:17:46 --> Helper loaded: form_helper
INFO - 2016-05-18 19:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:17:46 --> Form Validation Class Initialized
INFO - 2016-05-18 19:17:46 --> Controller Class Initialized
INFO - 2016-05-18 19:17:46 --> Model Class Initialized
INFO - 2016-05-18 19:17:46 --> Database Driver Class Initialized
INFO - 2016-05-18 19:17:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:17:46 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:17:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:17:46 --> Final output sent to browser
DEBUG - 2016-05-18 19:17:46 --> Total execution time: 0.0708
INFO - 2016-05-18 19:18:46 --> Config Class Initialized
INFO - 2016-05-18 19:18:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:18:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:18:46 --> Utf8 Class Initialized
INFO - 2016-05-18 19:18:46 --> URI Class Initialized
INFO - 2016-05-18 19:18:46 --> Router Class Initialized
INFO - 2016-05-18 19:18:46 --> Output Class Initialized
INFO - 2016-05-18 19:18:46 --> Security Class Initialized
DEBUG - 2016-05-18 19:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:18:46 --> Input Class Initialized
INFO - 2016-05-18 19:18:46 --> Language Class Initialized
INFO - 2016-05-18 19:18:46 --> Loader Class Initialized
INFO - 2016-05-18 19:18:46 --> Helper loaded: url_helper
INFO - 2016-05-18 19:18:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:18:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:18:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:18:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:18:46 --> Helper loaded: form_helper
INFO - 2016-05-18 19:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:18:46 --> Form Validation Class Initialized
INFO - 2016-05-18 19:18:46 --> Controller Class Initialized
INFO - 2016-05-18 19:18:46 --> Model Class Initialized
INFO - 2016-05-18 19:18:46 --> Database Driver Class Initialized
INFO - 2016-05-18 19:18:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:18:46 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:18:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:18:46 --> Final output sent to browser
DEBUG - 2016-05-18 19:18:46 --> Total execution time: 0.0737
INFO - 2016-05-18 19:19:46 --> Config Class Initialized
INFO - 2016-05-18 19:19:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:19:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:19:46 --> Utf8 Class Initialized
INFO - 2016-05-18 19:19:46 --> URI Class Initialized
INFO - 2016-05-18 19:19:46 --> Router Class Initialized
INFO - 2016-05-18 19:19:46 --> Output Class Initialized
INFO - 2016-05-18 19:19:46 --> Security Class Initialized
DEBUG - 2016-05-18 19:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:19:46 --> Input Class Initialized
INFO - 2016-05-18 19:19:46 --> Language Class Initialized
INFO - 2016-05-18 19:19:46 --> Loader Class Initialized
INFO - 2016-05-18 19:19:46 --> Helper loaded: url_helper
INFO - 2016-05-18 19:19:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:19:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:19:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:19:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:19:46 --> Helper loaded: form_helper
INFO - 2016-05-18 19:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:19:46 --> Form Validation Class Initialized
INFO - 2016-05-18 19:19:46 --> Controller Class Initialized
INFO - 2016-05-18 19:19:46 --> Model Class Initialized
INFO - 2016-05-18 19:19:46 --> Database Driver Class Initialized
INFO - 2016-05-18 19:19:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:19:46 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:19:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:19:46 --> Final output sent to browser
DEBUG - 2016-05-18 19:19:46 --> Total execution time: 0.0718
INFO - 2016-05-18 19:20:46 --> Config Class Initialized
INFO - 2016-05-18 19:20:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:20:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:20:46 --> Utf8 Class Initialized
INFO - 2016-05-18 19:20:46 --> URI Class Initialized
INFO - 2016-05-18 19:20:46 --> Router Class Initialized
INFO - 2016-05-18 19:20:46 --> Output Class Initialized
INFO - 2016-05-18 19:20:46 --> Security Class Initialized
DEBUG - 2016-05-18 19:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:20:46 --> Input Class Initialized
INFO - 2016-05-18 19:20:46 --> Language Class Initialized
INFO - 2016-05-18 19:20:46 --> Loader Class Initialized
INFO - 2016-05-18 19:20:46 --> Helper loaded: url_helper
INFO - 2016-05-18 19:20:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:20:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:20:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:20:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:20:46 --> Helper loaded: form_helper
INFO - 2016-05-18 19:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:20:46 --> Form Validation Class Initialized
INFO - 2016-05-18 19:20:46 --> Controller Class Initialized
INFO - 2016-05-18 19:20:46 --> Model Class Initialized
INFO - 2016-05-18 19:20:46 --> Database Driver Class Initialized
INFO - 2016-05-18 19:20:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:20:46 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:20:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:20:46 --> Final output sent to browser
DEBUG - 2016-05-18 19:20:46 --> Total execution time: 0.0739
INFO - 2016-05-18 19:21:41 --> Config Class Initialized
INFO - 2016-05-18 19:21:41 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:21:41 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:21:41 --> Utf8 Class Initialized
INFO - 2016-05-18 19:21:41 --> URI Class Initialized
INFO - 2016-05-18 19:21:41 --> Router Class Initialized
INFO - 2016-05-18 19:21:41 --> Output Class Initialized
INFO - 2016-05-18 19:21:41 --> Security Class Initialized
DEBUG - 2016-05-18 19:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:21:41 --> Input Class Initialized
INFO - 2016-05-18 19:21:41 --> Language Class Initialized
INFO - 2016-05-18 19:21:41 --> Loader Class Initialized
INFO - 2016-05-18 19:21:41 --> Helper loaded: url_helper
INFO - 2016-05-18 19:21:41 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:21:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:21:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:21:41 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:21:41 --> Helper loaded: form_helper
INFO - 2016-05-18 19:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:21:41 --> Form Validation Class Initialized
INFO - 2016-05-18 19:21:41 --> Controller Class Initialized
INFO - 2016-05-18 19:21:41 --> Model Class Initialized
INFO - 2016-05-18 19:21:41 --> Database Driver Class Initialized
INFO - 2016-05-18 19:21:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:21:41 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:21:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:21:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:21:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:21:41 --> Final output sent to browser
DEBUG - 2016-05-18 19:21:41 --> Total execution time: 0.0802
INFO - 2016-05-18 19:21:42 --> Config Class Initialized
INFO - 2016-05-18 19:21:42 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:21:42 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:21:42 --> Utf8 Class Initialized
INFO - 2016-05-18 19:21:42 --> URI Class Initialized
INFO - 2016-05-18 19:21:42 --> Router Class Initialized
INFO - 2016-05-18 19:21:42 --> Output Class Initialized
INFO - 2016-05-18 19:21:42 --> Security Class Initialized
DEBUG - 2016-05-18 19:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:21:42 --> Input Class Initialized
INFO - 2016-05-18 19:21:42 --> Language Class Initialized
INFO - 2016-05-18 19:21:42 --> Loader Class Initialized
INFO - 2016-05-18 19:21:42 --> Helper loaded: url_helper
INFO - 2016-05-18 19:21:42 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:21:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:21:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:21:42 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:21:42 --> Helper loaded: form_helper
INFO - 2016-05-18 19:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:21:42 --> Form Validation Class Initialized
INFO - 2016-05-18 19:21:42 --> Controller Class Initialized
INFO - 2016-05-18 19:21:42 --> Model Class Initialized
INFO - 2016-05-18 19:21:42 --> Database Driver Class Initialized
INFO - 2016-05-18 19:21:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:21:42 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:21:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:21:42 --> Final output sent to browser
DEBUG - 2016-05-18 19:21:42 --> Total execution time: 0.1345
INFO - 2016-05-18 19:21:50 --> Config Class Initialized
INFO - 2016-05-18 19:21:50 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:21:50 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:21:50 --> Utf8 Class Initialized
INFO - 2016-05-18 19:21:50 --> URI Class Initialized
INFO - 2016-05-18 19:21:50 --> Router Class Initialized
INFO - 2016-05-18 19:21:50 --> Output Class Initialized
INFO - 2016-05-18 19:21:50 --> Security Class Initialized
DEBUG - 2016-05-18 19:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:21:50 --> Input Class Initialized
INFO - 2016-05-18 19:21:50 --> Language Class Initialized
INFO - 2016-05-18 19:21:50 --> Loader Class Initialized
INFO - 2016-05-18 19:21:50 --> Helper loaded: url_helper
INFO - 2016-05-18 19:21:50 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:21:50 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:21:50 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:21:50 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:21:50 --> Helper loaded: form_helper
INFO - 2016-05-18 19:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:21:50 --> Form Validation Class Initialized
INFO - 2016-05-18 19:21:50 --> Controller Class Initialized
INFO - 2016-05-18 19:21:50 --> Model Class Initialized
INFO - 2016-05-18 19:21:50 --> Database Driver Class Initialized
INFO - 2016-05-18 19:21:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:21:50 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:21:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:21:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:21:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:21:50 --> Final output sent to browser
DEBUG - 2016-05-18 19:21:50 --> Total execution time: 0.1148
INFO - 2016-05-18 19:21:51 --> Config Class Initialized
INFO - 2016-05-18 19:21:51 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:21:51 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:21:51 --> Utf8 Class Initialized
INFO - 2016-05-18 19:21:51 --> URI Class Initialized
INFO - 2016-05-18 19:21:51 --> Router Class Initialized
INFO - 2016-05-18 19:21:51 --> Output Class Initialized
INFO - 2016-05-18 19:21:51 --> Security Class Initialized
DEBUG - 2016-05-18 19:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:21:51 --> Input Class Initialized
INFO - 2016-05-18 19:21:51 --> Language Class Initialized
INFO - 2016-05-18 19:21:51 --> Loader Class Initialized
INFO - 2016-05-18 19:21:51 --> Helper loaded: url_helper
INFO - 2016-05-18 19:21:51 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:21:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:21:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:21:51 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:21:51 --> Helper loaded: form_helper
INFO - 2016-05-18 19:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:21:51 --> Form Validation Class Initialized
INFO - 2016-05-18 19:21:51 --> Controller Class Initialized
INFO - 2016-05-18 19:21:51 --> Model Class Initialized
INFO - 2016-05-18 19:21:51 --> Database Driver Class Initialized
INFO - 2016-05-18 19:21:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:21:51 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:21:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:21:51 --> Final output sent to browser
DEBUG - 2016-05-18 19:21:51 --> Total execution time: 0.1773
INFO - 2016-05-18 19:21:58 --> Config Class Initialized
INFO - 2016-05-18 19:21:58 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:21:58 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:21:58 --> Utf8 Class Initialized
INFO - 2016-05-18 19:21:58 --> URI Class Initialized
INFO - 2016-05-18 19:21:58 --> Router Class Initialized
INFO - 2016-05-18 19:21:58 --> Output Class Initialized
INFO - 2016-05-18 19:21:58 --> Security Class Initialized
DEBUG - 2016-05-18 19:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:21:58 --> Input Class Initialized
INFO - 2016-05-18 19:21:58 --> Language Class Initialized
INFO - 2016-05-18 19:21:58 --> Loader Class Initialized
INFO - 2016-05-18 19:21:58 --> Helper loaded: url_helper
INFO - 2016-05-18 19:21:58 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:21:58 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:21:58 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:21:58 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:21:58 --> Helper loaded: form_helper
INFO - 2016-05-18 19:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:21:58 --> Form Validation Class Initialized
INFO - 2016-05-18 19:21:58 --> Controller Class Initialized
INFO - 2016-05-18 19:21:58 --> Model Class Initialized
INFO - 2016-05-18 19:21:58 --> Database Driver Class Initialized
INFO - 2016-05-18 19:21:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:21:58 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:21:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:21:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:21:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:21:58 --> Final output sent to browser
DEBUG - 2016-05-18 19:21:58 --> Total execution time: 0.0849
INFO - 2016-05-18 19:21:59 --> Config Class Initialized
INFO - 2016-05-18 19:21:59 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:21:59 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:21:59 --> Utf8 Class Initialized
INFO - 2016-05-18 19:21:59 --> URI Class Initialized
INFO - 2016-05-18 19:21:59 --> Router Class Initialized
INFO - 2016-05-18 19:21:59 --> Output Class Initialized
INFO - 2016-05-18 19:21:59 --> Security Class Initialized
DEBUG - 2016-05-18 19:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:21:59 --> Input Class Initialized
INFO - 2016-05-18 19:21:59 --> Language Class Initialized
INFO - 2016-05-18 19:21:59 --> Loader Class Initialized
INFO - 2016-05-18 19:21:59 --> Helper loaded: url_helper
INFO - 2016-05-18 19:21:59 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:21:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:21:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:21:59 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:21:59 --> Helper loaded: form_helper
INFO - 2016-05-18 19:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:21:59 --> Form Validation Class Initialized
INFO - 2016-05-18 19:21:59 --> Controller Class Initialized
INFO - 2016-05-18 19:21:59 --> Model Class Initialized
INFO - 2016-05-18 19:21:59 --> Database Driver Class Initialized
INFO - 2016-05-18 19:21:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:21:59 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:21:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:21:59 --> Final output sent to browser
DEBUG - 2016-05-18 19:21:59 --> Total execution time: 0.2441
INFO - 2016-05-18 19:22:04 --> Config Class Initialized
INFO - 2016-05-18 19:22:04 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:22:04 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:22:04 --> Utf8 Class Initialized
INFO - 2016-05-18 19:22:04 --> URI Class Initialized
INFO - 2016-05-18 19:22:04 --> Router Class Initialized
INFO - 2016-05-18 19:22:04 --> Output Class Initialized
INFO - 2016-05-18 19:22:04 --> Security Class Initialized
DEBUG - 2016-05-18 19:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:22:04 --> Input Class Initialized
INFO - 2016-05-18 19:22:04 --> Language Class Initialized
INFO - 2016-05-18 19:22:04 --> Loader Class Initialized
INFO - 2016-05-18 19:22:04 --> Helper loaded: url_helper
INFO - 2016-05-18 19:22:04 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:22:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:22:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:22:04 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:22:04 --> Helper loaded: form_helper
INFO - 2016-05-18 19:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:22:04 --> Form Validation Class Initialized
INFO - 2016-05-18 19:22:04 --> Controller Class Initialized
INFO - 2016-05-18 19:22:04 --> Model Class Initialized
INFO - 2016-05-18 19:22:04 --> Database Driver Class Initialized
INFO - 2016-05-18 19:22:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:22:04 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:22:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:22:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:22:04 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:22:04 --> Final output sent to browser
DEBUG - 2016-05-18 19:22:04 --> Total execution time: 0.0902
INFO - 2016-05-18 19:22:05 --> Config Class Initialized
INFO - 2016-05-18 19:22:05 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:22:05 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:22:05 --> Utf8 Class Initialized
INFO - 2016-05-18 19:22:05 --> URI Class Initialized
INFO - 2016-05-18 19:22:05 --> Router Class Initialized
INFO - 2016-05-18 19:22:05 --> Output Class Initialized
INFO - 2016-05-18 19:22:05 --> Security Class Initialized
DEBUG - 2016-05-18 19:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:22:05 --> Input Class Initialized
INFO - 2016-05-18 19:22:05 --> Language Class Initialized
INFO - 2016-05-18 19:22:05 --> Loader Class Initialized
INFO - 2016-05-18 19:22:05 --> Helper loaded: url_helper
INFO - 2016-05-18 19:22:05 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:22:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:22:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:22:05 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:22:05 --> Helper loaded: form_helper
INFO - 2016-05-18 19:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:22:05 --> Form Validation Class Initialized
INFO - 2016-05-18 19:22:05 --> Controller Class Initialized
INFO - 2016-05-18 19:22:05 --> Model Class Initialized
INFO - 2016-05-18 19:22:05 --> Database Driver Class Initialized
INFO - 2016-05-18 19:22:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:22:05 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:22:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:22:05 --> Final output sent to browser
DEBUG - 2016-05-18 19:22:05 --> Total execution time: 0.1509
INFO - 2016-05-18 19:23:05 --> Config Class Initialized
INFO - 2016-05-18 19:23:05 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:23:05 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:23:05 --> Utf8 Class Initialized
INFO - 2016-05-18 19:23:05 --> URI Class Initialized
INFO - 2016-05-18 19:23:05 --> Router Class Initialized
INFO - 2016-05-18 19:23:05 --> Output Class Initialized
INFO - 2016-05-18 19:23:05 --> Security Class Initialized
DEBUG - 2016-05-18 19:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:23:05 --> Input Class Initialized
INFO - 2016-05-18 19:23:05 --> Language Class Initialized
INFO - 2016-05-18 19:23:05 --> Loader Class Initialized
INFO - 2016-05-18 19:23:05 --> Helper loaded: url_helper
INFO - 2016-05-18 19:23:05 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:23:05 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:23:05 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:23:05 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:23:05 --> Helper loaded: form_helper
INFO - 2016-05-18 19:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:23:05 --> Form Validation Class Initialized
INFO - 2016-05-18 19:23:05 --> Controller Class Initialized
INFO - 2016-05-18 19:23:05 --> Model Class Initialized
INFO - 2016-05-18 19:23:05 --> Database Driver Class Initialized
INFO - 2016-05-18 19:23:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:23:05 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:23:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:23:05 --> Final output sent to browser
DEBUG - 2016-05-18 19:23:05 --> Total execution time: 0.0758
INFO - 2016-05-18 19:23:29 --> Config Class Initialized
INFO - 2016-05-18 19:23:29 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:23:29 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:23:29 --> Utf8 Class Initialized
INFO - 2016-05-18 19:23:29 --> URI Class Initialized
INFO - 2016-05-18 19:23:29 --> Router Class Initialized
INFO - 2016-05-18 19:23:29 --> Output Class Initialized
INFO - 2016-05-18 19:23:29 --> Security Class Initialized
DEBUG - 2016-05-18 19:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:23:29 --> Input Class Initialized
INFO - 2016-05-18 19:23:29 --> Language Class Initialized
INFO - 2016-05-18 19:23:29 --> Loader Class Initialized
INFO - 2016-05-18 19:23:29 --> Helper loaded: url_helper
INFO - 2016-05-18 19:23:29 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:23:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:23:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:23:29 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:23:29 --> Helper loaded: form_helper
INFO - 2016-05-18 19:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:23:29 --> Form Validation Class Initialized
INFO - 2016-05-18 19:23:29 --> Controller Class Initialized
INFO - 2016-05-18 19:23:29 --> Model Class Initialized
INFO - 2016-05-18 19:23:29 --> Database Driver Class Initialized
INFO - 2016-05-18 19:23:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:23:29 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:23:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:23:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:23:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:23:29 --> Final output sent to browser
DEBUG - 2016-05-18 19:23:29 --> Total execution time: 0.0761
INFO - 2016-05-18 19:23:30 --> Config Class Initialized
INFO - 2016-05-18 19:23:30 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:23:30 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:23:30 --> Utf8 Class Initialized
INFO - 2016-05-18 19:23:30 --> URI Class Initialized
INFO - 2016-05-18 19:23:30 --> Router Class Initialized
INFO - 2016-05-18 19:23:30 --> Output Class Initialized
INFO - 2016-05-18 19:23:30 --> Security Class Initialized
DEBUG - 2016-05-18 19:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:23:30 --> Input Class Initialized
INFO - 2016-05-18 19:23:30 --> Language Class Initialized
INFO - 2016-05-18 19:23:30 --> Loader Class Initialized
INFO - 2016-05-18 19:23:30 --> Helper loaded: url_helper
INFO - 2016-05-18 19:23:30 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:23:30 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:23:30 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:23:30 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:23:30 --> Helper loaded: form_helper
INFO - 2016-05-18 19:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:23:30 --> Form Validation Class Initialized
INFO - 2016-05-18 19:23:30 --> Controller Class Initialized
INFO - 2016-05-18 19:23:30 --> Model Class Initialized
INFO - 2016-05-18 19:23:30 --> Database Driver Class Initialized
INFO - 2016-05-18 19:23:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:23:30 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:23:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:23:30 --> Final output sent to browser
DEBUG - 2016-05-18 19:23:30 --> Total execution time: 0.1357
INFO - 2016-05-18 19:23:43 --> Config Class Initialized
INFO - 2016-05-18 19:23:43 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:23:43 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:23:43 --> Utf8 Class Initialized
INFO - 2016-05-18 19:23:43 --> URI Class Initialized
INFO - 2016-05-18 19:23:43 --> Router Class Initialized
INFO - 2016-05-18 19:23:43 --> Output Class Initialized
INFO - 2016-05-18 19:23:43 --> Security Class Initialized
DEBUG - 2016-05-18 19:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:23:43 --> Input Class Initialized
INFO - 2016-05-18 19:23:43 --> Language Class Initialized
INFO - 2016-05-18 19:23:43 --> Loader Class Initialized
INFO - 2016-05-18 19:23:43 --> Helper loaded: url_helper
INFO - 2016-05-18 19:23:43 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:23:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:23:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:23:43 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:23:43 --> Helper loaded: form_helper
INFO - 2016-05-18 19:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:23:43 --> Form Validation Class Initialized
INFO - 2016-05-18 19:23:43 --> Controller Class Initialized
INFO - 2016-05-18 19:23:43 --> Model Class Initialized
INFO - 2016-05-18 19:23:43 --> Database Driver Class Initialized
INFO - 2016-05-18 19:23:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:23:43 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:23:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:23:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:23:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:23:43 --> Final output sent to browser
DEBUG - 2016-05-18 19:23:43 --> Total execution time: 0.0824
INFO - 2016-05-18 19:23:43 --> Config Class Initialized
INFO - 2016-05-18 19:23:43 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:23:43 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:23:43 --> Utf8 Class Initialized
INFO - 2016-05-18 19:23:43 --> URI Class Initialized
INFO - 2016-05-18 19:23:43 --> Router Class Initialized
INFO - 2016-05-18 19:23:43 --> Output Class Initialized
INFO - 2016-05-18 19:23:43 --> Security Class Initialized
DEBUG - 2016-05-18 19:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:23:43 --> Input Class Initialized
INFO - 2016-05-18 19:23:43 --> Language Class Initialized
INFO - 2016-05-18 19:23:43 --> Loader Class Initialized
INFO - 2016-05-18 19:23:43 --> Helper loaded: url_helper
INFO - 2016-05-18 19:23:43 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:23:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:23:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:23:43 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:23:43 --> Helper loaded: form_helper
INFO - 2016-05-18 19:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:23:44 --> Form Validation Class Initialized
INFO - 2016-05-18 19:23:44 --> Controller Class Initialized
INFO - 2016-05-18 19:23:44 --> Model Class Initialized
INFO - 2016-05-18 19:23:44 --> Database Driver Class Initialized
INFO - 2016-05-18 19:23:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:23:44 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:23:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:23:44 --> Final output sent to browser
DEBUG - 2016-05-18 19:23:44 --> Total execution time: 0.1525
INFO - 2016-05-18 19:24:21 --> Config Class Initialized
INFO - 2016-05-18 19:24:21 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:24:21 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:24:21 --> Utf8 Class Initialized
INFO - 2016-05-18 19:24:21 --> URI Class Initialized
INFO - 2016-05-18 19:24:21 --> Router Class Initialized
INFO - 2016-05-18 19:24:21 --> Output Class Initialized
INFO - 2016-05-18 19:24:21 --> Security Class Initialized
DEBUG - 2016-05-18 19:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:24:21 --> Input Class Initialized
INFO - 2016-05-18 19:24:21 --> Language Class Initialized
INFO - 2016-05-18 19:24:21 --> Loader Class Initialized
INFO - 2016-05-18 19:24:21 --> Helper loaded: url_helper
INFO - 2016-05-18 19:24:21 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:24:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:24:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:24:21 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:24:21 --> Helper loaded: form_helper
INFO - 2016-05-18 19:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:24:21 --> Form Validation Class Initialized
INFO - 2016-05-18 19:24:21 --> Controller Class Initialized
INFO - 2016-05-18 19:24:21 --> Model Class Initialized
INFO - 2016-05-18 19:24:21 --> Database Driver Class Initialized
INFO - 2016-05-18 19:24:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:24:21 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:24:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:24:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:24:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:24:21 --> Final output sent to browser
DEBUG - 2016-05-18 19:24:21 --> Total execution time: 0.1232
INFO - 2016-05-18 19:24:22 --> Config Class Initialized
INFO - 2016-05-18 19:24:22 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:24:22 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:24:22 --> Utf8 Class Initialized
INFO - 2016-05-18 19:24:22 --> URI Class Initialized
INFO - 2016-05-18 19:24:22 --> Router Class Initialized
INFO - 2016-05-18 19:24:22 --> Output Class Initialized
INFO - 2016-05-18 19:24:22 --> Security Class Initialized
DEBUG - 2016-05-18 19:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:24:22 --> Input Class Initialized
INFO - 2016-05-18 19:24:22 --> Language Class Initialized
INFO - 2016-05-18 19:24:22 --> Loader Class Initialized
INFO - 2016-05-18 19:24:22 --> Helper loaded: url_helper
INFO - 2016-05-18 19:24:22 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:24:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:24:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:24:22 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:24:22 --> Helper loaded: form_helper
INFO - 2016-05-18 19:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:24:22 --> Form Validation Class Initialized
INFO - 2016-05-18 19:24:22 --> Controller Class Initialized
INFO - 2016-05-18 19:24:22 --> Model Class Initialized
INFO - 2016-05-18 19:24:22 --> Database Driver Class Initialized
INFO - 2016-05-18 19:24:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:24:22 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:24:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:24:22 --> Final output sent to browser
DEBUG - 2016-05-18 19:24:22 --> Total execution time: 0.1391
INFO - 2016-05-18 19:24:28 --> Config Class Initialized
INFO - 2016-05-18 19:24:28 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:24:28 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:24:28 --> Utf8 Class Initialized
INFO - 2016-05-18 19:24:28 --> URI Class Initialized
INFO - 2016-05-18 19:24:28 --> Router Class Initialized
INFO - 2016-05-18 19:24:28 --> Output Class Initialized
INFO - 2016-05-18 19:24:28 --> Security Class Initialized
DEBUG - 2016-05-18 19:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:24:28 --> Input Class Initialized
INFO - 2016-05-18 19:24:28 --> Language Class Initialized
INFO - 2016-05-18 19:24:28 --> Loader Class Initialized
INFO - 2016-05-18 19:24:28 --> Helper loaded: url_helper
INFO - 2016-05-18 19:24:28 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:24:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:24:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:24:28 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:24:28 --> Helper loaded: form_helper
INFO - 2016-05-18 19:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:24:28 --> Form Validation Class Initialized
INFO - 2016-05-18 19:24:28 --> Controller Class Initialized
INFO - 2016-05-18 19:24:28 --> Model Class Initialized
INFO - 2016-05-18 19:24:28 --> Database Driver Class Initialized
INFO - 2016-05-18 19:24:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:24:28 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:24:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:24:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:24:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:24:28 --> Final output sent to browser
DEBUG - 2016-05-18 19:24:28 --> Total execution time: 0.1050
INFO - 2016-05-18 19:24:28 --> Config Class Initialized
INFO - 2016-05-18 19:24:28 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:24:28 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:24:28 --> Utf8 Class Initialized
INFO - 2016-05-18 19:24:28 --> URI Class Initialized
INFO - 2016-05-18 19:24:28 --> Router Class Initialized
INFO - 2016-05-18 19:24:28 --> Output Class Initialized
INFO - 2016-05-18 19:24:28 --> Security Class Initialized
DEBUG - 2016-05-18 19:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:24:28 --> Input Class Initialized
INFO - 2016-05-18 19:24:28 --> Language Class Initialized
INFO - 2016-05-18 19:24:28 --> Loader Class Initialized
INFO - 2016-05-18 19:24:28 --> Helper loaded: url_helper
INFO - 2016-05-18 19:24:28 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:24:28 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:24:28 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:24:28 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:24:28 --> Helper loaded: form_helper
INFO - 2016-05-18 19:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:24:28 --> Form Validation Class Initialized
INFO - 2016-05-18 19:24:28 --> Controller Class Initialized
INFO - 2016-05-18 19:24:28 --> Model Class Initialized
INFO - 2016-05-18 19:24:28 --> Database Driver Class Initialized
INFO - 2016-05-18 19:24:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:24:28 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:24:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:24:29 --> Final output sent to browser
DEBUG - 2016-05-18 19:24:29 --> Total execution time: 0.1148
INFO - 2016-05-18 19:24:34 --> Config Class Initialized
INFO - 2016-05-18 19:24:34 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:24:34 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:24:34 --> Utf8 Class Initialized
INFO - 2016-05-18 19:24:34 --> URI Class Initialized
DEBUG - 2016-05-18 19:24:34 --> No URI present. Default controller set.
INFO - 2016-05-18 19:24:34 --> Config Class Initialized
INFO - 2016-05-18 19:24:34 --> Router Class Initialized
INFO - 2016-05-18 19:24:34 --> Hooks Class Initialized
INFO - 2016-05-18 19:24:34 --> Output Class Initialized
DEBUG - 2016-05-18 19:24:34 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:24:34 --> Security Class Initialized
INFO - 2016-05-18 19:24:34 --> Utf8 Class Initialized
INFO - 2016-05-18 19:24:34 --> URI Class Initialized
DEBUG - 2016-05-18 19:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:24:34 --> Input Class Initialized
INFO - 2016-05-18 19:24:34 --> Language Class Initialized
INFO - 2016-05-18 19:24:34 --> Router Class Initialized
INFO - 2016-05-18 19:24:34 --> Output Class Initialized
INFO - 2016-05-18 19:24:34 --> Security Class Initialized
DEBUG - 2016-05-18 19:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:24:34 --> Input Class Initialized
INFO - 2016-05-18 19:24:34 --> Language Class Initialized
INFO - 2016-05-18 19:24:34 --> Loader Class Initialized
INFO - 2016-05-18 19:24:34 --> Helper loaded: url_helper
INFO - 2016-05-18 19:24:34 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:24:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:24:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:24:34 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:24:34 --> Helper loaded: form_helper
INFO - 2016-05-18 19:24:34 --> Loader Class Initialized
INFO - 2016-05-18 19:24:34 --> Helper loaded: url_helper
INFO - 2016-05-18 19:24:34 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:24:34 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:24:34 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:24:34 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:24:34 --> Form Validation Class Initialized
INFO - 2016-05-18 19:24:34 --> Controller Class Initialized
INFO - 2016-05-18 19:24:34 --> Model Class Initialized
INFO - 2016-05-18 19:24:34 --> Helper loaded: form_helper
INFO - 2016-05-18 19:24:34 --> Database Driver Class Initialized
INFO - 2016-05-18 19:24:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:24:34 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:24:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:24:34 --> Form Validation Class Initialized
INFO - 2016-05-18 19:24:34 --> Controller Class Initialized
INFO - 2016-05-18 19:24:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-18 19:24:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:24:34 --> Final output sent to browser
DEBUG - 2016-05-18 19:24:34 --> Total execution time: 0.1059
INFO - 2016-05-18 19:24:34 --> Config Class Initialized
INFO - 2016-05-18 19:24:34 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:24:34 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:24:34 --> Utf8 Class Initialized
INFO - 2016-05-18 19:24:34 --> URI Class Initialized
INFO - 2016-05-18 19:24:34 --> Router Class Initialized
INFO - 2016-05-18 19:24:34 --> Output Class Initialized
INFO - 2016-05-18 19:24:35 --> Security Class Initialized
DEBUG - 2016-05-18 19:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:24:35 --> Input Class Initialized
INFO - 2016-05-18 19:24:35 --> Language Class Initialized
INFO - 2016-05-18 19:24:35 --> Loader Class Initialized
INFO - 2016-05-18 19:24:35 --> Helper loaded: url_helper
INFO - 2016-05-18 19:24:35 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:24:35 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:24:35 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:24:35 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:24:35 --> Helper loaded: form_helper
INFO - 2016-05-18 19:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:24:35 --> Form Validation Class Initialized
INFO - 2016-05-18 19:24:35 --> Controller Class Initialized
INFO - 2016-05-18 19:24:35 --> Model Class Initialized
INFO - 2016-05-18 19:24:35 --> Database Driver Class Initialized
INFO - 2016-05-18 19:24:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:24:35 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:24:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:24:35 --> Final output sent to browser
DEBUG - 2016-05-18 19:24:35 --> Total execution time: 0.0769
INFO - 2016-05-18 19:24:38 --> Config Class Initialized
INFO - 2016-05-18 19:24:38 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:24:38 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:24:38 --> Utf8 Class Initialized
INFO - 2016-05-18 19:24:38 --> URI Class Initialized
INFO - 2016-05-18 19:24:38 --> Router Class Initialized
INFO - 2016-05-18 19:24:38 --> Output Class Initialized
INFO - 2016-05-18 19:24:38 --> Security Class Initialized
DEBUG - 2016-05-18 19:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:24:38 --> Input Class Initialized
INFO - 2016-05-18 19:24:38 --> Language Class Initialized
INFO - 2016-05-18 19:24:38 --> Loader Class Initialized
INFO - 2016-05-18 19:24:38 --> Helper loaded: url_helper
INFO - 2016-05-18 19:24:38 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:24:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:24:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:24:38 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:24:38 --> Helper loaded: form_helper
INFO - 2016-05-18 19:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:24:38 --> Form Validation Class Initialized
INFO - 2016-05-18 19:24:38 --> Controller Class Initialized
INFO - 2016-05-18 19:24:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-18 19:24:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:24:38 --> Final output sent to browser
DEBUG - 2016-05-18 19:24:38 --> Total execution time: 0.1614
INFO - 2016-05-18 19:24:38 --> Config Class Initialized
INFO - 2016-05-18 19:24:38 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:24:38 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:24:38 --> Utf8 Class Initialized
INFO - 2016-05-18 19:24:38 --> URI Class Initialized
INFO - 2016-05-18 19:24:38 --> Router Class Initialized
INFO - 2016-05-18 19:24:38 --> Output Class Initialized
INFO - 2016-05-18 19:24:38 --> Security Class Initialized
DEBUG - 2016-05-18 19:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:24:38 --> Input Class Initialized
INFO - 2016-05-18 19:24:38 --> Language Class Initialized
INFO - 2016-05-18 19:24:38 --> Loader Class Initialized
INFO - 2016-05-18 19:24:38 --> Helper loaded: url_helper
INFO - 2016-05-18 19:24:38 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:24:38 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:24:38 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:24:38 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:24:38 --> Helper loaded: form_helper
INFO - 2016-05-18 19:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:24:38 --> Form Validation Class Initialized
INFO - 2016-05-18 19:24:38 --> Controller Class Initialized
INFO - 2016-05-18 19:24:38 --> Model Class Initialized
INFO - 2016-05-18 19:24:38 --> Database Driver Class Initialized
INFO - 2016-05-18 19:24:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:24:38 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:24:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:24:39 --> Final output sent to browser
DEBUG - 2016-05-18 19:24:39 --> Total execution time: 0.1009
INFO - 2016-05-18 19:24:42 --> Config Class Initialized
INFO - 2016-05-18 19:24:42 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:24:42 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:24:42 --> Utf8 Class Initialized
INFO - 2016-05-18 19:24:42 --> URI Class Initialized
INFO - 2016-05-18 19:24:42 --> Router Class Initialized
INFO - 2016-05-18 19:24:42 --> Output Class Initialized
INFO - 2016-05-18 19:24:42 --> Security Class Initialized
DEBUG - 2016-05-18 19:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:24:42 --> Input Class Initialized
INFO - 2016-05-18 19:24:42 --> Language Class Initialized
INFO - 2016-05-18 19:24:42 --> Loader Class Initialized
INFO - 2016-05-18 19:24:42 --> Helper loaded: url_helper
INFO - 2016-05-18 19:24:42 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:24:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:24:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:24:42 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:24:42 --> Helper loaded: form_helper
INFO - 2016-05-18 19:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:24:42 --> Form Validation Class Initialized
INFO - 2016-05-18 19:24:42 --> Controller Class Initialized
INFO - 2016-05-18 19:24:42 --> Config Class Initialized
INFO - 2016-05-18 19:24:42 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:24:42 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:24:42 --> Utf8 Class Initialized
INFO - 2016-05-18 19:24:42 --> URI Class Initialized
INFO - 2016-05-18 19:24:42 --> Router Class Initialized
INFO - 2016-05-18 19:24:42 --> Output Class Initialized
INFO - 2016-05-18 19:24:42 --> Security Class Initialized
DEBUG - 2016-05-18 19:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:24:42 --> Input Class Initialized
INFO - 2016-05-18 19:24:42 --> Language Class Initialized
INFO - 2016-05-18 19:24:42 --> Loader Class Initialized
INFO - 2016-05-18 19:24:42 --> Helper loaded: url_helper
INFO - 2016-05-18 19:24:42 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:24:42 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:24:42 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:24:42 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:24:42 --> Helper loaded: form_helper
INFO - 2016-05-18 19:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:24:42 --> Form Validation Class Initialized
INFO - 2016-05-18 19:24:42 --> Controller Class Initialized
INFO - 2016-05-18 19:24:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-18 19:24:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:24:42 --> Final output sent to browser
DEBUG - 2016-05-18 19:24:42 --> Total execution time: 0.0610
INFO - 2016-05-18 19:24:43 --> Config Class Initialized
INFO - 2016-05-18 19:24:43 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:24:43 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:24:43 --> Utf8 Class Initialized
INFO - 2016-05-18 19:24:43 --> URI Class Initialized
INFO - 2016-05-18 19:24:43 --> Router Class Initialized
INFO - 2016-05-18 19:24:43 --> Output Class Initialized
INFO - 2016-05-18 19:24:43 --> Security Class Initialized
DEBUG - 2016-05-18 19:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:24:43 --> Input Class Initialized
INFO - 2016-05-18 19:24:43 --> Language Class Initialized
INFO - 2016-05-18 19:24:43 --> Loader Class Initialized
INFO - 2016-05-18 19:24:43 --> Helper loaded: url_helper
INFO - 2016-05-18 19:24:43 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:24:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:24:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:24:43 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:24:43 --> Helper loaded: form_helper
INFO - 2016-05-18 19:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:24:43 --> Form Validation Class Initialized
INFO - 2016-05-18 19:24:43 --> Controller Class Initialized
INFO - 2016-05-18 19:24:43 --> Model Class Initialized
INFO - 2016-05-18 19:24:43 --> Database Driver Class Initialized
INFO - 2016-05-18 19:24:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:24:43 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:24:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:24:43 --> Final output sent to browser
DEBUG - 2016-05-18 19:24:43 --> Total execution time: 0.0919
INFO - 2016-05-18 19:24:53 --> Config Class Initialized
INFO - 2016-05-18 19:24:53 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:24:53 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:24:53 --> Utf8 Class Initialized
INFO - 2016-05-18 19:24:53 --> URI Class Initialized
INFO - 2016-05-18 19:24:53 --> Router Class Initialized
INFO - 2016-05-18 19:24:53 --> Output Class Initialized
INFO - 2016-05-18 19:24:53 --> Security Class Initialized
DEBUG - 2016-05-18 19:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:24:53 --> Input Class Initialized
INFO - 2016-05-18 19:24:53 --> Language Class Initialized
INFO - 2016-05-18 19:24:53 --> Loader Class Initialized
INFO - 2016-05-18 19:24:53 --> Helper loaded: url_helper
INFO - 2016-05-18 19:24:53 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:24:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:24:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:24:53 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:24:53 --> Helper loaded: form_helper
INFO - 2016-05-18 19:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:24:53 --> Form Validation Class Initialized
INFO - 2016-05-18 19:24:53 --> Controller Class Initialized
INFO - 2016-05-18 19:24:53 --> Model Class Initialized
INFO - 2016-05-18 19:24:53 --> Database Driver Class Initialized
INFO - 2016-05-18 19:24:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:24:53 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:24:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:24:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:24:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:24:53 --> Final output sent to browser
DEBUG - 2016-05-18 19:24:53 --> Total execution time: 0.0817
INFO - 2016-05-18 19:24:53 --> Config Class Initialized
INFO - 2016-05-18 19:24:53 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:24:53 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:24:53 --> Utf8 Class Initialized
INFO - 2016-05-18 19:24:53 --> URI Class Initialized
INFO - 2016-05-18 19:24:53 --> Router Class Initialized
INFO - 2016-05-18 19:24:53 --> Output Class Initialized
INFO - 2016-05-18 19:24:53 --> Security Class Initialized
DEBUG - 2016-05-18 19:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:24:53 --> Input Class Initialized
INFO - 2016-05-18 19:24:53 --> Language Class Initialized
INFO - 2016-05-18 19:24:53 --> Loader Class Initialized
INFO - 2016-05-18 19:24:53 --> Helper loaded: url_helper
INFO - 2016-05-18 19:24:53 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:24:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:24:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:24:53 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:24:53 --> Helper loaded: form_helper
INFO - 2016-05-18 19:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:24:53 --> Form Validation Class Initialized
INFO - 2016-05-18 19:24:53 --> Controller Class Initialized
INFO - 2016-05-18 19:24:53 --> Model Class Initialized
INFO - 2016-05-18 19:24:53 --> Database Driver Class Initialized
INFO - 2016-05-18 19:24:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:24:53 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:24:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:24:53 --> Final output sent to browser
DEBUG - 2016-05-18 19:24:53 --> Total execution time: 0.1154
INFO - 2016-05-18 19:25:12 --> Config Class Initialized
INFO - 2016-05-18 19:25:12 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:25:12 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:25:12 --> Utf8 Class Initialized
INFO - 2016-05-18 19:25:12 --> URI Class Initialized
INFO - 2016-05-18 19:25:12 --> Router Class Initialized
INFO - 2016-05-18 19:25:12 --> Output Class Initialized
INFO - 2016-05-18 19:25:12 --> Security Class Initialized
DEBUG - 2016-05-18 19:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:25:12 --> Input Class Initialized
INFO - 2016-05-18 19:25:12 --> Language Class Initialized
INFO - 2016-05-18 19:25:12 --> Loader Class Initialized
INFO - 2016-05-18 19:25:12 --> Helper loaded: url_helper
INFO - 2016-05-18 19:25:12 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:25:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:25:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:25:12 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:25:12 --> Helper loaded: form_helper
INFO - 2016-05-18 19:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:25:12 --> Form Validation Class Initialized
INFO - 2016-05-18 19:25:12 --> Controller Class Initialized
INFO - 2016-05-18 19:25:12 --> Model Class Initialized
INFO - 2016-05-18 19:25:12 --> Database Driver Class Initialized
INFO - 2016-05-18 19:25:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:25:12 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:25:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:25:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:25:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:25:12 --> Final output sent to browser
DEBUG - 2016-05-18 19:25:12 --> Total execution time: 0.0929
INFO - 2016-05-18 19:25:12 --> Config Class Initialized
INFO - 2016-05-18 19:25:12 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:25:12 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:25:12 --> Utf8 Class Initialized
INFO - 2016-05-18 19:25:12 --> URI Class Initialized
INFO - 2016-05-18 19:25:12 --> Router Class Initialized
INFO - 2016-05-18 19:25:12 --> Output Class Initialized
INFO - 2016-05-18 19:25:12 --> Security Class Initialized
DEBUG - 2016-05-18 19:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:25:12 --> Input Class Initialized
INFO - 2016-05-18 19:25:12 --> Language Class Initialized
INFO - 2016-05-18 19:25:12 --> Loader Class Initialized
INFO - 2016-05-18 19:25:12 --> Helper loaded: url_helper
INFO - 2016-05-18 19:25:12 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:25:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:25:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:25:12 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:25:12 --> Helper loaded: form_helper
INFO - 2016-05-18 19:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:25:12 --> Form Validation Class Initialized
INFO - 2016-05-18 19:25:12 --> Controller Class Initialized
INFO - 2016-05-18 19:25:12 --> Model Class Initialized
INFO - 2016-05-18 19:25:12 --> Database Driver Class Initialized
INFO - 2016-05-18 19:25:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:25:12 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:25:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:25:12 --> Final output sent to browser
DEBUG - 2016-05-18 19:25:12 --> Total execution time: 0.1081
INFO - 2016-05-18 19:25:17 --> Config Class Initialized
INFO - 2016-05-18 19:25:17 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:25:17 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:25:17 --> Utf8 Class Initialized
INFO - 2016-05-18 19:25:17 --> URI Class Initialized
INFO - 2016-05-18 19:25:17 --> Router Class Initialized
INFO - 2016-05-18 19:25:17 --> Output Class Initialized
INFO - 2016-05-18 19:25:17 --> Security Class Initialized
DEBUG - 2016-05-18 19:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:25:17 --> Input Class Initialized
INFO - 2016-05-18 19:25:17 --> Language Class Initialized
INFO - 2016-05-18 19:25:17 --> Loader Class Initialized
INFO - 2016-05-18 19:25:17 --> Helper loaded: url_helper
INFO - 2016-05-18 19:25:17 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:25:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:25:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:25:17 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:25:17 --> Helper loaded: form_helper
INFO - 2016-05-18 19:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:25:17 --> Form Validation Class Initialized
INFO - 2016-05-18 19:25:17 --> Controller Class Initialized
INFO - 2016-05-18 19:25:17 --> Model Class Initialized
INFO - 2016-05-18 19:25:17 --> Database Driver Class Initialized
INFO - 2016-05-18 19:25:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:25:17 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:25:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:25:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:25:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:25:17 --> Final output sent to browser
DEBUG - 2016-05-18 19:25:17 --> Total execution time: 0.0831
INFO - 2016-05-18 19:25:17 --> Config Class Initialized
INFO - 2016-05-18 19:25:17 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:25:17 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:25:17 --> Utf8 Class Initialized
INFO - 2016-05-18 19:25:17 --> URI Class Initialized
INFO - 2016-05-18 19:25:17 --> Router Class Initialized
INFO - 2016-05-18 19:25:18 --> Output Class Initialized
INFO - 2016-05-18 19:25:18 --> Security Class Initialized
DEBUG - 2016-05-18 19:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:25:18 --> Input Class Initialized
INFO - 2016-05-18 19:25:18 --> Language Class Initialized
INFO - 2016-05-18 19:25:18 --> Loader Class Initialized
INFO - 2016-05-18 19:25:18 --> Helper loaded: url_helper
INFO - 2016-05-18 19:25:18 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:25:18 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:25:18 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:25:18 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:25:18 --> Helper loaded: form_helper
INFO - 2016-05-18 19:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:25:18 --> Form Validation Class Initialized
INFO - 2016-05-18 19:25:18 --> Controller Class Initialized
INFO - 2016-05-18 19:25:18 --> Model Class Initialized
INFO - 2016-05-18 19:25:18 --> Database Driver Class Initialized
INFO - 2016-05-18 19:25:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:25:18 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:25:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:25:18 --> Final output sent to browser
DEBUG - 2016-05-18 19:25:18 --> Total execution time: 0.1128
INFO - 2016-05-18 19:25:22 --> Config Class Initialized
INFO - 2016-05-18 19:25:22 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:25:22 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:25:22 --> Utf8 Class Initialized
INFO - 2016-05-18 19:25:22 --> URI Class Initialized
INFO - 2016-05-18 19:25:22 --> Router Class Initialized
INFO - 2016-05-18 19:25:22 --> Output Class Initialized
INFO - 2016-05-18 19:25:22 --> Security Class Initialized
DEBUG - 2016-05-18 19:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:25:22 --> Input Class Initialized
INFO - 2016-05-18 19:25:22 --> Language Class Initialized
INFO - 2016-05-18 19:25:22 --> Loader Class Initialized
INFO - 2016-05-18 19:25:22 --> Helper loaded: url_helper
INFO - 2016-05-18 19:25:22 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:25:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:25:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:25:22 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:25:22 --> Helper loaded: form_helper
INFO - 2016-05-18 19:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:25:22 --> Form Validation Class Initialized
INFO - 2016-05-18 19:25:22 --> Controller Class Initialized
INFO - 2016-05-18 19:25:22 --> Model Class Initialized
INFO - 2016-05-18 19:25:22 --> Database Driver Class Initialized
INFO - 2016-05-18 19:25:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:25:22 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:25:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:25:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:25:22 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:25:22 --> Final output sent to browser
DEBUG - 2016-05-18 19:25:22 --> Total execution time: 0.0836
INFO - 2016-05-18 19:25:22 --> Config Class Initialized
INFO - 2016-05-18 19:25:22 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:25:22 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:25:22 --> Utf8 Class Initialized
INFO - 2016-05-18 19:25:22 --> URI Class Initialized
INFO - 2016-05-18 19:25:22 --> Router Class Initialized
INFO - 2016-05-18 19:25:22 --> Output Class Initialized
INFO - 2016-05-18 19:25:22 --> Security Class Initialized
DEBUG - 2016-05-18 19:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:25:22 --> Input Class Initialized
INFO - 2016-05-18 19:25:22 --> Language Class Initialized
INFO - 2016-05-18 19:25:22 --> Loader Class Initialized
INFO - 2016-05-18 19:25:22 --> Helper loaded: url_helper
INFO - 2016-05-18 19:25:22 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:25:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:25:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:25:22 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:25:22 --> Helper loaded: form_helper
INFO - 2016-05-18 19:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:25:22 --> Form Validation Class Initialized
INFO - 2016-05-18 19:25:22 --> Controller Class Initialized
INFO - 2016-05-18 19:25:22 --> Model Class Initialized
INFO - 2016-05-18 19:25:22 --> Database Driver Class Initialized
INFO - 2016-05-18 19:25:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:25:22 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:25:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:25:22 --> Final output sent to browser
DEBUG - 2016-05-18 19:25:22 --> Total execution time: 0.1190
INFO - 2016-05-18 19:25:25 --> Config Class Initialized
INFO - 2016-05-18 19:25:25 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:25:25 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:25:25 --> Utf8 Class Initialized
INFO - 2016-05-18 19:25:25 --> URI Class Initialized
INFO - 2016-05-18 19:25:25 --> Router Class Initialized
INFO - 2016-05-18 19:25:25 --> Output Class Initialized
INFO - 2016-05-18 19:25:25 --> Security Class Initialized
DEBUG - 2016-05-18 19:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:25:25 --> Input Class Initialized
INFO - 2016-05-18 19:25:25 --> Language Class Initialized
INFO - 2016-05-18 19:25:25 --> Loader Class Initialized
INFO - 2016-05-18 19:25:25 --> Helper loaded: url_helper
INFO - 2016-05-18 19:25:25 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:25:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:25:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:25:25 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:25:25 --> Helper loaded: form_helper
INFO - 2016-05-18 19:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:25:25 --> Form Validation Class Initialized
INFO - 2016-05-18 19:25:25 --> Controller Class Initialized
INFO - 2016-05-18 19:25:25 --> Model Class Initialized
INFO - 2016-05-18 19:25:25 --> Database Driver Class Initialized
INFO - 2016-05-18 19:25:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:25:25 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:25:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:25:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:25:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:25:25 --> Final output sent to browser
DEBUG - 2016-05-18 19:25:25 --> Total execution time: 0.0817
INFO - 2016-05-18 19:25:26 --> Config Class Initialized
INFO - 2016-05-18 19:25:26 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:25:26 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:25:26 --> Utf8 Class Initialized
INFO - 2016-05-18 19:25:26 --> URI Class Initialized
INFO - 2016-05-18 19:25:26 --> Router Class Initialized
INFO - 2016-05-18 19:25:26 --> Output Class Initialized
INFO - 2016-05-18 19:25:26 --> Security Class Initialized
DEBUG - 2016-05-18 19:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:25:26 --> Input Class Initialized
INFO - 2016-05-18 19:25:26 --> Language Class Initialized
INFO - 2016-05-18 19:25:26 --> Loader Class Initialized
INFO - 2016-05-18 19:25:26 --> Helper loaded: url_helper
INFO - 2016-05-18 19:25:26 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:25:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:25:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:25:26 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:25:26 --> Helper loaded: form_helper
INFO - 2016-05-18 19:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:25:26 --> Form Validation Class Initialized
INFO - 2016-05-18 19:25:26 --> Controller Class Initialized
INFO - 2016-05-18 19:25:26 --> Model Class Initialized
INFO - 2016-05-18 19:25:26 --> Database Driver Class Initialized
INFO - 2016-05-18 19:25:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:25:26 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:25:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:25:26 --> Final output sent to browser
DEBUG - 2016-05-18 19:25:26 --> Total execution time: 0.1497
INFO - 2016-05-18 19:25:32 --> Config Class Initialized
INFO - 2016-05-18 19:25:32 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:25:32 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:25:32 --> Utf8 Class Initialized
INFO - 2016-05-18 19:25:32 --> URI Class Initialized
INFO - 2016-05-18 19:25:32 --> Router Class Initialized
INFO - 2016-05-18 19:25:32 --> Output Class Initialized
INFO - 2016-05-18 19:25:32 --> Security Class Initialized
DEBUG - 2016-05-18 19:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:25:32 --> Input Class Initialized
INFO - 2016-05-18 19:25:32 --> Language Class Initialized
INFO - 2016-05-18 19:25:32 --> Loader Class Initialized
INFO - 2016-05-18 19:25:32 --> Helper loaded: url_helper
INFO - 2016-05-18 19:25:32 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:25:32 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:25:32 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:25:32 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:25:32 --> Helper loaded: form_helper
INFO - 2016-05-18 19:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:25:32 --> Form Validation Class Initialized
INFO - 2016-05-18 19:25:32 --> Controller Class Initialized
INFO - 2016-05-18 19:25:32 --> Model Class Initialized
INFO - 2016-05-18 19:25:32 --> Database Driver Class Initialized
INFO - 2016-05-18 19:25:32 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:25:32 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:25:32 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:25:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:25:32 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:25:32 --> Final output sent to browser
DEBUG - 2016-05-18 19:25:32 --> Total execution time: 0.1233
INFO - 2016-05-18 19:25:32 --> Config Class Initialized
INFO - 2016-05-18 19:25:32 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:25:32 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:25:32 --> Utf8 Class Initialized
INFO - 2016-05-18 19:25:32 --> URI Class Initialized
INFO - 2016-05-18 19:25:32 --> Router Class Initialized
INFO - 2016-05-18 19:25:32 --> Output Class Initialized
INFO - 2016-05-18 19:25:32 --> Security Class Initialized
DEBUG - 2016-05-18 19:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:25:32 --> Input Class Initialized
INFO - 2016-05-18 19:25:32 --> Language Class Initialized
INFO - 2016-05-18 19:25:33 --> Loader Class Initialized
INFO - 2016-05-18 19:25:33 --> Helper loaded: url_helper
INFO - 2016-05-18 19:25:33 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:25:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:25:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:25:33 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:25:33 --> Helper loaded: form_helper
INFO - 2016-05-18 19:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:25:33 --> Form Validation Class Initialized
INFO - 2016-05-18 19:25:33 --> Controller Class Initialized
INFO - 2016-05-18 19:25:33 --> Model Class Initialized
INFO - 2016-05-18 19:25:33 --> Database Driver Class Initialized
INFO - 2016-05-18 19:25:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:25:33 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:25:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:25:33 --> Final output sent to browser
DEBUG - 2016-05-18 19:25:33 --> Total execution time: 0.1216
INFO - 2016-05-18 19:25:43 --> Config Class Initialized
INFO - 2016-05-18 19:25:43 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:25:43 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:25:43 --> Utf8 Class Initialized
INFO - 2016-05-18 19:25:43 --> URI Class Initialized
INFO - 2016-05-18 19:25:43 --> Router Class Initialized
INFO - 2016-05-18 19:25:43 --> Output Class Initialized
INFO - 2016-05-18 19:25:43 --> Security Class Initialized
DEBUG - 2016-05-18 19:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:25:43 --> Input Class Initialized
INFO - 2016-05-18 19:25:43 --> Language Class Initialized
INFO - 2016-05-18 19:25:43 --> Loader Class Initialized
INFO - 2016-05-18 19:25:43 --> Helper loaded: url_helper
INFO - 2016-05-18 19:25:43 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:25:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:25:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:25:43 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:25:43 --> Helper loaded: form_helper
INFO - 2016-05-18 19:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:25:43 --> Form Validation Class Initialized
INFO - 2016-05-18 19:25:43 --> Controller Class Initialized
INFO - 2016-05-18 19:25:43 --> Model Class Initialized
INFO - 2016-05-18 19:25:43 --> Database Driver Class Initialized
INFO - 2016-05-18 19:25:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:25:43 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:25:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:25:43 --> Final output sent to browser
DEBUG - 2016-05-18 19:25:43 --> Total execution time: 0.0726
INFO - 2016-05-18 19:25:46 --> Config Class Initialized
INFO - 2016-05-18 19:25:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:25:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:25:46 --> Utf8 Class Initialized
INFO - 2016-05-18 19:25:46 --> URI Class Initialized
INFO - 2016-05-18 19:25:46 --> Router Class Initialized
INFO - 2016-05-18 19:25:46 --> Output Class Initialized
INFO - 2016-05-18 19:25:46 --> Security Class Initialized
DEBUG - 2016-05-18 19:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:25:46 --> Input Class Initialized
INFO - 2016-05-18 19:25:46 --> Language Class Initialized
INFO - 2016-05-18 19:25:46 --> Loader Class Initialized
INFO - 2016-05-18 19:25:46 --> Helper loaded: url_helper
INFO - 2016-05-18 19:25:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:25:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:25:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:25:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:25:46 --> Helper loaded: form_helper
INFO - 2016-05-18 19:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:25:46 --> Form Validation Class Initialized
INFO - 2016-05-18 19:25:46 --> Controller Class Initialized
INFO - 2016-05-18 19:25:46 --> Model Class Initialized
INFO - 2016-05-18 19:25:46 --> Database Driver Class Initialized
INFO - 2016-05-18 19:25:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:25:46 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:25:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:25:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:25:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:25:46 --> Final output sent to browser
DEBUG - 2016-05-18 19:25:46 --> Total execution time: 0.0895
INFO - 2016-05-18 19:25:46 --> Config Class Initialized
INFO - 2016-05-18 19:25:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:25:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:25:46 --> Utf8 Class Initialized
INFO - 2016-05-18 19:25:46 --> URI Class Initialized
INFO - 2016-05-18 19:25:46 --> Router Class Initialized
INFO - 2016-05-18 19:25:46 --> Output Class Initialized
INFO - 2016-05-18 19:25:46 --> Security Class Initialized
DEBUG - 2016-05-18 19:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:25:46 --> Input Class Initialized
INFO - 2016-05-18 19:25:46 --> Language Class Initialized
INFO - 2016-05-18 19:25:46 --> Loader Class Initialized
INFO - 2016-05-18 19:25:46 --> Helper loaded: url_helper
INFO - 2016-05-18 19:25:46 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:25:46 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:25:46 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:25:46 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:25:46 --> Helper loaded: form_helper
INFO - 2016-05-18 19:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:25:47 --> Form Validation Class Initialized
INFO - 2016-05-18 19:25:47 --> Controller Class Initialized
INFO - 2016-05-18 19:25:47 --> Model Class Initialized
INFO - 2016-05-18 19:25:47 --> Database Driver Class Initialized
INFO - 2016-05-18 19:25:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:25:47 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:25:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:25:47 --> Final output sent to browser
DEBUG - 2016-05-18 19:25:47 --> Total execution time: 0.1218
INFO - 2016-05-18 19:26:07 --> Config Class Initialized
INFO - 2016-05-18 19:26:07 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:26:07 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:26:07 --> Utf8 Class Initialized
INFO - 2016-05-18 19:26:07 --> URI Class Initialized
INFO - 2016-05-18 19:26:07 --> Router Class Initialized
INFO - 2016-05-18 19:26:07 --> Output Class Initialized
INFO - 2016-05-18 19:26:07 --> Security Class Initialized
DEBUG - 2016-05-18 19:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:26:07 --> Input Class Initialized
INFO - 2016-05-18 19:26:07 --> Language Class Initialized
INFO - 2016-05-18 19:26:07 --> Loader Class Initialized
INFO - 2016-05-18 19:26:07 --> Helper loaded: url_helper
INFO - 2016-05-18 19:26:07 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:26:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:26:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:26:07 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:26:07 --> Helper loaded: form_helper
INFO - 2016-05-18 19:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:26:07 --> Form Validation Class Initialized
INFO - 2016-05-18 19:26:07 --> Controller Class Initialized
INFO - 2016-05-18 19:26:07 --> Model Class Initialized
INFO - 2016-05-18 19:26:07 --> Database Driver Class Initialized
INFO - 2016-05-18 19:26:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:26:07 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:26:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:26:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:26:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:26:07 --> Final output sent to browser
DEBUG - 2016-05-18 19:26:07 --> Total execution time: 0.0820
INFO - 2016-05-18 19:26:08 --> Config Class Initialized
INFO - 2016-05-18 19:26:08 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:26:08 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:26:08 --> Utf8 Class Initialized
INFO - 2016-05-18 19:26:08 --> URI Class Initialized
INFO - 2016-05-18 19:26:08 --> Router Class Initialized
INFO - 2016-05-18 19:26:08 --> Output Class Initialized
INFO - 2016-05-18 19:26:08 --> Security Class Initialized
DEBUG - 2016-05-18 19:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:26:08 --> Input Class Initialized
INFO - 2016-05-18 19:26:08 --> Language Class Initialized
INFO - 2016-05-18 19:26:08 --> Loader Class Initialized
INFO - 2016-05-18 19:26:08 --> Helper loaded: url_helper
INFO - 2016-05-18 19:26:08 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:26:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:26:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:26:08 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:26:08 --> Helper loaded: form_helper
INFO - 2016-05-18 19:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:26:08 --> Form Validation Class Initialized
INFO - 2016-05-18 19:26:08 --> Controller Class Initialized
INFO - 2016-05-18 19:26:08 --> Model Class Initialized
INFO - 2016-05-18 19:26:08 --> Config Class Initialized
INFO - 2016-05-18 19:26:08 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:26:08 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:26:08 --> Utf8 Class Initialized
INFO - 2016-05-18 19:26:08 --> URI Class Initialized
INFO - 2016-05-18 19:26:08 --> Router Class Initialized
INFO - 2016-05-18 19:26:08 --> Database Driver Class Initialized
INFO - 2016-05-18 19:26:08 --> Output Class Initialized
INFO - 2016-05-18 19:26:08 --> Security Class Initialized
INFO - 2016-05-18 19:26:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:26:08 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:26:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
DEBUG - 2016-05-18 19:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:26:08 --> Input Class Initialized
INFO - 2016-05-18 19:26:08 --> Language Class Initialized
INFO - 2016-05-18 19:26:08 --> Final output sent to browser
DEBUG - 2016-05-18 19:26:08 --> Total execution time: 0.1262
INFO - 2016-05-18 19:26:08 --> Loader Class Initialized
INFO - 2016-05-18 19:26:08 --> Helper loaded: url_helper
INFO - 2016-05-18 19:26:08 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:26:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:26:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:26:08 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:26:08 --> Helper loaded: form_helper
INFO - 2016-05-18 19:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:26:08 --> Form Validation Class Initialized
INFO - 2016-05-18 19:26:08 --> Controller Class Initialized
INFO - 2016-05-18 19:26:08 --> Model Class Initialized
INFO - 2016-05-18 19:26:08 --> Database Driver Class Initialized
INFO - 2016-05-18 19:26:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:26:08 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:26:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:26:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:26:08 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:26:08 --> Final output sent to browser
DEBUG - 2016-05-18 19:26:08 --> Total execution time: 0.1184
INFO - 2016-05-18 19:26:08 --> Config Class Initialized
INFO - 2016-05-18 19:26:08 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:26:08 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:26:08 --> Utf8 Class Initialized
INFO - 2016-05-18 19:26:08 --> URI Class Initialized
INFO - 2016-05-18 19:26:08 --> Router Class Initialized
INFO - 2016-05-18 19:26:08 --> Output Class Initialized
INFO - 2016-05-18 19:26:08 --> Security Class Initialized
DEBUG - 2016-05-18 19:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:26:08 --> Input Class Initialized
INFO - 2016-05-18 19:26:08 --> Language Class Initialized
INFO - 2016-05-18 19:26:08 --> Loader Class Initialized
INFO - 2016-05-18 19:26:08 --> Helper loaded: url_helper
INFO - 2016-05-18 19:26:08 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:26:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:26:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:26:08 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:26:08 --> Helper loaded: form_helper
INFO - 2016-05-18 19:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:26:08 --> Form Validation Class Initialized
INFO - 2016-05-18 19:26:08 --> Controller Class Initialized
INFO - 2016-05-18 19:26:08 --> Model Class Initialized
INFO - 2016-05-18 19:26:08 --> Database Driver Class Initialized
INFO - 2016-05-18 19:26:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:26:08 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:26:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:26:08 --> Final output sent to browser
DEBUG - 2016-05-18 19:26:08 --> Total execution time: 0.1032
INFO - 2016-05-18 19:26:13 --> Config Class Initialized
INFO - 2016-05-18 19:26:13 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:26:13 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:26:13 --> Utf8 Class Initialized
INFO - 2016-05-18 19:26:13 --> URI Class Initialized
INFO - 2016-05-18 19:26:13 --> Router Class Initialized
INFO - 2016-05-18 19:26:13 --> Output Class Initialized
INFO - 2016-05-18 19:26:13 --> Security Class Initialized
DEBUG - 2016-05-18 19:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:26:13 --> Input Class Initialized
INFO - 2016-05-18 19:26:13 --> Language Class Initialized
INFO - 2016-05-18 19:26:13 --> Loader Class Initialized
INFO - 2016-05-18 19:26:13 --> Helper loaded: url_helper
INFO - 2016-05-18 19:26:13 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:26:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:26:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:26:14 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:26:14 --> Helper loaded: form_helper
INFO - 2016-05-18 19:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:26:14 --> Form Validation Class Initialized
INFO - 2016-05-18 19:26:14 --> Controller Class Initialized
INFO - 2016-05-18 19:26:14 --> Model Class Initialized
INFO - 2016-05-18 19:26:14 --> Database Driver Class Initialized
INFO - 2016-05-18 19:26:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:26:14 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:26:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:26:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:26:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:26:14 --> Final output sent to browser
DEBUG - 2016-05-18 19:26:14 --> Total execution time: 0.1016
INFO - 2016-05-18 19:26:14 --> Config Class Initialized
INFO - 2016-05-18 19:26:14 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:26:14 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:26:14 --> Utf8 Class Initialized
INFO - 2016-05-18 19:26:14 --> URI Class Initialized
INFO - 2016-05-18 19:26:14 --> Router Class Initialized
INFO - 2016-05-18 19:26:14 --> Output Class Initialized
INFO - 2016-05-18 19:26:14 --> Security Class Initialized
DEBUG - 2016-05-18 19:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:26:14 --> Input Class Initialized
INFO - 2016-05-18 19:26:14 --> Language Class Initialized
INFO - 2016-05-18 19:26:14 --> Loader Class Initialized
INFO - 2016-05-18 19:26:14 --> Helper loaded: url_helper
INFO - 2016-05-18 19:26:14 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:26:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:26:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:26:14 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:26:14 --> Helper loaded: form_helper
INFO - 2016-05-18 19:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:26:14 --> Form Validation Class Initialized
INFO - 2016-05-18 19:26:14 --> Controller Class Initialized
INFO - 2016-05-18 19:26:14 --> Model Class Initialized
INFO - 2016-05-18 19:26:14 --> Database Driver Class Initialized
INFO - 2016-05-18 19:26:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:26:14 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:26:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:26:14 --> Final output sent to browser
DEBUG - 2016-05-18 19:26:14 --> Total execution time: 0.0992
INFO - 2016-05-18 19:26:20 --> Config Class Initialized
INFO - 2016-05-18 19:26:20 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:26:20 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:26:20 --> Utf8 Class Initialized
INFO - 2016-05-18 19:26:20 --> URI Class Initialized
INFO - 2016-05-18 19:26:20 --> Router Class Initialized
INFO - 2016-05-18 19:26:20 --> Output Class Initialized
INFO - 2016-05-18 19:26:20 --> Security Class Initialized
DEBUG - 2016-05-18 19:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:26:20 --> Input Class Initialized
INFO - 2016-05-18 19:26:20 --> Language Class Initialized
INFO - 2016-05-18 19:26:20 --> Loader Class Initialized
INFO - 2016-05-18 19:26:20 --> Helper loaded: url_helper
INFO - 2016-05-18 19:26:20 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:26:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:26:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:26:20 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:26:20 --> Helper loaded: form_helper
INFO - 2016-05-18 19:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:26:20 --> Form Validation Class Initialized
INFO - 2016-05-18 19:26:20 --> Controller Class Initialized
INFO - 2016-05-18 19:26:20 --> Model Class Initialized
INFO - 2016-05-18 19:26:20 --> Database Driver Class Initialized
INFO - 2016-05-18 19:26:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:26:20 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:26:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:26:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:26:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:26:20 --> Final output sent to browser
DEBUG - 2016-05-18 19:26:20 --> Total execution time: 0.0994
INFO - 2016-05-18 19:26:20 --> Config Class Initialized
INFO - 2016-05-18 19:26:20 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:26:20 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:26:20 --> Utf8 Class Initialized
INFO - 2016-05-18 19:26:20 --> URI Class Initialized
INFO - 2016-05-18 19:26:20 --> Router Class Initialized
INFO - 2016-05-18 19:26:20 --> Output Class Initialized
INFO - 2016-05-18 19:26:20 --> Security Class Initialized
DEBUG - 2016-05-18 19:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:26:20 --> Input Class Initialized
INFO - 2016-05-18 19:26:20 --> Language Class Initialized
INFO - 2016-05-18 19:26:20 --> Loader Class Initialized
INFO - 2016-05-18 19:26:20 --> Helper loaded: url_helper
INFO - 2016-05-18 19:26:20 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:26:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:26:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:26:20 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:26:20 --> Helper loaded: form_helper
INFO - 2016-05-18 19:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:26:20 --> Form Validation Class Initialized
INFO - 2016-05-18 19:26:20 --> Controller Class Initialized
INFO - 2016-05-18 19:26:20 --> Model Class Initialized
INFO - 2016-05-18 19:26:20 --> Database Driver Class Initialized
INFO - 2016-05-18 19:26:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:26:20 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:26:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:26:20 --> Final output sent to browser
DEBUG - 2016-05-18 19:26:20 --> Total execution time: 0.1152
INFO - 2016-05-18 19:26:43 --> Config Class Initialized
INFO - 2016-05-18 19:26:43 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:26:43 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:26:43 --> Utf8 Class Initialized
INFO - 2016-05-18 19:26:43 --> URI Class Initialized
INFO - 2016-05-18 19:26:43 --> Router Class Initialized
INFO - 2016-05-18 19:26:43 --> Output Class Initialized
INFO - 2016-05-18 19:26:43 --> Security Class Initialized
DEBUG - 2016-05-18 19:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:26:43 --> Input Class Initialized
INFO - 2016-05-18 19:26:43 --> Language Class Initialized
INFO - 2016-05-18 19:26:43 --> Loader Class Initialized
INFO - 2016-05-18 19:26:43 --> Helper loaded: url_helper
INFO - 2016-05-18 19:26:43 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:26:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:26:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:26:43 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:26:43 --> Helper loaded: form_helper
INFO - 2016-05-18 19:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:26:43 --> Form Validation Class Initialized
INFO - 2016-05-18 19:26:43 --> Controller Class Initialized
INFO - 2016-05-18 19:26:43 --> Model Class Initialized
INFO - 2016-05-18 19:26:43 --> Database Driver Class Initialized
INFO - 2016-05-18 19:26:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:26:43 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:26:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:26:43 --> Final output sent to browser
DEBUG - 2016-05-18 19:26:43 --> Total execution time: 0.0688
INFO - 2016-05-18 19:27:20 --> Config Class Initialized
INFO - 2016-05-18 19:27:20 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:27:20 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:27:20 --> Utf8 Class Initialized
INFO - 2016-05-18 19:27:20 --> URI Class Initialized
INFO - 2016-05-18 19:27:20 --> Router Class Initialized
INFO - 2016-05-18 19:27:20 --> Output Class Initialized
INFO - 2016-05-18 19:27:20 --> Security Class Initialized
DEBUG - 2016-05-18 19:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:27:20 --> Input Class Initialized
INFO - 2016-05-18 19:27:20 --> Language Class Initialized
INFO - 2016-05-18 19:27:20 --> Loader Class Initialized
INFO - 2016-05-18 19:27:20 --> Helper loaded: url_helper
INFO - 2016-05-18 19:27:20 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:27:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:27:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:27:20 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:27:20 --> Helper loaded: form_helper
INFO - 2016-05-18 19:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:27:20 --> Form Validation Class Initialized
INFO - 2016-05-18 19:27:20 --> Controller Class Initialized
INFO - 2016-05-18 19:27:20 --> Model Class Initialized
INFO - 2016-05-18 19:27:20 --> Database Driver Class Initialized
INFO - 2016-05-18 19:27:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:27:20 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:27:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:27:20 --> Final output sent to browser
DEBUG - 2016-05-18 19:27:20 --> Total execution time: 0.0683
INFO - 2016-05-18 19:27:43 --> Config Class Initialized
INFO - 2016-05-18 19:27:43 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:27:43 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:27:43 --> Utf8 Class Initialized
INFO - 2016-05-18 19:27:43 --> URI Class Initialized
INFO - 2016-05-18 19:27:43 --> Router Class Initialized
INFO - 2016-05-18 19:27:43 --> Output Class Initialized
INFO - 2016-05-18 19:27:43 --> Security Class Initialized
DEBUG - 2016-05-18 19:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:27:43 --> Input Class Initialized
INFO - 2016-05-18 19:27:43 --> Language Class Initialized
INFO - 2016-05-18 19:27:43 --> Loader Class Initialized
INFO - 2016-05-18 19:27:43 --> Helper loaded: url_helper
INFO - 2016-05-18 19:27:43 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:27:43 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:27:43 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:27:43 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:27:43 --> Helper loaded: form_helper
INFO - 2016-05-18 19:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:27:43 --> Form Validation Class Initialized
INFO - 2016-05-18 19:27:43 --> Controller Class Initialized
INFO - 2016-05-18 19:27:43 --> Model Class Initialized
INFO - 2016-05-18 19:27:43 --> Database Driver Class Initialized
INFO - 2016-05-18 19:27:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:27:43 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:27:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:27:43 --> Final output sent to browser
DEBUG - 2016-05-18 19:27:43 --> Total execution time: 0.0719
INFO - 2016-05-18 19:28:02 --> Config Class Initialized
INFO - 2016-05-18 19:28:02 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:28:02 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:28:02 --> Utf8 Class Initialized
INFO - 2016-05-18 19:28:02 --> URI Class Initialized
INFO - 2016-05-18 19:28:02 --> Router Class Initialized
INFO - 2016-05-18 19:28:02 --> Output Class Initialized
INFO - 2016-05-18 19:28:02 --> Security Class Initialized
DEBUG - 2016-05-18 19:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:28:02 --> Input Class Initialized
INFO - 2016-05-18 19:28:02 --> Language Class Initialized
INFO - 2016-05-18 19:28:02 --> Loader Class Initialized
INFO - 2016-05-18 19:28:02 --> Helper loaded: url_helper
INFO - 2016-05-18 19:28:02 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:28:02 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:28:02 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:28:02 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:28:02 --> Helper loaded: form_helper
INFO - 2016-05-18 19:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:28:02 --> Form Validation Class Initialized
INFO - 2016-05-18 19:28:02 --> Controller Class Initialized
INFO - 2016-05-18 19:28:02 --> Model Class Initialized
INFO - 2016-05-18 19:28:02 --> Database Driver Class Initialized
INFO - 2016-05-18 19:28:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:28:02 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:28:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:28:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:28:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:28:02 --> Final output sent to browser
DEBUG - 2016-05-18 19:28:02 --> Total execution time: 0.0786
INFO - 2016-05-18 19:28:03 --> Config Class Initialized
INFO - 2016-05-18 19:28:03 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:28:03 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:28:03 --> Utf8 Class Initialized
INFO - 2016-05-18 19:28:03 --> URI Class Initialized
INFO - 2016-05-18 19:28:03 --> Router Class Initialized
INFO - 2016-05-18 19:28:03 --> Output Class Initialized
INFO - 2016-05-18 19:28:03 --> Security Class Initialized
DEBUG - 2016-05-18 19:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:28:03 --> Input Class Initialized
INFO - 2016-05-18 19:28:03 --> Language Class Initialized
INFO - 2016-05-18 19:28:03 --> Loader Class Initialized
INFO - 2016-05-18 19:28:03 --> Helper loaded: url_helper
INFO - 2016-05-18 19:28:03 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:28:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:28:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:28:03 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:28:03 --> Helper loaded: form_helper
INFO - 2016-05-18 19:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:28:03 --> Form Validation Class Initialized
INFO - 2016-05-18 19:28:03 --> Controller Class Initialized
INFO - 2016-05-18 19:28:03 --> Model Class Initialized
INFO - 2016-05-18 19:28:03 --> Database Driver Class Initialized
INFO - 2016-05-18 19:28:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:28:03 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:28:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:28:03 --> Final output sent to browser
DEBUG - 2016-05-18 19:28:03 --> Total execution time: 0.1369
INFO - 2016-05-18 19:28:07 --> Config Class Initialized
INFO - 2016-05-18 19:28:07 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:28:07 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:28:07 --> Utf8 Class Initialized
INFO - 2016-05-18 19:28:07 --> URI Class Initialized
INFO - 2016-05-18 19:28:07 --> Router Class Initialized
INFO - 2016-05-18 19:28:07 --> Output Class Initialized
INFO - 2016-05-18 19:28:07 --> Security Class Initialized
DEBUG - 2016-05-18 19:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:28:07 --> Input Class Initialized
INFO - 2016-05-18 19:28:07 --> Language Class Initialized
INFO - 2016-05-18 19:28:07 --> Loader Class Initialized
INFO - 2016-05-18 19:28:07 --> Helper loaded: url_helper
INFO - 2016-05-18 19:28:07 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:28:07 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:28:07 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:28:07 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:28:07 --> Helper loaded: form_helper
INFO - 2016-05-18 19:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:28:07 --> Form Validation Class Initialized
INFO - 2016-05-18 19:28:07 --> Controller Class Initialized
INFO - 2016-05-18 19:28:07 --> Model Class Initialized
INFO - 2016-05-18 19:28:07 --> Database Driver Class Initialized
INFO - 2016-05-18 19:28:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:28:07 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:28:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:28:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:28:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:28:07 --> Final output sent to browser
DEBUG - 2016-05-18 19:28:07 --> Total execution time: 0.1048
INFO - 2016-05-18 19:28:08 --> Config Class Initialized
INFO - 2016-05-18 19:28:08 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:28:08 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:28:08 --> Utf8 Class Initialized
INFO - 2016-05-18 19:28:08 --> URI Class Initialized
INFO - 2016-05-18 19:28:08 --> Router Class Initialized
INFO - 2016-05-18 19:28:08 --> Output Class Initialized
INFO - 2016-05-18 19:28:08 --> Security Class Initialized
DEBUG - 2016-05-18 19:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:28:08 --> Input Class Initialized
INFO - 2016-05-18 19:28:08 --> Language Class Initialized
INFO - 2016-05-18 19:28:08 --> Loader Class Initialized
INFO - 2016-05-18 19:28:08 --> Helper loaded: url_helper
INFO - 2016-05-18 19:28:08 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:28:08 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:28:08 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:28:08 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:28:08 --> Helper loaded: form_helper
INFO - 2016-05-18 19:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:28:08 --> Form Validation Class Initialized
INFO - 2016-05-18 19:28:08 --> Controller Class Initialized
INFO - 2016-05-18 19:28:08 --> Model Class Initialized
INFO - 2016-05-18 19:28:08 --> Database Driver Class Initialized
INFO - 2016-05-18 19:28:08 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:28:08 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:28:08 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:28:08 --> Final output sent to browser
DEBUG - 2016-05-18 19:28:08 --> Total execution time: 0.1316
INFO - 2016-05-18 19:28:20 --> Config Class Initialized
INFO - 2016-05-18 19:28:20 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:28:20 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:28:20 --> Utf8 Class Initialized
INFO - 2016-05-18 19:28:20 --> URI Class Initialized
INFO - 2016-05-18 19:28:20 --> Router Class Initialized
INFO - 2016-05-18 19:28:20 --> Output Class Initialized
INFO - 2016-05-18 19:28:20 --> Security Class Initialized
DEBUG - 2016-05-18 19:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:28:20 --> Input Class Initialized
INFO - 2016-05-18 19:28:20 --> Language Class Initialized
INFO - 2016-05-18 19:28:20 --> Loader Class Initialized
INFO - 2016-05-18 19:28:20 --> Helper loaded: url_helper
INFO - 2016-05-18 19:28:20 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:28:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:28:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:28:20 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:28:20 --> Helper loaded: form_helper
INFO - 2016-05-18 19:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:28:20 --> Form Validation Class Initialized
INFO - 2016-05-18 19:28:20 --> Controller Class Initialized
INFO - 2016-05-18 19:28:20 --> Model Class Initialized
INFO - 2016-05-18 19:28:20 --> Database Driver Class Initialized
INFO - 2016-05-18 19:28:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:28:20 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:28:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:28:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:28:20 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:28:20 --> Final output sent to browser
DEBUG - 2016-05-18 19:28:20 --> Total execution time: 0.0834
INFO - 2016-05-18 19:28:20 --> Config Class Initialized
INFO - 2016-05-18 19:28:20 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:28:20 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:28:20 --> Utf8 Class Initialized
INFO - 2016-05-18 19:28:20 --> URI Class Initialized
INFO - 2016-05-18 19:28:20 --> Router Class Initialized
INFO - 2016-05-18 19:28:20 --> Output Class Initialized
INFO - 2016-05-18 19:28:20 --> Security Class Initialized
DEBUG - 2016-05-18 19:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:28:20 --> Input Class Initialized
INFO - 2016-05-18 19:28:20 --> Language Class Initialized
INFO - 2016-05-18 19:28:20 --> Loader Class Initialized
INFO - 2016-05-18 19:28:20 --> Helper loaded: url_helper
INFO - 2016-05-18 19:28:20 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:28:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:28:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:28:20 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:28:20 --> Helper loaded: form_helper
INFO - 2016-05-18 19:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:28:20 --> Form Validation Class Initialized
INFO - 2016-05-18 19:28:20 --> Controller Class Initialized
INFO - 2016-05-18 19:28:20 --> Model Class Initialized
INFO - 2016-05-18 19:28:20 --> Database Driver Class Initialized
INFO - 2016-05-18 19:28:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:28:20 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:28:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:28:20 --> Final output sent to browser
DEBUG - 2016-05-18 19:28:20 --> Total execution time: 0.1192
INFO - 2016-05-18 19:28:25 --> Config Class Initialized
INFO - 2016-05-18 19:28:25 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:28:25 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:28:25 --> Utf8 Class Initialized
INFO - 2016-05-18 19:28:25 --> URI Class Initialized
INFO - 2016-05-18 19:28:25 --> Router Class Initialized
INFO - 2016-05-18 19:28:25 --> Output Class Initialized
INFO - 2016-05-18 19:28:25 --> Security Class Initialized
DEBUG - 2016-05-18 19:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:28:25 --> Input Class Initialized
INFO - 2016-05-18 19:28:25 --> Language Class Initialized
INFO - 2016-05-18 19:28:25 --> Loader Class Initialized
INFO - 2016-05-18 19:28:25 --> Helper loaded: url_helper
INFO - 2016-05-18 19:28:25 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:28:25 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:28:25 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:28:25 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:28:25 --> Helper loaded: form_helper
INFO - 2016-05-18 19:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:28:25 --> Form Validation Class Initialized
INFO - 2016-05-18 19:28:25 --> Controller Class Initialized
INFO - 2016-05-18 19:28:25 --> Config Class Initialized
INFO - 2016-05-18 19:28:25 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:28:25 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:28:25 --> Utf8 Class Initialized
INFO - 2016-05-18 19:28:25 --> URI Class Initialized
INFO - 2016-05-18 19:28:26 --> Router Class Initialized
INFO - 2016-05-18 19:28:26 --> Output Class Initialized
INFO - 2016-05-18 19:28:26 --> Security Class Initialized
DEBUG - 2016-05-18 19:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:28:26 --> Input Class Initialized
INFO - 2016-05-18 19:28:26 --> Language Class Initialized
INFO - 2016-05-18 19:28:26 --> Loader Class Initialized
INFO - 2016-05-18 19:28:26 --> Helper loaded: url_helper
INFO - 2016-05-18 19:28:26 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:28:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:28:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:28:26 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:28:26 --> Helper loaded: form_helper
INFO - 2016-05-18 19:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:28:26 --> Form Validation Class Initialized
INFO - 2016-05-18 19:28:26 --> Controller Class Initialized
INFO - 2016-05-18 19:28:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-18 19:28:26 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:28:26 --> Final output sent to browser
DEBUG - 2016-05-18 19:28:26 --> Total execution time: 0.0812
INFO - 2016-05-18 19:28:26 --> Config Class Initialized
INFO - 2016-05-18 19:28:26 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:28:26 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:28:26 --> Utf8 Class Initialized
INFO - 2016-05-18 19:28:26 --> URI Class Initialized
INFO - 2016-05-18 19:28:26 --> Router Class Initialized
INFO - 2016-05-18 19:28:26 --> Output Class Initialized
INFO - 2016-05-18 19:28:26 --> Security Class Initialized
DEBUG - 2016-05-18 19:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:28:26 --> Input Class Initialized
INFO - 2016-05-18 19:28:26 --> Language Class Initialized
INFO - 2016-05-18 19:28:26 --> Loader Class Initialized
INFO - 2016-05-18 19:28:26 --> Helper loaded: url_helper
INFO - 2016-05-18 19:28:26 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:28:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:28:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:28:26 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:28:26 --> Helper loaded: form_helper
INFO - 2016-05-18 19:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:28:26 --> Form Validation Class Initialized
INFO - 2016-05-18 19:28:26 --> Controller Class Initialized
INFO - 2016-05-18 19:28:26 --> Model Class Initialized
INFO - 2016-05-18 19:28:26 --> Database Driver Class Initialized
INFO - 2016-05-18 19:28:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:28:26 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:28:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:28:26 --> Final output sent to browser
DEBUG - 2016-05-18 19:28:26 --> Total execution time: 0.1266
INFO - 2016-05-18 19:28:27 --> Config Class Initialized
INFO - 2016-05-18 19:28:27 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:28:27 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:28:27 --> Utf8 Class Initialized
INFO - 2016-05-18 19:28:27 --> URI Class Initialized
INFO - 2016-05-18 19:28:27 --> Router Class Initialized
INFO - 2016-05-18 19:28:27 --> Output Class Initialized
INFO - 2016-05-18 19:28:27 --> Security Class Initialized
DEBUG - 2016-05-18 19:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:28:27 --> Input Class Initialized
INFO - 2016-05-18 19:28:27 --> Language Class Initialized
INFO - 2016-05-18 19:28:27 --> Loader Class Initialized
INFO - 2016-05-18 19:28:27 --> Helper loaded: url_helper
INFO - 2016-05-18 19:28:27 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:28:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:28:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:28:27 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:28:27 --> Helper loaded: form_helper
INFO - 2016-05-18 19:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:28:27 --> Form Validation Class Initialized
INFO - 2016-05-18 19:28:27 --> Controller Class Initialized
INFO - 2016-05-18 19:28:27 --> Model Class Initialized
INFO - 2016-05-18 19:28:27 --> Database Driver Class Initialized
INFO - 2016-05-18 19:28:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:28:27 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:28:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:28:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:28:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:28:27 --> Final output sent to browser
DEBUG - 2016-05-18 19:28:27 --> Total execution time: 0.0814
INFO - 2016-05-18 19:28:27 --> Config Class Initialized
INFO - 2016-05-18 19:28:27 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:28:27 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:28:27 --> Utf8 Class Initialized
INFO - 2016-05-18 19:28:27 --> URI Class Initialized
INFO - 2016-05-18 19:28:27 --> Router Class Initialized
INFO - 2016-05-18 19:28:27 --> Output Class Initialized
INFO - 2016-05-18 19:28:27 --> Security Class Initialized
DEBUG - 2016-05-18 19:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:28:27 --> Input Class Initialized
INFO - 2016-05-18 19:28:27 --> Language Class Initialized
INFO - 2016-05-18 19:28:27 --> Loader Class Initialized
INFO - 2016-05-18 19:28:27 --> Helper loaded: url_helper
INFO - 2016-05-18 19:28:27 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:28:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:28:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:28:27 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:28:27 --> Helper loaded: form_helper
INFO - 2016-05-18 19:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:28:27 --> Form Validation Class Initialized
INFO - 2016-05-18 19:28:27 --> Controller Class Initialized
INFO - 2016-05-18 19:28:27 --> Model Class Initialized
INFO - 2016-05-18 19:28:27 --> Database Driver Class Initialized
INFO - 2016-05-18 19:28:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:28:27 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:28:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:28:27 --> Final output sent to browser
DEBUG - 2016-05-18 19:28:27 --> Total execution time: 0.1276
INFO - 2016-05-18 19:29:19 --> Config Class Initialized
INFO - 2016-05-18 19:29:19 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:29:19 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:29:19 --> Utf8 Class Initialized
INFO - 2016-05-18 19:29:19 --> URI Class Initialized
INFO - 2016-05-18 19:29:19 --> Router Class Initialized
INFO - 2016-05-18 19:29:19 --> Output Class Initialized
INFO - 2016-05-18 19:29:19 --> Security Class Initialized
DEBUG - 2016-05-18 19:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:29:19 --> Input Class Initialized
INFO - 2016-05-18 19:29:19 --> Language Class Initialized
INFO - 2016-05-18 19:29:19 --> Loader Class Initialized
INFO - 2016-05-18 19:29:19 --> Helper loaded: url_helper
INFO - 2016-05-18 19:29:19 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:29:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:29:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:29:19 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:29:19 --> Helper loaded: form_helper
INFO - 2016-05-18 19:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:29:19 --> Form Validation Class Initialized
INFO - 2016-05-18 19:29:19 --> Controller Class Initialized
INFO - 2016-05-18 19:29:19 --> Model Class Initialized
INFO - 2016-05-18 19:29:19 --> Database Driver Class Initialized
INFO - 2016-05-18 19:29:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:29:19 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:29:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:29:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:29:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:29:19 --> Final output sent to browser
DEBUG - 2016-05-18 19:29:19 --> Total execution time: 0.0801
INFO - 2016-05-18 19:29:19 --> Config Class Initialized
INFO - 2016-05-18 19:29:19 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:29:19 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:29:19 --> Utf8 Class Initialized
INFO - 2016-05-18 19:29:19 --> URI Class Initialized
INFO - 2016-05-18 19:29:19 --> Router Class Initialized
INFO - 2016-05-18 19:29:19 --> Output Class Initialized
INFO - 2016-05-18 19:29:19 --> Security Class Initialized
DEBUG - 2016-05-18 19:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:29:19 --> Input Class Initialized
INFO - 2016-05-18 19:29:19 --> Language Class Initialized
INFO - 2016-05-18 19:29:19 --> Loader Class Initialized
INFO - 2016-05-18 19:29:19 --> Helper loaded: url_helper
INFO - 2016-05-18 19:29:19 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:29:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:29:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:29:19 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:29:19 --> Helper loaded: form_helper
INFO - 2016-05-18 19:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:29:19 --> Form Validation Class Initialized
INFO - 2016-05-18 19:29:19 --> Controller Class Initialized
INFO - 2016-05-18 19:29:19 --> Model Class Initialized
INFO - 2016-05-18 19:29:19 --> Database Driver Class Initialized
INFO - 2016-05-18 19:29:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:29:19 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:29:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:29:19 --> Final output sent to browser
DEBUG - 2016-05-18 19:29:19 --> Total execution time: 0.0961
INFO - 2016-05-18 19:29:26 --> Config Class Initialized
INFO - 2016-05-18 19:29:26 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:29:26 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:29:26 --> Utf8 Class Initialized
INFO - 2016-05-18 19:29:26 --> URI Class Initialized
INFO - 2016-05-18 19:29:26 --> Router Class Initialized
INFO - 2016-05-18 19:29:26 --> Output Class Initialized
INFO - 2016-05-18 19:29:26 --> Security Class Initialized
DEBUG - 2016-05-18 19:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:29:26 --> Input Class Initialized
INFO - 2016-05-18 19:29:26 --> Language Class Initialized
INFO - 2016-05-18 19:29:26 --> Loader Class Initialized
INFO - 2016-05-18 19:29:26 --> Helper loaded: url_helper
INFO - 2016-05-18 19:29:26 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:29:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:29:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:29:26 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:29:26 --> Helper loaded: form_helper
INFO - 2016-05-18 19:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:29:26 --> Form Validation Class Initialized
INFO - 2016-05-18 19:29:26 --> Controller Class Initialized
INFO - 2016-05-18 19:29:26 --> Model Class Initialized
INFO - 2016-05-18 19:29:26 --> Database Driver Class Initialized
INFO - 2016-05-18 19:29:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:29:26 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:29:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:29:26 --> Final output sent to browser
DEBUG - 2016-05-18 19:29:26 --> Total execution time: 0.0664
INFO - 2016-05-18 19:29:29 --> Config Class Initialized
INFO - 2016-05-18 19:29:29 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:29:29 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:29:29 --> Utf8 Class Initialized
INFO - 2016-05-18 19:29:29 --> URI Class Initialized
INFO - 2016-05-18 19:29:29 --> Router Class Initialized
INFO - 2016-05-18 19:29:29 --> Output Class Initialized
INFO - 2016-05-18 19:29:29 --> Security Class Initialized
DEBUG - 2016-05-18 19:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:29:29 --> Input Class Initialized
INFO - 2016-05-18 19:29:29 --> Language Class Initialized
INFO - 2016-05-18 19:29:29 --> Loader Class Initialized
INFO - 2016-05-18 19:29:29 --> Helper loaded: url_helper
INFO - 2016-05-18 19:29:29 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:29:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:29:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:29:29 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:29:29 --> Helper loaded: form_helper
INFO - 2016-05-18 19:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:29:29 --> Form Validation Class Initialized
INFO - 2016-05-18 19:29:29 --> Controller Class Initialized
INFO - 2016-05-18 19:29:29 --> Model Class Initialized
INFO - 2016-05-18 19:29:29 --> Database Driver Class Initialized
INFO - 2016-05-18 19:29:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:29:29 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:29:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:29:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:29:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:29:29 --> Final output sent to browser
DEBUG - 2016-05-18 19:29:29 --> Total execution time: 0.0885
INFO - 2016-05-18 19:29:29 --> Config Class Initialized
INFO - 2016-05-18 19:29:29 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:29:29 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:29:29 --> Utf8 Class Initialized
INFO - 2016-05-18 19:29:29 --> URI Class Initialized
INFO - 2016-05-18 19:29:29 --> Router Class Initialized
INFO - 2016-05-18 19:29:29 --> Output Class Initialized
INFO - 2016-05-18 19:29:29 --> Security Class Initialized
DEBUG - 2016-05-18 19:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:29:29 --> Input Class Initialized
INFO - 2016-05-18 19:29:29 --> Language Class Initialized
INFO - 2016-05-18 19:29:29 --> Loader Class Initialized
INFO - 2016-05-18 19:29:29 --> Helper loaded: url_helper
INFO - 2016-05-18 19:29:29 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:29:29 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:29:29 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:29:29 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:29:29 --> Helper loaded: form_helper
INFO - 2016-05-18 19:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:29:29 --> Form Validation Class Initialized
INFO - 2016-05-18 19:29:29 --> Controller Class Initialized
INFO - 2016-05-18 19:29:29 --> Model Class Initialized
INFO - 2016-05-18 19:29:29 --> Database Driver Class Initialized
INFO - 2016-05-18 19:29:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:29:29 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:29:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:29:29 --> Final output sent to browser
DEBUG - 2016-05-18 19:29:29 --> Total execution time: 0.1044
INFO - 2016-05-18 19:29:48 --> Config Class Initialized
INFO - 2016-05-18 19:29:48 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:29:48 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:29:48 --> Utf8 Class Initialized
INFO - 2016-05-18 19:29:48 --> URI Class Initialized
INFO - 2016-05-18 19:29:48 --> Router Class Initialized
INFO - 2016-05-18 19:29:48 --> Output Class Initialized
INFO - 2016-05-18 19:29:48 --> Security Class Initialized
DEBUG - 2016-05-18 19:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:29:48 --> Input Class Initialized
INFO - 2016-05-18 19:29:48 --> Language Class Initialized
INFO - 2016-05-18 19:29:48 --> Loader Class Initialized
INFO - 2016-05-18 19:29:48 --> Helper loaded: url_helper
INFO - 2016-05-18 19:29:48 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:29:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:29:48 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:29:48 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:29:48 --> Helper loaded: form_helper
INFO - 2016-05-18 19:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:29:48 --> Form Validation Class Initialized
INFO - 2016-05-18 19:29:48 --> Controller Class Initialized
INFO - 2016-05-18 19:29:48 --> Model Class Initialized
INFO - 2016-05-18 19:29:48 --> Database Driver Class Initialized
INFO - 2016-05-18 19:29:48 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:29:48 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:29:48 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:29:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:29:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:29:48 --> Final output sent to browser
DEBUG - 2016-05-18 19:29:48 --> Total execution time: 0.0902
INFO - 2016-05-18 19:29:49 --> Config Class Initialized
INFO - 2016-05-18 19:29:49 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:29:49 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:29:49 --> Utf8 Class Initialized
INFO - 2016-05-18 19:29:49 --> URI Class Initialized
INFO - 2016-05-18 19:29:49 --> Router Class Initialized
INFO - 2016-05-18 19:29:49 --> Output Class Initialized
INFO - 2016-05-18 19:29:49 --> Security Class Initialized
DEBUG - 2016-05-18 19:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:29:49 --> Input Class Initialized
INFO - 2016-05-18 19:29:49 --> Language Class Initialized
INFO - 2016-05-18 19:29:49 --> Loader Class Initialized
INFO - 2016-05-18 19:29:49 --> Helper loaded: url_helper
INFO - 2016-05-18 19:29:49 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:29:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:29:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:29:49 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:29:49 --> Helper loaded: form_helper
INFO - 2016-05-18 19:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:29:49 --> Form Validation Class Initialized
INFO - 2016-05-18 19:29:49 --> Controller Class Initialized
INFO - 2016-05-18 19:29:49 --> Model Class Initialized
INFO - 2016-05-18 19:29:49 --> Database Driver Class Initialized
INFO - 2016-05-18 19:29:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:29:49 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:29:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:29:49 --> Final output sent to browser
DEBUG - 2016-05-18 19:29:49 --> Total execution time: 0.1053
INFO - 2016-05-18 19:30:26 --> Config Class Initialized
INFO - 2016-05-18 19:30:26 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:30:26 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:30:26 --> Utf8 Class Initialized
INFO - 2016-05-18 19:30:26 --> URI Class Initialized
INFO - 2016-05-18 19:30:26 --> Router Class Initialized
INFO - 2016-05-18 19:30:26 --> Output Class Initialized
INFO - 2016-05-18 19:30:26 --> Security Class Initialized
DEBUG - 2016-05-18 19:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:30:26 --> Input Class Initialized
INFO - 2016-05-18 19:30:26 --> Language Class Initialized
INFO - 2016-05-18 19:30:26 --> Loader Class Initialized
INFO - 2016-05-18 19:30:26 --> Helper loaded: url_helper
INFO - 2016-05-18 19:30:26 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:30:26 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:30:26 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:30:26 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:30:26 --> Helper loaded: form_helper
INFO - 2016-05-18 19:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:30:26 --> Form Validation Class Initialized
INFO - 2016-05-18 19:30:26 --> Controller Class Initialized
INFO - 2016-05-18 19:30:26 --> Model Class Initialized
INFO - 2016-05-18 19:30:26 --> Database Driver Class Initialized
INFO - 2016-05-18 19:30:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:30:26 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:30:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:30:26 --> Final output sent to browser
DEBUG - 2016-05-18 19:30:26 --> Total execution time: 0.0875
INFO - 2016-05-18 19:30:49 --> Config Class Initialized
INFO - 2016-05-18 19:30:49 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:30:49 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:30:49 --> Utf8 Class Initialized
INFO - 2016-05-18 19:30:49 --> URI Class Initialized
INFO - 2016-05-18 19:30:49 --> Router Class Initialized
INFO - 2016-05-18 19:30:49 --> Output Class Initialized
INFO - 2016-05-18 19:30:49 --> Security Class Initialized
DEBUG - 2016-05-18 19:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:30:49 --> Input Class Initialized
INFO - 2016-05-18 19:30:49 --> Language Class Initialized
INFO - 2016-05-18 19:30:49 --> Loader Class Initialized
INFO - 2016-05-18 19:30:49 --> Helper loaded: url_helper
INFO - 2016-05-18 19:30:49 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:30:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:30:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:30:49 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:30:49 --> Helper loaded: form_helper
INFO - 2016-05-18 19:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:30:49 --> Form Validation Class Initialized
INFO - 2016-05-18 19:30:49 --> Controller Class Initialized
INFO - 2016-05-18 19:30:49 --> Model Class Initialized
INFO - 2016-05-18 19:30:49 --> Database Driver Class Initialized
INFO - 2016-05-18 19:30:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:30:49 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:30:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:30:49 --> Final output sent to browser
DEBUG - 2016-05-18 19:30:49 --> Total execution time: 0.0687
INFO - 2016-05-18 19:31:49 --> Config Class Initialized
INFO - 2016-05-18 19:31:49 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:31:49 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:31:49 --> Utf8 Class Initialized
INFO - 2016-05-18 19:31:49 --> URI Class Initialized
INFO - 2016-05-18 19:31:49 --> Router Class Initialized
INFO - 2016-05-18 19:31:49 --> Output Class Initialized
INFO - 2016-05-18 19:31:49 --> Security Class Initialized
DEBUG - 2016-05-18 19:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:31:49 --> Input Class Initialized
INFO - 2016-05-18 19:31:49 --> Language Class Initialized
INFO - 2016-05-18 19:31:49 --> Loader Class Initialized
INFO - 2016-05-18 19:31:49 --> Helper loaded: url_helper
INFO - 2016-05-18 19:31:49 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:31:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:31:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:31:49 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:31:49 --> Helper loaded: form_helper
INFO - 2016-05-18 19:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:31:49 --> Form Validation Class Initialized
INFO - 2016-05-18 19:31:49 --> Controller Class Initialized
INFO - 2016-05-18 19:31:49 --> Model Class Initialized
INFO - 2016-05-18 19:31:49 --> Database Driver Class Initialized
INFO - 2016-05-18 19:31:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:31:49 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:31:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:31:49 --> Final output sent to browser
DEBUG - 2016-05-18 19:31:49 --> Total execution time: 0.0679
INFO - 2016-05-18 19:32:49 --> Config Class Initialized
INFO - 2016-05-18 19:32:49 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:32:49 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:32:49 --> Utf8 Class Initialized
INFO - 2016-05-18 19:32:49 --> URI Class Initialized
INFO - 2016-05-18 19:32:49 --> Router Class Initialized
INFO - 2016-05-18 19:32:49 --> Output Class Initialized
INFO - 2016-05-18 19:32:49 --> Security Class Initialized
DEBUG - 2016-05-18 19:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:32:49 --> Input Class Initialized
INFO - 2016-05-18 19:32:49 --> Language Class Initialized
INFO - 2016-05-18 19:32:49 --> Loader Class Initialized
INFO - 2016-05-18 19:32:49 --> Helper loaded: url_helper
INFO - 2016-05-18 19:32:49 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:32:49 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:32:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:32:49 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:32:49 --> Helper loaded: form_helper
INFO - 2016-05-18 19:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:32:49 --> Form Validation Class Initialized
INFO - 2016-05-18 19:32:49 --> Controller Class Initialized
INFO - 2016-05-18 19:32:49 --> Model Class Initialized
INFO - 2016-05-18 19:32:49 --> Database Driver Class Initialized
INFO - 2016-05-18 19:32:49 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:32:49 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:32:49 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:32:49 --> Final output sent to browser
DEBUG - 2016-05-18 19:32:49 --> Total execution time: 0.0790
INFO - 2016-05-18 19:32:57 --> Config Class Initialized
INFO - 2016-05-18 19:32:57 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:32:57 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:32:57 --> Utf8 Class Initialized
INFO - 2016-05-18 19:32:57 --> URI Class Initialized
INFO - 2016-05-18 19:32:57 --> Router Class Initialized
INFO - 2016-05-18 19:32:57 --> Output Class Initialized
INFO - 2016-05-18 19:32:57 --> Security Class Initialized
DEBUG - 2016-05-18 19:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:32:57 --> Input Class Initialized
INFO - 2016-05-18 19:32:57 --> Language Class Initialized
INFO - 2016-05-18 19:32:57 --> Loader Class Initialized
INFO - 2016-05-18 19:32:57 --> Helper loaded: url_helper
INFO - 2016-05-18 19:32:57 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:32:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:32:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:32:57 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:32:57 --> Helper loaded: form_helper
INFO - 2016-05-18 19:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:32:57 --> Form Validation Class Initialized
INFO - 2016-05-18 19:32:57 --> Controller Class Initialized
INFO - 2016-05-18 19:32:57 --> Model Class Initialized
INFO - 2016-05-18 19:32:57 --> Database Driver Class Initialized
INFO - 2016-05-18 19:32:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:32:57 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:32:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:32:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:32:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:32:57 --> Final output sent to browser
DEBUG - 2016-05-18 19:32:57 --> Total execution time: 0.0927
INFO - 2016-05-18 19:32:57 --> Config Class Initialized
INFO - 2016-05-18 19:32:57 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:32:57 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:32:57 --> Utf8 Class Initialized
INFO - 2016-05-18 19:32:57 --> URI Class Initialized
INFO - 2016-05-18 19:32:57 --> Router Class Initialized
INFO - 2016-05-18 19:32:57 --> Output Class Initialized
INFO - 2016-05-18 19:32:57 --> Security Class Initialized
DEBUG - 2016-05-18 19:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:32:57 --> Input Class Initialized
INFO - 2016-05-18 19:32:57 --> Language Class Initialized
INFO - 2016-05-18 19:32:57 --> Loader Class Initialized
INFO - 2016-05-18 19:32:57 --> Helper loaded: url_helper
INFO - 2016-05-18 19:32:57 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:32:57 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:32:57 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:32:57 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:32:57 --> Helper loaded: form_helper
INFO - 2016-05-18 19:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:32:57 --> Form Validation Class Initialized
INFO - 2016-05-18 19:32:57 --> Controller Class Initialized
INFO - 2016-05-18 19:32:57 --> Model Class Initialized
INFO - 2016-05-18 19:32:57 --> Database Driver Class Initialized
INFO - 2016-05-18 19:32:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:32:57 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:32:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:32:57 --> Final output sent to browser
DEBUG - 2016-05-18 19:32:57 --> Total execution time: 0.1646
INFO - 2016-05-18 19:33:03 --> Config Class Initialized
INFO - 2016-05-18 19:33:03 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:33:03 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:33:03 --> Utf8 Class Initialized
INFO - 2016-05-18 19:33:03 --> URI Class Initialized
INFO - 2016-05-18 19:33:03 --> Router Class Initialized
INFO - 2016-05-18 19:33:03 --> Output Class Initialized
INFO - 2016-05-18 19:33:03 --> Security Class Initialized
DEBUG - 2016-05-18 19:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:33:03 --> Input Class Initialized
INFO - 2016-05-18 19:33:03 --> Language Class Initialized
INFO - 2016-05-18 19:33:03 --> Loader Class Initialized
INFO - 2016-05-18 19:33:03 --> Helper loaded: url_helper
INFO - 2016-05-18 19:33:03 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:33:03 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:33:03 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:33:03 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:33:03 --> Helper loaded: form_helper
INFO - 2016-05-18 19:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:33:03 --> Form Validation Class Initialized
INFO - 2016-05-18 19:33:03 --> Controller Class Initialized
INFO - 2016-05-18 19:33:03 --> Model Class Initialized
INFO - 2016-05-18 19:33:03 --> Database Driver Class Initialized
INFO - 2016-05-18 19:33:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:33:03 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:33:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:33:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:33:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:33:03 --> Final output sent to browser
DEBUG - 2016-05-18 19:33:03 --> Total execution time: 0.0853
INFO - 2016-05-18 19:33:04 --> Config Class Initialized
INFO - 2016-05-18 19:33:04 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:33:04 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:33:04 --> Utf8 Class Initialized
INFO - 2016-05-18 19:33:04 --> URI Class Initialized
INFO - 2016-05-18 19:33:04 --> Router Class Initialized
INFO - 2016-05-18 19:33:04 --> Output Class Initialized
INFO - 2016-05-18 19:33:04 --> Security Class Initialized
DEBUG - 2016-05-18 19:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:33:04 --> Input Class Initialized
INFO - 2016-05-18 19:33:04 --> Language Class Initialized
INFO - 2016-05-18 19:33:04 --> Loader Class Initialized
INFO - 2016-05-18 19:33:04 --> Helper loaded: url_helper
INFO - 2016-05-18 19:33:04 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:33:04 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:33:04 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:33:04 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:33:04 --> Helper loaded: form_helper
INFO - 2016-05-18 19:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:33:04 --> Form Validation Class Initialized
INFO - 2016-05-18 19:33:04 --> Controller Class Initialized
INFO - 2016-05-18 19:33:04 --> Model Class Initialized
INFO - 2016-05-18 19:33:04 --> Database Driver Class Initialized
INFO - 2016-05-18 19:33:04 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:33:04 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:33:04 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:33:04 --> Final output sent to browser
DEBUG - 2016-05-18 19:33:04 --> Total execution time: 0.1245
INFO - 2016-05-18 19:33:17 --> Config Class Initialized
INFO - 2016-05-18 19:33:17 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:33:17 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:33:17 --> Utf8 Class Initialized
INFO - 2016-05-18 19:33:17 --> URI Class Initialized
INFO - 2016-05-18 19:33:17 --> Router Class Initialized
INFO - 2016-05-18 19:33:17 --> Output Class Initialized
INFO - 2016-05-18 19:33:17 --> Security Class Initialized
DEBUG - 2016-05-18 19:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:33:17 --> Input Class Initialized
INFO - 2016-05-18 19:33:17 --> Language Class Initialized
INFO - 2016-05-18 19:33:17 --> Loader Class Initialized
INFO - 2016-05-18 19:33:17 --> Helper loaded: url_helper
INFO - 2016-05-18 19:33:17 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:33:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:33:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:33:17 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:33:17 --> Helper loaded: form_helper
INFO - 2016-05-18 19:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:33:17 --> Form Validation Class Initialized
INFO - 2016-05-18 19:33:17 --> Controller Class Initialized
INFO - 2016-05-18 19:33:17 --> Model Class Initialized
INFO - 2016-05-18 19:33:17 --> Database Driver Class Initialized
INFO - 2016-05-18 19:33:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:33:17 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:33:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:33:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:33:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:33:17 --> Final output sent to browser
DEBUG - 2016-05-18 19:33:17 --> Total execution time: 0.1173
INFO - 2016-05-18 19:33:17 --> Config Class Initialized
INFO - 2016-05-18 19:33:17 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:33:17 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:33:17 --> Utf8 Class Initialized
INFO - 2016-05-18 19:33:17 --> URI Class Initialized
INFO - 2016-05-18 19:33:17 --> Router Class Initialized
INFO - 2016-05-18 19:33:17 --> Output Class Initialized
INFO - 2016-05-18 19:33:17 --> Security Class Initialized
DEBUG - 2016-05-18 19:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:33:17 --> Input Class Initialized
INFO - 2016-05-18 19:33:17 --> Language Class Initialized
INFO - 2016-05-18 19:33:17 --> Loader Class Initialized
INFO - 2016-05-18 19:33:17 --> Helper loaded: url_helper
INFO - 2016-05-18 19:33:17 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:33:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:33:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:33:17 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:33:17 --> Helper loaded: form_helper
INFO - 2016-05-18 19:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:33:17 --> Form Validation Class Initialized
INFO - 2016-05-18 19:33:17 --> Controller Class Initialized
INFO - 2016-05-18 19:33:17 --> Model Class Initialized
INFO - 2016-05-18 19:33:17 --> Database Driver Class Initialized
INFO - 2016-05-18 19:33:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:33:17 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:33:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:33:17 --> Final output sent to browser
DEBUG - 2016-05-18 19:33:17 --> Total execution time: 0.1091
INFO - 2016-05-18 19:34:17 --> Config Class Initialized
INFO - 2016-05-18 19:34:17 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:34:17 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:34:17 --> Utf8 Class Initialized
INFO - 2016-05-18 19:34:17 --> URI Class Initialized
INFO - 2016-05-18 19:34:17 --> Router Class Initialized
INFO - 2016-05-18 19:34:17 --> Output Class Initialized
INFO - 2016-05-18 19:34:17 --> Security Class Initialized
DEBUG - 2016-05-18 19:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:34:17 --> Input Class Initialized
INFO - 2016-05-18 19:34:17 --> Language Class Initialized
INFO - 2016-05-18 19:34:17 --> Loader Class Initialized
INFO - 2016-05-18 19:34:17 --> Helper loaded: url_helper
INFO - 2016-05-18 19:34:17 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:34:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:34:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:34:17 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:34:17 --> Helper loaded: form_helper
INFO - 2016-05-18 19:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:34:17 --> Form Validation Class Initialized
INFO - 2016-05-18 19:34:17 --> Controller Class Initialized
INFO - 2016-05-18 19:34:17 --> Model Class Initialized
INFO - 2016-05-18 19:34:17 --> Database Driver Class Initialized
INFO - 2016-05-18 19:34:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:34:17 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:34:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:34:17 --> Final output sent to browser
DEBUG - 2016-05-18 19:34:17 --> Total execution time: 0.0812
INFO - 2016-05-18 19:35:12 --> Config Class Initialized
INFO - 2016-05-18 19:35:12 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:35:12 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:35:12 --> Utf8 Class Initialized
INFO - 2016-05-18 19:35:12 --> URI Class Initialized
INFO - 2016-05-18 19:35:12 --> Router Class Initialized
INFO - 2016-05-18 19:35:12 --> Output Class Initialized
INFO - 2016-05-18 19:35:12 --> Security Class Initialized
DEBUG - 2016-05-18 19:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:35:12 --> Input Class Initialized
INFO - 2016-05-18 19:35:12 --> Language Class Initialized
INFO - 2016-05-18 19:35:12 --> Loader Class Initialized
INFO - 2016-05-18 19:35:12 --> Helper loaded: url_helper
INFO - 2016-05-18 19:35:12 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:35:12 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:35:12 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:35:12 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:35:12 --> Helper loaded: form_helper
INFO - 2016-05-18 19:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:35:12 --> Form Validation Class Initialized
INFO - 2016-05-18 19:35:12 --> Controller Class Initialized
INFO - 2016-05-18 19:35:12 --> Model Class Initialized
INFO - 2016-05-18 19:35:12 --> Database Driver Class Initialized
INFO - 2016-05-18 19:35:12 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:35:12 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:35:12 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-18 19:35:12 --> Severity: Notice --> Undefined index: idFacturas C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php 40
ERROR - 2016-05-18 19:35:12 --> Severity: Notice --> Undefined index: idFacturas C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php 40
INFO - 2016-05-18 19:35:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:35:12 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:35:12 --> Final output sent to browser
DEBUG - 2016-05-18 19:35:12 --> Total execution time: 0.1340
INFO - 2016-05-18 19:35:13 --> Config Class Initialized
INFO - 2016-05-18 19:35:13 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:35:13 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:35:13 --> Utf8 Class Initialized
INFO - 2016-05-18 19:35:13 --> URI Class Initialized
INFO - 2016-05-18 19:35:13 --> Router Class Initialized
INFO - 2016-05-18 19:35:13 --> Output Class Initialized
INFO - 2016-05-18 19:35:13 --> Security Class Initialized
DEBUG - 2016-05-18 19:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:35:13 --> Input Class Initialized
INFO - 2016-05-18 19:35:13 --> Language Class Initialized
INFO - 2016-05-18 19:35:13 --> Loader Class Initialized
INFO - 2016-05-18 19:35:13 --> Helper loaded: url_helper
INFO - 2016-05-18 19:35:13 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:35:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:35:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:35:13 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:35:13 --> Helper loaded: form_helper
INFO - 2016-05-18 19:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:35:13 --> Form Validation Class Initialized
INFO - 2016-05-18 19:35:13 --> Controller Class Initialized
INFO - 2016-05-18 19:35:13 --> Model Class Initialized
INFO - 2016-05-18 19:35:13 --> Database Driver Class Initialized
INFO - 2016-05-18 19:35:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:35:13 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:35:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:35:13 --> Final output sent to browser
DEBUG - 2016-05-18 19:35:13 --> Total execution time: 0.1108
INFO - 2016-05-18 19:35:17 --> Config Class Initialized
INFO - 2016-05-18 19:35:17 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:35:17 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:35:17 --> Utf8 Class Initialized
INFO - 2016-05-18 19:35:17 --> URI Class Initialized
INFO - 2016-05-18 19:35:17 --> Router Class Initialized
INFO - 2016-05-18 19:35:17 --> Output Class Initialized
INFO - 2016-05-18 19:35:17 --> Security Class Initialized
DEBUG - 2016-05-18 19:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:35:17 --> Input Class Initialized
INFO - 2016-05-18 19:35:17 --> Language Class Initialized
INFO - 2016-05-18 19:35:17 --> Loader Class Initialized
INFO - 2016-05-18 19:35:17 --> Helper loaded: url_helper
INFO - 2016-05-18 19:35:17 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:35:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:35:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:35:17 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:35:17 --> Helper loaded: form_helper
INFO - 2016-05-18 19:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:35:17 --> Form Validation Class Initialized
INFO - 2016-05-18 19:35:17 --> Controller Class Initialized
INFO - 2016-05-18 19:35:17 --> Model Class Initialized
INFO - 2016-05-18 19:35:17 --> Database Driver Class Initialized
INFO - 2016-05-18 19:35:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:35:17 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:35:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:35:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:35:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:35:17 --> Final output sent to browser
DEBUG - 2016-05-18 19:35:17 --> Total execution time: 0.0806
INFO - 2016-05-18 19:35:17 --> Config Class Initialized
INFO - 2016-05-18 19:35:17 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:35:17 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:35:17 --> Utf8 Class Initialized
INFO - 2016-05-18 19:35:17 --> URI Class Initialized
INFO - 2016-05-18 19:35:17 --> Router Class Initialized
INFO - 2016-05-18 19:35:17 --> Output Class Initialized
INFO - 2016-05-18 19:35:17 --> Security Class Initialized
DEBUG - 2016-05-18 19:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:35:17 --> Input Class Initialized
INFO - 2016-05-18 19:35:17 --> Language Class Initialized
INFO - 2016-05-18 19:35:17 --> Loader Class Initialized
INFO - 2016-05-18 19:35:17 --> Helper loaded: url_helper
INFO - 2016-05-18 19:35:17 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:35:17 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:35:17 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:35:17 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:35:17 --> Helper loaded: form_helper
INFO - 2016-05-18 19:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:35:17 --> Form Validation Class Initialized
INFO - 2016-05-18 19:35:17 --> Controller Class Initialized
INFO - 2016-05-18 19:35:17 --> Model Class Initialized
INFO - 2016-05-18 19:35:17 --> Database Driver Class Initialized
INFO - 2016-05-18 19:35:17 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:35:17 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:35:17 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:35:17 --> Final output sent to browser
DEBUG - 2016-05-18 19:35:17 --> Total execution time: 0.1038
INFO - 2016-05-18 19:35:20 --> Config Class Initialized
INFO - 2016-05-18 19:35:20 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:35:20 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:35:20 --> Utf8 Class Initialized
INFO - 2016-05-18 19:35:20 --> URI Class Initialized
INFO - 2016-05-18 19:35:20 --> Router Class Initialized
INFO - 2016-05-18 19:35:20 --> Output Class Initialized
INFO - 2016-05-18 19:35:20 --> Security Class Initialized
DEBUG - 2016-05-18 19:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:35:20 --> Input Class Initialized
INFO - 2016-05-18 19:35:20 --> Language Class Initialized
INFO - 2016-05-18 19:35:20 --> Loader Class Initialized
INFO - 2016-05-18 19:35:20 --> Helper loaded: url_helper
INFO - 2016-05-18 19:35:20 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:35:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:35:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:35:20 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:35:20 --> Helper loaded: form_helper
INFO - 2016-05-18 19:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:35:20 --> Form Validation Class Initialized
INFO - 2016-05-18 19:35:20 --> Controller Class Initialized
INFO - 2016-05-18 19:35:20 --> Model Class Initialized
INFO - 2016-05-18 19:35:20 --> Database Driver Class Initialized
INFO - 2016-05-18 19:35:20 --> Final output sent to browser
DEBUG - 2016-05-18 19:35:20 --> Total execution time: 0.2889
INFO - 2016-05-18 19:35:31 --> Config Class Initialized
INFO - 2016-05-18 19:35:31 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:35:31 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:35:31 --> Utf8 Class Initialized
INFO - 2016-05-18 19:35:31 --> URI Class Initialized
INFO - 2016-05-18 19:35:31 --> Router Class Initialized
INFO - 2016-05-18 19:35:31 --> Output Class Initialized
INFO - 2016-05-18 19:35:31 --> Security Class Initialized
DEBUG - 2016-05-18 19:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:35:31 --> Input Class Initialized
INFO - 2016-05-18 19:35:31 --> Language Class Initialized
INFO - 2016-05-18 19:35:31 --> Loader Class Initialized
INFO - 2016-05-18 19:35:31 --> Helper loaded: url_helper
INFO - 2016-05-18 19:35:31 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:35:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:35:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:35:31 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:35:31 --> Helper loaded: form_helper
INFO - 2016-05-18 19:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:35:31 --> Form Validation Class Initialized
INFO - 2016-05-18 19:35:31 --> Controller Class Initialized
INFO - 2016-05-18 19:35:31 --> Model Class Initialized
INFO - 2016-05-18 19:35:31 --> Database Driver Class Initialized
INFO - 2016-05-18 19:35:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:35:31 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:35:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:35:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:35:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:35:31 --> Final output sent to browser
DEBUG - 2016-05-18 19:35:31 --> Total execution time: 0.0859
INFO - 2016-05-18 19:35:31 --> Config Class Initialized
INFO - 2016-05-18 19:35:31 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:35:31 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:35:31 --> Utf8 Class Initialized
INFO - 2016-05-18 19:35:31 --> URI Class Initialized
INFO - 2016-05-18 19:35:31 --> Router Class Initialized
INFO - 2016-05-18 19:35:31 --> Output Class Initialized
INFO - 2016-05-18 19:35:31 --> Security Class Initialized
DEBUG - 2016-05-18 19:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:35:31 --> Input Class Initialized
INFO - 2016-05-18 19:35:31 --> Language Class Initialized
INFO - 2016-05-18 19:35:31 --> Loader Class Initialized
INFO - 2016-05-18 19:35:31 --> Helper loaded: url_helper
INFO - 2016-05-18 19:35:31 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:35:31 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:35:31 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:35:31 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:35:31 --> Helper loaded: form_helper
INFO - 2016-05-18 19:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:35:31 --> Form Validation Class Initialized
INFO - 2016-05-18 19:35:31 --> Controller Class Initialized
INFO - 2016-05-18 19:35:31 --> Model Class Initialized
INFO - 2016-05-18 19:35:31 --> Database Driver Class Initialized
INFO - 2016-05-18 19:35:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:35:31 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:35:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:35:31 --> Final output sent to browser
DEBUG - 2016-05-18 19:35:31 --> Total execution time: 0.0955
INFO - 2016-05-18 19:36:10 --> Config Class Initialized
INFO - 2016-05-18 19:36:10 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:36:10 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:36:10 --> Utf8 Class Initialized
INFO - 2016-05-18 19:36:10 --> URI Class Initialized
INFO - 2016-05-18 19:36:10 --> Router Class Initialized
INFO - 2016-05-18 19:36:10 --> Output Class Initialized
INFO - 2016-05-18 19:36:10 --> Security Class Initialized
DEBUG - 2016-05-18 19:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:36:10 --> Input Class Initialized
INFO - 2016-05-18 19:36:10 --> Language Class Initialized
INFO - 2016-05-18 19:36:10 --> Loader Class Initialized
INFO - 2016-05-18 19:36:10 --> Helper loaded: url_helper
INFO - 2016-05-18 19:36:10 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:36:10 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:36:10 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:36:10 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:36:10 --> Helper loaded: form_helper
INFO - 2016-05-18 19:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:36:10 --> Form Validation Class Initialized
INFO - 2016-05-18 19:36:10 --> Controller Class Initialized
INFO - 2016-05-18 19:36:10 --> Model Class Initialized
INFO - 2016-05-18 19:36:10 --> Database Driver Class Initialized
INFO - 2016-05-18 19:36:10 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:36:10 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:36:10 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:36:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:36:10 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:36:10 --> Final output sent to browser
DEBUG - 2016-05-18 19:36:10 --> Total execution time: 0.0832
INFO - 2016-05-18 19:36:11 --> Config Class Initialized
INFO - 2016-05-18 19:36:11 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:36:11 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:36:11 --> Utf8 Class Initialized
INFO - 2016-05-18 19:36:11 --> URI Class Initialized
INFO - 2016-05-18 19:36:11 --> Router Class Initialized
INFO - 2016-05-18 19:36:11 --> Output Class Initialized
INFO - 2016-05-18 19:36:11 --> Security Class Initialized
DEBUG - 2016-05-18 19:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:36:11 --> Input Class Initialized
INFO - 2016-05-18 19:36:11 --> Language Class Initialized
INFO - 2016-05-18 19:36:11 --> Loader Class Initialized
INFO - 2016-05-18 19:36:11 --> Helper loaded: url_helper
INFO - 2016-05-18 19:36:11 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:36:11 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:36:11 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:36:11 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:36:11 --> Helper loaded: form_helper
INFO - 2016-05-18 19:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:36:11 --> Form Validation Class Initialized
INFO - 2016-05-18 19:36:11 --> Controller Class Initialized
INFO - 2016-05-18 19:36:11 --> Model Class Initialized
INFO - 2016-05-18 19:36:11 --> Database Driver Class Initialized
INFO - 2016-05-18 19:36:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:36:11 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:36:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:36:11 --> Final output sent to browser
DEBUG - 2016-05-18 19:36:11 --> Total execution time: 0.1938
INFO - 2016-05-18 19:36:13 --> Config Class Initialized
INFO - 2016-05-18 19:36:13 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:36:13 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:36:13 --> Utf8 Class Initialized
INFO - 2016-05-18 19:36:13 --> URI Class Initialized
INFO - 2016-05-18 19:36:13 --> Router Class Initialized
INFO - 2016-05-18 19:36:13 --> Output Class Initialized
INFO - 2016-05-18 19:36:13 --> Security Class Initialized
DEBUG - 2016-05-18 19:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:36:13 --> Input Class Initialized
INFO - 2016-05-18 19:36:13 --> Language Class Initialized
INFO - 2016-05-18 19:36:13 --> Loader Class Initialized
INFO - 2016-05-18 19:36:13 --> Helper loaded: url_helper
INFO - 2016-05-18 19:36:13 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:36:13 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:36:13 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:36:13 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:36:13 --> Helper loaded: form_helper
INFO - 2016-05-18 19:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:36:13 --> Form Validation Class Initialized
INFO - 2016-05-18 19:36:13 --> Controller Class Initialized
INFO - 2016-05-18 19:36:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-18 19:36:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-18 19:36:13 --> Final output sent to browser
DEBUG - 2016-05-18 19:36:13 --> Total execution time: 0.0632
INFO - 2016-05-18 19:36:14 --> Config Class Initialized
INFO - 2016-05-18 19:36:14 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:36:14 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:36:14 --> Utf8 Class Initialized
INFO - 2016-05-18 19:36:14 --> URI Class Initialized
INFO - 2016-05-18 19:36:14 --> Router Class Initialized
INFO - 2016-05-18 19:36:14 --> Output Class Initialized
INFO - 2016-05-18 19:36:14 --> Security Class Initialized
DEBUG - 2016-05-18 19:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:36:14 --> Input Class Initialized
INFO - 2016-05-18 19:36:14 --> Language Class Initialized
INFO - 2016-05-18 19:36:14 --> Loader Class Initialized
INFO - 2016-05-18 19:36:14 --> Helper loaded: url_helper
INFO - 2016-05-18 19:36:14 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:36:14 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:36:14 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:36:14 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:36:14 --> Helper loaded: form_helper
INFO - 2016-05-18 19:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:36:14 --> Form Validation Class Initialized
INFO - 2016-05-18 19:36:14 --> Controller Class Initialized
INFO - 2016-05-18 19:36:14 --> Model Class Initialized
INFO - 2016-05-18 19:36:14 --> Database Driver Class Initialized
INFO - 2016-05-18 19:36:14 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:36:14 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:36:14 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:36:14 --> Final output sent to browser
DEBUG - 2016-05-18 19:36:14 --> Total execution time: 0.1288
INFO - 2016-05-18 19:36:15 --> Config Class Initialized
INFO - 2016-05-18 19:36:15 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:36:15 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:36:15 --> Utf8 Class Initialized
INFO - 2016-05-18 19:36:15 --> URI Class Initialized
INFO - 2016-05-18 19:36:15 --> Router Class Initialized
INFO - 2016-05-18 19:36:15 --> Output Class Initialized
INFO - 2016-05-18 19:36:15 --> Security Class Initialized
DEBUG - 2016-05-18 19:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:36:15 --> Input Class Initialized
INFO - 2016-05-18 19:36:15 --> Language Class Initialized
INFO - 2016-05-18 19:36:15 --> Loader Class Initialized
INFO - 2016-05-18 19:36:15 --> Helper loaded: url_helper
INFO - 2016-05-18 19:36:15 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:36:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:36:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:36:15 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:36:15 --> Helper loaded: form_helper
INFO - 2016-05-18 19:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:36:15 --> Form Validation Class Initialized
INFO - 2016-05-18 19:36:15 --> Controller Class Initialized
INFO - 2016-05-18 19:36:15 --> Config Class Initialized
INFO - 2016-05-18 19:36:15 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:36:15 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:36:15 --> Utf8 Class Initialized
INFO - 2016-05-18 19:36:15 --> URI Class Initialized
INFO - 2016-05-18 19:36:15 --> Router Class Initialized
INFO - 2016-05-18 19:36:15 --> Output Class Initialized
INFO - 2016-05-18 19:36:15 --> Security Class Initialized
DEBUG - 2016-05-18 19:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:36:15 --> Input Class Initialized
INFO - 2016-05-18 19:36:15 --> Language Class Initialized
INFO - 2016-05-18 19:36:15 --> Loader Class Initialized
INFO - 2016-05-18 19:36:15 --> Helper loaded: url_helper
INFO - 2016-05-18 19:36:15 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:36:15 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:36:15 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:36:15 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:36:15 --> Helper loaded: form_helper
INFO - 2016-05-18 19:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:36:15 --> Form Validation Class Initialized
INFO - 2016-05-18 19:36:15 --> Controller Class Initialized
INFO - 2016-05-18 19:36:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-18 19:36:15 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:36:15 --> Final output sent to browser
DEBUG - 2016-05-18 19:36:15 --> Total execution time: 0.0668
INFO - 2016-05-18 19:36:16 --> Config Class Initialized
INFO - 2016-05-18 19:36:16 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:36:16 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:36:16 --> Utf8 Class Initialized
INFO - 2016-05-18 19:36:16 --> URI Class Initialized
INFO - 2016-05-18 19:36:16 --> Router Class Initialized
INFO - 2016-05-18 19:36:16 --> Output Class Initialized
INFO - 2016-05-18 19:36:16 --> Security Class Initialized
DEBUG - 2016-05-18 19:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:36:16 --> Input Class Initialized
INFO - 2016-05-18 19:36:16 --> Language Class Initialized
INFO - 2016-05-18 19:36:16 --> Loader Class Initialized
INFO - 2016-05-18 19:36:16 --> Helper loaded: url_helper
INFO - 2016-05-18 19:36:16 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:36:16 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:36:16 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:36:16 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:36:16 --> Helper loaded: form_helper
INFO - 2016-05-18 19:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:36:16 --> Form Validation Class Initialized
INFO - 2016-05-18 19:36:16 --> Controller Class Initialized
INFO - 2016-05-18 19:36:16 --> Model Class Initialized
INFO - 2016-05-18 19:36:16 --> Database Driver Class Initialized
INFO - 2016-05-18 19:36:16 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:36:16 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:36:16 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:36:16 --> Final output sent to browser
DEBUG - 2016-05-18 19:36:16 --> Total execution time: 0.1256
INFO - 2016-05-18 19:36:19 --> Config Class Initialized
INFO - 2016-05-18 19:36:19 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:36:19 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:36:19 --> Utf8 Class Initialized
INFO - 2016-05-18 19:36:19 --> URI Class Initialized
INFO - 2016-05-18 19:36:19 --> Router Class Initialized
INFO - 2016-05-18 19:36:19 --> Output Class Initialized
INFO - 2016-05-18 19:36:19 --> Security Class Initialized
DEBUG - 2016-05-18 19:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:36:19 --> Input Class Initialized
INFO - 2016-05-18 19:36:19 --> Language Class Initialized
INFO - 2016-05-18 19:36:19 --> Loader Class Initialized
INFO - 2016-05-18 19:36:19 --> Helper loaded: url_helper
INFO - 2016-05-18 19:36:19 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:36:19 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:36:19 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:36:19 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:36:19 --> Helper loaded: form_helper
INFO - 2016-05-18 19:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:36:19 --> Form Validation Class Initialized
INFO - 2016-05-18 19:36:19 --> Controller Class Initialized
INFO - 2016-05-18 19:36:19 --> Model Class Initialized
INFO - 2016-05-18 19:36:19 --> Database Driver Class Initialized
INFO - 2016-05-18 19:36:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:36:19 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:36:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:36:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:36:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:36:19 --> Final output sent to browser
DEBUG - 2016-05-18 19:36:19 --> Total execution time: 0.1109
INFO - 2016-05-18 19:36:20 --> Config Class Initialized
INFO - 2016-05-18 19:36:20 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:36:20 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:36:20 --> Utf8 Class Initialized
INFO - 2016-05-18 19:36:20 --> URI Class Initialized
INFO - 2016-05-18 19:36:20 --> Router Class Initialized
INFO - 2016-05-18 19:36:20 --> Output Class Initialized
INFO - 2016-05-18 19:36:20 --> Security Class Initialized
DEBUG - 2016-05-18 19:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:36:20 --> Input Class Initialized
INFO - 2016-05-18 19:36:20 --> Language Class Initialized
INFO - 2016-05-18 19:36:20 --> Loader Class Initialized
INFO - 2016-05-18 19:36:20 --> Helper loaded: url_helper
INFO - 2016-05-18 19:36:20 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:36:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:36:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:36:20 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:36:20 --> Helper loaded: form_helper
INFO - 2016-05-18 19:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:36:20 --> Form Validation Class Initialized
INFO - 2016-05-18 19:36:20 --> Controller Class Initialized
INFO - 2016-05-18 19:36:20 --> Model Class Initialized
INFO - 2016-05-18 19:36:20 --> Database Driver Class Initialized
INFO - 2016-05-18 19:36:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:36:20 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:36:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:36:20 --> Final output sent to browser
DEBUG - 2016-05-18 19:36:20 --> Total execution time: 0.1103
INFO - 2016-05-18 19:37:20 --> Config Class Initialized
INFO - 2016-05-18 19:37:20 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:37:20 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:37:20 --> Utf8 Class Initialized
INFO - 2016-05-18 19:37:20 --> URI Class Initialized
INFO - 2016-05-18 19:37:20 --> Router Class Initialized
INFO - 2016-05-18 19:37:20 --> Output Class Initialized
INFO - 2016-05-18 19:37:20 --> Security Class Initialized
DEBUG - 2016-05-18 19:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:37:20 --> Input Class Initialized
INFO - 2016-05-18 19:37:20 --> Language Class Initialized
INFO - 2016-05-18 19:37:20 --> Loader Class Initialized
INFO - 2016-05-18 19:37:20 --> Helper loaded: url_helper
INFO - 2016-05-18 19:37:20 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:37:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:37:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:37:20 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:37:20 --> Helper loaded: form_helper
INFO - 2016-05-18 19:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:37:20 --> Form Validation Class Initialized
INFO - 2016-05-18 19:37:20 --> Controller Class Initialized
INFO - 2016-05-18 19:37:20 --> Model Class Initialized
INFO - 2016-05-18 19:37:20 --> Database Driver Class Initialized
INFO - 2016-05-18 19:37:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:37:20 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:37:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:37:20 --> Final output sent to browser
DEBUG - 2016-05-18 19:37:20 --> Total execution time: 0.0689
INFO - 2016-05-18 19:38:20 --> Config Class Initialized
INFO - 2016-05-18 19:38:20 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:38:20 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:38:20 --> Utf8 Class Initialized
INFO - 2016-05-18 19:38:20 --> URI Class Initialized
INFO - 2016-05-18 19:38:20 --> Router Class Initialized
INFO - 2016-05-18 19:38:20 --> Output Class Initialized
INFO - 2016-05-18 19:38:20 --> Security Class Initialized
DEBUG - 2016-05-18 19:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:38:20 --> Input Class Initialized
INFO - 2016-05-18 19:38:20 --> Language Class Initialized
INFO - 2016-05-18 19:38:20 --> Loader Class Initialized
INFO - 2016-05-18 19:38:20 --> Helper loaded: url_helper
INFO - 2016-05-18 19:38:20 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:38:20 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:38:20 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:38:20 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:38:20 --> Helper loaded: form_helper
INFO - 2016-05-18 19:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:38:20 --> Form Validation Class Initialized
INFO - 2016-05-18 19:38:20 --> Controller Class Initialized
INFO - 2016-05-18 19:38:20 --> Model Class Initialized
INFO - 2016-05-18 19:38:20 --> Database Driver Class Initialized
INFO - 2016-05-18 19:38:20 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:38:20 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:38:20 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:38:20 --> Final output sent to browser
DEBUG - 2016-05-18 19:38:20 --> Total execution time: 0.0764
INFO - 2016-05-18 19:38:21 --> Config Class Initialized
INFO - 2016-05-18 19:38:21 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:38:21 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:38:21 --> Utf8 Class Initialized
INFO - 2016-05-18 19:38:21 --> URI Class Initialized
INFO - 2016-05-18 19:38:21 --> Router Class Initialized
INFO - 2016-05-18 19:38:21 --> Output Class Initialized
INFO - 2016-05-18 19:38:21 --> Security Class Initialized
DEBUG - 2016-05-18 19:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:38:21 --> Input Class Initialized
INFO - 2016-05-18 19:38:21 --> Language Class Initialized
INFO - 2016-05-18 19:38:21 --> Loader Class Initialized
INFO - 2016-05-18 19:38:21 --> Helper loaded: url_helper
INFO - 2016-05-18 19:38:21 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:38:21 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:38:21 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:38:21 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:38:21 --> Helper loaded: form_helper
INFO - 2016-05-18 19:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:38:21 --> Form Validation Class Initialized
INFO - 2016-05-18 19:38:21 --> Controller Class Initialized
INFO - 2016-05-18 19:38:21 --> Model Class Initialized
INFO - 2016-05-18 19:38:21 --> Database Driver Class Initialized
INFO - 2016-05-18 19:38:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:38:21 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:38:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:38:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:38:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:38:21 --> Final output sent to browser
DEBUG - 2016-05-18 19:38:21 --> Total execution time: 0.0819
INFO - 2016-05-18 19:38:22 --> Config Class Initialized
INFO - 2016-05-18 19:38:22 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:38:22 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:38:22 --> Utf8 Class Initialized
INFO - 2016-05-18 19:38:22 --> URI Class Initialized
INFO - 2016-05-18 19:38:22 --> Router Class Initialized
INFO - 2016-05-18 19:38:22 --> Output Class Initialized
INFO - 2016-05-18 19:38:22 --> Security Class Initialized
DEBUG - 2016-05-18 19:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:38:22 --> Input Class Initialized
INFO - 2016-05-18 19:38:22 --> Language Class Initialized
INFO - 2016-05-18 19:38:22 --> Loader Class Initialized
INFO - 2016-05-18 19:38:22 --> Helper loaded: url_helper
INFO - 2016-05-18 19:38:22 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:38:22 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:38:22 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:38:22 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:38:22 --> Helper loaded: form_helper
INFO - 2016-05-18 19:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:38:22 --> Form Validation Class Initialized
INFO - 2016-05-18 19:38:22 --> Controller Class Initialized
INFO - 2016-05-18 19:38:22 --> Model Class Initialized
INFO - 2016-05-18 19:38:22 --> Database Driver Class Initialized
INFO - 2016-05-18 19:38:22 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:38:22 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:38:22 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:38:22 --> Final output sent to browser
DEBUG - 2016-05-18 19:38:22 --> Total execution time: 0.1250
INFO - 2016-05-18 19:38:23 --> Config Class Initialized
INFO - 2016-05-18 19:38:23 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:38:23 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:38:23 --> Utf8 Class Initialized
INFO - 2016-05-18 19:38:23 --> URI Class Initialized
INFO - 2016-05-18 19:38:23 --> Router Class Initialized
INFO - 2016-05-18 19:38:23 --> Output Class Initialized
INFO - 2016-05-18 19:38:23 --> Security Class Initialized
DEBUG - 2016-05-18 19:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:38:23 --> Input Class Initialized
INFO - 2016-05-18 19:38:23 --> Language Class Initialized
INFO - 2016-05-18 19:38:23 --> Loader Class Initialized
INFO - 2016-05-18 19:38:23 --> Helper loaded: url_helper
INFO - 2016-05-18 19:38:23 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:38:23 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:38:23 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:38:23 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:38:23 --> Helper loaded: form_helper
INFO - 2016-05-18 19:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:38:23 --> Form Validation Class Initialized
INFO - 2016-05-18 19:38:23 --> Controller Class Initialized
INFO - 2016-05-18 19:38:23 --> Model Class Initialized
INFO - 2016-05-18 19:38:23 --> Database Driver Class Initialized
INFO - 2016-05-18 19:38:23 --> Final output sent to browser
DEBUG - 2016-05-18 19:38:23 --> Total execution time: 0.1729
INFO - 2016-05-18 19:40:48 --> Config Class Initialized
INFO - 2016-05-18 19:40:48 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:40:48 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:40:48 --> Utf8 Class Initialized
INFO - 2016-05-18 19:40:48 --> URI Class Initialized
INFO - 2016-05-18 19:40:48 --> Router Class Initialized
INFO - 2016-05-18 19:40:48 --> Output Class Initialized
INFO - 2016-05-18 19:40:48 --> Security Class Initialized
DEBUG - 2016-05-18 19:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:40:48 --> Input Class Initialized
INFO - 2016-05-18 19:40:48 --> Language Class Initialized
INFO - 2016-05-18 19:40:48 --> Loader Class Initialized
INFO - 2016-05-18 19:40:48 --> Helper loaded: url_helper
INFO - 2016-05-18 19:40:48 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:40:48 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:40:49 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:40:49 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:40:49 --> Helper loaded: form_helper
INFO - 2016-05-18 19:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:40:49 --> Form Validation Class Initialized
INFO - 2016-05-18 19:40:49 --> Controller Class Initialized
INFO - 2016-05-18 19:40:49 --> Model Class Initialized
INFO - 2016-05-18 19:40:49 --> Database Driver Class Initialized
INFO - 2016-05-18 19:40:49 --> Final output sent to browser
DEBUG - 2016-05-18 19:40:49 --> Total execution time: 0.1593
INFO - 2016-05-18 19:40:59 --> Config Class Initialized
INFO - 2016-05-18 19:40:59 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:40:59 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:40:59 --> Utf8 Class Initialized
INFO - 2016-05-18 19:40:59 --> URI Class Initialized
INFO - 2016-05-18 19:40:59 --> Router Class Initialized
INFO - 2016-05-18 19:40:59 --> Output Class Initialized
INFO - 2016-05-18 19:40:59 --> Security Class Initialized
DEBUG - 2016-05-18 19:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:40:59 --> Input Class Initialized
INFO - 2016-05-18 19:40:59 --> Language Class Initialized
INFO - 2016-05-18 19:40:59 --> Loader Class Initialized
INFO - 2016-05-18 19:40:59 --> Helper loaded: url_helper
INFO - 2016-05-18 19:40:59 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:40:59 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:40:59 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:40:59 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:40:59 --> Helper loaded: form_helper
INFO - 2016-05-18 19:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:40:59 --> Form Validation Class Initialized
INFO - 2016-05-18 19:40:59 --> Controller Class Initialized
INFO - 2016-05-18 19:40:59 --> Model Class Initialized
INFO - 2016-05-18 19:40:59 --> Database Driver Class Initialized
INFO - 2016-05-18 19:40:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:40:59 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:40:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:40:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:40:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:40:59 --> Final output sent to browser
DEBUG - 2016-05-18 19:40:59 --> Total execution time: 0.0930
INFO - 2016-05-18 19:41:00 --> Config Class Initialized
INFO - 2016-05-18 19:41:00 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:41:00 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:41:00 --> Utf8 Class Initialized
INFO - 2016-05-18 19:41:00 --> URI Class Initialized
INFO - 2016-05-18 19:41:00 --> Router Class Initialized
INFO - 2016-05-18 19:41:00 --> Output Class Initialized
INFO - 2016-05-18 19:41:00 --> Security Class Initialized
DEBUG - 2016-05-18 19:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:41:00 --> Input Class Initialized
INFO - 2016-05-18 19:41:00 --> Language Class Initialized
INFO - 2016-05-18 19:41:00 --> Loader Class Initialized
INFO - 2016-05-18 19:41:00 --> Helper loaded: url_helper
INFO - 2016-05-18 19:41:00 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:41:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:41:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:41:00 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:41:00 --> Helper loaded: form_helper
INFO - 2016-05-18 19:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:41:00 --> Form Validation Class Initialized
INFO - 2016-05-18 19:41:00 --> Controller Class Initialized
INFO - 2016-05-18 19:41:00 --> Model Class Initialized
INFO - 2016-05-18 19:41:00 --> Database Driver Class Initialized
INFO - 2016-05-18 19:41:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:41:00 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:41:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:41:00 --> Final output sent to browser
DEBUG - 2016-05-18 19:41:00 --> Total execution time: 0.1067
INFO - 2016-05-18 19:42:00 --> Config Class Initialized
INFO - 2016-05-18 19:42:00 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:42:00 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:42:00 --> Utf8 Class Initialized
INFO - 2016-05-18 19:42:00 --> URI Class Initialized
INFO - 2016-05-18 19:42:00 --> Router Class Initialized
INFO - 2016-05-18 19:42:00 --> Output Class Initialized
INFO - 2016-05-18 19:42:00 --> Security Class Initialized
DEBUG - 2016-05-18 19:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:42:00 --> Input Class Initialized
INFO - 2016-05-18 19:42:00 --> Language Class Initialized
INFO - 2016-05-18 19:42:00 --> Loader Class Initialized
INFO - 2016-05-18 19:42:00 --> Helper loaded: url_helper
INFO - 2016-05-18 19:42:00 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:42:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:42:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:42:00 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:42:00 --> Helper loaded: form_helper
INFO - 2016-05-18 19:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:42:00 --> Form Validation Class Initialized
INFO - 2016-05-18 19:42:00 --> Controller Class Initialized
INFO - 2016-05-18 19:42:00 --> Model Class Initialized
INFO - 2016-05-18 19:42:00 --> Database Driver Class Initialized
INFO - 2016-05-18 19:42:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:42:00 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:42:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:42:00 --> Final output sent to browser
DEBUG - 2016-05-18 19:42:00 --> Total execution time: 0.0705
INFO - 2016-05-18 19:43:00 --> Config Class Initialized
INFO - 2016-05-18 19:43:00 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:43:00 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:43:00 --> Utf8 Class Initialized
INFO - 2016-05-18 19:43:00 --> URI Class Initialized
INFO - 2016-05-18 19:43:00 --> Router Class Initialized
INFO - 2016-05-18 19:43:00 --> Output Class Initialized
INFO - 2016-05-18 19:43:00 --> Security Class Initialized
DEBUG - 2016-05-18 19:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:43:00 --> Input Class Initialized
INFO - 2016-05-18 19:43:00 --> Language Class Initialized
INFO - 2016-05-18 19:43:00 --> Loader Class Initialized
INFO - 2016-05-18 19:43:00 --> Helper loaded: url_helper
INFO - 2016-05-18 19:43:00 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:43:00 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:43:00 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:43:00 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:43:00 --> Helper loaded: form_helper
INFO - 2016-05-18 19:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:43:00 --> Form Validation Class Initialized
INFO - 2016-05-18 19:43:00 --> Controller Class Initialized
INFO - 2016-05-18 19:43:00 --> Model Class Initialized
INFO - 2016-05-18 19:43:00 --> Database Driver Class Initialized
INFO - 2016-05-18 19:43:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:43:00 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:43:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:43:00 --> Final output sent to browser
DEBUG - 2016-05-18 19:43:00 --> Total execution time: 0.0769
INFO - 2016-05-18 19:43:51 --> Config Class Initialized
INFO - 2016-05-18 19:43:51 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:43:51 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:43:51 --> Utf8 Class Initialized
INFO - 2016-05-18 19:43:51 --> URI Class Initialized
INFO - 2016-05-18 19:43:51 --> Router Class Initialized
INFO - 2016-05-18 19:43:51 --> Output Class Initialized
INFO - 2016-05-18 19:43:51 --> Security Class Initialized
DEBUG - 2016-05-18 19:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:43:51 --> Input Class Initialized
INFO - 2016-05-18 19:43:51 --> Language Class Initialized
INFO - 2016-05-18 19:43:51 --> Loader Class Initialized
INFO - 2016-05-18 19:43:51 --> Helper loaded: url_helper
INFO - 2016-05-18 19:43:51 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:43:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:43:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:43:51 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:43:51 --> Helper loaded: form_helper
INFO - 2016-05-18 19:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:43:51 --> Form Validation Class Initialized
INFO - 2016-05-18 19:43:51 --> Controller Class Initialized
INFO - 2016-05-18 19:43:51 --> Model Class Initialized
INFO - 2016-05-18 19:43:51 --> Database Driver Class Initialized
INFO - 2016-05-18 19:43:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:43:51 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:43:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:43:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaFacturasPendientes.php
INFO - 2016-05-18 19:43:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-18 19:43:51 --> Final output sent to browser
DEBUG - 2016-05-18 19:43:51 --> Total execution time: 0.0853
INFO - 2016-05-18 19:43:51 --> Config Class Initialized
INFO - 2016-05-18 19:43:51 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:43:51 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:43:51 --> Utf8 Class Initialized
INFO - 2016-05-18 19:43:51 --> URI Class Initialized
INFO - 2016-05-18 19:43:51 --> Router Class Initialized
INFO - 2016-05-18 19:43:51 --> Output Class Initialized
INFO - 2016-05-18 19:43:51 --> Security Class Initialized
DEBUG - 2016-05-18 19:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:43:51 --> Input Class Initialized
INFO - 2016-05-18 19:43:51 --> Language Class Initialized
INFO - 2016-05-18 19:43:51 --> Loader Class Initialized
INFO - 2016-05-18 19:43:51 --> Helper loaded: url_helper
INFO - 2016-05-18 19:43:51 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:43:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:43:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:43:51 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:43:51 --> Helper loaded: form_helper
INFO - 2016-05-18 19:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:43:51 --> Form Validation Class Initialized
INFO - 2016-05-18 19:43:51 --> Controller Class Initialized
INFO - 2016-05-18 19:43:51 --> Model Class Initialized
INFO - 2016-05-18 19:43:51 --> Database Driver Class Initialized
INFO - 2016-05-18 19:43:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:43:51 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:43:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:43:51 --> Final output sent to browser
DEBUG - 2016-05-18 19:43:51 --> Total execution time: 0.1322
INFO - 2016-05-18 19:44:27 --> Config Class Initialized
INFO - 2016-05-18 19:44:27 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:44:27 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:44:27 --> Utf8 Class Initialized
INFO - 2016-05-18 19:44:27 --> URI Class Initialized
DEBUG - 2016-05-18 19:44:27 --> No URI present. Default controller set.
INFO - 2016-05-18 19:44:27 --> Router Class Initialized
INFO - 2016-05-18 19:44:27 --> Output Class Initialized
INFO - 2016-05-18 19:44:27 --> Security Class Initialized
DEBUG - 2016-05-18 19:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:44:27 --> Input Class Initialized
INFO - 2016-05-18 19:44:27 --> Language Class Initialized
INFO - 2016-05-18 19:44:27 --> Loader Class Initialized
INFO - 2016-05-18 19:44:27 --> Helper loaded: url_helper
INFO - 2016-05-18 19:44:27 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:44:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:44:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:44:27 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:44:27 --> Helper loaded: form_helper
INFO - 2016-05-18 19:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:44:27 --> Form Validation Class Initialized
INFO - 2016-05-18 19:44:27 --> Controller Class Initialized
INFO - 2016-05-18 19:44:27 --> Model Class Initialized
INFO - 2016-05-18 19:44:27 --> Database Driver Class Initialized
INFO - 2016-05-18 19:44:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:44:27 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:44:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:44:27 --> Config Class Initialized
INFO - 2016-05-18 19:44:27 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:44:27 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:44:27 --> Utf8 Class Initialized
INFO - 2016-05-18 19:44:27 --> URI Class Initialized
INFO - 2016-05-18 19:44:27 --> Router Class Initialized
INFO - 2016-05-18 19:44:27 --> Output Class Initialized
INFO - 2016-05-18 19:44:27 --> Security Class Initialized
DEBUG - 2016-05-18 19:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:44:27 --> Input Class Initialized
INFO - 2016-05-18 19:44:27 --> Language Class Initialized
INFO - 2016-05-18 19:44:27 --> Loader Class Initialized
INFO - 2016-05-18 19:44:27 --> Helper loaded: url_helper
INFO - 2016-05-18 19:44:27 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:44:27 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:44:27 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:44:27 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:44:27 --> Helper loaded: form_helper
INFO - 2016-05-18 19:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:44:27 --> Form Validation Class Initialized
INFO - 2016-05-18 19:44:27 --> Controller Class Initialized
INFO - 2016-05-18 19:44:27 --> Model Class Initialized
INFO - 2016-05-18 19:44:27 --> Database Driver Class Initialized
INFO - 2016-05-18 19:44:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_login.php
INFO - 2016-05-18 19:44:27 --> Final output sent to browser
DEBUG - 2016-05-18 19:44:27 --> Total execution time: 0.1185
INFO - 2016-05-18 19:44:33 --> Config Class Initialized
INFO - 2016-05-18 19:44:33 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:44:33 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:44:33 --> Utf8 Class Initialized
INFO - 2016-05-18 19:44:33 --> URI Class Initialized
INFO - 2016-05-18 19:44:33 --> Router Class Initialized
INFO - 2016-05-18 19:44:33 --> Output Class Initialized
INFO - 2016-05-18 19:44:33 --> Security Class Initialized
DEBUG - 2016-05-18 19:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:44:33 --> Input Class Initialized
INFO - 2016-05-18 19:44:33 --> Language Class Initialized
INFO - 2016-05-18 19:44:33 --> Loader Class Initialized
INFO - 2016-05-18 19:44:33 --> Helper loaded: url_helper
INFO - 2016-05-18 19:44:33 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:44:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:44:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:44:33 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:44:33 --> Helper loaded: form_helper
INFO - 2016-05-18 19:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:44:33 --> Form Validation Class Initialized
INFO - 2016-05-18 19:44:33 --> Controller Class Initialized
INFO - 2016-05-18 19:44:33 --> Model Class Initialized
INFO - 2016-05-18 19:44:33 --> Database Driver Class Initialized
INFO - 2016-05-18 19:44:33 --> Config Class Initialized
INFO - 2016-05-18 19:44:33 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:44:33 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:44:33 --> Utf8 Class Initialized
INFO - 2016-05-18 19:44:33 --> URI Class Initialized
DEBUG - 2016-05-18 19:44:33 --> No URI present. Default controller set.
INFO - 2016-05-18 19:44:33 --> Router Class Initialized
INFO - 2016-05-18 19:44:33 --> Output Class Initialized
INFO - 2016-05-18 19:44:33 --> Security Class Initialized
DEBUG - 2016-05-18 19:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:44:33 --> Input Class Initialized
INFO - 2016-05-18 19:44:33 --> Language Class Initialized
INFO - 2016-05-18 19:44:33 --> Loader Class Initialized
INFO - 2016-05-18 19:44:33 --> Helper loaded: url_helper
INFO - 2016-05-18 19:44:33 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:44:33 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:44:33 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:44:33 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:44:33 --> Helper loaded: form_helper
INFO - 2016-05-18 19:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:44:33 --> Form Validation Class Initialized
INFO - 2016-05-18 19:44:33 --> Controller Class Initialized
INFO - 2016-05-18 19:44:33 --> Model Class Initialized
INFO - 2016-05-18 19:44:33 --> Database Driver Class Initialized
INFO - 2016-05-18 19:44:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:44:33 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:44:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:44:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_index.php
INFO - 2016-05-18 19:44:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-18 19:44:33 --> Final output sent to browser
DEBUG - 2016-05-18 19:44:33 --> Total execution time: 0.1283
INFO - 2016-05-18 19:44:37 --> Config Class Initialized
INFO - 2016-05-18 19:44:37 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:44:37 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:44:37 --> Utf8 Class Initialized
INFO - 2016-05-18 19:44:37 --> URI Class Initialized
INFO - 2016-05-18 19:44:37 --> Router Class Initialized
INFO - 2016-05-18 19:44:37 --> Output Class Initialized
INFO - 2016-05-18 19:44:37 --> Security Class Initialized
DEBUG - 2016-05-18 19:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:44:37 --> Input Class Initialized
INFO - 2016-05-18 19:44:37 --> Language Class Initialized
INFO - 2016-05-18 19:44:37 --> Loader Class Initialized
INFO - 2016-05-18 19:44:37 --> Helper loaded: url_helper
INFO - 2016-05-18 19:44:37 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:44:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:44:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:44:37 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:44:37 --> Helper loaded: form_helper
INFO - 2016-05-18 19:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:44:37 --> Form Validation Class Initialized
INFO - 2016-05-18 19:44:37 --> Controller Class Initialized
INFO - 2016-05-18 19:44:37 --> Model Class Initialized
INFO - 2016-05-18 19:44:37 --> Database Driver Class Initialized
ERROR - 2016-05-18 19:44:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 43
ERROR - 2016-05-18 19:44:37 --> Severity: Notice --> Undefined variable: cantidad C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Carrito.php 51
INFO - 2016-05-18 19:44:37 --> Config Class Initialized
INFO - 2016-05-18 19:44:37 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:44:37 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:44:37 --> Utf8 Class Initialized
INFO - 2016-05-18 19:44:37 --> URI Class Initialized
INFO - 2016-05-18 19:44:37 --> Router Class Initialized
INFO - 2016-05-18 19:44:37 --> Output Class Initialized
INFO - 2016-05-18 19:44:37 --> Security Class Initialized
DEBUG - 2016-05-18 19:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:44:37 --> Input Class Initialized
INFO - 2016-05-18 19:44:37 --> Language Class Initialized
INFO - 2016-05-18 19:44:37 --> Loader Class Initialized
INFO - 2016-05-18 19:44:37 --> Helper loaded: url_helper
INFO - 2016-05-18 19:44:37 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:44:37 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:44:37 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:44:37 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:44:37 --> Helper loaded: form_helper
INFO - 2016-05-18 19:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:44:37 --> Form Validation Class Initialized
INFO - 2016-05-18 19:44:37 --> Controller Class Initialized
INFO - 2016-05-18 19:44:37 --> Model Class Initialized
INFO - 2016-05-18 19:44:37 --> Database Driver Class Initialized
INFO - 2016-05-18 19:44:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_carrito.php
INFO - 2016-05-18 19:44:37 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-18 19:44:37 --> Final output sent to browser
DEBUG - 2016-05-18 19:44:37 --> Total execution time: 0.0992
INFO - 2016-05-18 19:44:38 --> Config Class Initialized
INFO - 2016-05-18 19:44:38 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:44:38 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:44:38 --> Utf8 Class Initialized
INFO - 2016-05-18 19:44:38 --> URI Class Initialized
INFO - 2016-05-18 19:44:38 --> Router Class Initialized
INFO - 2016-05-18 19:44:39 --> Output Class Initialized
INFO - 2016-05-18 19:44:39 --> Security Class Initialized
DEBUG - 2016-05-18 19:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:44:39 --> Input Class Initialized
INFO - 2016-05-18 19:44:39 --> Language Class Initialized
INFO - 2016-05-18 19:44:39 --> Loader Class Initialized
INFO - 2016-05-18 19:44:39 --> Helper loaded: url_helper
INFO - 2016-05-18 19:44:39 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:44:39 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:44:39 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:44:39 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:44:39 --> Helper loaded: form_helper
INFO - 2016-05-18 19:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:44:39 --> Form Validation Class Initialized
INFO - 2016-05-18 19:44:39 --> Controller Class Initialized
INFO - 2016-05-18 19:44:39 --> Model Class Initialized
INFO - 2016-05-18 19:44:39 --> Database Driver Class Initialized
INFO - 2016-05-18 19:44:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_venta1.php
INFO - 2016-05-18 19:44:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-18 19:44:39 --> Final output sent to browser
DEBUG - 2016-05-18 19:44:39 --> Total execution time: 0.1814
INFO - 2016-05-18 19:44:41 --> Config Class Initialized
INFO - 2016-05-18 19:44:41 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:44:41 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:44:41 --> Utf8 Class Initialized
INFO - 2016-05-18 19:44:41 --> URI Class Initialized
INFO - 2016-05-18 19:44:41 --> Router Class Initialized
INFO - 2016-05-18 19:44:41 --> Output Class Initialized
INFO - 2016-05-18 19:44:41 --> Security Class Initialized
DEBUG - 2016-05-18 19:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:44:41 --> Input Class Initialized
INFO - 2016-05-18 19:44:41 --> Language Class Initialized
INFO - 2016-05-18 19:44:41 --> Loader Class Initialized
INFO - 2016-05-18 19:44:41 --> Helper loaded: url_helper
INFO - 2016-05-18 19:44:41 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:44:41 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:44:41 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:44:41 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:44:41 --> Helper loaded: form_helper
INFO - 2016-05-18 19:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:44:41 --> Form Validation Class Initialized
INFO - 2016-05-18 19:44:41 --> Controller Class Initialized
INFO - 2016-05-18 19:44:41 --> Model Class Initialized
INFO - 2016-05-18 19:44:41 --> Database Driver Class Initialized
INFO - 2016-05-18 19:44:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_venta2.php
INFO - 2016-05-18 19:44:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-18 19:44:41 --> Final output sent to browser
DEBUG - 2016-05-18 19:44:41 --> Total execution time: 0.1325
INFO - 2016-05-18 19:44:44 --> Config Class Initialized
INFO - 2016-05-18 19:44:44 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:44:44 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:44:44 --> Utf8 Class Initialized
INFO - 2016-05-18 19:44:44 --> URI Class Initialized
INFO - 2016-05-18 19:44:44 --> Router Class Initialized
INFO - 2016-05-18 19:44:44 --> Output Class Initialized
INFO - 2016-05-18 19:44:44 --> Security Class Initialized
DEBUG - 2016-05-18 19:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:44:44 --> Input Class Initialized
INFO - 2016-05-18 19:44:44 --> Language Class Initialized
INFO - 2016-05-18 19:44:44 --> Loader Class Initialized
INFO - 2016-05-18 19:44:44 --> Helper loaded: url_helper
INFO - 2016-05-18 19:44:44 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:44:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:44:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:44:44 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:44:44 --> Helper loaded: form_helper
INFO - 2016-05-18 19:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:44:44 --> Form Validation Class Initialized
INFO - 2016-05-18 19:44:44 --> Controller Class Initialized
INFO - 2016-05-18 19:44:44 --> Model Class Initialized
INFO - 2016-05-18 19:44:44 --> Database Driver Class Initialized
INFO - 2016-05-18 19:44:44 --> Config Class Initialized
INFO - 2016-05-18 19:44:44 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:44:44 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:44:44 --> Utf8 Class Initialized
INFO - 2016-05-18 19:44:44 --> URI Class Initialized
INFO - 2016-05-18 19:44:44 --> Router Class Initialized
INFO - 2016-05-18 19:44:44 --> Output Class Initialized
INFO - 2016-05-18 19:44:44 --> Security Class Initialized
DEBUG - 2016-05-18 19:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:44:44 --> Input Class Initialized
INFO - 2016-05-18 19:44:44 --> Language Class Initialized
INFO - 2016-05-18 19:44:44 --> Loader Class Initialized
INFO - 2016-05-18 19:44:44 --> Helper loaded: url_helper
INFO - 2016-05-18 19:44:44 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:44:44 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:44:44 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:44:44 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:44:44 --> Helper loaded: form_helper
INFO - 2016-05-18 19:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:44:44 --> Form Validation Class Initialized
INFO - 2016-05-18 19:44:44 --> Controller Class Initialized
INFO - 2016-05-18 19:44:45 --> Model Class Initialized
INFO - 2016-05-18 19:44:45 --> Database Driver Class Initialized
INFO - 2016-05-18 19:44:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_resumenventa.php
INFO - 2016-05-18 19:44:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-18 19:44:45 --> Final output sent to browser
DEBUG - 2016-05-18 19:44:45 --> Total execution time: 0.1087
INFO - 2016-05-18 19:44:47 --> Config Class Initialized
INFO - 2016-05-18 19:44:47 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:44:47 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:44:47 --> Utf8 Class Initialized
INFO - 2016-05-18 19:44:47 --> URI Class Initialized
INFO - 2016-05-18 19:44:47 --> Router Class Initialized
INFO - 2016-05-18 19:44:47 --> Output Class Initialized
INFO - 2016-05-18 19:44:47 --> Security Class Initialized
DEBUG - 2016-05-18 19:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:44:47 --> Input Class Initialized
INFO - 2016-05-18 19:44:47 --> Language Class Initialized
INFO - 2016-05-18 19:44:47 --> Loader Class Initialized
INFO - 2016-05-18 19:44:47 --> Helper loaded: url_helper
INFO - 2016-05-18 19:44:47 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:44:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:44:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:44:47 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:44:47 --> Helper loaded: form_helper
INFO - 2016-05-18 19:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:44:47 --> Form Validation Class Initialized
INFO - 2016-05-18 19:44:47 --> Controller Class Initialized
INFO - 2016-05-18 19:44:47 --> Model Class Initialized
INFO - 2016-05-18 19:44:47 --> Database Driver Class Initialized
INFO - 2016-05-18 19:44:47 --> Config Class Initialized
INFO - 2016-05-18 19:44:47 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:44:47 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:44:47 --> Utf8 Class Initialized
INFO - 2016-05-18 19:44:47 --> URI Class Initialized
INFO - 2016-05-18 19:44:47 --> Router Class Initialized
INFO - 2016-05-18 19:44:47 --> Output Class Initialized
INFO - 2016-05-18 19:44:47 --> Security Class Initialized
DEBUG - 2016-05-18 19:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:44:47 --> Input Class Initialized
INFO - 2016-05-18 19:44:47 --> Language Class Initialized
INFO - 2016-05-18 19:44:47 --> Loader Class Initialized
INFO - 2016-05-18 19:44:47 --> Helper loaded: url_helper
INFO - 2016-05-18 19:44:47 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:44:47 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:44:47 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:44:47 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:44:47 --> Helper loaded: form_helper
INFO - 2016-05-18 19:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:44:48 --> Form Validation Class Initialized
INFO - 2016-05-18 19:44:48 --> Controller Class Initialized
INFO - 2016-05-18 19:44:48 --> Model Class Initialized
INFO - 2016-05-18 19:44:48 --> Database Driver Class Initialized
INFO - 2016-05-18 19:44:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_ventafinalizadaB.php
INFO - 2016-05-18 19:44:48 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\ven_template1.php
INFO - 2016-05-18 19:44:48 --> Final output sent to browser
DEBUG - 2016-05-18 19:44:48 --> Total execution time: 0.1189
INFO - 2016-05-18 19:44:52 --> Config Class Initialized
INFO - 2016-05-18 19:44:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:44:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:44:52 --> Utf8 Class Initialized
INFO - 2016-05-18 19:44:52 --> URI Class Initialized
INFO - 2016-05-18 19:44:52 --> Router Class Initialized
INFO - 2016-05-18 19:44:52 --> Output Class Initialized
INFO - 2016-05-18 19:44:52 --> Security Class Initialized
DEBUG - 2016-05-18 19:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:44:52 --> Input Class Initialized
INFO - 2016-05-18 19:44:52 --> Language Class Initialized
INFO - 2016-05-18 19:44:52 --> Loader Class Initialized
INFO - 2016-05-18 19:44:52 --> Helper loaded: url_helper
INFO - 2016-05-18 19:44:52 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:44:52 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:44:52 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:44:52 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:44:52 --> Helper loaded: form_helper
INFO - 2016-05-18 19:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:44:52 --> Form Validation Class Initialized
INFO - 2016-05-18 19:44:52 --> Controller Class Initialized
INFO - 2016-05-18 19:44:52 --> Model Class Initialized
INFO - 2016-05-18 19:44:52 --> Database Driver Class Initialized
INFO - 2016-05-18 19:44:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:44:52 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:44:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:44:52 --> Final output sent to browser
DEBUG - 2016-05-18 19:44:52 --> Total execution time: 0.0711
INFO - 2016-05-18 19:44:53 --> Config Class Initialized
INFO - 2016-05-18 19:44:53 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:44:53 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:44:53 --> Utf8 Class Initialized
INFO - 2016-05-18 19:44:53 --> URI Class Initialized
INFO - 2016-05-18 19:44:53 --> Router Class Initialized
INFO - 2016-05-18 19:44:53 --> Output Class Initialized
INFO - 2016-05-18 19:44:53 --> Security Class Initialized
DEBUG - 2016-05-18 19:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:44:53 --> Input Class Initialized
INFO - 2016-05-18 19:44:53 --> Language Class Initialized
INFO - 2016-05-18 19:44:53 --> Loader Class Initialized
INFO - 2016-05-18 19:44:53 --> Helper loaded: url_helper
INFO - 2016-05-18 19:44:53 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:44:53 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:44:53 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:44:53 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:44:53 --> Helper loaded: form_helper
INFO - 2016-05-18 19:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:44:53 --> Form Validation Class Initialized
INFO - 2016-05-18 19:44:53 --> Controller Class Initialized
INFO - 2016-05-18 19:44:53 --> Model Class Initialized
INFO - 2016-05-18 19:44:53 --> Database Driver Class Initialized
INFO - 2016-05-18 19:44:53 --> Final output sent to browser
DEBUG - 2016-05-18 19:44:53 --> Total execution time: 0.1735
INFO - 2016-05-18 19:45:51 --> Config Class Initialized
INFO - 2016-05-18 19:45:51 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:45:51 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:45:51 --> Utf8 Class Initialized
INFO - 2016-05-18 19:45:51 --> URI Class Initialized
INFO - 2016-05-18 19:45:51 --> Router Class Initialized
INFO - 2016-05-18 19:45:51 --> Output Class Initialized
INFO - 2016-05-18 19:45:51 --> Security Class Initialized
DEBUG - 2016-05-18 19:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:45:51 --> Input Class Initialized
INFO - 2016-05-18 19:45:51 --> Language Class Initialized
INFO - 2016-05-18 19:45:51 --> Loader Class Initialized
INFO - 2016-05-18 19:45:51 --> Helper loaded: url_helper
INFO - 2016-05-18 19:45:51 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:45:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:45:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:45:51 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:45:51 --> Helper loaded: form_helper
INFO - 2016-05-18 19:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:45:51 --> Form Validation Class Initialized
INFO - 2016-05-18 19:45:51 --> Controller Class Initialized
INFO - 2016-05-18 19:45:51 --> Model Class Initialized
INFO - 2016-05-18 19:45:51 --> Database Driver Class Initialized
INFO - 2016-05-18 19:45:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:45:51 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:45:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:45:51 --> Final output sent to browser
DEBUG - 2016-05-18 19:45:51 --> Total execution time: 0.0700
INFO - 2016-05-18 19:46:51 --> Config Class Initialized
INFO - 2016-05-18 19:46:51 --> Hooks Class Initialized
DEBUG - 2016-05-18 19:46:51 --> UTF-8 Support Enabled
INFO - 2016-05-18 19:46:51 --> Utf8 Class Initialized
INFO - 2016-05-18 19:46:51 --> URI Class Initialized
INFO - 2016-05-18 19:46:51 --> Router Class Initialized
INFO - 2016-05-18 19:46:51 --> Output Class Initialized
INFO - 2016-05-18 19:46:51 --> Security Class Initialized
DEBUG - 2016-05-18 19:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 19:46:51 --> Input Class Initialized
INFO - 2016-05-18 19:46:51 --> Language Class Initialized
INFO - 2016-05-18 19:46:51 --> Loader Class Initialized
INFO - 2016-05-18 19:46:51 --> Helper loaded: url_helper
INFO - 2016-05-18 19:46:51 --> Helper loaded: sesion_helper
INFO - 2016-05-18 19:46:51 --> Helper loaded: admin_templates_helper
INFO - 2016-05-18 19:46:51 --> Helper loaded: ven_templates_helper
INFO - 2016-05-18 19:46:51 --> Helper loaded: redondear_helper
INFO - 2016-05-18 19:46:51 --> Helper loaded: form_helper
INFO - 2016-05-18 19:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-18 19:46:51 --> Form Validation Class Initialized
INFO - 2016-05-18 19:46:51 --> Controller Class Initialized
INFO - 2016-05-18 19:46:51 --> Model Class Initialized
INFO - 2016-05-18 19:46:51 --> Database Driver Class Initialized
INFO - 2016-05-18 19:46:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-18 19:46:51 --> Pagination Class Initialized
DEBUG - 2016-05-18 19:46:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-18 19:46:51 --> Final output sent to browser
DEBUG - 2016-05-18 19:46:51 --> Total execution time: 0.0952
