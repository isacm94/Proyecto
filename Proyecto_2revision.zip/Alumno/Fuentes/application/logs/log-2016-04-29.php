<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-04-29 17:43:45 --> Config Class Initialized
INFO - 2016-04-29 17:43:45 --> Hooks Class Initialized
DEBUG - 2016-04-29 17:43:45 --> UTF-8 Support Enabled
INFO - 2016-04-29 17:43:45 --> Utf8 Class Initialized
INFO - 2016-04-29 17:43:45 --> URI Class Initialized
INFO - 2016-04-29 17:43:45 --> Router Class Initialized
INFO - 2016-04-29 17:43:45 --> Output Class Initialized
INFO - 2016-04-29 17:43:45 --> Security Class Initialized
DEBUG - 2016-04-29 17:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-29 17:43:45 --> Input Class Initialized
INFO - 2016-04-29 17:43:45 --> Language Class Initialized
INFO - 2016-04-29 17:43:45 --> Loader Class Initialized
INFO - 2016-04-29 17:43:45 --> Helper loaded: url_helper
INFO - 2016-04-29 17:43:45 --> Helper loaded: sesion_helper
INFO - 2016-04-29 17:43:45 --> Helper loaded: templates_helper
INFO - 2016-04-29 17:43:45 --> Helper loaded: form_helper
INFO - 2016-04-29 17:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-29 17:43:45 --> Form Validation Class Initialized
INFO - 2016-04-29 17:43:45 --> Controller Class Initialized
INFO - 2016-04-29 18:24:03 --> Config Class Initialized
INFO - 2016-04-29 18:24:03 --> Hooks Class Initialized
DEBUG - 2016-04-29 18:24:03 --> UTF-8 Support Enabled
INFO - 2016-04-29 18:24:03 --> Utf8 Class Initialized
INFO - 2016-04-29 18:24:03 --> URI Class Initialized
INFO - 2016-04-29 18:24:03 --> Router Class Initialized
INFO - 2016-04-29 18:24:03 --> Output Class Initialized
INFO - 2016-04-29 18:24:03 --> Security Class Initialized
DEBUG - 2016-04-29 18:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-29 18:24:03 --> Input Class Initialized
INFO - 2016-04-29 18:24:03 --> Language Class Initialized
INFO - 2016-04-29 18:24:03 --> Loader Class Initialized
INFO - 2016-04-29 18:24:03 --> Helper loaded: url_helper
INFO - 2016-04-29 18:24:03 --> Helper loaded: sesion_helper
INFO - 2016-04-29 18:24:03 --> Helper loaded: templates_helper
INFO - 2016-04-29 18:24:03 --> Helper loaded: form_helper
INFO - 2016-04-29 18:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-04-29 18:24:03 --> Form Validation Class Initialized
INFO - 2016-04-29 18:24:03 --> Controller Class Initialized
