<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-05 18:22:14 --> Config Class Initialized
INFO - 2016-05-05 18:22:14 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:22:14 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:22:14 --> Utf8 Class Initialized
INFO - 2016-05-05 18:22:14 --> URI Class Initialized
INFO - 2016-05-05 18:22:14 --> Router Class Initialized
INFO - 2016-05-05 18:22:14 --> Output Class Initialized
INFO - 2016-05-05 18:22:14 --> Security Class Initialized
DEBUG - 2016-05-05 18:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:22:14 --> Input Class Initialized
INFO - 2016-05-05 18:22:14 --> Language Class Initialized
INFO - 2016-05-05 18:22:14 --> Loader Class Initialized
INFO - 2016-05-05 18:22:14 --> Helper loaded: url_helper
INFO - 2016-05-05 18:22:14 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:22:14 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:22:14 --> Helper loaded: form_helper
INFO - 2016-05-05 18:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:22:14 --> Form Validation Class Initialized
INFO - 2016-05-05 18:22:14 --> Controller Class Initialized
INFO - 2016-05-05 18:22:14 --> Config Class Initialized
INFO - 2016-05-05 18:22:14 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:22:14 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:22:14 --> Utf8 Class Initialized
INFO - 2016-05-05 18:22:14 --> URI Class Initialized
INFO - 2016-05-05 18:22:14 --> Router Class Initialized
INFO - 2016-05-05 18:22:14 --> Output Class Initialized
INFO - 2016-05-05 18:22:14 --> Security Class Initialized
DEBUG - 2016-05-05 18:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:22:14 --> Input Class Initialized
INFO - 2016-05-05 18:22:14 --> Language Class Initialized
INFO - 2016-05-05 18:22:14 --> Loader Class Initialized
INFO - 2016-05-05 18:22:14 --> Helper loaded: url_helper
INFO - 2016-05-05 18:22:14 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:22:14 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:22:14 --> Helper loaded: form_helper
INFO - 2016-05-05 18:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:22:14 --> Form Validation Class Initialized
INFO - 2016-05-05 18:22:14 --> Controller Class Initialized
INFO - 2016-05-05 18:22:14 --> Model Class Initialized
INFO - 2016-05-05 18:22:14 --> Database Driver Class Initialized
INFO - 2016-05-05 18:22:14 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_login.php
INFO - 2016-05-05 18:22:14 --> Final output sent to browser
DEBUG - 2016-05-05 18:22:14 --> Total execution time: 0.1355
INFO - 2016-05-05 18:23:54 --> Config Class Initialized
INFO - 2016-05-05 18:23:54 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:23:54 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:23:54 --> Utf8 Class Initialized
INFO - 2016-05-05 18:23:54 --> URI Class Initialized
INFO - 2016-05-05 18:23:54 --> Router Class Initialized
INFO - 2016-05-05 18:23:54 --> Output Class Initialized
INFO - 2016-05-05 18:23:54 --> Security Class Initialized
DEBUG - 2016-05-05 18:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:23:54 --> Input Class Initialized
INFO - 2016-05-05 18:23:54 --> Language Class Initialized
INFO - 2016-05-05 18:23:54 --> Loader Class Initialized
INFO - 2016-05-05 18:23:54 --> Helper loaded: url_helper
INFO - 2016-05-05 18:23:54 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:23:54 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:23:54 --> Helper loaded: form_helper
INFO - 2016-05-05 18:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:23:54 --> Form Validation Class Initialized
INFO - 2016-05-05 18:23:54 --> Controller Class Initialized
INFO - 2016-05-05 18:23:54 --> Model Class Initialized
INFO - 2016-05-05 18:23:54 --> Database Driver Class Initialized
INFO - 2016-05-05 18:23:54 --> Config Class Initialized
INFO - 2016-05-05 18:23:54 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:23:54 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:23:54 --> Utf8 Class Initialized
INFO - 2016-05-05 18:23:54 --> URI Class Initialized
INFO - 2016-05-05 18:23:54 --> Router Class Initialized
INFO - 2016-05-05 18:23:54 --> Output Class Initialized
INFO - 2016-05-05 18:23:54 --> Security Class Initialized
DEBUG - 2016-05-05 18:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:23:54 --> Input Class Initialized
INFO - 2016-05-05 18:23:54 --> Language Class Initialized
INFO - 2016-05-05 18:23:54 --> Loader Class Initialized
INFO - 2016-05-05 18:23:54 --> Helper loaded: url_helper
INFO - 2016-05-05 18:23:54 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:23:54 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:23:54 --> Helper loaded: form_helper
INFO - 2016-05-05 18:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:23:54 --> Form Validation Class Initialized
INFO - 2016-05-05 18:23:54 --> Controller Class Initialized
INFO - 2016-05-05 18:23:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-05 18:23:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-05 18:23:54 --> Final output sent to browser
DEBUG - 2016-05-05 18:23:54 --> Total execution time: 0.0488
INFO - 2016-05-05 18:24:39 --> Config Class Initialized
INFO - 2016-05-05 18:24:39 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:24:39 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:24:39 --> Utf8 Class Initialized
INFO - 2016-05-05 18:24:39 --> URI Class Initialized
INFO - 2016-05-05 18:24:39 --> Router Class Initialized
INFO - 2016-05-05 18:24:39 --> Output Class Initialized
INFO - 2016-05-05 18:24:39 --> Security Class Initialized
DEBUG - 2016-05-05 18:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:24:39 --> Input Class Initialized
INFO - 2016-05-05 18:24:39 --> Language Class Initialized
INFO - 2016-05-05 18:24:39 --> Loader Class Initialized
INFO - 2016-05-05 18:24:39 --> Helper loaded: url_helper
INFO - 2016-05-05 18:24:39 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:24:39 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:24:39 --> Helper loaded: form_helper
INFO - 2016-05-05 18:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:24:39 --> Form Validation Class Initialized
INFO - 2016-05-05 18:24:39 --> Controller Class Initialized
INFO - 2016-05-05 18:24:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-05 18:24:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template1.php
INFO - 2016-05-05 18:24:39 --> Final output sent to browser
DEBUG - 2016-05-05 18:24:39 --> Total execution time: 0.0500
INFO - 2016-05-05 18:24:41 --> Config Class Initialized
INFO - 2016-05-05 18:24:41 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:24:41 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:24:41 --> Utf8 Class Initialized
INFO - 2016-05-05 18:24:41 --> URI Class Initialized
INFO - 2016-05-05 18:24:41 --> Router Class Initialized
INFO - 2016-05-05 18:24:41 --> Output Class Initialized
INFO - 2016-05-05 18:24:41 --> Security Class Initialized
DEBUG - 2016-05-05 18:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:24:41 --> Input Class Initialized
INFO - 2016-05-05 18:24:41 --> Language Class Initialized
INFO - 2016-05-05 18:24:41 --> Loader Class Initialized
INFO - 2016-05-05 18:24:41 --> Helper loaded: url_helper
INFO - 2016-05-05 18:24:41 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:24:41 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:24:41 --> Helper loaded: form_helper
INFO - 2016-05-05 18:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:24:41 --> Form Validation Class Initialized
INFO - 2016-05-05 18:24:41 --> Controller Class Initialized
INFO - 2016-05-05 18:24:41 --> Config Class Initialized
INFO - 2016-05-05 18:24:41 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:24:41 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:24:41 --> Utf8 Class Initialized
INFO - 2016-05-05 18:24:41 --> URI Class Initialized
INFO - 2016-05-05 18:24:41 --> Router Class Initialized
INFO - 2016-05-05 18:24:41 --> Output Class Initialized
INFO - 2016-05-05 18:24:41 --> Security Class Initialized
DEBUG - 2016-05-05 18:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:24:41 --> Input Class Initialized
INFO - 2016-05-05 18:24:41 --> Language Class Initialized
INFO - 2016-05-05 18:24:41 --> Loader Class Initialized
INFO - 2016-05-05 18:24:41 --> Helper loaded: url_helper
INFO - 2016-05-05 18:24:41 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:24:41 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:24:41 --> Helper loaded: form_helper
INFO - 2016-05-05 18:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:24:41 --> Form Validation Class Initialized
INFO - 2016-05-05 18:24:41 --> Controller Class Initialized
INFO - 2016-05-05 18:24:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\config_plantillas.php
INFO - 2016-05-05 18:24:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:24:41 --> Final output sent to browser
DEBUG - 2016-05-05 18:24:41 --> Total execution time: 0.0559
INFO - 2016-05-05 18:24:51 --> Config Class Initialized
INFO - 2016-05-05 18:24:51 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:24:51 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:24:51 --> Utf8 Class Initialized
INFO - 2016-05-05 18:24:51 --> URI Class Initialized
INFO - 2016-05-05 18:24:51 --> Router Class Initialized
INFO - 2016-05-05 18:24:51 --> Output Class Initialized
INFO - 2016-05-05 18:24:51 --> Security Class Initialized
DEBUG - 2016-05-05 18:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:24:51 --> Input Class Initialized
INFO - 2016-05-05 18:24:51 --> Language Class Initialized
INFO - 2016-05-05 18:24:51 --> Loader Class Initialized
INFO - 2016-05-05 18:24:51 --> Helper loaded: url_helper
INFO - 2016-05-05 18:24:51 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:24:51 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:24:51 --> Helper loaded: form_helper
INFO - 2016-05-05 18:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:24:51 --> Form Validation Class Initialized
INFO - 2016-05-05 18:24:51 --> Controller Class Initialized
INFO - 2016-05-05 18:24:51 --> Model Class Initialized
INFO - 2016-05-05 18:24:51 --> Database Driver Class Initialized
INFO - 2016-05-05 18:24:51 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:24:51 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:24:51 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:24:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 18:24:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:24:51 --> Final output sent to browser
DEBUG - 2016-05-05 18:24:51 --> Total execution time: 0.1884
INFO - 2016-05-05 18:30:21 --> Config Class Initialized
INFO - 2016-05-05 18:30:21 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:30:21 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:30:21 --> Utf8 Class Initialized
INFO - 2016-05-05 18:30:21 --> URI Class Initialized
INFO - 2016-05-05 18:30:21 --> Router Class Initialized
INFO - 2016-05-05 18:30:21 --> Output Class Initialized
INFO - 2016-05-05 18:30:21 --> Security Class Initialized
DEBUG - 2016-05-05 18:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:30:21 --> Input Class Initialized
INFO - 2016-05-05 18:30:21 --> Language Class Initialized
INFO - 2016-05-05 18:30:21 --> Loader Class Initialized
INFO - 2016-05-05 18:30:21 --> Helper loaded: url_helper
INFO - 2016-05-05 18:30:21 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:30:21 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:30:21 --> Helper loaded: form_helper
INFO - 2016-05-05 18:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:30:21 --> Form Validation Class Initialized
INFO - 2016-05-05 18:30:21 --> Controller Class Initialized
INFO - 2016-05-05 18:30:21 --> Model Class Initialized
INFO - 2016-05-05 18:30:21 --> Database Driver Class Initialized
INFO - 2016-05-05 18:30:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:30:21 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:30:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:30:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 18:30:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:30:21 --> Final output sent to browser
DEBUG - 2016-05-05 18:30:21 --> Total execution time: 0.0963
INFO - 2016-05-05 18:30:26 --> Config Class Initialized
INFO - 2016-05-05 18:30:26 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:30:26 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:30:26 --> Utf8 Class Initialized
INFO - 2016-05-05 18:30:26 --> URI Class Initialized
INFO - 2016-05-05 18:30:26 --> Router Class Initialized
INFO - 2016-05-05 18:30:26 --> Output Class Initialized
INFO - 2016-05-05 18:30:26 --> Security Class Initialized
DEBUG - 2016-05-05 18:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:30:26 --> Input Class Initialized
INFO - 2016-05-05 18:30:26 --> Language Class Initialized
INFO - 2016-05-05 18:30:26 --> Loader Class Initialized
INFO - 2016-05-05 18:30:26 --> Helper loaded: url_helper
INFO - 2016-05-05 18:30:26 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:30:26 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:30:26 --> Helper loaded: form_helper
INFO - 2016-05-05 18:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:30:26 --> Form Validation Class Initialized
INFO - 2016-05-05 18:30:26 --> Controller Class Initialized
INFO - 2016-05-05 18:30:26 --> Model Class Initialized
INFO - 2016-05-05 18:30:26 --> Database Driver Class Initialized
INFO - 2016-05-05 18:30:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:30:26 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:30:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:30:26 --> Config Class Initialized
INFO - 2016-05-05 18:30:26 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:30:26 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:30:26 --> Utf8 Class Initialized
INFO - 2016-05-05 18:30:26 --> URI Class Initialized
INFO - 2016-05-05 18:30:26 --> Router Class Initialized
INFO - 2016-05-05 18:30:26 --> Output Class Initialized
INFO - 2016-05-05 18:30:26 --> Security Class Initialized
DEBUG - 2016-05-05 18:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:30:26 --> Input Class Initialized
INFO - 2016-05-05 18:30:26 --> Language Class Initialized
INFO - 2016-05-05 18:30:26 --> Loader Class Initialized
INFO - 2016-05-05 18:30:26 --> Helper loaded: url_helper
INFO - 2016-05-05 18:30:26 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:30:26 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:30:26 --> Helper loaded: form_helper
INFO - 2016-05-05 18:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:30:26 --> Form Validation Class Initialized
INFO - 2016-05-05 18:30:26 --> Controller Class Initialized
INFO - 2016-05-05 18:30:26 --> Model Class Initialized
INFO - 2016-05-05 18:30:26 --> Database Driver Class Initialized
INFO - 2016-05-05 18:30:26 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:30:26 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:30:26 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:30:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 18:30:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:30:27 --> Final output sent to browser
DEBUG - 2016-05-05 18:30:27 --> Total execution time: 0.3640
INFO - 2016-05-05 18:30:34 --> Config Class Initialized
INFO - 2016-05-05 18:30:34 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:30:34 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:30:34 --> Utf8 Class Initialized
INFO - 2016-05-05 18:30:34 --> URI Class Initialized
INFO - 2016-05-05 18:30:34 --> Router Class Initialized
INFO - 2016-05-05 18:30:34 --> Output Class Initialized
INFO - 2016-05-05 18:30:34 --> Security Class Initialized
DEBUG - 2016-05-05 18:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:30:34 --> Input Class Initialized
INFO - 2016-05-05 18:30:34 --> Language Class Initialized
INFO - 2016-05-05 18:30:34 --> Loader Class Initialized
INFO - 2016-05-05 18:30:34 --> Helper loaded: url_helper
INFO - 2016-05-05 18:30:34 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:30:34 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:30:34 --> Helper loaded: form_helper
INFO - 2016-05-05 18:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:30:34 --> Form Validation Class Initialized
INFO - 2016-05-05 18:30:34 --> Controller Class Initialized
INFO - 2016-05-05 18:30:34 --> Model Class Initialized
INFO - 2016-05-05 18:30:34 --> Database Driver Class Initialized
INFO - 2016-05-05 18:30:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:30:34 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:30:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:30:34 --> Config Class Initialized
INFO - 2016-05-05 18:30:34 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:30:34 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:30:34 --> Utf8 Class Initialized
INFO - 2016-05-05 18:30:34 --> URI Class Initialized
INFO - 2016-05-05 18:30:34 --> Router Class Initialized
INFO - 2016-05-05 18:30:34 --> Output Class Initialized
INFO - 2016-05-05 18:30:34 --> Security Class Initialized
DEBUG - 2016-05-05 18:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:30:34 --> Input Class Initialized
INFO - 2016-05-05 18:30:34 --> Language Class Initialized
INFO - 2016-05-05 18:30:34 --> Loader Class Initialized
INFO - 2016-05-05 18:30:34 --> Helper loaded: url_helper
INFO - 2016-05-05 18:30:34 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:30:34 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:30:34 --> Helper loaded: form_helper
INFO - 2016-05-05 18:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:30:34 --> Form Validation Class Initialized
INFO - 2016-05-05 18:30:34 --> Controller Class Initialized
INFO - 2016-05-05 18:30:34 --> Model Class Initialized
INFO - 2016-05-05 18:30:34 --> Database Driver Class Initialized
INFO - 2016-05-05 18:30:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:30:34 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:30:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:30:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 18:30:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:30:34 --> Final output sent to browser
DEBUG - 2016-05-05 18:30:34 --> Total execution time: 0.0947
INFO - 2016-05-05 18:33:43 --> Config Class Initialized
INFO - 2016-05-05 18:33:43 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:33:43 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:33:43 --> Utf8 Class Initialized
INFO - 2016-05-05 18:33:43 --> URI Class Initialized
INFO - 2016-05-05 18:33:43 --> Router Class Initialized
INFO - 2016-05-05 18:33:43 --> Output Class Initialized
INFO - 2016-05-05 18:33:43 --> Security Class Initialized
DEBUG - 2016-05-05 18:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:33:43 --> Input Class Initialized
INFO - 2016-05-05 18:33:43 --> Language Class Initialized
INFO - 2016-05-05 18:33:43 --> Loader Class Initialized
INFO - 2016-05-05 18:33:43 --> Helper loaded: url_helper
INFO - 2016-05-05 18:33:43 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:33:43 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:33:43 --> Helper loaded: form_helper
INFO - 2016-05-05 18:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:33:43 --> Form Validation Class Initialized
INFO - 2016-05-05 18:33:43 --> Controller Class Initialized
INFO - 2016-05-05 18:33:43 --> Model Class Initialized
INFO - 2016-05-05 18:33:43 --> Database Driver Class Initialized
INFO - 2016-05-05 18:33:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:33:43 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:33:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:33:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-05 18:33:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:33:43 --> Final output sent to browser
DEBUG - 2016-05-05 18:33:43 --> Total execution time: 0.0971
INFO - 2016-05-05 18:34:51 --> Config Class Initialized
INFO - 2016-05-05 18:34:51 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:34:51 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:34:51 --> Utf8 Class Initialized
INFO - 2016-05-05 18:34:52 --> URI Class Initialized
INFO - 2016-05-05 18:34:52 --> Router Class Initialized
INFO - 2016-05-05 18:34:52 --> Output Class Initialized
INFO - 2016-05-05 18:34:52 --> Security Class Initialized
DEBUG - 2016-05-05 18:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:34:52 --> Input Class Initialized
INFO - 2016-05-05 18:34:52 --> Language Class Initialized
INFO - 2016-05-05 18:34:52 --> Loader Class Initialized
INFO - 2016-05-05 18:34:52 --> Helper loaded: url_helper
INFO - 2016-05-05 18:34:52 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:34:52 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:34:52 --> Helper loaded: form_helper
INFO - 2016-05-05 18:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:34:52 --> Form Validation Class Initialized
INFO - 2016-05-05 18:34:52 --> Controller Class Initialized
INFO - 2016-05-05 18:34:52 --> Model Class Initialized
INFO - 2016-05-05 18:34:52 --> Database Driver Class Initialized
INFO - 2016-05-05 18:34:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:34:52 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:34:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:34:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-05 18:34:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:34:52 --> Final output sent to browser
DEBUG - 2016-05-05 18:34:52 --> Total execution time: 0.0988
INFO - 2016-05-05 18:34:55 --> Config Class Initialized
INFO - 2016-05-05 18:34:55 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:34:55 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:34:55 --> Utf8 Class Initialized
INFO - 2016-05-05 18:34:55 --> URI Class Initialized
INFO - 2016-05-05 18:34:55 --> Router Class Initialized
INFO - 2016-05-05 18:34:55 --> Output Class Initialized
INFO - 2016-05-05 18:34:55 --> Security Class Initialized
DEBUG - 2016-05-05 18:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:34:55 --> Input Class Initialized
INFO - 2016-05-05 18:34:55 --> Language Class Initialized
INFO - 2016-05-05 18:34:55 --> Loader Class Initialized
INFO - 2016-05-05 18:34:55 --> Helper loaded: url_helper
INFO - 2016-05-05 18:34:55 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:34:55 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:34:55 --> Helper loaded: form_helper
INFO - 2016-05-05 18:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:34:55 --> Form Validation Class Initialized
INFO - 2016-05-05 18:34:55 --> Controller Class Initialized
INFO - 2016-05-05 18:34:55 --> Model Class Initialized
INFO - 2016-05-05 18:34:55 --> Database Driver Class Initialized
INFO - 2016-05-05 18:34:55 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:34:55 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:34:55 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:34:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 18:34:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:34:55 --> Final output sent to browser
DEBUG - 2016-05-05 18:34:55 --> Total execution time: 0.0921
INFO - 2016-05-05 18:40:36 --> Config Class Initialized
INFO - 2016-05-05 18:40:36 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:40:36 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:40:36 --> Utf8 Class Initialized
INFO - 2016-05-05 18:40:36 --> URI Class Initialized
INFO - 2016-05-05 18:40:36 --> Router Class Initialized
INFO - 2016-05-05 18:40:36 --> Output Class Initialized
INFO - 2016-05-05 18:40:36 --> Security Class Initialized
DEBUG - 2016-05-05 18:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:40:36 --> Input Class Initialized
INFO - 2016-05-05 18:40:36 --> Language Class Initialized
INFO - 2016-05-05 18:40:36 --> Loader Class Initialized
INFO - 2016-05-05 18:40:36 --> Helper loaded: url_helper
INFO - 2016-05-05 18:40:36 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:40:36 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:40:36 --> Helper loaded: form_helper
INFO - 2016-05-05 18:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:40:36 --> Form Validation Class Initialized
INFO - 2016-05-05 18:40:36 --> Controller Class Initialized
INFO - 2016-05-05 18:40:36 --> Model Class Initialized
INFO - 2016-05-05 18:40:36 --> Database Driver Class Initialized
INFO - 2016-05-05 18:40:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:40:36 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:40:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:40:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 18:40:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:40:36 --> Final output sent to browser
DEBUG - 2016-05-05 18:40:36 --> Total execution time: 0.1645
INFO - 2016-05-05 18:40:38 --> Config Class Initialized
INFO - 2016-05-05 18:40:38 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:40:38 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:40:38 --> Utf8 Class Initialized
INFO - 2016-05-05 18:40:38 --> URI Class Initialized
INFO - 2016-05-05 18:40:38 --> Router Class Initialized
INFO - 2016-05-05 18:40:38 --> Output Class Initialized
INFO - 2016-05-05 18:40:38 --> Security Class Initialized
DEBUG - 2016-05-05 18:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:40:38 --> Input Class Initialized
INFO - 2016-05-05 18:40:38 --> Language Class Initialized
INFO - 2016-05-05 18:40:38 --> Loader Class Initialized
INFO - 2016-05-05 18:40:38 --> Helper loaded: url_helper
INFO - 2016-05-05 18:40:38 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:40:38 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:40:38 --> Helper loaded: form_helper
INFO - 2016-05-05 18:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:40:38 --> Form Validation Class Initialized
INFO - 2016-05-05 18:40:38 --> Controller Class Initialized
INFO - 2016-05-05 18:40:38 --> Model Class Initialized
INFO - 2016-05-05 18:40:38 --> Database Driver Class Initialized
INFO - 2016-05-05 18:40:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:40:38 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:40:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-05 18:40:38 --> Query error: Unknown table 'pro' - Invalid query: SELECT pro.*, prov.nombre 'proveedor' , caat.nombre 'categoria' FROM producto prod INNER JOIN proveedor prov on prod.idProveedor = prov.idProveedor INNER JOIN categoria cat on prod.idCategoria = cat.idCategoria WHERE idProveedor = '5'
INFO - 2016-05-05 18:40:38 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-05 18:40:53 --> Config Class Initialized
INFO - 2016-05-05 18:40:53 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:40:53 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:40:53 --> Utf8 Class Initialized
INFO - 2016-05-05 18:40:53 --> URI Class Initialized
INFO - 2016-05-05 18:40:53 --> Router Class Initialized
INFO - 2016-05-05 18:40:53 --> Output Class Initialized
INFO - 2016-05-05 18:40:53 --> Security Class Initialized
DEBUG - 2016-05-05 18:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:40:53 --> Input Class Initialized
INFO - 2016-05-05 18:40:53 --> Language Class Initialized
INFO - 2016-05-05 18:40:53 --> Loader Class Initialized
INFO - 2016-05-05 18:40:53 --> Helper loaded: url_helper
INFO - 2016-05-05 18:40:53 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:40:53 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:40:53 --> Helper loaded: form_helper
INFO - 2016-05-05 18:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:40:53 --> Form Validation Class Initialized
INFO - 2016-05-05 18:40:53 --> Controller Class Initialized
INFO - 2016-05-05 18:40:53 --> Model Class Initialized
INFO - 2016-05-05 18:40:53 --> Database Driver Class Initialized
INFO - 2016-05-05 18:40:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:40:53 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:40:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-05 18:40:53 --> Query error: Unknown column 'caat.nombre' in 'field list' - Invalid query: SELECT prod.*, prov.nombre 'proveedor' , caat.nombre 'categoria' FROM producto prod INNER JOIN proveedor prov on prod.idProveedor = prov.idProveedor INNER JOIN categoria cat on prod.idCategoria = cat.idCategoria WHERE idProveedor = '5'
INFO - 2016-05-05 18:40:53 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-05 18:40:59 --> Config Class Initialized
INFO - 2016-05-05 18:40:59 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:40:59 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:40:59 --> Utf8 Class Initialized
INFO - 2016-05-05 18:40:59 --> URI Class Initialized
INFO - 2016-05-05 18:40:59 --> Router Class Initialized
INFO - 2016-05-05 18:40:59 --> Output Class Initialized
INFO - 2016-05-05 18:40:59 --> Security Class Initialized
DEBUG - 2016-05-05 18:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:40:59 --> Input Class Initialized
INFO - 2016-05-05 18:40:59 --> Language Class Initialized
INFO - 2016-05-05 18:40:59 --> Loader Class Initialized
INFO - 2016-05-05 18:40:59 --> Helper loaded: url_helper
INFO - 2016-05-05 18:40:59 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:40:59 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:40:59 --> Helper loaded: form_helper
INFO - 2016-05-05 18:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:40:59 --> Form Validation Class Initialized
INFO - 2016-05-05 18:40:59 --> Controller Class Initialized
INFO - 2016-05-05 18:40:59 --> Model Class Initialized
INFO - 2016-05-05 18:40:59 --> Database Driver Class Initialized
INFO - 2016-05-05 18:40:59 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:40:59 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:40:59 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-05 18:40:59 --> Query error: Column 'idProveedor' in where clause is ambiguous - Invalid query: SELECT prod.*, prov.nombre 'proveedor' , cat.nombre 'categoria' FROM producto prod INNER JOIN proveedor prov on prod.idProveedor = prov.idProveedor INNER JOIN categoria cat on prod.idCategoria = cat.idCategoria WHERE idProveedor = '5'
INFO - 2016-05-05 18:40:59 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-05 18:41:18 --> Config Class Initialized
INFO - 2016-05-05 18:41:18 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:41:18 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:41:18 --> Utf8 Class Initialized
INFO - 2016-05-05 18:41:18 --> URI Class Initialized
INFO - 2016-05-05 18:41:18 --> Router Class Initialized
INFO - 2016-05-05 18:41:18 --> Output Class Initialized
INFO - 2016-05-05 18:41:18 --> Security Class Initialized
DEBUG - 2016-05-05 18:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:41:18 --> Input Class Initialized
INFO - 2016-05-05 18:41:18 --> Language Class Initialized
INFO - 2016-05-05 18:41:18 --> Loader Class Initialized
INFO - 2016-05-05 18:41:18 --> Helper loaded: url_helper
INFO - 2016-05-05 18:41:18 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:41:18 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:41:18 --> Helper loaded: form_helper
INFO - 2016-05-05 18:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:41:18 --> Form Validation Class Initialized
INFO - 2016-05-05 18:41:18 --> Controller Class Initialized
INFO - 2016-05-05 18:41:18 --> Model Class Initialized
INFO - 2016-05-05 18:41:18 --> Database Driver Class Initialized
INFO - 2016-05-05 18:41:18 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:41:18 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:41:18 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-05 18:41:18 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 7
ERROR - 2016-05-05 18:41:18 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 19
ERROR - 2016-05-05 18:41:18 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 25
ERROR - 2016-05-05 18:41:18 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 26
ERROR - 2016-05-05 18:41:18 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 27
ERROR - 2016-05-05 18:41:18 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 27
ERROR - 2016-05-05 18:41:18 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 28
ERROR - 2016-05-05 18:41:18 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 32
ERROR - 2016-05-05 18:41:18 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 33
ERROR - 2016-05-05 18:41:18 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 34
ERROR - 2016-05-05 18:41:18 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 35
ERROR - 2016-05-05 18:41:18 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 39
INFO - 2016-05-05 18:41:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 18:41:18 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:41:18 --> Final output sent to browser
DEBUG - 2016-05-05 18:41:18 --> Total execution time: 0.0970
INFO - 2016-05-05 18:41:35 --> Config Class Initialized
INFO - 2016-05-05 18:41:35 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:41:35 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:41:35 --> Utf8 Class Initialized
INFO - 2016-05-05 18:41:35 --> URI Class Initialized
INFO - 2016-05-05 18:41:35 --> Router Class Initialized
INFO - 2016-05-05 18:41:35 --> Output Class Initialized
INFO - 2016-05-05 18:41:35 --> Security Class Initialized
DEBUG - 2016-05-05 18:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:41:35 --> Input Class Initialized
INFO - 2016-05-05 18:41:35 --> Language Class Initialized
INFO - 2016-05-05 18:41:35 --> Loader Class Initialized
INFO - 2016-05-05 18:41:35 --> Helper loaded: url_helper
INFO - 2016-05-05 18:41:35 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:41:35 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:41:35 --> Helper loaded: form_helper
INFO - 2016-05-05 18:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:41:35 --> Form Validation Class Initialized
INFO - 2016-05-05 18:41:35 --> Controller Class Initialized
INFO - 2016-05-05 18:41:35 --> Model Class Initialized
INFO - 2016-05-05 18:41:35 --> Database Driver Class Initialized
INFO - 2016-05-05 18:41:35 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:41:35 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:41:35 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-05 18:41:35 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 19
ERROR - 2016-05-05 18:41:35 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 25
ERROR - 2016-05-05 18:41:35 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 26
ERROR - 2016-05-05 18:41:35 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 27
ERROR - 2016-05-05 18:41:35 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 27
ERROR - 2016-05-05 18:41:35 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 28
ERROR - 2016-05-05 18:41:35 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 32
ERROR - 2016-05-05 18:41:35 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 33
ERROR - 2016-05-05 18:41:35 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 34
ERROR - 2016-05-05 18:41:35 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 35
ERROR - 2016-05-05 18:41:35 --> Severity: Notice --> Undefined variable: proveedor C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 39
INFO - 2016-05-05 18:41:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 18:41:35 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:41:35 --> Final output sent to browser
DEBUG - 2016-05-05 18:41:35 --> Total execution time: 0.0957
INFO - 2016-05-05 18:43:01 --> Config Class Initialized
INFO - 2016-05-05 18:43:01 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:43:01 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:43:01 --> Utf8 Class Initialized
INFO - 2016-05-05 18:43:01 --> URI Class Initialized
INFO - 2016-05-05 18:43:01 --> Router Class Initialized
INFO - 2016-05-05 18:43:01 --> Output Class Initialized
INFO - 2016-05-05 18:43:01 --> Security Class Initialized
DEBUG - 2016-05-05 18:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:43:01 --> Input Class Initialized
INFO - 2016-05-05 18:43:01 --> Language Class Initialized
INFO - 2016-05-05 18:43:01 --> Loader Class Initialized
INFO - 2016-05-05 18:43:01 --> Helper loaded: url_helper
INFO - 2016-05-05 18:43:01 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:43:01 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:43:01 --> Helper loaded: form_helper
INFO - 2016-05-05 18:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:43:01 --> Form Validation Class Initialized
INFO - 2016-05-05 18:43:01 --> Controller Class Initialized
INFO - 2016-05-05 18:43:01 --> Model Class Initialized
INFO - 2016-05-05 18:43:01 --> Database Driver Class Initialized
INFO - 2016-05-05 18:43:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:43:01 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:43:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-05 18:43:01 --> Severity: Notice --> Undefined index: direccion C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 32
ERROR - 2016-05-05 18:43:01 --> Severity: Notice --> Undefined index: localidad C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 33
ERROR - 2016-05-05 18:43:01 --> Severity: Notice --> Undefined index: cp C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 34
ERROR - 2016-05-05 18:43:01 --> Severity: Notice --> Undefined index: provincia C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 35
ERROR - 2016-05-05 18:43:01 --> Severity: Notice --> Undefined index: anotaciones C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 39
INFO - 2016-05-05 18:43:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 18:43:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:43:01 --> Final output sent to browser
DEBUG - 2016-05-05 18:43:01 --> Total execution time: 0.1250
INFO - 2016-05-05 18:43:43 --> Config Class Initialized
INFO - 2016-05-05 18:43:43 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:43:43 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:43:43 --> Utf8 Class Initialized
INFO - 2016-05-05 18:43:43 --> URI Class Initialized
INFO - 2016-05-05 18:43:43 --> Router Class Initialized
INFO - 2016-05-05 18:43:43 --> Output Class Initialized
INFO - 2016-05-05 18:43:43 --> Security Class Initialized
DEBUG - 2016-05-05 18:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:43:43 --> Input Class Initialized
INFO - 2016-05-05 18:43:43 --> Language Class Initialized
INFO - 2016-05-05 18:43:43 --> Loader Class Initialized
INFO - 2016-05-05 18:43:43 --> Helper loaded: url_helper
INFO - 2016-05-05 18:43:43 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:43:43 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:43:43 --> Helper loaded: form_helper
INFO - 2016-05-05 18:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:43:43 --> Form Validation Class Initialized
INFO - 2016-05-05 18:43:43 --> Controller Class Initialized
INFO - 2016-05-05 18:43:43 --> Model Class Initialized
INFO - 2016-05-05 18:43:43 --> Database Driver Class Initialized
INFO - 2016-05-05 18:43:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:43:43 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:43:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-05 18:43:43 --> Severity: Notice --> Undefined index: anotaciones C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php 37
INFO - 2016-05-05 18:43:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 18:43:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:43:43 --> Final output sent to browser
DEBUG - 2016-05-05 18:43:43 --> Total execution time: 0.1009
INFO - 2016-05-05 18:44:50 --> Config Class Initialized
INFO - 2016-05-05 18:44:50 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:44:50 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:44:50 --> Utf8 Class Initialized
INFO - 2016-05-05 18:44:50 --> URI Class Initialized
INFO - 2016-05-05 18:44:50 --> Router Class Initialized
INFO - 2016-05-05 18:44:50 --> Output Class Initialized
INFO - 2016-05-05 18:44:50 --> Security Class Initialized
DEBUG - 2016-05-05 18:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:44:50 --> Input Class Initialized
INFO - 2016-05-05 18:44:50 --> Language Class Initialized
INFO - 2016-05-05 18:44:50 --> Loader Class Initialized
INFO - 2016-05-05 18:44:50 --> Helper loaded: url_helper
INFO - 2016-05-05 18:44:50 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:44:50 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:44:50 --> Helper loaded: form_helper
INFO - 2016-05-05 18:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:44:50 --> Form Validation Class Initialized
INFO - 2016-05-05 18:44:50 --> Controller Class Initialized
INFO - 2016-05-05 18:44:50 --> Model Class Initialized
INFO - 2016-05-05 18:44:50 --> Database Driver Class Initialized
INFO - 2016-05-05 18:44:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:44:50 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:44:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:44:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 18:44:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:44:50 --> Final output sent to browser
DEBUG - 2016-05-05 18:44:50 --> Total execution time: 0.1015
INFO - 2016-05-05 18:45:46 --> Config Class Initialized
INFO - 2016-05-05 18:45:46 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:45:46 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:45:46 --> Utf8 Class Initialized
INFO - 2016-05-05 18:45:46 --> URI Class Initialized
INFO - 2016-05-05 18:45:46 --> Router Class Initialized
INFO - 2016-05-05 18:45:46 --> Output Class Initialized
INFO - 2016-05-05 18:45:46 --> Security Class Initialized
DEBUG - 2016-05-05 18:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:45:46 --> Input Class Initialized
INFO - 2016-05-05 18:45:46 --> Language Class Initialized
INFO - 2016-05-05 18:45:46 --> Loader Class Initialized
INFO - 2016-05-05 18:45:46 --> Helper loaded: url_helper
INFO - 2016-05-05 18:45:46 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:45:47 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:45:47 --> Helper loaded: form_helper
INFO - 2016-05-05 18:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:45:47 --> Form Validation Class Initialized
INFO - 2016-05-05 18:45:47 --> Controller Class Initialized
INFO - 2016-05-05 18:45:47 --> Model Class Initialized
INFO - 2016-05-05 18:45:47 --> Database Driver Class Initialized
INFO - 2016-05-05 18:45:47 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:45:47 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:45:47 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:45:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 18:45:47 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:45:47 --> Final output sent to browser
DEBUG - 2016-05-05 18:45:47 --> Total execution time: 0.0852
INFO - 2016-05-05 18:46:09 --> Config Class Initialized
INFO - 2016-05-05 18:46:09 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:46:09 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:46:09 --> Utf8 Class Initialized
INFO - 2016-05-05 18:46:09 --> URI Class Initialized
INFO - 2016-05-05 18:46:09 --> Router Class Initialized
INFO - 2016-05-05 18:46:09 --> Output Class Initialized
INFO - 2016-05-05 18:46:09 --> Security Class Initialized
DEBUG - 2016-05-05 18:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:46:09 --> Input Class Initialized
INFO - 2016-05-05 18:46:09 --> Language Class Initialized
INFO - 2016-05-05 18:46:09 --> Loader Class Initialized
INFO - 2016-05-05 18:46:09 --> Helper loaded: url_helper
INFO - 2016-05-05 18:46:09 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:46:09 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:46:09 --> Helper loaded: form_helper
INFO - 2016-05-05 18:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:46:09 --> Form Validation Class Initialized
INFO - 2016-05-05 18:46:09 --> Controller Class Initialized
INFO - 2016-05-05 18:46:09 --> Model Class Initialized
INFO - 2016-05-05 18:46:09 --> Database Driver Class Initialized
INFO - 2016-05-05 18:46:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:46:09 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:46:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:46:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 18:46:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:46:09 --> Final output sent to browser
DEBUG - 2016-05-05 18:46:09 --> Total execution time: 0.1190
INFO - 2016-05-05 18:46:38 --> Config Class Initialized
INFO - 2016-05-05 18:46:38 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:46:38 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:46:38 --> Utf8 Class Initialized
INFO - 2016-05-05 18:46:38 --> URI Class Initialized
INFO - 2016-05-05 18:46:38 --> Router Class Initialized
INFO - 2016-05-05 18:46:38 --> Output Class Initialized
INFO - 2016-05-05 18:46:38 --> Security Class Initialized
DEBUG - 2016-05-05 18:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:46:38 --> Input Class Initialized
INFO - 2016-05-05 18:46:38 --> Language Class Initialized
INFO - 2016-05-05 18:46:38 --> Loader Class Initialized
INFO - 2016-05-05 18:46:38 --> Helper loaded: url_helper
INFO - 2016-05-05 18:46:38 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:46:38 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:46:38 --> Helper loaded: form_helper
INFO - 2016-05-05 18:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:46:38 --> Form Validation Class Initialized
INFO - 2016-05-05 18:46:38 --> Controller Class Initialized
INFO - 2016-05-05 18:46:38 --> Model Class Initialized
INFO - 2016-05-05 18:46:38 --> Database Driver Class Initialized
INFO - 2016-05-05 18:46:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:46:38 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:46:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:46:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 18:46:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:46:38 --> Final output sent to browser
DEBUG - 2016-05-05 18:46:38 --> Total execution time: 0.0773
INFO - 2016-05-05 18:47:05 --> Config Class Initialized
INFO - 2016-05-05 18:47:05 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:47:05 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:47:05 --> Utf8 Class Initialized
INFO - 2016-05-05 18:47:05 --> URI Class Initialized
INFO - 2016-05-05 18:47:05 --> Router Class Initialized
INFO - 2016-05-05 18:47:05 --> Output Class Initialized
INFO - 2016-05-05 18:47:05 --> Security Class Initialized
DEBUG - 2016-05-05 18:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:47:05 --> Input Class Initialized
INFO - 2016-05-05 18:47:05 --> Language Class Initialized
INFO - 2016-05-05 18:47:05 --> Loader Class Initialized
INFO - 2016-05-05 18:47:05 --> Helper loaded: url_helper
INFO - 2016-05-05 18:47:05 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:47:05 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:47:05 --> Helper loaded: form_helper
INFO - 2016-05-05 18:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:47:05 --> Form Validation Class Initialized
INFO - 2016-05-05 18:47:05 --> Controller Class Initialized
INFO - 2016-05-05 18:47:05 --> Model Class Initialized
INFO - 2016-05-05 18:47:05 --> Database Driver Class Initialized
INFO - 2016-05-05 18:47:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:47:05 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:47:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:47:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 18:47:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:47:05 --> Final output sent to browser
DEBUG - 2016-05-05 18:47:05 --> Total execution time: 0.1378
INFO - 2016-05-05 18:47:29 --> Config Class Initialized
INFO - 2016-05-05 18:47:29 --> Hooks Class Initialized
DEBUG - 2016-05-05 18:47:29 --> UTF-8 Support Enabled
INFO - 2016-05-05 18:47:29 --> Utf8 Class Initialized
INFO - 2016-05-05 18:47:29 --> URI Class Initialized
INFO - 2016-05-05 18:47:29 --> Router Class Initialized
INFO - 2016-05-05 18:47:29 --> Output Class Initialized
INFO - 2016-05-05 18:47:29 --> Security Class Initialized
DEBUG - 2016-05-05 18:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 18:47:29 --> Input Class Initialized
INFO - 2016-05-05 18:47:29 --> Language Class Initialized
INFO - 2016-05-05 18:47:29 --> Loader Class Initialized
INFO - 2016-05-05 18:47:29 --> Helper loaded: url_helper
INFO - 2016-05-05 18:47:29 --> Helper loaded: sesion_helper
INFO - 2016-05-05 18:47:29 --> Helper loaded: templates_helper
INFO - 2016-05-05 18:47:29 --> Helper loaded: form_helper
INFO - 2016-05-05 18:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 18:47:29 --> Form Validation Class Initialized
INFO - 2016-05-05 18:47:29 --> Controller Class Initialized
INFO - 2016-05-05 18:47:29 --> Model Class Initialized
INFO - 2016-05-05 18:47:29 --> Database Driver Class Initialized
INFO - 2016-05-05 18:47:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 18:47:29 --> Pagination Class Initialized
DEBUG - 2016-05-05 18:47:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 18:47:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 18:47:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 18:47:29 --> Final output sent to browser
DEBUG - 2016-05-05 18:47:29 --> Total execution time: 0.1271
INFO - 2016-05-05 20:20:25 --> Config Class Initialized
INFO - 2016-05-05 20:20:25 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:20:25 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:20:25 --> Utf8 Class Initialized
INFO - 2016-05-05 20:20:25 --> URI Class Initialized
INFO - 2016-05-05 20:20:25 --> Router Class Initialized
INFO - 2016-05-05 20:20:25 --> Output Class Initialized
INFO - 2016-05-05 20:20:25 --> Security Class Initialized
DEBUG - 2016-05-05 20:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:20:25 --> Input Class Initialized
INFO - 2016-05-05 20:20:25 --> Language Class Initialized
INFO - 2016-05-05 20:20:25 --> Loader Class Initialized
INFO - 2016-05-05 20:20:25 --> Helper loaded: url_helper
INFO - 2016-05-05 20:20:25 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:20:25 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:20:25 --> Helper loaded: form_helper
INFO - 2016-05-05 20:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:20:25 --> Form Validation Class Initialized
INFO - 2016-05-05 20:20:25 --> Controller Class Initialized
INFO - 2016-05-05 20:20:25 --> Model Class Initialized
INFO - 2016-05-05 20:20:25 --> Database Driver Class Initialized
INFO - 2016-05-05 20:20:25 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:20:25 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:20:25 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:20:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 20:20:25 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:20:25 --> Final output sent to browser
DEBUG - 2016-05-05 20:20:25 --> Total execution time: 0.0944
INFO - 2016-05-05 20:21:09 --> Config Class Initialized
INFO - 2016-05-05 20:21:09 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:21:09 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:21:09 --> Utf8 Class Initialized
INFO - 2016-05-05 20:21:09 --> URI Class Initialized
INFO - 2016-05-05 20:21:09 --> Router Class Initialized
INFO - 2016-05-05 20:21:09 --> Output Class Initialized
INFO - 2016-05-05 20:21:09 --> Security Class Initialized
DEBUG - 2016-05-05 20:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:21:09 --> Input Class Initialized
INFO - 2016-05-05 20:21:09 --> Language Class Initialized
INFO - 2016-05-05 20:21:09 --> Loader Class Initialized
INFO - 2016-05-05 20:21:09 --> Helper loaded: url_helper
INFO - 2016-05-05 20:21:09 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:21:09 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:21:09 --> Helper loaded: form_helper
INFO - 2016-05-05 20:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:21:09 --> Form Validation Class Initialized
INFO - 2016-05-05 20:21:09 --> Controller Class Initialized
INFO - 2016-05-05 20:21:09 --> Model Class Initialized
INFO - 2016-05-05 20:21:09 --> Database Driver Class Initialized
INFO - 2016-05-05 20:21:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:21:09 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:21:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:21:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 20:21:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:21:09 --> Final output sent to browser
DEBUG - 2016-05-05 20:21:09 --> Total execution time: 0.0780
INFO - 2016-05-05 20:22:13 --> Config Class Initialized
INFO - 2016-05-05 20:22:13 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:22:13 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:22:13 --> Utf8 Class Initialized
INFO - 2016-05-05 20:22:13 --> URI Class Initialized
INFO - 2016-05-05 20:22:13 --> Router Class Initialized
INFO - 2016-05-05 20:22:13 --> Output Class Initialized
INFO - 2016-05-05 20:22:13 --> Security Class Initialized
DEBUG - 2016-05-05 20:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:22:13 --> Input Class Initialized
INFO - 2016-05-05 20:22:13 --> Language Class Initialized
INFO - 2016-05-05 20:22:13 --> Loader Class Initialized
INFO - 2016-05-05 20:22:13 --> Helper loaded: url_helper
INFO - 2016-05-05 20:22:13 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:22:13 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:22:13 --> Helper loaded: form_helper
INFO - 2016-05-05 20:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:22:13 --> Form Validation Class Initialized
INFO - 2016-05-05 20:22:13 --> Controller Class Initialized
INFO - 2016-05-05 20:22:13 --> Model Class Initialized
INFO - 2016-05-05 20:22:13 --> Database Driver Class Initialized
INFO - 2016-05-05 20:22:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:22:13 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:22:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:22:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 20:22:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:22:13 --> Final output sent to browser
DEBUG - 2016-05-05 20:22:13 --> Total execution time: 0.0940
INFO - 2016-05-05 20:23:29 --> Config Class Initialized
INFO - 2016-05-05 20:23:29 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:23:29 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:23:29 --> Utf8 Class Initialized
INFO - 2016-05-05 20:23:29 --> URI Class Initialized
INFO - 2016-05-05 20:23:29 --> Router Class Initialized
INFO - 2016-05-05 20:23:29 --> Output Class Initialized
INFO - 2016-05-05 20:23:29 --> Security Class Initialized
DEBUG - 2016-05-05 20:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:23:29 --> Input Class Initialized
INFO - 2016-05-05 20:23:29 --> Language Class Initialized
INFO - 2016-05-05 20:23:29 --> Loader Class Initialized
INFO - 2016-05-05 20:23:29 --> Helper loaded: url_helper
INFO - 2016-05-05 20:23:29 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:23:29 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:23:29 --> Helper loaded: form_helper
INFO - 2016-05-05 20:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:23:29 --> Form Validation Class Initialized
INFO - 2016-05-05 20:23:29 --> Controller Class Initialized
INFO - 2016-05-05 20:23:29 --> Model Class Initialized
INFO - 2016-05-05 20:23:29 --> Database Driver Class Initialized
INFO - 2016-05-05 20:23:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:23:29 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:23:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:23:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 20:23:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:23:29 --> Final output sent to browser
DEBUG - 2016-05-05 20:23:29 --> Total execution time: 0.0819
INFO - 2016-05-05 20:23:36 --> Config Class Initialized
INFO - 2016-05-05 20:23:36 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:23:36 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:23:36 --> Utf8 Class Initialized
INFO - 2016-05-05 20:23:36 --> URI Class Initialized
INFO - 2016-05-05 20:23:36 --> Router Class Initialized
INFO - 2016-05-05 20:23:36 --> Output Class Initialized
INFO - 2016-05-05 20:23:36 --> Security Class Initialized
DEBUG - 2016-05-05 20:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:23:36 --> Input Class Initialized
INFO - 2016-05-05 20:23:36 --> Language Class Initialized
INFO - 2016-05-05 20:23:36 --> Loader Class Initialized
INFO - 2016-05-05 20:23:36 --> Helper loaded: url_helper
INFO - 2016-05-05 20:23:36 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:23:36 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:23:36 --> Helper loaded: form_helper
INFO - 2016-05-05 20:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:23:36 --> Form Validation Class Initialized
INFO - 2016-05-05 20:23:36 --> Controller Class Initialized
INFO - 2016-05-05 20:23:36 --> Model Class Initialized
INFO - 2016-05-05 20:23:36 --> Database Driver Class Initialized
INFO - 2016-05-05 20:23:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:23:36 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:23:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:23:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 20:23:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:23:36 --> Final output sent to browser
DEBUG - 2016-05-05 20:23:36 --> Total execution time: 0.0789
INFO - 2016-05-05 20:23:41 --> Config Class Initialized
INFO - 2016-05-05 20:23:41 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:23:41 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:23:41 --> Utf8 Class Initialized
INFO - 2016-05-05 20:23:41 --> URI Class Initialized
INFO - 2016-05-05 20:23:41 --> Router Class Initialized
INFO - 2016-05-05 20:23:41 --> Output Class Initialized
INFO - 2016-05-05 20:23:41 --> Security Class Initialized
DEBUG - 2016-05-05 20:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:23:41 --> Input Class Initialized
INFO - 2016-05-05 20:23:41 --> Language Class Initialized
INFO - 2016-05-05 20:23:41 --> Loader Class Initialized
INFO - 2016-05-05 20:23:41 --> Helper loaded: url_helper
INFO - 2016-05-05 20:23:41 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:23:41 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:23:41 --> Helper loaded: form_helper
INFO - 2016-05-05 20:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:23:41 --> Form Validation Class Initialized
INFO - 2016-05-05 20:23:41 --> Controller Class Initialized
INFO - 2016-05-05 20:23:41 --> Model Class Initialized
INFO - 2016-05-05 20:23:41 --> Database Driver Class Initialized
INFO - 2016-05-05 20:23:41 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:23:41 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:23:41 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:23:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 20:23:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:23:41 --> Final output sent to browser
DEBUG - 2016-05-05 20:23:41 --> Total execution time: 0.1052
INFO - 2016-05-05 20:23:42 --> Config Class Initialized
INFO - 2016-05-05 20:23:42 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:23:42 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:23:42 --> Utf8 Class Initialized
INFO - 2016-05-05 20:23:42 --> URI Class Initialized
INFO - 2016-05-05 20:23:42 --> Router Class Initialized
INFO - 2016-05-05 20:23:42 --> Output Class Initialized
INFO - 2016-05-05 20:23:42 --> Security Class Initialized
DEBUG - 2016-05-05 20:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:23:42 --> Input Class Initialized
INFO - 2016-05-05 20:23:42 --> Language Class Initialized
INFO - 2016-05-05 20:23:42 --> Loader Class Initialized
INFO - 2016-05-05 20:23:42 --> Helper loaded: url_helper
INFO - 2016-05-05 20:23:42 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:23:42 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:23:42 --> Helper loaded: form_helper
INFO - 2016-05-05 20:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:23:42 --> Form Validation Class Initialized
INFO - 2016-05-05 20:23:42 --> Controller Class Initialized
INFO - 2016-05-05 20:23:42 --> Model Class Initialized
INFO - 2016-05-05 20:23:42 --> Database Driver Class Initialized
INFO - 2016-05-05 20:23:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:23:42 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:23:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:23:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 20:23:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:23:42 --> Final output sent to browser
DEBUG - 2016-05-05 20:23:42 --> Total execution time: 0.0784
INFO - 2016-05-05 20:23:43 --> Config Class Initialized
INFO - 2016-05-05 20:23:43 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:23:43 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:23:43 --> Utf8 Class Initialized
INFO - 2016-05-05 20:23:43 --> URI Class Initialized
INFO - 2016-05-05 20:23:43 --> Router Class Initialized
INFO - 2016-05-05 20:23:43 --> Output Class Initialized
INFO - 2016-05-05 20:23:43 --> Security Class Initialized
DEBUG - 2016-05-05 20:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:23:43 --> Input Class Initialized
INFO - 2016-05-05 20:23:43 --> Language Class Initialized
INFO - 2016-05-05 20:23:43 --> Loader Class Initialized
INFO - 2016-05-05 20:23:43 --> Helper loaded: url_helper
INFO - 2016-05-05 20:23:43 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:23:43 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:23:43 --> Helper loaded: form_helper
INFO - 2016-05-05 20:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:23:43 --> Form Validation Class Initialized
INFO - 2016-05-05 20:23:43 --> Controller Class Initialized
INFO - 2016-05-05 20:23:43 --> Model Class Initialized
INFO - 2016-05-05 20:23:43 --> Database Driver Class Initialized
INFO - 2016-05-05 20:23:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:23:43 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:23:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:23:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 20:23:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:23:43 --> Final output sent to browser
DEBUG - 2016-05-05 20:23:43 --> Total execution time: 0.1123
INFO - 2016-05-05 20:23:44 --> Config Class Initialized
INFO - 2016-05-05 20:23:44 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:23:44 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:23:44 --> Utf8 Class Initialized
INFO - 2016-05-05 20:23:44 --> URI Class Initialized
INFO - 2016-05-05 20:23:44 --> Router Class Initialized
INFO - 2016-05-05 20:23:44 --> Output Class Initialized
INFO - 2016-05-05 20:23:44 --> Security Class Initialized
DEBUG - 2016-05-05 20:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:23:44 --> Input Class Initialized
INFO - 2016-05-05 20:23:44 --> Language Class Initialized
INFO - 2016-05-05 20:23:44 --> Loader Class Initialized
INFO - 2016-05-05 20:23:44 --> Helper loaded: url_helper
INFO - 2016-05-05 20:23:44 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:23:44 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:23:44 --> Helper loaded: form_helper
INFO - 2016-05-05 20:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:23:44 --> Form Validation Class Initialized
INFO - 2016-05-05 20:23:44 --> Controller Class Initialized
INFO - 2016-05-05 20:23:44 --> Model Class Initialized
INFO - 2016-05-05 20:23:44 --> Database Driver Class Initialized
INFO - 2016-05-05 20:23:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:23:44 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:23:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:23:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 20:23:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:23:44 --> Final output sent to browser
DEBUG - 2016-05-05 20:23:44 --> Total execution time: 0.0748
INFO - 2016-05-05 20:23:45 --> Config Class Initialized
INFO - 2016-05-05 20:23:45 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:23:45 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:23:45 --> Utf8 Class Initialized
INFO - 2016-05-05 20:23:45 --> URI Class Initialized
INFO - 2016-05-05 20:23:45 --> Router Class Initialized
INFO - 2016-05-05 20:23:45 --> Output Class Initialized
INFO - 2016-05-05 20:23:45 --> Security Class Initialized
DEBUG - 2016-05-05 20:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:23:45 --> Input Class Initialized
INFO - 2016-05-05 20:23:45 --> Language Class Initialized
INFO - 2016-05-05 20:23:45 --> Loader Class Initialized
INFO - 2016-05-05 20:23:45 --> Helper loaded: url_helper
INFO - 2016-05-05 20:23:45 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:23:45 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:23:45 --> Helper loaded: form_helper
INFO - 2016-05-05 20:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:23:45 --> Form Validation Class Initialized
INFO - 2016-05-05 20:23:45 --> Controller Class Initialized
INFO - 2016-05-05 20:23:45 --> Model Class Initialized
INFO - 2016-05-05 20:23:45 --> Database Driver Class Initialized
INFO - 2016-05-05 20:23:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:23:45 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:23:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:23:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 20:23:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:23:45 --> Final output sent to browser
DEBUG - 2016-05-05 20:23:45 --> Total execution time: 0.1145
INFO - 2016-05-05 20:26:01 --> Config Class Initialized
INFO - 2016-05-05 20:26:01 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:26:01 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:26:01 --> Utf8 Class Initialized
INFO - 2016-05-05 20:26:01 --> URI Class Initialized
INFO - 2016-05-05 20:26:01 --> Router Class Initialized
INFO - 2016-05-05 20:26:01 --> Output Class Initialized
INFO - 2016-05-05 20:26:01 --> Security Class Initialized
DEBUG - 2016-05-05 20:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:26:01 --> Input Class Initialized
INFO - 2016-05-05 20:26:01 --> Language Class Initialized
INFO - 2016-05-05 20:26:01 --> Loader Class Initialized
INFO - 2016-05-05 20:26:01 --> Helper loaded: url_helper
INFO - 2016-05-05 20:26:01 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:26:01 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:26:01 --> Helper loaded: form_helper
INFO - 2016-05-05 20:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:26:01 --> Form Validation Class Initialized
INFO - 2016-05-05 20:26:01 --> Controller Class Initialized
INFO - 2016-05-05 20:26:01 --> Model Class Initialized
INFO - 2016-05-05 20:26:01 --> Database Driver Class Initialized
INFO - 2016-05-05 20:26:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:26:01 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:26:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:26:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 20:26:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:26:01 --> Final output sent to browser
DEBUG - 2016-05-05 20:26:01 --> Total execution time: 0.0793
INFO - 2016-05-05 20:26:33 --> Config Class Initialized
INFO - 2016-05-05 20:26:33 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:26:33 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:26:33 --> Utf8 Class Initialized
INFO - 2016-05-05 20:26:33 --> URI Class Initialized
INFO - 2016-05-05 20:26:33 --> Router Class Initialized
INFO - 2016-05-05 20:26:33 --> Output Class Initialized
INFO - 2016-05-05 20:26:33 --> Security Class Initialized
DEBUG - 2016-05-05 20:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:26:33 --> Input Class Initialized
INFO - 2016-05-05 20:26:33 --> Language Class Initialized
INFO - 2016-05-05 20:26:33 --> Loader Class Initialized
INFO - 2016-05-05 20:26:33 --> Helper loaded: url_helper
INFO - 2016-05-05 20:26:33 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:26:33 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:26:33 --> Helper loaded: form_helper
INFO - 2016-05-05 20:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:26:33 --> Form Validation Class Initialized
INFO - 2016-05-05 20:26:33 --> Controller Class Initialized
INFO - 2016-05-05 20:26:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:26:33 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:26:33 --> Model Class Initialized
INFO - 2016-05-05 20:26:33 --> Database Driver Class Initialized
INFO - 2016-05-05 20:26:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProveedor.php
INFO - 2016-05-05 20:26:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:26:33 --> Final output sent to browser
DEBUG - 2016-05-05 20:26:33 --> Total execution time: 0.1350
INFO - 2016-05-05 20:26:46 --> Config Class Initialized
INFO - 2016-05-05 20:26:46 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:26:46 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:26:46 --> Utf8 Class Initialized
INFO - 2016-05-05 20:26:46 --> URI Class Initialized
INFO - 2016-05-05 20:26:46 --> Router Class Initialized
INFO - 2016-05-05 20:26:46 --> Output Class Initialized
INFO - 2016-05-05 20:26:46 --> Security Class Initialized
DEBUG - 2016-05-05 20:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:26:46 --> Input Class Initialized
INFO - 2016-05-05 20:26:46 --> Language Class Initialized
INFO - 2016-05-05 20:26:46 --> Loader Class Initialized
INFO - 2016-05-05 20:26:46 --> Helper loaded: url_helper
INFO - 2016-05-05 20:26:46 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:26:46 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:26:46 --> Helper loaded: form_helper
INFO - 2016-05-05 20:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:26:46 --> Form Validation Class Initialized
INFO - 2016-05-05 20:26:46 --> Controller Class Initialized
INFO - 2016-05-05 20:26:46 --> Model Class Initialized
INFO - 2016-05-05 20:26:46 --> Database Driver Class Initialized
INFO - 2016-05-05 20:26:46 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:26:46 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:26:46 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:26:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 20:26:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:26:46 --> Final output sent to browser
DEBUG - 2016-05-05 20:26:46 --> Total execution time: 0.1007
INFO - 2016-05-05 20:26:49 --> Config Class Initialized
INFO - 2016-05-05 20:26:49 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:26:49 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:26:49 --> Utf8 Class Initialized
INFO - 2016-05-05 20:26:49 --> URI Class Initialized
INFO - 2016-05-05 20:26:49 --> Router Class Initialized
INFO - 2016-05-05 20:26:49 --> Output Class Initialized
INFO - 2016-05-05 20:26:49 --> Security Class Initialized
DEBUG - 2016-05-05 20:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:26:49 --> Input Class Initialized
INFO - 2016-05-05 20:26:49 --> Language Class Initialized
INFO - 2016-05-05 20:26:49 --> Loader Class Initialized
INFO - 2016-05-05 20:26:49 --> Helper loaded: url_helper
INFO - 2016-05-05 20:26:49 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:26:49 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:26:49 --> Helper loaded: form_helper
INFO - 2016-05-05 20:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:26:49 --> Form Validation Class Initialized
INFO - 2016-05-05 20:26:49 --> Controller Class Initialized
INFO - 2016-05-05 20:26:49 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:26:49 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:26:49 --> Model Class Initialized
INFO - 2016-05-05 20:26:49 --> Database Driver Class Initialized
INFO - 2016-05-05 20:26:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-05 20:26:49 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:26:49 --> Final output sent to browser
DEBUG - 2016-05-05 20:26:49 --> Total execution time: 0.0885
INFO - 2016-05-05 20:30:16 --> Config Class Initialized
INFO - 2016-05-05 20:30:16 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:30:16 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:30:16 --> Utf8 Class Initialized
INFO - 2016-05-05 20:30:16 --> URI Class Initialized
INFO - 2016-05-05 20:30:16 --> Router Class Initialized
INFO - 2016-05-05 20:30:16 --> Output Class Initialized
INFO - 2016-05-05 20:30:16 --> Security Class Initialized
DEBUG - 2016-05-05 20:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:30:16 --> Input Class Initialized
INFO - 2016-05-05 20:30:16 --> Language Class Initialized
INFO - 2016-05-05 20:30:16 --> Loader Class Initialized
INFO - 2016-05-05 20:30:16 --> Helper loaded: url_helper
INFO - 2016-05-05 20:30:16 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:30:16 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:30:16 --> Helper loaded: form_helper
INFO - 2016-05-05 20:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:30:16 --> Form Validation Class Initialized
INFO - 2016-05-05 20:30:16 --> Controller Class Initialized
INFO - 2016-05-05 20:30:16 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:30:16 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:30:16 --> Model Class Initialized
INFO - 2016-05-05 20:30:16 --> Database Driver Class Initialized
INFO - 2016-05-05 20:30:17 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-05 20:30:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-05 20:30:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:30:17 --> Final output sent to browser
DEBUG - 2016-05-05 20:30:17 --> Total execution time: 0.1490
INFO - 2016-05-05 20:30:23 --> Config Class Initialized
INFO - 2016-05-05 20:30:23 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:30:23 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:30:23 --> Utf8 Class Initialized
INFO - 2016-05-05 20:30:23 --> URI Class Initialized
INFO - 2016-05-05 20:30:23 --> Router Class Initialized
INFO - 2016-05-05 20:30:23 --> Output Class Initialized
INFO - 2016-05-05 20:30:23 --> Security Class Initialized
DEBUG - 2016-05-05 20:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:30:23 --> Input Class Initialized
INFO - 2016-05-05 20:30:23 --> Language Class Initialized
INFO - 2016-05-05 20:30:23 --> Loader Class Initialized
INFO - 2016-05-05 20:30:23 --> Helper loaded: url_helper
INFO - 2016-05-05 20:30:23 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:30:23 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:30:23 --> Helper loaded: form_helper
INFO - 2016-05-05 20:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:30:23 --> Form Validation Class Initialized
INFO - 2016-05-05 20:30:23 --> Controller Class Initialized
INFO - 2016-05-05 20:30:23 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:30:23 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:30:23 --> Model Class Initialized
INFO - 2016-05-05 20:30:23 --> Database Driver Class Initialized
INFO - 2016-05-05 20:30:23 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-05 20:30:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-05 20:30:23 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:30:23 --> Final output sent to browser
DEBUG - 2016-05-05 20:30:23 --> Total execution time: 0.1482
INFO - 2016-05-05 20:30:30 --> Config Class Initialized
INFO - 2016-05-05 20:30:30 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:30:30 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:30:30 --> Utf8 Class Initialized
INFO - 2016-05-05 20:30:30 --> URI Class Initialized
INFO - 2016-05-05 20:30:30 --> Router Class Initialized
INFO - 2016-05-05 20:30:30 --> Output Class Initialized
INFO - 2016-05-05 20:30:30 --> Security Class Initialized
DEBUG - 2016-05-05 20:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:30:30 --> Input Class Initialized
INFO - 2016-05-05 20:30:30 --> Language Class Initialized
INFO - 2016-05-05 20:30:30 --> Loader Class Initialized
INFO - 2016-05-05 20:30:30 --> Helper loaded: url_helper
INFO - 2016-05-05 20:30:30 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:30:30 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:30:30 --> Helper loaded: form_helper
INFO - 2016-05-05 20:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:30:30 --> Form Validation Class Initialized
INFO - 2016-05-05 20:30:30 --> Controller Class Initialized
INFO - 2016-05-05 20:30:30 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:30:30 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:30:30 --> Model Class Initialized
INFO - 2016-05-05 20:30:30 --> Database Driver Class Initialized
INFO - 2016-05-05 20:30:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-05 20:30:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:30:30 --> Final output sent to browser
DEBUG - 2016-05-05 20:30:30 --> Total execution time: 0.1049
INFO - 2016-05-05 20:30:36 --> Config Class Initialized
INFO - 2016-05-05 20:30:36 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:30:36 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:30:36 --> Utf8 Class Initialized
INFO - 2016-05-05 20:30:36 --> URI Class Initialized
INFO - 2016-05-05 20:30:36 --> Router Class Initialized
INFO - 2016-05-05 20:30:36 --> Output Class Initialized
INFO - 2016-05-05 20:30:36 --> Security Class Initialized
DEBUG - 2016-05-05 20:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:30:36 --> Input Class Initialized
INFO - 2016-05-05 20:30:36 --> Language Class Initialized
INFO - 2016-05-05 20:30:36 --> Loader Class Initialized
INFO - 2016-05-05 20:30:36 --> Helper loaded: url_helper
INFO - 2016-05-05 20:30:36 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:30:36 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:30:36 --> Helper loaded: form_helper
INFO - 2016-05-05 20:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:30:36 --> Form Validation Class Initialized
INFO - 2016-05-05 20:30:36 --> Controller Class Initialized
INFO - 2016-05-05 20:30:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:30:36 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:30:36 --> Model Class Initialized
INFO - 2016-05-05 20:30:36 --> Database Driver Class Initialized
INFO - 2016-05-05 20:30:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-05 20:30:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:30:36 --> Final output sent to browser
DEBUG - 2016-05-05 20:30:36 --> Total execution time: 0.0930
INFO - 2016-05-05 20:31:29 --> Config Class Initialized
INFO - 2016-05-05 20:31:29 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:31:29 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:31:29 --> Utf8 Class Initialized
INFO - 2016-05-05 20:31:29 --> URI Class Initialized
INFO - 2016-05-05 20:31:29 --> Router Class Initialized
INFO - 2016-05-05 20:31:29 --> Output Class Initialized
INFO - 2016-05-05 20:31:29 --> Security Class Initialized
DEBUG - 2016-05-05 20:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:31:29 --> Input Class Initialized
INFO - 2016-05-05 20:31:29 --> Language Class Initialized
INFO - 2016-05-05 20:31:29 --> Loader Class Initialized
INFO - 2016-05-05 20:31:29 --> Helper loaded: url_helper
INFO - 2016-05-05 20:31:29 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:31:29 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:31:29 --> Helper loaded: form_helper
INFO - 2016-05-05 20:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:31:29 --> Form Validation Class Initialized
INFO - 2016-05-05 20:31:29 --> Controller Class Initialized
INFO - 2016-05-05 20:31:29 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:31:29 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:31:29 --> Model Class Initialized
INFO - 2016-05-05 20:31:29 --> Database Driver Class Initialized
INFO - 2016-05-05 20:31:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-05 20:31:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:31:29 --> Final output sent to browser
DEBUG - 2016-05-05 20:31:29 --> Total execution time: 0.1019
INFO - 2016-05-05 20:34:54 --> Config Class Initialized
INFO - 2016-05-05 20:34:54 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:34:54 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:34:54 --> Utf8 Class Initialized
INFO - 2016-05-05 20:34:54 --> URI Class Initialized
INFO - 2016-05-05 20:34:54 --> Router Class Initialized
INFO - 2016-05-05 20:34:54 --> Output Class Initialized
INFO - 2016-05-05 20:34:54 --> Security Class Initialized
DEBUG - 2016-05-05 20:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:34:54 --> Input Class Initialized
INFO - 2016-05-05 20:34:54 --> Language Class Initialized
INFO - 2016-05-05 20:34:54 --> Loader Class Initialized
INFO - 2016-05-05 20:34:54 --> Helper loaded: url_helper
INFO - 2016-05-05 20:34:54 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:34:54 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:34:54 --> Helper loaded: form_helper
INFO - 2016-05-05 20:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:34:54 --> Form Validation Class Initialized
INFO - 2016-05-05 20:34:54 --> Controller Class Initialized
INFO - 2016-05-05 20:34:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:34:54 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:34:54 --> Model Class Initialized
INFO - 2016-05-05 20:34:54 --> Database Driver Class Initialized
INFO - 2016-05-05 20:34:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-05 20:34:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:34:54 --> Final output sent to browser
DEBUG - 2016-05-05 20:34:54 --> Total execution time: 0.0762
INFO - 2016-05-05 20:34:59 --> Config Class Initialized
INFO - 2016-05-05 20:34:59 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:34:59 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:34:59 --> Utf8 Class Initialized
INFO - 2016-05-05 20:34:59 --> URI Class Initialized
INFO - 2016-05-05 20:34:59 --> Router Class Initialized
INFO - 2016-05-05 20:34:59 --> Output Class Initialized
INFO - 2016-05-05 20:34:59 --> Security Class Initialized
DEBUG - 2016-05-05 20:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:34:59 --> Input Class Initialized
INFO - 2016-05-05 20:34:59 --> Language Class Initialized
INFO - 2016-05-05 20:34:59 --> Loader Class Initialized
INFO - 2016-05-05 20:34:59 --> Helper loaded: url_helper
INFO - 2016-05-05 20:34:59 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:34:59 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:34:59 --> Helper loaded: form_helper
INFO - 2016-05-05 20:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:34:59 --> Form Validation Class Initialized
INFO - 2016-05-05 20:34:59 --> Controller Class Initialized
INFO - 2016-05-05 20:34:59 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:34:59 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:34:59 --> Model Class Initialized
INFO - 2016-05-05 20:34:59 --> Database Driver Class Initialized
INFO - 2016-05-05 20:34:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-05 20:34:59 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:34:59 --> Final output sent to browser
DEBUG - 2016-05-05 20:34:59 --> Total execution time: 0.0921
INFO - 2016-05-05 20:35:31 --> Config Class Initialized
INFO - 2016-05-05 20:35:31 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:35:31 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:35:31 --> Utf8 Class Initialized
INFO - 2016-05-05 20:35:31 --> URI Class Initialized
INFO - 2016-05-05 20:35:31 --> Router Class Initialized
INFO - 2016-05-05 20:35:31 --> Output Class Initialized
INFO - 2016-05-05 20:35:31 --> Security Class Initialized
DEBUG - 2016-05-05 20:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:35:31 --> Input Class Initialized
INFO - 2016-05-05 20:35:31 --> Language Class Initialized
INFO - 2016-05-05 20:35:31 --> Loader Class Initialized
INFO - 2016-05-05 20:35:31 --> Helper loaded: url_helper
INFO - 2016-05-05 20:35:31 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:35:31 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:35:31 --> Helper loaded: form_helper
INFO - 2016-05-05 20:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:35:31 --> Form Validation Class Initialized
INFO - 2016-05-05 20:35:31 --> Controller Class Initialized
INFO - 2016-05-05 20:35:31 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:35:31 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:35:31 --> Model Class Initialized
INFO - 2016-05-05 20:35:31 --> Database Driver Class Initialized
ERROR - 2016-05-05 20:35:31 --> Severity: Warning --> move_uploaded_file(././images/1462473331_C:\xampp\tmp\php9A8B.tmp): failed to open stream: Invalid argument C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Agregar\Producto.php 83
ERROR - 2016-05-05 20:35:31 --> Severity: Warning --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\php9A8B.tmp' to '././images/1462473331_C:\xampp\tmp\php9A8B.tmp' C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Agregar\Producto.php 83
INFO - 2016-05-05 20:35:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-05 20:35:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:35:31 --> Final output sent to browser
DEBUG - 2016-05-05 20:35:31 --> Total execution time: 0.1113
INFO - 2016-05-05 20:35:55 --> Config Class Initialized
INFO - 2016-05-05 20:35:55 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:35:55 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:35:55 --> Utf8 Class Initialized
INFO - 2016-05-05 20:35:55 --> URI Class Initialized
INFO - 2016-05-05 20:35:55 --> Router Class Initialized
INFO - 2016-05-05 20:35:55 --> Output Class Initialized
INFO - 2016-05-05 20:35:55 --> Security Class Initialized
DEBUG - 2016-05-05 20:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:35:55 --> Input Class Initialized
INFO - 2016-05-05 20:35:55 --> Language Class Initialized
INFO - 2016-05-05 20:35:55 --> Loader Class Initialized
INFO - 2016-05-05 20:35:55 --> Helper loaded: url_helper
INFO - 2016-05-05 20:35:55 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:35:55 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:35:55 --> Helper loaded: form_helper
INFO - 2016-05-05 20:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:35:55 --> Form Validation Class Initialized
INFO - 2016-05-05 20:35:55 --> Controller Class Initialized
INFO - 2016-05-05 20:35:55 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:35:55 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:35:55 --> Model Class Initialized
INFO - 2016-05-05 20:35:55 --> Database Driver Class Initialized
ERROR - 2016-05-05 20:35:55 --> Severity: Notice --> Undefined variable: filename C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Agregar\Producto.php 86
INFO - 2016-05-05 20:35:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-05 20:35:55 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:35:55 --> Final output sent to browser
DEBUG - 2016-05-05 20:35:55 --> Total execution time: 0.2043
INFO - 2016-05-05 20:36:05 --> Config Class Initialized
INFO - 2016-05-05 20:36:05 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:36:05 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:36:05 --> Utf8 Class Initialized
INFO - 2016-05-05 20:36:05 --> URI Class Initialized
INFO - 2016-05-05 20:36:05 --> Router Class Initialized
INFO - 2016-05-05 20:36:05 --> Output Class Initialized
INFO - 2016-05-05 20:36:05 --> Security Class Initialized
DEBUG - 2016-05-05 20:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:36:05 --> Input Class Initialized
INFO - 2016-05-05 20:36:05 --> Language Class Initialized
INFO - 2016-05-05 20:36:05 --> Loader Class Initialized
INFO - 2016-05-05 20:36:05 --> Helper loaded: url_helper
INFO - 2016-05-05 20:36:05 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:36:05 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:36:05 --> Helper loaded: form_helper
INFO - 2016-05-05 20:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:36:05 --> Form Validation Class Initialized
INFO - 2016-05-05 20:36:05 --> Controller Class Initialized
INFO - 2016-05-05 20:36:05 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:36:05 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:36:05 --> Model Class Initialized
INFO - 2016-05-05 20:36:05 --> Database Driver Class Initialized
ERROR - 2016-05-05 20:36:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Agregar\Producto.php 104
ERROR - 2016-05-05 20:36:05 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`bdproyecto`.`producto`, CONSTRAINT `fk_Camiseta_Categoria` FOREIGN KEY (`idCategoria`) REFERENCES `categoria` (`idCategoria`) ON DELETE NO ACTION ON UPDATE NO ACTION) - Invalid query: INSERT INTO `producto` (`imagen`) VALUES ('1462473365_hp-pc-hardaily.jpg')
INFO - 2016-05-05 20:36:05 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-05 20:36:13 --> Config Class Initialized
INFO - 2016-05-05 20:36:13 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:36:13 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:36:13 --> Utf8 Class Initialized
INFO - 2016-05-05 20:36:13 --> URI Class Initialized
INFO - 2016-05-05 20:36:13 --> Router Class Initialized
INFO - 2016-05-05 20:36:13 --> Output Class Initialized
INFO - 2016-05-05 20:36:13 --> Security Class Initialized
DEBUG - 2016-05-05 20:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:36:13 --> Input Class Initialized
INFO - 2016-05-05 20:36:13 --> Language Class Initialized
INFO - 2016-05-05 20:36:13 --> Loader Class Initialized
INFO - 2016-05-05 20:36:13 --> Helper loaded: url_helper
INFO - 2016-05-05 20:36:13 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:36:13 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:36:13 --> Helper loaded: form_helper
INFO - 2016-05-05 20:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:36:13 --> Form Validation Class Initialized
INFO - 2016-05-05 20:36:13 --> Controller Class Initialized
INFO - 2016-05-05 20:36:13 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:36:13 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:36:13 --> Model Class Initialized
INFO - 2016-05-05 20:36:13 --> Database Driver Class Initialized
ERROR - 2016-05-05 20:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Agregar\Producto.php 104
ERROR - 2016-05-05 20:36:13 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`bdproyecto`.`producto`, CONSTRAINT `fk_Camiseta_Categoria` FOREIGN KEY (`idCategoria`) REFERENCES `categoria` (`idCategoria`) ON DELETE NO ACTION ON UPDATE NO ACTION) - Invalid query: INSERT INTO `producto` (`imagen`) VALUES ('1462473373_hp-pc-hardaily.jpg')
INFO - 2016-05-05 20:36:13 --> Language file loaded: language/spanish/db_lang.php
INFO - 2016-05-05 20:36:17 --> Config Class Initialized
INFO - 2016-05-05 20:36:17 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:36:17 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:36:17 --> Utf8 Class Initialized
INFO - 2016-05-05 20:36:17 --> URI Class Initialized
INFO - 2016-05-05 20:36:17 --> Router Class Initialized
INFO - 2016-05-05 20:36:17 --> Output Class Initialized
INFO - 2016-05-05 20:36:17 --> Security Class Initialized
DEBUG - 2016-05-05 20:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:36:17 --> Input Class Initialized
INFO - 2016-05-05 20:36:17 --> Language Class Initialized
INFO - 2016-05-05 20:36:17 --> Loader Class Initialized
INFO - 2016-05-05 20:36:17 --> Helper loaded: url_helper
INFO - 2016-05-05 20:36:17 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:36:17 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:36:17 --> Helper loaded: form_helper
INFO - 2016-05-05 20:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:36:17 --> Form Validation Class Initialized
INFO - 2016-05-05 20:36:17 --> Controller Class Initialized
INFO - 2016-05-05 20:36:17 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:36:17 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:36:17 --> Model Class Initialized
INFO - 2016-05-05 20:36:17 --> Database Driver Class Initialized
INFO - 2016-05-05 20:36:17 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-05 20:36:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-05 20:36:17 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:36:17 --> Final output sent to browser
DEBUG - 2016-05-05 20:36:17 --> Total execution time: 0.0897
INFO - 2016-05-05 20:36:43 --> Config Class Initialized
INFO - 2016-05-05 20:36:43 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:36:43 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:36:43 --> Utf8 Class Initialized
INFO - 2016-05-05 20:36:43 --> URI Class Initialized
INFO - 2016-05-05 20:36:43 --> Router Class Initialized
INFO - 2016-05-05 20:36:43 --> Output Class Initialized
INFO - 2016-05-05 20:36:43 --> Security Class Initialized
DEBUG - 2016-05-05 20:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:36:43 --> Input Class Initialized
INFO - 2016-05-05 20:36:43 --> Language Class Initialized
INFO - 2016-05-05 20:36:43 --> Loader Class Initialized
INFO - 2016-05-05 20:36:43 --> Helper loaded: url_helper
INFO - 2016-05-05 20:36:43 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:36:43 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:36:43 --> Helper loaded: form_helper
INFO - 2016-05-05 20:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:36:43 --> Form Validation Class Initialized
INFO - 2016-05-05 20:36:43 --> Controller Class Initialized
INFO - 2016-05-05 20:36:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:36:43 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:36:43 --> Model Class Initialized
INFO - 2016-05-05 20:36:43 --> Database Driver Class Initialized
INFO - 2016-05-05 20:36:43 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-05 20:36:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-05 20:36:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:36:44 --> Final output sent to browser
DEBUG - 2016-05-05 20:36:44 --> Total execution time: 0.1478
INFO - 2016-05-05 20:36:51 --> Config Class Initialized
INFO - 2016-05-05 20:36:51 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:36:51 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:36:51 --> Utf8 Class Initialized
INFO - 2016-05-05 20:36:51 --> URI Class Initialized
INFO - 2016-05-05 20:36:51 --> Router Class Initialized
INFO - 2016-05-05 20:36:51 --> Output Class Initialized
INFO - 2016-05-05 20:36:51 --> Security Class Initialized
DEBUG - 2016-05-05 20:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:36:51 --> Input Class Initialized
INFO - 2016-05-05 20:36:51 --> Language Class Initialized
INFO - 2016-05-05 20:36:51 --> Loader Class Initialized
INFO - 2016-05-05 20:36:51 --> Helper loaded: url_helper
INFO - 2016-05-05 20:36:51 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:36:51 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:36:51 --> Helper loaded: form_helper
INFO - 2016-05-05 20:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:36:51 --> Form Validation Class Initialized
INFO - 2016-05-05 20:36:51 --> Controller Class Initialized
INFO - 2016-05-05 20:36:51 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:36:51 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:36:51 --> Model Class Initialized
INFO - 2016-05-05 20:36:51 --> Database Driver Class Initialized
INFO - 2016-05-05 20:36:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-05 20:36:51 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:36:51 --> Final output sent to browser
DEBUG - 2016-05-05 20:36:51 --> Total execution time: 0.1869
INFO - 2016-05-05 20:37:06 --> Config Class Initialized
INFO - 2016-05-05 20:37:06 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:37:06 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:37:06 --> Utf8 Class Initialized
INFO - 2016-05-05 20:37:06 --> URI Class Initialized
INFO - 2016-05-05 20:37:06 --> Router Class Initialized
INFO - 2016-05-05 20:37:06 --> Output Class Initialized
INFO - 2016-05-05 20:37:06 --> Security Class Initialized
DEBUG - 2016-05-05 20:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:37:06 --> Input Class Initialized
INFO - 2016-05-05 20:37:06 --> Language Class Initialized
INFO - 2016-05-05 20:37:06 --> Loader Class Initialized
INFO - 2016-05-05 20:37:06 --> Helper loaded: url_helper
INFO - 2016-05-05 20:37:06 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:37:06 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:37:06 --> Helper loaded: form_helper
INFO - 2016-05-05 20:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:37:06 --> Form Validation Class Initialized
INFO - 2016-05-05 20:37:06 --> Controller Class Initialized
INFO - 2016-05-05 20:37:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-05 20:37:06 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:37:06 --> Final output sent to browser
DEBUG - 2016-05-05 20:37:06 --> Total execution time: 0.0546
INFO - 2016-05-05 20:37:09 --> Config Class Initialized
INFO - 2016-05-05 20:37:09 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:37:09 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:37:09 --> Utf8 Class Initialized
INFO - 2016-05-05 20:37:09 --> URI Class Initialized
INFO - 2016-05-05 20:37:09 --> Router Class Initialized
INFO - 2016-05-05 20:37:09 --> Output Class Initialized
INFO - 2016-05-05 20:37:09 --> Security Class Initialized
DEBUG - 2016-05-05 20:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:37:09 --> Input Class Initialized
INFO - 2016-05-05 20:37:09 --> Language Class Initialized
INFO - 2016-05-05 20:37:09 --> Loader Class Initialized
INFO - 2016-05-05 20:37:09 --> Helper loaded: url_helper
INFO - 2016-05-05 20:37:09 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:37:09 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:37:09 --> Helper loaded: form_helper
INFO - 2016-05-05 20:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:37:09 --> Form Validation Class Initialized
INFO - 2016-05-05 20:37:09 --> Controller Class Initialized
INFO - 2016-05-05 20:37:09 --> Model Class Initialized
INFO - 2016-05-05 20:37:09 --> Database Driver Class Initialized
INFO - 2016-05-05 20:37:09 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:37:09 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:37:09 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:37:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 20:37:09 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:37:09 --> Final output sent to browser
DEBUG - 2016-05-05 20:37:09 --> Total execution time: 0.0880
INFO - 2016-05-05 20:37:13 --> Config Class Initialized
INFO - 2016-05-05 20:37:13 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:37:13 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:37:13 --> Utf8 Class Initialized
INFO - 2016-05-05 20:37:13 --> URI Class Initialized
INFO - 2016-05-05 20:37:13 --> Router Class Initialized
INFO - 2016-05-05 20:37:13 --> Output Class Initialized
INFO - 2016-05-05 20:37:13 --> Security Class Initialized
DEBUG - 2016-05-05 20:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:37:13 --> Input Class Initialized
INFO - 2016-05-05 20:37:13 --> Language Class Initialized
INFO - 2016-05-05 20:37:13 --> Loader Class Initialized
INFO - 2016-05-05 20:37:13 --> Helper loaded: url_helper
INFO - 2016-05-05 20:37:13 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:37:13 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:37:13 --> Helper loaded: form_helper
INFO - 2016-05-05 20:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:37:13 --> Form Validation Class Initialized
INFO - 2016-05-05 20:37:13 --> Controller Class Initialized
INFO - 2016-05-05 20:37:13 --> Model Class Initialized
INFO - 2016-05-05 20:37:13 --> Database Driver Class Initialized
INFO - 2016-05-05 20:37:13 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:37:13 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:37:13 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:37:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 20:37:13 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:37:13 --> Final output sent to browser
DEBUG - 2016-05-05 20:37:13 --> Total execution time: 0.1687
INFO - 2016-05-05 20:38:44 --> Config Class Initialized
INFO - 2016-05-05 20:38:44 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:38:44 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:38:44 --> Utf8 Class Initialized
INFO - 2016-05-05 20:38:44 --> URI Class Initialized
INFO - 2016-05-05 20:38:44 --> Router Class Initialized
INFO - 2016-05-05 20:38:44 --> Output Class Initialized
INFO - 2016-05-05 20:38:44 --> Security Class Initialized
DEBUG - 2016-05-05 20:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:38:44 --> Input Class Initialized
INFO - 2016-05-05 20:38:44 --> Language Class Initialized
INFO - 2016-05-05 20:38:44 --> Loader Class Initialized
INFO - 2016-05-05 20:38:44 --> Helper loaded: url_helper
INFO - 2016-05-05 20:38:44 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:38:44 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:38:44 --> Helper loaded: form_helper
INFO - 2016-05-05 20:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:38:44 --> Form Validation Class Initialized
INFO - 2016-05-05 20:38:44 --> Controller Class Initialized
INFO - 2016-05-05 20:38:44 --> Model Class Initialized
INFO - 2016-05-05 20:38:44 --> Database Driver Class Initialized
INFO - 2016-05-05 20:38:44 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:38:44 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:38:44 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:38:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 20:38:44 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:38:44 --> Final output sent to browser
DEBUG - 2016-05-05 20:38:44 --> Total execution time: 0.0970
INFO - 2016-05-05 20:38:50 --> Config Class Initialized
INFO - 2016-05-05 20:38:50 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:38:50 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:38:50 --> Utf8 Class Initialized
INFO - 2016-05-05 20:38:50 --> URI Class Initialized
INFO - 2016-05-05 20:38:50 --> Router Class Initialized
INFO - 2016-05-05 20:38:50 --> Output Class Initialized
INFO - 2016-05-05 20:38:50 --> Security Class Initialized
DEBUG - 2016-05-05 20:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:38:50 --> Input Class Initialized
INFO - 2016-05-05 20:38:50 --> Language Class Initialized
INFO - 2016-05-05 20:38:50 --> Loader Class Initialized
INFO - 2016-05-05 20:38:50 --> Helper loaded: url_helper
INFO - 2016-05-05 20:38:50 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:38:50 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:38:50 --> Helper loaded: form_helper
INFO - 2016-05-05 20:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:38:50 --> Form Validation Class Initialized
INFO - 2016-05-05 20:38:50 --> Controller Class Initialized
INFO - 2016-05-05 20:38:50 --> Model Class Initialized
INFO - 2016-05-05 20:38:50 --> Database Driver Class Initialized
INFO - 2016-05-05 20:38:50 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:38:50 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:38:50 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:38:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 20:38:50 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:38:50 --> Final output sent to browser
DEBUG - 2016-05-05 20:38:50 --> Total execution time: 0.1661
INFO - 2016-05-05 20:38:52 --> Config Class Initialized
INFO - 2016-05-05 20:38:52 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:38:52 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:38:52 --> Utf8 Class Initialized
INFO - 2016-05-05 20:38:52 --> URI Class Initialized
INFO - 2016-05-05 20:38:52 --> Router Class Initialized
INFO - 2016-05-05 20:38:52 --> Output Class Initialized
INFO - 2016-05-05 20:38:52 --> Security Class Initialized
DEBUG - 2016-05-05 20:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:38:52 --> Input Class Initialized
INFO - 2016-05-05 20:38:52 --> Language Class Initialized
INFO - 2016-05-05 20:38:52 --> Loader Class Initialized
INFO - 2016-05-05 20:38:52 --> Helper loaded: url_helper
INFO - 2016-05-05 20:38:52 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:38:52 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:38:52 --> Helper loaded: form_helper
INFO - 2016-05-05 20:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:38:52 --> Form Validation Class Initialized
INFO - 2016-05-05 20:38:52 --> Controller Class Initialized
INFO - 2016-05-05 20:38:52 --> Model Class Initialized
INFO - 2016-05-05 20:38:52 --> Database Driver Class Initialized
INFO - 2016-05-05 20:38:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:38:52 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:38:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:38:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modCategoria.php
INFO - 2016-05-05 20:38:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:38:52 --> Final output sent to browser
DEBUG - 2016-05-05 20:38:52 --> Total execution time: 0.1052
INFO - 2016-05-05 20:38:53 --> Config Class Initialized
INFO - 2016-05-05 20:38:53 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:38:53 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:38:53 --> Utf8 Class Initialized
INFO - 2016-05-05 20:38:53 --> URI Class Initialized
INFO - 2016-05-05 20:38:53 --> Router Class Initialized
INFO - 2016-05-05 20:38:53 --> Output Class Initialized
INFO - 2016-05-05 20:38:53 --> Security Class Initialized
DEBUG - 2016-05-05 20:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:38:53 --> Input Class Initialized
INFO - 2016-05-05 20:38:53 --> Language Class Initialized
INFO - 2016-05-05 20:38:53 --> Loader Class Initialized
INFO - 2016-05-05 20:38:53 --> Helper loaded: url_helper
INFO - 2016-05-05 20:38:53 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:38:53 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:38:53 --> Helper loaded: form_helper
INFO - 2016-05-05 20:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:38:53 --> Form Validation Class Initialized
INFO - 2016-05-05 20:38:53 --> Controller Class Initialized
INFO - 2016-05-05 20:38:53 --> Model Class Initialized
INFO - 2016-05-05 20:38:53 --> Database Driver Class Initialized
INFO - 2016-05-05 20:38:53 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:38:53 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:38:53 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:38:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 20:38:53 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:38:53 --> Final output sent to browser
DEBUG - 2016-05-05 20:38:53 --> Total execution time: 0.0895
INFO - 2016-05-05 20:38:58 --> Config Class Initialized
INFO - 2016-05-05 20:38:58 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:38:58 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:38:58 --> Utf8 Class Initialized
INFO - 2016-05-05 20:38:58 --> URI Class Initialized
INFO - 2016-05-05 20:38:58 --> Router Class Initialized
INFO - 2016-05-05 20:38:58 --> Output Class Initialized
INFO - 2016-05-05 20:38:58 --> Security Class Initialized
DEBUG - 2016-05-05 20:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:38:58 --> Input Class Initialized
INFO - 2016-05-05 20:38:58 --> Language Class Initialized
INFO - 2016-05-05 20:38:58 --> Loader Class Initialized
INFO - 2016-05-05 20:38:58 --> Helper loaded: url_helper
INFO - 2016-05-05 20:38:58 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:38:58 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:38:58 --> Helper loaded: form_helper
INFO - 2016-05-05 20:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:38:58 --> Form Validation Class Initialized
INFO - 2016-05-05 20:38:58 --> Controller Class Initialized
INFO - 2016-05-05 20:38:58 --> Model Class Initialized
INFO - 2016-05-05 20:38:58 --> Database Driver Class Initialized
INFO - 2016-05-05 20:38:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:38:58 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:38:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:38:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 20:38:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:38:58 --> Final output sent to browser
DEBUG - 2016-05-05 20:38:58 --> Total execution time: 0.1141
INFO - 2016-05-05 20:39:01 --> Config Class Initialized
INFO - 2016-05-05 20:39:01 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:39:01 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:39:01 --> Utf8 Class Initialized
INFO - 2016-05-05 20:39:01 --> URI Class Initialized
INFO - 2016-05-05 20:39:01 --> Router Class Initialized
INFO - 2016-05-05 20:39:01 --> Output Class Initialized
INFO - 2016-05-05 20:39:01 --> Security Class Initialized
DEBUG - 2016-05-05 20:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:39:01 --> Input Class Initialized
INFO - 2016-05-05 20:39:01 --> Language Class Initialized
INFO - 2016-05-05 20:39:01 --> Loader Class Initialized
INFO - 2016-05-05 20:39:01 --> Helper loaded: url_helper
INFO - 2016-05-05 20:39:01 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:39:01 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:39:01 --> Helper loaded: form_helper
INFO - 2016-05-05 20:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:39:01 --> Form Validation Class Initialized
INFO - 2016-05-05 20:39:01 --> Controller Class Initialized
INFO - 2016-05-05 20:39:01 --> Model Class Initialized
INFO - 2016-05-05 20:39:01 --> Database Driver Class Initialized
INFO - 2016-05-05 20:39:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:39:01 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:39:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:39:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 20:39:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:39:01 --> Final output sent to browser
DEBUG - 2016-05-05 20:39:01 --> Total execution time: 0.0726
INFO - 2016-05-05 20:39:02 --> Config Class Initialized
INFO - 2016-05-05 20:39:02 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:39:02 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:39:02 --> Utf8 Class Initialized
INFO - 2016-05-05 20:39:02 --> URI Class Initialized
INFO - 2016-05-05 20:39:02 --> Router Class Initialized
INFO - 2016-05-05 20:39:02 --> Output Class Initialized
INFO - 2016-05-05 20:39:02 --> Security Class Initialized
DEBUG - 2016-05-05 20:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:39:02 --> Input Class Initialized
INFO - 2016-05-05 20:39:02 --> Language Class Initialized
INFO - 2016-05-05 20:39:02 --> Loader Class Initialized
INFO - 2016-05-05 20:39:02 --> Helper loaded: url_helper
INFO - 2016-05-05 20:39:02 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:39:02 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:39:02 --> Helper loaded: form_helper
INFO - 2016-05-05 20:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:39:03 --> Form Validation Class Initialized
INFO - 2016-05-05 20:39:03 --> Controller Class Initialized
INFO - 2016-05-05 20:39:03 --> Model Class Initialized
INFO - 2016-05-05 20:39:03 --> Database Driver Class Initialized
INFO - 2016-05-05 20:39:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:39:03 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:39:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:39:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 20:39:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:39:03 --> Final output sent to browser
DEBUG - 2016-05-05 20:39:03 --> Total execution time: 0.1291
INFO - 2016-05-05 20:39:05 --> Config Class Initialized
INFO - 2016-05-05 20:39:05 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:39:05 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:39:05 --> Utf8 Class Initialized
INFO - 2016-05-05 20:39:05 --> URI Class Initialized
INFO - 2016-05-05 20:39:05 --> Router Class Initialized
INFO - 2016-05-05 20:39:05 --> Output Class Initialized
INFO - 2016-05-05 20:39:05 --> Security Class Initialized
DEBUG - 2016-05-05 20:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:39:05 --> Input Class Initialized
INFO - 2016-05-05 20:39:05 --> Language Class Initialized
INFO - 2016-05-05 20:39:05 --> Loader Class Initialized
INFO - 2016-05-05 20:39:05 --> Helper loaded: url_helper
INFO - 2016-05-05 20:39:05 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:39:05 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:39:05 --> Helper loaded: form_helper
INFO - 2016-05-05 20:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:39:05 --> Form Validation Class Initialized
INFO - 2016-05-05 20:39:05 --> Controller Class Initialized
INFO - 2016-05-05 20:39:05 --> Model Class Initialized
INFO - 2016-05-05 20:39:05 --> Database Driver Class Initialized
INFO - 2016-05-05 20:39:05 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:39:05 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:39:05 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:39:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 20:39:05 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:39:05 --> Final output sent to browser
DEBUG - 2016-05-05 20:39:05 --> Total execution time: 0.0841
INFO - 2016-05-05 20:43:00 --> Config Class Initialized
INFO - 2016-05-05 20:43:00 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:43:00 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:43:00 --> Utf8 Class Initialized
INFO - 2016-05-05 20:43:00 --> URI Class Initialized
INFO - 2016-05-05 20:43:00 --> Router Class Initialized
INFO - 2016-05-05 20:43:00 --> Output Class Initialized
INFO - 2016-05-05 20:43:00 --> Security Class Initialized
DEBUG - 2016-05-05 20:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:43:00 --> Input Class Initialized
INFO - 2016-05-05 20:43:00 --> Language Class Initialized
INFO - 2016-05-05 20:43:00 --> Loader Class Initialized
INFO - 2016-05-05 20:43:00 --> Helper loaded: url_helper
INFO - 2016-05-05 20:43:00 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:43:00 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:43:00 --> Helper loaded: form_helper
INFO - 2016-05-05 20:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:43:00 --> Form Validation Class Initialized
INFO - 2016-05-05 20:43:00 --> Controller Class Initialized
INFO - 2016-05-05 20:43:00 --> Model Class Initialized
INFO - 2016-05-05 20:43:00 --> Database Driver Class Initialized
INFO - 2016-05-05 20:43:00 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:43:00 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:43:00 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:43:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 20:43:00 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:43:00 --> Final output sent to browser
DEBUG - 2016-05-05 20:43:00 --> Total execution time: 0.1176
INFO - 2016-05-05 20:43:03 --> Config Class Initialized
INFO - 2016-05-05 20:43:03 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:43:03 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:43:03 --> Utf8 Class Initialized
INFO - 2016-05-05 20:43:03 --> URI Class Initialized
INFO - 2016-05-05 20:43:03 --> Router Class Initialized
INFO - 2016-05-05 20:43:03 --> Output Class Initialized
INFO - 2016-05-05 20:43:03 --> Security Class Initialized
DEBUG - 2016-05-05 20:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:43:03 --> Input Class Initialized
INFO - 2016-05-05 20:43:03 --> Language Class Initialized
INFO - 2016-05-05 20:43:03 --> Loader Class Initialized
INFO - 2016-05-05 20:43:03 --> Helper loaded: url_helper
INFO - 2016-05-05 20:43:03 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:43:03 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:43:03 --> Helper loaded: form_helper
INFO - 2016-05-05 20:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:43:03 --> Form Validation Class Initialized
INFO - 2016-05-05 20:43:03 --> Controller Class Initialized
INFO - 2016-05-05 20:43:03 --> Model Class Initialized
INFO - 2016-05-05 20:43:03 --> Database Driver Class Initialized
INFO - 2016-05-05 20:43:03 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:43:03 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:43:03 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-05 20:43:03 --> Severity: Notice --> Undefined variable: select_categorias C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php 54
ERROR - 2016-05-05 20:43:03 --> Severity: Notice --> Undefined variable: select_proveedores C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php 59
INFO - 2016-05-05 20:43:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-05 20:43:03 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:43:03 --> Final output sent to browser
DEBUG - 2016-05-05 20:43:03 --> Total execution time: 0.1206
INFO - 2016-05-05 20:45:49 --> Config Class Initialized
INFO - 2016-05-05 20:45:49 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:45:49 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:45:49 --> Utf8 Class Initialized
INFO - 2016-05-05 20:45:49 --> URI Class Initialized
INFO - 2016-05-05 20:45:49 --> Router Class Initialized
INFO - 2016-05-05 20:45:49 --> Output Class Initialized
INFO - 2016-05-05 20:45:49 --> Security Class Initialized
DEBUG - 2016-05-05 20:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:45:49 --> Input Class Initialized
INFO - 2016-05-05 20:45:49 --> Language Class Initialized
INFO - 2016-05-05 20:45:49 --> Loader Class Initialized
INFO - 2016-05-05 20:45:49 --> Helper loaded: url_helper
INFO - 2016-05-05 20:45:49 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:45:49 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:45:49 --> Helper loaded: form_helper
INFO - 2016-05-05 20:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:45:49 --> Form Validation Class Initialized
INFO - 2016-05-05 20:45:49 --> Controller Class Initialized
INFO - 2016-05-05 20:45:49 --> Model Class Initialized
ERROR - 2016-05-05 20:45:49 --> Severity: Compile Error --> Cannot redeclare Mdl_lista::getCategorias() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 222
INFO - 2016-05-05 20:46:26 --> Config Class Initialized
INFO - 2016-05-05 20:46:26 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:46:26 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:46:26 --> Utf8 Class Initialized
INFO - 2016-05-05 20:46:26 --> URI Class Initialized
INFO - 2016-05-05 20:46:26 --> Router Class Initialized
INFO - 2016-05-05 20:46:26 --> Output Class Initialized
INFO - 2016-05-05 20:46:26 --> Security Class Initialized
DEBUG - 2016-05-05 20:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:46:26 --> Input Class Initialized
INFO - 2016-05-05 20:46:26 --> Language Class Initialized
INFO - 2016-05-05 20:46:26 --> Loader Class Initialized
INFO - 2016-05-05 20:46:26 --> Helper loaded: url_helper
INFO - 2016-05-05 20:46:26 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:46:26 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:46:26 --> Helper loaded: form_helper
INFO - 2016-05-05 20:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:46:26 --> Form Validation Class Initialized
INFO - 2016-05-05 20:46:26 --> Controller Class Initialized
INFO - 2016-05-05 20:46:26 --> Model Class Initialized
ERROR - 2016-05-05 20:46:26 --> Severity: Compile Error --> Cannot redeclare Mdl_lista::getCategorias() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 222
INFO - 2016-05-05 20:46:28 --> Config Class Initialized
INFO - 2016-05-05 20:46:28 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:46:28 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:46:28 --> Utf8 Class Initialized
INFO - 2016-05-05 20:46:28 --> URI Class Initialized
INFO - 2016-05-05 20:46:28 --> Router Class Initialized
INFO - 2016-05-05 20:46:28 --> Output Class Initialized
INFO - 2016-05-05 20:46:28 --> Security Class Initialized
DEBUG - 2016-05-05 20:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:46:28 --> Input Class Initialized
INFO - 2016-05-05 20:46:28 --> Language Class Initialized
INFO - 2016-05-05 20:46:28 --> Loader Class Initialized
INFO - 2016-05-05 20:46:28 --> Helper loaded: url_helper
INFO - 2016-05-05 20:46:28 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:46:28 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:46:28 --> Helper loaded: form_helper
INFO - 2016-05-05 20:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:46:28 --> Form Validation Class Initialized
INFO - 2016-05-05 20:46:28 --> Controller Class Initialized
INFO - 2016-05-05 20:46:28 --> Model Class Initialized
ERROR - 2016-05-05 20:46:28 --> Severity: Compile Error --> Cannot redeclare Mdl_lista::getCategorias() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 222
INFO - 2016-05-05 20:46:29 --> Config Class Initialized
INFO - 2016-05-05 20:46:29 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:46:29 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:46:29 --> Utf8 Class Initialized
INFO - 2016-05-05 20:46:29 --> URI Class Initialized
INFO - 2016-05-05 20:46:29 --> Router Class Initialized
INFO - 2016-05-05 20:46:29 --> Output Class Initialized
INFO - 2016-05-05 20:46:29 --> Security Class Initialized
DEBUG - 2016-05-05 20:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:46:29 --> Input Class Initialized
INFO - 2016-05-05 20:46:29 --> Language Class Initialized
INFO - 2016-05-05 20:46:29 --> Loader Class Initialized
INFO - 2016-05-05 20:46:29 --> Helper loaded: url_helper
INFO - 2016-05-05 20:46:29 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:46:29 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:46:29 --> Helper loaded: form_helper
INFO - 2016-05-05 20:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:46:29 --> Form Validation Class Initialized
INFO - 2016-05-05 20:46:29 --> Controller Class Initialized
INFO - 2016-05-05 20:46:29 --> Model Class Initialized
ERROR - 2016-05-05 20:46:29 --> Severity: Compile Error --> Cannot redeclare Mdl_lista::getCategorias() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 222
INFO - 2016-05-05 20:46:29 --> Config Class Initialized
INFO - 2016-05-05 20:46:29 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:46:29 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:46:29 --> Utf8 Class Initialized
INFO - 2016-05-05 20:46:29 --> URI Class Initialized
INFO - 2016-05-05 20:46:29 --> Router Class Initialized
INFO - 2016-05-05 20:46:29 --> Output Class Initialized
INFO - 2016-05-05 20:46:29 --> Security Class Initialized
DEBUG - 2016-05-05 20:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:46:29 --> Input Class Initialized
INFO - 2016-05-05 20:46:29 --> Language Class Initialized
INFO - 2016-05-05 20:46:29 --> Loader Class Initialized
INFO - 2016-05-05 20:46:29 --> Helper loaded: url_helper
INFO - 2016-05-05 20:46:29 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:46:29 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:46:29 --> Helper loaded: form_helper
INFO - 2016-05-05 20:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:46:29 --> Form Validation Class Initialized
INFO - 2016-05-05 20:46:29 --> Controller Class Initialized
INFO - 2016-05-05 20:46:29 --> Model Class Initialized
ERROR - 2016-05-05 20:46:29 --> Severity: Compile Error --> Cannot redeclare Mdl_lista::getCategorias() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 222
INFO - 2016-05-05 20:46:30 --> Config Class Initialized
INFO - 2016-05-05 20:46:30 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:46:30 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:46:30 --> Utf8 Class Initialized
INFO - 2016-05-05 20:46:30 --> URI Class Initialized
INFO - 2016-05-05 20:46:30 --> Router Class Initialized
INFO - 2016-05-05 20:46:30 --> Output Class Initialized
INFO - 2016-05-05 20:46:30 --> Security Class Initialized
DEBUG - 2016-05-05 20:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:46:30 --> Input Class Initialized
INFO - 2016-05-05 20:46:30 --> Language Class Initialized
INFO - 2016-05-05 20:46:30 --> Loader Class Initialized
INFO - 2016-05-05 20:46:30 --> Helper loaded: url_helper
INFO - 2016-05-05 20:46:30 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:46:30 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:46:30 --> Helper loaded: form_helper
INFO - 2016-05-05 20:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:46:30 --> Form Validation Class Initialized
INFO - 2016-05-05 20:46:30 --> Controller Class Initialized
INFO - 2016-05-05 20:46:30 --> Model Class Initialized
ERROR - 2016-05-05 20:46:30 --> Severity: Compile Error --> Cannot redeclare Mdl_lista::getCategorias() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 222
INFO - 2016-05-05 20:46:30 --> Config Class Initialized
INFO - 2016-05-05 20:46:30 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:46:30 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:46:30 --> Utf8 Class Initialized
INFO - 2016-05-05 20:46:30 --> URI Class Initialized
INFO - 2016-05-05 20:46:30 --> Router Class Initialized
INFO - 2016-05-05 20:46:30 --> Output Class Initialized
INFO - 2016-05-05 20:46:30 --> Security Class Initialized
DEBUG - 2016-05-05 20:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:46:30 --> Input Class Initialized
INFO - 2016-05-05 20:46:30 --> Language Class Initialized
INFO - 2016-05-05 20:46:30 --> Loader Class Initialized
INFO - 2016-05-05 20:46:30 --> Helper loaded: url_helper
INFO - 2016-05-05 20:46:30 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:46:31 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:46:31 --> Helper loaded: form_helper
INFO - 2016-05-05 20:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:46:31 --> Form Validation Class Initialized
INFO - 2016-05-05 20:46:31 --> Controller Class Initialized
INFO - 2016-05-05 20:46:31 --> Model Class Initialized
ERROR - 2016-05-05 20:46:31 --> Severity: Compile Error --> Cannot redeclare Mdl_lista::getCategorias() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 222
INFO - 2016-05-05 20:46:32 --> Config Class Initialized
INFO - 2016-05-05 20:46:32 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:46:32 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:46:32 --> Utf8 Class Initialized
INFO - 2016-05-05 20:46:32 --> URI Class Initialized
INFO - 2016-05-05 20:46:32 --> Router Class Initialized
INFO - 2016-05-05 20:46:32 --> Output Class Initialized
INFO - 2016-05-05 20:46:33 --> Security Class Initialized
DEBUG - 2016-05-05 20:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:46:33 --> Input Class Initialized
INFO - 2016-05-05 20:46:33 --> Language Class Initialized
INFO - 2016-05-05 20:46:33 --> Loader Class Initialized
INFO - 2016-05-05 20:46:33 --> Helper loaded: url_helper
INFO - 2016-05-05 20:46:33 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:46:33 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:46:33 --> Helper loaded: form_helper
INFO - 2016-05-05 20:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:46:33 --> Form Validation Class Initialized
INFO - 2016-05-05 20:46:33 --> Controller Class Initialized
INFO - 2016-05-05 20:46:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-05 20:46:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:46:33 --> Final output sent to browser
DEBUG - 2016-05-05 20:46:33 --> Total execution time: 0.0494
INFO - 2016-05-05 20:46:35 --> Config Class Initialized
INFO - 2016-05-05 20:46:35 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:46:35 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:46:35 --> Utf8 Class Initialized
INFO - 2016-05-05 20:46:35 --> URI Class Initialized
INFO - 2016-05-05 20:46:35 --> Router Class Initialized
INFO - 2016-05-05 20:46:35 --> Output Class Initialized
INFO - 2016-05-05 20:46:35 --> Security Class Initialized
DEBUG - 2016-05-05 20:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:46:35 --> Input Class Initialized
INFO - 2016-05-05 20:46:35 --> Language Class Initialized
INFO - 2016-05-05 20:46:35 --> Loader Class Initialized
INFO - 2016-05-05 20:46:35 --> Helper loaded: url_helper
INFO - 2016-05-05 20:46:35 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:46:35 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:46:35 --> Helper loaded: form_helper
INFO - 2016-05-05 20:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:46:35 --> Form Validation Class Initialized
INFO - 2016-05-05 20:46:35 --> Controller Class Initialized
INFO - 2016-05-05 20:46:35 --> Model Class Initialized
ERROR - 2016-05-05 20:46:35 --> Severity: Compile Error --> Cannot redeclare Mdl_lista::getCategorias() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\models\Mdl_lista.php 222
INFO - 2016-05-05 20:47:39 --> Config Class Initialized
INFO - 2016-05-05 20:47:39 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:47:39 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:47:39 --> Utf8 Class Initialized
INFO - 2016-05-05 20:47:39 --> URI Class Initialized
INFO - 2016-05-05 20:47:39 --> Router Class Initialized
INFO - 2016-05-05 20:47:39 --> Output Class Initialized
INFO - 2016-05-05 20:47:39 --> Security Class Initialized
DEBUG - 2016-05-05 20:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:47:39 --> Input Class Initialized
INFO - 2016-05-05 20:47:39 --> Language Class Initialized
INFO - 2016-05-05 20:47:39 --> Loader Class Initialized
INFO - 2016-05-05 20:47:39 --> Helper loaded: url_helper
INFO - 2016-05-05 20:47:39 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:47:39 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:47:39 --> Helper loaded: form_helper
INFO - 2016-05-05 20:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:47:39 --> Form Validation Class Initialized
INFO - 2016-05-05 20:47:39 --> Controller Class Initialized
INFO - 2016-05-05 20:47:39 --> Model Class Initialized
INFO - 2016-05-05 20:47:39 --> Database Driver Class Initialized
INFO - 2016-05-05 20:47:39 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:47:39 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:47:39 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:47:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 20:47:39 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:47:39 --> Final output sent to browser
DEBUG - 2016-05-05 20:47:39 --> Total execution time: 0.0881
INFO - 2016-05-05 20:47:42 --> Config Class Initialized
INFO - 2016-05-05 20:47:42 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:47:42 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:47:42 --> Utf8 Class Initialized
INFO - 2016-05-05 20:47:42 --> URI Class Initialized
INFO - 2016-05-05 20:47:42 --> Router Class Initialized
INFO - 2016-05-05 20:47:42 --> Output Class Initialized
INFO - 2016-05-05 20:47:42 --> Security Class Initialized
DEBUG - 2016-05-05 20:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:47:42 --> Input Class Initialized
INFO - 2016-05-05 20:47:42 --> Language Class Initialized
INFO - 2016-05-05 20:47:42 --> Loader Class Initialized
INFO - 2016-05-05 20:47:42 --> Helper loaded: url_helper
INFO - 2016-05-05 20:47:42 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:47:42 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:47:42 --> Helper loaded: form_helper
INFO - 2016-05-05 20:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:47:42 --> Form Validation Class Initialized
INFO - 2016-05-05 20:47:42 --> Controller Class Initialized
INFO - 2016-05-05 20:47:42 --> Model Class Initialized
INFO - 2016-05-05 20:47:42 --> Database Driver Class Initialized
INFO - 2016-05-05 20:47:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:47:42 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:47:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
ERROR - 2016-05-05 20:47:43 --> Severity: Error --> Call to undefined function CreaSelect() C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\controllers\Administrador\Lista\Productos.php 173
INFO - 2016-05-05 20:47:57 --> Config Class Initialized
INFO - 2016-05-05 20:47:57 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:47:57 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:47:57 --> Utf8 Class Initialized
INFO - 2016-05-05 20:47:57 --> URI Class Initialized
INFO - 2016-05-05 20:47:57 --> Router Class Initialized
INFO - 2016-05-05 20:47:57 --> Output Class Initialized
INFO - 2016-05-05 20:47:57 --> Security Class Initialized
DEBUG - 2016-05-05 20:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:47:57 --> Input Class Initialized
INFO - 2016-05-05 20:47:57 --> Language Class Initialized
INFO - 2016-05-05 20:47:57 --> Loader Class Initialized
INFO - 2016-05-05 20:47:57 --> Helper loaded: url_helper
INFO - 2016-05-05 20:47:57 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:47:57 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:47:57 --> Helper loaded: form_helper
INFO - 2016-05-05 20:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:47:57 --> Form Validation Class Initialized
INFO - 2016-05-05 20:47:57 --> Controller Class Initialized
INFO - 2016-05-05 20:47:57 --> Model Class Initialized
INFO - 2016-05-05 20:47:57 --> Database Driver Class Initialized
INFO - 2016-05-05 20:47:57 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:47:57 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:47:57 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:47:57 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:47:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-05 20:47:57 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:47:57 --> Final output sent to browser
DEBUG - 2016-05-05 20:47:57 --> Total execution time: 0.0816
INFO - 2016-05-05 20:49:01 --> Config Class Initialized
INFO - 2016-05-05 20:49:01 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:49:01 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:49:01 --> Utf8 Class Initialized
INFO - 2016-05-05 20:49:01 --> URI Class Initialized
INFO - 2016-05-05 20:49:01 --> Router Class Initialized
INFO - 2016-05-05 20:49:01 --> Output Class Initialized
INFO - 2016-05-05 20:49:01 --> Security Class Initialized
DEBUG - 2016-05-05 20:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:49:01 --> Input Class Initialized
INFO - 2016-05-05 20:49:01 --> Language Class Initialized
INFO - 2016-05-05 20:49:01 --> Loader Class Initialized
INFO - 2016-05-05 20:49:01 --> Helper loaded: url_helper
INFO - 2016-05-05 20:49:01 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:49:01 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:49:01 --> Helper loaded: form_helper
INFO - 2016-05-05 20:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:49:01 --> Form Validation Class Initialized
INFO - 2016-05-05 20:49:01 --> Controller Class Initialized
INFO - 2016-05-05 20:49:01 --> Model Class Initialized
INFO - 2016-05-05 20:49:01 --> Database Driver Class Initialized
INFO - 2016-05-05 20:49:01 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:49:01 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:49:01 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:49:01 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:49:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-05 20:49:01 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:49:01 --> Final output sent to browser
DEBUG - 2016-05-05 20:49:01 --> Total execution time: 0.0853
INFO - 2016-05-05 20:49:27 --> Config Class Initialized
INFO - 2016-05-05 20:49:27 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:49:27 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:49:27 --> Utf8 Class Initialized
INFO - 2016-05-05 20:49:27 --> URI Class Initialized
INFO - 2016-05-05 20:49:27 --> Router Class Initialized
INFO - 2016-05-05 20:49:27 --> Output Class Initialized
INFO - 2016-05-05 20:49:27 --> Security Class Initialized
DEBUG - 2016-05-05 20:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:49:27 --> Input Class Initialized
INFO - 2016-05-05 20:49:27 --> Language Class Initialized
INFO - 2016-05-05 20:49:27 --> Loader Class Initialized
INFO - 2016-05-05 20:49:27 --> Helper loaded: url_helper
INFO - 2016-05-05 20:49:27 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:49:27 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:49:27 --> Helper loaded: form_helper
INFO - 2016-05-05 20:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:49:27 --> Form Validation Class Initialized
INFO - 2016-05-05 20:49:27 --> Controller Class Initialized
INFO - 2016-05-05 20:49:27 --> Model Class Initialized
INFO - 2016-05-05 20:49:27 --> Database Driver Class Initialized
INFO - 2016-05-05 20:49:27 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:49:27 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:49:27 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:49:27 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:49:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 20:49:27 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:49:27 --> Final output sent to browser
DEBUG - 2016-05-05 20:49:27 --> Total execution time: 0.0766
INFO - 2016-05-05 20:49:29 --> Config Class Initialized
INFO - 2016-05-05 20:49:29 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:49:29 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:49:29 --> Utf8 Class Initialized
INFO - 2016-05-05 20:49:29 --> URI Class Initialized
INFO - 2016-05-05 20:49:29 --> Router Class Initialized
INFO - 2016-05-05 20:49:29 --> Output Class Initialized
INFO - 2016-05-05 20:49:29 --> Security Class Initialized
DEBUG - 2016-05-05 20:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:49:29 --> Input Class Initialized
INFO - 2016-05-05 20:49:29 --> Language Class Initialized
INFO - 2016-05-05 20:49:29 --> Loader Class Initialized
INFO - 2016-05-05 20:49:29 --> Helper loaded: url_helper
INFO - 2016-05-05 20:49:29 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:49:29 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:49:29 --> Helper loaded: form_helper
INFO - 2016-05-05 20:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:49:29 --> Form Validation Class Initialized
INFO - 2016-05-05 20:49:29 --> Controller Class Initialized
INFO - 2016-05-05 20:49:29 --> Model Class Initialized
INFO - 2016-05-05 20:49:29 --> Database Driver Class Initialized
INFO - 2016-05-05 20:49:29 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:49:29 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:49:29 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:49:29 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:49:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-05 20:49:29 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:49:29 --> Final output sent to browser
DEBUG - 2016-05-05 20:49:29 --> Total execution time: 0.1150
INFO - 2016-05-05 20:49:36 --> Config Class Initialized
INFO - 2016-05-05 20:49:36 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:49:36 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:49:36 --> Utf8 Class Initialized
INFO - 2016-05-05 20:49:36 --> URI Class Initialized
INFO - 2016-05-05 20:49:36 --> Router Class Initialized
INFO - 2016-05-05 20:49:36 --> Output Class Initialized
INFO - 2016-05-05 20:49:36 --> Security Class Initialized
DEBUG - 2016-05-05 20:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:49:36 --> Input Class Initialized
INFO - 2016-05-05 20:49:36 --> Language Class Initialized
INFO - 2016-05-05 20:49:36 --> Loader Class Initialized
INFO - 2016-05-05 20:49:36 --> Helper loaded: url_helper
INFO - 2016-05-05 20:49:36 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:49:36 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:49:36 --> Helper loaded: form_helper
INFO - 2016-05-05 20:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:49:36 --> Form Validation Class Initialized
INFO - 2016-05-05 20:49:36 --> Controller Class Initialized
INFO - 2016-05-05 20:49:36 --> Model Class Initialized
INFO - 2016-05-05 20:49:36 --> Database Driver Class Initialized
INFO - 2016-05-05 20:49:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:49:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:49:36 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:49:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:49:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 20:49:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:49:36 --> Final output sent to browser
DEBUG - 2016-05-05 20:49:36 --> Total execution time: 0.1058
INFO - 2016-05-05 20:49:38 --> Config Class Initialized
INFO - 2016-05-05 20:49:38 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:49:38 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:49:38 --> Utf8 Class Initialized
INFO - 2016-05-05 20:49:38 --> URI Class Initialized
INFO - 2016-05-05 20:49:38 --> Router Class Initialized
INFO - 2016-05-05 20:49:38 --> Output Class Initialized
INFO - 2016-05-05 20:49:38 --> Security Class Initialized
DEBUG - 2016-05-05 20:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:49:38 --> Input Class Initialized
INFO - 2016-05-05 20:49:38 --> Language Class Initialized
INFO - 2016-05-05 20:49:38 --> Loader Class Initialized
INFO - 2016-05-05 20:49:38 --> Helper loaded: url_helper
INFO - 2016-05-05 20:49:38 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:49:38 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:49:38 --> Helper loaded: form_helper
INFO - 2016-05-05 20:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:49:38 --> Form Validation Class Initialized
INFO - 2016-05-05 20:49:38 --> Controller Class Initialized
INFO - 2016-05-05 20:49:38 --> Model Class Initialized
INFO - 2016-05-05 20:49:38 --> Database Driver Class Initialized
INFO - 2016-05-05 20:49:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:49:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:49:38 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:49:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:49:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-05 20:49:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:49:38 --> Final output sent to browser
DEBUG - 2016-05-05 20:49:38 --> Total execution time: 0.1333
INFO - 2016-05-05 20:49:42 --> Config Class Initialized
INFO - 2016-05-05 20:49:42 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:49:42 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:49:42 --> Utf8 Class Initialized
INFO - 2016-05-05 20:49:42 --> URI Class Initialized
INFO - 2016-05-05 20:49:42 --> Router Class Initialized
INFO - 2016-05-05 20:49:42 --> Output Class Initialized
INFO - 2016-05-05 20:49:42 --> Security Class Initialized
DEBUG - 2016-05-05 20:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:49:42 --> Input Class Initialized
INFO - 2016-05-05 20:49:42 --> Language Class Initialized
INFO - 2016-05-05 20:49:42 --> Loader Class Initialized
INFO - 2016-05-05 20:49:42 --> Helper loaded: url_helper
INFO - 2016-05-05 20:49:42 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:49:42 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:49:42 --> Helper loaded: form_helper
INFO - 2016-05-05 20:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:49:42 --> Form Validation Class Initialized
INFO - 2016-05-05 20:49:42 --> Controller Class Initialized
INFO - 2016-05-05 20:49:42 --> Model Class Initialized
INFO - 2016-05-05 20:49:42 --> Database Driver Class Initialized
INFO - 2016-05-05 20:49:42 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:49:42 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:49:42 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:49:42 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:49:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 20:49:42 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:49:42 --> Final output sent to browser
DEBUG - 2016-05-05 20:49:42 --> Total execution time: 0.0764
INFO - 2016-05-05 20:49:44 --> Config Class Initialized
INFO - 2016-05-05 20:49:44 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:49:44 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:49:44 --> Utf8 Class Initialized
INFO - 2016-05-05 20:49:44 --> URI Class Initialized
INFO - 2016-05-05 20:49:44 --> Router Class Initialized
INFO - 2016-05-05 20:49:44 --> Output Class Initialized
INFO - 2016-05-05 20:49:44 --> Security Class Initialized
DEBUG - 2016-05-05 20:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:49:44 --> Input Class Initialized
INFO - 2016-05-05 20:49:44 --> Language Class Initialized
INFO - 2016-05-05 20:49:44 --> Loader Class Initialized
INFO - 2016-05-05 20:49:45 --> Helper loaded: url_helper
INFO - 2016-05-05 20:49:45 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:49:45 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:49:45 --> Helper loaded: form_helper
INFO - 2016-05-05 20:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:49:45 --> Form Validation Class Initialized
INFO - 2016-05-05 20:49:45 --> Controller Class Initialized
INFO - 2016-05-05 20:49:45 --> Model Class Initialized
INFO - 2016-05-05 20:49:45 --> Database Driver Class Initialized
INFO - 2016-05-05 20:49:45 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:49:45 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:49:45 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:49:45 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:49:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-05 20:49:45 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:49:45 --> Final output sent to browser
DEBUG - 2016-05-05 20:49:45 --> Total execution time: 0.1431
INFO - 2016-05-05 20:50:23 --> Config Class Initialized
INFO - 2016-05-05 20:50:23 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:50:23 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:50:23 --> Utf8 Class Initialized
INFO - 2016-05-05 20:50:23 --> URI Class Initialized
INFO - 2016-05-05 20:50:23 --> Router Class Initialized
INFO - 2016-05-05 20:50:23 --> Output Class Initialized
INFO - 2016-05-05 20:50:23 --> Security Class Initialized
DEBUG - 2016-05-05 20:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:50:23 --> Input Class Initialized
INFO - 2016-05-05 20:50:23 --> Language Class Initialized
INFO - 2016-05-05 20:50:23 --> Loader Class Initialized
INFO - 2016-05-05 20:50:24 --> Helper loaded: url_helper
INFO - 2016-05-05 20:50:24 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:50:24 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:50:24 --> Helper loaded: form_helper
INFO - 2016-05-05 20:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:50:24 --> Form Validation Class Initialized
INFO - 2016-05-05 20:50:24 --> Controller Class Initialized
INFO - 2016-05-05 20:50:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_index.php
INFO - 2016-05-05 20:50:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:50:24 --> Final output sent to browser
DEBUG - 2016-05-05 20:50:24 --> Total execution time: 0.0540
INFO - 2016-05-05 20:50:30 --> Config Class Initialized
INFO - 2016-05-05 20:50:30 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:50:30 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:50:30 --> Utf8 Class Initialized
INFO - 2016-05-05 20:50:30 --> URI Class Initialized
INFO - 2016-05-05 20:50:30 --> Router Class Initialized
INFO - 2016-05-05 20:50:30 --> Output Class Initialized
INFO - 2016-05-05 20:50:30 --> Security Class Initialized
DEBUG - 2016-05-05 20:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:50:30 --> Input Class Initialized
INFO - 2016-05-05 20:50:30 --> Language Class Initialized
INFO - 2016-05-05 20:50:30 --> Loader Class Initialized
INFO - 2016-05-05 20:50:30 --> Helper loaded: url_helper
INFO - 2016-05-05 20:50:30 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:50:30 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:50:30 --> Helper loaded: form_helper
INFO - 2016-05-05 20:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:50:31 --> Form Validation Class Initialized
INFO - 2016-05-05 20:50:31 --> Controller Class Initialized
INFO - 2016-05-05 20:50:31 --> Model Class Initialized
INFO - 2016-05-05 20:50:31 --> Database Driver Class Initialized
INFO - 2016-05-05 20:50:31 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:50:31 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:50:31 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:50:31 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:50:31 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:50:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-05 20:50:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:50:31 --> Final output sent to browser
DEBUG - 2016-05-05 20:50:31 --> Total execution time: 0.1029
INFO - 2016-05-05 20:52:36 --> Config Class Initialized
INFO - 2016-05-05 20:52:36 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:52:36 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:52:36 --> Utf8 Class Initialized
INFO - 2016-05-05 20:52:36 --> URI Class Initialized
INFO - 2016-05-05 20:52:36 --> Router Class Initialized
INFO - 2016-05-05 20:52:36 --> Output Class Initialized
INFO - 2016-05-05 20:52:36 --> Security Class Initialized
DEBUG - 2016-05-05 20:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:52:36 --> Input Class Initialized
INFO - 2016-05-05 20:52:36 --> Language Class Initialized
INFO - 2016-05-05 20:52:36 --> Loader Class Initialized
INFO - 2016-05-05 20:52:36 --> Helper loaded: url_helper
INFO - 2016-05-05 20:52:36 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:52:36 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:52:36 --> Helper loaded: form_helper
INFO - 2016-05-05 20:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:52:36 --> Form Validation Class Initialized
INFO - 2016-05-05 20:52:36 --> Controller Class Initialized
INFO - 2016-05-05 20:52:36 --> Model Class Initialized
INFO - 2016-05-05 20:52:36 --> Database Driver Class Initialized
INFO - 2016-05-05 20:52:36 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:52:36 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:52:36 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:52:36 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:52:36 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:52:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-05 20:52:36 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:52:36 --> Final output sent to browser
DEBUG - 2016-05-05 20:52:36 --> Total execution time: 0.0855
INFO - 2016-05-05 20:52:38 --> Config Class Initialized
INFO - 2016-05-05 20:52:38 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:52:38 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:52:38 --> Utf8 Class Initialized
INFO - 2016-05-05 20:52:38 --> URI Class Initialized
INFO - 2016-05-05 20:52:38 --> Router Class Initialized
INFO - 2016-05-05 20:52:38 --> Output Class Initialized
INFO - 2016-05-05 20:52:38 --> Security Class Initialized
DEBUG - 2016-05-05 20:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:52:38 --> Input Class Initialized
INFO - 2016-05-05 20:52:38 --> Language Class Initialized
INFO - 2016-05-05 20:52:38 --> Loader Class Initialized
INFO - 2016-05-05 20:52:38 --> Helper loaded: url_helper
INFO - 2016-05-05 20:52:38 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:52:38 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:52:38 --> Helper loaded: form_helper
INFO - 2016-05-05 20:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:52:38 --> Form Validation Class Initialized
INFO - 2016-05-05 20:52:38 --> Controller Class Initialized
INFO - 2016-05-05 20:52:38 --> Model Class Initialized
INFO - 2016-05-05 20:52:38 --> Database Driver Class Initialized
INFO - 2016-05-05 20:52:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:52:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:52:38 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:52:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:52:38 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:52:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProveedor.php
INFO - 2016-05-05 20:52:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:52:38 --> Final output sent to browser
DEBUG - 2016-05-05 20:52:38 --> Total execution time: 0.1826
INFO - 2016-05-05 20:52:40 --> Config Class Initialized
INFO - 2016-05-05 20:52:40 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:52:40 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:52:40 --> Utf8 Class Initialized
INFO - 2016-05-05 20:52:40 --> URI Class Initialized
INFO - 2016-05-05 20:52:40 --> Router Class Initialized
INFO - 2016-05-05 20:52:40 --> Output Class Initialized
INFO - 2016-05-05 20:52:40 --> Security Class Initialized
DEBUG - 2016-05-05 20:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:52:40 --> Input Class Initialized
INFO - 2016-05-05 20:52:40 --> Language Class Initialized
INFO - 2016-05-05 20:52:40 --> Loader Class Initialized
INFO - 2016-05-05 20:52:40 --> Helper loaded: url_helper
INFO - 2016-05-05 20:52:40 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:52:40 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:52:40 --> Helper loaded: form_helper
INFO - 2016-05-05 20:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:52:40 --> Form Validation Class Initialized
INFO - 2016-05-05 20:52:40 --> Controller Class Initialized
INFO - 2016-05-05 20:52:40 --> Model Class Initialized
INFO - 2016-05-05 20:52:40 --> Database Driver Class Initialized
INFO - 2016-05-05 20:52:40 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:52:40 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:52:40 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:52:40 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:52:40 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 20:52:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProveedores.php
INFO - 2016-05-05 20:52:40 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:52:40 --> Final output sent to browser
DEBUG - 2016-05-05 20:52:40 --> Total execution time: 0.0975
INFO - 2016-05-05 20:52:43 --> Config Class Initialized
INFO - 2016-05-05 20:52:43 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:52:43 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:52:43 --> Utf8 Class Initialized
INFO - 2016-05-05 20:52:43 --> URI Class Initialized
INFO - 2016-05-05 20:52:43 --> Router Class Initialized
INFO - 2016-05-05 20:52:43 --> Output Class Initialized
INFO - 2016-05-05 20:52:43 --> Security Class Initialized
DEBUG - 2016-05-05 20:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:52:43 --> Input Class Initialized
INFO - 2016-05-05 20:52:43 --> Language Class Initialized
INFO - 2016-05-05 20:52:43 --> Loader Class Initialized
INFO - 2016-05-05 20:52:43 --> Helper loaded: url_helper
INFO - 2016-05-05 20:52:43 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:52:43 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:52:43 --> Helper loaded: form_helper
INFO - 2016-05-05 20:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:52:43 --> Form Validation Class Initialized
INFO - 2016-05-05 20:52:43 --> Controller Class Initialized
INFO - 2016-05-05 20:52:43 --> Model Class Initialized
INFO - 2016-05-05 20:52:43 --> Database Driver Class Initialized
INFO - 2016-05-05 20:52:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:52:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:52:43 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:52:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:52:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-05 20:52:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:52:43 --> Final output sent to browser
DEBUG - 2016-05-05 20:52:43 --> Total execution time: 0.0848
INFO - 2016-05-05 20:54:02 --> Config Class Initialized
INFO - 2016-05-05 20:54:02 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:54:02 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:54:02 --> Utf8 Class Initialized
INFO - 2016-05-05 20:54:02 --> URI Class Initialized
INFO - 2016-05-05 20:54:02 --> Router Class Initialized
INFO - 2016-05-05 20:54:02 --> Output Class Initialized
INFO - 2016-05-05 20:54:02 --> Security Class Initialized
DEBUG - 2016-05-05 20:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:54:02 --> Input Class Initialized
INFO - 2016-05-05 20:54:02 --> Language Class Initialized
INFO - 2016-05-05 20:54:02 --> Loader Class Initialized
INFO - 2016-05-05 20:54:02 --> Helper loaded: url_helper
INFO - 2016-05-05 20:54:02 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:54:02 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:54:02 --> Helper loaded: form_helper
INFO - 2016-05-05 20:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:54:02 --> Form Validation Class Initialized
INFO - 2016-05-05 20:54:02 --> Controller Class Initialized
INFO - 2016-05-05 20:54:02 --> Model Class Initialized
INFO - 2016-05-05 20:54:02 --> Database Driver Class Initialized
INFO - 2016-05-05 20:54:02 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:54:02 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:54:02 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:54:02 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:54:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-05 20:54:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:54:02 --> Final output sent to browser
DEBUG - 2016-05-05 20:54:02 --> Total execution time: 0.0801
INFO - 2016-05-05 20:55:20 --> Config Class Initialized
INFO - 2016-05-05 20:55:20 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:55:20 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:55:20 --> Utf8 Class Initialized
INFO - 2016-05-05 20:55:20 --> URI Class Initialized
INFO - 2016-05-05 20:55:20 --> Router Class Initialized
INFO - 2016-05-05 20:55:20 --> Output Class Initialized
INFO - 2016-05-05 20:55:20 --> Security Class Initialized
DEBUG - 2016-05-05 20:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:55:20 --> Input Class Initialized
INFO - 2016-05-05 20:55:20 --> Language Class Initialized
INFO - 2016-05-05 20:55:21 --> Loader Class Initialized
INFO - 2016-05-05 20:55:21 --> Helper loaded: url_helper
INFO - 2016-05-05 20:55:21 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:55:21 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:55:21 --> Helper loaded: form_helper
INFO - 2016-05-05 20:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:55:21 --> Form Validation Class Initialized
INFO - 2016-05-05 20:55:21 --> Controller Class Initialized
INFO - 2016-05-05 20:55:21 --> Model Class Initialized
INFO - 2016-05-05 20:55:21 --> Database Driver Class Initialized
INFO - 2016-05-05 20:55:21 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:55:21 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:55:21 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:55:21 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:55:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-05 20:55:21 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:55:21 --> Final output sent to browser
DEBUG - 2016-05-05 20:55:21 --> Total execution time: 0.0902
INFO - 2016-05-05 20:55:52 --> Config Class Initialized
INFO - 2016-05-05 20:55:52 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:55:52 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:55:52 --> Utf8 Class Initialized
INFO - 2016-05-05 20:55:52 --> URI Class Initialized
INFO - 2016-05-05 20:55:52 --> Router Class Initialized
INFO - 2016-05-05 20:55:52 --> Output Class Initialized
INFO - 2016-05-05 20:55:52 --> Security Class Initialized
DEBUG - 2016-05-05 20:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:55:52 --> Input Class Initialized
INFO - 2016-05-05 20:55:52 --> Language Class Initialized
INFO - 2016-05-05 20:55:52 --> Loader Class Initialized
INFO - 2016-05-05 20:55:52 --> Helper loaded: url_helper
INFO - 2016-05-05 20:55:52 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:55:52 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:55:52 --> Helper loaded: form_helper
INFO - 2016-05-05 20:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:55:52 --> Form Validation Class Initialized
INFO - 2016-05-05 20:55:52 --> Controller Class Initialized
INFO - 2016-05-05 20:55:52 --> Model Class Initialized
INFO - 2016-05-05 20:55:52 --> Database Driver Class Initialized
INFO - 2016-05-05 20:55:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:55:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:55:52 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:55:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:55:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-05 20:55:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:55:52 --> Final output sent to browser
DEBUG - 2016-05-05 20:55:52 --> Total execution time: 0.0843
INFO - 2016-05-05 20:56:33 --> Config Class Initialized
INFO - 2016-05-05 20:56:33 --> Hooks Class Initialized
DEBUG - 2016-05-05 20:56:33 --> UTF-8 Support Enabled
INFO - 2016-05-05 20:56:33 --> Utf8 Class Initialized
INFO - 2016-05-05 20:56:33 --> URI Class Initialized
INFO - 2016-05-05 20:56:33 --> Router Class Initialized
INFO - 2016-05-05 20:56:33 --> Output Class Initialized
INFO - 2016-05-05 20:56:33 --> Security Class Initialized
DEBUG - 2016-05-05 20:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 20:56:33 --> Input Class Initialized
INFO - 2016-05-05 20:56:33 --> Language Class Initialized
INFO - 2016-05-05 20:56:33 --> Loader Class Initialized
INFO - 2016-05-05 20:56:33 --> Helper loaded: url_helper
INFO - 2016-05-05 20:56:33 --> Helper loaded: sesion_helper
INFO - 2016-05-05 20:56:33 --> Helper loaded: templates_helper
INFO - 2016-05-05 20:56:33 --> Helper loaded: form_helper
INFO - 2016-05-05 20:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 20:56:33 --> Form Validation Class Initialized
INFO - 2016-05-05 20:56:33 --> Controller Class Initialized
INFO - 2016-05-05 20:56:33 --> Model Class Initialized
INFO - 2016-05-05 20:56:33 --> Database Driver Class Initialized
INFO - 2016-05-05 20:56:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 20:56:33 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 20:56:33 --> Pagination Class Initialized
DEBUG - 2016-05-05 20:56:33 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 20:56:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_modProducto.php
INFO - 2016-05-05 20:56:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 20:56:33 --> Final output sent to browser
DEBUG - 2016-05-05 20:56:33 --> Total execution time: 0.0754
INFO - 2016-05-05 21:03:33 --> Config Class Initialized
INFO - 2016-05-05 21:03:33 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:03:33 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:03:33 --> Utf8 Class Initialized
INFO - 2016-05-05 21:03:33 --> URI Class Initialized
INFO - 2016-05-05 21:03:33 --> Router Class Initialized
INFO - 2016-05-05 21:03:33 --> Output Class Initialized
INFO - 2016-05-05 21:03:33 --> Security Class Initialized
DEBUG - 2016-05-05 21:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:03:33 --> Input Class Initialized
INFO - 2016-05-05 21:03:33 --> Language Class Initialized
INFO - 2016-05-05 21:03:33 --> Loader Class Initialized
INFO - 2016-05-05 21:03:33 --> Helper loaded: url_helper
INFO - 2016-05-05 21:03:33 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:03:33 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:03:33 --> Helper loaded: form_helper
INFO - 2016-05-05 21:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:03:33 --> Form Validation Class Initialized
INFO - 2016-05-05 21:03:33 --> Controller Class Initialized
INFO - 2016-05-05 21:03:33 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:03:33 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 21:03:33 --> Model Class Initialized
INFO - 2016-05-05 21:03:33 --> Database Driver Class Initialized
INFO - 2016-05-05 21:03:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addProducto.php
INFO - 2016-05-05 21:03:33 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:03:33 --> Final output sent to browser
DEBUG - 2016-05-05 21:03:33 --> Total execution time: 0.0941
INFO - 2016-05-05 21:04:19 --> Config Class Initialized
INFO - 2016-05-05 21:04:19 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:04:19 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:04:19 --> Utf8 Class Initialized
INFO - 2016-05-05 21:04:19 --> URI Class Initialized
INFO - 2016-05-05 21:04:19 --> Router Class Initialized
INFO - 2016-05-05 21:04:19 --> Output Class Initialized
INFO - 2016-05-05 21:04:19 --> Security Class Initialized
DEBUG - 2016-05-05 21:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:04:19 --> Input Class Initialized
INFO - 2016-05-05 21:04:19 --> Language Class Initialized
INFO - 2016-05-05 21:04:19 --> Loader Class Initialized
INFO - 2016-05-05 21:04:19 --> Helper loaded: url_helper
INFO - 2016-05-05 21:04:19 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:04:19 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:04:19 --> Helper loaded: form_helper
INFO - 2016-05-05 21:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:04:19 --> Form Validation Class Initialized
INFO - 2016-05-05 21:04:19 --> Controller Class Initialized
INFO - 2016-05-05 21:04:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:04:19 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 21:04:19 --> Model Class Initialized
INFO - 2016-05-05 21:04:19 --> Database Driver Class Initialized
INFO - 2016-05-05 21:04:19 --> Language file loaded: language/spanish/form_validation_lang.php
INFO - 2016-05-05 21:04:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-05 21:04:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:04:19 --> Final output sent to browser
DEBUG - 2016-05-05 21:04:19 --> Total execution time: 0.1162
INFO - 2016-05-05 21:04:46 --> Config Class Initialized
INFO - 2016-05-05 21:04:46 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:04:46 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:04:46 --> Utf8 Class Initialized
INFO - 2016-05-05 21:04:46 --> URI Class Initialized
INFO - 2016-05-05 21:04:46 --> Router Class Initialized
INFO - 2016-05-05 21:04:46 --> Output Class Initialized
INFO - 2016-05-05 21:04:46 --> Security Class Initialized
DEBUG - 2016-05-05 21:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:04:46 --> Input Class Initialized
INFO - 2016-05-05 21:04:46 --> Language Class Initialized
INFO - 2016-05-05 21:04:46 --> Loader Class Initialized
INFO - 2016-05-05 21:04:46 --> Helper loaded: url_helper
INFO - 2016-05-05 21:04:46 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:04:46 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:04:46 --> Helper loaded: form_helper
INFO - 2016-05-05 21:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:04:46 --> Form Validation Class Initialized
INFO - 2016-05-05 21:04:46 --> Controller Class Initialized
INFO - 2016-05-05 21:04:46 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:04:46 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 21:04:46 --> Model Class Initialized
INFO - 2016-05-05 21:04:46 --> Database Driver Class Initialized
INFO - 2016-05-05 21:04:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-05 21:04:46 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:04:46 --> Final output sent to browser
DEBUG - 2016-05-05 21:04:46 --> Total execution time: 0.0898
INFO - 2016-05-05 21:06:02 --> Config Class Initialized
INFO - 2016-05-05 21:06:02 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:06:02 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:06:02 --> Utf8 Class Initialized
INFO - 2016-05-05 21:06:02 --> URI Class Initialized
INFO - 2016-05-05 21:06:02 --> Router Class Initialized
INFO - 2016-05-05 21:06:02 --> Output Class Initialized
INFO - 2016-05-05 21:06:02 --> Security Class Initialized
DEBUG - 2016-05-05 21:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:06:02 --> Input Class Initialized
INFO - 2016-05-05 21:06:02 --> Language Class Initialized
INFO - 2016-05-05 21:06:02 --> Loader Class Initialized
INFO - 2016-05-05 21:06:02 --> Helper loaded: url_helper
INFO - 2016-05-05 21:06:02 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:06:02 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:06:02 --> Helper loaded: form_helper
INFO - 2016-05-05 21:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:06:02 --> Form Validation Class Initialized
INFO - 2016-05-05 21:06:02 --> Controller Class Initialized
INFO - 2016-05-05 21:06:02 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:06:02 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 21:06:02 --> Model Class Initialized
INFO - 2016-05-05 21:06:02 --> Database Driver Class Initialized
INFO - 2016-05-05 21:06:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-05 21:06:02 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:06:02 --> Final output sent to browser
DEBUG - 2016-05-05 21:06:02 --> Total execution time: 0.0876
INFO - 2016-05-05 21:06:31 --> Config Class Initialized
INFO - 2016-05-05 21:06:31 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:06:31 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:06:31 --> Utf8 Class Initialized
INFO - 2016-05-05 21:06:31 --> URI Class Initialized
INFO - 2016-05-05 21:06:31 --> Router Class Initialized
INFO - 2016-05-05 21:06:31 --> Output Class Initialized
INFO - 2016-05-05 21:06:31 --> Security Class Initialized
DEBUG - 2016-05-05 21:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:06:31 --> Input Class Initialized
INFO - 2016-05-05 21:06:31 --> Language Class Initialized
INFO - 2016-05-05 21:06:31 --> Loader Class Initialized
INFO - 2016-05-05 21:06:31 --> Helper loaded: url_helper
INFO - 2016-05-05 21:06:31 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:06:31 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:06:31 --> Helper loaded: form_helper
INFO - 2016-05-05 21:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:06:31 --> Form Validation Class Initialized
INFO - 2016-05-05 21:06:31 --> Controller Class Initialized
INFO - 2016-05-05 21:06:31 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:06:31 --> Helper loaded: nif_validate_helper
INFO - 2016-05-05 21:06:31 --> Model Class Initialized
INFO - 2016-05-05 21:06:31 --> Database Driver Class Initialized
INFO - 2016-05-05 21:06:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_addImagenProducto.php
INFO - 2016-05-05 21:06:31 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:06:31 --> Final output sent to browser
DEBUG - 2016-05-05 21:06:31 --> Total execution time: 0.2284
INFO - 2016-05-05 21:06:34 --> Config Class Initialized
INFO - 2016-05-05 21:06:34 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:06:34 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:06:34 --> Utf8 Class Initialized
INFO - 2016-05-05 21:06:34 --> URI Class Initialized
INFO - 2016-05-05 21:06:34 --> Router Class Initialized
INFO - 2016-05-05 21:06:34 --> Output Class Initialized
INFO - 2016-05-05 21:06:34 --> Security Class Initialized
DEBUG - 2016-05-05 21:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:06:34 --> Input Class Initialized
INFO - 2016-05-05 21:06:34 --> Language Class Initialized
INFO - 2016-05-05 21:06:34 --> Loader Class Initialized
INFO - 2016-05-05 21:06:34 --> Helper loaded: url_helper
INFO - 2016-05-05 21:06:34 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:06:34 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:06:34 --> Helper loaded: form_helper
INFO - 2016-05-05 21:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:06:34 --> Form Validation Class Initialized
INFO - 2016-05-05 21:06:34 --> Controller Class Initialized
INFO - 2016-05-05 21:06:34 --> Model Class Initialized
INFO - 2016-05-05 21:06:34 --> Database Driver Class Initialized
INFO - 2016-05-05 21:06:34 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:06:34 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 21:06:34 --> Pagination Class Initialized
DEBUG - 2016-05-05 21:06:34 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 21:06:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 21:06:34 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:06:34 --> Final output sent to browser
DEBUG - 2016-05-05 21:06:34 --> Total execution time: 0.1526
INFO - 2016-05-05 21:06:43 --> Config Class Initialized
INFO - 2016-05-05 21:06:43 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:06:43 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:06:43 --> Utf8 Class Initialized
INFO - 2016-05-05 21:06:43 --> URI Class Initialized
INFO - 2016-05-05 21:06:43 --> Router Class Initialized
INFO - 2016-05-05 21:06:43 --> Output Class Initialized
INFO - 2016-05-05 21:06:43 --> Security Class Initialized
DEBUG - 2016-05-05 21:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:06:43 --> Input Class Initialized
INFO - 2016-05-05 21:06:43 --> Language Class Initialized
INFO - 2016-05-05 21:06:43 --> Loader Class Initialized
INFO - 2016-05-05 21:06:43 --> Helper loaded: url_helper
INFO - 2016-05-05 21:06:43 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:06:43 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:06:43 --> Helper loaded: form_helper
INFO - 2016-05-05 21:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:06:43 --> Form Validation Class Initialized
INFO - 2016-05-05 21:06:43 --> Controller Class Initialized
INFO - 2016-05-05 21:06:43 --> Model Class Initialized
INFO - 2016-05-05 21:06:43 --> Database Driver Class Initialized
INFO - 2016-05-05 21:06:43 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:06:43 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 21:06:43 --> Pagination Class Initialized
DEBUG - 2016-05-05 21:06:43 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 21:06:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 21:06:43 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:06:43 --> Final output sent to browser
DEBUG - 2016-05-05 21:06:43 --> Total execution time: 0.0900
INFO - 2016-05-05 21:08:07 --> Config Class Initialized
INFO - 2016-05-05 21:08:07 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:08:07 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:08:07 --> Utf8 Class Initialized
INFO - 2016-05-05 21:08:07 --> URI Class Initialized
INFO - 2016-05-05 21:08:07 --> Router Class Initialized
INFO - 2016-05-05 21:08:07 --> Output Class Initialized
INFO - 2016-05-05 21:08:07 --> Security Class Initialized
DEBUG - 2016-05-05 21:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:08:07 --> Input Class Initialized
INFO - 2016-05-05 21:08:07 --> Language Class Initialized
INFO - 2016-05-05 21:08:07 --> Loader Class Initialized
INFO - 2016-05-05 21:08:07 --> Helper loaded: url_helper
INFO - 2016-05-05 21:08:07 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:08:07 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:08:07 --> Helper loaded: form_helper
INFO - 2016-05-05 21:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:08:07 --> Form Validation Class Initialized
INFO - 2016-05-05 21:08:07 --> Controller Class Initialized
INFO - 2016-05-05 21:08:07 --> Model Class Initialized
INFO - 2016-05-05 21:08:07 --> Database Driver Class Initialized
INFO - 2016-05-05 21:08:07 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:08:07 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 21:08:07 --> Pagination Class Initialized
DEBUG - 2016-05-05 21:08:07 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 21:08:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 21:08:07 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:08:07 --> Final output sent to browser
DEBUG - 2016-05-05 21:08:07 --> Total execution time: 0.0834
INFO - 2016-05-05 21:08:11 --> Config Class Initialized
INFO - 2016-05-05 21:08:11 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:08:11 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:08:11 --> Utf8 Class Initialized
INFO - 2016-05-05 21:08:11 --> URI Class Initialized
INFO - 2016-05-05 21:08:11 --> Router Class Initialized
INFO - 2016-05-05 21:08:11 --> Output Class Initialized
INFO - 2016-05-05 21:08:11 --> Security Class Initialized
DEBUG - 2016-05-05 21:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:08:11 --> Input Class Initialized
INFO - 2016-05-05 21:08:11 --> Language Class Initialized
INFO - 2016-05-05 21:08:11 --> Loader Class Initialized
INFO - 2016-05-05 21:08:11 --> Helper loaded: url_helper
INFO - 2016-05-05 21:08:11 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:08:11 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:08:11 --> Helper loaded: form_helper
INFO - 2016-05-05 21:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:08:11 --> Form Validation Class Initialized
INFO - 2016-05-05 21:08:11 --> Controller Class Initialized
INFO - 2016-05-05 21:08:11 --> Model Class Initialized
INFO - 2016-05-05 21:08:11 --> Database Driver Class Initialized
INFO - 2016-05-05 21:08:11 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 21:08:11 --> Pagination Class Initialized
DEBUG - 2016-05-05 21:08:11 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 21:08:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-05 21:08:11 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:08:11 --> Final output sent to browser
DEBUG - 2016-05-05 21:08:11 --> Total execution time: 0.0881
INFO - 2016-05-05 21:08:19 --> Config Class Initialized
INFO - 2016-05-05 21:08:19 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:08:19 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:08:19 --> Utf8 Class Initialized
INFO - 2016-05-05 21:08:19 --> URI Class Initialized
INFO - 2016-05-05 21:08:19 --> Router Class Initialized
INFO - 2016-05-05 21:08:19 --> Output Class Initialized
INFO - 2016-05-05 21:08:19 --> Security Class Initialized
DEBUG - 2016-05-05 21:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:08:19 --> Input Class Initialized
INFO - 2016-05-05 21:08:19 --> Language Class Initialized
INFO - 2016-05-05 21:08:19 --> Loader Class Initialized
INFO - 2016-05-05 21:08:19 --> Helper loaded: url_helper
INFO - 2016-05-05 21:08:19 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:08:19 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:08:19 --> Helper loaded: form_helper
INFO - 2016-05-05 21:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:08:19 --> Form Validation Class Initialized
INFO - 2016-05-05 21:08:19 --> Controller Class Initialized
INFO - 2016-05-05 21:08:19 --> Model Class Initialized
INFO - 2016-05-05 21:08:19 --> Database Driver Class Initialized
INFO - 2016-05-05 21:08:19 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:08:19 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 21:08:19 --> Pagination Class Initialized
DEBUG - 2016-05-05 21:08:19 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 21:08:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 21:08:19 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:08:19 --> Final output sent to browser
DEBUG - 2016-05-05 21:08:19 --> Total execution time: 0.1192
INFO - 2016-05-05 21:08:24 --> Config Class Initialized
INFO - 2016-05-05 21:08:24 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:08:24 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:08:24 --> Utf8 Class Initialized
INFO - 2016-05-05 21:08:24 --> URI Class Initialized
INFO - 2016-05-05 21:08:24 --> Router Class Initialized
INFO - 2016-05-05 21:08:24 --> Output Class Initialized
INFO - 2016-05-05 21:08:24 --> Security Class Initialized
DEBUG - 2016-05-05 21:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:08:24 --> Input Class Initialized
INFO - 2016-05-05 21:08:24 --> Language Class Initialized
INFO - 2016-05-05 21:08:24 --> Loader Class Initialized
INFO - 2016-05-05 21:08:24 --> Helper loaded: url_helper
INFO - 2016-05-05 21:08:24 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:08:24 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:08:24 --> Helper loaded: form_helper
INFO - 2016-05-05 21:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:08:24 --> Form Validation Class Initialized
INFO - 2016-05-05 21:08:24 --> Controller Class Initialized
INFO - 2016-05-05 21:08:24 --> Model Class Initialized
INFO - 2016-05-05 21:08:24 --> Database Driver Class Initialized
INFO - 2016-05-05 21:08:24 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 21:08:24 --> Pagination Class Initialized
DEBUG - 2016-05-05 21:08:24 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 21:08:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaCategorias.php
INFO - 2016-05-05 21:08:24 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:08:24 --> Final output sent to browser
DEBUG - 2016-05-05 21:08:24 --> Total execution time: 0.1300
INFO - 2016-05-05 21:08:28 --> Config Class Initialized
INFO - 2016-05-05 21:08:28 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:08:28 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:08:28 --> Utf8 Class Initialized
INFO - 2016-05-05 21:08:28 --> URI Class Initialized
INFO - 2016-05-05 21:08:28 --> Router Class Initialized
INFO - 2016-05-05 21:08:28 --> Output Class Initialized
INFO - 2016-05-05 21:08:28 --> Security Class Initialized
DEBUG - 2016-05-05 21:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:08:28 --> Input Class Initialized
INFO - 2016-05-05 21:08:28 --> Language Class Initialized
INFO - 2016-05-05 21:08:28 --> Loader Class Initialized
INFO - 2016-05-05 21:08:28 --> Helper loaded: url_helper
INFO - 2016-05-05 21:08:28 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:08:28 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:08:28 --> Helper loaded: form_helper
INFO - 2016-05-05 21:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:08:28 --> Form Validation Class Initialized
INFO - 2016-05-05 21:08:28 --> Controller Class Initialized
INFO - 2016-05-05 21:08:28 --> Model Class Initialized
INFO - 2016-05-05 21:08:28 --> Database Driver Class Initialized
INFO - 2016-05-05 21:08:28 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:08:28 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 21:08:28 --> Pagination Class Initialized
DEBUG - 2016-05-05 21:08:28 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 21:08:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 21:08:28 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:08:28 --> Final output sent to browser
DEBUG - 2016-05-05 21:08:28 --> Total execution time: 0.0767
INFO - 2016-05-05 21:09:30 --> Config Class Initialized
INFO - 2016-05-05 21:09:30 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:09:30 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:09:30 --> Utf8 Class Initialized
INFO - 2016-05-05 21:09:30 --> URI Class Initialized
INFO - 2016-05-05 21:09:30 --> Router Class Initialized
INFO - 2016-05-05 21:09:30 --> Output Class Initialized
INFO - 2016-05-05 21:09:30 --> Security Class Initialized
DEBUG - 2016-05-05 21:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:09:30 --> Input Class Initialized
INFO - 2016-05-05 21:09:30 --> Language Class Initialized
INFO - 2016-05-05 21:09:30 --> Loader Class Initialized
INFO - 2016-05-05 21:09:30 --> Helper loaded: url_helper
INFO - 2016-05-05 21:09:30 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:09:30 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:09:30 --> Helper loaded: form_helper
INFO - 2016-05-05 21:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:09:30 --> Form Validation Class Initialized
INFO - 2016-05-05 21:09:30 --> Controller Class Initialized
INFO - 2016-05-05 21:09:30 --> Model Class Initialized
INFO - 2016-05-05 21:09:30 --> Database Driver Class Initialized
INFO - 2016-05-05 21:09:30 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:09:30 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 21:09:30 --> Pagination Class Initialized
DEBUG - 2016-05-05 21:09:30 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 21:09:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 21:09:30 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:09:30 --> Final output sent to browser
DEBUG - 2016-05-05 21:09:30 --> Total execution time: 0.2054
INFO - 2016-05-05 21:09:38 --> Config Class Initialized
INFO - 2016-05-05 21:09:38 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:09:38 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:09:38 --> Utf8 Class Initialized
INFO - 2016-05-05 21:09:38 --> URI Class Initialized
INFO - 2016-05-05 21:09:38 --> Router Class Initialized
INFO - 2016-05-05 21:09:38 --> Output Class Initialized
INFO - 2016-05-05 21:09:38 --> Security Class Initialized
DEBUG - 2016-05-05 21:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:09:38 --> Input Class Initialized
INFO - 2016-05-05 21:09:38 --> Language Class Initialized
INFO - 2016-05-05 21:09:38 --> Loader Class Initialized
INFO - 2016-05-05 21:09:38 --> Helper loaded: url_helper
INFO - 2016-05-05 21:09:38 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:09:38 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:09:38 --> Helper loaded: form_helper
INFO - 2016-05-05 21:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:09:38 --> Form Validation Class Initialized
INFO - 2016-05-05 21:09:38 --> Controller Class Initialized
INFO - 2016-05-05 21:09:38 --> Model Class Initialized
INFO - 2016-05-05 21:09:38 --> Database Driver Class Initialized
INFO - 2016-05-05 21:09:38 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:09:38 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 21:09:38 --> Pagination Class Initialized
DEBUG - 2016-05-05 21:09:38 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 21:09:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 21:09:38 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:09:38 --> Final output sent to browser
DEBUG - 2016-05-05 21:09:38 --> Total execution time: 0.0792
INFO - 2016-05-05 21:09:41 --> Config Class Initialized
INFO - 2016-05-05 21:09:41 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:09:41 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:09:41 --> Utf8 Class Initialized
INFO - 2016-05-05 21:09:41 --> URI Class Initialized
INFO - 2016-05-05 21:09:41 --> Router Class Initialized
INFO - 2016-05-05 21:09:41 --> Output Class Initialized
INFO - 2016-05-05 21:09:41 --> Security Class Initialized
DEBUG - 2016-05-05 21:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:09:41 --> Input Class Initialized
INFO - 2016-05-05 21:09:41 --> Language Class Initialized
INFO - 2016-05-05 21:09:41 --> Loader Class Initialized
INFO - 2016-05-05 21:09:41 --> Helper loaded: url_helper
INFO - 2016-05-05 21:09:41 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:09:41 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:09:41 --> Helper loaded: form_helper
INFO - 2016-05-05 21:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:09:41 --> Form Validation Class Initialized
INFO - 2016-05-05 21:09:41 --> Controller Class Initialized
INFO - 2016-05-05 21:09:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\error404.php
INFO - 2016-05-05 21:09:41 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:09:41 --> Final output sent to browser
DEBUG - 2016-05-05 21:09:41 --> Total execution time: 0.0794
INFO - 2016-05-05 21:09:52 --> Config Class Initialized
INFO - 2016-05-05 21:09:52 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:09:52 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:09:52 --> Utf8 Class Initialized
INFO - 2016-05-05 21:09:52 --> URI Class Initialized
INFO - 2016-05-05 21:09:52 --> Router Class Initialized
INFO - 2016-05-05 21:09:52 --> Output Class Initialized
INFO - 2016-05-05 21:09:52 --> Security Class Initialized
DEBUG - 2016-05-05 21:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:09:52 --> Input Class Initialized
INFO - 2016-05-05 21:09:52 --> Language Class Initialized
INFO - 2016-05-05 21:09:52 --> Loader Class Initialized
INFO - 2016-05-05 21:09:52 --> Helper loaded: url_helper
INFO - 2016-05-05 21:09:52 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:09:52 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:09:52 --> Helper loaded: form_helper
INFO - 2016-05-05 21:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:09:52 --> Form Validation Class Initialized
INFO - 2016-05-05 21:09:52 --> Controller Class Initialized
INFO - 2016-05-05 21:09:52 --> Model Class Initialized
INFO - 2016-05-05 21:09:52 --> Database Driver Class Initialized
INFO - 2016-05-05 21:09:52 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:09:52 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 21:09:52 --> Pagination Class Initialized
DEBUG - 2016-05-05 21:09:52 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 21:09:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 21:09:52 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:09:52 --> Final output sent to browser
DEBUG - 2016-05-05 21:09:52 --> Total execution time: 0.0830
INFO - 2016-05-05 21:09:54 --> Config Class Initialized
INFO - 2016-05-05 21:09:54 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:09:54 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:09:54 --> Utf8 Class Initialized
INFO - 2016-05-05 21:09:54 --> URI Class Initialized
INFO - 2016-05-05 21:09:54 --> Router Class Initialized
INFO - 2016-05-05 21:09:54 --> Output Class Initialized
INFO - 2016-05-05 21:09:54 --> Security Class Initialized
DEBUG - 2016-05-05 21:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:09:54 --> Input Class Initialized
INFO - 2016-05-05 21:09:54 --> Language Class Initialized
INFO - 2016-05-05 21:09:54 --> Loader Class Initialized
INFO - 2016-05-05 21:09:54 --> Helper loaded: url_helper
INFO - 2016-05-05 21:09:54 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:09:54 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:09:54 --> Helper loaded: form_helper
INFO - 2016-05-05 21:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:09:54 --> Form Validation Class Initialized
INFO - 2016-05-05 21:09:54 --> Controller Class Initialized
INFO - 2016-05-05 21:09:54 --> Model Class Initialized
INFO - 2016-05-05 21:09:54 --> Database Driver Class Initialized
INFO - 2016-05-05 21:09:54 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:09:54 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 21:09:54 --> Pagination Class Initialized
DEBUG - 2016-05-05 21:09:54 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 21:09:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 21:09:54 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:09:54 --> Final output sent to browser
DEBUG - 2016-05-05 21:09:54 --> Total execution time: 0.0961
INFO - 2016-05-05 21:09:56 --> Config Class Initialized
INFO - 2016-05-05 21:09:56 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:09:56 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:09:56 --> Utf8 Class Initialized
INFO - 2016-05-05 21:09:56 --> URI Class Initialized
INFO - 2016-05-05 21:09:56 --> Router Class Initialized
INFO - 2016-05-05 21:09:56 --> Output Class Initialized
INFO - 2016-05-05 21:09:56 --> Security Class Initialized
DEBUG - 2016-05-05 21:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:09:56 --> Input Class Initialized
INFO - 2016-05-05 21:09:56 --> Language Class Initialized
INFO - 2016-05-05 21:09:56 --> Loader Class Initialized
INFO - 2016-05-05 21:09:56 --> Helper loaded: url_helper
INFO - 2016-05-05 21:09:56 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:09:56 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:09:56 --> Helper loaded: form_helper
INFO - 2016-05-05 21:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:09:56 --> Form Validation Class Initialized
INFO - 2016-05-05 21:09:56 --> Controller Class Initialized
INFO - 2016-05-05 21:09:56 --> Model Class Initialized
INFO - 2016-05-05 21:09:56 --> Database Driver Class Initialized
INFO - 2016-05-05 21:09:56 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:09:56 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 21:09:56 --> Pagination Class Initialized
DEBUG - 2016-05-05 21:09:56 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 21:09:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_listaProductos.php
INFO - 2016-05-05 21:09:56 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:09:56 --> Final output sent to browser
DEBUG - 2016-05-05 21:09:56 --> Total execution time: 0.1146
INFO - 2016-05-05 21:09:58 --> Config Class Initialized
INFO - 2016-05-05 21:09:58 --> Hooks Class Initialized
DEBUG - 2016-05-05 21:09:58 --> UTF-8 Support Enabled
INFO - 2016-05-05 21:09:58 --> Utf8 Class Initialized
INFO - 2016-05-05 21:09:58 --> URI Class Initialized
INFO - 2016-05-05 21:09:58 --> Router Class Initialized
INFO - 2016-05-05 21:09:58 --> Output Class Initialized
INFO - 2016-05-05 21:09:58 --> Security Class Initialized
DEBUG - 2016-05-05 21:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-05 21:09:58 --> Input Class Initialized
INFO - 2016-05-05 21:09:58 --> Language Class Initialized
INFO - 2016-05-05 21:09:58 --> Loader Class Initialized
INFO - 2016-05-05 21:09:58 --> Helper loaded: url_helper
INFO - 2016-05-05 21:09:58 --> Helper loaded: sesion_helper
INFO - 2016-05-05 21:09:58 --> Helper loaded: templates_helper
INFO - 2016-05-05 21:09:58 --> Helper loaded: form_helper
INFO - 2016-05-05 21:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-05-05 21:09:58 --> Form Validation Class Initialized
INFO - 2016-05-05 21:09:58 --> Controller Class Initialized
INFO - 2016-05-05 21:09:58 --> Model Class Initialized
INFO - 2016-05-05 21:09:58 --> Database Driver Class Initialized
INFO - 2016-05-05 21:09:58 --> Helper loaded: creaselect_helper
INFO - 2016-05-05 21:09:58 --> Language file loaded: language/spanish/pagination_lang.php
INFO - 2016-05-05 21:09:58 --> Pagination Class Initialized
DEBUG - 2016-05-05 21:09:58 --> Config file loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\config/paginacion.php
INFO - 2016-05-05 21:09:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_detalleProducto.php
INFO - 2016-05-05 21:09:58 --> File loaded: C:\xampp\htdocs\Proyecto\Alumno\Fuentes\application\views\adm_template2.php
INFO - 2016-05-05 21:09:58 --> Final output sent to browser
DEBUG - 2016-05-05 21:09:58 --> Total execution time: 0.1164
